/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomAppIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#client_id CustomAppIntegration#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#client_secret CustomAppIntegration#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#confidential CustomAppIntegration#confidential}
    */
    readonly confidential?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#create_time CustomAppIntegration#create_time}
    */
    readonly createTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#created_by CustomAppIntegration#created_by}
    */
    readonly createdBy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#creator_username CustomAppIntegration#creator_username}
    */
    readonly creatorUsername?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#id CustomAppIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#integration_id CustomAppIntegration#integration_id}
    */
    readonly integrationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#name CustomAppIntegration#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#redirect_urls CustomAppIntegration#redirect_urls}
    */
    readonly redirectUrls?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#scopes CustomAppIntegration#scopes}
    */
    readonly scopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#user_authorized_scopes CustomAppIntegration#user_authorized_scopes}
    */
    readonly userAuthorizedScopes?: string[];
    /**
    * token_access_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#token_access_policy CustomAppIntegration#token_access_policy}
    */
    readonly tokenAccessPolicy?: CustomAppIntegrationTokenAccessPolicy;
}
export interface CustomAppIntegrationTokenAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#absolute_session_lifetime_in_minutes CustomAppIntegration#absolute_session_lifetime_in_minutes}
    */
    readonly absoluteSessionLifetimeInMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#access_token_ttl_in_minutes CustomAppIntegration#access_token_ttl_in_minutes}
    */
    readonly accessTokenTtlInMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#enable_single_use_refresh_tokens CustomAppIntegration#enable_single_use_refresh_tokens}
    */
    readonly enableSingleUseRefreshTokens?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#refresh_token_ttl_in_minutes CustomAppIntegration#refresh_token_ttl_in_minutes}
    */
    readonly refreshTokenTtlInMinutes?: number;
}
export declare function customAppIntegrationTokenAccessPolicyToTerraform(struct?: CustomAppIntegrationTokenAccessPolicyOutputReference | CustomAppIntegrationTokenAccessPolicy): any;
export declare function customAppIntegrationTokenAccessPolicyToHclTerraform(struct?: CustomAppIntegrationTokenAccessPolicyOutputReference | CustomAppIntegrationTokenAccessPolicy): any;
export declare class CustomAppIntegrationTokenAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomAppIntegrationTokenAccessPolicy | undefined;
    set internalValue(value: CustomAppIntegrationTokenAccessPolicy | undefined);
    private _absoluteSessionLifetimeInMinutes?;
    get absoluteSessionLifetimeInMinutes(): number;
    set absoluteSessionLifetimeInMinutes(value: number);
    resetAbsoluteSessionLifetimeInMinutes(): void;
    get absoluteSessionLifetimeInMinutesInput(): number | undefined;
    private _accessTokenTtlInMinutes?;
    get accessTokenTtlInMinutes(): number;
    set accessTokenTtlInMinutes(value: number);
    resetAccessTokenTtlInMinutes(): void;
    get accessTokenTtlInMinutesInput(): number | undefined;
    private _enableSingleUseRefreshTokens?;
    get enableSingleUseRefreshTokens(): boolean | cdktn.IResolvable;
    set enableSingleUseRefreshTokens(value: boolean | cdktn.IResolvable);
    resetEnableSingleUseRefreshTokens(): void;
    get enableSingleUseRefreshTokensInput(): boolean | cdktn.IResolvable | undefined;
    private _refreshTokenTtlInMinutes?;
    get refreshTokenTtlInMinutes(): number;
    set refreshTokenTtlInMinutes(value: number);
    resetRefreshTokenTtlInMinutes(): void;
    get refreshTokenTtlInMinutesInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration databricks_custom_app_integration}
*/
export declare class CustomAppIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_custom_app_integration";
    /**
    * Generates CDKTN code for importing a CustomAppIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomAppIntegration to import
    * @param importFromId The id of the existing CustomAppIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomAppIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/custom_app_integration databricks_custom_app_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomAppIntegrationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: CustomAppIntegrationConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _confidential?;
    get confidential(): boolean | cdktn.IResolvable;
    set confidential(value: boolean | cdktn.IResolvable);
    resetConfidential(): void;
    get confidentialInput(): boolean | cdktn.IResolvable | undefined;
    private _createTime?;
    get createTime(): string;
    set createTime(value: string);
    resetCreateTime(): void;
    get createTimeInput(): string | undefined;
    private _createdBy?;
    get createdBy(): number;
    set createdBy(value: number);
    resetCreatedBy(): void;
    get createdByInput(): number | undefined;
    private _creatorUsername?;
    get creatorUsername(): string;
    set creatorUsername(value: string);
    resetCreatorUsername(): void;
    get creatorUsernameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _integrationId?;
    get integrationId(): string;
    set integrationId(value: string);
    resetIntegrationId(): void;
    get integrationIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _redirectUrls?;
    get redirectUrls(): string[];
    set redirectUrls(value: string[]);
    resetRedirectUrls(): void;
    get redirectUrlsInput(): string[] | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _userAuthorizedScopes?;
    get userAuthorizedScopes(): string[];
    set userAuthorizedScopes(value: string[]);
    resetUserAuthorizedScopes(): void;
    get userAuthorizedScopesInput(): string[] | undefined;
    private _tokenAccessPolicy;
    get tokenAccessPolicy(): CustomAppIntegrationTokenAccessPolicyOutputReference;
    putTokenAccessPolicy(value: CustomAppIntegrationTokenAccessPolicy): void;
    resetTokenAccessPolicy(): void;
    get tokenAccessPolicyInput(): CustomAppIntegrationTokenAccessPolicy | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
