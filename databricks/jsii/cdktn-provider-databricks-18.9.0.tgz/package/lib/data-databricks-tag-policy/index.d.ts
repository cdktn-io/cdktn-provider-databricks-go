/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksTagPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/tag_policy#provider_config DataDatabricksTagPolicy#provider_config}
    */
    readonly providerConfig?: DataDatabricksTagPolicyProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/tag_policy#tag_key DataDatabricksTagPolicy#tag_key}
    */
    readonly tagKey: string;
}
export interface DataDatabricksTagPolicyProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/tag_policy#workspace_id DataDatabricksTagPolicy#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksTagPolicyProviderConfigToTerraform(struct?: DataDatabricksTagPolicyProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksTagPolicyProviderConfigToHclTerraform(struct?: DataDatabricksTagPolicyProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksTagPolicyProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTagPolicyProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTagPolicyProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksTagPolicyValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/tag_policy#name DataDatabricksTagPolicy#name}
    */
    readonly name: string;
}
export declare function dataDatabricksTagPolicyValuesToTerraform(struct?: DataDatabricksTagPolicyValues): any;
export declare function dataDatabricksTagPolicyValuesToHclTerraform(struct?: DataDatabricksTagPolicyValues): any;
export declare class DataDatabricksTagPolicyValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTagPolicyValues | undefined;
    set internalValue(value: DataDatabricksTagPolicyValues | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksTagPolicyValuesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTagPolicyValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTagPolicyValuesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/tag_policy databricks_tag_policy}
*/
export declare class DataDatabricksTagPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_tag_policy";
    /**
    * Generates CDKTN code for importing a DataDatabricksTagPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksTagPolicy to import
    * @param importFromId The id of the existing DataDatabricksTagPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/tag_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksTagPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/tag_policy databricks_tag_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksTagPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksTagPolicyConfig);
    get createTime(): string;
    get description(): string;
    get id(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksTagPolicyProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksTagPolicyProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksTagPolicyProviderConfig | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    get updateTime(): string;
    private _values;
    get values(): DataDatabricksTagPolicyValuesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
