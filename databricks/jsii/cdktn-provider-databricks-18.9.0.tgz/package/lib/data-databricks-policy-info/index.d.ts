/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPolicyInfoConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#name DataDatabricksPolicyInfo#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#on_securable_fullname DataDatabricksPolicyInfo#on_securable_fullname}
    */
    readonly onSecurableFullname: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#on_securable_type DataDatabricksPolicyInfo#on_securable_type}
    */
    readonly onSecurableType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#provider_config DataDatabricksPolicyInfo#provider_config}
    */
    readonly providerConfig?: DataDatabricksPolicyInfoProviderConfig;
}
export interface DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#column_alias DataDatabricksPolicyInfo#column_alias}
    */
    readonly columnAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_key DataDatabricksPolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueToTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined);
    private _columnAlias?;
    get columnAlias(): string;
    set columnAlias(value: string);
    get columnAliasInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_key DataDatabricksPolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueToTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#column_tag_value DataDatabricksPolicyInfo#column_tag_value}
    */
    readonly columnTagValue?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_value DataDatabricksPolicyInfo#tag_value}
    */
    readonly tagValue?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue;
}
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionToTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined);
    private _columnTagValue;
    get columnTagValue(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference;
    putColumnTagValue(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue): void;
    resetColumnTagValue(): void;
    get columnTagValueInput(): cdktn.IResolvable | DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | undefined;
    private _tagValue;
    get tagValue(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference;
    putTagValue(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue): void;
    resetTagValue(): void;
    get tagValueInput(): cdktn.IResolvable | DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | undefined;
}
export interface DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_introspection DataDatabricksPolicyInfo#tag_introspection}
    */
    readonly tagIntrospection?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection;
}
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionToTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable | undefined);
    private _tagIntrospection;
    get tagIntrospection(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionOutputReference;
    putTagIntrospection(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection): void;
    resetTagIntrospection(): void;
    get tagIntrospectionInput(): cdktn.IResolvable | DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | undefined;
}
export interface DataDatabricksPolicyInfoColumnMaskUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#alias DataDatabricksPolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#constant DataDatabricksPolicyInfo#constant}
    */
    readonly constant?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#function_arg_expression DataDatabricksPolicyInfo#function_arg_expression}
    */
    readonly functionArgExpression?: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression;
}
export declare function dataDatabricksPolicyInfoColumnMaskUsingToTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoColumnMaskUsingToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoColumnMaskUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMaskUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
    private _functionArgExpression;
    get functionArgExpression(): DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpressionOutputReference;
    putFunctionArgExpression(value: DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression): void;
    resetFunctionArgExpression(): void;
    get functionArgExpressionInput(): cdktn.IResolvable | DataDatabricksPolicyInfoColumnMaskUsingFunctionArgExpression | undefined;
}
export declare class DataDatabricksPolicyInfoColumnMaskUsingList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfoColumnMaskUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfoColumnMaskUsingOutputReference;
}
export interface DataDatabricksPolicyInfoColumnMask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#function_name DataDatabricksPolicyInfo#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#on_column DataDatabricksPolicyInfo#on_column}
    */
    readonly onColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#using DataDatabricksPolicyInfo#using}
    */
    readonly using?: DataDatabricksPolicyInfoColumnMaskUsing[] | cdktn.IResolvable;
}
export declare function dataDatabricksPolicyInfoColumnMaskToTerraform(struct?: DataDatabricksPolicyInfoColumnMask): any;
export declare function dataDatabricksPolicyInfoColumnMaskToHclTerraform(struct?: DataDatabricksPolicyInfoColumnMask): any;
export declare class DataDatabricksPolicyInfoColumnMaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoColumnMask | undefined;
    set internalValue(value: DataDatabricksPolicyInfoColumnMask | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _onColumn?;
    get onColumn(): string;
    set onColumn(value: string);
    get onColumnInput(): string | undefined;
    private _using;
    get using(): DataDatabricksPolicyInfoColumnMaskUsingList;
    putUsing(value: DataDatabricksPolicyInfoColumnMaskUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | DataDatabricksPolicyInfoColumnMaskUsing[] | undefined;
}
export interface DataDatabricksPolicyInfoDeny {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#privileges DataDatabricksPolicyInfo#privileges}
    */
    readonly privileges: string[];
}
export declare function dataDatabricksPolicyInfoDenyToTerraform(struct?: DataDatabricksPolicyInfoDeny): any;
export declare function dataDatabricksPolicyInfoDenyToHclTerraform(struct?: DataDatabricksPolicyInfoDeny): any;
export declare class DataDatabricksPolicyInfoDenyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoDeny | undefined;
    set internalValue(value: DataDatabricksPolicyInfoDeny | undefined);
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
}
export interface DataDatabricksPolicyInfoGrant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#privileges DataDatabricksPolicyInfo#privileges}
    */
    readonly privileges: string[];
}
export declare function dataDatabricksPolicyInfoGrantToTerraform(struct?: DataDatabricksPolicyInfoGrant): any;
export declare function dataDatabricksPolicyInfoGrantToHclTerraform(struct?: DataDatabricksPolicyInfoGrant): any;
export declare class DataDatabricksPolicyInfoGrantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoGrant | undefined;
    set internalValue(value: DataDatabricksPolicyInfoGrant | undefined);
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
}
export interface DataDatabricksPolicyInfoMatchColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#alias DataDatabricksPolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#condition DataDatabricksPolicyInfo#condition}
    */
    readonly condition?: string;
}
export declare function dataDatabricksPolicyInfoMatchColumnsToTerraform(struct?: DataDatabricksPolicyInfoMatchColumns): any;
export declare function dataDatabricksPolicyInfoMatchColumnsToHclTerraform(struct?: DataDatabricksPolicyInfoMatchColumns): any;
export declare class DataDatabricksPolicyInfoMatchColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfoMatchColumns | undefined;
    set internalValue(value: DataDatabricksPolicyInfoMatchColumns | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
}
export declare class DataDatabricksPolicyInfoMatchColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfoMatchColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfoMatchColumnsOutputReference;
}
export interface DataDatabricksPolicyInfoProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#workspace_id DataDatabricksPolicyInfo#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPolicyInfoProviderConfigToTerraform(struct?: DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoProviderConfigToHclTerraform(struct?: DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#column_alias DataDatabricksPolicyInfo#column_alias}
    */
    readonly columnAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_key DataDatabricksPolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueToTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined);
    private _columnAlias?;
    get columnAlias(): string;
    set columnAlias(value: string);
    get columnAliasInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_key DataDatabricksPolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueToTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#column_tag_value DataDatabricksPolicyInfo#column_tag_value}
    */
    readonly columnTagValue?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_value DataDatabricksPolicyInfo#tag_value}
    */
    readonly tagValue?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue;
}
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionToTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined);
    private _columnTagValue;
    get columnTagValue(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference;
    putColumnTagValue(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue): void;
    resetColumnTagValue(): void;
    get columnTagValueInput(): cdktn.IResolvable | DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | undefined;
    private _tagValue;
    get tagValue(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference;
    putTagValue(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue): void;
    resetTagValue(): void;
    get tagValueInput(): cdktn.IResolvable | DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | undefined;
}
export interface DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#tag_introspection DataDatabricksPolicyInfo#tag_introspection}
    */
    readonly tagIntrospection?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection;
}
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionToTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable | undefined);
    private _tagIntrospection;
    get tagIntrospection(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionOutputReference;
    putTagIntrospection(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection): void;
    resetTagIntrospection(): void;
    get tagIntrospectionInput(): cdktn.IResolvable | DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | undefined;
}
export interface DataDatabricksPolicyInfoRowFilterUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#alias DataDatabricksPolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#constant DataDatabricksPolicyInfo#constant}
    */
    readonly constant?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#function_arg_expression DataDatabricksPolicyInfo#function_arg_expression}
    */
    readonly functionArgExpression?: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression;
}
export declare function dataDatabricksPolicyInfoRowFilterUsingToTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable): any;
export declare function dataDatabricksPolicyInfoRowFilterUsingToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable): any;
export declare class DataDatabricksPolicyInfoRowFilterUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilterUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
    private _functionArgExpression;
    get functionArgExpression(): DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpressionOutputReference;
    putFunctionArgExpression(value: DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression): void;
    resetFunctionArgExpression(): void;
    get functionArgExpressionInput(): cdktn.IResolvable | DataDatabricksPolicyInfoRowFilterUsingFunctionArgExpression | undefined;
}
export declare class DataDatabricksPolicyInfoRowFilterUsingList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPolicyInfoRowFilterUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPolicyInfoRowFilterUsingOutputReference;
}
export interface DataDatabricksPolicyInfoRowFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#function_name DataDatabricksPolicyInfo#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#using DataDatabricksPolicyInfo#using}
    */
    readonly using?: DataDatabricksPolicyInfoRowFilterUsing[] | cdktn.IResolvable;
}
export declare function dataDatabricksPolicyInfoRowFilterToTerraform(struct?: DataDatabricksPolicyInfoRowFilter): any;
export declare function dataDatabricksPolicyInfoRowFilterToHclTerraform(struct?: DataDatabricksPolicyInfoRowFilter): any;
export declare class DataDatabricksPolicyInfoRowFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPolicyInfoRowFilter | undefined;
    set internalValue(value: DataDatabricksPolicyInfoRowFilter | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _using;
    get using(): DataDatabricksPolicyInfoRowFilterUsingList;
    putUsing(value: DataDatabricksPolicyInfoRowFilterUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | DataDatabricksPolicyInfoRowFilterUsing[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info databricks_policy_info}
*/
export declare class DataDatabricksPolicyInfo extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_policy_info";
    /**
    * Generates CDKTN code for importing a DataDatabricksPolicyInfo resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPolicyInfo to import
    * @param importFromId The id of the existing DataDatabricksPolicyInfo that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPolicyInfo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/policy_info databricks_policy_info} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPolicyInfoConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPolicyInfoConfig);
    private _columnMask;
    get columnMask(): DataDatabricksPolicyInfoColumnMaskOutputReference;
    get comment(): string;
    get createdAt(): number;
    get createdBy(): string;
    private _deny;
    get deny(): DataDatabricksPolicyInfoDenyOutputReference;
    get exceptPrincipals(): string[];
    get forSecurableType(): string;
    private _grant;
    get grant(): DataDatabricksPolicyInfoGrantOutputReference;
    get id(): string;
    private _matchColumns;
    get matchColumns(): DataDatabricksPolicyInfoMatchColumnsList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onSecurableFullname?;
    get onSecurableFullname(): string;
    set onSecurableFullname(value: string);
    get onSecurableFullnameInput(): string | undefined;
    private _onSecurableType?;
    get onSecurableType(): string;
    set onSecurableType(value: string);
    get onSecurableTypeInput(): string | undefined;
    get policyType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPolicyInfoProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPolicyInfoProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPolicyInfoProviderConfig | undefined;
    private _rowFilter;
    get rowFilter(): DataDatabricksPolicyInfoRowFilterOutputReference;
    get toPrincipals(): string[];
    get updatedAt(): number;
    get updatedBy(): string;
    get whenCondition(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
