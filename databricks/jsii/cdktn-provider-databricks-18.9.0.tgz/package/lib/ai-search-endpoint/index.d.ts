/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiSearchEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#budget_policy_id AiSearchEndpoint#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#custom_tags AiSearchEndpoint#custom_tags}
    */
    readonly customTags?: AiSearchEndpointCustomTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#endpoint_id AiSearchEndpoint#endpoint_id}
    */
    readonly endpointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#endpoint_type AiSearchEndpoint#endpoint_type}
    */
    readonly endpointType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#parent AiSearchEndpoint#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#provider_config AiSearchEndpoint#provider_config}
    */
    readonly providerConfig?: AiSearchEndpointProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#replica_count AiSearchEndpoint#replica_count}
    */
    readonly replicaCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#target_qps AiSearchEndpoint#target_qps}
    */
    readonly targetQps?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#usage_policy_id AiSearchEndpoint#usage_policy_id}
    */
    readonly usagePolicyId?: string;
}
export interface AiSearchEndpointCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#key AiSearchEndpoint#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#value AiSearchEndpoint#value}
    */
    readonly value?: string;
}
export declare function aiSearchEndpointCustomTagsToTerraform(struct?: AiSearchEndpointCustomTags | cdktn.IResolvable): any;
export declare function aiSearchEndpointCustomTagsToHclTerraform(struct?: AiSearchEndpointCustomTags | cdktn.IResolvable): any;
export declare class AiSearchEndpointCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchEndpointCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchEndpointCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class AiSearchEndpointCustomTagsList extends cdktn.ComplexList {
    internalValue?: AiSearchEndpointCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchEndpointCustomTagsOutputReference;
}
export interface AiSearchEndpointEndpointStatus {
}
export declare function aiSearchEndpointEndpointStatusToTerraform(struct?: AiSearchEndpointEndpointStatus): any;
export declare function aiSearchEndpointEndpointStatusToHclTerraform(struct?: AiSearchEndpointEndpointStatus): any;
export declare class AiSearchEndpointEndpointStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchEndpointEndpointStatus | undefined;
    set internalValue(value: AiSearchEndpointEndpointStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface AiSearchEndpointProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#workspace_id AiSearchEndpoint#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function aiSearchEndpointProviderConfigToTerraform(struct?: AiSearchEndpointProviderConfig | cdktn.IResolvable): any;
export declare function aiSearchEndpointProviderConfigToHclTerraform(struct?: AiSearchEndpointProviderConfig | cdktn.IResolvable): any;
export declare class AiSearchEndpointProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchEndpointProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchEndpointProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface AiSearchEndpointScalingInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#requested_target_qps AiSearchEndpoint#requested_target_qps}
    */
    readonly requestedTargetQps?: number;
}
export declare function aiSearchEndpointScalingInfoToTerraform(struct?: AiSearchEndpointScalingInfo): any;
export declare function aiSearchEndpointScalingInfoToHclTerraform(struct?: AiSearchEndpointScalingInfo): any;
export declare class AiSearchEndpointScalingInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchEndpointScalingInfo | undefined;
    set internalValue(value: AiSearchEndpointScalingInfo | undefined);
    private _requestedTargetQps?;
    get requestedTargetQps(): number;
    set requestedTargetQps(value: number);
    resetRequestedTargetQps(): void;
    get requestedTargetQpsInput(): number | undefined;
    get state(): string;
}
export interface AiSearchEndpointThroughputInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#maximum_concurrency_allowed AiSearchEndpoint#maximum_concurrency_allowed}
    */
    readonly maximumConcurrencyAllowed?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#minimal_concurrency_allowed AiSearchEndpoint#minimal_concurrency_allowed}
    */
    readonly minimalConcurrencyAllowed?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#requested_concurrency AiSearchEndpoint#requested_concurrency}
    */
    readonly requestedConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#requested_num_replicas AiSearchEndpoint#requested_num_replicas}
    */
    readonly requestedNumReplicas?: number;
}
export declare function aiSearchEndpointThroughputInfoToTerraform(struct?: AiSearchEndpointThroughputInfo): any;
export declare function aiSearchEndpointThroughputInfoToHclTerraform(struct?: AiSearchEndpointThroughputInfo): any;
export declare class AiSearchEndpointThroughputInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchEndpointThroughputInfo | undefined;
    set internalValue(value: AiSearchEndpointThroughputInfo | undefined);
    get changeRequestMessage(): string;
    get changeRequestState(): string;
    get currentConcurrency(): number;
    get currentConcurrencyUtilizationPercentage(): number;
    get currentNumReplicas(): number;
    private _maximumConcurrencyAllowed?;
    get maximumConcurrencyAllowed(): number;
    set maximumConcurrencyAllowed(value: number);
    resetMaximumConcurrencyAllowed(): void;
    get maximumConcurrencyAllowedInput(): number | undefined;
    private _minimalConcurrencyAllowed?;
    get minimalConcurrencyAllowed(): number;
    set minimalConcurrencyAllowed(value: number);
    resetMinimalConcurrencyAllowed(): void;
    get minimalConcurrencyAllowedInput(): number | undefined;
    private _requestedConcurrency?;
    get requestedConcurrency(): number;
    set requestedConcurrency(value: number);
    resetRequestedConcurrency(): void;
    get requestedConcurrencyInput(): number | undefined;
    private _requestedNumReplicas?;
    get requestedNumReplicas(): number;
    set requestedNumReplicas(value: number);
    resetRequestedNumReplicas(): void;
    get requestedNumReplicasInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint databricks_ai_search_endpoint}
*/
export declare class AiSearchEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_ai_search_endpoint";
    /**
    * Generates CDKTN code for importing a AiSearchEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiSearchEndpoint to import
    * @param importFromId The id of the existing AiSearchEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiSearchEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_search_endpoint databricks_ai_search_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiSearchEndpointConfig
    */
    constructor(scope: Construct, id: string, config: AiSearchEndpointConfig);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    get createTime(): string;
    get creator(): string;
    private _customTags;
    get customTags(): AiSearchEndpointCustomTagsList;
    putCustomTags(value: AiSearchEndpointCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | AiSearchEndpointCustomTags[] | undefined;
    get effectiveBudgetPolicyId(): string;
    private _endpointId?;
    get endpointId(): string;
    set endpointId(value: string);
    resetEndpointId(): void;
    get endpointIdInput(): string | undefined;
    private _endpointStatus;
    get endpointStatus(): AiSearchEndpointEndpointStatusOutputReference;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    get endpointTypeInput(): string | undefined;
    get id(): string;
    get indexCount(): number;
    get lastUpdatedUser(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AiSearchEndpointProviderConfigOutputReference;
    putProviderConfig(value: AiSearchEndpointProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AiSearchEndpointProviderConfig | undefined;
    private _replicaCount?;
    get replicaCount(): number;
    set replicaCount(value: number);
    resetReplicaCount(): void;
    get replicaCountInput(): number | undefined;
    private _scalingInfo;
    get scalingInfo(): AiSearchEndpointScalingInfoOutputReference;
    private _targetQps?;
    get targetQps(): number;
    set targetQps(value: number);
    resetTargetQps(): void;
    get targetQpsInput(): number | undefined;
    private _throughputInfo;
    get throughputInfo(): AiSearchEndpointThroughputInfoOutputReference;
    get updateTime(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
