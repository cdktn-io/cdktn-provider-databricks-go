/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsOutputReference, PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions, PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptionsOutputReference, PipelineIngestionDefinitionObjectsReport, PipelineIngestionDefinitionObjectsReportOutputReference, PipelineIngestionDefinitionObjectsSchema, PipelineIngestionDefinitionObjectsSchemaOutputReference, PipelineIngestionDefinitionDataStagingOptions, PipelineIngestionDefinitionDataStagingOptionsOutputReference, PipelineIngestionDefinitionFullRefreshWindow, PipelineIngestionDefinitionFullRefreshWindowOutputReference } from './structs0';
export interface PipelineIngestionDefinitionObjectsTableConnectorOptions {
    /**
    * api_source_connector_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#api_source_connector_options Pipeline#api_source_connector_options}
    */
    readonly apiSourceConnectorOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions;
    /**
    * confluence_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#confluence_options Pipeline#confluence_options}
    */
    readonly confluenceOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions;
    /**
    * gdrive_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#gdrive_options Pipeline#gdrive_options}
    */
    readonly gdriveOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions;
    /**
    * google_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#google_ads_options Pipeline#google_ads_options}
    */
    readonly googleAdsOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions;
    /**
    * jira_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#jira_options Pipeline#jira_options}
    */
    readonly jiraOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions;
    /**
    * kafka_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#kafka_options Pipeline#kafka_options}
    */
    readonly kafkaOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions;
    /**
    * linkedin_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#linkedin_ads_options Pipeline#linkedin_ads_options}
    */
    readonly linkedinAdsOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions;
    /**
    * marketo_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#marketo_options Pipeline#marketo_options}
    */
    readonly marketoOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions;
    /**
    * meta_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#meta_ads_options Pipeline#meta_ads_options}
    */
    readonly metaAdsOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions;
    /**
    * outlook_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#outlook_options Pipeline#outlook_options}
    */
    readonly outlookOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions;
    /**
    * rabbitmq_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#rabbitmq_options Pipeline#rabbitmq_options}
    */
    readonly rabbitmqOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions;
    /**
    * reddit_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#reddit_ads_options Pipeline#reddit_ads_options}
    */
    readonly redditAdsOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions;
    /**
    * sharepoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#sharepoint_options Pipeline#sharepoint_options}
    */
    readonly sharepointOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions;
    /**
    * smartsheet_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#smartsheet_options Pipeline#smartsheet_options}
    */
    readonly smartsheetOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions;
    /**
    * tiktok_ads_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#tiktok_ads_options Pipeline#tiktok_ads_options}
    */
    readonly tiktokAdsOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions;
    /**
    * zendesk_support_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#zendesk_support_options Pipeline#zendesk_support_options}
    */
    readonly zendeskSupportOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions;
}
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsToTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptions): any;
export declare function pipelineIngestionDefinitionObjectsTableConnectorOptionsToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableConnectorOptionsOutputReference | PipelineIngestionDefinitionObjectsTableConnectorOptions): any;
export declare class PipelineIngestionDefinitionObjectsTableConnectorOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableConnectorOptions | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableConnectorOptions | undefined);
    private _apiSourceConnectorOptions;
    get apiSourceConnectorOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptionsOutputReference;
    putApiSourceConnectorOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions): void;
    resetApiSourceConnectorOptions(): void;
    get apiSourceConnectorOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsApiSourceConnectorOptions | undefined;
    private _confluenceOptions;
    get confluenceOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptionsOutputReference;
    putConfluenceOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions): void;
    resetConfluenceOptions(): void;
    get confluenceOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsConfluenceOptions | undefined;
    private _gdriveOptions;
    get gdriveOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptionsOutputReference;
    putGdriveOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions): void;
    resetGdriveOptions(): void;
    get gdriveOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGdriveOptions | undefined;
    private _googleAdsOptions;
    get googleAdsOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptionsOutputReference;
    putGoogleAdsOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions): void;
    resetGoogleAdsOptions(): void;
    get googleAdsOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsGoogleAdsOptions | undefined;
    private _jiraOptions;
    get jiraOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptionsOutputReference;
    putJiraOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions): void;
    resetJiraOptions(): void;
    get jiraOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsJiraOptions | undefined;
    private _kafkaOptions;
    get kafkaOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptionsOutputReference;
    putKafkaOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions): void;
    resetKafkaOptions(): void;
    get kafkaOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsKafkaOptions | undefined;
    private _linkedinAdsOptions;
    get linkedinAdsOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptionsOutputReference;
    putLinkedinAdsOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions): void;
    resetLinkedinAdsOptions(): void;
    get linkedinAdsOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsLinkedinAdsOptions | undefined;
    private _marketoOptions;
    get marketoOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptionsOutputReference;
    putMarketoOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions): void;
    resetMarketoOptions(): void;
    get marketoOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMarketoOptions | undefined;
    private _metaAdsOptions;
    get metaAdsOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptionsOutputReference;
    putMetaAdsOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions): void;
    resetMetaAdsOptions(): void;
    get metaAdsOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsMetaAdsOptions | undefined;
    private _outlookOptions;
    get outlookOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptionsOutputReference;
    putOutlookOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions): void;
    resetOutlookOptions(): void;
    get outlookOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsOutlookOptions | undefined;
    private _rabbitmqOptions;
    get rabbitmqOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptionsOutputReference;
    putRabbitmqOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions): void;
    resetRabbitmqOptions(): void;
    get rabbitmqOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRabbitmqOptions | undefined;
    private _redditAdsOptions;
    get redditAdsOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptionsOutputReference;
    putRedditAdsOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions): void;
    resetRedditAdsOptions(): void;
    get redditAdsOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsRedditAdsOptions | undefined;
    private _sharepointOptions;
    get sharepointOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptionsOutputReference;
    putSharepointOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions): void;
    resetSharepointOptions(): void;
    get sharepointOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSharepointOptions | undefined;
    private _smartsheetOptions;
    get smartsheetOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptionsOutputReference;
    putSmartsheetOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions): void;
    resetSmartsheetOptions(): void;
    get smartsheetOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsSmartsheetOptions | undefined;
    private _tiktokAdsOptions;
    get tiktokAdsOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptionsOutputReference;
    putTiktokAdsOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions): void;
    resetTiktokAdsOptions(): void;
    get tiktokAdsOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsTiktokAdsOptions | undefined;
    private _zendeskSupportOptions;
    get zendeskSupportOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptionsOutputReference;
    putZendeskSupportOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions): void;
    resetZendeskSupportOptions(): void;
    get zendeskSupportOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptionsZendeskSupportOptions | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#enabled Pipeline#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#min_interval_hours Pipeline#min_interval_hours}
    */
    readonly minIntervalHours?: number;
}
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicyToTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy): any;
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicyToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy): any;
export declare class PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _minIntervalHours?;
    get minIntervalHours(): number;
    set minIntervalHours(value: number);
    resetMinIntervalHours(): void;
    get minIntervalHoursInput(): number | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#cursor_columns Pipeline#cursor_columns}
    */
    readonly cursorColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#deletion_condition Pipeline#deletion_condition}
    */
    readonly deletionCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#hard_deletion_sync_min_interval_in_seconds Pipeline#hard_deletion_sync_min_interval_in_seconds}
    */
    readonly hardDeletionSyncMinIntervalInSeconds?: number;
}
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfigToTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig): any;
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfigToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig): any;
export declare class PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig | undefined);
    private _cursorColumns?;
    get cursorColumns(): string[];
    set cursorColumns(value: string[]);
    resetCursorColumns(): void;
    get cursorColumnsInput(): string[] | undefined;
    private _deletionCondition?;
    get deletionCondition(): string;
    set deletionCondition(value: string);
    resetDeletionCondition(): void;
    get deletionConditionInput(): string | undefined;
    private _hardDeletionSyncMinIntervalInSeconds?;
    get hardDeletionSyncMinIntervalInSeconds(): number;
    set hardDeletionSyncMinIntervalInSeconds(value: number);
    resetHardDeletionSyncMinIntervalInSeconds(): void;
    get hardDeletionSyncMinIntervalInSecondsInput(): number | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#key Pipeline#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#value Pipeline#value}
    */
    readonly value?: string;
}
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParametersToTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParametersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParametersOutputReference;
}
export interface PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#incremental Pipeline#incremental}
    */
    readonly incremental?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#parameters Pipeline#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#report_parameters Pipeline#report_parameters}
    */
    readonly reportParameters?: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersToTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters): any;
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters): any;
export declare class PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters | undefined);
    private _incremental?;
    get incremental(): boolean | cdktn.IResolvable;
    set incremental(value: boolean | cdktn.IResolvable);
    resetIncremental(): void;
    get incrementalInput(): boolean | cdktn.IResolvable | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _reportParameters;
    get reportParameters(): PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParametersList;
    putReportParameters(value: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable): void;
    resetReportParameters(): void;
    get reportParametersInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersReportParameters[] | undefined;
}
export interface PipelineIngestionDefinitionObjectsTableTableConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#clustering_columns Pipeline#clustering_columns}
    */
    readonly clusteringColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#enable_auto_clustering Pipeline#enable_auto_clustering}
    */
    readonly enableAutoClustering?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#exclude_columns Pipeline#exclude_columns}
    */
    readonly excludeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#include_columns Pipeline#include_columns}
    */
    readonly includeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#primary_keys Pipeline#primary_keys}
    */
    readonly primaryKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#row_filter Pipeline#row_filter}
    */
    readonly rowFilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#salesforce_include_formula_fields Pipeline#salesforce_include_formula_fields}
    */
    readonly salesforceIncludeFormulaFields?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#scd_type Pipeline#scd_type}
    */
    readonly scdType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#sequence_by Pipeline#sequence_by}
    */
    readonly sequenceBy?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_metadata_column Pipeline#source_metadata_column}
    */
    readonly sourceMetadataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#table_properties Pipeline#table_properties}
    */
    readonly tableProperties?: {
        [key: string]: string;
    };
    /**
    * auto_full_refresh_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#auto_full_refresh_policy Pipeline#auto_full_refresh_policy}
    */
    readonly autoFullRefreshPolicy?: PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy;
    /**
    * query_based_connector_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#query_based_connector_config Pipeline#query_based_connector_config}
    */
    readonly queryBasedConnectorConfig?: PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig;
    /**
    * workday_report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#workday_report_parameters Pipeline#workday_report_parameters}
    */
    readonly workdayReportParameters?: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters;
}
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationToTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationOutputReference | PipelineIngestionDefinitionObjectsTableTableConfiguration): any;
export declare function pipelineIngestionDefinitionObjectsTableTableConfigurationToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableTableConfigurationOutputReference | PipelineIngestionDefinitionObjectsTableTableConfiguration): any;
export declare class PipelineIngestionDefinitionObjectsTableTableConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTableTableConfiguration | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTableTableConfiguration | undefined);
    private _clusteringColumns?;
    get clusteringColumns(): string[];
    set clusteringColumns(value: string[]);
    resetClusteringColumns(): void;
    get clusteringColumnsInput(): string[] | undefined;
    private _enableAutoClustering?;
    get enableAutoClustering(): boolean | cdktn.IResolvable;
    set enableAutoClustering(value: boolean | cdktn.IResolvable);
    resetEnableAutoClustering(): void;
    get enableAutoClusteringInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeColumns?;
    get excludeColumns(): string[];
    set excludeColumns(value: string[]);
    resetExcludeColumns(): void;
    get excludeColumnsInput(): string[] | undefined;
    private _includeColumns?;
    get includeColumns(): string[];
    set includeColumns(value: string[]);
    resetIncludeColumns(): void;
    get includeColumnsInput(): string[] | undefined;
    private _primaryKeys?;
    get primaryKeys(): string[];
    set primaryKeys(value: string[]);
    resetPrimaryKeys(): void;
    get primaryKeysInput(): string[] | undefined;
    private _rowFilter?;
    get rowFilter(): string;
    set rowFilter(value: string);
    resetRowFilter(): void;
    get rowFilterInput(): string | undefined;
    private _salesforceIncludeFormulaFields?;
    get salesforceIncludeFormulaFields(): boolean | cdktn.IResolvable;
    set salesforceIncludeFormulaFields(value: boolean | cdktn.IResolvable);
    resetSalesforceIncludeFormulaFields(): void;
    get salesforceIncludeFormulaFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _scdType?;
    get scdType(): string;
    set scdType(value: string);
    resetScdType(): void;
    get scdTypeInput(): string | undefined;
    private _sequenceBy?;
    get sequenceBy(): string[];
    set sequenceBy(value: string[]);
    resetSequenceBy(): void;
    get sequenceByInput(): string[] | undefined;
    private _sourceMetadataColumn?;
    get sourceMetadataColumn(): string;
    set sourceMetadataColumn(value: string);
    resetSourceMetadataColumn(): void;
    get sourceMetadataColumnInput(): string | undefined;
    private _tableProperties?;
    get tableProperties(): {
        [key: string]: string;
    };
    set tableProperties(value: {
        [key: string]: string;
    });
    resetTableProperties(): void;
    get tablePropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _autoFullRefreshPolicy;
    get autoFullRefreshPolicy(): PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicyOutputReference;
    putAutoFullRefreshPolicy(value: PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy): void;
    resetAutoFullRefreshPolicy(): void;
    get autoFullRefreshPolicyInput(): PipelineIngestionDefinitionObjectsTableTableConfigurationAutoFullRefreshPolicy | undefined;
    private _queryBasedConnectorConfig;
    get queryBasedConnectorConfig(): PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfigOutputReference;
    putQueryBasedConnectorConfig(value: PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig): void;
    resetQueryBasedConnectorConfig(): void;
    get queryBasedConnectorConfigInput(): PipelineIngestionDefinitionObjectsTableTableConfigurationQueryBasedConnectorConfig | undefined;
    private _workdayReportParameters;
    get workdayReportParameters(): PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParametersOutputReference;
    putWorkdayReportParameters(value: PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters): void;
    resetWorkdayReportParameters(): void;
    get workdayReportParametersInput(): PipelineIngestionDefinitionObjectsTableTableConfigurationWorkdayReportParameters | undefined;
}
export interface PipelineIngestionDefinitionObjectsTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#destination_catalog Pipeline#destination_catalog}
    */
    readonly destinationCatalog: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#destination_schema Pipeline#destination_schema}
    */
    readonly destinationSchema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#destination_table Pipeline#destination_table}
    */
    readonly destinationTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_catalog Pipeline#source_catalog}
    */
    readonly sourceCatalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_schema Pipeline#source_schema}
    */
    readonly sourceSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_table Pipeline#source_table}
    */
    readonly sourceTable?: string;
    /**
    * connector_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#connector_options Pipeline#connector_options}
    */
    readonly connectorOptions?: PipelineIngestionDefinitionObjectsTableConnectorOptions;
    /**
    * table_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#table_configuration Pipeline#table_configuration}
    */
    readonly tableConfiguration?: PipelineIngestionDefinitionObjectsTableTableConfiguration;
}
export declare function pipelineIngestionDefinitionObjectsTableToTerraform(struct?: PipelineIngestionDefinitionObjectsTableOutputReference | PipelineIngestionDefinitionObjectsTable): any;
export declare function pipelineIngestionDefinitionObjectsTableToHclTerraform(struct?: PipelineIngestionDefinitionObjectsTableOutputReference | PipelineIngestionDefinitionObjectsTable): any;
export declare class PipelineIngestionDefinitionObjectsTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionObjectsTable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjectsTable | undefined);
    private _destinationCatalog?;
    get destinationCatalog(): string;
    set destinationCatalog(value: string);
    get destinationCatalogInput(): string | undefined;
    private _destinationSchema?;
    get destinationSchema(): string;
    set destinationSchema(value: string);
    get destinationSchemaInput(): string | undefined;
    private _destinationTable?;
    get destinationTable(): string;
    set destinationTable(value: string);
    resetDestinationTable(): void;
    get destinationTableInput(): string | undefined;
    private _sourceCatalog?;
    get sourceCatalog(): string;
    set sourceCatalog(value: string);
    resetSourceCatalog(): void;
    get sourceCatalogInput(): string | undefined;
    private _sourceSchema?;
    get sourceSchema(): string;
    set sourceSchema(value: string);
    resetSourceSchema(): void;
    get sourceSchemaInput(): string | undefined;
    private _sourceTable?;
    get sourceTable(): string;
    set sourceTable(value: string);
    resetSourceTable(): void;
    get sourceTableInput(): string | undefined;
    private _connectorOptions;
    get connectorOptions(): PipelineIngestionDefinitionObjectsTableConnectorOptionsOutputReference;
    putConnectorOptions(value: PipelineIngestionDefinitionObjectsTableConnectorOptions): void;
    resetConnectorOptions(): void;
    get connectorOptionsInput(): PipelineIngestionDefinitionObjectsTableConnectorOptions | undefined;
    private _tableConfiguration;
    get tableConfiguration(): PipelineIngestionDefinitionObjectsTableTableConfigurationOutputReference;
    putTableConfiguration(value: PipelineIngestionDefinitionObjectsTableTableConfiguration): void;
    resetTableConfiguration(): void;
    get tableConfigurationInput(): PipelineIngestionDefinitionObjectsTableTableConfiguration | undefined;
}
export interface PipelineIngestionDefinitionObjects {
    /**
    * report block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#report Pipeline#report}
    */
    readonly report?: PipelineIngestionDefinitionObjectsReport;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: PipelineIngestionDefinitionObjectsSchema;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#table Pipeline#table}
    */
    readonly table?: PipelineIngestionDefinitionObjectsTable;
}
export declare function pipelineIngestionDefinitionObjectsToTerraform(struct?: PipelineIngestionDefinitionObjects | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionObjectsToHclTerraform(struct?: PipelineIngestionDefinitionObjects | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionObjectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionObjects | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionObjects | cdktn.IResolvable | undefined);
    private _report;
    get report(): PipelineIngestionDefinitionObjectsReportOutputReference;
    putReport(value: PipelineIngestionDefinitionObjectsReport): void;
    resetReport(): void;
    get reportInput(): PipelineIngestionDefinitionObjectsReport | undefined;
    private _schema;
    get schema(): PipelineIngestionDefinitionObjectsSchemaOutputReference;
    putSchema(value: PipelineIngestionDefinitionObjectsSchema): void;
    resetSchema(): void;
    get schemaInput(): PipelineIngestionDefinitionObjectsSchema | undefined;
    private _table;
    get table(): PipelineIngestionDefinitionObjectsTableOutputReference;
    putTable(value: PipelineIngestionDefinitionObjectsTable): void;
    resetTable(): void;
    get tableInput(): PipelineIngestionDefinitionObjectsTable | undefined;
}
export declare class PipelineIngestionDefinitionObjectsList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionObjects[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionObjectsOutputReference;
}
export interface PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#configs Pipeline#configs}
    */
    readonly configs?: {
        [key: string]: string;
    };
}
export declare function pipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfigToTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfigOutputReference | PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig): any;
export declare function pipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfigToHclTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfigOutputReference | PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig): any;
export declare class PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig | undefined;
    set internalValue(value: PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig | undefined);
    private _configs?;
    get configs(): {
        [key: string]: string;
    };
    set configs(value: {
        [key: string]: string;
    });
    resetConfigs(): void;
    get configsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#publication_name Pipeline#publication_name}
    */
    readonly publicationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#slot_name Pipeline#slot_name}
    */
    readonly slotName?: string;
}
export declare function pipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfigToTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfigOutputReference | PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig): any;
export declare function pipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfigToHclTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfigOutputReference | PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig): any;
export declare class PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig | undefined;
    set internalValue(value: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig | undefined);
    private _publicationName?;
    get publicationName(): string;
    set publicationName(value: string);
    resetPublicationName(): void;
    get publicationNameInput(): string | undefined;
    private _slotName?;
    get slotName(): string;
    set slotName(value: string);
    resetSlotName(): void;
    get slotNameInput(): string | undefined;
}
export interface PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres {
    /**
    * slot_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#slot_config Pipeline#slot_config}
    */
    readonly slotConfig?: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig;
}
export declare function pipelineIngestionDefinitionSourceConfigurationsCatalogPostgresToTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresOutputReference | PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres): any;
export declare function pipelineIngestionDefinitionSourceConfigurationsCatalogPostgresToHclTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresOutputReference | PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres): any;
export declare class PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres | undefined;
    set internalValue(value: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres | undefined);
    private _slotConfig;
    get slotConfig(): PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfigOutputReference;
    putSlotConfig(value: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig): void;
    resetSlotConfig(): void;
    get slotConfigInput(): PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresSlotConfig | undefined;
}
export interface PipelineIngestionDefinitionSourceConfigurationsCatalog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_catalog Pipeline#source_catalog}
    */
    readonly sourceCatalog?: string;
    /**
    * postgres block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#postgres Pipeline#postgres}
    */
    readonly postgres?: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres;
}
export declare function pipelineIngestionDefinitionSourceConfigurationsCatalogToTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsCatalogOutputReference | PipelineIngestionDefinitionSourceConfigurationsCatalog): any;
export declare function pipelineIngestionDefinitionSourceConfigurationsCatalogToHclTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsCatalogOutputReference | PipelineIngestionDefinitionSourceConfigurationsCatalog): any;
export declare class PipelineIngestionDefinitionSourceConfigurationsCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionSourceConfigurationsCatalog | undefined;
    set internalValue(value: PipelineIngestionDefinitionSourceConfigurationsCatalog | undefined);
    private _sourceCatalog?;
    get sourceCatalog(): string;
    set sourceCatalog(value: string);
    resetSourceCatalog(): void;
    get sourceCatalogInput(): string | undefined;
    private _postgres;
    get postgres(): PipelineIngestionDefinitionSourceConfigurationsCatalogPostgresOutputReference;
    putPostgres(value: PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres): void;
    resetPostgres(): void;
    get postgresInput(): PipelineIngestionDefinitionSourceConfigurationsCatalogPostgres | undefined;
}
export interface PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#manager_account_id Pipeline#manager_account_id}
    */
    readonly managerAccountId?: string;
}
export declare function pipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfigToTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfigOutputReference | PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig): any;
export declare function pipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfigToHclTerraform(struct?: PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfigOutputReference | PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig): any;
export declare class PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig | undefined;
    set internalValue(value: PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig | undefined);
    private _managerAccountId?;
    get managerAccountId(): string;
    set managerAccountId(value: string);
    resetManagerAccountId(): void;
    get managerAccountIdInput(): string | undefined;
}
export interface PipelineIngestionDefinitionSourceConfigurations {
    /**
    * api_source_connector_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#api_source_connector_config Pipeline#api_source_connector_config}
    */
    readonly apiSourceConnectorConfig?: PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig;
    /**
    * catalog block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#catalog Pipeline#catalog}
    */
    readonly catalog?: PipelineIngestionDefinitionSourceConfigurationsCatalog;
    /**
    * google_ads_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#google_ads_config Pipeline#google_ads_config}
    */
    readonly googleAdsConfig?: PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig;
}
export declare function pipelineIngestionDefinitionSourceConfigurationsToTerraform(struct?: PipelineIngestionDefinitionSourceConfigurations | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionSourceConfigurationsToHclTerraform(struct?: PipelineIngestionDefinitionSourceConfigurations | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionSourceConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionSourceConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionSourceConfigurations | cdktn.IResolvable | undefined);
    private _apiSourceConnectorConfig;
    get apiSourceConnectorConfig(): PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfigOutputReference;
    putApiSourceConnectorConfig(value: PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig): void;
    resetApiSourceConnectorConfig(): void;
    get apiSourceConnectorConfigInput(): PipelineIngestionDefinitionSourceConfigurationsApiSourceConnectorConfig | undefined;
    private _catalog;
    get catalog(): PipelineIngestionDefinitionSourceConfigurationsCatalogOutputReference;
    putCatalog(value: PipelineIngestionDefinitionSourceConfigurationsCatalog): void;
    resetCatalog(): void;
    get catalogInput(): PipelineIngestionDefinitionSourceConfigurationsCatalog | undefined;
    private _googleAdsConfig;
    get googleAdsConfig(): PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfigOutputReference;
    putGoogleAdsConfig(value: PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig): void;
    resetGoogleAdsConfig(): void;
    get googleAdsConfigInput(): PipelineIngestionDefinitionSourceConfigurationsGoogleAdsConfig | undefined;
}
export declare class PipelineIngestionDefinitionSourceConfigurationsList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionSourceConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionSourceConfigurationsOutputReference;
}
export interface PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#enabled Pipeline#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#min_interval_hours Pipeline#min_interval_hours}
    */
    readonly minIntervalHours?: number;
}
export declare function pipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicyToTerraform(struct?: PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy): any;
export declare function pipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicyToHclTerraform(struct?: PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicyOutputReference | PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy): any;
export declare class PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy | undefined;
    set internalValue(value: PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _minIntervalHours?;
    get minIntervalHours(): number;
    set minIntervalHours(value: number);
    resetMinIntervalHours(): void;
    get minIntervalHoursInput(): number | undefined;
}
export interface PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#cursor_columns Pipeline#cursor_columns}
    */
    readonly cursorColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#deletion_condition Pipeline#deletion_condition}
    */
    readonly deletionCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#hard_deletion_sync_min_interval_in_seconds Pipeline#hard_deletion_sync_min_interval_in_seconds}
    */
    readonly hardDeletionSyncMinIntervalInSeconds?: number;
}
export declare function pipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfigToTerraform(struct?: PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig): any;
export declare function pipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfigToHclTerraform(struct?: PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfigOutputReference | PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig): any;
export declare class PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig | undefined;
    set internalValue(value: PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig | undefined);
    private _cursorColumns?;
    get cursorColumns(): string[];
    set cursorColumns(value: string[]);
    resetCursorColumns(): void;
    get cursorColumnsInput(): string[] | undefined;
    private _deletionCondition?;
    get deletionCondition(): string;
    set deletionCondition(value: string);
    resetDeletionCondition(): void;
    get deletionConditionInput(): string | undefined;
    private _hardDeletionSyncMinIntervalInSeconds?;
    get hardDeletionSyncMinIntervalInSeconds(): number;
    set hardDeletionSyncMinIntervalInSeconds(value: number);
    resetHardDeletionSyncMinIntervalInSeconds(): void;
    get hardDeletionSyncMinIntervalInSecondsInput(): number | undefined;
}
export interface PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#key Pipeline#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#value Pipeline#value}
    */
    readonly value?: string;
}
export declare function pipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParametersToTerraform(struct?: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare function pipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable): any;
export declare class PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParametersList extends cdktn.ComplexList {
    internalValue?: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParametersOutputReference;
}
export interface PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#incremental Pipeline#incremental}
    */
    readonly incremental?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#parameters Pipeline#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#report_parameters Pipeline#report_parameters}
    */
    readonly reportParameters?: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable;
}
export declare function pipelineIngestionDefinitionTableConfigurationWorkdayReportParametersToTerraform(struct?: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters): any;
export declare function pipelineIngestionDefinitionTableConfigurationWorkdayReportParametersToHclTerraform(struct?: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersOutputReference | PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters): any;
export declare class PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters | undefined;
    set internalValue(value: PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters | undefined);
    private _incremental?;
    get incremental(): boolean | cdktn.IResolvable;
    set incremental(value: boolean | cdktn.IResolvable);
    resetIncremental(): void;
    get incrementalInput(): boolean | cdktn.IResolvable | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _reportParameters;
    get reportParameters(): PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParametersList;
    putReportParameters(value: PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters[] | cdktn.IResolvable): void;
    resetReportParameters(): void;
    get reportParametersInput(): cdktn.IResolvable | PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersReportParameters[] | undefined;
}
export interface PipelineIngestionDefinitionTableConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#clustering_columns Pipeline#clustering_columns}
    */
    readonly clusteringColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#enable_auto_clustering Pipeline#enable_auto_clustering}
    */
    readonly enableAutoClustering?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#exclude_columns Pipeline#exclude_columns}
    */
    readonly excludeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#include_columns Pipeline#include_columns}
    */
    readonly includeColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#primary_keys Pipeline#primary_keys}
    */
    readonly primaryKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#row_filter Pipeline#row_filter}
    */
    readonly rowFilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#salesforce_include_formula_fields Pipeline#salesforce_include_formula_fields}
    */
    readonly salesforceIncludeFormulaFields?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#scd_type Pipeline#scd_type}
    */
    readonly scdType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#sequence_by Pipeline#sequence_by}
    */
    readonly sequenceBy?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_metadata_column Pipeline#source_metadata_column}
    */
    readonly sourceMetadataColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#table_properties Pipeline#table_properties}
    */
    readonly tableProperties?: {
        [key: string]: string;
    };
    /**
    * auto_full_refresh_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#auto_full_refresh_policy Pipeline#auto_full_refresh_policy}
    */
    readonly autoFullRefreshPolicy?: PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy;
    /**
    * query_based_connector_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#query_based_connector_config Pipeline#query_based_connector_config}
    */
    readonly queryBasedConnectorConfig?: PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig;
    /**
    * workday_report_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#workday_report_parameters Pipeline#workday_report_parameters}
    */
    readonly workdayReportParameters?: PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters;
}
export declare function pipelineIngestionDefinitionTableConfigurationToTerraform(struct?: PipelineIngestionDefinitionTableConfigurationOutputReference | PipelineIngestionDefinitionTableConfiguration): any;
export declare function pipelineIngestionDefinitionTableConfigurationToHclTerraform(struct?: PipelineIngestionDefinitionTableConfigurationOutputReference | PipelineIngestionDefinitionTableConfiguration): any;
export declare class PipelineIngestionDefinitionTableConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinitionTableConfiguration | undefined;
    set internalValue(value: PipelineIngestionDefinitionTableConfiguration | undefined);
    private _clusteringColumns?;
    get clusteringColumns(): string[];
    set clusteringColumns(value: string[]);
    resetClusteringColumns(): void;
    get clusteringColumnsInput(): string[] | undefined;
    private _enableAutoClustering?;
    get enableAutoClustering(): boolean | cdktn.IResolvable;
    set enableAutoClustering(value: boolean | cdktn.IResolvable);
    resetEnableAutoClustering(): void;
    get enableAutoClusteringInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeColumns?;
    get excludeColumns(): string[];
    set excludeColumns(value: string[]);
    resetExcludeColumns(): void;
    get excludeColumnsInput(): string[] | undefined;
    private _includeColumns?;
    get includeColumns(): string[];
    set includeColumns(value: string[]);
    resetIncludeColumns(): void;
    get includeColumnsInput(): string[] | undefined;
    private _primaryKeys?;
    get primaryKeys(): string[];
    set primaryKeys(value: string[]);
    resetPrimaryKeys(): void;
    get primaryKeysInput(): string[] | undefined;
    private _rowFilter?;
    get rowFilter(): string;
    set rowFilter(value: string);
    resetRowFilter(): void;
    get rowFilterInput(): string | undefined;
    private _salesforceIncludeFormulaFields?;
    get salesforceIncludeFormulaFields(): boolean | cdktn.IResolvable;
    set salesforceIncludeFormulaFields(value: boolean | cdktn.IResolvable);
    resetSalesforceIncludeFormulaFields(): void;
    get salesforceIncludeFormulaFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _scdType?;
    get scdType(): string;
    set scdType(value: string);
    resetScdType(): void;
    get scdTypeInput(): string | undefined;
    private _sequenceBy?;
    get sequenceBy(): string[];
    set sequenceBy(value: string[]);
    resetSequenceBy(): void;
    get sequenceByInput(): string[] | undefined;
    private _sourceMetadataColumn?;
    get sourceMetadataColumn(): string;
    set sourceMetadataColumn(value: string);
    resetSourceMetadataColumn(): void;
    get sourceMetadataColumnInput(): string | undefined;
    private _tableProperties?;
    get tableProperties(): {
        [key: string]: string;
    };
    set tableProperties(value: {
        [key: string]: string;
    });
    resetTableProperties(): void;
    get tablePropertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _autoFullRefreshPolicy;
    get autoFullRefreshPolicy(): PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicyOutputReference;
    putAutoFullRefreshPolicy(value: PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy): void;
    resetAutoFullRefreshPolicy(): void;
    get autoFullRefreshPolicyInput(): PipelineIngestionDefinitionTableConfigurationAutoFullRefreshPolicy | undefined;
    private _queryBasedConnectorConfig;
    get queryBasedConnectorConfig(): PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfigOutputReference;
    putQueryBasedConnectorConfig(value: PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig): void;
    resetQueryBasedConnectorConfig(): void;
    get queryBasedConnectorConfigInput(): PipelineIngestionDefinitionTableConfigurationQueryBasedConnectorConfig | undefined;
    private _workdayReportParameters;
    get workdayReportParameters(): PipelineIngestionDefinitionTableConfigurationWorkdayReportParametersOutputReference;
    putWorkdayReportParameters(value: PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters): void;
    resetWorkdayReportParameters(): void;
    get workdayReportParametersInput(): PipelineIngestionDefinitionTableConfigurationWorkdayReportParameters | undefined;
}
export interface PipelineIngestionDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#connection_name Pipeline#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#connector_type Pipeline#connector_type}
    */
    readonly connectorType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#ingest_from_uc_foreign_catalog Pipeline#ingest_from_uc_foreign_catalog}
    */
    readonly ingestFromUcForeignCatalog?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#ingestion_gateway_id Pipeline#ingestion_gateway_id}
    */
    readonly ingestionGatewayId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#netsuite_jar_path Pipeline#netsuite_jar_path}
    */
    readonly netsuiteJarPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_type Pipeline#source_type}
    */
    readonly sourceType?: string;
    /**
    * data_staging_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#data_staging_options Pipeline#data_staging_options}
    */
    readonly dataStagingOptions?: PipelineIngestionDefinitionDataStagingOptions;
    /**
    * full_refresh_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#full_refresh_window Pipeline#full_refresh_window}
    */
    readonly fullRefreshWindow?: PipelineIngestionDefinitionFullRefreshWindow;
    /**
    * objects block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#objects Pipeline#objects}
    */
    readonly objects?: PipelineIngestionDefinitionObjects[] | cdktn.IResolvable;
    /**
    * source_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#source_configurations Pipeline#source_configurations}
    */
    readonly sourceConfigurations?: PipelineIngestionDefinitionSourceConfigurations[] | cdktn.IResolvable;
    /**
    * table_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#table_configuration Pipeline#table_configuration}
    */
    readonly tableConfiguration?: PipelineIngestionDefinitionTableConfiguration;
}
export declare function pipelineIngestionDefinitionToTerraform(struct?: PipelineIngestionDefinitionOutputReference | PipelineIngestionDefinition): any;
export declare function pipelineIngestionDefinitionToHclTerraform(struct?: PipelineIngestionDefinitionOutputReference | PipelineIngestionDefinition): any;
export declare class PipelineIngestionDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineIngestionDefinition | undefined;
    set internalValue(value: PipelineIngestionDefinition | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _connectorType?;
    get connectorType(): string;
    set connectorType(value: string);
    resetConnectorType(): void;
    get connectorTypeInput(): string | undefined;
    private _ingestFromUcForeignCatalog?;
    get ingestFromUcForeignCatalog(): boolean | cdktn.IResolvable;
    set ingestFromUcForeignCatalog(value: boolean | cdktn.IResolvable);
    resetIngestFromUcForeignCatalog(): void;
    get ingestFromUcForeignCatalogInput(): boolean | cdktn.IResolvable | undefined;
    private _ingestionGatewayId?;
    get ingestionGatewayId(): string;
    set ingestionGatewayId(value: string);
    resetIngestionGatewayId(): void;
    get ingestionGatewayIdInput(): string | undefined;
    private _netsuiteJarPath?;
    get netsuiteJarPath(): string;
    set netsuiteJarPath(value: string);
    resetNetsuiteJarPath(): void;
    get netsuiteJarPathInput(): string | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    resetSourceType(): void;
    get sourceTypeInput(): string | undefined;
    private _dataStagingOptions;
    get dataStagingOptions(): PipelineIngestionDefinitionDataStagingOptionsOutputReference;
    putDataStagingOptions(value: PipelineIngestionDefinitionDataStagingOptions): void;
    resetDataStagingOptions(): void;
    get dataStagingOptionsInput(): PipelineIngestionDefinitionDataStagingOptions | undefined;
    private _fullRefreshWindow;
    get fullRefreshWindow(): PipelineIngestionDefinitionFullRefreshWindowOutputReference;
    putFullRefreshWindow(value: PipelineIngestionDefinitionFullRefreshWindow): void;
    resetFullRefreshWindow(): void;
    get fullRefreshWindowInput(): PipelineIngestionDefinitionFullRefreshWindow | undefined;
    private _objects;
    get objects(): PipelineIngestionDefinitionObjectsList;
    putObjects(value: PipelineIngestionDefinitionObjects[] | cdktn.IResolvable): void;
    resetObjects(): void;
    get objectsInput(): cdktn.IResolvable | PipelineIngestionDefinitionObjects[] | undefined;
    private _sourceConfigurations;
    get sourceConfigurations(): PipelineIngestionDefinitionSourceConfigurationsList;
    putSourceConfigurations(value: PipelineIngestionDefinitionSourceConfigurations[] | cdktn.IResolvable): void;
    resetSourceConfigurations(): void;
    get sourceConfigurationsInput(): cdktn.IResolvable | PipelineIngestionDefinitionSourceConfigurations[] | undefined;
    private _tableConfiguration;
    get tableConfiguration(): PipelineIngestionDefinitionTableConfigurationOutputReference;
    putTableConfiguration(value: PipelineIngestionDefinitionTableConfiguration): void;
    resetTableConfiguration(): void;
    get tableConfigurationInput(): PipelineIngestionDefinitionTableConfiguration | undefined;
}
export interface PipelineLatestUpdates {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#creation_time Pipeline#creation_time}
    */
    readonly creationTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#state Pipeline#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#update_id Pipeline#update_id}
    */
    readonly updateId?: string;
}
export declare function pipelineLatestUpdatesToTerraform(struct?: PipelineLatestUpdates | cdktn.IResolvable): any;
export declare function pipelineLatestUpdatesToHclTerraform(struct?: PipelineLatestUpdates | cdktn.IResolvable): any;
export declare class PipelineLatestUpdatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineLatestUpdates | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineLatestUpdates | cdktn.IResolvable | undefined);
    private _creationTime?;
    get creationTime(): string;
    set creationTime(value: string);
    resetCreationTime(): void;
    get creationTimeInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _updateId?;
    get updateId(): string;
    set updateId(value: string);
    resetUpdateId(): void;
    get updateIdInput(): string | undefined;
}
export declare class PipelineLatestUpdatesList extends cdktn.ComplexList {
    internalValue?: PipelineLatestUpdates[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineLatestUpdatesOutputReference;
}
export interface PipelineLibraryFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#path Pipeline#path}
    */
    readonly path: string;
}
export declare function pipelineLibraryFileToTerraform(struct?: PipelineLibraryFileOutputReference | PipelineLibraryFile): any;
export declare function pipelineLibraryFileToHclTerraform(struct?: PipelineLibraryFileOutputReference | PipelineLibraryFile): any;
export declare class PipelineLibraryFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineLibraryFile | undefined;
    set internalValue(value: PipelineLibraryFile | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface PipelineLibraryGlob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#include Pipeline#include}
    */
    readonly include: string;
}
export declare function pipelineLibraryGlobToTerraform(struct?: PipelineLibraryGlobOutputReference | PipelineLibraryGlob): any;
export declare function pipelineLibraryGlobToHclTerraform(struct?: PipelineLibraryGlobOutputReference | PipelineLibraryGlob): any;
export declare class PipelineLibraryGlobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineLibraryGlob | undefined;
    set internalValue(value: PipelineLibraryGlob | undefined);
    private _include?;
    get include(): string;
    set include(value: string);
    get includeInput(): string | undefined;
}
export interface PipelineLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#coordinates Pipeline#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#exclusions Pipeline#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#repo Pipeline#repo}
    */
    readonly repo?: string;
}
export declare function pipelineLibraryMavenToTerraform(struct?: PipelineLibraryMavenOutputReference | PipelineLibraryMaven): any;
export declare function pipelineLibraryMavenToHclTerraform(struct?: PipelineLibraryMavenOutputReference | PipelineLibraryMaven): any;
export declare class PipelineLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineLibraryMaven | undefined;
    set internalValue(value: PipelineLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface PipelineLibraryNotebook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#path Pipeline#path}
    */
    readonly path: string;
}
export declare function pipelineLibraryNotebookToTerraform(struct?: PipelineLibraryNotebookOutputReference | PipelineLibraryNotebook): any;
export declare function pipelineLibraryNotebookToHclTerraform(struct?: PipelineLibraryNotebookOutputReference | PipelineLibraryNotebook): any;
export declare class PipelineLibraryNotebookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineLibraryNotebook | undefined;
    set internalValue(value: PipelineLibraryNotebook | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface PipelineLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#jar Pipeline#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#whl Pipeline#whl}
    */
    readonly whl?: string;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#file Pipeline#file}
    */
    readonly file?: PipelineLibraryFile;
    /**
    * glob block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#glob Pipeline#glob}
    */
    readonly glob?: PipelineLibraryGlob;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#maven Pipeline#maven}
    */
    readonly maven?: PipelineLibraryMaven;
    /**
    * notebook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#notebook Pipeline#notebook}
    */
    readonly notebook?: PipelineLibraryNotebook;
}
export declare function pipelineLibraryToTerraform(struct?: PipelineLibrary | cdktn.IResolvable): any;
export declare function pipelineLibraryToHclTerraform(struct?: PipelineLibrary | cdktn.IResolvable): any;
export declare class PipelineLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineLibrary | cdktn.IResolvable | undefined);
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _file;
    get file(): PipelineLibraryFileOutputReference;
    putFile(value: PipelineLibraryFile): void;
    resetFile(): void;
    get fileInput(): PipelineLibraryFile | undefined;
    private _glob;
    get glob(): PipelineLibraryGlobOutputReference;
    putGlob(value: PipelineLibraryGlob): void;
    resetGlob(): void;
    get globInput(): PipelineLibraryGlob | undefined;
    private _maven;
    get maven(): PipelineLibraryMavenOutputReference;
    putMaven(value: PipelineLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): PipelineLibraryMaven | undefined;
    private _notebook;
    get notebook(): PipelineLibraryNotebookOutputReference;
    putNotebook(value: PipelineLibraryNotebook): void;
    resetNotebook(): void;
    get notebookInput(): PipelineLibraryNotebook | undefined;
}
export declare class PipelineLibraryList extends cdktn.ComplexList {
    internalValue?: PipelineLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineLibraryOutputReference;
}
export interface PipelineNotification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#alerts Pipeline#alerts}
    */
    readonly alerts?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#email_recipients Pipeline#email_recipients}
    */
    readonly emailRecipients?: string[];
}
export declare function pipelineNotificationToTerraform(struct?: PipelineNotification | cdktn.IResolvable): any;
export declare function pipelineNotificationToHclTerraform(struct?: PipelineNotification | cdktn.IResolvable): any;
export declare class PipelineNotificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PipelineNotification | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineNotification | cdktn.IResolvable | undefined);
    private _alerts?;
    get alerts(): string[];
    set alerts(value: string[]);
    resetAlerts(): void;
    get alertsInput(): string[] | undefined;
    private _emailRecipients?;
    get emailRecipients(): string[];
    set emailRecipients(value: string[]);
    resetEmailRecipients(): void;
    get emailRecipientsInput(): string[] | undefined;
}
export declare class PipelineNotificationList extends cdktn.ComplexList {
    internalValue?: PipelineNotification[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PipelineNotificationOutputReference;
}
export interface PipelineProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#workspace_id Pipeline#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function pipelineProviderConfigToTerraform(struct?: PipelineProviderConfigOutputReference | PipelineProviderConfig): any;
export declare function pipelineProviderConfigToHclTerraform(struct?: PipelineProviderConfigOutputReference | PipelineProviderConfig): any;
export declare class PipelineProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineProviderConfig | undefined;
    set internalValue(value: PipelineProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PipelineRestartWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#days_of_week Pipeline#days_of_week}
    */
    readonly daysOfWeek?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#start_hour Pipeline#start_hour}
    */
    readonly startHour: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#time_zone_id Pipeline#time_zone_id}
    */
    readonly timeZoneId?: string;
}
export declare function pipelineRestartWindowToTerraform(struct?: PipelineRestartWindowOutputReference | PipelineRestartWindow): any;
export declare function pipelineRestartWindowToHclTerraform(struct?: PipelineRestartWindowOutputReference | PipelineRestartWindow): any;
export declare class PipelineRestartWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineRestartWindow | undefined;
    set internalValue(value: PipelineRestartWindow | undefined);
    private _daysOfWeek?;
    get daysOfWeek(): string[];
    set daysOfWeek(value: string[]);
    resetDaysOfWeek(): void;
    get daysOfWeekInput(): string[] | undefined;
    private _startHour?;
    get startHour(): number;
    set startHour(value: number);
    get startHourInput(): number | undefined;
    private _timeZoneId?;
    get timeZoneId(): string;
    set timeZoneId(value: string);
    resetTimeZoneId(): void;
    get timeZoneIdInput(): string | undefined;
}
export interface PipelineRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#group_name Pipeline#group_name}
    */
    readonly groupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#service_principal_name Pipeline#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#user_name Pipeline#user_name}
    */
    readonly userName?: string;
}
export declare function pipelineRunAsToTerraform(struct?: PipelineRunAsOutputReference | PipelineRunAs): any;
export declare function pipelineRunAsToHclTerraform(struct?: PipelineRunAsOutputReference | PipelineRunAs): any;
export declare class PipelineRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineRunAs | undefined;
    set internalValue(value: PipelineRunAs | undefined);
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface PipelineTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#default Pipeline#default}
    */
    readonly default?: string;
}
export declare function pipelineTimeoutsToTerraform(struct?: PipelineTimeouts | cdktn.IResolvable): any;
export declare function pipelineTimeoutsToHclTerraform(struct?: PipelineTimeouts | cdktn.IResolvable): any;
export declare class PipelineTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
export interface PipelineTriggerCron {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#quartz_cron_schedule Pipeline#quartz_cron_schedule}
    */
    readonly quartzCronSchedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#timezone_id Pipeline#timezone_id}
    */
    readonly timezoneId?: string;
}
export declare function pipelineTriggerCronToTerraform(struct?: PipelineTriggerCronOutputReference | PipelineTriggerCron): any;
export declare function pipelineTriggerCronToHclTerraform(struct?: PipelineTriggerCronOutputReference | PipelineTriggerCron): any;
export declare class PipelineTriggerCronOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTriggerCron | undefined;
    set internalValue(value: PipelineTriggerCron | undefined);
    private _quartzCronSchedule?;
    get quartzCronSchedule(): string;
    set quartzCronSchedule(value: string);
    resetQuartzCronSchedule(): void;
    get quartzCronScheduleInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    resetTimezoneId(): void;
    get timezoneIdInput(): string | undefined;
}
export interface PipelineTriggerManual {
}
export declare function pipelineTriggerManualToTerraform(struct?: PipelineTriggerManualOutputReference | PipelineTriggerManual): any;
export declare function pipelineTriggerManualToHclTerraform(struct?: PipelineTriggerManualOutputReference | PipelineTriggerManual): any;
export declare class PipelineTriggerManualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTriggerManual | undefined;
    set internalValue(value: PipelineTriggerManual | undefined);
}
export interface PipelineTrigger {
    /**
    * cron block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#cron Pipeline#cron}
    */
    readonly cron?: PipelineTriggerCron;
    /**
    * manual block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/pipeline#manual Pipeline#manual}
    */
    readonly manual?: PipelineTriggerManual;
}
export declare function pipelineTriggerToTerraform(struct?: PipelineTriggerOutputReference | PipelineTrigger): any;
export declare function pipelineTriggerToHclTerraform(struct?: PipelineTriggerOutputReference | PipelineTrigger): any;
export declare class PipelineTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTrigger | undefined;
    set internalValue(value: PipelineTrigger | undefined);
    private _cron;
    get cron(): PipelineTriggerCronOutputReference;
    putCron(value: PipelineTriggerCron): void;
    resetCron(): void;
    get cronInput(): PipelineTriggerCron | undefined;
    private _manual;
    get manual(): PipelineTriggerManualOutputReference;
    putManual(value: PipelineTriggerManual): void;
    resetManual(): void;
    get manualInput(): PipelineTriggerManual | undefined;
}
