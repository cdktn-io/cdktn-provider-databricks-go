/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiGatewayModelServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#comment AiGatewayModelService#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#config AiGatewayModelService#config}
    */
    readonly config?: AiGatewayModelServiceConfigA;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model_service_id AiGatewayModelService#model_service_id}
    */
    readonly modelServiceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#parent AiGatewayModelService#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#provider_config AiGatewayModelService#provider_config}
    */
    readonly providerConfig?: AiGatewayModelServiceProviderConfig;
}
export interface AiGatewayModelServiceConfigInferenceTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#parent AiGatewayModelService#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#table_name_prefix AiGatewayModelService#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function aiGatewayModelServiceConfigInferenceTableToTerraform(struct?: AiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigInferenceTableToHclTerraform(struct?: AiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigInferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable | undefined);
    get isDeleted(): cdktn.IResolvable;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get table(): string;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface AiGatewayModelServiceConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#key AiGatewayModelService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#principal AiGatewayModelService#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#renewal_period AiGatewayModelService#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#requests AiGatewayModelService#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#tokens AiGatewayModelService#tokens}
    */
    readonly tokens?: number;
}
export declare function aiGatewayModelServiceConfigRateLimitsToTerraform(struct?: AiGatewayModelServiceConfigRateLimits | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRateLimitsToHclTerraform(struct?: AiGatewayModelServiceConfigRateLimits | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayModelServiceConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class AiGatewayModelServiceConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: AiGatewayModelServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayModelServiceConfigRateLimitsOutputReference;
}
export interface AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model AiGatewayModelService#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#native_api_types AiGatewayModelService#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function aiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetToTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export interface AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model_provider_service AiGatewayModelService#model_provider_service}
    */
    readonly modelProviderService: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#target AiGatewayModelService#target}
    */
    readonly target: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget;
}
export declare function aiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigToTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable | undefined);
    private _modelProviderService?;
    get modelProviderService(): string;
    set modelProviderService(value: string);
    get modelProviderServiceInput(): string | undefined;
    private _target;
    get target(): AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetOutputReference;
    putTarget(value: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget): void;
    get targetInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | undefined;
}
export interface AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model AiGatewayModelService#model}
    */
    readonly model: string;
}
export declare function aiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigToTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
}
export interface AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model_serving_endpoint AiGatewayModelService#model_serving_endpoint}
    */
    readonly modelServingEndpoint: string;
}
export declare function aiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigToTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined);
    get model(): string;
    private _modelServingEndpoint?;
    get modelServingEndpoint(): string;
    set modelServingEndpoint(value: string);
    get modelServingEndpointInput(): string | undefined;
}
export interface AiGatewayModelServiceConfigRoutingDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#destination_type AiGatewayModelService#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#external_model_config AiGatewayModelService#external_model_config}
    */
    readonly externalModelConfig?: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#name AiGatewayModelService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#pay_per_token_config AiGatewayModelService#pay_per_token_config}
    */
    readonly payPerTokenConfig?: AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#provisioned_throughput_config AiGatewayModelService#provisioned_throughput_config}
    */
    readonly provisionedThroughputConfig?: AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#traffic_percentage AiGatewayModelService#traffic_percentage}
    */
    readonly trafficPercentage?: number;
}
export declare function aiGatewayModelServiceConfigRoutingDestinationsToTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingDestinationsToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _externalModelConfig;
    get externalModelConfig(): AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigOutputReference;
    putExternalModelConfig(value: AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig): void;
    resetExternalModelConfig(): void;
    get externalModelConfigInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _payPerTokenConfig;
    get payPerTokenConfig(): AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigOutputReference;
    putPayPerTokenConfig(value: AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig): void;
    resetPayPerTokenConfig(): void;
    get payPerTokenConfigInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | undefined;
    private _provisionedThroughputConfig;
    get provisionedThroughputConfig(): AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigOutputReference;
    putProvisionedThroughputConfig(value: AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig): void;
    resetProvisionedThroughputConfig(): void;
    get provisionedThroughputConfigInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    resetTrafficPercentage(): void;
    get trafficPercentageInput(): number | undefined;
}
export declare class AiGatewayModelServiceConfigRoutingDestinationsList extends cdktn.ComplexList {
    internalValue?: AiGatewayModelServiceConfigRoutingDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayModelServiceConfigRoutingDestinationsOutputReference;
}
export interface AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model AiGatewayModelService#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#native_api_types AiGatewayModelService#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetToTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export interface AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model_provider_service AiGatewayModelService#model_provider_service}
    */
    readonly modelProviderService: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#target AiGatewayModelService#target}
    */
    readonly target: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget;
}
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigToTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable | undefined);
    private _modelProviderService?;
    get modelProviderService(): string;
    set modelProviderService(value: string);
    get modelProviderServiceInput(): string | undefined;
    private _target;
    get target(): AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetOutputReference;
    putTarget(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget): void;
    get targetInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | undefined;
}
export interface AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model AiGatewayModelService#model}
    */
    readonly model: string;
}
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigToTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
}
export interface AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#model_serving_endpoint AiGatewayModelService#model_serving_endpoint}
    */
    readonly modelServingEndpoint: string;
}
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigToTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined);
    get model(): string;
    private _modelServingEndpoint?;
    get modelServingEndpoint(): string;
    set modelServingEndpoint(value: string);
    get modelServingEndpointInput(): string | undefined;
}
export interface AiGatewayModelServiceConfigRoutingFallbackDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#destination_type AiGatewayModelService#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#external_model_config AiGatewayModelService#external_model_config}
    */
    readonly externalModelConfig?: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#name AiGatewayModelService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#pay_per_token_config AiGatewayModelService#pay_per_token_config}
    */
    readonly payPerTokenConfig?: AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#provisioned_throughput_config AiGatewayModelService#provisioned_throughput_config}
    */
    readonly provisionedThroughputConfig?: AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#traffic_percentage AiGatewayModelService#traffic_percentage}
    */
    readonly trafficPercentage?: number;
}
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsToTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingFallbackDestinationsToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingFallbackDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _externalModelConfig;
    get externalModelConfig(): AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigOutputReference;
    putExternalModelConfig(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig): void;
    resetExternalModelConfig(): void;
    get externalModelConfigInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _payPerTokenConfig;
    get payPerTokenConfig(): AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigOutputReference;
    putPayPerTokenConfig(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig): void;
    resetPayPerTokenConfig(): void;
    get payPerTokenConfigInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | undefined;
    private _provisionedThroughputConfig;
    get provisionedThroughputConfig(): AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigOutputReference;
    putProvisionedThroughputConfig(value: AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig): void;
    resetProvisionedThroughputConfig(): void;
    get provisionedThroughputConfigInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    resetTrafficPercentage(): void;
    get trafficPercentageInput(): number | undefined;
}
export declare class AiGatewayModelServiceConfigRoutingFallbackDestinationsList extends cdktn.ComplexList {
    internalValue?: AiGatewayModelServiceConfigRoutingFallbackDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayModelServiceConfigRoutingFallbackDestinationsOutputReference;
}
export interface AiGatewayModelServiceConfigRoutingFallback {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#destinations AiGatewayModelService#destinations}
    */
    readonly destinations?: AiGatewayModelServiceConfigRoutingFallbackDestinations[] | cdktn.IResolvable;
}
export declare function aiGatewayModelServiceConfigRoutingFallbackToTerraform(struct?: AiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingFallbackToHclTerraform(struct?: AiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable | undefined);
    private _destinations;
    get destinations(): AiGatewayModelServiceConfigRoutingFallbackDestinationsList;
    putDestinations(value: AiGatewayModelServiceConfigRoutingFallbackDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingFallbackDestinations[] | undefined;
}
export interface AiGatewayModelServiceConfigRouting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#destinations AiGatewayModelService#destinations}
    */
    readonly destinations?: AiGatewayModelServiceConfigRoutingDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#fallback AiGatewayModelService#fallback}
    */
    readonly fallback?: AiGatewayModelServiceConfigRoutingFallback;
}
export declare function aiGatewayModelServiceConfigRoutingToTerraform(struct?: AiGatewayModelServiceConfigRouting | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigRoutingToHclTerraform(struct?: AiGatewayModelServiceConfigRouting | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigRouting | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigRouting | cdktn.IResolvable | undefined);
    private _destinations;
    get destinations(): AiGatewayModelServiceConfigRoutingDestinationsList;
    putDestinations(value: AiGatewayModelServiceConfigRoutingDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingDestinations[] | undefined;
    private _fallback;
    get fallback(): AiGatewayModelServiceConfigRoutingFallbackOutputReference;
    putFallback(value: AiGatewayModelServiceConfigRoutingFallback): void;
    resetFallback(): void;
    get fallbackInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRoutingFallback | undefined;
}
export interface AiGatewayModelServiceConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#inference_table AiGatewayModelService#inference_table}
    */
    readonly inferenceTable?: AiGatewayModelServiceConfigInferenceTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#rate_limits AiGatewayModelService#rate_limits}
    */
    readonly rateLimits?: AiGatewayModelServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#routing AiGatewayModelService#routing}
    */
    readonly routing?: AiGatewayModelServiceConfigRouting;
}
export declare function aiGatewayModelServiceConfigAToTerraform(struct?: AiGatewayModelServiceConfigA | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceConfigAToHclTerraform(struct?: AiGatewayModelServiceConfigA | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceConfigA | cdktn.IResolvable | undefined);
    private _inferenceTable;
    get inferenceTable(): AiGatewayModelServiceConfigInferenceTableOutputReference;
    putInferenceTable(value: AiGatewayModelServiceConfigInferenceTable): void;
    resetInferenceTable(): void;
    get inferenceTableInput(): cdktn.IResolvable | AiGatewayModelServiceConfigInferenceTable | undefined;
    private _rateLimits;
    get rateLimits(): AiGatewayModelServiceConfigRateLimitsList;
    putRateLimits(value: AiGatewayModelServiceConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRateLimits[] | undefined;
    private _routing;
    get routing(): AiGatewayModelServiceConfigRoutingOutputReference;
    putRouting(value: AiGatewayModelServiceConfigRouting): void;
    resetRouting(): void;
    get routingInput(): cdktn.IResolvable | AiGatewayModelServiceConfigRouting | undefined;
}
export interface AiGatewayModelServiceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#workspace_id AiGatewayModelService#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function aiGatewayModelServiceProviderConfigToTerraform(struct?: AiGatewayModelServiceProviderConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelServiceProviderConfigToHclTerraform(struct?: AiGatewayModelServiceProviderConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelServiceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelServiceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelServiceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service databricks_ai_gateway_model_service}
*/
export declare class AiGatewayModelService extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_ai_gateway_model_service";
    /**
    * Generates CDKTN code for importing a AiGatewayModelService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiGatewayModelService to import
    * @param importFromId The id of the existing AiGatewayModelService that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiGatewayModelService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/ai_gateway_model_service databricks_ai_gateway_model_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiGatewayModelServiceConfig
    */
    constructor(scope: Construct, id: string, config: AiGatewayModelServiceConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _config;
    get config(): AiGatewayModelServiceConfigAOutputReference;
    putConfig(value: AiGatewayModelServiceConfigA): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | AiGatewayModelServiceConfigA | undefined;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _modelServiceId?;
    get modelServiceId(): string;
    set modelServiceId(value: string);
    get modelServiceIdInput(): string | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AiGatewayModelServiceProviderConfigOutputReference;
    putProviderConfig(value: AiGatewayModelServiceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AiGatewayModelServiceProviderConfig | undefined;
    get supportedApiTypes(): string[];
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
