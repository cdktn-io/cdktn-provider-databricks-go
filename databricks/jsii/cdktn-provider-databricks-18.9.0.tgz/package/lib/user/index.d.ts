/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#acl_principal_id User#acl_principal_id}
    */
    readonly aclPrincipalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#active User#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#allow_cluster_create User#allow_cluster_create}
    */
    readonly allowClusterCreate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#allow_instance_pool_create User#allow_instance_pool_create}
    */
    readonly allowInstancePoolCreate?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#api User#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#databricks_sql_access User#databricks_sql_access}
    */
    readonly databricksSqlAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#disable_as_user_deletion User#disable_as_user_deletion}
    */
    readonly disableAsUserDeletion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#display_name User#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#external_id User#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#force User#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#force_delete_home_dir User#force_delete_home_dir}
    */
    readonly forceDeleteHomeDir?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#force_delete_repos User#force_delete_repos}
    */
    readonly forceDeleteRepos?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#home User#home}
    */
    readonly home?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#id User#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#repos User#repos}
    */
    readonly repos?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#user_name User#user_name}
    */
    readonly userName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#workspace_access User#workspace_access}
    */
    readonly workspaceAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#workspace_consume User#workspace_consume}
    */
    readonly workspaceConsume?: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#provider_config User#provider_config}
    */
    readonly providerConfig?: UserProviderConfig;
}
export interface UserProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#workspace_id User#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function userProviderConfigToTerraform(struct?: UserProviderConfigOutputReference | UserProviderConfig): any;
export declare function userProviderConfigToHclTerraform(struct?: UserProviderConfigOutputReference | UserProviderConfig): any;
export declare class UserProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserProviderConfig | undefined;
    set internalValue(value: UserProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user databricks_user}
*/
export declare class User extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_user";
    /**
    * Generates CDKTN code for importing a User resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the User to import
    * @param importFromId The id of the existing User that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the User to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user databricks_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserConfig
    */
    constructor(scope: Construct, id: string, config: UserConfig);
    private _aclPrincipalId?;
    get aclPrincipalId(): string;
    set aclPrincipalId(value: string);
    resetAclPrincipalId(): void;
    get aclPrincipalIdInput(): string | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _allowClusterCreate?;
    get allowClusterCreate(): boolean | cdktn.IResolvable;
    set allowClusterCreate(value: boolean | cdktn.IResolvable);
    resetAllowClusterCreate(): void;
    get allowClusterCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _allowInstancePoolCreate?;
    get allowInstancePoolCreate(): boolean | cdktn.IResolvable;
    set allowInstancePoolCreate(value: boolean | cdktn.IResolvable);
    resetAllowInstancePoolCreate(): void;
    get allowInstancePoolCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _databricksSqlAccess?;
    get databricksSqlAccess(): boolean | cdktn.IResolvable;
    set databricksSqlAccess(value: boolean | cdktn.IResolvable);
    resetDatabricksSqlAccess(): void;
    get databricksSqlAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _disableAsUserDeletion?;
    get disableAsUserDeletion(): boolean | cdktn.IResolvable;
    set disableAsUserDeletion(value: boolean | cdktn.IResolvable);
    resetDisableAsUserDeletion(): void;
    get disableAsUserDeletionInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDeleteHomeDir?;
    get forceDeleteHomeDir(): boolean | cdktn.IResolvable;
    set forceDeleteHomeDir(value: boolean | cdktn.IResolvable);
    resetForceDeleteHomeDir(): void;
    get forceDeleteHomeDirInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDeleteRepos?;
    get forceDeleteRepos(): boolean | cdktn.IResolvable;
    set forceDeleteRepos(value: boolean | cdktn.IResolvable);
    resetForceDeleteRepos(): void;
    get forceDeleteReposInput(): boolean | cdktn.IResolvable | undefined;
    private _home?;
    get home(): string;
    set home(value: string);
    resetHome(): void;
    get homeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _repos?;
    get repos(): string;
    set repos(value: string);
    resetRepos(): void;
    get reposInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _workspaceAccess?;
    get workspaceAccess(): boolean | cdktn.IResolvable;
    set workspaceAccess(value: boolean | cdktn.IResolvable);
    resetWorkspaceAccess(): void;
    get workspaceAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _workspaceConsume?;
    get workspaceConsume(): boolean | cdktn.IResolvable;
    set workspaceConsume(value: boolean | cdktn.IResolvable);
    resetWorkspaceConsume(): void;
    get workspaceConsumeInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): UserProviderConfigOutputReference;
    putProviderConfig(value: UserProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): UserProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
