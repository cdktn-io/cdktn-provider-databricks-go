/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountIamExternalUserV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_external_user_v2#name DataDatabricksAccountIamExternalUserV2#name}
    */
    readonly name: string;
}
export interface DataDatabricksAccountIamExternalUserV2FullName {
}
export declare function dataDatabricksAccountIamExternalUserV2FullNameToTerraform(struct?: DataDatabricksAccountIamExternalUserV2FullName): any;
export declare function dataDatabricksAccountIamExternalUserV2FullNameToHclTerraform(struct?: DataDatabricksAccountIamExternalUserV2FullName): any;
export declare class DataDatabricksAccountIamExternalUserV2FullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountIamExternalUserV2FullName | undefined;
    set internalValue(value: DataDatabricksAccountIamExternalUserV2FullName | undefined);
    get familyName(): string;
    get givenName(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_external_user_v2 databricks_account_iam_external_user_v2}
*/
export declare class DataDatabricksAccountIamExternalUserV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_iam_external_user_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountIamExternalUserV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountIamExternalUserV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountIamExternalUserV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_external_user_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountIamExternalUserV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_external_user_v2 databricks_account_iam_external_user_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountIamExternalUserV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountIamExternalUserV2Config);
    get accountId(): string;
    get accountUserStatus(): string;
    get displayName(): string;
    get externalUserId(): string;
    private _fullName;
    get fullName(): DataDatabricksAccountIamExternalUserV2FullNameOutputReference;
    get internalId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
