/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountIamServicePrincipalsV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_service_principals_v2#filter DataDatabricksAccountIamServicePrincipalsV2#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_service_principals_v2#page_size DataDatabricksAccountIamServicePrincipalsV2#page_size}
    */
    readonly pageSize?: number;
}
export interface DataDatabricksAccountIamServicePrincipalsV2ServicePrincipals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_service_principals_v2#service_principal_id DataDatabricksAccountIamServicePrincipalsV2#service_principal_id}
    */
    readonly servicePrincipalId: string;
}
export declare function dataDatabricksAccountIamServicePrincipalsV2ServicePrincipalsToTerraform(struct?: DataDatabricksAccountIamServicePrincipalsV2ServicePrincipals): any;
export declare function dataDatabricksAccountIamServicePrincipalsV2ServicePrincipalsToHclTerraform(struct?: DataDatabricksAccountIamServicePrincipalsV2ServicePrincipals): any;
export declare class DataDatabricksAccountIamServicePrincipalsV2ServicePrincipalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountIamServicePrincipalsV2ServicePrincipals | undefined;
    set internalValue(value: DataDatabricksAccountIamServicePrincipalsV2ServicePrincipals | undefined);
    get accountId(): string;
    get accountSpStatus(): string;
    get applicationId(): string;
    get displayName(): string;
    get externalId(): string;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
}
export declare class DataDatabricksAccountIamServicePrincipalsV2ServicePrincipalsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountIamServicePrincipalsV2ServicePrincipals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountIamServicePrincipalsV2ServicePrincipalsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_service_principals_v2 databricks_account_iam_service_principals_v2}
*/
export declare class DataDatabricksAccountIamServicePrincipalsV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_iam_service_principals_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountIamServicePrincipalsV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountIamServicePrincipalsV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountIamServicePrincipalsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_service_principals_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountIamServicePrincipalsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/account_iam_service_principals_v2 databricks_account_iam_service_principals_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountIamServicePrincipalsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAccountIamServicePrincipalsV2Config);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _servicePrincipals;
    get servicePrincipals(): DataDatabricksAccountIamServicePrincipalsV2ServicePrincipalsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
