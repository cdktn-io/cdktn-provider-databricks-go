/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppsSettingsCustomTemplatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#page_size DataDatabricksAppsSettingsCustomTemplates#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#provider_config DataDatabricksAppsSettingsCustomTemplates#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppsSettingsCustomTemplatesProviderConfig;
}
export interface DataDatabricksAppsSettingsCustomTemplatesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#workspace_id DataDatabricksAppsSettingsCustomTemplates#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesProviderConfigToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesProviderConfigToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#permission DataDatabricksAppsSettingsCustomTemplates#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#permission DataDatabricksAppsSettingsCustomTemplates#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#permission DataDatabricksAppsSettingsCustomTemplates#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#permission DataDatabricksAppsSettingsCustomTemplates#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#permission DataDatabricksAppsSettingsCustomTemplates#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#permission DataDatabricksAppsSettingsCustomTemplates#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#securable_type DataDatabricksAppsSettingsCustomTemplates#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpecToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpecToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#description DataDatabricksAppsSettingsCustomTemplates#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#experiment_spec DataDatabricksAppsSettingsCustomTemplates#experiment_spec}
    */
    readonly experimentSpec?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#job_spec DataDatabricksAppsSettingsCustomTemplates#job_spec}
    */
    readonly jobSpec?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#name DataDatabricksAppsSettingsCustomTemplates#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#secret_spec DataDatabricksAppsSettingsCustomTemplates#secret_spec}
    */
    readonly secretSpec?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#serving_endpoint_spec DataDatabricksAppsSettingsCustomTemplates#serving_endpoint_spec}
    */
    readonly servingEndpointSpec?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#sql_warehouse_spec DataDatabricksAppsSettingsCustomTemplates#sql_warehouse_spec}
    */
    readonly sqlWarehouseSpec?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#uc_securable_spec DataDatabricksAppsSettingsCustomTemplates#uc_securable_spec}
    */
    readonly ucSecurableSpec?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experimentSpec;
    get experimentSpec(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpecOutputReference;
    putExperimentSpec(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec): void;
    resetExperimentSpec(): void;
    get experimentSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsExperimentSpec | undefined;
    private _jobSpec;
    get jobSpec(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpecOutputReference;
    putJobSpec(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec): void;
    resetJobSpec(): void;
    get jobSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsJobSpec | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secretSpec;
    get secretSpec(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpecOutputReference;
    putSecretSpec(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec): void;
    resetSecretSpec(): void;
    get secretSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSecretSpec | undefined;
    private _servingEndpointSpec;
    get servingEndpointSpec(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpecOutputReference;
    putServingEndpointSpec(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec): void;
    resetServingEndpointSpec(): void;
    get servingEndpointSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsServingEndpointSpec | undefined;
    private _sqlWarehouseSpec;
    get sqlWarehouseSpec(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpecOutputReference;
    putSqlWarehouseSpec(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec): void;
    resetSqlWarehouseSpec(): void;
    get sqlWarehouseSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsSqlWarehouseSpec | undefined;
    private _ucSecurableSpec;
    get ucSecurableSpec(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpecOutputReference;
    putUcSecurableSpec(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec): void;
    resetUcSecurableSpec(): void;
    get ucSecurableSpecInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsUcSecurableSpec | undefined;
}
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsOutputReference;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesManifest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#description DataDatabricksAppsSettingsCustomTemplates#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#name DataDatabricksAppsSettingsCustomTemplates#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#resource_specs DataDatabricksAppsSettingsCustomTemplates#resource_specs}
    */
    readonly resourceSpecs?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#version DataDatabricksAppsSettingsCustomTemplates#version}
    */
    readonly version: number;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifest): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesManifestToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifest): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifest | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifest | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceSpecs;
    get resourceSpecs(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecsList;
    putResourceSpecs(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs[] | cdktn.IResolvable): void;
    resetResourceSpecs(): void;
    get resourceSpecsInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestResourceSpecs[] | undefined;
    private _version?;
    get version(): number;
    set version(value: number);
    get versionInput(): number | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#workspace_id DataDatabricksAppsSettingsCustomTemplates#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfigToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfigToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppsSettingsCustomTemplatesTemplates {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#name DataDatabricksAppsSettingsCustomTemplates#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#provider_config DataDatabricksAppsSettingsCustomTemplates#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig;
}
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesToTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplates): any;
export declare function dataDatabricksAppsSettingsCustomTemplatesTemplatesToHclTerraform(struct?: DataDatabricksAppsSettingsCustomTemplatesTemplates): any;
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppsSettingsCustomTemplatesTemplates | undefined;
    set internalValue(value: DataDatabricksAppsSettingsCustomTemplatesTemplates | undefined);
    get creator(): string;
    get description(): string;
    get gitProvider(): string;
    get gitRepo(): string;
    private _manifest;
    get manifest(): DataDatabricksAppsSettingsCustomTemplatesTemplatesManifestOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get path(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesTemplatesProviderConfig | undefined;
}
export declare class DataDatabricksAppsSettingsCustomTemplatesTemplatesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppsSettingsCustomTemplatesTemplates[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppsSettingsCustomTemplatesTemplatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates databricks_apps_settings_custom_templates}
*/
export declare class DataDatabricksAppsSettingsCustomTemplates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_apps_settings_custom_templates";
    /**
    * Generates CDKTN code for importing a DataDatabricksAppsSettingsCustomTemplates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAppsSettingsCustomTemplates to import
    * @param importFromId The id of the existing DataDatabricksAppsSettingsCustomTemplates that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAppsSettingsCustomTemplates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/apps_settings_custom_templates databricks_apps_settings_custom_templates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppsSettingsCustomTemplatesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAppsSettingsCustomTemplatesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppsSettingsCustomTemplatesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppsSettingsCustomTemplatesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppsSettingsCustomTemplatesProviderConfig | undefined;
    private _templates;
    get templates(): DataDatabricksAppsSettingsCustomTemplatesTemplatesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
