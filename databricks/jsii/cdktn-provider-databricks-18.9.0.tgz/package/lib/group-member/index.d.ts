/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupMemberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member#api GroupMember#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member#group_id GroupMember#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member#id GroupMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member#member_id GroupMember#member_id}
    */
    readonly memberId: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member#provider_config GroupMember#provider_config}
    */
    readonly providerConfig?: GroupMemberProviderConfig;
}
export interface GroupMemberProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member#workspace_id GroupMember#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function groupMemberProviderConfigToTerraform(struct?: GroupMemberProviderConfigOutputReference | GroupMemberProviderConfig): any;
export declare function groupMemberProviderConfigToHclTerraform(struct?: GroupMemberProviderConfigOutputReference | GroupMemberProviderConfig): any;
export declare class GroupMemberProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupMemberProviderConfig | undefined;
    set internalValue(value: GroupMemberProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member databricks_group_member}
*/
export declare class GroupMember extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_group_member";
    /**
    * Generates CDKTN code for importing a GroupMember resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupMember to import
    * @param importFromId The id of the existing GroupMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/group_member databricks_group_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupMemberConfig
    */
    constructor(scope: Construct, id: string, config: GroupMemberConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberId?;
    get memberId(): string;
    set memberId(value: string);
    get memberIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): GroupMemberProviderConfigOutputReference;
    putProviderConfig(value: GroupMemberProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): GroupMemberProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
