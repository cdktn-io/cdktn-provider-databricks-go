/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceIamDirectGroupMemberV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_direct_group_member_v2#group_id WorkspaceIamDirectGroupMemberV2#group_id}
    */
    readonly groupId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_direct_group_member_v2#principal_id WorkspaceIamDirectGroupMemberV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_direct_group_member_v2#provider_config WorkspaceIamDirectGroupMemberV2#provider_config}
    */
    readonly providerConfig?: WorkspaceIamDirectGroupMemberV2ProviderConfig;
}
export interface WorkspaceIamDirectGroupMemberV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_direct_group_member_v2#workspace_id WorkspaceIamDirectGroupMemberV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceIamDirectGroupMemberV2ProviderConfigToTerraform(struct?: WorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceIamDirectGroupMemberV2ProviderConfigToHclTerraform(struct?: WorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceIamDirectGroupMemberV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_direct_group_member_v2 databricks_workspace_iam_direct_group_member_v2}
*/
export declare class WorkspaceIamDirectGroupMemberV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_iam_direct_group_member_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceIamDirectGroupMemberV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceIamDirectGroupMemberV2 to import
    * @param importFromId The id of the existing WorkspaceIamDirectGroupMemberV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_direct_group_member_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceIamDirectGroupMemberV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_direct_group_member_v2 databricks_workspace_iam_direct_group_member_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceIamDirectGroupMemberV2Config
    */
    constructor(scope: Construct, id: string, config: WorkspaceIamDirectGroupMemberV2Config);
    get displayName(): string;
    get externalId(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    get membershipSource(): string;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): WorkspaceIamDirectGroupMemberV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceIamDirectGroupMemberV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceIamDirectGroupMemberV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
