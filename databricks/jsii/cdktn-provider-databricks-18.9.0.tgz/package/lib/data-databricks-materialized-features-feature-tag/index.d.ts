/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMaterializedFeaturesFeatureTagConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/materialized_features_feature_tag#key DataDatabricksMaterializedFeaturesFeatureTag#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/materialized_features_feature_tag#provider_config DataDatabricksMaterializedFeaturesFeatureTag#provider_config}
    */
    readonly providerConfig?: DataDatabricksMaterializedFeaturesFeatureTagProviderConfig;
}
export interface DataDatabricksMaterializedFeaturesFeatureTagProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/materialized_features_feature_tag#workspace_id DataDatabricksMaterializedFeaturesFeatureTag#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMaterializedFeaturesFeatureTagProviderConfigToTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksMaterializedFeaturesFeatureTagProviderConfigToHclTerraform(struct?: DataDatabricksMaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksMaterializedFeaturesFeatureTagProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/materialized_features_feature_tag databricks_materialized_features_feature_tag}
*/
export declare class DataDatabricksMaterializedFeaturesFeatureTag extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_materialized_features_feature_tag";
    /**
    * Generates CDKTN code for importing a DataDatabricksMaterializedFeaturesFeatureTag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMaterializedFeaturesFeatureTag to import
    * @param importFromId The id of the existing DataDatabricksMaterializedFeaturesFeatureTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/materialized_features_feature_tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMaterializedFeaturesFeatureTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/materialized_features_feature_tag databricks_materialized_features_feature_tag} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMaterializedFeaturesFeatureTagConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMaterializedFeaturesFeatureTagConfig);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMaterializedFeaturesFeatureTagProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMaterializedFeaturesFeatureTagProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksMaterializedFeaturesFeatureTagProviderConfig | undefined;
    get value(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
