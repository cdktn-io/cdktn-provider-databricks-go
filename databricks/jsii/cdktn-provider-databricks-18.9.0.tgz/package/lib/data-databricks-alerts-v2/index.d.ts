/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAlertsV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#page_size DataDatabricksAlertsV2#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#provider_config DataDatabricksAlertsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksAlertsV2ProviderConfig;
}
export interface DataDatabricksAlertsV2AlertsEffectiveRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#service_principal_name DataDatabricksAlertsV2#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#user_name DataDatabricksAlertsV2#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksAlertsV2AlertsEffectiveRunAsToTerraform(struct?: DataDatabricksAlertsV2AlertsEffectiveRunAs): any;
export declare function dataDatabricksAlertsV2AlertsEffectiveRunAsToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEffectiveRunAs): any;
export declare class DataDatabricksAlertsV2AlertsEffectiveRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsEffectiveRunAs | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEffectiveRunAs | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#destination_id DataDatabricksAlertsV2#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#user_email DataDatabricksAlertsV2#user_email}
    */
    readonly userEmail?: string;
}
export declare function dataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptionsToTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions | cdktn.IResolvable): any;
export declare function dataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptionsToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions | cdktn.IResolvable): any;
export declare class DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string;
    set userEmail(value: string);
    resetUserEmail(): void;
    get userEmailInput(): string | undefined;
}
export declare class DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptionsOutputReference;
}
export interface DataDatabricksAlertsV2AlertsEvaluationNotification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#notify_on_ok DataDatabricksAlertsV2#notify_on_ok}
    */
    readonly notifyOnOk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#retrigger_seconds DataDatabricksAlertsV2#retrigger_seconds}
    */
    readonly retriggerSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#subscriptions DataDatabricksAlertsV2#subscriptions}
    */
    readonly subscriptions?: DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions[] | cdktn.IResolvable;
}
export declare function dataDatabricksAlertsV2AlertsEvaluationNotificationToTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationNotification | cdktn.IResolvable): any;
export declare function dataDatabricksAlertsV2AlertsEvaluationNotificationToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationNotification | cdktn.IResolvable): any;
export declare class DataDatabricksAlertsV2AlertsEvaluationNotificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsEvaluationNotification | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEvaluationNotification | cdktn.IResolvable | undefined);
    get effectiveNotifyOnOk(): cdktn.IResolvable;
    get effectiveRetriggerSeconds(): number;
    private _notifyOnOk?;
    get notifyOnOk(): boolean | cdktn.IResolvable;
    set notifyOnOk(value: boolean | cdktn.IResolvable);
    resetNotifyOnOk(): void;
    get notifyOnOkInput(): boolean | cdktn.IResolvable | undefined;
    private _retriggerSeconds?;
    get retriggerSeconds(): number;
    set retriggerSeconds(value: number);
    resetRetriggerSeconds(): void;
    get retriggerSecondsInput(): number | undefined;
    private _subscriptions;
    get subscriptions(): DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptionsList;
    putSubscriptions(value: DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | DataDatabricksAlertsV2AlertsEvaluationNotificationSubscriptions[] | undefined;
}
export interface DataDatabricksAlertsV2AlertsEvaluationSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#aggregation DataDatabricksAlertsV2#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#display DataDatabricksAlertsV2#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#name DataDatabricksAlertsV2#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAlertsV2AlertsEvaluationSourceToTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationSource): any;
export declare function dataDatabricksAlertsV2AlertsEvaluationSourceToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationSource): any;
export declare class DataDatabricksAlertsV2AlertsEvaluationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsEvaluationSource | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEvaluationSource | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAlertsV2AlertsEvaluationThresholdColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#aggregation DataDatabricksAlertsV2#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#display DataDatabricksAlertsV2#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#name DataDatabricksAlertsV2#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAlertsV2AlertsEvaluationThresholdColumnToTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationThresholdColumn | cdktn.IResolvable): any;
export declare function dataDatabricksAlertsV2AlertsEvaluationThresholdColumnToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationThresholdColumn | cdktn.IResolvable): any;
export declare class DataDatabricksAlertsV2AlertsEvaluationThresholdColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsEvaluationThresholdColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEvaluationThresholdColumn | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAlertsV2AlertsEvaluationThresholdValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#bool_value DataDatabricksAlertsV2#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#double_value DataDatabricksAlertsV2#double_value}
    */
    readonly doubleValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#string_value DataDatabricksAlertsV2#string_value}
    */
    readonly stringValue?: string;
}
export declare function dataDatabricksAlertsV2AlertsEvaluationThresholdValueToTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationThresholdValue | cdktn.IResolvable): any;
export declare function dataDatabricksAlertsV2AlertsEvaluationThresholdValueToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationThresholdValue | cdktn.IResolvable): any;
export declare class DataDatabricksAlertsV2AlertsEvaluationThresholdValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsEvaluationThresholdValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEvaluationThresholdValue | cdktn.IResolvable | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface DataDatabricksAlertsV2AlertsEvaluationThreshold {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#column DataDatabricksAlertsV2#column}
    */
    readonly column?: DataDatabricksAlertsV2AlertsEvaluationThresholdColumn;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#value DataDatabricksAlertsV2#value}
    */
    readonly value?: DataDatabricksAlertsV2AlertsEvaluationThresholdValue;
}
export declare function dataDatabricksAlertsV2AlertsEvaluationThresholdToTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationThreshold | cdktn.IResolvable): any;
export declare function dataDatabricksAlertsV2AlertsEvaluationThresholdToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluationThreshold | cdktn.IResolvable): any;
export declare class DataDatabricksAlertsV2AlertsEvaluationThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsEvaluationThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEvaluationThreshold | cdktn.IResolvable | undefined);
    private _column;
    get column(): DataDatabricksAlertsV2AlertsEvaluationThresholdColumnOutputReference;
    putColumn(value: DataDatabricksAlertsV2AlertsEvaluationThresholdColumn): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | DataDatabricksAlertsV2AlertsEvaluationThresholdColumn | undefined;
    private _value;
    get value(): DataDatabricksAlertsV2AlertsEvaluationThresholdValueOutputReference;
    putValue(value: DataDatabricksAlertsV2AlertsEvaluationThresholdValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | DataDatabricksAlertsV2AlertsEvaluationThresholdValue | undefined;
}
export interface DataDatabricksAlertsV2AlertsEvaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#comparison_operator DataDatabricksAlertsV2#comparison_operator}
    */
    readonly comparisonOperator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#empty_result_state DataDatabricksAlertsV2#empty_result_state}
    */
    readonly emptyResultState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#notification DataDatabricksAlertsV2#notification}
    */
    readonly notification?: DataDatabricksAlertsV2AlertsEvaluationNotification;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#source DataDatabricksAlertsV2#source}
    */
    readonly source: DataDatabricksAlertsV2AlertsEvaluationSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#threshold DataDatabricksAlertsV2#threshold}
    */
    readonly threshold?: DataDatabricksAlertsV2AlertsEvaluationThreshold;
}
export declare function dataDatabricksAlertsV2AlertsEvaluationToTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluation): any;
export declare function dataDatabricksAlertsV2AlertsEvaluationToHclTerraform(struct?: DataDatabricksAlertsV2AlertsEvaluation): any;
export declare class DataDatabricksAlertsV2AlertsEvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsEvaluation | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsEvaluation | undefined);
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    get comparisonOperatorInput(): string | undefined;
    private _emptyResultState?;
    get emptyResultState(): string;
    set emptyResultState(value: string);
    resetEmptyResultState(): void;
    get emptyResultStateInput(): string | undefined;
    get lastEvaluatedAt(): string;
    private _notification;
    get notification(): DataDatabricksAlertsV2AlertsEvaluationNotificationOutputReference;
    putNotification(value: DataDatabricksAlertsV2AlertsEvaluationNotification): void;
    resetNotification(): void;
    get notificationInput(): cdktn.IResolvable | DataDatabricksAlertsV2AlertsEvaluationNotification | undefined;
    private _source;
    get source(): DataDatabricksAlertsV2AlertsEvaluationSourceOutputReference;
    putSource(value: DataDatabricksAlertsV2AlertsEvaluationSource): void;
    get sourceInput(): DataDatabricksAlertsV2AlertsEvaluationSource | undefined;
    get state(): string;
    private _threshold;
    get threshold(): DataDatabricksAlertsV2AlertsEvaluationThresholdOutputReference;
    putThreshold(value: DataDatabricksAlertsV2AlertsEvaluationThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | DataDatabricksAlertsV2AlertsEvaluationThreshold | undefined;
}
export interface DataDatabricksAlertsV2AlertsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#name DataDatabricksAlertsV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#type DataDatabricksAlertsV2#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#value DataDatabricksAlertsV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAlertsV2AlertsParametersToTerraform(struct?: DataDatabricksAlertsV2AlertsParameters): any;
export declare function dataDatabricksAlertsV2AlertsParametersToHclTerraform(struct?: DataDatabricksAlertsV2AlertsParameters): any;
export declare class DataDatabricksAlertsV2AlertsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAlertsV2AlertsParameters | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsParameters | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksAlertsV2AlertsParametersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAlertsV2AlertsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAlertsV2AlertsParametersOutputReference;
}
export interface DataDatabricksAlertsV2AlertsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#workspace_id DataDatabricksAlertsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAlertsV2AlertsProviderConfigToTerraform(struct?: DataDatabricksAlertsV2AlertsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAlertsV2AlertsProviderConfigToHclTerraform(struct?: DataDatabricksAlertsV2AlertsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAlertsV2AlertsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAlertsV2AlertsRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#service_principal_name DataDatabricksAlertsV2#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#user_name DataDatabricksAlertsV2#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksAlertsV2AlertsRunAsToTerraform(struct?: DataDatabricksAlertsV2AlertsRunAs): any;
export declare function dataDatabricksAlertsV2AlertsRunAsToHclTerraform(struct?: DataDatabricksAlertsV2AlertsRunAs): any;
export declare class DataDatabricksAlertsV2AlertsRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsRunAs | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsRunAs | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface DataDatabricksAlertsV2AlertsSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#pause_status DataDatabricksAlertsV2#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#quartz_cron_schedule DataDatabricksAlertsV2#quartz_cron_schedule}
    */
    readonly quartzCronSchedule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#timezone_id DataDatabricksAlertsV2#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function dataDatabricksAlertsV2AlertsScheduleToTerraform(struct?: DataDatabricksAlertsV2AlertsSchedule): any;
export declare function dataDatabricksAlertsV2AlertsScheduleToHclTerraform(struct?: DataDatabricksAlertsV2AlertsSchedule): any;
export declare class DataDatabricksAlertsV2AlertsScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2AlertsSchedule | undefined;
    set internalValue(value: DataDatabricksAlertsV2AlertsSchedule | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _quartzCronSchedule?;
    get quartzCronSchedule(): string;
    set quartzCronSchedule(value: string);
    get quartzCronScheduleInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface DataDatabricksAlertsV2Alerts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#id DataDatabricksAlertsV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#provider_config DataDatabricksAlertsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksAlertsV2AlertsProviderConfig;
}
export declare function dataDatabricksAlertsV2AlertsToTerraform(struct?: DataDatabricksAlertsV2Alerts): any;
export declare function dataDatabricksAlertsV2AlertsToHclTerraform(struct?: DataDatabricksAlertsV2Alerts): any;
export declare class DataDatabricksAlertsV2AlertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAlertsV2Alerts | undefined;
    set internalValue(value: DataDatabricksAlertsV2Alerts | undefined);
    get createTime(): string;
    get customDescription(): string;
    get customSummary(): string;
    get displayName(): string;
    private _effectiveRunAs;
    get effectiveRunAs(): DataDatabricksAlertsV2AlertsEffectiveRunAsOutputReference;
    private _evaluation;
    get evaluation(): DataDatabricksAlertsV2AlertsEvaluationOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get lifecycleState(): string;
    get ownerUserName(): string;
    private _parameters;
    get parameters(): DataDatabricksAlertsV2AlertsParametersList;
    get parentPath(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAlertsV2AlertsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAlertsV2AlertsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAlertsV2AlertsProviderConfig | undefined;
    get queryText(): string;
    private _runAs;
    get runAs(): DataDatabricksAlertsV2AlertsRunAsOutputReference;
    get runAsUserName(): string;
    private _schedule;
    get schedule(): DataDatabricksAlertsV2AlertsScheduleOutputReference;
    get updateTime(): string;
    get warehouseId(): string;
}
export declare class DataDatabricksAlertsV2AlertsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAlertsV2Alerts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAlertsV2AlertsOutputReference;
}
export interface DataDatabricksAlertsV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#workspace_id DataDatabricksAlertsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAlertsV2ProviderConfigToTerraform(struct?: DataDatabricksAlertsV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAlertsV2ProviderConfigToHclTerraform(struct?: DataDatabricksAlertsV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAlertsV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertsV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertsV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2 databricks_alerts_v2}
*/
export declare class DataDatabricksAlertsV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_alerts_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAlertsV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAlertsV2 to import
    * @param importFromId The id of the existing DataDatabricksAlertsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAlertsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/alerts_v2 databricks_alerts_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAlertsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAlertsV2Config);
    private _alerts;
    get alerts(): DataDatabricksAlertsV2AlertsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAlertsV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAlertsV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAlertsV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
