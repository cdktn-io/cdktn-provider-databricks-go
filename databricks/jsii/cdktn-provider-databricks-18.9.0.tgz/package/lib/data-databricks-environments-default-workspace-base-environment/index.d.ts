/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/environments_default_workspace_base_environment#name DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/environments_default_workspace_base_environment#provider_config DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment#provider_config}
    */
    readonly providerConfig?: DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig;
}
export interface DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/environments_default_workspace_base_environment#workspace_id DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfigToTerraform(struct?: DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfigToHclTerraform(struct?: DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/environments_default_workspace_base_environment databricks_environments_default_workspace_base_environment}
*/
export declare class DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_environments_default_workspace_base_environment";
    /**
    * Generates CDKTN code for importing a DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment to import
    * @param importFromId The id of the existing DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/environments_default_workspace_base_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/environments_default_workspace_base_environment databricks_environments_default_workspace_base_environment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentConfig);
    get cpuWorkspaceBaseEnvironment(): string;
    get gpuWorkspaceBaseEnvironment(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksEnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
