/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiGatewayMcpServicesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#page_size DataDatabricksAiGatewayMcpServices#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#parent DataDatabricksAiGatewayMcpServices#parent}
    */
    readonly parent?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#provider_config DataDatabricksAiGatewayMcpServices#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayMcpServicesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#view DataDatabricksAiGatewayMcpServices#view}
    */
    readonly view?: string;
}
export interface DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#key DataDatabricksAiGatewayMcpServices#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#principal DataDatabricksAiGatewayMcpServices#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#renewal_period DataDatabricksAiGatewayMcpServices#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#requests DataDatabricksAiGatewayMcpServices#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#tokens DataDatabricksAiGatewayMcpServices#tokens}
    */
    readonly tokens?: number;
}
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimitsToTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimitsToHclTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimitsOutputReference;
}
export interface DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#name DataDatabricksAiGatewayMcpServices#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnectionToTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnectionToHclTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection | cdktn.IResolvable | undefined);
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options;
    get options(): cdktn.StringMap;
}
export interface DataDatabricksAiGatewayMcpServicesMcpServicesConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#include_tool_selectors DataDatabricksAiGatewayMcpServices#include_tool_selectors}
    */
    readonly includeToolSelectors?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#rate_limits DataDatabricksAiGatewayMcpServices#rate_limits}
    */
    readonly rateLimits?: DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#source_connection DataDatabricksAiGatewayMcpServices#source_connection}
    */
    readonly sourceConnection?: DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection;
}
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesConfigToTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesConfig): any;
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesConfigToHclTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesConfig): any;
export declare class DataDatabricksAiGatewayMcpServicesMcpServicesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayMcpServicesMcpServicesConfig | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServicesMcpServicesConfig | undefined);
    private _includeToolSelectors?;
    get includeToolSelectors(): string[];
    set includeToolSelectors(value: string[]);
    resetIncludeToolSelectors(): void;
    get includeToolSelectorsInput(): string[] | undefined;
    private _rateLimits;
    get rateLimits(): DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimitsList;
    putRateLimits(value: DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | DataDatabricksAiGatewayMcpServicesMcpServicesConfigRateLimits[] | undefined;
    private _sourceConnection;
    get sourceConnection(): DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnectionOutputReference;
    putSourceConnection(value: DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection): void;
    resetSourceConnection(): void;
    get sourceConnectionInput(): cdktn.IResolvable | DataDatabricksAiGatewayMcpServicesMcpServicesConfigSourceConnection | undefined;
}
export interface DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#workspace_id DataDatabricksAiGatewayMcpServices#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesProviderConfigToTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAiGatewayMcpServicesMcpServices {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#name DataDatabricksAiGatewayMcpServices#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#provider_config DataDatabricksAiGatewayMcpServices#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig;
}
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesToTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServices): any;
export declare function dataDatabricksAiGatewayMcpServicesMcpServicesToHclTerraform(struct?: DataDatabricksAiGatewayMcpServicesMcpServices): any;
export declare class DataDatabricksAiGatewayMcpServicesMcpServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayMcpServicesMcpServices | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServicesMcpServices | undefined);
    get comment(): string;
    private _config;
    get config(): DataDatabricksAiGatewayMcpServicesMcpServicesConfigOutputReference;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayMcpServicesMcpServicesProviderConfig | undefined;
    get updateTime(): string;
    get updatedBy(): string;
}
export declare class DataDatabricksAiGatewayMcpServicesMcpServicesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayMcpServicesMcpServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayMcpServicesMcpServicesOutputReference;
}
export interface DataDatabricksAiGatewayMcpServicesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#workspace_id DataDatabricksAiGatewayMcpServices#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayMcpServicesProviderConfigToTerraform(struct?: DataDatabricksAiGatewayMcpServicesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayMcpServicesProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayMcpServicesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayMcpServicesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayMcpServicesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServicesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services databricks_ai_gateway_mcp_services}
*/
export declare class DataDatabricksAiGatewayMcpServices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_gateway_mcp_services";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiGatewayMcpServices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiGatewayMcpServices to import
    * @param importFromId The id of the existing DataDatabricksAiGatewayMcpServices that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiGatewayMcpServices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/ai_gateway_mcp_services databricks_ai_gateway_mcp_services} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiGatewayMcpServicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAiGatewayMcpServicesConfig);
    private _mcpServices;
    get mcpServices(): DataDatabricksAiGatewayMcpServicesMcpServicesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayMcpServicesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayMcpServicesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayMcpServicesProviderConfig | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
