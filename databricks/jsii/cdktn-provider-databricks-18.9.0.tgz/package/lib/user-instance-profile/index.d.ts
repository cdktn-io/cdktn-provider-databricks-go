/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserInstanceProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile#api UserInstanceProfile#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile#id UserInstanceProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile#instance_profile_id UserInstanceProfile#instance_profile_id}
    */
    readonly instanceProfileId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile#user_id UserInstanceProfile#user_id}
    */
    readonly userId: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile#provider_config UserInstanceProfile#provider_config}
    */
    readonly providerConfig?: UserInstanceProfileProviderConfig;
}
export interface UserInstanceProfileProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile#workspace_id UserInstanceProfile#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function userInstanceProfileProviderConfigToTerraform(struct?: UserInstanceProfileProviderConfigOutputReference | UserInstanceProfileProviderConfig): any;
export declare function userInstanceProfileProviderConfigToHclTerraform(struct?: UserInstanceProfileProviderConfigOutputReference | UserInstanceProfileProviderConfig): any;
export declare class UserInstanceProfileProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserInstanceProfileProviderConfig | undefined;
    set internalValue(value: UserInstanceProfileProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile databricks_user_instance_profile}
*/
export declare class UserInstanceProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_user_instance_profile";
    /**
    * Generates CDKTN code for importing a UserInstanceProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserInstanceProfile to import
    * @param importFromId The id of the existing UserInstanceProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserInstanceProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/user_instance_profile databricks_user_instance_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserInstanceProfileConfig
    */
    constructor(scope: Construct, id: string, config: UserInstanceProfileConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfileId?;
    get instanceProfileId(): string;
    set instanceProfileId(value: string);
    get instanceProfileIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): UserInstanceProfileProviderConfigOutputReference;
    putProviderConfig(value: UserInstanceProfileProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): UserInstanceProfileProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
