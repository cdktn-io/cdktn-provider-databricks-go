/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresDatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#name DataDatabricksPostgresDatabase#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#provider_config DataDatabricksPostgresDatabase#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresDatabaseProviderConfig;
}
export interface DataDatabricksPostgresDatabaseProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#workspace_id DataDatabricksPostgresDatabase#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresDatabaseProviderConfigToTerraform(struct?: DataDatabricksPostgresDatabaseProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresDatabaseProviderConfigToHclTerraform(struct?: DataDatabricksPostgresDatabaseProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresDatabaseProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDatabaseProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresDatabaseProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresDatabaseSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#postgres_database DataDatabricksPostgresDatabase#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#role DataDatabricksPostgresDatabase#role}
    */
    readonly role: string;
}
export declare function dataDatabricksPostgresDatabaseSpecToTerraform(struct?: DataDatabricksPostgresDatabaseSpec): any;
export declare function dataDatabricksPostgresDatabaseSpecToHclTerraform(struct?: DataDatabricksPostgresDatabaseSpec): any;
export declare class DataDatabricksPostgresDatabaseSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDatabaseSpec | undefined;
    set internalValue(value: DataDatabricksPostgresDatabaseSpec | undefined);
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
}
export interface DataDatabricksPostgresDatabaseStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#postgres_database DataDatabricksPostgresDatabase#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#role DataDatabricksPostgresDatabase#role}
    */
    readonly role?: string;
}
export declare function dataDatabricksPostgresDatabaseStatusToTerraform(struct?: DataDatabricksPostgresDatabaseStatus): any;
export declare function dataDatabricksPostgresDatabaseStatusToHclTerraform(struct?: DataDatabricksPostgresDatabaseStatus): any;
export declare class DataDatabricksPostgresDatabaseStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDatabaseStatus | undefined;
    set internalValue(value: DataDatabricksPostgresDatabaseStatus | undefined);
    get databaseId(): string;
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database databricks_postgres_database}
*/
export declare class DataDatabricksPostgresDatabase extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_database";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresDatabase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresDatabase to import
    * @param importFromId The id of the existing DataDatabricksPostgresDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/postgres_database databricks_postgres_database} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresDatabaseConfig);
    get createTime(): string;
    get databaseId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresDatabaseProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresDatabaseProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresDatabaseProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresDatabaseSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresDatabaseStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
