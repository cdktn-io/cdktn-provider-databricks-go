/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#catalog_id PostgresCatalog#catalog_id}
    */
    readonly catalogId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#provider_config PostgresCatalog#provider_config}
    */
    readonly providerConfig?: PostgresCatalogProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#spec PostgresCatalog#spec}
    */
    readonly spec?: PostgresCatalogSpec;
}
export interface PostgresCatalogProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#workspace_id PostgresCatalog#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresCatalogProviderConfigToTerraform(struct?: PostgresCatalogProviderConfig | cdktn.IResolvable): any;
export declare function postgresCatalogProviderConfigToHclTerraform(struct?: PostgresCatalogProviderConfig | cdktn.IResolvable): any;
export declare class PostgresCatalogProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresCatalogProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresCatalogProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresCatalogSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#branch PostgresCatalog#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#create_database_if_missing PostgresCatalog#create_database_if_missing}
    */
    readonly createDatabaseIfMissing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#postgres_database PostgresCatalog#postgres_database}
    */
    readonly postgresDatabase: string;
}
export declare function postgresCatalogSpecToTerraform(struct?: PostgresCatalogSpec | cdktn.IResolvable): any;
export declare function postgresCatalogSpecToHclTerraform(struct?: PostgresCatalogSpec | cdktn.IResolvable): any;
export declare class PostgresCatalogSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresCatalogSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresCatalogSpec | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _createDatabaseIfMissing?;
    get createDatabaseIfMissing(): boolean | cdktn.IResolvable;
    set createDatabaseIfMissing(value: boolean | cdktn.IResolvable);
    resetCreateDatabaseIfMissing(): void;
    get createDatabaseIfMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    get postgresDatabaseInput(): string | undefined;
}
export interface PostgresCatalogStatus {
}
export declare function postgresCatalogStatusToTerraform(struct?: PostgresCatalogStatus): any;
export declare function postgresCatalogStatusToHclTerraform(struct?: PostgresCatalogStatus): any;
export declare class PostgresCatalogStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresCatalogStatus | undefined;
    set internalValue(value: PostgresCatalogStatus | undefined);
    get branch(): string;
    get postgresDatabase(): string;
    get project(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog databricks_postgres_catalog}
*/
export declare class PostgresCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_catalog";
    /**
    * Generates CDKTN code for importing a PostgresCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresCatalog to import
    * @param importFromId The id of the existing PostgresCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_catalog databricks_postgres_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresCatalogConfig
    */
    constructor(scope: Construct, id: string, config: PostgresCatalogConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    get catalogIdInput(): string | undefined;
    get createTime(): string;
    get name(): string;
    private _providerConfig;
    get providerConfig(): PostgresCatalogProviderConfigOutputReference;
    putProviderConfig(value: PostgresCatalogProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresCatalogProviderConfig | undefined;
    private _spec;
    get spec(): PostgresCatalogSpecOutputReference;
    putSpec(value: PostgresCatalogSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresCatalogSpec | undefined;
    private _status;
    get status(): PostgresCatalogStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
