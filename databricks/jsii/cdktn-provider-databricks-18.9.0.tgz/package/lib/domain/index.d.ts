/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#business_owner_ids Domain#business_owner_ids}
    */
    readonly businessOwnerIds?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#description Domain#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#domain_id Domain#domain_id}
    */
    readonly domainId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#draft Domain#draft}
    */
    readonly draft?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#icon Domain#icon}
    */
    readonly icon?: DomainIcon;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#parent_domain_id Domain#parent_domain_id}
    */
    readonly parentDomainId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#provider_config Domain#provider_config}
    */
    readonly providerConfig?: DomainProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#subtitle Domain#subtitle}
    */
    readonly subtitle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#tag_key Domain#tag_key}
    */
    readonly tagKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#technical_owner_ids Domain#technical_owner_ids}
    */
    readonly technicalOwnerIds?: number[];
}
export interface DomainIcon {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#color Domain#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#name Domain#name}
    */
    readonly name?: string;
}
export declare function domainIconToTerraform(struct?: DomainIcon | cdktn.IResolvable): any;
export declare function domainIconToHclTerraform(struct?: DomainIcon | cdktn.IResolvable): any;
export declare class DomainIconOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DomainIcon | cdktn.IResolvable | undefined;
    set internalValue(value: DomainIcon | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DomainProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#workspace_id Domain#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function domainProviderConfigToTerraform(struct?: DomainProviderConfig | cdktn.IResolvable): any;
export declare function domainProviderConfigToHclTerraform(struct?: DomainProviderConfig | cdktn.IResolvable): any;
export declare class DomainProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DomainProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DomainProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain databricks_domain}
*/
export declare class Domain extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_domain";
    /**
    * Generates CDKTN code for importing a Domain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Domain to import
    * @param importFromId The id of the existing Domain that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Domain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/domain databricks_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DomainConfig
    */
    constructor(scope: Construct, id: string, config: DomainConfig);
    private _businessOwnerIds?;
    get businessOwnerIds(): number[];
    set businessOwnerIds(value: number[]);
    resetBusinessOwnerIds(): void;
    get businessOwnerIdsInput(): number[] | undefined;
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    resetDomainId(): void;
    get domainIdInput(): string | undefined;
    private _draft?;
    get draft(): boolean | cdktn.IResolvable;
    set draft(value: boolean | cdktn.IResolvable);
    resetDraft(): void;
    get draftInput(): boolean | cdktn.IResolvable | undefined;
    get effectiveDraft(): cdktn.IResolvable;
    private _icon;
    get icon(): DomainIconOutputReference;
    putIcon(value: DomainIcon): void;
    resetIcon(): void;
    get iconInput(): cdktn.IResolvable | DomainIcon | undefined;
    get name(): string;
    private _parentDomainId?;
    get parentDomainId(): string;
    set parentDomainId(value: string);
    resetParentDomainId(): void;
    get parentDomainIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DomainProviderConfigOutputReference;
    putProviderConfig(value: DomainProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DomainProviderConfig | undefined;
    private _subtitle?;
    get subtitle(): string;
    set subtitle(value: string);
    resetSubtitle(): void;
    get subtitleInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    private _technicalOwnerIds?;
    get technicalOwnerIds(): number[];
    set technicalOwnerIds(value: number[]);
    resetTechnicalOwnerIds(): void;
    get technicalOwnerIdsInput(): number[] | undefined;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
