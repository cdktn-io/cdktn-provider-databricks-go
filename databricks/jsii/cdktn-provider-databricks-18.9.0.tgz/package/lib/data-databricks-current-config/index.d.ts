/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksCurrentConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#account_id DataDatabricksCurrentConfig#account_id}
    */
    readonly accountId?: string;
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#api DataDatabricksCurrentConfig#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#auth_type DataDatabricksCurrentConfig#auth_type}
    */
    readonly authType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#cloud DataDatabricksCurrentConfig#cloud}
    */
    readonly cloud?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#cloud_type DataDatabricksCurrentConfig#cloud_type}
    */
    readonly cloudType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#host DataDatabricksCurrentConfig#host}
    */
    readonly host?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#id DataDatabricksCurrentConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#is_account DataDatabricksCurrentConfig#is_account}
    */
    readonly isAccount?: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#provider_config DataDatabricksCurrentConfig#provider_config}
    */
    readonly providerConfig?: DataDatabricksCurrentConfigProviderConfig;
}
export interface DataDatabricksCurrentConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#workspace_id DataDatabricksCurrentConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksCurrentConfigProviderConfigToTerraform(struct?: DataDatabricksCurrentConfigProviderConfigOutputReference | DataDatabricksCurrentConfigProviderConfig): any;
export declare function dataDatabricksCurrentConfigProviderConfigToHclTerraform(struct?: DataDatabricksCurrentConfigProviderConfigOutputReference | DataDatabricksCurrentConfigProviderConfig): any;
export declare class DataDatabricksCurrentConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCurrentConfigProviderConfig | undefined;
    set internalValue(value: DataDatabricksCurrentConfigProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config databricks_current_config}
*/
export declare class DataDatabricksCurrentConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_current_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksCurrentConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksCurrentConfig to import
    * @param importFromId The id of the existing DataDatabricksCurrentConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksCurrentConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/current_config databricks_current_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksCurrentConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksCurrentConfigConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _authType?;
    get authType(): string;
    set authType(value: string);
    resetAuthType(): void;
    get authTypeInput(): string | undefined;
    private _cloud?;
    get cloud(): string;
    set cloud(value: string);
    resetCloud(): void;
    get cloudInput(): string | undefined;
    private _cloudType?;
    get cloudType(): string;
    set cloudType(value: string);
    resetCloudType(): void;
    get cloudTypeInput(): string | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isAccount?;
    get isAccount(): boolean | cdktn.IResolvable;
    set isAccount(value: boolean | cdktn.IResolvable);
    resetIsAccount(): void;
    get isAccountInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksCurrentConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksCurrentConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksCurrentConfigProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
