/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresSnapshotScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#parent PostgresSnapshotSchedule#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#provider_config PostgresSnapshotSchedule#provider_config}
    */
    readonly providerConfig?: PostgresSnapshotScheduleProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#schedule PostgresSnapshotSchedule#schedule}
    */
    readonly schedule?: PostgresSnapshotScheduleSchedule[] | cdktn.IResolvable;
}
export interface PostgresSnapshotScheduleProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#workspace_id PostgresSnapshotSchedule#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresSnapshotScheduleProviderConfigToTerraform(struct?: PostgresSnapshotScheduleProviderConfig | cdktn.IResolvable): any;
export declare function postgresSnapshotScheduleProviderConfigToHclTerraform(struct?: PostgresSnapshotScheduleProviderConfig | cdktn.IResolvable): any;
export declare class PostgresSnapshotScheduleProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSnapshotScheduleProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSnapshotScheduleProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresSnapshotScheduleScheduleDailySchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#hour PostgresSnapshotSchedule#hour}
    */
    readonly hour?: number;
}
export declare function postgresSnapshotScheduleScheduleDailyScheduleToTerraform(struct?: PostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable): any;
export declare function postgresSnapshotScheduleScheduleDailyScheduleToHclTerraform(struct?: PostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable): any;
export declare class PostgresSnapshotScheduleScheduleDailyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable | undefined);
    private _hour?;
    get hour(): number;
    set hour(value: number);
    resetHour(): void;
    get hourInput(): number | undefined;
}
export interface PostgresSnapshotScheduleScheduleMonthlySchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#day PostgresSnapshotSchedule#day}
    */
    readonly day: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#hour PostgresSnapshotSchedule#hour}
    */
    readonly hour?: number;
}
export declare function postgresSnapshotScheduleScheduleMonthlyScheduleToTerraform(struct?: PostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable): any;
export declare function postgresSnapshotScheduleScheduleMonthlyScheduleToHclTerraform(struct?: PostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable): any;
export declare class PostgresSnapshotScheduleScheduleMonthlyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable | undefined);
    private _day?;
    get day(): number;
    set day(value: number);
    get dayInput(): number | undefined;
    private _hour?;
    get hour(): number;
    set hour(value: number);
    resetHour(): void;
    get hourInput(): number | undefined;
}
export interface PostgresSnapshotScheduleScheduleWeeklySchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#day_of_week PostgresSnapshotSchedule#day_of_week}
    */
    readonly dayOfWeek: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#hour PostgresSnapshotSchedule#hour}
    */
    readonly hour?: number;
}
export declare function postgresSnapshotScheduleScheduleWeeklyScheduleToTerraform(struct?: PostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable): any;
export declare function postgresSnapshotScheduleScheduleWeeklyScheduleToHclTerraform(struct?: PostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable): any;
export declare class PostgresSnapshotScheduleScheduleWeeklyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    get dayOfWeekInput(): string | undefined;
    private _hour?;
    get hour(): number;
    set hour(value: number);
    resetHour(): void;
    get hourInput(): number | undefined;
}
export interface PostgresSnapshotScheduleSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#daily_schedule PostgresSnapshotSchedule#daily_schedule}
    */
    readonly dailySchedule?: PostgresSnapshotScheduleScheduleDailySchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#monthly_schedule PostgresSnapshotSchedule#monthly_schedule}
    */
    readonly monthlySchedule?: PostgresSnapshotScheduleScheduleMonthlySchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#retention PostgresSnapshotSchedule#retention}
    */
    readonly retention: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#weekly_schedule PostgresSnapshotSchedule#weekly_schedule}
    */
    readonly weeklySchedule?: PostgresSnapshotScheduleScheduleWeeklySchedule;
}
export declare function postgresSnapshotScheduleScheduleToTerraform(struct?: PostgresSnapshotScheduleSchedule | cdktn.IResolvable): any;
export declare function postgresSnapshotScheduleScheduleToHclTerraform(struct?: PostgresSnapshotScheduleSchedule | cdktn.IResolvable): any;
export declare class PostgresSnapshotScheduleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PostgresSnapshotScheduleSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresSnapshotScheduleSchedule | cdktn.IResolvable | undefined);
    private _dailySchedule;
    get dailySchedule(): PostgresSnapshotScheduleScheduleDailyScheduleOutputReference;
    putDailySchedule(value: PostgresSnapshotScheduleScheduleDailySchedule): void;
    resetDailySchedule(): void;
    get dailyScheduleInput(): cdktn.IResolvable | PostgresSnapshotScheduleScheduleDailySchedule | undefined;
    private _monthlySchedule;
    get monthlySchedule(): PostgresSnapshotScheduleScheduleMonthlyScheduleOutputReference;
    putMonthlySchedule(value: PostgresSnapshotScheduleScheduleMonthlySchedule): void;
    resetMonthlySchedule(): void;
    get monthlyScheduleInput(): cdktn.IResolvable | PostgresSnapshotScheduleScheduleMonthlySchedule | undefined;
    private _retention?;
    get retention(): string;
    set retention(value: string);
    get retentionInput(): string | undefined;
    private _weeklySchedule;
    get weeklySchedule(): PostgresSnapshotScheduleScheduleWeeklyScheduleOutputReference;
    putWeeklySchedule(value: PostgresSnapshotScheduleScheduleWeeklySchedule): void;
    resetWeeklySchedule(): void;
    get weeklyScheduleInput(): cdktn.IResolvable | PostgresSnapshotScheduleScheduleWeeklySchedule | undefined;
}
export declare class PostgresSnapshotScheduleScheduleList extends cdktn.ComplexList {
    internalValue?: PostgresSnapshotScheduleSchedule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PostgresSnapshotScheduleScheduleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule databricks_postgres_snapshot_schedule}
*/
export declare class PostgresSnapshotSchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_snapshot_schedule";
    /**
    * Generates CDKTN code for importing a PostgresSnapshotSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresSnapshotSchedule to import
    * @param importFromId The id of the existing PostgresSnapshotSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresSnapshotSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_snapshot_schedule databricks_postgres_snapshot_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresSnapshotScheduleConfig
    */
    constructor(scope: Construct, id: string, config: PostgresSnapshotScheduleConfig);
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresSnapshotScheduleProviderConfigOutputReference;
    putProviderConfig(value: PostgresSnapshotScheduleProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresSnapshotScheduleProviderConfig | undefined;
    private _schedule;
    get schedule(): PostgresSnapshotScheduleScheduleList;
    putSchedule(value: PostgresSnapshotScheduleSchedule[] | cdktn.IResolvable): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | PostgresSnapshotScheduleSchedule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
