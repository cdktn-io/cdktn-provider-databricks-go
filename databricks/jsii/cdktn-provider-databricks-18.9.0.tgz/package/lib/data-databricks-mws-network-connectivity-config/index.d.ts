/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMwsNetworkConnectivityConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#account_id DataDatabricksMwsNetworkConnectivityConfig#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#creation_time DataDatabricksMwsNetworkConnectivityConfig#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#id DataDatabricksMwsNetworkConnectivityConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#name DataDatabricksMwsNetworkConnectivityConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#network_connectivity_config_id DataDatabricksMwsNetworkConnectivityConfig#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#region DataDatabricksMwsNetworkConnectivityConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#updated_time DataDatabricksMwsNetworkConnectivityConfig#updated_time}
    */
    readonly updatedTime?: number;
    /**
    * egress_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#egress_config DataDatabricksMwsNetworkConnectivityConfig#egress_config}
    */
    readonly egressConfig?: DataDatabricksMwsNetworkConnectivityConfigEgressConfig;
}
export interface DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#cidr_blocks DataDatabricksMwsNetworkConnectivityConfig#cidr_blocks}
    */
    readonly cidrBlocks?: string[];
}
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleToTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule): any;
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleToHclTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule): any;
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule | undefined;
    set internalValue(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule | undefined);
    private _cidrBlocks?;
    get cidrBlocks(): string[];
    set cidrBlocks(value: string[]);
    resetCidrBlocks(): void;
    get cidrBlocksInput(): string[] | undefined;
}
export interface DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#subnets DataDatabricksMwsNetworkConnectivityConfig#subnets}
    */
    readonly subnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#target_region DataDatabricksMwsNetworkConnectivityConfig#target_region}
    */
    readonly targetRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#target_services DataDatabricksMwsNetworkConnectivityConfig#target_services}
    */
    readonly targetServices?: string[];
}
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleToTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule): any;
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleToHclTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule): any;
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule | undefined;
    set internalValue(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule | undefined);
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
    private _targetRegion?;
    get targetRegion(): string;
    set targetRegion(value: string);
    resetTargetRegion(): void;
    get targetRegionInput(): string | undefined;
    private _targetServices?;
    get targetServices(): string[];
    set targetServices(value: string[]);
    resetTargetServices(): void;
    get targetServicesInput(): string[] | undefined;
}
export interface DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules {
    /**
    * aws_stable_ip_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#aws_stable_ip_rule DataDatabricksMwsNetworkConnectivityConfig#aws_stable_ip_rule}
    */
    readonly awsStableIpRule?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule;
    /**
    * azure_service_endpoint_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#azure_service_endpoint_rule DataDatabricksMwsNetworkConnectivityConfig#azure_service_endpoint_rule}
    */
    readonly azureServiceEndpointRule?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule;
}
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesToTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules): any;
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesToHclTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules): any;
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules | undefined;
    set internalValue(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules | undefined);
    private _awsStableIpRule;
    get awsStableIpRule(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference;
    putAwsStableIpRule(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule): void;
    resetAwsStableIpRule(): void;
    get awsStableIpRuleInput(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule | undefined;
    private _azureServiceEndpointRule;
    get azureServiceEndpointRule(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference;
    putAzureServiceEndpointRule(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule): void;
    resetAzureServiceEndpointRule(): void;
    get azureServiceEndpointRuleInput(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule | undefined;
}
export interface DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#account_id DataDatabricksMwsNetworkConnectivityConfig#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#connection_state DataDatabricksMwsNetworkConnectivityConfig#connection_state}
    */
    readonly connectionState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#creation_time DataDatabricksMwsNetworkConnectivityConfig#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#deactivated DataDatabricksMwsNetworkConnectivityConfig#deactivated}
    */
    readonly deactivated?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#deactivated_at DataDatabricksMwsNetworkConnectivityConfig#deactivated_at}
    */
    readonly deactivatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#domain_names DataDatabricksMwsNetworkConnectivityConfig#domain_names}
    */
    readonly domainNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#enabled DataDatabricksMwsNetworkConnectivityConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#endpoint_service DataDatabricksMwsNetworkConnectivityConfig#endpoint_service}
    */
    readonly endpointService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#error_message DataDatabricksMwsNetworkConnectivityConfig#error_message}
    */
    readonly errorMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#network_connectivity_config_id DataDatabricksMwsNetworkConnectivityConfig#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#resource_names DataDatabricksMwsNetworkConnectivityConfig#resource_names}
    */
    readonly resourceNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#rule_id DataDatabricksMwsNetworkConnectivityConfig#rule_id}
    */
    readonly ruleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#updated_time DataDatabricksMwsNetworkConnectivityConfig#updated_time}
    */
    readonly updatedTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#vpc_endpoint_id DataDatabricksMwsNetworkConnectivityConfig#vpc_endpoint_id}
    */
    readonly vpcEndpointId?: string;
}
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesToTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable): any;
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesToHclTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable): any;
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _connectionState?;
    get connectionState(): string;
    set connectionState(value: string);
    resetConnectionState(): void;
    get connectionStateInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _deactivated?;
    get deactivated(): boolean | cdktn.IResolvable;
    set deactivated(value: boolean | cdktn.IResolvable);
    resetDeactivated(): void;
    get deactivatedInput(): boolean | cdktn.IResolvable | undefined;
    private _deactivatedAt?;
    get deactivatedAt(): number;
    set deactivatedAt(value: number);
    resetDeactivatedAt(): void;
    get deactivatedAtInput(): number | undefined;
    private _domainNames?;
    get domainNames(): string[];
    set domainNames(value: string[]);
    resetDomainNames(): void;
    get domainNamesInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointService?;
    get endpointService(): string;
    set endpointService(value: string);
    resetEndpointService(): void;
    get endpointServiceInput(): string | undefined;
    private _errorMessage?;
    get errorMessage(): string;
    set errorMessage(value: string);
    resetErrorMessage(): void;
    get errorMessageInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    resetNetworkConnectivityConfigId(): void;
    get networkConnectivityConfigIdInput(): string | undefined;
    private _resourceNames?;
    get resourceNames(): string[];
    set resourceNames(value: string[]);
    resetResourceNames(): void;
    get resourceNamesInput(): string[] | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    resetRuleId(): void;
    get ruleIdInput(): string | undefined;
    private _updatedTime?;
    get updatedTime(): number;
    set updatedTime(value: number);
    resetUpdatedTime(): void;
    get updatedTimeInput(): number | undefined;
    private _vpcEndpointId?;
    get vpcEndpointId(): string;
    set vpcEndpointId(value: string);
    resetVpcEndpointId(): void;
    get vpcEndpointIdInput(): string | undefined;
}
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesOutputReference;
}
export interface DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#connection_state DataDatabricksMwsNetworkConnectivityConfig#connection_state}
    */
    readonly connectionState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#creation_time DataDatabricksMwsNetworkConnectivityConfig#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#deactivated DataDatabricksMwsNetworkConnectivityConfig#deactivated}
    */
    readonly deactivated?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#deactivated_at DataDatabricksMwsNetworkConnectivityConfig#deactivated_at}
    */
    readonly deactivatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#domain_names DataDatabricksMwsNetworkConnectivityConfig#domain_names}
    */
    readonly domainNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#endpoint_name DataDatabricksMwsNetworkConnectivityConfig#endpoint_name}
    */
    readonly endpointName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#error_message DataDatabricksMwsNetworkConnectivityConfig#error_message}
    */
    readonly errorMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#group_id DataDatabricksMwsNetworkConnectivityConfig#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#network_connectivity_config_id DataDatabricksMwsNetworkConnectivityConfig#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#resource_id DataDatabricksMwsNetworkConnectivityConfig#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#rule_id DataDatabricksMwsNetworkConnectivityConfig#rule_id}
    */
    readonly ruleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#updated_time DataDatabricksMwsNetworkConnectivityConfig#updated_time}
    */
    readonly updatedTime?: number;
}
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesToTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable): any;
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesToHclTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable): any;
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable | undefined);
    private _connectionState?;
    get connectionState(): string;
    set connectionState(value: string);
    resetConnectionState(): void;
    get connectionStateInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _deactivated?;
    get deactivated(): boolean | cdktn.IResolvable;
    set deactivated(value: boolean | cdktn.IResolvable);
    resetDeactivated(): void;
    get deactivatedInput(): boolean | cdktn.IResolvable | undefined;
    private _deactivatedAt?;
    get deactivatedAt(): number;
    set deactivatedAt(value: number);
    resetDeactivatedAt(): void;
    get deactivatedAtInput(): number | undefined;
    private _domainNames?;
    get domainNames(): string[];
    set domainNames(value: string[]);
    resetDomainNames(): void;
    get domainNamesInput(): string[] | undefined;
    private _endpointName?;
    get endpointName(): string;
    set endpointName(value: string);
    resetEndpointName(): void;
    get endpointNameInput(): string | undefined;
    private _errorMessage?;
    get errorMessage(): string;
    set errorMessage(value: string);
    resetErrorMessage(): void;
    get errorMessageInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    resetNetworkConnectivityConfigId(): void;
    get networkConnectivityConfigIdInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    resetRuleId(): void;
    get ruleIdInput(): string | undefined;
    private _updatedTime?;
    get updatedTime(): number;
    set updatedTime(value: number);
    resetUpdatedTime(): void;
    get updatedTimeInput(): number | undefined;
}
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesOutputReference;
}
export interface DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules {
    /**
    * aws_private_endpoint_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#aws_private_endpoint_rules DataDatabricksMwsNetworkConnectivityConfig#aws_private_endpoint_rules}
    */
    readonly awsPrivateEndpointRules?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | cdktn.IResolvable;
    /**
    * azure_private_endpoint_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#azure_private_endpoint_rules DataDatabricksMwsNetworkConnectivityConfig#azure_private_endpoint_rules}
    */
    readonly azurePrivateEndpointRules?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | cdktn.IResolvable;
}
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesToTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules): any;
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesToHclTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules): any;
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules | undefined;
    set internalValue(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules | undefined);
    private _awsPrivateEndpointRules;
    get awsPrivateEndpointRules(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesList;
    putAwsPrivateEndpointRules(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | cdktn.IResolvable): void;
    resetAwsPrivateEndpointRules(): void;
    get awsPrivateEndpointRulesInput(): cdktn.IResolvable | DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | undefined;
    private _azurePrivateEndpointRules;
    get azurePrivateEndpointRules(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesList;
    putAzurePrivateEndpointRules(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | cdktn.IResolvable): void;
    resetAzurePrivateEndpointRules(): void;
    get azurePrivateEndpointRulesInput(): cdktn.IResolvable | DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | undefined;
}
export interface DataDatabricksMwsNetworkConnectivityConfigEgressConfig {
    /**
    * default_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#default_rules DataDatabricksMwsNetworkConnectivityConfig#default_rules}
    */
    readonly defaultRules?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules;
    /**
    * target_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#target_rules DataDatabricksMwsNetworkConnectivityConfig#target_rules}
    */
    readonly targetRules?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules;
}
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigToTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfig): any;
export declare function dataDatabricksMwsNetworkConnectivityConfigEgressConfigToHclTerraform(struct?: DataDatabricksMwsNetworkConnectivityConfigEgressConfigOutputReference | DataDatabricksMwsNetworkConnectivityConfigEgressConfig): any;
export declare class DataDatabricksMwsNetworkConnectivityConfigEgressConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMwsNetworkConnectivityConfigEgressConfig | undefined;
    set internalValue(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfig | undefined);
    private _defaultRules;
    get defaultRules(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference;
    putDefaultRules(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules): void;
    resetDefaultRules(): void;
    get defaultRulesInput(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigDefaultRules | undefined;
    private _targetRules;
    get targetRules(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference;
    putTargetRules(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules): void;
    resetTargetRules(): void;
    get targetRulesInput(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigTargetRules | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config databricks_mws_network_connectivity_config}
*/
export declare class DataDatabricksMwsNetworkConnectivityConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mws_network_connectivity_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksMwsNetworkConnectivityConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMwsNetworkConnectivityConfig to import
    * @param importFromId The id of the existing DataDatabricksMwsNetworkConnectivityConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMwsNetworkConnectivityConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/mws_network_connectivity_config databricks_mws_network_connectivity_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMwsNetworkConnectivityConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksMwsNetworkConnectivityConfigConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    resetNetworkConnectivityConfigId(): void;
    get networkConnectivityConfigIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _updatedTime?;
    get updatedTime(): number;
    set updatedTime(value: number);
    resetUpdatedTime(): void;
    get updatedTimeInput(): number | undefined;
    private _egressConfig;
    get egressConfig(): DataDatabricksMwsNetworkConnectivityConfigEgressConfigOutputReference;
    putEgressConfig(value: DataDatabricksMwsNetworkConnectivityConfigEgressConfig): void;
    resetEgressConfig(): void;
    get egressConfigInput(): DataDatabricksMwsNetworkConnectivityConfigEgressConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
