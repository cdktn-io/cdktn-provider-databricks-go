/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SchemaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#catalog_name Schema#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#comment Schema#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#enable_predictive_optimization Schema#enable_predictive_optimization}
    */
    readonly enablePredictiveOptimization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#force_destroy Schema#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#id Schema#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#metastore_id Schema#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#name Schema#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#owner Schema#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#properties Schema#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#storage_root Schema#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#provider_config Schema#provider_config}
    */
    readonly providerConfig?: SchemaProviderConfig;
}
export interface SchemaProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#workspace_id Schema#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function schemaProviderConfigToTerraform(struct?: SchemaProviderConfigOutputReference | SchemaProviderConfig): any;
export declare function schemaProviderConfigToHclTerraform(struct?: SchemaProviderConfigOutputReference | SchemaProviderConfig): any;
export declare class SchemaProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SchemaProviderConfig | undefined;
    set internalValue(value: SchemaProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema databricks_schema}
*/
export declare class Schema extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_schema";
    /**
    * Generates CDKTN code for importing a Schema resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Schema to import
    * @param importFromId The id of the existing Schema that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Schema to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/schema databricks_schema} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SchemaConfig
    */
    constructor(scope: Construct, id: string, config: SchemaConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _enablePredictiveOptimization?;
    get enablePredictiveOptimization(): string;
    set enablePredictiveOptimization(value: string);
    resetEnablePredictiveOptimization(): void;
    get enablePredictiveOptimizationInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    get schemaId(): string;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): SchemaProviderConfigOutputReference;
    putProviderConfig(value: SchemaProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SchemaProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
