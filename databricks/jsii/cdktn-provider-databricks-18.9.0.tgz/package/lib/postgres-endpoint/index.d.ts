/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#endpoint_id PostgresEndpoint#endpoint_id}
    */
    readonly endpointId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#parent PostgresEndpoint#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#provider_config PostgresEndpoint#provider_config}
    */
    readonly providerConfig?: PostgresEndpointProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#replace_existing PostgresEndpoint#replace_existing}
    */
    readonly replaceExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#spec PostgresEndpoint#spec}
    */
    readonly spec?: PostgresEndpointSpec;
}
export interface PostgresEndpointProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#workspace_id PostgresEndpoint#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresEndpointProviderConfigToTerraform(struct?: PostgresEndpointProviderConfig | cdktn.IResolvable): any;
export declare function postgresEndpointProviderConfigToHclTerraform(struct?: PostgresEndpointProviderConfig | cdktn.IResolvable): any;
export declare class PostgresEndpointProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresEndpointProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresEndpointSpecGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#enable_readable_secondaries PostgresEndpoint#enable_readable_secondaries}
    */
    readonly enableReadableSecondaries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#max PostgresEndpoint#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#min PostgresEndpoint#min}
    */
    readonly min: number;
}
export declare function postgresEndpointSpecGroupToTerraform(struct?: PostgresEndpointSpecGroup | cdktn.IResolvable): any;
export declare function postgresEndpointSpecGroupToHclTerraform(struct?: PostgresEndpointSpecGroup | cdktn.IResolvable): any;
export declare class PostgresEndpointSpecGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointSpecGroup | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresEndpointSpecGroup | cdktn.IResolvable | undefined);
    private _enableReadableSecondaries?;
    get enableReadableSecondaries(): boolean | cdktn.IResolvable;
    set enableReadableSecondaries(value: boolean | cdktn.IResolvable);
    resetEnableReadableSecondaries(): void;
    get enableReadableSecondariesInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface PostgresEndpointSpecSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#pg_settings PostgresEndpoint#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
}
export declare function postgresEndpointSpecSettingsToTerraform(struct?: PostgresEndpointSpecSettings | cdktn.IResolvable): any;
export declare function postgresEndpointSpecSettingsToHclTerraform(struct?: PostgresEndpointSpecSettings | cdktn.IResolvable): any;
export declare class PostgresEndpointSpecSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointSpecSettings | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresEndpointSpecSettings | cdktn.IResolvable | undefined);
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface PostgresEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#autoscaling_limit_max_cu PostgresEndpoint#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#autoscaling_limit_min_cu PostgresEndpoint#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#disabled PostgresEndpoint#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#endpoint_type PostgresEndpoint#endpoint_type}
    */
    readonly endpointType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#group PostgresEndpoint#group}
    */
    readonly group?: PostgresEndpointSpecGroup;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#no_suspension PostgresEndpoint#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#settings PostgresEndpoint#settings}
    */
    readonly settings?: PostgresEndpointSpecSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#suspend_timeout_duration PostgresEndpoint#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function postgresEndpointSpecToTerraform(struct?: PostgresEndpointSpec | cdktn.IResolvable): any;
export declare function postgresEndpointSpecToHclTerraform(struct?: PostgresEndpointSpec | cdktn.IResolvable): any;
export declare class PostgresEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresEndpointSpec | cdktn.IResolvable | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    get endpointTypeInput(): string | undefined;
    private _group;
    get group(): PostgresEndpointSpecGroupOutputReference;
    putGroup(value: PostgresEndpointSpecGroup): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | PostgresEndpointSpecGroup | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _settings;
    get settings(): PostgresEndpointSpecSettingsOutputReference;
    putSettings(value: PostgresEndpointSpecSettings): void;
    resetSettings(): void;
    get settingsInput(): cdktn.IResolvable | PostgresEndpointSpecSettings | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface PostgresEndpointStatusGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#max PostgresEndpoint#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#min PostgresEndpoint#min}
    */
    readonly min: number;
}
export declare function postgresEndpointStatusGroupToTerraform(struct?: PostgresEndpointStatusGroup): any;
export declare function postgresEndpointStatusGroupToHclTerraform(struct?: PostgresEndpointStatusGroup): any;
export declare class PostgresEndpointStatusGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointStatusGroup | undefined;
    set internalValue(value: PostgresEndpointStatusGroup | undefined);
    get enableReadableSecondaries(): cdktn.IResolvable;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface PostgresEndpointStatusHosts {
}
export declare function postgresEndpointStatusHostsToTerraform(struct?: PostgresEndpointStatusHosts): any;
export declare function postgresEndpointStatusHostsToHclTerraform(struct?: PostgresEndpointStatusHosts): any;
export declare class PostgresEndpointStatusHostsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointStatusHosts | undefined;
    set internalValue(value: PostgresEndpointStatusHosts | undefined);
    get host(): string;
    get readOnlyHost(): string;
    get readOnlyPooledHost(): string;
    get readWritePooledHost(): string;
}
export interface PostgresEndpointStatusSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#pg_settings PostgresEndpoint#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
}
export declare function postgresEndpointStatusSettingsToTerraform(struct?: PostgresEndpointStatusSettings): any;
export declare function postgresEndpointStatusSettingsToHclTerraform(struct?: PostgresEndpointStatusSettings): any;
export declare class PostgresEndpointStatusSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointStatusSettings | undefined;
    set internalValue(value: PostgresEndpointStatusSettings | undefined);
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface PostgresEndpointStatus {
}
export declare function postgresEndpointStatusToTerraform(struct?: PostgresEndpointStatus): any;
export declare function postgresEndpointStatusToHclTerraform(struct?: PostgresEndpointStatus): any;
export declare class PostgresEndpointStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresEndpointStatus | undefined;
    set internalValue(value: PostgresEndpointStatus | undefined);
    get autoscalingLimitMaxCu(): number;
    get autoscalingLimitMinCu(): number;
    get currentState(): string;
    get disabled(): cdktn.IResolvable;
    get endpointId(): string;
    get endpointType(): string;
    private _group;
    get group(): PostgresEndpointStatusGroupOutputReference;
    private _hosts;
    get hosts(): PostgresEndpointStatusHostsOutputReference;
    get lastActiveTime(): string;
    get pendingState(): string;
    private _settings;
    get settings(): PostgresEndpointStatusSettingsOutputReference;
    get suspendTimeoutDuration(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint databricks_postgres_endpoint}
*/
export declare class PostgresEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_endpoint";
    /**
    * Generates CDKTN code for importing a PostgresEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresEndpoint to import
    * @param importFromId The id of the existing PostgresEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/postgres_endpoint databricks_postgres_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresEndpointConfig
    */
    constructor(scope: Construct, id: string, config: PostgresEndpointConfig);
    get createTime(): string;
    private _endpointId?;
    get endpointId(): string;
    set endpointId(value: string);
    get endpointIdInput(): string | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresEndpointProviderConfigOutputReference;
    putProviderConfig(value: PostgresEndpointProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresEndpointProviderConfig | undefined;
    private _replaceExisting?;
    get replaceExisting(): boolean | cdktn.IResolvable;
    set replaceExisting(value: boolean | cdktn.IResolvable);
    resetReplaceExisting(): void;
    get replaceExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _spec;
    get spec(): PostgresEndpointSpecOutputReference;
    putSpec(value: PostgresEndpointSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresEndpointSpec | undefined;
    private _status;
    get status(): PostgresEndpointStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
