/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain#name DataDatabricksDomain#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain#provider_config DataDatabricksDomain#provider_config}
    */
    readonly providerConfig?: DataDatabricksDomainProviderConfig;
}
export interface DataDatabricksDomainIcon {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain#color DataDatabricksDomain#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain#name DataDatabricksDomain#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksDomainIconToTerraform(struct?: DataDatabricksDomainIcon): any;
export declare function dataDatabricksDomainIconToHclTerraform(struct?: DataDatabricksDomainIcon): any;
export declare class DataDatabricksDomainIconOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDomainIcon | undefined;
    set internalValue(value: DataDatabricksDomainIcon | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DataDatabricksDomainProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain#workspace_id DataDatabricksDomain#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDomainProviderConfigToTerraform(struct?: DataDatabricksDomainProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDomainProviderConfigToHclTerraform(struct?: DataDatabricksDomainProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDomainProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDomainProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDomainProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain databricks_domain}
*/
export declare class DataDatabricksDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_domain";
    /**
    * Generates CDKTN code for importing a DataDatabricksDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDomain to import
    * @param importFromId The id of the existing DataDatabricksDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/data-sources/domain databricks_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDomainConfig);
    get businessOwnerIds(): number[];
    get createTime(): string;
    get description(): string;
    get domainId(): string;
    get draft(): cdktn.IResolvable;
    get effectiveDraft(): cdktn.IResolvable;
    private _icon;
    get icon(): DataDatabricksDomainIconOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentDomainId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksDomainProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDomainProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDomainProviderConfig | undefined;
    get subtitle(): string;
    get tagKey(): string;
    get technicalOwnerIds(): number[];
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
