/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceIamGroupV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_group_v2#external_id WorkspaceIamGroupV2#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_group_v2#group_name WorkspaceIamGroupV2#group_name}
    */
    readonly groupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_group_v2#provider_config WorkspaceIamGroupV2#provider_config}
    */
    readonly providerConfig?: WorkspaceIamGroupV2ProviderConfig;
}
export interface WorkspaceIamGroupV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_group_v2#workspace_id WorkspaceIamGroupV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceIamGroupV2ProviderConfigToTerraform(struct?: WorkspaceIamGroupV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceIamGroupV2ProviderConfigToHclTerraform(struct?: WorkspaceIamGroupV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceIamGroupV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceIamGroupV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceIamGroupV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_group_v2 databricks_workspace_iam_group_v2}
*/
export declare class WorkspaceIamGroupV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_iam_group_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceIamGroupV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceIamGroupV2 to import
    * @param importFromId The id of the existing WorkspaceIamGroupV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_group_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceIamGroupV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.134.0/docs/resources/workspace_iam_group_v2 databricks_workspace_iam_group_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceIamGroupV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: WorkspaceIamGroupV2Config);
    get accountId(): string;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    get groupId(): string;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): WorkspaceIamGroupV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceIamGroupV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceIamGroupV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
