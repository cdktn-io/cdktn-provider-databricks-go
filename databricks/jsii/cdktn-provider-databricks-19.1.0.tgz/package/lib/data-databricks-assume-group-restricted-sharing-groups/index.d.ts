/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAssumeGroupRestrictedSharingGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups#page_size DataDatabricksAssumeGroupRestrictedSharingGroups#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups#provider_config DataDatabricksAssumeGroupRestrictedSharingGroups#provider_config}
    */
    readonly providerConfig?: DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig;
}
export interface DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups#workspace_id DataDatabricksAssumeGroupRestrictedSharingGroups#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfigToTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfigToHclTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups#workspace_id DataDatabricksAssumeGroupRestrictedSharingGroups#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfigToTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfigToHclTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups#name DataDatabricksAssumeGroupRestrictedSharingGroups#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups#provider_config DataDatabricksAssumeGroupRestrictedSharingGroups#provider_config}
    */
    readonly providerConfig?: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig;
}
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsToTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroups): any;
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsToHclTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroups): any;
export declare class DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroups | undefined;
    set internalValue(value: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroups | undefined);
    get groupDisplayName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsProviderConfig | undefined;
    get restrictedSharingGroupId(): string;
}
export declare class DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups databricks_assume_group_restricted_sharing_groups}
*/
export declare class DataDatabricksAssumeGroupRestrictedSharingGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_assume_group_restricted_sharing_groups";
    /**
    * Generates CDKTN code for importing a DataDatabricksAssumeGroupRestrictedSharingGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAssumeGroupRestrictedSharingGroups to import
    * @param importFromId The id of the existing DataDatabricksAssumeGroupRestrictedSharingGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAssumeGroupRestrictedSharingGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/assume_group_restricted_sharing_groups databricks_assume_group_restricted_sharing_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAssumeGroupRestrictedSharingGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAssumeGroupRestrictedSharingGroupsConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAssumeGroupRestrictedSharingGroupsProviderConfig | undefined;
    private _restrictedSharingGroups;
    get restrictedSharingGroups(): DataDatabricksAssumeGroupRestrictedSharingGroupsRestrictedSharingGroupsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
