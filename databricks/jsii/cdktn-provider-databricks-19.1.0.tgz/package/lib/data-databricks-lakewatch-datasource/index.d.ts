/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchDatasourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#name DataDatabricksLakewatchDatasource#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#provider_config DataDatabricksLakewatchDatasource#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchDatasourceProviderConfig;
}
export interface DataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#catalog_name DataDatabricksLakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#schema_name DataDatabricksLakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#table_name DataDatabricksLakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTableToTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTable): any;
export declare function dataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTable): any;
export declare class DataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#header_retention DataDatabricksLakewatchDatasource#header_retention}
    */
    readonly headerRetention?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsToTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsToHclTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable | undefined);
    private _headerRetention?;
    get headerRetention(): boolean | cdktn.IResolvable;
    set headerRetention(value: boolean | cdktn.IResolvable);
    resetHeaderRetention(): void;
    get headerRetentionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#path DataDatabricksLakewatchDatasource#path}
    */
    readonly path: string;
}
export declare function dataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArrayToTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArrayToHclTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArrayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceAutoloaderEnvelope {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#cloud_watch_logs DataDatabricksLakewatchDatasource#cloud_watch_logs}
    */
    readonly cloudWatchLogs?: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#json_array DataDatabricksLakewatchDatasource#json_array}
    */
    readonly jsonArray?: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray;
}
export declare function dataDatabricksLakewatchDatasourceAutoloaderEnvelopeToTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourceAutoloaderEnvelopeToHclTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourceAutoloaderEnvelopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable | undefined);
    private _cloudWatchLogs;
    get cloudWatchLogs(): DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsOutputReference;
    putCloudWatchLogs(value: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs): void;
    resetCloudWatchLogs(): void;
    get cloudWatchLogsInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | undefined;
    private _jsonArray;
    get jsonArray(): DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArrayOutputReference;
    putJsonArray(value: DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray): void;
    resetJsonArray(): void;
    get jsonArrayInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourceAutoloaderEnvelopeJsonArray | undefined;
}
export interface DataDatabricksLakewatchDatasourceAutoloaderRawTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#catalog_name DataDatabricksLakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#schema_name DataDatabricksLakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#table_name DataDatabricksLakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourceAutoloaderRawTableToTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderRawTable): any;
export declare function dataDatabricksLakewatchDatasourceAutoloaderRawTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloaderRawTable): any;
export declare class DataDatabricksLakewatchDatasourceAutoloaderRawTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceAutoloaderRawTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceAutoloaderRawTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceAutoloader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#aws_secret_scope DataDatabricksLakewatchDatasource#aws_secret_scope}
    */
    readonly awsSecretScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#envelope DataDatabricksLakewatchDatasource#envelope}
    */
    readonly envelope?: DataDatabricksLakewatchDatasourceAutoloaderEnvelope;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#format DataDatabricksLakewatchDatasource#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#format_options DataDatabricksLakewatchDatasource#format_options}
    */
    readonly formatOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#include_existing_files DataDatabricksLakewatchDatasource#include_existing_files}
    */
    readonly includeExistingFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#location DataDatabricksLakewatchDatasource#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#override_partition_columns DataDatabricksLakewatchDatasource#override_partition_columns}
    */
    readonly overridePartitionColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#queue_url DataDatabricksLakewatchDatasource#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#raw_table DataDatabricksLakewatchDatasource#raw_table}
    */
    readonly rawTable: DataDatabricksLakewatchDatasourceAutoloaderRawTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#service_credentials DataDatabricksLakewatchDatasource#service_credentials}
    */
    readonly serviceCredentials?: string;
}
export declare function dataDatabricksLakewatchDatasourceAutoloaderToTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloader): any;
export declare function dataDatabricksLakewatchDatasourceAutoloaderToHclTerraform(struct?: DataDatabricksLakewatchDatasourceAutoloader): any;
export declare class DataDatabricksLakewatchDatasourceAutoloaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceAutoloader | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceAutoloader | undefined);
    private _awsSecretScope?;
    get awsSecretScope(): string;
    set awsSecretScope(value: string);
    resetAwsSecretScope(): void;
    get awsSecretScopeInput(): string | undefined;
    get effectiveIncludeExistingFiles(): cdktn.IResolvable;
    private _effectiveRawTable;
    get effectiveRawTable(): DataDatabricksLakewatchDatasourceAutoloaderEffectiveRawTableOutputReference;
    private _envelope;
    get envelope(): DataDatabricksLakewatchDatasourceAutoloaderEnvelopeOutputReference;
    putEnvelope(value: DataDatabricksLakewatchDatasourceAutoloaderEnvelope): void;
    resetEnvelope(): void;
    get envelopeInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourceAutoloaderEnvelope | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _formatOptions?;
    get formatOptions(): {
        [key: string]: string;
    };
    set formatOptions(value: {
        [key: string]: string;
    });
    resetFormatOptions(): void;
    get formatOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _includeExistingFiles?;
    get includeExistingFiles(): boolean | cdktn.IResolvable;
    set includeExistingFiles(value: boolean | cdktn.IResolvable);
    resetIncludeExistingFiles(): void;
    get includeExistingFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _overridePartitionColumns?;
    get overridePartitionColumns(): string[];
    set overridePartitionColumns(value: string[]);
    resetOverridePartitionColumns(): void;
    get overridePartitionColumnsInput(): string[] | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _rawTable;
    get rawTable(): DataDatabricksLakewatchDatasourceAutoloaderRawTableOutputReference;
    putRawTable(value: DataDatabricksLakewatchDatasourceAutoloaderRawTable): void;
    get rawTableInput(): DataDatabricksLakewatchDatasourceAutoloaderRawTable | undefined;
    private _serviceCredentials?;
    get serviceCredentials(): string;
    set serviceCredentials(value: string);
    resetServiceCredentials(): void;
    get serviceCredentialsInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#display_name DataDatabricksLakewatchDatasource#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#email DataDatabricksLakewatchDatasource#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#id DataDatabricksLakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#principal_type DataDatabricksLakewatchDatasource#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchDatasourceCreatedByToTerraform(struct?: DataDatabricksLakewatchDatasourceCreatedBy): any;
export declare function dataDatabricksLakewatchDatasourceCreatedByToHclTerraform(struct?: DataDatabricksLakewatchDatasourceCreatedBy): any;
export declare class DataDatabricksLakewatchDatasourceCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceCreatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceExistingTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#catalog DataDatabricksLakewatchDatasource#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#include_existing_rows DataDatabricksLakewatchDatasource#include_existing_rows}
    */
    readonly includeExistingRows?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#name DataDatabricksLakewatchDatasource#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#schema DataDatabricksLakewatchDatasource#schema}
    */
    readonly schema?: string;
}
export declare function dataDatabricksLakewatchDatasourceExistingTableToTerraform(struct?: DataDatabricksLakewatchDatasourceExistingTable): any;
export declare function dataDatabricksLakewatchDatasourceExistingTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourceExistingTable): any;
export declare class DataDatabricksLakewatchDatasourceExistingTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceExistingTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceExistingTable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    get effectiveCatalog(): string;
    get effectiveName(): string;
    get effectiveSchema(): string;
    private _includeExistingRows?;
    get includeExistingRows(): boolean | cdktn.IResolvable;
    set includeExistingRows(value: boolean | cdktn.IResolvable);
    resetIncludeExistingRows(): void;
    get includeExistingRowsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceOwner {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#display_name DataDatabricksLakewatchDatasource#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#email DataDatabricksLakewatchDatasource#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#id DataDatabricksLakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#principal_type DataDatabricksLakewatchDatasource#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchDatasourceOwnerToTerraform(struct?: DataDatabricksLakewatchDatasourceOwner): any;
export declare function dataDatabricksLakewatchDatasourceOwnerToHclTerraform(struct?: DataDatabricksLakewatchDatasourceOwner): any;
export declare class DataDatabricksLakewatchDatasourceOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceOwner | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceOwner | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceParsersEffectiveTargetTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#catalog_name DataDatabricksLakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#schema_name DataDatabricksLakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#table_name DataDatabricksLakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourceParsersEffectiveTargetTableToTerraform(struct?: DataDatabricksLakewatchDatasourceParsersEffectiveTargetTable): any;
export declare function dataDatabricksLakewatchDatasourceParsersEffectiveTargetTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourceParsersEffectiveTargetTable): any;
export declare class DataDatabricksLakewatchDatasourceParsersEffectiveTargetTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceParsersEffectiveTargetTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceParsersEffectiveTargetTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceParsersTargetTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#catalog_name DataDatabricksLakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#schema_name DataDatabricksLakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#table_name DataDatabricksLakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourceParsersTargetTableToTerraform(struct?: DataDatabricksLakewatchDatasourceParsersTargetTable | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourceParsersTargetTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourceParsersTargetTable | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourceParsersTargetTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceParsersTargetTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceParsersTargetTable | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceParsers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#id DataDatabricksLakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#target_table DataDatabricksLakewatchDatasource#target_table}
    */
    readonly targetTable?: DataDatabricksLakewatchDatasourceParsersTargetTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#version DataDatabricksLakewatchDatasource#version}
    */
    readonly version: string;
}
export declare function dataDatabricksLakewatchDatasourceParsersToTerraform(struct?: DataDatabricksLakewatchDatasourceParsers): any;
export declare function dataDatabricksLakewatchDatasourceParsersToHclTerraform(struct?: DataDatabricksLakewatchDatasourceParsers): any;
export declare class DataDatabricksLakewatchDatasourceParsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchDatasourceParsers | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceParsers | undefined);
    private _effectiveTargetTable;
    get effectiveTargetTable(): DataDatabricksLakewatchDatasourceParsersEffectiveTargetTableOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _targetTable;
    get targetTable(): DataDatabricksLakewatchDatasourceParsersTargetTableOutputReference;
    putTargetTable(value: DataDatabricksLakewatchDatasourceParsersTargetTable): void;
    resetTargetTable(): void;
    get targetTableInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourceParsersTargetTable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export declare class DataDatabricksLakewatchDatasourceParsersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchDatasourceParsers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchDatasourceParsersOutputReference;
}
export interface DataDatabricksLakewatchDatasourceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#workspace_id DataDatabricksLakewatchDatasource#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchDatasourceProviderConfigToTerraform(struct?: DataDatabricksLakewatchDatasourceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourceProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchDatasourceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#at_least_every DataDatabricksLakewatchDatasource#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#compute_group DataDatabricksLakewatchDatasource#compute_group}
    */
    readonly computeGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#continuous DataDatabricksLakewatchDatasource#continuous}
    */
    readonly continuous?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#cron_expression DataDatabricksLakewatchDatasource#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#enabled DataDatabricksLakewatchDatasource#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksLakewatchDatasourceScheduleToTerraform(struct?: DataDatabricksLakewatchDatasourceSchedule): any;
export declare function dataDatabricksLakewatchDatasourceScheduleToHclTerraform(struct?: DataDatabricksLakewatchDatasourceSchedule): any;
export declare class DataDatabricksLakewatchDatasourceScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceSchedule | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceSchedule | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _computeGroup?;
    get computeGroup(): string;
    set computeGroup(value: string);
    resetComputeGroup(): void;
    get computeGroupInput(): string | undefined;
    private _continuous?;
    get continuous(): boolean | cdktn.IResolvable;
    set continuous(value: boolean | cdktn.IResolvable);
    resetContinuous(): void;
    get continuousInput(): boolean | cdktn.IResolvable | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksLakewatchDatasourceStatusIngestionJob {
}
export declare function dataDatabricksLakewatchDatasourceStatusIngestionJobToTerraform(struct?: DataDatabricksLakewatchDatasourceStatusIngestionJob): any;
export declare function dataDatabricksLakewatchDatasourceStatusIngestionJobToHclTerraform(struct?: DataDatabricksLakewatchDatasourceStatusIngestionJob): any;
export declare class DataDatabricksLakewatchDatasourceStatusIngestionJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceStatusIngestionJob | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceStatusIngestionJob | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface DataDatabricksLakewatchDatasourceStatusIngestionPipeline {
}
export declare function dataDatabricksLakewatchDatasourceStatusIngestionPipelineToTerraform(struct?: DataDatabricksLakewatchDatasourceStatusIngestionPipeline): any;
export declare function dataDatabricksLakewatchDatasourceStatusIngestionPipelineToHclTerraform(struct?: DataDatabricksLakewatchDatasourceStatusIngestionPipeline): any;
export declare class DataDatabricksLakewatchDatasourceStatusIngestionPipelineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceStatusIngestionPipeline | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceStatusIngestionPipeline | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface DataDatabricksLakewatchDatasourceStatus {
}
export declare function dataDatabricksLakewatchDatasourceStatusToTerraform(struct?: DataDatabricksLakewatchDatasourceStatus): any;
export declare function dataDatabricksLakewatchDatasourceStatusToHclTerraform(struct?: DataDatabricksLakewatchDatasourceStatus): any;
export declare class DataDatabricksLakewatchDatasourceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceStatus | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceStatus | undefined);
    private _ingestionJob;
    get ingestionJob(): DataDatabricksLakewatchDatasourceStatusIngestionJobOutputReference;
    private _ingestionPipeline;
    get ingestionPipeline(): DataDatabricksLakewatchDatasourceStatusIngestionPipelineOutputReference;
}
export interface DataDatabricksLakewatchDatasourceUnityCatalogConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#configuration DataDatabricksLakewatchDatasource#configuration}
    */
    readonly configuration?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#connection_name DataDatabricksLakewatchDatasource#connection_name}
    */
    readonly connectionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#start_time DataDatabricksLakewatchDatasource#start_time}
    */
    readonly startTime?: string;
}
export declare function dataDatabricksLakewatchDatasourceUnityCatalogConnectionToTerraform(struct?: DataDatabricksLakewatchDatasourceUnityCatalogConnection): any;
export declare function dataDatabricksLakewatchDatasourceUnityCatalogConnectionToHclTerraform(struct?: DataDatabricksLakewatchDatasourceUnityCatalogConnection): any;
export declare class DataDatabricksLakewatchDatasourceUnityCatalogConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceUnityCatalogConnection | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceUnityCatalogConnection | undefined);
    private _configuration?;
    get configuration(): {
        [key: string]: string;
    };
    set configuration(value: {
        [key: string]: string;
    });
    resetConfiguration(): void;
    get configurationInput(): {
        [key: string]: string;
    } | undefined;
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    get connectionNameInput(): string | undefined;
    get connector(): string;
    get effectiveStartTime(): string;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourceUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#display_name DataDatabricksLakewatchDatasource#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#email DataDatabricksLakewatchDatasource#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#id DataDatabricksLakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#principal_type DataDatabricksLakewatchDatasource#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchDatasourceUpdatedByToTerraform(struct?: DataDatabricksLakewatchDatasourceUpdatedBy): any;
export declare function dataDatabricksLakewatchDatasourceUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchDatasourceUpdatedBy): any;
export declare class DataDatabricksLakewatchDatasourceUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourceUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourceUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource databricks_lakewatch_datasource}
*/
export declare class DataDatabricksLakewatchDatasource extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_datasource";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchDatasource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchDatasource to import
    * @param importFromId The id of the existing DataDatabricksLakewatchDatasource that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchDatasource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/lakewatch_datasource databricks_lakewatch_datasource} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchDatasourceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchDatasourceConfig);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _autoloader;
    get autoloader(): DataDatabricksLakewatchDatasourceAutoloaderOutputReference;
    get catalogName(): string;
    get computeMode(): string;
    get computeWorkspaceId(): string;
    get createTime(): string;
    private _createdBy;
    get createdBy(): DataDatabricksLakewatchDatasourceCreatedByOutputReference;
    get datasourceId(): string;
    get datasourceName(): string;
    get description(): string;
    get effectiveCatalogName(): string;
    get effectiveDatasourceName(): string;
    get effectiveRunAsPrincipal(): string;
    get effectiveSchemaName(): string;
    get etag(): string;
    private _existingTable;
    get existingTable(): DataDatabricksLakewatchDatasourceExistingTableOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner;
    get owner(): DataDatabricksLakewatchDatasourceOwnerOutputReference;
    private _parsers;
    get parsers(): DataDatabricksLakewatchDatasourceParsersList;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchDatasourceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchDatasourceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourceProviderConfig | undefined;
    get runAsPrincipal(): string;
    private _schedule;
    get schedule(): DataDatabricksLakewatchDatasourceScheduleOutputReference;
    get schemaName(): string;
    private _status;
    get status(): DataDatabricksLakewatchDatasourceStatusOutputReference;
    private _unityCatalogConnection;
    get unityCatalogConnection(): DataDatabricksLakewatchDatasourceUnityCatalogConnectionOutputReference;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchDatasourceUpdatedByOutputReference;
    get version(): number;
    get warehouseId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
