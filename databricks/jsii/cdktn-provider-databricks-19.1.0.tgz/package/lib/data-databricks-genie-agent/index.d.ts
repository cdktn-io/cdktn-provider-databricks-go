/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksGenieAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#name DataDatabricksGenieAgent#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#provider_config DataDatabricksGenieAgent#provider_config}
    */
    readonly providerConfig?: DataDatabricksGenieAgentProviderConfig;
}
export interface DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#content DataDatabricksGenieAgent#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#format DataDatabricksGenieAgent#format}
    */
    readonly format: string;
}
export declare function dataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswerToTerraform(struct?: DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswerToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswerList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswerOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionBenchmarksQuestions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#answer DataDatabricksGenieAgent#answer}
    */
    readonly answer?: DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#evaluation_note DataDatabricksGenieAgent#evaluation_note}
    */
    readonly evaluationNote?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#question DataDatabricksGenieAgent#question}
    */
    readonly question: string;
}
export declare function dataDatabricksGenieAgentDefinitionBenchmarksQuestionsToTerraform(struct?: DataDatabricksGenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionBenchmarksQuestionsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionBenchmarksQuestionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable | undefined);
    private _answer;
    get answer(): DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswerList;
    putAnswer(value: DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable): void;
    resetAnswer(): void;
    get answerInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionBenchmarksQuestionsAnswer[] | undefined;
    private _evaluationNote?;
    get evaluationNote(): string;
    set evaluationNote(value: string);
    resetEvaluationNote(): void;
    get evaluationNoteInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionBenchmarksQuestionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionBenchmarksQuestions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionBenchmarksQuestionsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionBenchmarks {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#questions DataDatabricksGenieAgent#questions}
    */
    readonly questions?: DataDatabricksGenieAgentDefinitionBenchmarksQuestions[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentDefinitionBenchmarksToTerraform(struct?: DataDatabricksGenieAgentDefinitionBenchmarks | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionBenchmarksToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionBenchmarks | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionBenchmarksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionBenchmarks | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionBenchmarks | cdktn.IResolvable | undefined);
    private _questions;
    get questions(): DataDatabricksGenieAgentDefinitionBenchmarksQuestionsList;
    putQuestions(value: DataDatabricksGenieAgentDefinitionBenchmarksQuestions[] | cdktn.IResolvable): void;
    resetQuestions(): void;
    get questionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionBenchmarksQuestions[] | undefined;
}
export interface DataDatabricksGenieAgentDefinitionConfigSampleQuestions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#question DataDatabricksGenieAgent#question}
    */
    readonly question: string;
}
export declare function dataDatabricksGenieAgentDefinitionConfigSampleQuestionsToTerraform(struct?: DataDatabricksGenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionConfigSampleQuestionsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionConfigSampleQuestionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionConfigSampleQuestionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionConfigSampleQuestions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionConfigSampleQuestionsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sample_questions DataDatabricksGenieAgent#sample_questions}
    */
    readonly sampleQuestions?: DataDatabricksGenieAgentDefinitionConfigSampleQuestions[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentDefinitionConfigToTerraform(struct?: DataDatabricksGenieAgentDefinitionConfig | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionConfigToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionConfig | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionConfig | cdktn.IResolvable | undefined);
    private _sampleQuestions;
    get sampleQuestions(): DataDatabricksGenieAgentDefinitionConfigSampleQuestionsList;
    putSampleQuestions(value: DataDatabricksGenieAgentDefinitionConfigSampleQuestions[] | cdktn.IResolvable): void;
    resetSampleQuestions(): void;
    get sampleQuestionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionConfigSampleQuestions[] | undefined;
}
export interface DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#mcp_connection DataDatabricksGenieAgent#mcp_connection}
    */
    readonly mcpConnection: string;
}
export declare function dataDatabricksGenieAgentDefinitionDataSourcesMcpConnectionsToTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionDataSourcesMcpConnectionsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionDataSourcesMcpConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable | undefined);
    private _mcpConnection?;
    get mcpConnection(): string;
    set mcpConnection(value: string);
    get mcpConnectionInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionDataSourcesMcpConnectionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionDataSourcesMcpConnectionsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#column DataDatabricksGenieAgent#column}
    */
    readonly column: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#description DataDatabricksGenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#display_name DataDatabricksGenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#enable_entity_matching DataDatabricksGenieAgent#enable_entity_matching}
    */
    readonly enableEntityMatching?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#enable_format_assistance DataDatabricksGenieAgent#enable_format_assistance}
    */
    readonly enableFormatAssistance?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#exclude DataDatabricksGenieAgent#exclude}
    */
    readonly exclude?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#synonyms DataDatabricksGenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigsToTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enableEntityMatching?;
    get enableEntityMatching(): boolean | cdktn.IResolvable;
    set enableEntityMatching(value: boolean | cdktn.IResolvable);
    resetEnableEntityMatching(): void;
    get enableEntityMatchingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableFormatAssistance?;
    get enableFormatAssistance(): boolean | cdktn.IResolvable;
    set enableFormatAssistance(value: boolean | cdktn.IResolvable);
    resetEnableFormatAssistance(): void;
    get enableFormatAssistanceInput(): boolean | cdktn.IResolvable | undefined;
    private _exclude?;
    get exclude(): boolean | cdktn.IResolvable;
    set exclude(value: boolean | cdktn.IResolvable);
    resetExclude(): void;
    get excludeInput(): boolean | cdktn.IResolvable | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionDataSourcesTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#column_configs DataDatabricksGenieAgent#column_configs}
    */
    readonly columnConfigs?: DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#description DataDatabricksGenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#identifier DataDatabricksGenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentDefinitionDataSourcesTablesToTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesTables | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionDataSourcesTablesToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesTables | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionDataSourcesTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionDataSourcesTables | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionDataSourcesTables | cdktn.IResolvable | undefined);
    private _columnConfigs;
    get columnConfigs(): DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigsList;
    putColumnConfigs(value: DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable): void;
    resetColumnConfigs(): void;
    get columnConfigsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionDataSourcesTablesColumnConfigs[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionDataSourcesTablesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionDataSourcesTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionDataSourcesTablesOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionDataSourcesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#description DataDatabricksGenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#path DataDatabricksGenieAgent#path}
    */
    readonly path: string;
}
export declare function dataDatabricksGenieAgentDefinitionDataSourcesVolumesToTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionDataSourcesVolumesToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionDataSourcesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionDataSourcesVolumesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionDataSourcesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionDataSourcesVolumesOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionDataSources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#mcp_connections DataDatabricksGenieAgent#mcp_connections}
    */
    readonly mcpConnections?: DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#tables DataDatabricksGenieAgent#tables}
    */
    readonly tables?: DataDatabricksGenieAgentDefinitionDataSourcesTables[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#volumes DataDatabricksGenieAgent#volumes}
    */
    readonly volumes?: DataDatabricksGenieAgentDefinitionDataSourcesVolumes[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentDefinitionDataSourcesToTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSources | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionDataSourcesToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionDataSources | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionDataSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionDataSources | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionDataSources | cdktn.IResolvable | undefined);
    private _mcpConnections;
    get mcpConnections(): DataDatabricksGenieAgentDefinitionDataSourcesMcpConnectionsList;
    putMcpConnections(value: DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable): void;
    resetMcpConnections(): void;
    get mcpConnectionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionDataSourcesMcpConnections[] | undefined;
    private _tables;
    get tables(): DataDatabricksGenieAgentDefinitionDataSourcesTablesList;
    putTables(value: DataDatabricksGenieAgentDefinitionDataSourcesTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionDataSourcesTables[] | undefined;
    private _volumes;
    get volumes(): DataDatabricksGenieAgentDefinitionDataSourcesVolumesList;
    putVolumes(value: DataDatabricksGenieAgentDefinitionDataSourcesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionDataSourcesVolumes[] | undefined;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#max DataDatabricksGenieAgent#max}
    */
    readonly max?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#min DataDatabricksGenieAgent#min}
    */
    readonly min?: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable | undefined);
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#value_range DataDatabricksGenieAgent#value_range}
    */
    readonly valueRange?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#values DataDatabricksGenieAgent#values}
    */
    readonly values?: string[];
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable | undefined);
    private _valueRange;
    get valueRange(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeOutputReference;
    putValueRange(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange): void;
    resetValueRange(): void;
    get valueRangeInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#default_value DataDatabricksGenieAgent#default_value}
    */
    readonly defaultValue?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#description DataDatabricksGenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#name DataDatabricksGenieAgent#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#type_hint DataDatabricksGenieAgent#type_hint}
    */
    readonly typeHint?: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable | undefined);
    private _defaultValue;
    get defaultValue(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueOutputReference;
    putDefaultValue(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue): void;
    resetDefaultValue(): void;
    get defaultValueInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _typeHint?;
    get typeHint(): string;
    set typeHint(value: string);
    resetTypeHint(): void;
    get typeHintInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#parameters DataDatabricksGenieAgent#parameters}
    */
    readonly parameters?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#question DataDatabricksGenieAgent#question}
    */
    readonly question: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sql DataDatabricksGenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#usage_guidance DataDatabricksGenieAgent#usage_guidance}
    */
    readonly usageGuidance?: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _parameters;
    get parameters(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParametersList;
    putParameters(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _usageGuidance?;
    get usageGuidance(): string;
    set usageGuidance(value: string);
    resetUsageGuidance(): void;
    get usageGuidanceInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#alias DataDatabricksGenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#identifier DataDatabricksGenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeftToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeftToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#alias DataDatabricksGenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#identifier DataDatabricksGenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRightToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRightToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRightOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#comment DataDatabricksGenieAgent#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#instruction DataDatabricksGenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#left DataDatabricksGenieAgent#left}
    */
    readonly left: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#relationship_type DataDatabricksGenieAgent#relationship_type}
    */
    readonly relationshipType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#right DataDatabricksGenieAgent#right}
    */
    readonly right: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sql DataDatabricksGenieAgent#sql}
    */
    readonly sql: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsJoinSpecsToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsJoinSpecsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _left;
    get left(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeftOutputReference;
    putLeft(value: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft): void;
    get leftInput(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsLeft | undefined;
    private _relationshipType?;
    get relationshipType(): string;
    set relationshipType(value: string);
    resetRelationshipType(): void;
    get relationshipTypeInput(): string | undefined;
    private _right;
    get right(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRightOutputReference;
    putRight(value: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight): void;
    get rightInput(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsRight | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#identifier DataDatabricksGenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlFunctionsToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlFunctionsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlFunctionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsSqlFunctionsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#alias DataDatabricksGenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#display_name DataDatabricksGenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#instruction DataDatabricksGenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sql DataDatabricksGenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#synonyms DataDatabricksGenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressionsToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressionsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressionsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#display_name DataDatabricksGenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#instruction DataDatabricksGenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sql DataDatabricksGenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#synonyms DataDatabricksGenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFiltersToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFiltersToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFiltersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFiltersOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#alias DataDatabricksGenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#display_name DataDatabricksGenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#instruction DataDatabricksGenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sql DataDatabricksGenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#synonyms DataDatabricksGenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasuresToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasuresToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasuresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasuresList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasuresOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#expressions DataDatabricksGenieAgent#expressions}
    */
    readonly expressions?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#filters DataDatabricksGenieAgent#filters}
    */
    readonly filters?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#measures DataDatabricksGenieAgent#measures}
    */
    readonly measures?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable | undefined);
    private _expressions;
    get expressions(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressionsList;
    putExpressions(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable): void;
    resetExpressions(): void;
    get expressionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | undefined;
    private _filters;
    get filters(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFiltersList;
    putFilters(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsFilters[] | undefined;
    private _measures;
    get measures(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasuresList;
    putMeasures(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable): void;
    resetMeasures(): void;
    get measuresInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | undefined;
}
export interface DataDatabricksGenieAgentDefinitionInstructionsTextInstructions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#content DataDatabricksGenieAgent#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#id DataDatabricksGenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsTextInstructionsToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsTextInstructionsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsTextInstructionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class DataDatabricksGenieAgentDefinitionInstructionsTextInstructionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksGenieAgentDefinitionInstructionsTextInstructions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksGenieAgentDefinitionInstructionsTextInstructionsOutputReference;
}
export interface DataDatabricksGenieAgentDefinitionInstructions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#example_question_sqls DataDatabricksGenieAgent#example_question_sqls}
    */
    readonly exampleQuestionSqls?: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#join_specs DataDatabricksGenieAgent#join_specs}
    */
    readonly joinSpecs?: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sql_functions DataDatabricksGenieAgent#sql_functions}
    */
    readonly sqlFunctions?: DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#sql_snippets DataDatabricksGenieAgent#sql_snippets}
    */
    readonly sqlSnippets?: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#text_instructions DataDatabricksGenieAgent#text_instructions}
    */
    readonly textInstructions?: DataDatabricksGenieAgentDefinitionInstructionsTextInstructions[] | cdktn.IResolvable;
}
export declare function dataDatabricksGenieAgentDefinitionInstructionsToTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructions | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentDefinitionInstructionsToHclTerraform(struct?: DataDatabricksGenieAgentDefinitionInstructions | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentDefinitionInstructionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinitionInstructions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinitionInstructions | cdktn.IResolvable | undefined);
    private _exampleQuestionSqls;
    get exampleQuestionSqls(): DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqlsList;
    putExampleQuestionSqls(value: DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable): void;
    resetExampleQuestionSqls(): void;
    get exampleQuestionSqlsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsExampleQuestionSqls[] | undefined;
    private _joinSpecs;
    get joinSpecs(): DataDatabricksGenieAgentDefinitionInstructionsJoinSpecsList;
    putJoinSpecs(value: DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable): void;
    resetJoinSpecs(): void;
    get joinSpecsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsJoinSpecs[] | undefined;
    private _sqlFunctions;
    get sqlFunctions(): DataDatabricksGenieAgentDefinitionInstructionsSqlFunctionsList;
    putSqlFunctions(value: DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable): void;
    resetSqlFunctions(): void;
    get sqlFunctionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsSqlFunctions[] | undefined;
    private _sqlSnippets;
    get sqlSnippets(): DataDatabricksGenieAgentDefinitionInstructionsSqlSnippetsOutputReference;
    putSqlSnippets(value: DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets): void;
    resetSqlSnippets(): void;
    get sqlSnippetsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsSqlSnippets | undefined;
    private _textInstructions;
    get textInstructions(): DataDatabricksGenieAgentDefinitionInstructionsTextInstructionsList;
    putTextInstructions(value: DataDatabricksGenieAgentDefinitionInstructionsTextInstructions[] | cdktn.IResolvable): void;
    resetTextInstructions(): void;
    get textInstructionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructionsTextInstructions[] | undefined;
}
export interface DataDatabricksGenieAgentDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#benchmarks DataDatabricksGenieAgent#benchmarks}
    */
    readonly benchmarks?: DataDatabricksGenieAgentDefinitionBenchmarks;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#config DataDatabricksGenieAgent#config}
    */
    readonly config?: DataDatabricksGenieAgentDefinitionConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#data_sources DataDatabricksGenieAgent#data_sources}
    */
    readonly dataSources?: DataDatabricksGenieAgentDefinitionDataSources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#instructions DataDatabricksGenieAgent#instructions}
    */
    readonly instructions?: DataDatabricksGenieAgentDefinitionInstructions;
}
export declare function dataDatabricksGenieAgentDefinitionToTerraform(struct?: DataDatabricksGenieAgentDefinition): any;
export declare function dataDatabricksGenieAgentDefinitionToHclTerraform(struct?: DataDatabricksGenieAgentDefinition): any;
export declare class DataDatabricksGenieAgentDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentDefinition | undefined;
    set internalValue(value: DataDatabricksGenieAgentDefinition | undefined);
    private _benchmarks;
    get benchmarks(): DataDatabricksGenieAgentDefinitionBenchmarksOutputReference;
    putBenchmarks(value: DataDatabricksGenieAgentDefinitionBenchmarks): void;
    resetBenchmarks(): void;
    get benchmarksInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionBenchmarks | undefined;
    private _config;
    get config(): DataDatabricksGenieAgentDefinitionConfigOutputReference;
    putConfig(value: DataDatabricksGenieAgentDefinitionConfig): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionConfig | undefined;
    private _dataSources;
    get dataSources(): DataDatabricksGenieAgentDefinitionDataSourcesOutputReference;
    putDataSources(value: DataDatabricksGenieAgentDefinitionDataSources): void;
    resetDataSources(): void;
    get dataSourcesInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionDataSources | undefined;
    private _instructions;
    get instructions(): DataDatabricksGenieAgentDefinitionInstructionsOutputReference;
    putInstructions(value: DataDatabricksGenieAgentDefinitionInstructions): void;
    resetInstructions(): void;
    get instructionsInput(): cdktn.IResolvable | DataDatabricksGenieAgentDefinitionInstructions | undefined;
}
export interface DataDatabricksGenieAgentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#workspace_id DataDatabricksGenieAgent#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksGenieAgentProviderConfigToTerraform(struct?: DataDatabricksGenieAgentProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksGenieAgentProviderConfigToHclTerraform(struct?: DataDatabricksGenieAgentProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksGenieAgentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGenieAgentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksGenieAgentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent databricks_genie_agent}
*/
export declare class DataDatabricksGenieAgent extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_genie_agent";
    /**
    * Generates CDKTN code for importing a DataDatabricksGenieAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksGenieAgent to import
    * @param importFromId The id of the existing DataDatabricksGenieAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksGenieAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.143.0/docs/data-sources/genie_agent databricks_genie_agent} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksGenieAgentConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksGenieAgentConfig);
    get createTime(): string;
    private _definition;
    get definition(): DataDatabricksGenieAgentDefinitionOutputReference;
    get description(): string;
    get displayName(): string;
    get effectiveParentPath(): string;
    get etag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentPath(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksGenieAgentProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksGenieAgentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksGenieAgentProviderConfig | undefined;
    get updateTime(): string;
    get warehouseId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
