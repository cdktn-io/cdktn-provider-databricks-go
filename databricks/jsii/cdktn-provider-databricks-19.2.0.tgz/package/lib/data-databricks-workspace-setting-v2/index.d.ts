/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#name DataDatabricksWorkspaceSettingV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#provider_config DataDatabricksWorkspaceSettingV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceSettingV2ProviderConfig;
}
export interface DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#access_policy_type DataDatabricksWorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#approved_domains DataDatabricksWorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#allowed_scopes DataDatabricksWorkspaceSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes): any;
export declare function dataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes): any;
export declare class DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#forced_for_compliance_mode DataDatabricksWorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#unavailable_for_disabled_entitlement DataDatabricksWorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksWorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#hours DataDatabricksWorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#minutes DataDatabricksWorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#day_of_week DataDatabricksWorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#frequency DataDatabricksWorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#window_start_time DataDatabricksWorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#week_day_based_schedule DataDatabricksWorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#can_toggle DataDatabricksWorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#enabled DataDatabricksWorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#enablement_details DataDatabricksWorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#maintenance_window DataDatabricksWorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#restart_even_if_no_updates_available DataDatabricksWorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2BooleanValToTerraform(struct?: DataDatabricksWorkspaceSettingV2BooleanVal): any;
export declare function dataDatabricksWorkspaceSettingV2BooleanValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2BooleanVal): any;
export declare class DataDatabricksWorkspaceSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2BooleanVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2BooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#connectivity DataDatabricksWorkspaceSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity): any;
export declare function dataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity): any;
export declare class DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#access_policy_type DataDatabricksWorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#approved_domains DataDatabricksWorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#allowed_scopes DataDatabricksWorkspaceSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#forced_for_compliance_mode DataDatabricksWorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#unavailable_for_disabled_entitlement DataDatabricksWorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksWorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#hours DataDatabricksWorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#minutes DataDatabricksWorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#day_of_week DataDatabricksWorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#frequency DataDatabricksWorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#window_start_time DataDatabricksWorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#week_day_based_schedule DataDatabricksWorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#can_toggle DataDatabricksWorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#enabled DataDatabricksWorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#enablement_details DataDatabricksWorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#maintenance_window DataDatabricksWorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#restart_even_if_no_updates_available DataDatabricksWorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveBooleanValToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveBooleanVal): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveBooleanValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveBooleanVal): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#connectivity DataDatabricksWorkspaceSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveIntegerValToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveIntegerVal): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveIntegerValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveIntegerVal): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#email DataDatabricksWorkspaceSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectivePersonalComputeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectivePersonalCompute): any;
export declare function dataDatabricksWorkspaceSettingV2EffectivePersonalComputeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectivePersonalCompute): any;
export declare class DataDatabricksWorkspaceSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectivePersonalCompute | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectivePersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#disable_gov_tag_creation DataDatabricksWorkspaceSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#status DataDatabricksWorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveStringValToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveStringVal): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveStringValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveStringVal): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveStringVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#mid DataDatabricksWorkspaceSettingV2#mid}
    */
    readonly mid?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color DataDatabricksWorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color_scheme DataDatabricksWorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_diverging DataDatabricksWorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_sequential DataDatabricksWorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#from_categorical_index DataDatabricksWorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#mid DataDatabricksWorkspaceSettingV2#mid}
    */
    readonly mid?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color DataDatabricksWorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color_scheme DataDatabricksWorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_diverging DataDatabricksWorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_sequential DataDatabricksWorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#from_categorical_index DataDatabricksWorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark_mode DataDatabricksWorkspaceSettingV2#dark_mode}
    */
    readonly darkMode?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light_mode DataDatabricksWorkspaceSettingV2#light_mode}
    */
    readonly lightMode?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#base DataDatabricksWorkspaceSettingV2#base}
    */
    readonly base?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#field_title DataDatabricksWorkspaceSettingV2#field_title}
    */
    readonly fieldTitle?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#field_value DataDatabricksWorkspaceSettingV2#field_value}
    */
    readonly fieldValue?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_description DataDatabricksWorkspaceSettingV2#widget_description}
    */
    readonly widgetDescription?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_title DataDatabricksWorkspaceSettingV2#widget_title}
    */
    readonly widgetTitle?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#negative DataDatabricksWorkspaceSettingV2#negative}
    */
    readonly negative?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#neutral DataDatabricksWorkspaceSettingV2#neutral}
    */
    readonly neutral?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#positive DataDatabricksWorkspaceSettingV2#positive}
    */
    readonly positive?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#axis_line_color DataDatabricksWorkspaceSettingV2#axis_line_color}
    */
    readonly axisLineColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#canvas_background_color DataDatabricksWorkspaceSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#continuous_gradient DataDatabricksWorkspaceSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_settings DataDatabricksWorkspaceSettingV2#font_settings}
    */
    readonly fontSettings?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#grid_line_color DataDatabricksWorkspaceSettingV2#grid_line_color}
    */
    readonly gridLineColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#mark_corner_radius DataDatabricksWorkspaceSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#selection_color DataDatabricksWorkspaceSettingV2#selection_color}
    */
    readonly selectionColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#sentiment_colors DataDatabricksWorkspaceSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_box_vertical_align DataDatabricksWorkspaceSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_01 DataDatabricksWorkspaceSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_02 DataDatabricksWorkspaceSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_03 DataDatabricksWorkspaceSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_04 DataDatabricksWorkspaceSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_05 DataDatabricksWorkspaceSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_06 DataDatabricksWorkspaceSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_07 DataDatabricksWorkspaceSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_08 DataDatabricksWorkspaceSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_09 DataDatabricksWorkspaceSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_10 DataDatabricksWorkspaceSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_11 DataDatabricksWorkspaceSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_12 DataDatabricksWorkspaceSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_13 DataDatabricksWorkspaceSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_14 DataDatabricksWorkspaceSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_15 DataDatabricksWorkspaceSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_16 DataDatabricksWorkspaceSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_17 DataDatabricksWorkspaceSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_18 DataDatabricksWorkspaceSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_19 DataDatabricksWorkspaceSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_20 DataDatabricksWorkspaceSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_background_color DataDatabricksWorkspaceSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_border_color DataDatabricksWorkspaceSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_corner_radius DataDatabricksWorkspaceSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_header_alignment DataDatabricksWorkspaceSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_margin DataDatabricksWorkspaceSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_padding DataDatabricksWorkspaceSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_shadow DataDatabricksWorkspaceSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardTheme | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardTheme | undefined);
    private _axisLineColor;
    get axisLineColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color DataDatabricksWorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#label DataDatabricksWorkspaceSettingV2#label}
    */
    readonly label?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabelToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabel): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabelToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabel): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabel | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabel | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksWorkspaceSettingV2IntegerValToTerraform(struct?: DataDatabricksWorkspaceSettingV2IntegerVal): any;
export declare function dataDatabricksWorkspaceSettingV2IntegerValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2IntegerVal): any;
export declare class DataDatabricksWorkspaceSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2IntegerVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2IntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#email DataDatabricksWorkspaceSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient): any;
export declare function dataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient): any;
export declare class DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2PersonalComputeToTerraform(struct?: DataDatabricksWorkspaceSettingV2PersonalCompute): any;
export declare function dataDatabricksWorkspaceSettingV2PersonalComputeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2PersonalCompute): any;
export declare class DataDatabricksWorkspaceSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2PersonalCompute | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2PersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#workspace_id DataDatabricksWorkspaceSettingV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceSettingV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#disable_gov_tag_creation DataDatabricksWorkspaceSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#status DataDatabricksWorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins): any;
export declare function dataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins): any;
export declare class DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2StringValToTerraform(struct?: DataDatabricksWorkspaceSettingV2StringVal): any;
export declare function dataDatabricksWorkspaceSettingV2StringValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2StringVal): any;
export declare class DataDatabricksWorkspaceSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2StringVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2StringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#mid DataDatabricksWorkspaceSettingV2#mid}
    */
    readonly mid?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color DataDatabricksWorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color_scheme DataDatabricksWorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_diverging DataDatabricksWorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_sequential DataDatabricksWorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#from_categorical_index DataDatabricksWorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#mid DataDatabricksWorkspaceSettingV2#mid}
    */
    readonly mid?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#end DataDatabricksWorkspaceSettingV2#end}
    */
    readonly end?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#start DataDatabricksWorkspaceSettingV2#start}
    */
    readonly start?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color DataDatabricksWorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color_scheme DataDatabricksWorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_diverging DataDatabricksWorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#custom_sequential DataDatabricksWorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#from_categorical_index DataDatabricksWorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark_mode DataDatabricksWorkspaceSettingV2#dark_mode}
    */
    readonly darkMode?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light_mode DataDatabricksWorkspaceSettingV2#light_mode}
    */
    readonly lightMode?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_size DataDatabricksWorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_style DataDatabricksWorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_weight DataDatabricksWorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_case DataDatabricksWorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_decoration DataDatabricksWorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#base DataDatabricksWorkspaceSettingV2#base}
    */
    readonly base?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#field_title DataDatabricksWorkspaceSettingV2#field_title}
    */
    readonly fieldTitle?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#field_value DataDatabricksWorkspaceSettingV2#field_value}
    */
    readonly fieldValue?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_description DataDatabricksWorkspaceSettingV2#widget_description}
    */
    readonly widgetDescription?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_title DataDatabricksWorkspaceSettingV2#widget_title}
    */
    readonly widgetTitle?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#negative DataDatabricksWorkspaceSettingV2#negative}
    */
    readonly negative?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#neutral DataDatabricksWorkspaceSettingV2#neutral}
    */
    readonly neutral?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#positive DataDatabricksWorkspaceSettingV2#positive}
    */
    readonly positive?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#dark DataDatabricksWorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#light DataDatabricksWorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#axis_line_color DataDatabricksWorkspaceSettingV2#axis_line_color}
    */
    readonly axisLineColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#canvas_background_color DataDatabricksWorkspaceSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#continuous_gradient DataDatabricksWorkspaceSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_color DataDatabricksWorkspaceSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_family DataDatabricksWorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#font_settings DataDatabricksWorkspaceSettingV2#font_settings}
    */
    readonly fontSettings?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#grid_line_color DataDatabricksWorkspaceSettingV2#grid_line_color}
    */
    readonly gridLineColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#mark_corner_radius DataDatabricksWorkspaceSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#selection_color DataDatabricksWorkspaceSettingV2#selection_color}
    */
    readonly selectionColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#sentiment_colors DataDatabricksWorkspaceSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#text_box_vertical_align DataDatabricksWorkspaceSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_01 DataDatabricksWorkspaceSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_02 DataDatabricksWorkspaceSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_03 DataDatabricksWorkspaceSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_04 DataDatabricksWorkspaceSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_05 DataDatabricksWorkspaceSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_06 DataDatabricksWorkspaceSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_07 DataDatabricksWorkspaceSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_08 DataDatabricksWorkspaceSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_09 DataDatabricksWorkspaceSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_10 DataDatabricksWorkspaceSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_11 DataDatabricksWorkspaceSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_12 DataDatabricksWorkspaceSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_13 DataDatabricksWorkspaceSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_14 DataDatabricksWorkspaceSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_15 DataDatabricksWorkspaceSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_16 DataDatabricksWorkspaceSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_17 DataDatabricksWorkspaceSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_18 DataDatabricksWorkspaceSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_19 DataDatabricksWorkspaceSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#visualization_color_20 DataDatabricksWorkspaceSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_background_color DataDatabricksWorkspaceSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_border_color DataDatabricksWorkspaceSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_corner_radius DataDatabricksWorkspaceSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_header_alignment DataDatabricksWorkspaceSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_margin DataDatabricksWorkspaceSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_padding DataDatabricksWorkspaceSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#widget_shadow DataDatabricksWorkspaceSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardTheme): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceDashboardTheme): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardTheme | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardTheme | undefined);
    private _axisLineColor;
    get axisLineColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2WorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#color DataDatabricksWorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#label DataDatabricksWorkspaceSettingV2#label}
    */
    readonly label?: string;
}
export declare function dataDatabricksWorkspaceSettingV2WorkspaceLabelToTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceLabel): any;
export declare function dataDatabricksWorkspaceSettingV2WorkspaceLabelToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2WorkspaceLabel): any;
export declare class DataDatabricksWorkspaceSettingV2WorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2WorkspaceLabel | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2WorkspaceLabel | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2 databricks_workspace_setting_v2}
*/
export declare class DataDatabricksWorkspaceSettingV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_setting_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceSettingV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/workspace_setting_v2 databricks_workspace_setting_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceSettingV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _allowedAppsUserApiScopes;
    get allowedAppsUserApiScopes(): DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesOutputReference;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    private _booleanVal;
    get booleanVal(): DataDatabricksWorkspaceSettingV2BooleanValOutputReference;
    private _collaborationPlatformConnectivity;
    get collaborationPlatformConnectivity(): DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityOutputReference;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _effectiveAllowedAppsUserApiScopes;
    get effectiveAllowedAppsUserApiScopes(): DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesOutputReference;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): DataDatabricksWorkspaceSettingV2EffectiveBooleanValOutputReference;
    private _effectiveCollaborationPlatformConnectivity;
    get effectiveCollaborationPlatformConnectivity(): DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): DataDatabricksWorkspaceSettingV2EffectiveIntegerValOutputReference;
    private _effectiveOperationalEmailCustomRecipient;
    get effectiveOperationalEmailCustomRecipient(): DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): DataDatabricksWorkspaceSettingV2EffectivePersonalComputeOutputReference;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    private _effectiveStringVal;
    get effectiveStringVal(): DataDatabricksWorkspaceSettingV2EffectiveStringValOutputReference;
    private _effectiveWorkspaceDashboardTheme;
    get effectiveWorkspaceDashboardTheme(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceDashboardThemeOutputReference;
    private _effectiveWorkspaceLabel;
    get effectiveWorkspaceLabel(): DataDatabricksWorkspaceSettingV2EffectiveWorkspaceLabelOutputReference;
    private _integerVal;
    get integerVal(): DataDatabricksWorkspaceSettingV2IntegerValOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationalEmailCustomRecipient;
    get operationalEmailCustomRecipient(): DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientOutputReference;
    private _personalCompute;
    get personalCompute(): DataDatabricksWorkspaceSettingV2PersonalComputeOutputReference;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceSettingV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceSettingV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2ProviderConfig | undefined;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsOutputReference;
    private _stringVal;
    get stringVal(): DataDatabricksWorkspaceSettingV2StringValOutputReference;
    private _workspaceDashboardTheme;
    get workspaceDashboardTheme(): DataDatabricksWorkspaceSettingV2WorkspaceDashboardThemeOutputReference;
    private _workspaceLabel;
    get workspaceLabel(): DataDatabricksWorkspaceSettingV2WorkspaceLabelOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
