/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchRuleConfigAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#name DataDatabricksLakewatchRuleConfigA#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#provider_config DataDatabricksLakewatchRuleConfigA#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchRuleConfigProviderConfig;
}
export interface DataDatabricksLakewatchRuleConfigDefaultSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#at_least_every DataDatabricksLakewatchRuleConfigA#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#cron_expression DataDatabricksLakewatchRuleConfigA#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#enabled DataDatabricksLakewatchRuleConfigA#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksLakewatchRuleConfigDefaultScheduleToTerraform(struct?: DataDatabricksLakewatchRuleConfigDefaultSchedule): any;
export declare function dataDatabricksLakewatchRuleConfigDefaultScheduleToHclTerraform(struct?: DataDatabricksLakewatchRuleConfigDefaultSchedule): any;
export declare class DataDatabricksLakewatchRuleConfigDefaultScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleConfigDefaultSchedule | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleConfigDefaultSchedule | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksLakewatchRuleConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#workspace_id DataDatabricksLakewatchRuleConfigA#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchRuleConfigProviderConfigToTerraform(struct?: DataDatabricksLakewatchRuleConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRuleConfigProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchRuleConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRuleConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchRuleConfigUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#display_name DataDatabricksLakewatchRuleConfigA#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#email DataDatabricksLakewatchRuleConfigA#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#id DataDatabricksLakewatchRuleConfigA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#principal_type DataDatabricksLakewatchRuleConfigA#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchRuleConfigUpdatedByToTerraform(struct?: DataDatabricksLakewatchRuleConfigUpdatedBy): any;
export declare function dataDatabricksLakewatchRuleConfigUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchRuleConfigUpdatedBy): any;
export declare class DataDatabricksLakewatchRuleConfigUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRuleConfigUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchRuleConfigUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config databricks_lakewatch_rule_config}
*/
export declare class DataDatabricksLakewatchRuleConfigA extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_rule_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchRuleConfigA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchRuleConfigA to import
    * @param importFromId The id of the existing DataDatabricksLakewatchRuleConfigA that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchRuleConfigA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_rule_config databricks_lakewatch_rule_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchRuleConfigAConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchRuleConfigAConfig);
    get defaultFolder(): string;
    private _defaultSchedule;
    get defaultSchedule(): DataDatabricksLakewatchRuleConfigDefaultScheduleOutputReference;
    get defaultSignalCollationWindow(): string;
    get detectionCategories(): string[];
    get effectiveDefaultFolder(): string;
    get effectiveDetectionCategories(): string[];
    get etag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchRuleConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchRuleConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchRuleConfigProviderConfig | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchRuleConfigUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
