/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GenieAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#definition GenieAgent#definition}
    */
    readonly definition: GenieAgentDefinition;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#description GenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#display_name GenieAgent#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#genie_agent_id GenieAgent#genie_agent_id}
    */
    readonly genieAgentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#parent_path GenieAgent#parent_path}
    */
    readonly parentPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#provider_config GenieAgent#provider_config}
    */
    readonly providerConfig?: GenieAgentProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#warehouse_id GenieAgent#warehouse_id}
    */
    readonly warehouseId: string;
}
export interface GenieAgentDefinitionBenchmarksQuestionsAnswer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#content GenieAgent#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#format GenieAgent#format}
    */
    readonly format: string;
}
export declare function genieAgentDefinitionBenchmarksQuestionsAnswerToTerraform(struct?: GenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable): any;
export declare function genieAgentDefinitionBenchmarksQuestionsAnswerToHclTerraform(struct?: GenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionBenchmarksQuestionsAnswerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionBenchmarksQuestionsAnswer | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
}
export declare class GenieAgentDefinitionBenchmarksQuestionsAnswerList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionBenchmarksQuestionsAnswerOutputReference;
}
export interface GenieAgentDefinitionBenchmarksQuestions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#answer GenieAgent#answer}
    */
    readonly answer?: GenieAgentDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#evaluation_note GenieAgent#evaluation_note}
    */
    readonly evaluationNote?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#question GenieAgent#question}
    */
    readonly question: string;
}
export declare function genieAgentDefinitionBenchmarksQuestionsToTerraform(struct?: GenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable): any;
export declare function genieAgentDefinitionBenchmarksQuestionsToHclTerraform(struct?: GenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionBenchmarksQuestionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionBenchmarksQuestions | cdktn.IResolvable | undefined);
    private _answer;
    get answer(): GenieAgentDefinitionBenchmarksQuestionsAnswerList;
    putAnswer(value: GenieAgentDefinitionBenchmarksQuestionsAnswer[] | cdktn.IResolvable): void;
    resetAnswer(): void;
    get answerInput(): cdktn.IResolvable | GenieAgentDefinitionBenchmarksQuestionsAnswer[] | undefined;
    private _evaluationNote?;
    get evaluationNote(): string;
    set evaluationNote(value: string);
    resetEvaluationNote(): void;
    get evaluationNoteInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
}
export declare class GenieAgentDefinitionBenchmarksQuestionsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionBenchmarksQuestions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionBenchmarksQuestionsOutputReference;
}
export interface GenieAgentDefinitionBenchmarks {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#questions GenieAgent#questions}
    */
    readonly questions?: GenieAgentDefinitionBenchmarksQuestions[] | cdktn.IResolvable;
}
export declare function genieAgentDefinitionBenchmarksToTerraform(struct?: GenieAgentDefinitionBenchmarks | cdktn.IResolvable): any;
export declare function genieAgentDefinitionBenchmarksToHclTerraform(struct?: GenieAgentDefinitionBenchmarks | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionBenchmarksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionBenchmarks | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionBenchmarks | cdktn.IResolvable | undefined);
    private _questions;
    get questions(): GenieAgentDefinitionBenchmarksQuestionsList;
    putQuestions(value: GenieAgentDefinitionBenchmarksQuestions[] | cdktn.IResolvable): void;
    resetQuestions(): void;
    get questionsInput(): cdktn.IResolvable | GenieAgentDefinitionBenchmarksQuestions[] | undefined;
}
export interface GenieAgentDefinitionConfigSampleQuestions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#question GenieAgent#question}
    */
    readonly question: string;
}
export declare function genieAgentDefinitionConfigSampleQuestionsToTerraform(struct?: GenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable): any;
export declare function genieAgentDefinitionConfigSampleQuestionsToHclTerraform(struct?: GenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionConfigSampleQuestionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionConfigSampleQuestions | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
}
export declare class GenieAgentDefinitionConfigSampleQuestionsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionConfigSampleQuestions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionConfigSampleQuestionsOutputReference;
}
export interface GenieAgentDefinitionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sample_questions GenieAgent#sample_questions}
    */
    readonly sampleQuestions?: GenieAgentDefinitionConfigSampleQuestions[] | cdktn.IResolvable;
}
export declare function genieAgentDefinitionConfigToTerraform(struct?: GenieAgentDefinitionConfig | cdktn.IResolvable): any;
export declare function genieAgentDefinitionConfigToHclTerraform(struct?: GenieAgentDefinitionConfig | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionConfig | cdktn.IResolvable | undefined);
    private _sampleQuestions;
    get sampleQuestions(): GenieAgentDefinitionConfigSampleQuestionsList;
    putSampleQuestions(value: GenieAgentDefinitionConfigSampleQuestions[] | cdktn.IResolvable): void;
    resetSampleQuestions(): void;
    get sampleQuestionsInput(): cdktn.IResolvable | GenieAgentDefinitionConfigSampleQuestions[] | undefined;
}
export interface GenieAgentDefinitionDataSourcesMcpConnections {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#mcp_connection GenieAgent#mcp_connection}
    */
    readonly mcpConnection: string;
}
export declare function genieAgentDefinitionDataSourcesMcpConnectionsToTerraform(struct?: GenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable): any;
export declare function genieAgentDefinitionDataSourcesMcpConnectionsToHclTerraform(struct?: GenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionDataSourcesMcpConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionDataSourcesMcpConnections | cdktn.IResolvable | undefined);
    private _mcpConnection?;
    get mcpConnection(): string;
    set mcpConnection(value: string);
    get mcpConnectionInput(): string | undefined;
}
export declare class GenieAgentDefinitionDataSourcesMcpConnectionsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionDataSourcesMcpConnectionsOutputReference;
}
export interface GenieAgentDefinitionDataSourcesTablesColumnConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#column GenieAgent#column}
    */
    readonly column: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#description GenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#display_name GenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#enable_entity_matching GenieAgent#enable_entity_matching}
    */
    readonly enableEntityMatching?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#enable_format_assistance GenieAgent#enable_format_assistance}
    */
    readonly enableFormatAssistance?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#exclude GenieAgent#exclude}
    */
    readonly exclude?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#synonyms GenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function genieAgentDefinitionDataSourcesTablesColumnConfigsToTerraform(struct?: GenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable): any;
export declare function genieAgentDefinitionDataSourcesTablesColumnConfigsToHclTerraform(struct?: GenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionDataSourcesTablesColumnConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionDataSourcesTablesColumnConfigs | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enableEntityMatching?;
    get enableEntityMatching(): boolean | cdktn.IResolvable;
    set enableEntityMatching(value: boolean | cdktn.IResolvable);
    resetEnableEntityMatching(): void;
    get enableEntityMatchingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableFormatAssistance?;
    get enableFormatAssistance(): boolean | cdktn.IResolvable;
    set enableFormatAssistance(value: boolean | cdktn.IResolvable);
    resetEnableFormatAssistance(): void;
    get enableFormatAssistanceInput(): boolean | cdktn.IResolvable | undefined;
    private _exclude?;
    get exclude(): boolean | cdktn.IResolvable;
    set exclude(value: boolean | cdktn.IResolvable);
    resetExclude(): void;
    get excludeInput(): boolean | cdktn.IResolvable | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class GenieAgentDefinitionDataSourcesTablesColumnConfigsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionDataSourcesTablesColumnConfigsOutputReference;
}
export interface GenieAgentDefinitionDataSourcesTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#column_configs GenieAgent#column_configs}
    */
    readonly columnConfigs?: GenieAgentDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#description GenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#identifier GenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function genieAgentDefinitionDataSourcesTablesToTerraform(struct?: GenieAgentDefinitionDataSourcesTables | cdktn.IResolvable): any;
export declare function genieAgentDefinitionDataSourcesTablesToHclTerraform(struct?: GenieAgentDefinitionDataSourcesTables | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionDataSourcesTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionDataSourcesTables | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionDataSourcesTables | cdktn.IResolvable | undefined);
    private _columnConfigs;
    get columnConfigs(): GenieAgentDefinitionDataSourcesTablesColumnConfigsList;
    putColumnConfigs(value: GenieAgentDefinitionDataSourcesTablesColumnConfigs[] | cdktn.IResolvable): void;
    resetColumnConfigs(): void;
    get columnConfigsInput(): cdktn.IResolvable | GenieAgentDefinitionDataSourcesTablesColumnConfigs[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export declare class GenieAgentDefinitionDataSourcesTablesList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionDataSourcesTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionDataSourcesTablesOutputReference;
}
export interface GenieAgentDefinitionDataSourcesVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#description GenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#path GenieAgent#path}
    */
    readonly path: string;
}
export declare function genieAgentDefinitionDataSourcesVolumesToTerraform(struct?: GenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable): any;
export declare function genieAgentDefinitionDataSourcesVolumesToHclTerraform(struct?: GenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionDataSourcesVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionDataSourcesVolumes | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class GenieAgentDefinitionDataSourcesVolumesList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionDataSourcesVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionDataSourcesVolumesOutputReference;
}
export interface GenieAgentDefinitionDataSources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#mcp_connections GenieAgent#mcp_connections}
    */
    readonly mcpConnections?: GenieAgentDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#tables GenieAgent#tables}
    */
    readonly tables?: GenieAgentDefinitionDataSourcesTables[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#volumes GenieAgent#volumes}
    */
    readonly volumes?: GenieAgentDefinitionDataSourcesVolumes[] | cdktn.IResolvable;
}
export declare function genieAgentDefinitionDataSourcesToTerraform(struct?: GenieAgentDefinitionDataSources | cdktn.IResolvable): any;
export declare function genieAgentDefinitionDataSourcesToHclTerraform(struct?: GenieAgentDefinitionDataSources | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionDataSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionDataSources | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionDataSources | cdktn.IResolvable | undefined);
    private _mcpConnections;
    get mcpConnections(): GenieAgentDefinitionDataSourcesMcpConnectionsList;
    putMcpConnections(value: GenieAgentDefinitionDataSourcesMcpConnections[] | cdktn.IResolvable): void;
    resetMcpConnections(): void;
    get mcpConnectionsInput(): cdktn.IResolvable | GenieAgentDefinitionDataSourcesMcpConnections[] | undefined;
    private _tables;
    get tables(): GenieAgentDefinitionDataSourcesTablesList;
    putTables(value: GenieAgentDefinitionDataSourcesTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | GenieAgentDefinitionDataSourcesTables[] | undefined;
    private _volumes;
    get volumes(): GenieAgentDefinitionDataSourcesVolumesList;
    putVolumes(value: GenieAgentDefinitionDataSourcesVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | GenieAgentDefinitionDataSourcesVolumes[] | undefined;
}
export interface GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#max GenieAgent#max}
    */
    readonly max?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#min GenieAgent#min}
    */
    readonly min?: string;
}
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeToTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeToHclTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | cdktn.IResolvable | undefined);
    private _max?;
    get max(): string;
    set max(value: string);
    resetMax(): void;
    get maxInput(): string | undefined;
    private _min?;
    get min(): string;
    set min(value: string);
    resetMin(): void;
    get minInput(): string | undefined;
}
export interface GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#value_range GenieAgent#value_range}
    */
    readonly valueRange?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#values GenieAgent#values}
    */
    readonly values?: string[];
}
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueToTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueToHclTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | cdktn.IResolvable | undefined);
    private _valueRange;
    get valueRange(): GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRangeOutputReference;
    putValueRange(value: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange): void;
    resetValueRange(): void;
    get valueRangeInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueValueRange | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#default_value GenieAgent#default_value}
    */
    readonly defaultValue?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#description GenieAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#name GenieAgent#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#type_hint GenieAgent#type_hint}
    */
    readonly typeHint?: string;
}
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsParametersToTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsParametersToHclTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters | cdktn.IResolvable | undefined);
    private _defaultValue;
    get defaultValue(): GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValueOutputReference;
    putDefaultValue(value: GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue): void;
    resetDefaultValue(): void;
    get defaultValueInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersDefaultValue | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _typeHint?;
    get typeHint(): string;
    set typeHint(value: string);
    resetTypeHint(): void;
    get typeHintInput(): string | undefined;
}
export declare class GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersOutputReference;
}
export interface GenieAgentDefinitionInstructionsExampleQuestionSqls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#parameters GenieAgent#parameters}
    */
    readonly parameters?: GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#question GenieAgent#question}
    */
    readonly question: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sql GenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#usage_guidance GenieAgent#usage_guidance}
    */
    readonly usageGuidance?: string;
}
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsToTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsExampleQuestionSqlsToHclTerraform(struct?: GenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsExampleQuestionSqlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsExampleQuestionSqls | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _parameters;
    get parameters(): GenieAgentDefinitionInstructionsExampleQuestionSqlsParametersList;
    putParameters(value: GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsExampleQuestionSqlsParameters[] | undefined;
    private _question?;
    get question(): string;
    set question(value: string);
    get questionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _usageGuidance?;
    get usageGuidance(): string;
    set usageGuidance(value: string);
    resetUsageGuidance(): void;
    get usageGuidanceInput(): string | undefined;
}
export declare class GenieAgentDefinitionInstructionsExampleQuestionSqlsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsExampleQuestionSqlsOutputReference;
}
export interface GenieAgentDefinitionInstructionsJoinSpecsLeft {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#alias GenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#identifier GenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function genieAgentDefinitionInstructionsJoinSpecsLeftToTerraform(struct?: GenieAgentDefinitionInstructionsJoinSpecsLeft | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsJoinSpecsLeftToHclTerraform(struct?: GenieAgentDefinitionInstructionsJoinSpecsLeft | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsJoinSpecsLeftOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionInstructionsJoinSpecsLeft | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsJoinSpecsLeft | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface GenieAgentDefinitionInstructionsJoinSpecsRight {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#alias GenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#identifier GenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function genieAgentDefinitionInstructionsJoinSpecsRightToTerraform(struct?: GenieAgentDefinitionInstructionsJoinSpecsRight | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsJoinSpecsRightToHclTerraform(struct?: GenieAgentDefinitionInstructionsJoinSpecsRight | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsJoinSpecsRightOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionInstructionsJoinSpecsRight | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsJoinSpecsRight | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export interface GenieAgentDefinitionInstructionsJoinSpecs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#comment GenieAgent#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#instruction GenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#left GenieAgent#left}
    */
    readonly left: GenieAgentDefinitionInstructionsJoinSpecsLeft;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#relationship_type GenieAgent#relationship_type}
    */
    readonly relationshipType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#right GenieAgent#right}
    */
    readonly right: GenieAgentDefinitionInstructionsJoinSpecsRight;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sql GenieAgent#sql}
    */
    readonly sql: string;
}
export declare function genieAgentDefinitionInstructionsJoinSpecsToTerraform(struct?: GenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsJoinSpecsToHclTerraform(struct?: GenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsJoinSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsJoinSpecs | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _left;
    get left(): GenieAgentDefinitionInstructionsJoinSpecsLeftOutputReference;
    putLeft(value: GenieAgentDefinitionInstructionsJoinSpecsLeft): void;
    get leftInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsJoinSpecsLeft | undefined;
    private _relationshipType?;
    get relationshipType(): string;
    set relationshipType(value: string);
    resetRelationshipType(): void;
    get relationshipTypeInput(): string | undefined;
    private _right;
    get right(): GenieAgentDefinitionInstructionsJoinSpecsRightOutputReference;
    putRight(value: GenieAgentDefinitionInstructionsJoinSpecsRight): void;
    get rightInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsJoinSpecsRight | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
}
export declare class GenieAgentDefinitionInstructionsJoinSpecsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsJoinSpecsOutputReference;
}
export interface GenieAgentDefinitionInstructionsSqlFunctions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#identifier GenieAgent#identifier}
    */
    readonly identifier: string;
}
export declare function genieAgentDefinitionInstructionsSqlFunctionsToTerraform(struct?: GenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsSqlFunctionsToHclTerraform(struct?: GenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsSqlFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsSqlFunctions | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
}
export declare class GenieAgentDefinitionInstructionsSqlFunctionsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsSqlFunctionsOutputReference;
}
export interface GenieAgentDefinitionInstructionsSqlSnippetsExpressions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#alias GenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#display_name GenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#instruction GenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sql GenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#synonyms GenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function genieAgentDefinitionInstructionsSqlSnippetsExpressionsToTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsSqlSnippetsExpressionsToHclTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsSqlSnippetsExpressionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsSqlSnippetsExpressions | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class GenieAgentDefinitionInstructionsSqlSnippetsExpressionsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsSqlSnippetsExpressionsOutputReference;
}
export interface GenieAgentDefinitionInstructionsSqlSnippetsFilters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#display_name GenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#instruction GenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sql GenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#synonyms GenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function genieAgentDefinitionInstructionsSqlSnippetsFiltersToTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsSqlSnippetsFiltersToHclTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsSqlSnippetsFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsSqlSnippetsFilters | cdktn.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class GenieAgentDefinitionInstructionsSqlSnippetsFiltersList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsSqlSnippetsFiltersOutputReference;
}
export interface GenieAgentDefinitionInstructionsSqlSnippetsMeasures {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#alias GenieAgent#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#display_name GenieAgent#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#instruction GenieAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sql GenieAgent#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#synonyms GenieAgent#synonyms}
    */
    readonly synonyms?: string[];
}
export declare function genieAgentDefinitionInstructionsSqlSnippetsMeasuresToTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsSqlSnippetsMeasuresToHclTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsSqlSnippetsMeasuresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsSqlSnippetsMeasures | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _synonyms?;
    get synonyms(): string[];
    set synonyms(value: string[]);
    resetSynonyms(): void;
    get synonymsInput(): string[] | undefined;
}
export declare class GenieAgentDefinitionInstructionsSqlSnippetsMeasuresList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsSqlSnippetsMeasuresOutputReference;
}
export interface GenieAgentDefinitionInstructionsSqlSnippets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#expressions GenieAgent#expressions}
    */
    readonly expressions?: GenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#filters GenieAgent#filters}
    */
    readonly filters?: GenieAgentDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#measures GenieAgent#measures}
    */
    readonly measures?: GenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable;
}
export declare function genieAgentDefinitionInstructionsSqlSnippetsToTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsSqlSnippetsToHclTerraform(struct?: GenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsSqlSnippetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsSqlSnippets | cdktn.IResolvable | undefined);
    private _expressions;
    get expressions(): GenieAgentDefinitionInstructionsSqlSnippetsExpressionsList;
    putExpressions(value: GenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | cdktn.IResolvable): void;
    resetExpressions(): void;
    get expressionsInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsSqlSnippetsExpressions[] | undefined;
    private _filters;
    get filters(): GenieAgentDefinitionInstructionsSqlSnippetsFiltersList;
    putFilters(value: GenieAgentDefinitionInstructionsSqlSnippetsFilters[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsSqlSnippetsFilters[] | undefined;
    private _measures;
    get measures(): GenieAgentDefinitionInstructionsSqlSnippetsMeasuresList;
    putMeasures(value: GenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | cdktn.IResolvable): void;
    resetMeasures(): void;
    get measuresInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsSqlSnippetsMeasures[] | undefined;
}
export interface GenieAgentDefinitionInstructionsTextInstructions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#content GenieAgent#content}
    */
    readonly content: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#id GenieAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function genieAgentDefinitionInstructionsTextInstructionsToTerraform(struct?: GenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsTextInstructionsToHclTerraform(struct?: GenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsTextInstructionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructionsTextInstructions | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class GenieAgentDefinitionInstructionsTextInstructionsList extends cdktn.ComplexList {
    internalValue?: GenieAgentDefinitionInstructionsTextInstructions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GenieAgentDefinitionInstructionsTextInstructionsOutputReference;
}
export interface GenieAgentDefinitionInstructions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#example_question_sqls GenieAgent#example_question_sqls}
    */
    readonly exampleQuestionSqls?: GenieAgentDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#join_specs GenieAgent#join_specs}
    */
    readonly joinSpecs?: GenieAgentDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sql_functions GenieAgent#sql_functions}
    */
    readonly sqlFunctions?: GenieAgentDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#sql_snippets GenieAgent#sql_snippets}
    */
    readonly sqlSnippets?: GenieAgentDefinitionInstructionsSqlSnippets;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#text_instructions GenieAgent#text_instructions}
    */
    readonly textInstructions?: GenieAgentDefinitionInstructionsTextInstructions[] | cdktn.IResolvable;
}
export declare function genieAgentDefinitionInstructionsToTerraform(struct?: GenieAgentDefinitionInstructions | cdktn.IResolvable): any;
export declare function genieAgentDefinitionInstructionsToHclTerraform(struct?: GenieAgentDefinitionInstructions | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionInstructionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinitionInstructions | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinitionInstructions | cdktn.IResolvable | undefined);
    private _exampleQuestionSqls;
    get exampleQuestionSqls(): GenieAgentDefinitionInstructionsExampleQuestionSqlsList;
    putExampleQuestionSqls(value: GenieAgentDefinitionInstructionsExampleQuestionSqls[] | cdktn.IResolvable): void;
    resetExampleQuestionSqls(): void;
    get exampleQuestionSqlsInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsExampleQuestionSqls[] | undefined;
    private _joinSpecs;
    get joinSpecs(): GenieAgentDefinitionInstructionsJoinSpecsList;
    putJoinSpecs(value: GenieAgentDefinitionInstructionsJoinSpecs[] | cdktn.IResolvable): void;
    resetJoinSpecs(): void;
    get joinSpecsInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsJoinSpecs[] | undefined;
    private _sqlFunctions;
    get sqlFunctions(): GenieAgentDefinitionInstructionsSqlFunctionsList;
    putSqlFunctions(value: GenieAgentDefinitionInstructionsSqlFunctions[] | cdktn.IResolvable): void;
    resetSqlFunctions(): void;
    get sqlFunctionsInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsSqlFunctions[] | undefined;
    private _sqlSnippets;
    get sqlSnippets(): GenieAgentDefinitionInstructionsSqlSnippetsOutputReference;
    putSqlSnippets(value: GenieAgentDefinitionInstructionsSqlSnippets): void;
    resetSqlSnippets(): void;
    get sqlSnippetsInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsSqlSnippets | undefined;
    private _textInstructions;
    get textInstructions(): GenieAgentDefinitionInstructionsTextInstructionsList;
    putTextInstructions(value: GenieAgentDefinitionInstructionsTextInstructions[] | cdktn.IResolvable): void;
    resetTextInstructions(): void;
    get textInstructionsInput(): cdktn.IResolvable | GenieAgentDefinitionInstructionsTextInstructions[] | undefined;
}
export interface GenieAgentDefinition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#benchmarks GenieAgent#benchmarks}
    */
    readonly benchmarks?: GenieAgentDefinitionBenchmarks;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#config GenieAgent#config}
    */
    readonly config?: GenieAgentDefinitionConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#data_sources GenieAgent#data_sources}
    */
    readonly dataSources?: GenieAgentDefinitionDataSources;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#instructions GenieAgent#instructions}
    */
    readonly instructions?: GenieAgentDefinitionInstructions;
}
export declare function genieAgentDefinitionToTerraform(struct?: GenieAgentDefinition | cdktn.IResolvable): any;
export declare function genieAgentDefinitionToHclTerraform(struct?: GenieAgentDefinition | cdktn.IResolvable): any;
export declare class GenieAgentDefinitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentDefinition | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentDefinition | cdktn.IResolvable | undefined);
    private _benchmarks;
    get benchmarks(): GenieAgentDefinitionBenchmarksOutputReference;
    putBenchmarks(value: GenieAgentDefinitionBenchmarks): void;
    resetBenchmarks(): void;
    get benchmarksInput(): cdktn.IResolvable | GenieAgentDefinitionBenchmarks | undefined;
    private _config;
    get config(): GenieAgentDefinitionConfigOutputReference;
    putConfig(value: GenieAgentDefinitionConfig): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | GenieAgentDefinitionConfig | undefined;
    private _dataSources;
    get dataSources(): GenieAgentDefinitionDataSourcesOutputReference;
    putDataSources(value: GenieAgentDefinitionDataSources): void;
    resetDataSources(): void;
    get dataSourcesInput(): cdktn.IResolvable | GenieAgentDefinitionDataSources | undefined;
    private _instructions;
    get instructions(): GenieAgentDefinitionInstructionsOutputReference;
    putInstructions(value: GenieAgentDefinitionInstructions): void;
    resetInstructions(): void;
    get instructionsInput(): cdktn.IResolvable | GenieAgentDefinitionInstructions | undefined;
}
export interface GenieAgentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#workspace_id GenieAgent#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function genieAgentProviderConfigToTerraform(struct?: GenieAgentProviderConfig | cdktn.IResolvable): any;
export declare function genieAgentProviderConfigToHclTerraform(struct?: GenieAgentProviderConfig | cdktn.IResolvable): any;
export declare class GenieAgentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GenieAgentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: GenieAgentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent databricks_genie_agent}
*/
export declare class GenieAgent extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_genie_agent";
    /**
    * Generates CDKTN code for importing a GenieAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GenieAgent to import
    * @param importFromId The id of the existing GenieAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GenieAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/genie_agent databricks_genie_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GenieAgentConfig
    */
    constructor(scope: Construct, id: string, config: GenieAgentConfig);
    get createTime(): string;
    private _definition;
    get definition(): GenieAgentDefinitionOutputReference;
    putDefinition(value: GenieAgentDefinition): void;
    get definitionInput(): cdktn.IResolvable | GenieAgentDefinition | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get effectiveParentPath(): string;
    get etag(): string;
    private _genieAgentId?;
    get genieAgentId(): string;
    set genieAgentId(value: string);
    resetGenieAgentId(): void;
    get genieAgentIdInput(): string | undefined;
    get name(): string;
    private _parentPath?;
    get parentPath(): string;
    set parentPath(value: string);
    resetParentPath(): void;
    get parentPathInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): GenieAgentProviderConfigOutputReference;
    putProviderConfig(value: GenieAgentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | GenieAgentProviderConfig | undefined;
    get updateTime(): string;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
