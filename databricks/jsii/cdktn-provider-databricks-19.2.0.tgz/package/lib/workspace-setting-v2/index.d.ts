/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#aibi_dashboard_embedding_access_policy WorkspaceSettingV2#aibi_dashboard_embedding_access_policy}
    */
    readonly aibiDashboardEmbeddingAccessPolicy?: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#aibi_dashboard_embedding_approved_domains WorkspaceSettingV2#aibi_dashboard_embedding_approved_domains}
    */
    readonly aibiDashboardEmbeddingApprovedDomains?: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#allowed_apps_user_api_scopes WorkspaceSettingV2#allowed_apps_user_api_scopes}
    */
    readonly allowedAppsUserApiScopes?: WorkspaceSettingV2AllowedAppsUserApiScopes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#automatic_cluster_update_workspace WorkspaceSettingV2#automatic_cluster_update_workspace}
    */
    readonly automaticClusterUpdateWorkspace?: WorkspaceSettingV2AutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#boolean_val WorkspaceSettingV2#boolean_val}
    */
    readonly booleanVal?: WorkspaceSettingV2BooleanVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#collaboration_platform_connectivity WorkspaceSettingV2#collaboration_platform_connectivity}
    */
    readonly collaborationPlatformConnectivity?: WorkspaceSettingV2CollaborationPlatformConnectivity;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#effective_aibi_dashboard_embedding_access_policy WorkspaceSettingV2#effective_aibi_dashboard_embedding_access_policy}
    */
    readonly effectiveAibiDashboardEmbeddingAccessPolicy?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#effective_aibi_dashboard_embedding_approved_domains WorkspaceSettingV2#effective_aibi_dashboard_embedding_approved_domains}
    */
    readonly effectiveAibiDashboardEmbeddingApprovedDomains?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#effective_automatic_cluster_update_workspace WorkspaceSettingV2#effective_automatic_cluster_update_workspace}
    */
    readonly effectiveAutomaticClusterUpdateWorkspace?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#effective_personal_compute WorkspaceSettingV2#effective_personal_compute}
    */
    readonly effectivePersonalCompute?: WorkspaceSettingV2EffectivePersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#effective_restrict_workspace_admins WorkspaceSettingV2#effective_restrict_workspace_admins}
    */
    readonly effectiveRestrictWorkspaceAdmins?: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#effective_workspace_label WorkspaceSettingV2#effective_workspace_label}
    */
    readonly effectiveWorkspaceLabel?: WorkspaceSettingV2EffectiveWorkspaceLabel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#integer_val WorkspaceSettingV2#integer_val}
    */
    readonly integerVal?: WorkspaceSettingV2IntegerVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#name WorkspaceSettingV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#operational_email_custom_recipient WorkspaceSettingV2#operational_email_custom_recipient}
    */
    readonly operationalEmailCustomRecipient?: WorkspaceSettingV2OperationalEmailCustomRecipient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#personal_compute WorkspaceSettingV2#personal_compute}
    */
    readonly personalCompute?: WorkspaceSettingV2PersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#provider_config WorkspaceSettingV2#provider_config}
    */
    readonly providerConfig?: WorkspaceSettingV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#restrict_workspace_admins WorkspaceSettingV2#restrict_workspace_admins}
    */
    readonly restrictWorkspaceAdmins?: WorkspaceSettingV2RestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#string_val WorkspaceSettingV2#string_val}
    */
    readonly stringVal?: WorkspaceSettingV2StringVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#workspace_dashboard_theme WorkspaceSettingV2#workspace_dashboard_theme}
    */
    readonly workspaceDashboardTheme?: WorkspaceSettingV2WorkspaceDashboardTheme;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#workspace_label WorkspaceSettingV2#workspace_label}
    */
    readonly workspaceLabel?: WorkspaceSettingV2WorkspaceLabel;
}
export interface WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#access_policy_type WorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function workspaceSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function workspaceSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#approved_domains WorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function workspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function workspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface WorkspaceSettingV2AllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#allowed_scopes WorkspaceSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function workspaceSettingV2AllowedAppsUserApiScopesToTerraform(struct?: WorkspaceSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable): any;
export declare function workspaceSettingV2AllowedAppsUserApiScopesToHclTerraform(struct?: WorkspaceSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#forced_for_compliance_mode WorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#unavailable_for_disabled_entitlement WorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#unavailable_for_non_enterprise_tier WorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#hours WorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#minutes WorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#day_of_week WorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#frequency WorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#window_start_time WorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#week_day_based_schedule WorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#can_toggle WorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#enabled WorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#enablement_details WorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#maintenance_window WorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#restart_even_if_no_updates_available WorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2BooleanValToTerraform(struct?: WorkspaceSettingV2BooleanVal | cdktn.IResolvable): any;
export declare function workspaceSettingV2BooleanValToHclTerraform(struct?: WorkspaceSettingV2BooleanVal | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2BooleanVal | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2BooleanVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2CollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#connectivity WorkspaceSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function workspaceSettingV2CollaborationPlatformConnectivityToTerraform(struct?: WorkspaceSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable): any;
export declare function workspaceSettingV2CollaborationPlatformConnectivityToHclTerraform(struct?: WorkspaceSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2CollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#access_policy_type WorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#approved_domains WorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface WorkspaceSettingV2EffectiveAllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#allowed_scopes WorkspaceSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function workspaceSettingV2EffectiveAllowedAppsUserApiScopesToTerraform(struct?: WorkspaceSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare function workspaceSettingV2EffectiveAllowedAppsUserApiScopesToHclTerraform(struct?: WorkspaceSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare class WorkspaceSettingV2EffectiveAllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAllowedAppsUserApiScopes | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#forced_for_compliance_mode WorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#unavailable_for_disabled_entitlement WorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#unavailable_for_non_enterprise_tier WorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#hours WorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#minutes WorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#day_of_week WorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#frequency WorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#window_start_time WorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#week_day_based_schedule WorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#can_toggle WorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#enabled WorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#enablement_details WorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#maintenance_window WorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#restart_even_if_no_updates_available WorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2EffectiveBooleanValToTerraform(struct?: WorkspaceSettingV2EffectiveBooleanVal): any;
export declare function workspaceSettingV2EffectiveBooleanValToHclTerraform(struct?: WorkspaceSettingV2EffectiveBooleanVal): any;
export declare class WorkspaceSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2EffectiveCollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#connectivity WorkspaceSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function workspaceSettingV2EffectiveCollaborationPlatformConnectivityToTerraform(struct?: WorkspaceSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare function workspaceSettingV2EffectiveCollaborationPlatformConnectivityToHclTerraform(struct?: WorkspaceSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare class WorkspaceSettingV2EffectiveCollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveCollaborationPlatformConnectivity | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveCollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function workspaceSettingV2EffectiveIntegerValToTerraform(struct?: WorkspaceSettingV2EffectiveIntegerVal): any;
export declare function workspaceSettingV2EffectiveIntegerValToHclTerraform(struct?: WorkspaceSettingV2EffectiveIntegerVal): any;
export declare class WorkspaceSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface WorkspaceSettingV2EffectiveOperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#email WorkspaceSettingV2#email}
    */
    readonly email?: string;
}
export declare function workspaceSettingV2EffectiveOperationalEmailCustomRecipientToTerraform(struct?: WorkspaceSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare function workspaceSettingV2EffectiveOperationalEmailCustomRecipientToHclTerraform(struct?: WorkspaceSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare class WorkspaceSettingV2EffectiveOperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveOperationalEmailCustomRecipient | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveOperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2EffectivePersonalComputeToTerraform(struct?: WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectivePersonalComputeToHclTerraform(struct?: WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#disable_gov_tag_creation WorkspaceSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#status WorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function workspaceSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2EffectiveStringValToTerraform(struct?: WorkspaceSettingV2EffectiveStringVal): any;
export declare function workspaceSettingV2EffectiveStringValToHclTerraform(struct?: WorkspaceSettingV2EffectiveStringVal): any;
export declare class WorkspaceSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveStringVal | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#mid WorkspaceSettingV2#mid}
    */
    readonly mid?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color WorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color_scheme WorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_diverging WorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_sequential WorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#from_categorical_index WorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#mid WorkspaceSettingV2#mid}
    */
    readonly mid?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color WorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color_scheme WorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_diverging WorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_sequential WorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#from_categorical_index WorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark_mode WorkspaceSettingV2#dark_mode}
    */
    readonly darkMode?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light_mode WorkspaceSettingV2#light_mode}
    */
    readonly lightMode?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#base WorkspaceSettingV2#base}
    */
    readonly base?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#field_title WorkspaceSettingV2#field_title}
    */
    readonly fieldTitle?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#field_value WorkspaceSettingV2#field_value}
    */
    readonly fieldValue?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_description WorkspaceSettingV2#widget_description}
    */
    readonly widgetDescription?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_title WorkspaceSettingV2#widget_title}
    */
    readonly widgetTitle?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#negative WorkspaceSettingV2#negative}
    */
    readonly negative?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#neutral WorkspaceSettingV2#neutral}
    */
    readonly neutral?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#positive WorkspaceSettingV2#positive}
    */
    readonly positive?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#axis_line_color WorkspaceSettingV2#axis_line_color}
    */
    readonly axisLineColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#canvas_background_color WorkspaceSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#continuous_gradient WorkspaceSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_settings WorkspaceSettingV2#font_settings}
    */
    readonly fontSettings?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#grid_line_color WorkspaceSettingV2#grid_line_color}
    */
    readonly gridLineColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#mark_corner_radius WorkspaceSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#selection_color WorkspaceSettingV2#selection_color}
    */
    readonly selectionColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#sentiment_colors WorkspaceSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_box_vertical_align WorkspaceSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_01 WorkspaceSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_02 WorkspaceSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_03 WorkspaceSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_04 WorkspaceSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_05 WorkspaceSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_06 WorkspaceSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_07 WorkspaceSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_08 WorkspaceSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_09 WorkspaceSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_10 WorkspaceSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_11 WorkspaceSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_12 WorkspaceSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_13 WorkspaceSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_14 WorkspaceSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_15 WorkspaceSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_16 WorkspaceSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_17 WorkspaceSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_18 WorkspaceSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_19 WorkspaceSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_20 WorkspaceSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_background_color WorkspaceSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_border_color WorkspaceSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_corner_radius WorkspaceSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_header_alignment WorkspaceSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_margin WorkspaceSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_padding WorkspaceSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_shadow WorkspaceSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare function workspaceSettingV2EffectiveWorkspaceDashboardThemeToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceDashboardTheme | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceDashboardTheme | undefined);
    private _axisLineColor;
    get axisLineColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface WorkspaceSettingV2EffectiveWorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color WorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#label WorkspaceSettingV2#label}
    */
    readonly label?: string;
}
export declare function workspaceSettingV2EffectiveWorkspaceLabelToTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveWorkspaceLabelToHclTerraform(struct?: WorkspaceSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveWorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
export interface WorkspaceSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function workspaceSettingV2IntegerValToTerraform(struct?: WorkspaceSettingV2IntegerVal | cdktn.IResolvable): any;
export declare function workspaceSettingV2IntegerValToHclTerraform(struct?: WorkspaceSettingV2IntegerVal | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2IntegerVal | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2IntegerVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface WorkspaceSettingV2OperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#email WorkspaceSettingV2#email}
    */
    readonly email?: string;
}
export declare function workspaceSettingV2OperationalEmailCustomRecipientToTerraform(struct?: WorkspaceSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable): any;
export declare function workspaceSettingV2OperationalEmailCustomRecipientToHclTerraform(struct?: WorkspaceSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2OperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface WorkspaceSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2PersonalComputeToTerraform(struct?: WorkspaceSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare function workspaceSettingV2PersonalComputeToHclTerraform(struct?: WorkspaceSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2PersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2PersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface WorkspaceSettingV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#workspace_id WorkspaceSettingV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceSettingV2ProviderConfigToTerraform(struct?: WorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceSettingV2ProviderConfigToHclTerraform(struct?: WorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface WorkspaceSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#disable_gov_tag_creation WorkspaceSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#status WorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function workspaceSettingV2RestrictWorkspaceAdminsToTerraform(struct?: WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function workspaceSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface WorkspaceSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2StringValToTerraform(struct?: WorkspaceSettingV2StringVal | cdktn.IResolvable): any;
export declare function workspaceSettingV2StringValToHclTerraform(struct?: WorkspaceSettingV2StringVal | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2StringVal | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2StringVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeAxisLineColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#mid WorkspaceSettingV2#mid}
    */
    readonly mid?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color WorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color_scheme WorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_diverging WorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_sequential WorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#from_categorical_index WorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#mid WorkspaceSettingV2#mid}
    */
    readonly mid?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#end WorkspaceSettingV2#end}
    */
    readonly end?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#start WorkspaceSettingV2#start}
    */
    readonly start?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color WorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color_scheme WorkspaceSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_diverging WorkspaceSettingV2#custom_diverging}
    */
    readonly customDiverging?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#custom_sequential WorkspaceSettingV2#custom_sequential}
    */
    readonly customSequential?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#from_categorical_index WorkspaceSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark_mode WorkspaceSettingV2#dark_mode}
    */
    readonly darkMode?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light_mode WorkspaceSettingV2#light_mode}
    */
    readonly lightMode?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_size WorkspaceSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_style WorkspaceSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_weight WorkspaceSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_case WorkspaceSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_decoration WorkspaceSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#base WorkspaceSettingV2#base}
    */
    readonly base?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#field_title WorkspaceSettingV2#field_title}
    */
    readonly fieldTitle?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#field_value WorkspaceSettingV2#field_value}
    */
    readonly fieldValue?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_description WorkspaceSettingV2#widget_description}
    */
    readonly widgetDescription?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_title WorkspaceSettingV2#widget_title}
    */
    readonly widgetTitle?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeGridLineColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeSelectionColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#negative WorkspaceSettingV2#negative}
    */
    readonly negative?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#neutral WorkspaceSettingV2#neutral}
    */
    readonly neutral?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#positive WorkspaceSettingV2#positive}
    */
    readonly positive?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#dark WorkspaceSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#light WorkspaceSettingV2#light}
    */
    readonly light?: string;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface WorkspaceSettingV2WorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#axis_line_color WorkspaceSettingV2#axis_line_color}
    */
    readonly axisLineColor?: WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#canvas_background_color WorkspaceSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#continuous_gradient WorkspaceSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_color WorkspaceSettingV2#font_color}
    */
    readonly fontColor?: WorkspaceSettingV2WorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_family WorkspaceSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#font_settings WorkspaceSettingV2#font_settings}
    */
    readonly fontSettings?: WorkspaceSettingV2WorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#grid_line_color WorkspaceSettingV2#grid_line_color}
    */
    readonly gridLineColor?: WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#mark_corner_radius WorkspaceSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#selection_color WorkspaceSettingV2#selection_color}
    */
    readonly selectionColor?: WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#sentiment_colors WorkspaceSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#text_box_vertical_align WorkspaceSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_01 WorkspaceSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_02 WorkspaceSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_03 WorkspaceSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_04 WorkspaceSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_05 WorkspaceSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_06 WorkspaceSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_07 WorkspaceSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_08 WorkspaceSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_09 WorkspaceSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_10 WorkspaceSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_11 WorkspaceSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_12 WorkspaceSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_13 WorkspaceSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_14 WorkspaceSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_15 WorkspaceSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_16 WorkspaceSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_17 WorkspaceSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_18 WorkspaceSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_19 WorkspaceSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#visualization_color_20 WorkspaceSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_background_color WorkspaceSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_border_color WorkspaceSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_corner_radius WorkspaceSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_header_alignment WorkspaceSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_margin WorkspaceSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_padding WorkspaceSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#widget_shadow WorkspaceSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function workspaceSettingV2WorkspaceDashboardThemeToTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardTheme | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceDashboardThemeToHclTerraform(struct?: WorkspaceSettingV2WorkspaceDashboardTheme | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceDashboardTheme | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceDashboardTheme | cdktn.IResolvable | undefined);
    private _axisLineColor;
    get axisLineColor(): WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): WorkspaceSettingV2WorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: WorkspaceSettingV2WorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): WorkspaceSettingV2WorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: WorkspaceSettingV2WorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): WorkspaceSettingV2WorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): WorkspaceSettingV2WorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): WorkspaceSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface WorkspaceSettingV2WorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#color WorkspaceSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#label WorkspaceSettingV2#label}
    */
    readonly label?: string;
}
export declare function workspaceSettingV2WorkspaceLabelToTerraform(struct?: WorkspaceSettingV2WorkspaceLabel | cdktn.IResolvable): any;
export declare function workspaceSettingV2WorkspaceLabelToHclTerraform(struct?: WorkspaceSettingV2WorkspaceLabel | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2WorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2WorkspaceLabel | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2WorkspaceLabel | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2 databricks_workspace_setting_v2}
*/
export declare class WorkspaceSettingV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_setting_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceSettingV2 to import
    * @param importFromId The id of the existing WorkspaceSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/workspace_setting_v2 databricks_workspace_setting_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceSettingV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: WorkspaceSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    putAibiDashboardEmbeddingAccessPolicy(value: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy): void;
    resetAibiDashboardEmbeddingAccessPolicy(): void;
    get aibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    putAibiDashboardEmbeddingApprovedDomains(value: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains): void;
    resetAibiDashboardEmbeddingApprovedDomains(): void;
    get aibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    private _allowedAppsUserApiScopes;
    get allowedAppsUserApiScopes(): WorkspaceSettingV2AllowedAppsUserApiScopesOutputReference;
    putAllowedAppsUserApiScopes(value: WorkspaceSettingV2AllowedAppsUserApiScopes): void;
    resetAllowedAppsUserApiScopes(): void;
    get allowedAppsUserApiScopesInput(): cdktn.IResolvable | WorkspaceSettingV2AllowedAppsUserApiScopes | undefined;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    putAutomaticClusterUpdateWorkspace(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspace): void;
    resetAutomaticClusterUpdateWorkspace(): void;
    get automaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspace | undefined;
    private _booleanVal;
    get booleanVal(): WorkspaceSettingV2BooleanValOutputReference;
    putBooleanVal(value: WorkspaceSettingV2BooleanVal): void;
    resetBooleanVal(): void;
    get booleanValInput(): cdktn.IResolvable | WorkspaceSettingV2BooleanVal | undefined;
    private _collaborationPlatformConnectivity;
    get collaborationPlatformConnectivity(): WorkspaceSettingV2CollaborationPlatformConnectivityOutputReference;
    putCollaborationPlatformConnectivity(value: WorkspaceSettingV2CollaborationPlatformConnectivity): void;
    resetCollaborationPlatformConnectivity(): void;
    get collaborationPlatformConnectivityInput(): cdktn.IResolvable | WorkspaceSettingV2CollaborationPlatformConnectivity | undefined;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    putEffectiveAibiDashboardEmbeddingAccessPolicy(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): void;
    resetEffectiveAibiDashboardEmbeddingAccessPolicy(): void;
    get effectiveAibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    putEffectiveAibiDashboardEmbeddingApprovedDomains(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): void;
    resetEffectiveAibiDashboardEmbeddingApprovedDomains(): void;
    get effectiveAibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    private _effectiveAllowedAppsUserApiScopes;
    get effectiveAllowedAppsUserApiScopes(): WorkspaceSettingV2EffectiveAllowedAppsUserApiScopesOutputReference;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    putEffectiveAutomaticClusterUpdateWorkspace(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace): void;
    resetEffectiveAutomaticClusterUpdateWorkspace(): void;
    get effectiveAutomaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): WorkspaceSettingV2EffectiveBooleanValOutputReference;
    private _effectiveCollaborationPlatformConnectivity;
    get effectiveCollaborationPlatformConnectivity(): WorkspaceSettingV2EffectiveCollaborationPlatformConnectivityOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): WorkspaceSettingV2EffectiveIntegerValOutputReference;
    private _effectiveOperationalEmailCustomRecipient;
    get effectiveOperationalEmailCustomRecipient(): WorkspaceSettingV2EffectiveOperationalEmailCustomRecipientOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): WorkspaceSettingV2EffectivePersonalComputeOutputReference;
    putEffectivePersonalCompute(value: WorkspaceSettingV2EffectivePersonalCompute): void;
    resetEffectivePersonalCompute(): void;
    get effectivePersonalComputeInput(): cdktn.IResolvable | WorkspaceSettingV2EffectivePersonalCompute | undefined;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): WorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    putEffectiveRestrictWorkspaceAdmins(value: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins): void;
    resetEffectiveRestrictWorkspaceAdmins(): void;
    get effectiveRestrictWorkspaceAdminsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    private _effectiveStringVal;
    get effectiveStringVal(): WorkspaceSettingV2EffectiveStringValOutputReference;
    private _effectiveWorkspaceDashboardTheme;
    get effectiveWorkspaceDashboardTheme(): WorkspaceSettingV2EffectiveWorkspaceDashboardThemeOutputReference;
    private _effectiveWorkspaceLabel;
    get effectiveWorkspaceLabel(): WorkspaceSettingV2EffectiveWorkspaceLabelOutputReference;
    putEffectiveWorkspaceLabel(value: WorkspaceSettingV2EffectiveWorkspaceLabel): void;
    resetEffectiveWorkspaceLabel(): void;
    get effectiveWorkspaceLabelInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveWorkspaceLabel | undefined;
    private _integerVal;
    get integerVal(): WorkspaceSettingV2IntegerValOutputReference;
    putIntegerVal(value: WorkspaceSettingV2IntegerVal): void;
    resetIntegerVal(): void;
    get integerValInput(): cdktn.IResolvable | WorkspaceSettingV2IntegerVal | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operationalEmailCustomRecipient;
    get operationalEmailCustomRecipient(): WorkspaceSettingV2OperationalEmailCustomRecipientOutputReference;
    putOperationalEmailCustomRecipient(value: WorkspaceSettingV2OperationalEmailCustomRecipient): void;
    resetOperationalEmailCustomRecipient(): void;
    get operationalEmailCustomRecipientInput(): cdktn.IResolvable | WorkspaceSettingV2OperationalEmailCustomRecipient | undefined;
    private _personalCompute;
    get personalCompute(): WorkspaceSettingV2PersonalComputeOutputReference;
    putPersonalCompute(value: WorkspaceSettingV2PersonalCompute): void;
    resetPersonalCompute(): void;
    get personalComputeInput(): cdktn.IResolvable | WorkspaceSettingV2PersonalCompute | undefined;
    private _providerConfig;
    get providerConfig(): WorkspaceSettingV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceSettingV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceSettingV2ProviderConfig | undefined;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): WorkspaceSettingV2RestrictWorkspaceAdminsOutputReference;
    putRestrictWorkspaceAdmins(value: WorkspaceSettingV2RestrictWorkspaceAdmins): void;
    resetRestrictWorkspaceAdmins(): void;
    get restrictWorkspaceAdminsInput(): cdktn.IResolvable | WorkspaceSettingV2RestrictWorkspaceAdmins | undefined;
    private _stringVal;
    get stringVal(): WorkspaceSettingV2StringValOutputReference;
    putStringVal(value: WorkspaceSettingV2StringVal): void;
    resetStringVal(): void;
    get stringValInput(): cdktn.IResolvable | WorkspaceSettingV2StringVal | undefined;
    private _workspaceDashboardTheme;
    get workspaceDashboardTheme(): WorkspaceSettingV2WorkspaceDashboardThemeOutputReference;
    putWorkspaceDashboardTheme(value: WorkspaceSettingV2WorkspaceDashboardTheme): void;
    resetWorkspaceDashboardTheme(): void;
    get workspaceDashboardThemeInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceDashboardTheme | undefined;
    private _workspaceLabel;
    get workspaceLabel(): WorkspaceSettingV2WorkspaceLabelOutputReference;
    putWorkspaceLabel(value: WorkspaceSettingV2WorkspaceLabel): void;
    resetWorkspaceLabel(): void;
    get workspaceLabelInput(): cdktn.IResolvable | WorkspaceSettingV2WorkspaceLabel | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
