/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#aibi_dashboard_embedding_access_policy AccountSettingV2#aibi_dashboard_embedding_access_policy}
    */
    readonly aibiDashboardEmbeddingAccessPolicy?: AccountSettingV2AibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#aibi_dashboard_embedding_approved_domains AccountSettingV2#aibi_dashboard_embedding_approved_domains}
    */
    readonly aibiDashboardEmbeddingApprovedDomains?: AccountSettingV2AibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#allowed_apps_user_api_scopes AccountSettingV2#allowed_apps_user_api_scopes}
    */
    readonly allowedAppsUserApiScopes?: AccountSettingV2AllowedAppsUserApiScopes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#automatic_cluster_update_workspace AccountSettingV2#automatic_cluster_update_workspace}
    */
    readonly automaticClusterUpdateWorkspace?: AccountSettingV2AutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#boolean_val AccountSettingV2#boolean_val}
    */
    readonly booleanVal?: AccountSettingV2BooleanVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#collaboration_platform_connectivity AccountSettingV2#collaboration_platform_connectivity}
    */
    readonly collaborationPlatformConnectivity?: AccountSettingV2CollaborationPlatformConnectivity;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#effective_aibi_dashboard_embedding_access_policy AccountSettingV2#effective_aibi_dashboard_embedding_access_policy}
    */
    readonly effectiveAibiDashboardEmbeddingAccessPolicy?: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#effective_aibi_dashboard_embedding_approved_domains AccountSettingV2#effective_aibi_dashboard_embedding_approved_domains}
    */
    readonly effectiveAibiDashboardEmbeddingApprovedDomains?: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#effective_automatic_cluster_update_workspace AccountSettingV2#effective_automatic_cluster_update_workspace}
    */
    readonly effectiveAutomaticClusterUpdateWorkspace?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#effective_personal_compute AccountSettingV2#effective_personal_compute}
    */
    readonly effectivePersonalCompute?: AccountSettingV2EffectivePersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#effective_restrict_workspace_admins AccountSettingV2#effective_restrict_workspace_admins}
    */
    readonly effectiveRestrictWorkspaceAdmins?: AccountSettingV2EffectiveRestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#effective_workspace_label AccountSettingV2#effective_workspace_label}
    */
    readonly effectiveWorkspaceLabel?: AccountSettingV2EffectiveWorkspaceLabel;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#integer_val AccountSettingV2#integer_val}
    */
    readonly integerVal?: AccountSettingV2IntegerVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#name AccountSettingV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#operational_email_custom_recipient AccountSettingV2#operational_email_custom_recipient}
    */
    readonly operationalEmailCustomRecipient?: AccountSettingV2OperationalEmailCustomRecipient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#personal_compute AccountSettingV2#personal_compute}
    */
    readonly personalCompute?: AccountSettingV2PersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#restrict_workspace_admins AccountSettingV2#restrict_workspace_admins}
    */
    readonly restrictWorkspaceAdmins?: AccountSettingV2RestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#string_val AccountSettingV2#string_val}
    */
    readonly stringVal?: AccountSettingV2StringVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#workspace_dashboard_theme AccountSettingV2#workspace_dashboard_theme}
    */
    readonly workspaceDashboardTheme?: AccountSettingV2WorkspaceDashboardTheme;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#workspace_label AccountSettingV2#workspace_label}
    */
    readonly workspaceLabel?: AccountSettingV2WorkspaceLabel;
}
export interface AccountSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#access_policy_type AccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function accountSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function accountSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class AccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface AccountSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#approved_domains AccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function accountSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function accountSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class AccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface AccountSettingV2AllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#allowed_scopes AccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function accountSettingV2AllowedAppsUserApiScopesToTerraform(struct?: AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable): any;
export declare function accountSettingV2AllowedAppsUserApiScopesToHclTerraform(struct?: AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable): any;
export declare class AccountSettingV2AllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#forced_for_compliance_mode AccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#unavailable_for_disabled_entitlement AccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#unavailable_for_non_enterprise_tier AccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#hours AccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#minutes AccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#day_of_week AccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#frequency AccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#window_start_time AccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#week_day_based_schedule AccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#can_toggle AccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#enabled AccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#enablement_details AccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#maintenance_window AccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#restart_even_if_no_updates_available AccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2BooleanValToTerraform(struct?: AccountSettingV2BooleanVal | cdktn.IResolvable): any;
export declare function accountSettingV2BooleanValToHclTerraform(struct?: AccountSettingV2BooleanVal | cdktn.IResolvable): any;
export declare class AccountSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2BooleanVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2BooleanVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2CollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#connectivity AccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function accountSettingV2CollaborationPlatformConnectivityToTerraform(struct?: AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable): any;
export declare function accountSettingV2CollaborationPlatformConnectivityToHclTerraform(struct?: AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable): any;
export declare class AccountSettingV2CollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#access_policy_type AccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#approved_domains AccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface AccountSettingV2EffectiveAllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#allowed_scopes AccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function accountSettingV2EffectiveAllowedAppsUserApiScopesToTerraform(struct?: AccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare function accountSettingV2EffectiveAllowedAppsUserApiScopesToHclTerraform(struct?: AccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare class AccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined;
    set internalValue(value: AccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#forced_for_compliance_mode AccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#unavailable_for_disabled_entitlement AccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#unavailable_for_non_enterprise_tier AccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#hours AccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#minutes AccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#day_of_week AccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#frequency AccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#window_start_time AccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#week_day_based_schedule AccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#can_toggle AccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#enabled AccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#enablement_details AccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#maintenance_window AccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#restart_even_if_no_updates_available AccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2EffectiveBooleanValToTerraform(struct?: AccountSettingV2EffectiveBooleanVal): any;
export declare function accountSettingV2EffectiveBooleanValToHclTerraform(struct?: AccountSettingV2EffectiveBooleanVal): any;
export declare class AccountSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: AccountSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2EffectiveCollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#connectivity AccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function accountSettingV2EffectiveCollaborationPlatformConnectivityToTerraform(struct?: AccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare function accountSettingV2EffectiveCollaborationPlatformConnectivityToHclTerraform(struct?: AccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare class AccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined;
    set internalValue(value: AccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface AccountSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function accountSettingV2EffectiveIntegerValToTerraform(struct?: AccountSettingV2EffectiveIntegerVal): any;
export declare function accountSettingV2EffectiveIntegerValToHclTerraform(struct?: AccountSettingV2EffectiveIntegerVal): any;
export declare class AccountSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: AccountSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface AccountSettingV2EffectiveOperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#email AccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function accountSettingV2EffectiveOperationalEmailCustomRecipientToTerraform(struct?: AccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare function accountSettingV2EffectiveOperationalEmailCustomRecipientToHclTerraform(struct?: AccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare class AccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined;
    set internalValue(value: AccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface AccountSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2EffectivePersonalComputeToTerraform(struct?: AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare function accountSettingV2EffectivePersonalComputeToHclTerraform(struct?: AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#disable_gov_tag_creation AccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#status AccountSettingV2#status}
    */
    readonly status: string;
}
export declare function accountSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface AccountSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2EffectiveStringValToTerraform(struct?: AccountSettingV2EffectiveStringVal): any;
export declare function accountSettingV2EffectiveStringValToHclTerraform(struct?: AccountSettingV2EffectiveStringVal): any;
export declare class AccountSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveStringVal | undefined;
    set internalValue(value: AccountSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#mid AccountSettingV2#mid}
    */
    readonly mid?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color AccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color_scheme AccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_diverging AccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_sequential AccountSettingV2#custom_sequential}
    */
    readonly customSequential?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#from_categorical_index AccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#mid AccountSettingV2#mid}
    */
    readonly mid?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color AccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color_scheme AccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_diverging AccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_sequential AccountSettingV2#custom_sequential}
    */
    readonly customSequential?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#from_categorical_index AccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark_mode AccountSettingV2#dark_mode}
    */
    readonly darkMode?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light_mode AccountSettingV2#light_mode}
    */
    readonly lightMode?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#base AccountSettingV2#base}
    */
    readonly base?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#field_title AccountSettingV2#field_title}
    */
    readonly fieldTitle?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#field_value AccountSettingV2#field_value}
    */
    readonly fieldValue?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_description AccountSettingV2#widget_description}
    */
    readonly widgetDescription?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_title AccountSettingV2#widget_title}
    */
    readonly widgetTitle?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#negative AccountSettingV2#negative}
    */
    readonly negative?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#neutral AccountSettingV2#neutral}
    */
    readonly neutral?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#positive AccountSettingV2#positive}
    */
    readonly positive?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#axis_line_color AccountSettingV2#axis_line_color}
    */
    readonly axisLineColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#canvas_background_color AccountSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#continuous_gradient AccountSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_settings AccountSettingV2#font_settings}
    */
    readonly fontSettings?: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#grid_line_color AccountSettingV2#grid_line_color}
    */
    readonly gridLineColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#mark_corner_radius AccountSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#selection_color AccountSettingV2#selection_color}
    */
    readonly selectionColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#sentiment_colors AccountSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_box_vertical_align AccountSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_01 AccountSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_02 AccountSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_03 AccountSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_04 AccountSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_05 AccountSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_06 AccountSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_07 AccountSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_08 AccountSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_09 AccountSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_10 AccountSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_11 AccountSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_12 AccountSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_13 AccountSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_14 AccountSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_15 AccountSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_16 AccountSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_17 AccountSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_18 AccountSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_19 AccountSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_20 AccountSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_background_color AccountSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_border_color AccountSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_corner_radius AccountSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_header_alignment AccountSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_margin AccountSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_padding AccountSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_shadow AccountSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeToTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare function accountSettingV2EffectiveWorkspaceDashboardThemeToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare class AccountSettingV2EffectiveWorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceDashboardTheme | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceDashboardTheme | undefined);
    private _axisLineColor;
    get axisLineColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface AccountSettingV2EffectiveWorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color AccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#label AccountSettingV2#label}
    */
    readonly label?: string;
}
export declare function accountSettingV2EffectiveWorkspaceLabelToTerraform(struct?: AccountSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveWorkspaceLabelToHclTerraform(struct?: AccountSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveWorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveWorkspaceLabel | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
export interface AccountSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function accountSettingV2IntegerValToTerraform(struct?: AccountSettingV2IntegerVal | cdktn.IResolvable): any;
export declare function accountSettingV2IntegerValToHclTerraform(struct?: AccountSettingV2IntegerVal | cdktn.IResolvable): any;
export declare class AccountSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2IntegerVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2IntegerVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface AccountSettingV2OperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#email AccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function accountSettingV2OperationalEmailCustomRecipientToTerraform(struct?: AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable): any;
export declare function accountSettingV2OperationalEmailCustomRecipientToHclTerraform(struct?: AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable): any;
export declare class AccountSettingV2OperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface AccountSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2PersonalComputeToTerraform(struct?: AccountSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare function accountSettingV2PersonalComputeToHclTerraform(struct?: AccountSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare class AccountSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2PersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2PersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#disable_gov_tag_creation AccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#status AccountSettingV2#status}
    */
    readonly status: string;
}
export declare function accountSettingV2RestrictWorkspaceAdminsToTerraform(struct?: AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function accountSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class AccountSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface AccountSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2StringValToTerraform(struct?: AccountSettingV2StringVal | cdktn.IResolvable): any;
export declare function accountSettingV2StringValToHclTerraform(struct?: AccountSettingV2StringVal | cdktn.IResolvable): any;
export declare class AccountSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2StringVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2StringVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeAxisLineColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#mid AccountSettingV2#mid}
    */
    readonly mid?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color AccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color_scheme AccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_diverging AccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_sequential AccountSettingV2#custom_sequential}
    */
    readonly customSequential?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#from_categorical_index AccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#mid AccountSettingV2#mid}
    */
    readonly mid?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#end AccountSettingV2#end}
    */
    readonly end?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#start AccountSettingV2#start}
    */
    readonly start?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color AccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color_scheme AccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_diverging AccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#custom_sequential AccountSettingV2#custom_sequential}
    */
    readonly customSequential?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#from_categorical_index AccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark_mode AccountSettingV2#dark_mode}
    */
    readonly darkMode?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light_mode AccountSettingV2#light_mode}
    */
    readonly lightMode?: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_size AccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_style AccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_weight AccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_case AccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_decoration AccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#base AccountSettingV2#base}
    */
    readonly base?: AccountSettingV2WorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#field_title AccountSettingV2#field_title}
    */
    readonly fieldTitle?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#field_value AccountSettingV2#field_value}
    */
    readonly fieldValue?: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_description AccountSettingV2#widget_description}
    */
    readonly widgetDescription?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_title AccountSettingV2#widget_title}
    */
    readonly widgetTitle?: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): AccountSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeGridLineColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeSelectionColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#negative AccountSettingV2#negative}
    */
    readonly negative?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#neutral AccountSettingV2#neutral}
    */
    readonly neutral?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#positive AccountSettingV2#positive}
    */
    readonly positive?: AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#dark AccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#light AccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function accountSettingV2WorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface AccountSettingV2WorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#axis_line_color AccountSettingV2#axis_line_color}
    */
    readonly axisLineColor?: AccountSettingV2WorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#canvas_background_color AccountSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#continuous_gradient AccountSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: AccountSettingV2WorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_color AccountSettingV2#font_color}
    */
    readonly fontColor?: AccountSettingV2WorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_family AccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#font_settings AccountSettingV2#font_settings}
    */
    readonly fontSettings?: AccountSettingV2WorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#grid_line_color AccountSettingV2#grid_line_color}
    */
    readonly gridLineColor?: AccountSettingV2WorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#mark_corner_radius AccountSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#selection_color AccountSettingV2#selection_color}
    */
    readonly selectionColor?: AccountSettingV2WorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#sentiment_colors AccountSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: AccountSettingV2WorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#text_box_vertical_align AccountSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_01 AccountSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_02 AccountSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_03 AccountSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_04 AccountSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_05 AccountSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_06 AccountSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_07 AccountSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_08 AccountSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_09 AccountSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_10 AccountSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_11 AccountSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_12 AccountSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_13 AccountSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_14 AccountSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_15 AccountSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_16 AccountSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_17 AccountSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_18 AccountSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_19 AccountSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#visualization_color_20 AccountSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_background_color AccountSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_border_color AccountSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_corner_radius AccountSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_header_alignment AccountSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_margin AccountSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_padding AccountSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#widget_shadow AccountSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function accountSettingV2WorkspaceDashboardThemeToTerraform(struct?: AccountSettingV2WorkspaceDashboardTheme | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceDashboardThemeToHclTerraform(struct?: AccountSettingV2WorkspaceDashboardTheme | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceDashboardTheme | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceDashboardTheme | cdktn.IResolvable | undefined);
    private _axisLineColor;
    get axisLineColor(): AccountSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: AccountSettingV2WorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): AccountSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: AccountSettingV2WorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): AccountSettingV2WorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: AccountSettingV2WorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): AccountSettingV2WorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: AccountSettingV2WorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): AccountSettingV2WorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: AccountSettingV2WorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): AccountSettingV2WorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: AccountSettingV2WorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): AccountSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: AccountSettingV2WorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): AccountSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface AccountSettingV2WorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#color AccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#label AccountSettingV2#label}
    */
    readonly label?: string;
}
export declare function accountSettingV2WorkspaceLabelToTerraform(struct?: AccountSettingV2WorkspaceLabel | cdktn.IResolvable): any;
export declare function accountSettingV2WorkspaceLabelToHclTerraform(struct?: AccountSettingV2WorkspaceLabel | cdktn.IResolvable): any;
export declare class AccountSettingV2WorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2WorkspaceLabel | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2WorkspaceLabel | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2 databricks_account_setting_v2}
*/
export declare class AccountSettingV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_setting_v2";
    /**
    * Generates CDKTN code for importing a AccountSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountSettingV2 to import
    * @param importFromId The id of the existing AccountSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/resources/account_setting_v2 databricks_account_setting_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountSettingV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: AccountSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): AccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    putAibiDashboardEmbeddingAccessPolicy(value: AccountSettingV2AibiDashboardEmbeddingAccessPolicy): void;
    resetAibiDashboardEmbeddingAccessPolicy(): void;
    get aibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | AccountSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): AccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    putAibiDashboardEmbeddingApprovedDomains(value: AccountSettingV2AibiDashboardEmbeddingApprovedDomains): void;
    resetAibiDashboardEmbeddingApprovedDomains(): void;
    get aibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | AccountSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    private _allowedAppsUserApiScopes;
    get allowedAppsUserApiScopes(): AccountSettingV2AllowedAppsUserApiScopesOutputReference;
    putAllowedAppsUserApiScopes(value: AccountSettingV2AllowedAppsUserApiScopes): void;
    resetAllowedAppsUserApiScopes(): void;
    get allowedAppsUserApiScopesInput(): cdktn.IResolvable | AccountSettingV2AllowedAppsUserApiScopes | undefined;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): AccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    putAutomaticClusterUpdateWorkspace(value: AccountSettingV2AutomaticClusterUpdateWorkspace): void;
    resetAutomaticClusterUpdateWorkspace(): void;
    get automaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspace | undefined;
    private _booleanVal;
    get booleanVal(): AccountSettingV2BooleanValOutputReference;
    putBooleanVal(value: AccountSettingV2BooleanVal): void;
    resetBooleanVal(): void;
    get booleanValInput(): cdktn.IResolvable | AccountSettingV2BooleanVal | undefined;
    private _collaborationPlatformConnectivity;
    get collaborationPlatformConnectivity(): AccountSettingV2CollaborationPlatformConnectivityOutputReference;
    putCollaborationPlatformConnectivity(value: AccountSettingV2CollaborationPlatformConnectivity): void;
    resetCollaborationPlatformConnectivity(): void;
    get collaborationPlatformConnectivityInput(): cdktn.IResolvable | AccountSettingV2CollaborationPlatformConnectivity | undefined;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    putEffectiveAibiDashboardEmbeddingAccessPolicy(value: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): void;
    resetEffectiveAibiDashboardEmbeddingAccessPolicy(): void;
    get effectiveAibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    putEffectiveAibiDashboardEmbeddingApprovedDomains(value: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): void;
    resetEffectiveAibiDashboardEmbeddingApprovedDomains(): void;
    get effectiveAibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    private _effectiveAllowedAppsUserApiScopes;
    get effectiveAllowedAppsUserApiScopes(): AccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    putEffectiveAutomaticClusterUpdateWorkspace(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace): void;
    resetEffectiveAutomaticClusterUpdateWorkspace(): void;
    get effectiveAutomaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): AccountSettingV2EffectiveBooleanValOutputReference;
    private _effectiveCollaborationPlatformConnectivity;
    get effectiveCollaborationPlatformConnectivity(): AccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): AccountSettingV2EffectiveIntegerValOutputReference;
    private _effectiveOperationalEmailCustomRecipient;
    get effectiveOperationalEmailCustomRecipient(): AccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): AccountSettingV2EffectivePersonalComputeOutputReference;
    putEffectivePersonalCompute(value: AccountSettingV2EffectivePersonalCompute): void;
    resetEffectivePersonalCompute(): void;
    get effectivePersonalComputeInput(): cdktn.IResolvable | AccountSettingV2EffectivePersonalCompute | undefined;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): AccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    putEffectiveRestrictWorkspaceAdmins(value: AccountSettingV2EffectiveRestrictWorkspaceAdmins): void;
    resetEffectiveRestrictWorkspaceAdmins(): void;
    get effectiveRestrictWorkspaceAdminsInput(): cdktn.IResolvable | AccountSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    private _effectiveStringVal;
    get effectiveStringVal(): AccountSettingV2EffectiveStringValOutputReference;
    private _effectiveWorkspaceDashboardTheme;
    get effectiveWorkspaceDashboardTheme(): AccountSettingV2EffectiveWorkspaceDashboardThemeOutputReference;
    private _effectiveWorkspaceLabel;
    get effectiveWorkspaceLabel(): AccountSettingV2EffectiveWorkspaceLabelOutputReference;
    putEffectiveWorkspaceLabel(value: AccountSettingV2EffectiveWorkspaceLabel): void;
    resetEffectiveWorkspaceLabel(): void;
    get effectiveWorkspaceLabelInput(): cdktn.IResolvable | AccountSettingV2EffectiveWorkspaceLabel | undefined;
    private _integerVal;
    get integerVal(): AccountSettingV2IntegerValOutputReference;
    putIntegerVal(value: AccountSettingV2IntegerVal): void;
    resetIntegerVal(): void;
    get integerValInput(): cdktn.IResolvable | AccountSettingV2IntegerVal | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operationalEmailCustomRecipient;
    get operationalEmailCustomRecipient(): AccountSettingV2OperationalEmailCustomRecipientOutputReference;
    putOperationalEmailCustomRecipient(value: AccountSettingV2OperationalEmailCustomRecipient): void;
    resetOperationalEmailCustomRecipient(): void;
    get operationalEmailCustomRecipientInput(): cdktn.IResolvable | AccountSettingV2OperationalEmailCustomRecipient | undefined;
    private _personalCompute;
    get personalCompute(): AccountSettingV2PersonalComputeOutputReference;
    putPersonalCompute(value: AccountSettingV2PersonalCompute): void;
    resetPersonalCompute(): void;
    get personalComputeInput(): cdktn.IResolvable | AccountSettingV2PersonalCompute | undefined;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): AccountSettingV2RestrictWorkspaceAdminsOutputReference;
    putRestrictWorkspaceAdmins(value: AccountSettingV2RestrictWorkspaceAdmins): void;
    resetRestrictWorkspaceAdmins(): void;
    get restrictWorkspaceAdminsInput(): cdktn.IResolvable | AccountSettingV2RestrictWorkspaceAdmins | undefined;
    private _stringVal;
    get stringVal(): AccountSettingV2StringValOutputReference;
    putStringVal(value: AccountSettingV2StringVal): void;
    resetStringVal(): void;
    get stringValInput(): cdktn.IResolvable | AccountSettingV2StringVal | undefined;
    private _workspaceDashboardTheme;
    get workspaceDashboardTheme(): AccountSettingV2WorkspaceDashboardThemeOutputReference;
    putWorkspaceDashboardTheme(value: AccountSettingV2WorkspaceDashboardTheme): void;
    resetWorkspaceDashboardTheme(): void;
    get workspaceDashboardThemeInput(): cdktn.IResolvable | AccountSettingV2WorkspaceDashboardTheme | undefined;
    private _workspaceLabel;
    get workspaceLabel(): AccountSettingV2WorkspaceLabelOutputReference;
    putWorkspaceLabel(value: AccountSettingV2WorkspaceLabel): void;
    resetWorkspaceLabel(): void;
    get workspaceLabelInput(): cdktn.IResolvable | AccountSettingV2WorkspaceLabel | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
