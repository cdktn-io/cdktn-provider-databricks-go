/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchCommonConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#name DataDatabricksLakewatchCommonConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#provider_config DataDatabricksLakewatchCommonConfig#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchCommonConfigProviderConfig;
}
export interface DataDatabricksLakewatchCommonConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#workspace_id DataDatabricksLakewatchCommonConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchCommonConfigProviderConfigToTerraform(struct?: DataDatabricksLakewatchCommonConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchCommonConfigProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchCommonConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchCommonConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchCommonConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchCommonConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchCommonConfigUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#display_name DataDatabricksLakewatchCommonConfig#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#email DataDatabricksLakewatchCommonConfig#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#id DataDatabricksLakewatchCommonConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#principal_type DataDatabricksLakewatchCommonConfig#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchCommonConfigUpdatedByToTerraform(struct?: DataDatabricksLakewatchCommonConfigUpdatedBy): any;
export declare function dataDatabricksLakewatchCommonConfigUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchCommonConfigUpdatedBy): any;
export declare class DataDatabricksLakewatchCommonConfigUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchCommonConfigUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchCommonConfigUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config databricks_lakewatch_common_config}
*/
export declare class DataDatabricksLakewatchCommonConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_common_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchCommonConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchCommonConfig to import
    * @param importFromId The id of the existing DataDatabricksLakewatchCommonConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchCommonConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/lakewatch_common_config databricks_lakewatch_common_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchCommonConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchCommonConfigConfig);
    get etag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get perResourcePermissionsEnabled(): cdktn.IResolvable;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchCommonConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchCommonConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchCommonConfigProviderConfig | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchCommonConfigUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
