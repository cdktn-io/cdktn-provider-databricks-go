/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAssumeGroupRestrictedSharingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/assume_group_restricted_sharing_group#name DataDatabricksAssumeGroupRestrictedSharingGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/assume_group_restricted_sharing_group#provider_config DataDatabricksAssumeGroupRestrictedSharingGroup#provider_config}
    */
    readonly providerConfig?: DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig;
}
export interface DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/assume_group_restricted_sharing_group#workspace_id DataDatabricksAssumeGroupRestrictedSharingGroup#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupProviderConfigToTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAssumeGroupRestrictedSharingGroupProviderConfigToHclTerraform(struct?: DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/assume_group_restricted_sharing_group databricks_assume_group_restricted_sharing_group}
*/
export declare class DataDatabricksAssumeGroupRestrictedSharingGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_assume_group_restricted_sharing_group";
    /**
    * Generates CDKTN code for importing a DataDatabricksAssumeGroupRestrictedSharingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAssumeGroupRestrictedSharingGroup to import
    * @param importFromId The id of the existing DataDatabricksAssumeGroupRestrictedSharingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/assume_group_restricted_sharing_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAssumeGroupRestrictedSharingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/assume_group_restricted_sharing_group databricks_assume_group_restricted_sharing_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAssumeGroupRestrictedSharingGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAssumeGroupRestrictedSharingGroupConfig);
    get groupDisplayName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAssumeGroupRestrictedSharingGroupProviderConfig | undefined;
    get restrictedSharingGroupId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
