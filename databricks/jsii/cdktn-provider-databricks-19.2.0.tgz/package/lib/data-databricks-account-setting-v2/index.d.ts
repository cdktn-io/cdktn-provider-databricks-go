/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#name DataDatabricksAccountSettingV2#name}
    */
    readonly name: string;
}
export interface DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#access_policy_type DataDatabricksAccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#approved_domains DataDatabricksAccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2AllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#allowed_scopes DataDatabricksAccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksAccountSettingV2AllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksAccountSettingV2AllowedAppsUserApiScopes): any;
export declare function dataDatabricksAccountSettingV2AllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksAccountSettingV2AllowedAppsUserApiScopes): any;
export declare class DataDatabricksAccountSettingV2AllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#forced_for_compliance_mode DataDatabricksAccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#unavailable_for_disabled_entitlement DataDatabricksAccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksAccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#hours DataDatabricksAccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#minutes DataDatabricksAccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#day_of_week DataDatabricksAccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#frequency DataDatabricksAccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#window_start_time DataDatabricksAccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#week_day_based_schedule DataDatabricksAccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#can_toggle DataDatabricksAccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#enabled DataDatabricksAccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#enablement_details DataDatabricksAccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#maintenance_window DataDatabricksAccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#restart_even_if_no_updates_available DataDatabricksAccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2BooleanValToTerraform(struct?: DataDatabricksAccountSettingV2BooleanVal): any;
export declare function dataDatabricksAccountSettingV2BooleanValToHclTerraform(struct?: DataDatabricksAccountSettingV2BooleanVal): any;
export declare class DataDatabricksAccountSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2BooleanVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2BooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2CollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#connectivity DataDatabricksAccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksAccountSettingV2CollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksAccountSettingV2CollaborationPlatformConnectivity): any;
export declare function dataDatabricksAccountSettingV2CollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksAccountSettingV2CollaborationPlatformConnectivity): any;
export declare class DataDatabricksAccountSettingV2CollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2CollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2CollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#access_policy_type DataDatabricksAccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#approved_domains DataDatabricksAccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#allowed_scopes DataDatabricksAccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare function dataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare class DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#forced_for_compliance_mode DataDatabricksAccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#unavailable_for_disabled_entitlement DataDatabricksAccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksAccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#hours DataDatabricksAccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#minutes DataDatabricksAccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#day_of_week DataDatabricksAccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#frequency DataDatabricksAccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#window_start_time DataDatabricksAccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#week_day_based_schedule DataDatabricksAccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#can_toggle DataDatabricksAccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#enabled DataDatabricksAccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#enablement_details DataDatabricksAccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#maintenance_window DataDatabricksAccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#restart_even_if_no_updates_available DataDatabricksAccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2EffectiveBooleanValToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveBooleanVal): any;
export declare function dataDatabricksAccountSettingV2EffectiveBooleanValToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveBooleanVal): any;
export declare class DataDatabricksAccountSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#connectivity DataDatabricksAccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare function dataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare class DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksAccountSettingV2EffectiveIntegerValToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveIntegerVal): any;
export declare function dataDatabricksAccountSettingV2EffectiveIntegerValToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveIntegerVal): any;
export declare class DataDatabricksAccountSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#email DataDatabricksAccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare function dataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare class DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2EffectivePersonalComputeToTerraform(struct?: DataDatabricksAccountSettingV2EffectivePersonalCompute): any;
export declare function dataDatabricksAccountSettingV2EffectivePersonalComputeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectivePersonalCompute): any;
export declare class DataDatabricksAccountSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectivePersonalCompute | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectivePersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#disable_gov_tag_creation DataDatabricksAccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#status DataDatabricksAccountSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare function dataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare class DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveStringValToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveStringVal): any;
export declare function dataDatabricksAccountSettingV2EffectiveStringValToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveStringVal): any;
export declare class DataDatabricksAccountSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveStringVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#mid DataDatabricksAccountSettingV2#mid}
    */
    readonly mid?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color DataDatabricksAccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color_scheme DataDatabricksAccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_diverging DataDatabricksAccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_sequential DataDatabricksAccountSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#from_categorical_index DataDatabricksAccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#mid DataDatabricksAccountSettingV2#mid}
    */
    readonly mid?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color DataDatabricksAccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color_scheme DataDatabricksAccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_diverging DataDatabricksAccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_sequential DataDatabricksAccountSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#from_categorical_index DataDatabricksAccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark_mode DataDatabricksAccountSettingV2#dark_mode}
    */
    readonly darkMode?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light_mode DataDatabricksAccountSettingV2#light_mode}
    */
    readonly lightMode?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#base DataDatabricksAccountSettingV2#base}
    */
    readonly base?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#field_title DataDatabricksAccountSettingV2#field_title}
    */
    readonly fieldTitle?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#field_value DataDatabricksAccountSettingV2#field_value}
    */
    readonly fieldValue?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_description DataDatabricksAccountSettingV2#widget_description}
    */
    readonly widgetDescription?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_title DataDatabricksAccountSettingV2#widget_title}
    */
    readonly widgetTitle?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#negative DataDatabricksAccountSettingV2#negative}
    */
    readonly negative?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#neutral DataDatabricksAccountSettingV2#neutral}
    */
    readonly neutral?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#positive DataDatabricksAccountSettingV2#positive}
    */
    readonly positive?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#axis_line_color DataDatabricksAccountSettingV2#axis_line_color}
    */
    readonly axisLineColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#canvas_background_color DataDatabricksAccountSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#continuous_gradient DataDatabricksAccountSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_settings DataDatabricksAccountSettingV2#font_settings}
    */
    readonly fontSettings?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#grid_line_color DataDatabricksAccountSettingV2#grid_line_color}
    */
    readonly gridLineColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#mark_corner_radius DataDatabricksAccountSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#selection_color DataDatabricksAccountSettingV2#selection_color}
    */
    readonly selectionColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#sentiment_colors DataDatabricksAccountSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_box_vertical_align DataDatabricksAccountSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_01 DataDatabricksAccountSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_02 DataDatabricksAccountSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_03 DataDatabricksAccountSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_04 DataDatabricksAccountSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_05 DataDatabricksAccountSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_06 DataDatabricksAccountSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_07 DataDatabricksAccountSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_08 DataDatabricksAccountSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_09 DataDatabricksAccountSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_10 DataDatabricksAccountSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_11 DataDatabricksAccountSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_12 DataDatabricksAccountSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_13 DataDatabricksAccountSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_14 DataDatabricksAccountSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_15 DataDatabricksAccountSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_16 DataDatabricksAccountSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_17 DataDatabricksAccountSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_18 DataDatabricksAccountSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_19 DataDatabricksAccountSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_20 DataDatabricksAccountSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_background_color DataDatabricksAccountSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_border_color DataDatabricksAccountSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_corner_radius DataDatabricksAccountSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_header_alignment DataDatabricksAccountSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_margin DataDatabricksAccountSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_padding DataDatabricksAccountSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_shadow DataDatabricksAccountSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardTheme): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardTheme | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardTheme | undefined);
    private _axisLineColor;
    get axisLineColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveWorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color DataDatabricksAccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#label DataDatabricksAccountSettingV2#label}
    */
    readonly label?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceLabelToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceLabel): any;
export declare function dataDatabricksAccountSettingV2EffectiveWorkspaceLabelToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveWorkspaceLabel): any;
export declare class DataDatabricksAccountSettingV2EffectiveWorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveWorkspaceLabel | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveWorkspaceLabel | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksAccountSettingV2IntegerValToTerraform(struct?: DataDatabricksAccountSettingV2IntegerVal): any;
export declare function dataDatabricksAccountSettingV2IntegerValToHclTerraform(struct?: DataDatabricksAccountSettingV2IntegerVal): any;
export declare class DataDatabricksAccountSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2IntegerVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2IntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2OperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#email DataDatabricksAccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksAccountSettingV2OperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksAccountSettingV2OperationalEmailCustomRecipient): any;
export declare function dataDatabricksAccountSettingV2OperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksAccountSettingV2OperationalEmailCustomRecipient): any;
export declare class DataDatabricksAccountSettingV2OperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2OperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2OperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2PersonalComputeToTerraform(struct?: DataDatabricksAccountSettingV2PersonalCompute): any;
export declare function dataDatabricksAccountSettingV2PersonalComputeToHclTerraform(struct?: DataDatabricksAccountSettingV2PersonalCompute): any;
export declare class DataDatabricksAccountSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2PersonalCompute | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2PersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#disable_gov_tag_creation DataDatabricksAccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#status DataDatabricksAccountSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksAccountSettingV2RestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksAccountSettingV2RestrictWorkspaceAdmins): any;
export declare function dataDatabricksAccountSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksAccountSettingV2RestrictWorkspaceAdmins): any;
export declare class DataDatabricksAccountSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2RestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2RestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2StringValToTerraform(struct?: DataDatabricksAccountSettingV2StringVal): any;
export declare function dataDatabricksAccountSettingV2StringValToHclTerraform(struct?: DataDatabricksAccountSettingV2StringVal): any;
export declare class DataDatabricksAccountSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2StringVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2StringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#mid DataDatabricksAccountSettingV2#mid}
    */
    readonly mid?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingStart | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialStart | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color DataDatabricksAccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color_scheme DataDatabricksAccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_diverging DataDatabricksAccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_sequential DataDatabricksAccountSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#from_categorical_index DataDatabricksAccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#mid DataDatabricksAccountSettingV2#mid}
    */
    readonly mid?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingEnd | undefined;
    private _mid;
    get mid(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMidOutputReference;
    putMid(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid): void;
    resetMid(): void;
    get midInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingMid | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingStart | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#end DataDatabricksAccountSettingV2#end}
    */
    readonly end?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#start DataDatabricksAccountSettingV2#start}
    */
    readonly start?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | cdktn.IResolvable | undefined);
    private _end;
    get end(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEndOutputReference;
    putEnd(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd): void;
    resetEnd(): void;
    get endInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialEnd | undefined;
    private _start;
    get start(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStartOutputReference;
    putStart(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart): void;
    resetStart(): void;
    get startInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialStart | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color DataDatabricksAccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color_scheme DataDatabricksAccountSettingV2#color_scheme}
    */
    readonly colorScheme?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_diverging DataDatabricksAccountSettingV2#custom_diverging}
    */
    readonly customDiverging?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#custom_sequential DataDatabricksAccountSettingV2#custom_sequential}
    */
    readonly customSequential?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#from_categorical_index DataDatabricksAccountSettingV2#from_categorical_index}
    */
    readonly fromCategoricalIndex?: number;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | cdktn.IResolvable | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _colorScheme?;
    get colorScheme(): string;
    set colorScheme(value: string);
    resetColorScheme(): void;
    get colorSchemeInput(): string | undefined;
    private _customDiverging;
    get customDiverging(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDivergingOutputReference;
    putCustomDiverging(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging): void;
    resetCustomDiverging(): void;
    get customDivergingInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomDiverging | undefined;
    private _customSequential;
    get customSequential(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequentialOutputReference;
    putCustomSequential(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential): void;
    resetCustomSequential(): void;
    get customSequentialInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeCustomSequential | undefined;
    private _fromCategoricalIndex?;
    get fromCategoricalIndex(): number;
    set fromCategoricalIndex(value: number);
    resetFromCategoricalIndex(): void;
    get fromCategoricalIndexInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark_mode DataDatabricksAccountSettingV2#dark_mode}
    */
    readonly darkMode?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light_mode DataDatabricksAccountSettingV2#light_mode}
    */
    readonly lightMode?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient | cdktn.IResolvable | undefined);
    private _darkMode;
    get darkMode(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkModeOutputReference;
    putDarkMode(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode): void;
    resetDarkMode(): void;
    get darkModeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientDarkMode | undefined;
    private _lightMode;
    get lightMode(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightModeOutputReference;
    putLightMode(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode): void;
    resetLightMode(): void;
    get lightModeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientLightMode | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_size DataDatabricksAccountSettingV2#font_size}
    */
    readonly fontSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_style DataDatabricksAccountSettingV2#font_style}
    */
    readonly fontStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_weight DataDatabricksAccountSettingV2#font_weight}
    */
    readonly fontWeight?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_case DataDatabricksAccountSettingV2#text_case}
    */
    readonly textCase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_decoration DataDatabricksAccountSettingV2#text_decoration}
    */
    readonly textDecoration?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | cdktn.IResolvable | undefined);
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSize?;
    get fontSize(): number;
    set fontSize(value: number);
    resetFontSize(): void;
    get fontSizeInput(): number | undefined;
    private _fontStyle?;
    get fontStyle(): string;
    set fontStyle(value: string);
    resetFontStyle(): void;
    get fontStyleInput(): string | undefined;
    private _fontWeight?;
    get fontWeight(): number;
    set fontWeight(value: number);
    resetFontWeight(): void;
    get fontWeightInput(): number | undefined;
    private _textCase?;
    get textCase(): string;
    set textCase(value: string);
    resetTextCase(): void;
    get textCaseInput(): string | undefined;
    private _textDecoration?;
    get textDecoration(): string;
    set textDecoration(value: string);
    resetTextDecoration(): void;
    get textDecorationInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#base DataDatabricksAccountSettingV2#base}
    */
    readonly base?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#field_title DataDatabricksAccountSettingV2#field_title}
    */
    readonly fieldTitle?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#field_value DataDatabricksAccountSettingV2#field_value}
    */
    readonly fieldValue?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_description DataDatabricksAccountSettingV2#widget_description}
    */
    readonly widgetDescription?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_title DataDatabricksAccountSettingV2#widget_title}
    */
    readonly widgetTitle?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings | cdktn.IResolvable | undefined);
    private _base;
    get base(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBaseOutputReference;
    putBase(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase): void;
    resetBase(): void;
    get baseInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsBase | undefined;
    private _fieldTitle;
    get fieldTitle(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitleOutputReference;
    putFieldTitle(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle): void;
    resetFieldTitle(): void;
    get fieldTitleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldTitle | undefined;
    private _fieldValue;
    get fieldValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValueOutputReference;
    putFieldValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue): void;
    resetFieldValue(): void;
    get fieldValueInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsFieldValue | undefined;
    private _widgetDescription;
    get widgetDescription(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescriptionOutputReference;
    putWidgetDescription(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription): void;
    resetWidgetDescription(): void;
    get widgetDescriptionInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetDescription | undefined;
    private _widgetTitle;
    get widgetTitle(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitleOutputReference;
    putWidgetTitle(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle): void;
    resetWidgetTitle(): void;
    get widgetTitleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsWidgetTitle | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#negative DataDatabricksAccountSettingV2#negative}
    */
    readonly negative?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#neutral DataDatabricksAccountSettingV2#neutral}
    */
    readonly neutral?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#positive DataDatabricksAccountSettingV2#positive}
    */
    readonly positive?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors | cdktn.IResolvable | undefined);
    private _negative;
    get negative(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegativeOutputReference;
    putNegative(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative): void;
    resetNegative(): void;
    get negativeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNegative | undefined;
    private _neutral;
    get neutral(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutralOutputReference;
    putNeutral(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral): void;
    resetNeutral(): void;
    get neutralInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsNeutral | undefined;
    private _positive;
    get positive(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositiveOutputReference;
    putPositive(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive): void;
    resetPositive(): void;
    get positiveInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsPositive | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#dark DataDatabricksAccountSettingV2#dark}
    */
    readonly dark?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#light DataDatabricksAccountSettingV2#light}
    */
    readonly light?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColorToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColorToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | cdktn.IResolvable | undefined);
    private _dark?;
    get dark(): string;
    set dark(value: string);
    resetDark(): void;
    get darkInput(): string | undefined;
    private _light?;
    get light(): string;
    set light(value: string);
    resetLight(): void;
    get lightInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceDashboardTheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#axis_line_color DataDatabricksAccountSettingV2#axis_line_color}
    */
    readonly axisLineColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#canvas_background_color DataDatabricksAccountSettingV2#canvas_background_color}
    */
    readonly canvasBackgroundColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#continuous_gradient DataDatabricksAccountSettingV2#continuous_gradient}
    */
    readonly continuousGradient?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_color DataDatabricksAccountSettingV2#font_color}
    */
    readonly fontColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_family DataDatabricksAccountSettingV2#font_family}
    */
    readonly fontFamily?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#font_settings DataDatabricksAccountSettingV2#font_settings}
    */
    readonly fontSettings?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#grid_line_color DataDatabricksAccountSettingV2#grid_line_color}
    */
    readonly gridLineColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#mark_corner_radius DataDatabricksAccountSettingV2#mark_corner_radius}
    */
    readonly markCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#selection_color DataDatabricksAccountSettingV2#selection_color}
    */
    readonly selectionColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#sentiment_colors DataDatabricksAccountSettingV2#sentiment_colors}
    */
    readonly sentimentColors?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#text_box_vertical_align DataDatabricksAccountSettingV2#text_box_vertical_align}
    */
    readonly textBoxVerticalAlign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_01 DataDatabricksAccountSettingV2#visualization_color_01}
    */
    readonly visualizationColor01?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_02 DataDatabricksAccountSettingV2#visualization_color_02}
    */
    readonly visualizationColor02?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_03 DataDatabricksAccountSettingV2#visualization_color_03}
    */
    readonly visualizationColor03?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_04 DataDatabricksAccountSettingV2#visualization_color_04}
    */
    readonly visualizationColor04?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_05 DataDatabricksAccountSettingV2#visualization_color_05}
    */
    readonly visualizationColor05?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_06 DataDatabricksAccountSettingV2#visualization_color_06}
    */
    readonly visualizationColor06?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_07 DataDatabricksAccountSettingV2#visualization_color_07}
    */
    readonly visualizationColor07?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_08 DataDatabricksAccountSettingV2#visualization_color_08}
    */
    readonly visualizationColor08?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_09 DataDatabricksAccountSettingV2#visualization_color_09}
    */
    readonly visualizationColor09?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_10 DataDatabricksAccountSettingV2#visualization_color_10}
    */
    readonly visualizationColor10?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_11 DataDatabricksAccountSettingV2#visualization_color_11}
    */
    readonly visualizationColor11?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_12 DataDatabricksAccountSettingV2#visualization_color_12}
    */
    readonly visualizationColor12?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_13 DataDatabricksAccountSettingV2#visualization_color_13}
    */
    readonly visualizationColor13?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_14 DataDatabricksAccountSettingV2#visualization_color_14}
    */
    readonly visualizationColor14?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_15 DataDatabricksAccountSettingV2#visualization_color_15}
    */
    readonly visualizationColor15?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_16 DataDatabricksAccountSettingV2#visualization_color_16}
    */
    readonly visualizationColor16?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_17 DataDatabricksAccountSettingV2#visualization_color_17}
    */
    readonly visualizationColor17?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_18 DataDatabricksAccountSettingV2#visualization_color_18}
    */
    readonly visualizationColor18?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_19 DataDatabricksAccountSettingV2#visualization_color_19}
    */
    readonly visualizationColor19?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#visualization_color_20 DataDatabricksAccountSettingV2#visualization_color_20}
    */
    readonly visualizationColor20?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_background_color DataDatabricksAccountSettingV2#widget_background_color}
    */
    readonly widgetBackgroundColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_border_color DataDatabricksAccountSettingV2#widget_border_color}
    */
    readonly widgetBorderColor?: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_corner_radius DataDatabricksAccountSettingV2#widget_corner_radius}
    */
    readonly widgetCornerRadius?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_header_alignment DataDatabricksAccountSettingV2#widget_header_alignment}
    */
    readonly widgetHeaderAlignment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_margin DataDatabricksAccountSettingV2#widget_margin}
    */
    readonly widgetMargin?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_padding DataDatabricksAccountSettingV2#widget_padding}
    */
    readonly widgetPadding?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#widget_shadow DataDatabricksAccountSettingV2#widget_shadow}
    */
    readonly widgetShadow?: number;
}
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardTheme): any;
export declare function dataDatabricksAccountSettingV2WorkspaceDashboardThemeToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceDashboardTheme): any;
export declare class DataDatabricksAccountSettingV2WorkspaceDashboardThemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceDashboardTheme | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceDashboardTheme | undefined);
    private _axisLineColor;
    get axisLineColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColorOutputReference;
    putAxisLineColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor): void;
    resetAxisLineColor(): void;
    get axisLineColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeAxisLineColor | undefined;
    private _canvasBackgroundColor;
    get canvasBackgroundColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColorOutputReference;
    putCanvasBackgroundColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor): void;
    resetCanvasBackgroundColor(): void;
    get canvasBackgroundColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeCanvasBackgroundColor | undefined;
    private _continuousGradient;
    get continuousGradient(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradientOutputReference;
    putContinuousGradient(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient): void;
    resetContinuousGradient(): void;
    get continuousGradientInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeContinuousGradient | undefined;
    private _fontColor;
    get fontColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColorOutputReference;
    putFontColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor): void;
    resetFontColor(): void;
    get fontColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontColor | undefined;
    private _fontFamily?;
    get fontFamily(): string;
    set fontFamily(value: string);
    resetFontFamily(): void;
    get fontFamilyInput(): string | undefined;
    private _fontSettings;
    get fontSettings(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettingsOutputReference;
    putFontSettings(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings): void;
    resetFontSettings(): void;
    get fontSettingsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeFontSettings | undefined;
    private _gridLineColor;
    get gridLineColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColorOutputReference;
    putGridLineColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor): void;
    resetGridLineColor(): void;
    get gridLineColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeGridLineColor | undefined;
    private _markCornerRadius?;
    get markCornerRadius(): number;
    set markCornerRadius(value: number);
    resetMarkCornerRadius(): void;
    get markCornerRadiusInput(): number | undefined;
    private _selectionColor;
    get selectionColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColorOutputReference;
    putSelectionColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor): void;
    resetSelectionColor(): void;
    get selectionColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeSelectionColor | undefined;
    private _sentimentColors;
    get sentimentColors(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColorsOutputReference;
    putSentimentColors(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors): void;
    resetSentimentColors(): void;
    get sentimentColorsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeSentimentColors | undefined;
    private _textBoxVerticalAlign?;
    get textBoxVerticalAlign(): string;
    set textBoxVerticalAlign(value: string);
    resetTextBoxVerticalAlign(): void;
    get textBoxVerticalAlignInput(): string | undefined;
    private _visualizationColor01?;
    get visualizationColor01(): string;
    set visualizationColor01(value: string);
    resetVisualizationColor01(): void;
    get visualizationColor01Input(): string | undefined;
    private _visualizationColor02?;
    get visualizationColor02(): string;
    set visualizationColor02(value: string);
    resetVisualizationColor02(): void;
    get visualizationColor02Input(): string | undefined;
    private _visualizationColor03?;
    get visualizationColor03(): string;
    set visualizationColor03(value: string);
    resetVisualizationColor03(): void;
    get visualizationColor03Input(): string | undefined;
    private _visualizationColor04?;
    get visualizationColor04(): string;
    set visualizationColor04(value: string);
    resetVisualizationColor04(): void;
    get visualizationColor04Input(): string | undefined;
    private _visualizationColor05?;
    get visualizationColor05(): string;
    set visualizationColor05(value: string);
    resetVisualizationColor05(): void;
    get visualizationColor05Input(): string | undefined;
    private _visualizationColor06?;
    get visualizationColor06(): string;
    set visualizationColor06(value: string);
    resetVisualizationColor06(): void;
    get visualizationColor06Input(): string | undefined;
    private _visualizationColor07?;
    get visualizationColor07(): string;
    set visualizationColor07(value: string);
    resetVisualizationColor07(): void;
    get visualizationColor07Input(): string | undefined;
    private _visualizationColor08?;
    get visualizationColor08(): string;
    set visualizationColor08(value: string);
    resetVisualizationColor08(): void;
    get visualizationColor08Input(): string | undefined;
    private _visualizationColor09?;
    get visualizationColor09(): string;
    set visualizationColor09(value: string);
    resetVisualizationColor09(): void;
    get visualizationColor09Input(): string | undefined;
    private _visualizationColor10?;
    get visualizationColor10(): string;
    set visualizationColor10(value: string);
    resetVisualizationColor10(): void;
    get visualizationColor10Input(): string | undefined;
    private _visualizationColor11?;
    get visualizationColor11(): string;
    set visualizationColor11(value: string);
    resetVisualizationColor11(): void;
    get visualizationColor11Input(): string | undefined;
    private _visualizationColor12?;
    get visualizationColor12(): string;
    set visualizationColor12(value: string);
    resetVisualizationColor12(): void;
    get visualizationColor12Input(): string | undefined;
    private _visualizationColor13?;
    get visualizationColor13(): string;
    set visualizationColor13(value: string);
    resetVisualizationColor13(): void;
    get visualizationColor13Input(): string | undefined;
    private _visualizationColor14?;
    get visualizationColor14(): string;
    set visualizationColor14(value: string);
    resetVisualizationColor14(): void;
    get visualizationColor14Input(): string | undefined;
    private _visualizationColor15?;
    get visualizationColor15(): string;
    set visualizationColor15(value: string);
    resetVisualizationColor15(): void;
    get visualizationColor15Input(): string | undefined;
    private _visualizationColor16?;
    get visualizationColor16(): string;
    set visualizationColor16(value: string);
    resetVisualizationColor16(): void;
    get visualizationColor16Input(): string | undefined;
    private _visualizationColor17?;
    get visualizationColor17(): string;
    set visualizationColor17(value: string);
    resetVisualizationColor17(): void;
    get visualizationColor17Input(): string | undefined;
    private _visualizationColor18?;
    get visualizationColor18(): string;
    set visualizationColor18(value: string);
    resetVisualizationColor18(): void;
    get visualizationColor18Input(): string | undefined;
    private _visualizationColor19?;
    get visualizationColor19(): string;
    set visualizationColor19(value: string);
    resetVisualizationColor19(): void;
    get visualizationColor19Input(): string | undefined;
    private _visualizationColor20?;
    get visualizationColor20(): string;
    set visualizationColor20(value: string);
    resetVisualizationColor20(): void;
    get visualizationColor20Input(): string | undefined;
    private _widgetBackgroundColor;
    get widgetBackgroundColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColorOutputReference;
    putWidgetBackgroundColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor): void;
    resetWidgetBackgroundColor(): void;
    get widgetBackgroundColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBackgroundColor | undefined;
    private _widgetBorderColor;
    get widgetBorderColor(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColorOutputReference;
    putWidgetBorderColor(value: DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor): void;
    resetWidgetBorderColor(): void;
    get widgetBorderColorInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2WorkspaceDashboardThemeWidgetBorderColor | undefined;
    private _widgetCornerRadius?;
    get widgetCornerRadius(): number;
    set widgetCornerRadius(value: number);
    resetWidgetCornerRadius(): void;
    get widgetCornerRadiusInput(): number | undefined;
    private _widgetHeaderAlignment?;
    get widgetHeaderAlignment(): string;
    set widgetHeaderAlignment(value: string);
    resetWidgetHeaderAlignment(): void;
    get widgetHeaderAlignmentInput(): string | undefined;
    private _widgetMargin?;
    get widgetMargin(): number;
    set widgetMargin(value: number);
    resetWidgetMargin(): void;
    get widgetMarginInput(): number | undefined;
    private _widgetPadding?;
    get widgetPadding(): number;
    set widgetPadding(value: number);
    resetWidgetPadding(): void;
    get widgetPaddingInput(): number | undefined;
    private _widgetShadow?;
    get widgetShadow(): number;
    set widgetShadow(value: number);
    resetWidgetShadow(): void;
    get widgetShadowInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2WorkspaceLabel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#color DataDatabricksAccountSettingV2#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#label DataDatabricksAccountSettingV2#label}
    */
    readonly label?: string;
}
export declare function dataDatabricksAccountSettingV2WorkspaceLabelToTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceLabel): any;
export declare function dataDatabricksAccountSettingV2WorkspaceLabelToHclTerraform(struct?: DataDatabricksAccountSettingV2WorkspaceLabel): any;
export declare class DataDatabricksAccountSettingV2WorkspaceLabelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2WorkspaceLabel | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2WorkspaceLabel | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2 databricks_account_setting_v2}
*/
export declare class DataDatabricksAccountSettingV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_setting_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountSettingV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.144.0/docs/data-sources/account_setting_v2 databricks_account_setting_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountSettingV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _allowedAppsUserApiScopes;
    get allowedAppsUserApiScopes(): DataDatabricksAccountSettingV2AllowedAppsUserApiScopesOutputReference;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    private _booleanVal;
    get booleanVal(): DataDatabricksAccountSettingV2BooleanValOutputReference;
    private _collaborationPlatformConnectivity;
    get collaborationPlatformConnectivity(): DataDatabricksAccountSettingV2CollaborationPlatformConnectivityOutputReference;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _effectiveAllowedAppsUserApiScopes;
    get effectiveAllowedAppsUserApiScopes(): DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): DataDatabricksAccountSettingV2EffectiveBooleanValOutputReference;
    private _effectiveCollaborationPlatformConnectivity;
    get effectiveCollaborationPlatformConnectivity(): DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): DataDatabricksAccountSettingV2EffectiveIntegerValOutputReference;
    private _effectiveOperationalEmailCustomRecipient;
    get effectiveOperationalEmailCustomRecipient(): DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): DataDatabricksAccountSettingV2EffectivePersonalComputeOutputReference;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    private _effectiveStringVal;
    get effectiveStringVal(): DataDatabricksAccountSettingV2EffectiveStringValOutputReference;
    private _effectiveWorkspaceDashboardTheme;
    get effectiveWorkspaceDashboardTheme(): DataDatabricksAccountSettingV2EffectiveWorkspaceDashboardThemeOutputReference;
    private _effectiveWorkspaceLabel;
    get effectiveWorkspaceLabel(): DataDatabricksAccountSettingV2EffectiveWorkspaceLabelOutputReference;
    private _integerVal;
    get integerVal(): DataDatabricksAccountSettingV2IntegerValOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationalEmailCustomRecipient;
    get operationalEmailCustomRecipient(): DataDatabricksAccountSettingV2OperationalEmailCustomRecipientOutputReference;
    private _personalCompute;
    get personalCompute(): DataDatabricksAccountSettingV2PersonalComputeOutputReference;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): DataDatabricksAccountSettingV2RestrictWorkspaceAdminsOutputReference;
    private _stringVal;
    get stringVal(): DataDatabricksAccountSettingV2StringValOutputReference;
    private _workspaceDashboardTheme;
    get workspaceDashboardTheme(): DataDatabricksAccountSettingV2WorkspaceDashboardThemeOutputReference;
    private _workspaceLabel;
    get workspaceLabel(): DataDatabricksAccountSettingV2WorkspaceLabelOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
