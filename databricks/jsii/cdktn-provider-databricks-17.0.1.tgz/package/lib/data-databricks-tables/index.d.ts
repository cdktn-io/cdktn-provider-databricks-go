/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksTablesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables#catalog_name DataDatabricksTables#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables#id DataDatabricksTables#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables#ids DataDatabricksTables#ids}
    */
    readonly ids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables#schema_name DataDatabricksTables#schema_name}
    */
    readonly schemaName: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables#provider_config DataDatabricksTables#provider_config}
    */
    readonly providerConfig?: DataDatabricksTablesProviderConfig;
}
export interface DataDatabricksTablesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables#workspace_id DataDatabricksTables#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksTablesProviderConfigToTerraform(struct?: DataDatabricksTablesProviderConfigOutputReference | DataDatabricksTablesProviderConfig): any;
export declare function dataDatabricksTablesProviderConfigToHclTerraform(struct?: DataDatabricksTablesProviderConfigOutputReference | DataDatabricksTablesProviderConfig): any;
export declare class DataDatabricksTablesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTablesProviderConfig | undefined;
    set internalValue(value: DataDatabricksTablesProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables databricks_tables}
*/
export declare class DataDatabricksTables extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_tables";
    /**
    * Generates CDKTN code for importing a DataDatabricksTables resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksTables to import
    * @param importFromId The id of the existing DataDatabricksTables that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksTables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/tables databricks_tables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksTablesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksTablesConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksTablesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksTablesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksTablesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
