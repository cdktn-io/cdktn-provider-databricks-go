/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WarehousesDefaultWarehouseOverrideConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override#default_warehouse_override_id WarehousesDefaultWarehouseOverride#default_warehouse_override_id}
    */
    readonly defaultWarehouseOverrideId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override#provider_config WarehousesDefaultWarehouseOverride#provider_config}
    */
    readonly providerConfig?: WarehousesDefaultWarehouseOverrideProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override#type WarehousesDefaultWarehouseOverride#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override#warehouse_id WarehousesDefaultWarehouseOverride#warehouse_id}
    */
    readonly warehouseId?: string;
}
export interface WarehousesDefaultWarehouseOverrideProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override#workspace_id WarehousesDefaultWarehouseOverride#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function warehousesDefaultWarehouseOverrideProviderConfigToTerraform(struct?: WarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable): any;
export declare function warehousesDefaultWarehouseOverrideProviderConfigToHclTerraform(struct?: WarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable): any;
export declare class WarehousesDefaultWarehouseOverrideProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override databricks_warehouses_default_warehouse_override}
*/
export declare class WarehousesDefaultWarehouseOverride extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_warehouses_default_warehouse_override";
    /**
    * Generates CDKTN code for importing a WarehousesDefaultWarehouseOverride resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WarehousesDefaultWarehouseOverride to import
    * @param importFromId The id of the existing WarehousesDefaultWarehouseOverride that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WarehousesDefaultWarehouseOverride to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/warehouses_default_warehouse_override databricks_warehouses_default_warehouse_override} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WarehousesDefaultWarehouseOverrideConfig
    */
    constructor(scope: Construct, id: string, config: WarehousesDefaultWarehouseOverrideConfig);
    private _defaultWarehouseOverrideId?;
    get defaultWarehouseOverrideId(): string;
    set defaultWarehouseOverrideId(value: string);
    get defaultWarehouseOverrideIdInput(): string | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): WarehousesDefaultWarehouseOverrideProviderConfigOutputReference;
    putProviderConfig(value: WarehousesDefaultWarehouseOverrideProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WarehousesDefaultWarehouseOverrideProviderConfig | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
