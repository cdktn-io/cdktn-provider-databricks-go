/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DisableLegacyAccessSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#etag DisableLegacyAccessSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#id DisableLegacyAccessSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#setting_name DisableLegacyAccessSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * disable_legacy_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#disable_legacy_access DisableLegacyAccessSetting#disable_legacy_access}
    */
    readonly disableLegacyAccess: DisableLegacyAccessSettingDisableLegacyAccess;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#provider_config DisableLegacyAccessSetting#provider_config}
    */
    readonly providerConfig?: DisableLegacyAccessSettingProviderConfig;
}
export interface DisableLegacyAccessSettingDisableLegacyAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#value DisableLegacyAccessSetting#value}
    */
    readonly value: boolean | cdktn.IResolvable;
}
export declare function disableLegacyAccessSettingDisableLegacyAccessToTerraform(struct?: DisableLegacyAccessSettingDisableLegacyAccessOutputReference | DisableLegacyAccessSettingDisableLegacyAccess): any;
export declare function disableLegacyAccessSettingDisableLegacyAccessToHclTerraform(struct?: DisableLegacyAccessSettingDisableLegacyAccessOutputReference | DisableLegacyAccessSettingDisableLegacyAccess): any;
export declare class DisableLegacyAccessSettingDisableLegacyAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisableLegacyAccessSettingDisableLegacyAccess | undefined;
    set internalValue(value: DisableLegacyAccessSettingDisableLegacyAccess | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DisableLegacyAccessSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#workspace_id DisableLegacyAccessSetting#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function disableLegacyAccessSettingProviderConfigToTerraform(struct?: DisableLegacyAccessSettingProviderConfigOutputReference | DisableLegacyAccessSettingProviderConfig): any;
export declare function disableLegacyAccessSettingProviderConfigToHclTerraform(struct?: DisableLegacyAccessSettingProviderConfigOutputReference | DisableLegacyAccessSettingProviderConfig): any;
export declare class DisableLegacyAccessSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisableLegacyAccessSettingProviderConfig | undefined;
    set internalValue(value: DisableLegacyAccessSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting databricks_disable_legacy_access_setting}
*/
export declare class DisableLegacyAccessSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_disable_legacy_access_setting";
    /**
    * Generates CDKTN code for importing a DisableLegacyAccessSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisableLegacyAccessSetting to import
    * @param importFromId The id of the existing DisableLegacyAccessSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisableLegacyAccessSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/disable_legacy_access_setting databricks_disable_legacy_access_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisableLegacyAccessSettingConfig
    */
    constructor(scope: Construct, id: string, config: DisableLegacyAccessSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _disableLegacyAccess;
    get disableLegacyAccess(): DisableLegacyAccessSettingDisableLegacyAccessOutputReference;
    putDisableLegacyAccess(value: DisableLegacyAccessSettingDisableLegacyAccess): void;
    get disableLegacyAccessInput(): DisableLegacyAccessSettingDisableLegacyAccess | undefined;
    private _providerConfig;
    get providerConfig(): DisableLegacyAccessSettingProviderConfigOutputReference;
    putProviderConfig(value: DisableLegacyAccessSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DisableLegacyAccessSettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
