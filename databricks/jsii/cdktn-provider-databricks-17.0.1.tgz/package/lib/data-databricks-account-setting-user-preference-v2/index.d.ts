/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountSettingUserPreferenceV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2#name DataDatabricksAccountSettingUserPreferenceV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2#user_id DataDatabricksAccountSettingUserPreferenceV2#user_id}
    */
    readonly userId: string;
}
export interface DataDatabricksAccountSettingUserPreferenceV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2#value DataDatabricksAccountSettingUserPreferenceV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingUserPreferenceV2BooleanValToTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2BooleanVal): any;
export declare function dataDatabricksAccountSettingUserPreferenceV2BooleanValToHclTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2BooleanVal): any;
export declare class DataDatabricksAccountSettingUserPreferenceV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingUserPreferenceV2BooleanVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingUserPreferenceV2BooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2#value DataDatabricksAccountSettingUserPreferenceV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanValToTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanVal): any;
export declare function dataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanValToHclTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanVal): any;
export declare class DataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingUserPreferenceV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2#value DataDatabricksAccountSettingUserPreferenceV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingUserPreferenceV2EffectiveStringValToTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2EffectiveStringVal): any;
export declare function dataDatabricksAccountSettingUserPreferenceV2EffectiveStringValToHclTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2EffectiveStringVal): any;
export declare class DataDatabricksAccountSettingUserPreferenceV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingUserPreferenceV2EffectiveStringVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingUserPreferenceV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingUserPreferenceV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2#value DataDatabricksAccountSettingUserPreferenceV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingUserPreferenceV2StringValToTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2StringVal): any;
export declare function dataDatabricksAccountSettingUserPreferenceV2StringValToHclTerraform(struct?: DataDatabricksAccountSettingUserPreferenceV2StringVal): any;
export declare class DataDatabricksAccountSettingUserPreferenceV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingUserPreferenceV2StringVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingUserPreferenceV2StringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2 databricks_account_setting_user_preference_v2}
*/
export declare class DataDatabricksAccountSettingUserPreferenceV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_setting_user_preference_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountSettingUserPreferenceV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountSettingUserPreferenceV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountSettingUserPreferenceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountSettingUserPreferenceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/data-sources/account_setting_user_preference_v2 databricks_account_setting_user_preference_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountSettingUserPreferenceV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountSettingUserPreferenceV2Config);
    private _booleanVal;
    get booleanVal(): DataDatabricksAccountSettingUserPreferenceV2BooleanValOutputReference;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): DataDatabricksAccountSettingUserPreferenceV2EffectiveBooleanValOutputReference;
    private _effectiveStringVal;
    get effectiveStringVal(): DataDatabricksAccountSettingUserPreferenceV2EffectiveStringValOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _stringVal;
    get stringVal(): DataDatabricksAccountSettingUserPreferenceV2StringValOutputReference;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
