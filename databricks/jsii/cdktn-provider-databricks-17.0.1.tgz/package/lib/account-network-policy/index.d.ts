/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountNetworkPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#account_id AccountNetworkPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#egress AccountNetworkPolicy#egress}
    */
    readonly egress?: AccountNetworkPolicyEgress;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ingress AccountNetworkPolicy#ingress}
    */
    readonly ingress?: AccountNetworkPolicyIngress;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ingress_dry_run AccountNetworkPolicy#ingress_dry_run}
    */
    readonly ingressDryRun?: AccountNetworkPolicyIngressDryRun;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#network_policy_id AccountNetworkPolicy#network_policy_id}
    */
    readonly networkPolicyId?: string;
}
export interface AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#internet_destination_type AccountNetworkPolicy#internet_destination_type}
    */
    readonly internetDestinationType?: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _internetDestinationType?;
    get internetDestinationType(): string;
    set internetDestinationType(value: string);
    resetInternetDestinationType(): void;
    get internetDestinationTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsOutputReference;
}
export interface AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#azure_storage_account AccountNetworkPolicy#azure_storage_account}
    */
    readonly azureStorageAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#azure_storage_service AccountNetworkPolicy#azure_storage_service}
    */
    readonly azureStorageService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#bucket_name AccountNetworkPolicy#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#region AccountNetworkPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#storage_destination_type AccountNetworkPolicy#storage_destination_type}
    */
    readonly storageDestinationType?: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined);
    private _azureStorageAccount?;
    get azureStorageAccount(): string;
    set azureStorageAccount(value: string);
    resetAzureStorageAccount(): void;
    get azureStorageAccountInput(): string | undefined;
    private _azureStorageService?;
    get azureStorageService(): string;
    set azureStorageService(value: string);
    resetAzureStorageService(): void;
    get azureStorageServiceInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageDestinationType?;
    get storageDestinationType(): string;
    set storageDestinationType(value: string);
    resetStorageDestinationType(): void;
    get storageDestinationTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsOutputReference;
}
export interface AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#dry_run_mode_product_filter AccountNetworkPolicy#dry_run_mode_product_filter}
    */
    readonly dryRunModeProductFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#enforcement_mode AccountNetworkPolicy#enforcement_mode}
    */
    readonly enforcementMode?: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessPolicyEnforcementToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessPolicyEnforcementToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessPolicyEnforcementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined);
    private _dryRunModeProductFilter?;
    get dryRunModeProductFilter(): string[];
    set dryRunModeProductFilter(value: string[]);
    resetDryRunModeProductFilter(): void;
    get dryRunModeProductFilterInput(): string[] | undefined;
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    resetEnforcementMode(): void;
    get enforcementModeInput(): string | undefined;
}
export interface AccountNetworkPolicyEgressNetworkAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#allowed_internet_destinations AccountNetworkPolicy#allowed_internet_destinations}
    */
    readonly allowedInternetDestinations?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#allowed_storage_destinations AccountNetworkPolicy#allowed_storage_destinations}
    */
    readonly allowedStorageDestinations?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#policy_enforcement AccountNetworkPolicy#policy_enforcement}
    */
    readonly policyEnforcement?: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable | undefined);
    private _allowedInternetDestinations;
    get allowedInternetDestinations(): AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsList;
    putAllowedInternetDestinations(value: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable): void;
    resetAllowedInternetDestinations(): void;
    get allowedInternetDestinationsInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | undefined;
    private _allowedStorageDestinations;
    get allowedStorageDestinations(): AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsList;
    putAllowedStorageDestinations(value: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable): void;
    resetAllowedStorageDestinations(): void;
    get allowedStorageDestinationsInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | undefined;
    private _policyEnforcement;
    get policyEnforcement(): AccountNetworkPolicyEgressNetworkAccessPolicyEnforcementOutputReference;
    putPolicyEnforcement(value: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement): void;
    resetPolicyEnforcement(): void;
    get policyEnforcementInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyEgress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#network_access AccountNetworkPolicy#network_access}
    */
    readonly networkAccess?: AccountNetworkPolicyEgressNetworkAccess;
}
export declare function accountNetworkPolicyEgressToTerraform(struct?: AccountNetworkPolicyEgress | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressToHclTerraform(struct?: AccountNetworkPolicyEgress | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyEgress | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgress | cdktn.IResolvable | undefined);
    private _networkAccess;
    get networkAccess(): AccountNetworkPolicyEgressNetworkAccessOutputReference;
    putNetworkAccess(value: AccountNetworkPolicyEgressNetworkAccess): void;
    resetNetworkAccess(): void;
    get networkAccessInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccess | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressPublicAccessToTerraform(struct?: AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressPublicAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressPublicAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#public_access AccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: AccountNetworkPolicyIngressPublicAccess;
}
export declare function accountNetworkPolicyIngressToTerraform(struct?: AccountNetworkPolicyIngress | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressToHclTerraform(struct?: AccountNetworkPolicyIngress | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngress | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngress | cdktn.IResolvable | undefined);
    private _publicAccess;
    get publicAccess(): AccountNetworkPolicyIngressPublicAccessOutputReference;
    putPublicAccess(value: AccountNetworkPolicyIngressPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccess | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRun {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#public_access AccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: AccountNetworkPolicyIngressDryRunPublicAccess;
}
export declare function accountNetworkPolicyIngressDryRunToTerraform(struct?: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunToHclTerraform(struct?: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRun | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable | undefined);
    private _publicAccess;
    get publicAccess(): AccountNetworkPolicyIngressDryRunPublicAccessOutputReference;
    putPublicAccess(value: AccountNetworkPolicyIngressDryRunPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccess | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy databricks_account_network_policy}
*/
export declare class AccountNetworkPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_network_policy";
    /**
    * Generates CDKTN code for importing a AccountNetworkPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountNetworkPolicy to import
    * @param importFromId The id of the existing AccountNetworkPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountNetworkPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.114.2/docs/resources/account_network_policy databricks_account_network_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountNetworkPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AccountNetworkPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _egress;
    get egress(): AccountNetworkPolicyEgressOutputReference;
    putEgress(value: AccountNetworkPolicyEgress): void;
    resetEgress(): void;
    get egressInput(): cdktn.IResolvable | AccountNetworkPolicyEgress | undefined;
    private _ingress;
    get ingress(): AccountNetworkPolicyIngressOutputReference;
    putIngress(value: AccountNetworkPolicyIngress): void;
    resetIngress(): void;
    get ingressInput(): cdktn.IResolvable | AccountNetworkPolicyIngress | undefined;
    private _ingressDryRun;
    get ingressDryRun(): AccountNetworkPolicyIngressDryRunOutputReference;
    putIngressDryRun(value: AccountNetworkPolicyIngressDryRun): void;
    resetIngressDryRun(): void;
    get ingressDryRunInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRun | undefined;
    private _networkPolicyId?;
    get networkPolicyId(): string;
    set networkPolicyId(value: string);
    resetNetworkPolicyId(): void;
    get networkPolicyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
