/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DataDatabricksAccountNetworkPoliciesItemsIngressDryRunCrossWorkspaceAccess, DataDatabricksAccountNetworkPoliciesItemsIngressDryRunCrossWorkspaceAccessOutputReference, DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess, DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessOutputReference, DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess, DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessOutputReference, DataDatabricksAccountNetworkPoliciesItemsEgressOutputReference, DataDatabricksAccountNetworkPoliciesItemsIngressOutputReference } from './structs0';
export interface DataDatabricksAccountNetworkPoliciesItemsIngressDryRun {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/account_network_policies#cross_workspace_access DataDatabricksAccountNetworkPolicies#cross_workspace_access}
    */
    readonly crossWorkspaceAccess?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunCrossWorkspaceAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/account_network_policies#private_access DataDatabricksAccountNetworkPolicies#private_access}
    */
    readonly privateAccess?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/account_network_policies#public_access DataDatabricksAccountNetworkPolicies#public_access}
    */
    readonly publicAccess?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRun): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsIngressDryRunToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItemsIngressDryRun): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsIngressDryRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRun | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRun | undefined);
    private _crossWorkspaceAccess;
    get crossWorkspaceAccess(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunCrossWorkspaceAccessOutputReference;
    putCrossWorkspaceAccess(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunCrossWorkspaceAccess): void;
    resetCrossWorkspaceAccess(): void;
    get crossWorkspaceAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunCrossWorkspaceAccess | undefined;
    private _privateAccess;
    get privateAccess(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccessOutputReference;
    putPrivateAccess(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccessOutputReference;
    putPublicAccess(value: DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPoliciesItemsIngressDryRunPublicAccess | undefined;
}
export interface DataDatabricksAccountNetworkPoliciesItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/account_network_policies#network_policy_id DataDatabricksAccountNetworkPolicies#network_policy_id}
    */
    readonly networkPolicyId: string;
}
export declare function dataDatabricksAccountNetworkPoliciesItemsToTerraform(struct?: DataDatabricksAccountNetworkPoliciesItems): any;
export declare function dataDatabricksAccountNetworkPoliciesItemsToHclTerraform(struct?: DataDatabricksAccountNetworkPoliciesItems): any;
export declare class DataDatabricksAccountNetworkPoliciesItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPoliciesItems | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPoliciesItems | undefined);
    get accountId(): string;
    private _egress;
    get egress(): DataDatabricksAccountNetworkPoliciesItemsEgressOutputReference;
    private _ingress;
    get ingress(): DataDatabricksAccountNetworkPoliciesItemsIngressOutputReference;
    private _ingressDryRun;
    get ingressDryRun(): DataDatabricksAccountNetworkPoliciesItemsIngressDryRunOutputReference;
    private _networkPolicyId?;
    get networkPolicyId(): string;
    set networkPolicyId(value: string);
    get networkPolicyIdInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPoliciesItemsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPoliciesItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPoliciesItemsOutputReference;
}
