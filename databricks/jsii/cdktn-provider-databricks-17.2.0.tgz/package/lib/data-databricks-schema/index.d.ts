/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSchemaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#id DataDatabricksSchema#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#name DataDatabricksSchema#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#provider_config DataDatabricksSchema#provider_config}
    */
    readonly providerConfig?: DataDatabricksSchemaProviderConfig;
    /**
    * schema_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#schema_info DataDatabricksSchema#schema_info}
    */
    readonly schemaInfo?: DataDatabricksSchemaSchemaInfo;
}
export interface DataDatabricksSchemaProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#workspace_id DataDatabricksSchema#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSchemaProviderConfigToTerraform(struct?: DataDatabricksSchemaProviderConfigOutputReference | DataDatabricksSchemaProviderConfig): any;
export declare function dataDatabricksSchemaProviderConfigToHclTerraform(struct?: DataDatabricksSchemaProviderConfigOutputReference | DataDatabricksSchemaProviderConfig): any;
export declare class DataDatabricksSchemaProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSchemaProviderConfig | undefined;
    set internalValue(value: DataDatabricksSchemaProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#inherited_from_name DataDatabricksSchema#inherited_from_name}
    */
    readonly inheritedFromName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#inherited_from_type DataDatabricksSchema#inherited_from_type}
    */
    readonly inheritedFromType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#value DataDatabricksSchema#value}
    */
    readonly value: string;
}
export declare function dataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlagToTerraform(struct?: DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlagOutputReference | DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag): any;
export declare function dataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlagToHclTerraform(struct?: DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlagOutputReference | DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag): any;
export declare class DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag | undefined;
    set internalValue(value: DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag | undefined);
    private _inheritedFromName?;
    get inheritedFromName(): string;
    set inheritedFromName(value: string);
    resetInheritedFromName(): void;
    get inheritedFromNameInput(): string | undefined;
    private _inheritedFromType?;
    get inheritedFromType(): string;
    set inheritedFromType(value: string);
    resetInheritedFromType(): void;
    get inheritedFromTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface DataDatabricksSchemaSchemaInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#browse_only DataDatabricksSchema#browse_only}
    */
    readonly browseOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#catalog_name DataDatabricksSchema#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#catalog_type DataDatabricksSchema#catalog_type}
    */
    readonly catalogType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#comment DataDatabricksSchema#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#created_at DataDatabricksSchema#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#created_by DataDatabricksSchema#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#enable_predictive_optimization DataDatabricksSchema#enable_predictive_optimization}
    */
    readonly enablePredictiveOptimization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#full_name DataDatabricksSchema#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#metastore_id DataDatabricksSchema#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#name DataDatabricksSchema#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#owner DataDatabricksSchema#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#properties DataDatabricksSchema#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#schema_id DataDatabricksSchema#schema_id}
    */
    readonly schemaId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#storage_location DataDatabricksSchema#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#storage_root DataDatabricksSchema#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#updated_at DataDatabricksSchema#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#updated_by DataDatabricksSchema#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * effective_predictive_optimization_flag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#effective_predictive_optimization_flag DataDatabricksSchema#effective_predictive_optimization_flag}
    */
    readonly effectivePredictiveOptimizationFlag?: DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag;
}
export declare function dataDatabricksSchemaSchemaInfoToTerraform(struct?: DataDatabricksSchemaSchemaInfoOutputReference | DataDatabricksSchemaSchemaInfo): any;
export declare function dataDatabricksSchemaSchemaInfoToHclTerraform(struct?: DataDatabricksSchemaSchemaInfoOutputReference | DataDatabricksSchemaSchemaInfo): any;
export declare class DataDatabricksSchemaSchemaInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSchemaSchemaInfo | undefined;
    set internalValue(value: DataDatabricksSchemaSchemaInfo | undefined);
    private _browseOnly?;
    get browseOnly(): boolean | cdktn.IResolvable;
    set browseOnly(value: boolean | cdktn.IResolvable);
    resetBrowseOnly(): void;
    get browseOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _catalogType?;
    get catalogType(): string;
    set catalogType(value: string);
    resetCatalogType(): void;
    get catalogTypeInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _enablePredictiveOptimization?;
    get enablePredictiveOptimization(): string;
    set enablePredictiveOptimization(value: string);
    resetEnablePredictiveOptimization(): void;
    get enablePredictiveOptimizationInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _schemaId?;
    get schemaId(): string;
    set schemaId(value: string);
    resetSchemaId(): void;
    get schemaIdInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _effectivePredictiveOptimizationFlag;
    get effectivePredictiveOptimizationFlag(): DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlagOutputReference;
    putEffectivePredictiveOptimizationFlag(value: DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag): void;
    resetEffectivePredictiveOptimizationFlag(): void;
    get effectivePredictiveOptimizationFlagInput(): DataDatabricksSchemaSchemaInfoEffectivePredictiveOptimizationFlag | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema databricks_schema}
*/
export declare class DataDatabricksSchema extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_schema";
    /**
    * Generates CDKTN code for importing a DataDatabricksSchema resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSchema to import
    * @param importFromId The id of the existing DataDatabricksSchema that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSchema to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/schema databricks_schema} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSchemaConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksSchemaConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSchemaProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSchemaProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksSchemaProviderConfig | undefined;
    private _schemaInfo;
    get schemaInfo(): DataDatabricksSchemaSchemaInfoOutputReference;
    putSchemaInfo(value: DataDatabricksSchemaSchemaInfo): void;
    resetSchemaInfo(): void;
    get schemaInfoInput(): DataDatabricksSchemaSchemaInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
