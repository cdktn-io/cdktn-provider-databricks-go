/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RfaAccessRequestDestinationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#destinations RfaAccessRequestDestinations#destinations}
    */
    readonly destinations?: RfaAccessRequestDestinationsDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#provider_config RfaAccessRequestDestinations#provider_config}
    */
    readonly providerConfig?: RfaAccessRequestDestinationsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#securable RfaAccessRequestDestinations#securable}
    */
    readonly securable: RfaAccessRequestDestinationsSecurable;
}
export interface RfaAccessRequestDestinationsDestinationSourceSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#full_name RfaAccessRequestDestinations#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#provider_share RfaAccessRequestDestinations#provider_share}
    */
    readonly providerShare?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#type RfaAccessRequestDestinations#type}
    */
    readonly type?: string;
}
export declare function rfaAccessRequestDestinationsDestinationSourceSecurableToTerraform(struct?: RfaAccessRequestDestinationsDestinationSourceSecurable): any;
export declare function rfaAccessRequestDestinationsDestinationSourceSecurableToHclTerraform(struct?: RfaAccessRequestDestinationsDestinationSourceSecurable): any;
export declare class RfaAccessRequestDestinationsDestinationSourceSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RfaAccessRequestDestinationsDestinationSourceSecurable | undefined;
    set internalValue(value: RfaAccessRequestDestinationsDestinationSourceSecurable | undefined);
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _providerShare?;
    get providerShare(): string;
    set providerShare(value: string);
    resetProviderShare(): void;
    get providerShareInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface RfaAccessRequestDestinationsDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#destination_id RfaAccessRequestDestinations#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#destination_type RfaAccessRequestDestinations#destination_type}
    */
    readonly destinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#special_destination RfaAccessRequestDestinations#special_destination}
    */
    readonly specialDestination?: string;
}
export declare function rfaAccessRequestDestinationsDestinationsToTerraform(struct?: RfaAccessRequestDestinationsDestinations | cdktn.IResolvable): any;
export declare function rfaAccessRequestDestinationsDestinationsToHclTerraform(struct?: RfaAccessRequestDestinationsDestinations | cdktn.IResolvable): any;
export declare class RfaAccessRequestDestinationsDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): RfaAccessRequestDestinationsDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: RfaAccessRequestDestinationsDestinations | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    resetDestinationType(): void;
    get destinationTypeInput(): string | undefined;
    private _specialDestination?;
    get specialDestination(): string;
    set specialDestination(value: string);
    resetSpecialDestination(): void;
    get specialDestinationInput(): string | undefined;
}
export declare class RfaAccessRequestDestinationsDestinationsList extends cdktn.ComplexList {
    internalValue?: RfaAccessRequestDestinationsDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): RfaAccessRequestDestinationsDestinationsOutputReference;
}
export interface RfaAccessRequestDestinationsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#workspace_id RfaAccessRequestDestinations#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function rfaAccessRequestDestinationsProviderConfigToTerraform(struct?: RfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable): any;
export declare function rfaAccessRequestDestinationsProviderConfigToHclTerraform(struct?: RfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable): any;
export declare class RfaAccessRequestDestinationsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: RfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface RfaAccessRequestDestinationsSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#full_name RfaAccessRequestDestinations#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#provider_share RfaAccessRequestDestinations#provider_share}
    */
    readonly providerShare?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#type RfaAccessRequestDestinations#type}
    */
    readonly type?: string;
}
export declare function rfaAccessRequestDestinationsSecurableToTerraform(struct?: RfaAccessRequestDestinationsSecurable | cdktn.IResolvable): any;
export declare function rfaAccessRequestDestinationsSecurableToHclTerraform(struct?: RfaAccessRequestDestinationsSecurable | cdktn.IResolvable): any;
export declare class RfaAccessRequestDestinationsSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RfaAccessRequestDestinationsSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: RfaAccessRequestDestinationsSecurable | cdktn.IResolvable | undefined);
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _providerShare?;
    get providerShare(): string;
    set providerShare(value: string);
    resetProviderShare(): void;
    get providerShareInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations databricks_rfa_access_request_destinations}
*/
export declare class RfaAccessRequestDestinations extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_rfa_access_request_destinations";
    /**
    * Generates CDKTN code for importing a RfaAccessRequestDestinations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RfaAccessRequestDestinations to import
    * @param importFromId The id of the existing RfaAccessRequestDestinations that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RfaAccessRequestDestinations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/rfa_access_request_destinations databricks_rfa_access_request_destinations} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RfaAccessRequestDestinationsConfig
    */
    constructor(scope: Construct, id: string, config: RfaAccessRequestDestinationsConfig);
    get areAnyDestinationsHidden(): cdktn.IResolvable;
    private _destinationSourceSecurable;
    get destinationSourceSecurable(): RfaAccessRequestDestinationsDestinationSourceSecurableOutputReference;
    private _destinations;
    get destinations(): RfaAccessRequestDestinationsDestinationsList;
    putDestinations(value: RfaAccessRequestDestinationsDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | RfaAccessRequestDestinationsDestinations[] | undefined;
    get fullName(): string;
    private _providerConfig;
    get providerConfig(): RfaAccessRequestDestinationsProviderConfigOutputReference;
    putProviderConfig(value: RfaAccessRequestDestinationsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | RfaAccessRequestDestinationsProviderConfig | undefined;
    private _securable;
    get securable(): RfaAccessRequestDestinationsSecurableOutputReference;
    putSecurable(value: RfaAccessRequestDestinationsSecurable): void;
    get securableInput(): cdktn.IResolvable | RfaAccessRequestDestinationsSecurable | undefined;
    get securableType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
