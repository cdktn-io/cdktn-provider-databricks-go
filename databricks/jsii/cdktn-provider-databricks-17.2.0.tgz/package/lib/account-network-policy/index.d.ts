/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { AccountNetworkPolicyEgress, AccountNetworkPolicyEgressOutputReference, AccountNetworkPolicyIngress, AccountNetworkPolicyIngressOutputReference, AccountNetworkPolicyIngressDryRun, AccountNetworkPolicyIngressDryRunOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountNetworkPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy#account_id AccountNetworkPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy#egress AccountNetworkPolicy#egress}
    */
    readonly egress?: AccountNetworkPolicyEgress;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy#ingress AccountNetworkPolicy#ingress}
    */
    readonly ingress?: AccountNetworkPolicyIngress;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy#ingress_dry_run AccountNetworkPolicy#ingress_dry_run}
    */
    readonly ingressDryRun?: AccountNetworkPolicyIngressDryRun;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy#network_policy_id AccountNetworkPolicy#network_policy_id}
    */
    readonly networkPolicyId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy databricks_account_network_policy}
*/
export declare class AccountNetworkPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_network_policy";
    /**
    * Generates CDKTN code for importing a AccountNetworkPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountNetworkPolicy to import
    * @param importFromId The id of the existing AccountNetworkPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountNetworkPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_network_policy databricks_account_network_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountNetworkPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AccountNetworkPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _egress;
    get egress(): AccountNetworkPolicyEgressOutputReference;
    putEgress(value: AccountNetworkPolicyEgress): void;
    resetEgress(): void;
    get egressInput(): cdktn.IResolvable | AccountNetworkPolicyEgress | undefined;
    private _ingress;
    get ingress(): AccountNetworkPolicyIngressOutputReference;
    putIngress(value: AccountNetworkPolicyIngress): void;
    resetIngress(): void;
    get ingressInput(): cdktn.IResolvable | AccountNetworkPolicyIngress | undefined;
    private _ingressDryRun;
    get ingressDryRun(): AccountNetworkPolicyIngressDryRunOutputReference;
    putIngressDryRun(value: AccountNetworkPolicyIngressDryRun): void;
    resetIngressDryRun(): void;
    get ingressDryRunInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRun | undefined;
    private _networkPolicyId?;
    get networkPolicyId(): string;
    set networkPolicyId(value: string);
    resetNetworkPolicyId(): void;
    get networkPolicyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
