/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NotificationDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#destination_type NotificationDestination#destination_type}
    */
    readonly destinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#display_name NotificationDestination#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#id NotificationDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#config NotificationDestination#config}
    */
    readonly config?: NotificationDestinationConfigA;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#provider_config NotificationDestination#provider_config}
    */
    readonly providerConfig?: NotificationDestinationProviderConfig;
}
export interface NotificationDestinationConfigEmail {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#addresses NotificationDestination#addresses}
    */
    readonly addresses?: string[];
}
export declare function notificationDestinationConfigEmailToTerraform(struct?: NotificationDestinationConfigEmailOutputReference | NotificationDestinationConfigEmail): any;
export declare function notificationDestinationConfigEmailToHclTerraform(struct?: NotificationDestinationConfigEmailOutputReference | NotificationDestinationConfigEmail): any;
export declare class NotificationDestinationConfigEmailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationConfigEmail | undefined;
    set internalValue(value: NotificationDestinationConfigEmail | undefined);
    private _addresses?;
    get addresses(): string[];
    set addresses(value: string[]);
    resetAddresses(): void;
    get addressesInput(): string[] | undefined;
}
export interface NotificationDestinationConfigGenericWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#password NotificationDestination#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#password_set NotificationDestination#password_set}
    */
    readonly passwordSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#url NotificationDestination#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#url_set NotificationDestination#url_set}
    */
    readonly urlSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#username NotificationDestination#username}
    */
    readonly username?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#username_set NotificationDestination#username_set}
    */
    readonly usernameSet?: boolean | cdktn.IResolvable;
}
export declare function notificationDestinationConfigGenericWebhookToTerraform(struct?: NotificationDestinationConfigGenericWebhookOutputReference | NotificationDestinationConfigGenericWebhook): any;
export declare function notificationDestinationConfigGenericWebhookToHclTerraform(struct?: NotificationDestinationConfigGenericWebhookOutputReference | NotificationDestinationConfigGenericWebhook): any;
export declare class NotificationDestinationConfigGenericWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationConfigGenericWebhook | undefined;
    set internalValue(value: NotificationDestinationConfigGenericWebhook | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _passwordSet?;
    get passwordSet(): boolean | cdktn.IResolvable;
    set passwordSet(value: boolean | cdktn.IResolvable);
    resetPasswordSet(): void;
    get passwordSetInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _urlSet?;
    get urlSet(): boolean | cdktn.IResolvable;
    set urlSet(value: boolean | cdktn.IResolvable);
    resetUrlSet(): void;
    get urlSetInput(): boolean | cdktn.IResolvable | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _usernameSet?;
    get usernameSet(): boolean | cdktn.IResolvable;
    set usernameSet(value: boolean | cdktn.IResolvable);
    resetUsernameSet(): void;
    get usernameSetInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NotificationDestinationConfigMicrosoftTeams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#app_id NotificationDestination#app_id}
    */
    readonly appId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#app_id_set NotificationDestination#app_id_set}
    */
    readonly appIdSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#auth_secret NotificationDestination#auth_secret}
    */
    readonly authSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#auth_secret_set NotificationDestination#auth_secret_set}
    */
    readonly authSecretSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#channel_url NotificationDestination#channel_url}
    */
    readonly channelUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#channel_url_set NotificationDestination#channel_url_set}
    */
    readonly channelUrlSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#tenant_id NotificationDestination#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#tenant_id_set NotificationDestination#tenant_id_set}
    */
    readonly tenantIdSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#url NotificationDestination#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#url_set NotificationDestination#url_set}
    */
    readonly urlSet?: boolean | cdktn.IResolvable;
}
export declare function notificationDestinationConfigMicrosoftTeamsToTerraform(struct?: NotificationDestinationConfigMicrosoftTeamsOutputReference | NotificationDestinationConfigMicrosoftTeams): any;
export declare function notificationDestinationConfigMicrosoftTeamsToHclTerraform(struct?: NotificationDestinationConfigMicrosoftTeamsOutputReference | NotificationDestinationConfigMicrosoftTeams): any;
export declare class NotificationDestinationConfigMicrosoftTeamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationConfigMicrosoftTeams | undefined;
    set internalValue(value: NotificationDestinationConfigMicrosoftTeams | undefined);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    resetAppId(): void;
    get appIdInput(): string | undefined;
    private _appIdSet?;
    get appIdSet(): boolean | cdktn.IResolvable;
    set appIdSet(value: boolean | cdktn.IResolvable);
    resetAppIdSet(): void;
    get appIdSetInput(): boolean | cdktn.IResolvable | undefined;
    private _authSecret?;
    get authSecret(): string;
    set authSecret(value: string);
    resetAuthSecret(): void;
    get authSecretInput(): string | undefined;
    private _authSecretSet?;
    get authSecretSet(): boolean | cdktn.IResolvable;
    set authSecretSet(value: boolean | cdktn.IResolvable);
    resetAuthSecretSet(): void;
    get authSecretSetInput(): boolean | cdktn.IResolvable | undefined;
    private _channelUrl?;
    get channelUrl(): string;
    set channelUrl(value: string);
    resetChannelUrl(): void;
    get channelUrlInput(): string | undefined;
    private _channelUrlSet?;
    get channelUrlSet(): boolean | cdktn.IResolvable;
    set channelUrlSet(value: boolean | cdktn.IResolvable);
    resetChannelUrlSet(): void;
    get channelUrlSetInput(): boolean | cdktn.IResolvable | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _tenantIdSet?;
    get tenantIdSet(): boolean | cdktn.IResolvable;
    set tenantIdSet(value: boolean | cdktn.IResolvable);
    resetTenantIdSet(): void;
    get tenantIdSetInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _urlSet?;
    get urlSet(): boolean | cdktn.IResolvable;
    set urlSet(value: boolean | cdktn.IResolvable);
    resetUrlSet(): void;
    get urlSetInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NotificationDestinationConfigPagerduty {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#integration_key NotificationDestination#integration_key}
    */
    readonly integrationKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#integration_key_set NotificationDestination#integration_key_set}
    */
    readonly integrationKeySet?: boolean | cdktn.IResolvable;
}
export declare function notificationDestinationConfigPagerdutyToTerraform(struct?: NotificationDestinationConfigPagerdutyOutputReference | NotificationDestinationConfigPagerduty): any;
export declare function notificationDestinationConfigPagerdutyToHclTerraform(struct?: NotificationDestinationConfigPagerdutyOutputReference | NotificationDestinationConfigPagerduty): any;
export declare class NotificationDestinationConfigPagerdutyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationConfigPagerduty | undefined;
    set internalValue(value: NotificationDestinationConfigPagerduty | undefined);
    private _integrationKey?;
    get integrationKey(): string;
    set integrationKey(value: string);
    resetIntegrationKey(): void;
    get integrationKeyInput(): string | undefined;
    private _integrationKeySet?;
    get integrationKeySet(): boolean | cdktn.IResolvable;
    set integrationKeySet(value: boolean | cdktn.IResolvable);
    resetIntegrationKeySet(): void;
    get integrationKeySetInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NotificationDestinationConfigSlack {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#channel_id NotificationDestination#channel_id}
    */
    readonly channelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#channel_id_set NotificationDestination#channel_id_set}
    */
    readonly channelIdSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#oauth_token NotificationDestination#oauth_token}
    */
    readonly oauthToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#oauth_token_set NotificationDestination#oauth_token_set}
    */
    readonly oauthTokenSet?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#url NotificationDestination#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#url_set NotificationDestination#url_set}
    */
    readonly urlSet?: boolean | cdktn.IResolvable;
}
export declare function notificationDestinationConfigSlackToTerraform(struct?: NotificationDestinationConfigSlackOutputReference | NotificationDestinationConfigSlack): any;
export declare function notificationDestinationConfigSlackToHclTerraform(struct?: NotificationDestinationConfigSlackOutputReference | NotificationDestinationConfigSlack): any;
export declare class NotificationDestinationConfigSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationConfigSlack | undefined;
    set internalValue(value: NotificationDestinationConfigSlack | undefined);
    private _channelId?;
    get channelId(): string;
    set channelId(value: string);
    resetChannelId(): void;
    get channelIdInput(): string | undefined;
    private _channelIdSet?;
    get channelIdSet(): boolean | cdktn.IResolvable;
    set channelIdSet(value: boolean | cdktn.IResolvable);
    resetChannelIdSet(): void;
    get channelIdSetInput(): boolean | cdktn.IResolvable | undefined;
    private _oauthToken?;
    get oauthToken(): string;
    set oauthToken(value: string);
    resetOauthToken(): void;
    get oauthTokenInput(): string | undefined;
    private _oauthTokenSet?;
    get oauthTokenSet(): boolean | cdktn.IResolvable;
    set oauthTokenSet(value: boolean | cdktn.IResolvable);
    resetOauthTokenSet(): void;
    get oauthTokenSetInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _urlSet?;
    get urlSet(): boolean | cdktn.IResolvable;
    set urlSet(value: boolean | cdktn.IResolvable);
    resetUrlSet(): void;
    get urlSetInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NotificationDestinationConfigA {
    /**
    * email block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#email NotificationDestination#email}
    */
    readonly email?: NotificationDestinationConfigEmail;
    /**
    * generic_webhook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#generic_webhook NotificationDestination#generic_webhook}
    */
    readonly genericWebhook?: NotificationDestinationConfigGenericWebhook;
    /**
    * microsoft_teams block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#microsoft_teams NotificationDestination#microsoft_teams}
    */
    readonly microsoftTeams?: NotificationDestinationConfigMicrosoftTeams;
    /**
    * pagerduty block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#pagerduty NotificationDestination#pagerduty}
    */
    readonly pagerduty?: NotificationDestinationConfigPagerduty;
    /**
    * slack block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#slack NotificationDestination#slack}
    */
    readonly slack?: NotificationDestinationConfigSlack;
}
export declare function notificationDestinationConfigAToTerraform(struct?: NotificationDestinationConfigAOutputReference | NotificationDestinationConfigA): any;
export declare function notificationDestinationConfigAToHclTerraform(struct?: NotificationDestinationConfigAOutputReference | NotificationDestinationConfigA): any;
export declare class NotificationDestinationConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationConfigA | undefined;
    set internalValue(value: NotificationDestinationConfigA | undefined);
    private _email;
    get email(): NotificationDestinationConfigEmailOutputReference;
    putEmail(value: NotificationDestinationConfigEmail): void;
    resetEmail(): void;
    get emailInput(): NotificationDestinationConfigEmail | undefined;
    private _genericWebhook;
    get genericWebhook(): NotificationDestinationConfigGenericWebhookOutputReference;
    putGenericWebhook(value: NotificationDestinationConfigGenericWebhook): void;
    resetGenericWebhook(): void;
    get genericWebhookInput(): NotificationDestinationConfigGenericWebhook | undefined;
    private _microsoftTeams;
    get microsoftTeams(): NotificationDestinationConfigMicrosoftTeamsOutputReference;
    putMicrosoftTeams(value: NotificationDestinationConfigMicrosoftTeams): void;
    resetMicrosoftTeams(): void;
    get microsoftTeamsInput(): NotificationDestinationConfigMicrosoftTeams | undefined;
    private _pagerduty;
    get pagerduty(): NotificationDestinationConfigPagerdutyOutputReference;
    putPagerduty(value: NotificationDestinationConfigPagerduty): void;
    resetPagerduty(): void;
    get pagerdutyInput(): NotificationDestinationConfigPagerduty | undefined;
    private _slack;
    get slack(): NotificationDestinationConfigSlackOutputReference;
    putSlack(value: NotificationDestinationConfigSlack): void;
    resetSlack(): void;
    get slackInput(): NotificationDestinationConfigSlack | undefined;
}
export interface NotificationDestinationProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#workspace_id NotificationDestination#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function notificationDestinationProviderConfigToTerraform(struct?: NotificationDestinationProviderConfigOutputReference | NotificationDestinationProviderConfig): any;
export declare function notificationDestinationProviderConfigToHclTerraform(struct?: NotificationDestinationProviderConfigOutputReference | NotificationDestinationProviderConfig): any;
export declare class NotificationDestinationProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NotificationDestinationProviderConfig | undefined;
    set internalValue(value: NotificationDestinationProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination databricks_notification_destination}
*/
export declare class NotificationDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_notification_destination";
    /**
    * Generates CDKTN code for importing a NotificationDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NotificationDestination to import
    * @param importFromId The id of the existing NotificationDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NotificationDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/notification_destination databricks_notification_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NotificationDestinationConfig
    */
    constructor(scope: Construct, id: string, config: NotificationDestinationConfig);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    resetDestinationType(): void;
    get destinationTypeInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _config;
    get config(): NotificationDestinationConfigAOutputReference;
    putConfig(value: NotificationDestinationConfigA): void;
    resetConfig(): void;
    get configInput(): NotificationDestinationConfigA | undefined;
    private _providerConfig;
    get providerConfig(): NotificationDestinationProviderConfigOutputReference;
    putProviderConfig(value: NotificationDestinationProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): NotificationDestinationProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
