/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDirectoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory#id DataDatabricksDirectory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory#object_id DataDatabricksDirectory#object_id}
    */
    readonly objectId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory#path DataDatabricksDirectory#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory#workspace_path DataDatabricksDirectory#workspace_path}
    */
    readonly workspacePath?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory#provider_config DataDatabricksDirectory#provider_config}
    */
    readonly providerConfig?: DataDatabricksDirectoryProviderConfig;
}
export interface DataDatabricksDirectoryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory#workspace_id DataDatabricksDirectory#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDirectoryProviderConfigToTerraform(struct?: DataDatabricksDirectoryProviderConfigOutputReference | DataDatabricksDirectoryProviderConfig): any;
export declare function dataDatabricksDirectoryProviderConfigToHclTerraform(struct?: DataDatabricksDirectoryProviderConfigOutputReference | DataDatabricksDirectoryProviderConfig): any;
export declare class DataDatabricksDirectoryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDirectoryProviderConfig | undefined;
    set internalValue(value: DataDatabricksDirectoryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory databricks_directory}
*/
export declare class DataDatabricksDirectory extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_directory";
    /**
    * Generates CDKTN code for importing a DataDatabricksDirectory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDirectory to import
    * @param importFromId The id of the existing DataDatabricksDirectory that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDirectory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/directory databricks_directory} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDirectoryConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDirectoryConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): number;
    set objectId(value: number);
    resetObjectId(): void;
    get objectIdInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _workspacePath?;
    get workspacePath(): string;
    set workspacePath(value: string);
    resetWorkspacePath(): void;
    get workspacePathInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDirectoryProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDirectoryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksDirectoryProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
