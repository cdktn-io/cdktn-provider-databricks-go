/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksBudgetPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/budget_policy#policy_id DataDatabricksBudgetPolicy#policy_id}
    */
    readonly policyId: string;
}
export interface DataDatabricksBudgetPolicyCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/budget_policy#key DataDatabricksBudgetPolicy#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/budget_policy#value DataDatabricksBudgetPolicy#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksBudgetPolicyCustomTagsToTerraform(struct?: DataDatabricksBudgetPolicyCustomTags): any;
export declare function dataDatabricksBudgetPolicyCustomTagsToHclTerraform(struct?: DataDatabricksBudgetPolicyCustomTags): any;
export declare class DataDatabricksBudgetPolicyCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksBudgetPolicyCustomTags | undefined;
    set internalValue(value: DataDatabricksBudgetPolicyCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksBudgetPolicyCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksBudgetPolicyCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksBudgetPolicyCustomTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/budget_policy databricks_budget_policy}
*/
export declare class DataDatabricksBudgetPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_budget_policy";
    /**
    * Generates CDKTN code for importing a DataDatabricksBudgetPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksBudgetPolicy to import
    * @param importFromId The id of the existing DataDatabricksBudgetPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/budget_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksBudgetPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/budget_policy databricks_budget_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksBudgetPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksBudgetPolicyConfig);
    get bindingWorkspaceIds(): number[];
    private _customTags;
    get customTags(): DataDatabricksBudgetPolicyCustomTagsList;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    get policyName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
