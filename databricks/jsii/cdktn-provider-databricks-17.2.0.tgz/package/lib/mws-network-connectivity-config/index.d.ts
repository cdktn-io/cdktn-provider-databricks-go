/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MwsNetworkConnectivityConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#account_id MwsNetworkConnectivityConfig#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#creation_time MwsNetworkConnectivityConfig#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#id MwsNetworkConnectivityConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#name MwsNetworkConnectivityConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#network_connectivity_config_id MwsNetworkConnectivityConfig#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#region MwsNetworkConnectivityConfig#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#updated_time MwsNetworkConnectivityConfig#updated_time}
    */
    readonly updatedTime?: number;
    /**
    * egress_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#egress_config MwsNetworkConnectivityConfig#egress_config}
    */
    readonly egressConfig?: MwsNetworkConnectivityConfigEgressConfig;
}
export interface MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#cidr_blocks MwsNetworkConnectivityConfig#cidr_blocks}
    */
    readonly cidrBlocks?: string[];
}
export declare function mwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleToTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference | MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule): any;
export declare function mwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleToHclTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference | MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule): any;
export declare class MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule | undefined;
    set internalValue(value: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule | undefined);
    private _cidrBlocks?;
    get cidrBlocks(): string[];
    set cidrBlocks(value: string[]);
    resetCidrBlocks(): void;
    get cidrBlocksInput(): string[] | undefined;
}
export interface MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#subnets MwsNetworkConnectivityConfig#subnets}
    */
    readonly subnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#target_region MwsNetworkConnectivityConfig#target_region}
    */
    readonly targetRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#target_services MwsNetworkConnectivityConfig#target_services}
    */
    readonly targetServices?: string[];
}
export declare function mwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleToTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference | MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule): any;
export declare function mwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleToHclTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference | MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule): any;
export declare class MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule | undefined;
    set internalValue(value: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule | undefined);
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
    private _targetRegion?;
    get targetRegion(): string;
    set targetRegion(value: string);
    resetTargetRegion(): void;
    get targetRegionInput(): string | undefined;
    private _targetServices?;
    get targetServices(): string[];
    set targetServices(value: string[]);
    resetTargetServices(): void;
    get targetServicesInput(): string[] | undefined;
}
export interface MwsNetworkConnectivityConfigEgressConfigDefaultRules {
    /**
    * aws_stable_ip_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#aws_stable_ip_rule MwsNetworkConnectivityConfig#aws_stable_ip_rule}
    */
    readonly awsStableIpRule?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule;
    /**
    * azure_service_endpoint_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#azure_service_endpoint_rule MwsNetworkConnectivityConfig#azure_service_endpoint_rule}
    */
    readonly azureServiceEndpointRule?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule;
}
export declare function mwsNetworkConnectivityConfigEgressConfigDefaultRulesToTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference | MwsNetworkConnectivityConfigEgressConfigDefaultRules): any;
export declare function mwsNetworkConnectivityConfigEgressConfigDefaultRulesToHclTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference | MwsNetworkConnectivityConfigEgressConfigDefaultRules): any;
export declare class MwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsNetworkConnectivityConfigEgressConfigDefaultRules | undefined;
    set internalValue(value: MwsNetworkConnectivityConfigEgressConfigDefaultRules | undefined);
    private _awsStableIpRule;
    get awsStableIpRule(): MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRuleOutputReference;
    putAwsStableIpRule(value: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule): void;
    resetAwsStableIpRule(): void;
    get awsStableIpRuleInput(): MwsNetworkConnectivityConfigEgressConfigDefaultRulesAwsStableIpRule | undefined;
    private _azureServiceEndpointRule;
    get azureServiceEndpointRule(): MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRuleOutputReference;
    putAzureServiceEndpointRule(value: MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule): void;
    resetAzureServiceEndpointRule(): void;
    get azureServiceEndpointRuleInput(): MwsNetworkConnectivityConfigEgressConfigDefaultRulesAzureServiceEndpointRule | undefined;
}
export interface MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#account_id MwsNetworkConnectivityConfig#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#connection_state MwsNetworkConnectivityConfig#connection_state}
    */
    readonly connectionState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#creation_time MwsNetworkConnectivityConfig#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#deactivated MwsNetworkConnectivityConfig#deactivated}
    */
    readonly deactivated?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#deactivated_at MwsNetworkConnectivityConfig#deactivated_at}
    */
    readonly deactivatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#domain_names MwsNetworkConnectivityConfig#domain_names}
    */
    readonly domainNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#enabled MwsNetworkConnectivityConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#endpoint_service MwsNetworkConnectivityConfig#endpoint_service}
    */
    readonly endpointService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#error_message MwsNetworkConnectivityConfig#error_message}
    */
    readonly errorMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#network_connectivity_config_id MwsNetworkConnectivityConfig#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#resource_names MwsNetworkConnectivityConfig#resource_names}
    */
    readonly resourceNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#rule_id MwsNetworkConnectivityConfig#rule_id}
    */
    readonly ruleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#updated_time MwsNetworkConnectivityConfig#updated_time}
    */
    readonly updatedTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#vpc_endpoint_id MwsNetworkConnectivityConfig#vpc_endpoint_id}
    */
    readonly vpcEndpointId?: string;
}
export declare function mwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesToTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable): any;
export declare function mwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesToHclTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable): any;
export declare class MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable | undefined;
    set internalValue(value: MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules | cdktn.IResolvable | undefined);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _connectionState?;
    get connectionState(): string;
    set connectionState(value: string);
    resetConnectionState(): void;
    get connectionStateInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _deactivated?;
    get deactivated(): boolean | cdktn.IResolvable;
    set deactivated(value: boolean | cdktn.IResolvable);
    resetDeactivated(): void;
    get deactivatedInput(): boolean | cdktn.IResolvable | undefined;
    private _deactivatedAt?;
    get deactivatedAt(): number;
    set deactivatedAt(value: number);
    resetDeactivatedAt(): void;
    get deactivatedAtInput(): number | undefined;
    private _domainNames?;
    get domainNames(): string[];
    set domainNames(value: string[]);
    resetDomainNames(): void;
    get domainNamesInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointService?;
    get endpointService(): string;
    set endpointService(value: string);
    resetEndpointService(): void;
    get endpointServiceInput(): string | undefined;
    private _errorMessage?;
    get errorMessage(): string;
    set errorMessage(value: string);
    resetErrorMessage(): void;
    get errorMessageInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    resetNetworkConnectivityConfigId(): void;
    get networkConnectivityConfigIdInput(): string | undefined;
    private _resourceNames?;
    get resourceNames(): string[];
    set resourceNames(value: string[]);
    resetResourceNames(): void;
    get resourceNamesInput(): string[] | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    resetRuleId(): void;
    get ruleIdInput(): string | undefined;
    private _updatedTime?;
    get updatedTime(): number;
    set updatedTime(value: number);
    resetUpdatedTime(): void;
    get updatedTimeInput(): number | undefined;
    private _vpcEndpointId?;
    get vpcEndpointId(): string;
    set vpcEndpointId(value: string);
    resetVpcEndpointId(): void;
    get vpcEndpointIdInput(): string | undefined;
}
export declare class MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesList extends cdktn.ComplexList {
    internalValue?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesOutputReference;
}
export interface MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#connection_state MwsNetworkConnectivityConfig#connection_state}
    */
    readonly connectionState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#creation_time MwsNetworkConnectivityConfig#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#deactivated MwsNetworkConnectivityConfig#deactivated}
    */
    readonly deactivated?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#deactivated_at MwsNetworkConnectivityConfig#deactivated_at}
    */
    readonly deactivatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#domain_names MwsNetworkConnectivityConfig#domain_names}
    */
    readonly domainNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#endpoint_name MwsNetworkConnectivityConfig#endpoint_name}
    */
    readonly endpointName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#error_message MwsNetworkConnectivityConfig#error_message}
    */
    readonly errorMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#group_id MwsNetworkConnectivityConfig#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#network_connectivity_config_id MwsNetworkConnectivityConfig#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#resource_id MwsNetworkConnectivityConfig#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#rule_id MwsNetworkConnectivityConfig#rule_id}
    */
    readonly ruleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#updated_time MwsNetworkConnectivityConfig#updated_time}
    */
    readonly updatedTime?: number;
}
export declare function mwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesToTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable): any;
export declare function mwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesToHclTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable): any;
export declare class MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable | undefined;
    set internalValue(value: MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules | cdktn.IResolvable | undefined);
    private _connectionState?;
    get connectionState(): string;
    set connectionState(value: string);
    resetConnectionState(): void;
    get connectionStateInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _deactivated?;
    get deactivated(): boolean | cdktn.IResolvable;
    set deactivated(value: boolean | cdktn.IResolvable);
    resetDeactivated(): void;
    get deactivatedInput(): boolean | cdktn.IResolvable | undefined;
    private _deactivatedAt?;
    get deactivatedAt(): number;
    set deactivatedAt(value: number);
    resetDeactivatedAt(): void;
    get deactivatedAtInput(): number | undefined;
    private _domainNames?;
    get domainNames(): string[];
    set domainNames(value: string[]);
    resetDomainNames(): void;
    get domainNamesInput(): string[] | undefined;
    private _endpointName?;
    get endpointName(): string;
    set endpointName(value: string);
    resetEndpointName(): void;
    get endpointNameInput(): string | undefined;
    private _errorMessage?;
    get errorMessage(): string;
    set errorMessage(value: string);
    resetErrorMessage(): void;
    get errorMessageInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    resetNetworkConnectivityConfigId(): void;
    get networkConnectivityConfigIdInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    resetRuleId(): void;
    get ruleIdInput(): string | undefined;
    private _updatedTime?;
    get updatedTime(): number;
    set updatedTime(value: number);
    resetUpdatedTime(): void;
    get updatedTimeInput(): number | undefined;
}
export declare class MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesList extends cdktn.ComplexList {
    internalValue?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesOutputReference;
}
export interface MwsNetworkConnectivityConfigEgressConfigTargetRules {
    /**
    * aws_private_endpoint_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#aws_private_endpoint_rules MwsNetworkConnectivityConfig#aws_private_endpoint_rules}
    */
    readonly awsPrivateEndpointRules?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | cdktn.IResolvable;
    /**
    * azure_private_endpoint_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#azure_private_endpoint_rules MwsNetworkConnectivityConfig#azure_private_endpoint_rules}
    */
    readonly azurePrivateEndpointRules?: MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | cdktn.IResolvable;
}
export declare function mwsNetworkConnectivityConfigEgressConfigTargetRulesToTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference | MwsNetworkConnectivityConfigEgressConfigTargetRules): any;
export declare function mwsNetworkConnectivityConfigEgressConfigTargetRulesToHclTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference | MwsNetworkConnectivityConfigEgressConfigTargetRules): any;
export declare class MwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsNetworkConnectivityConfigEgressConfigTargetRules | undefined;
    set internalValue(value: MwsNetworkConnectivityConfigEgressConfigTargetRules | undefined);
    private _awsPrivateEndpointRules;
    get awsPrivateEndpointRules(): MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRulesList;
    putAwsPrivateEndpointRules(value: MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | cdktn.IResolvable): void;
    resetAwsPrivateEndpointRules(): void;
    get awsPrivateEndpointRulesInput(): cdktn.IResolvable | MwsNetworkConnectivityConfigEgressConfigTargetRulesAwsPrivateEndpointRules[] | undefined;
    private _azurePrivateEndpointRules;
    get azurePrivateEndpointRules(): MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRulesList;
    putAzurePrivateEndpointRules(value: MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | cdktn.IResolvable): void;
    resetAzurePrivateEndpointRules(): void;
    get azurePrivateEndpointRulesInput(): cdktn.IResolvable | MwsNetworkConnectivityConfigEgressConfigTargetRulesAzurePrivateEndpointRules[] | undefined;
}
export interface MwsNetworkConnectivityConfigEgressConfig {
    /**
    * default_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#default_rules MwsNetworkConnectivityConfig#default_rules}
    */
    readonly defaultRules?: MwsNetworkConnectivityConfigEgressConfigDefaultRules;
    /**
    * target_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#target_rules MwsNetworkConnectivityConfig#target_rules}
    */
    readonly targetRules?: MwsNetworkConnectivityConfigEgressConfigTargetRules;
}
export declare function mwsNetworkConnectivityConfigEgressConfigToTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigOutputReference | MwsNetworkConnectivityConfigEgressConfig): any;
export declare function mwsNetworkConnectivityConfigEgressConfigToHclTerraform(struct?: MwsNetworkConnectivityConfigEgressConfigOutputReference | MwsNetworkConnectivityConfigEgressConfig): any;
export declare class MwsNetworkConnectivityConfigEgressConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsNetworkConnectivityConfigEgressConfig | undefined;
    set internalValue(value: MwsNetworkConnectivityConfigEgressConfig | undefined);
    private _defaultRules;
    get defaultRules(): MwsNetworkConnectivityConfigEgressConfigDefaultRulesOutputReference;
    putDefaultRules(value: MwsNetworkConnectivityConfigEgressConfigDefaultRules): void;
    resetDefaultRules(): void;
    get defaultRulesInput(): MwsNetworkConnectivityConfigEgressConfigDefaultRules | undefined;
    private _targetRules;
    get targetRules(): MwsNetworkConnectivityConfigEgressConfigTargetRulesOutputReference;
    putTargetRules(value: MwsNetworkConnectivityConfigEgressConfigTargetRules): void;
    resetTargetRules(): void;
    get targetRulesInput(): MwsNetworkConnectivityConfigEgressConfigTargetRules | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config databricks_mws_network_connectivity_config}
*/
export declare class MwsNetworkConnectivityConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mws_network_connectivity_config";
    /**
    * Generates CDKTN code for importing a MwsNetworkConnectivityConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MwsNetworkConnectivityConfig to import
    * @param importFromId The id of the existing MwsNetworkConnectivityConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MwsNetworkConnectivityConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/mws_network_connectivity_config databricks_mws_network_connectivity_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MwsNetworkConnectivityConfigConfig
    */
    constructor(scope: Construct, id: string, config: MwsNetworkConnectivityConfigConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    resetNetworkConnectivityConfigId(): void;
    get networkConnectivityConfigIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _updatedTime?;
    get updatedTime(): number;
    set updatedTime(value: number);
    resetUpdatedTime(): void;
    get updatedTimeInput(): number | undefined;
    private _egressConfig;
    get egressConfig(): MwsNetworkConnectivityConfigEgressConfigOutputReference;
    putEgressConfig(value: MwsNetworkConnectivityConfigEgressConfig): void;
    resetEgressConfig(): void;
    get egressConfigInput(): MwsNetworkConnectivityConfigEgressConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
