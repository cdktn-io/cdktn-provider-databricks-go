/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ComplianceSecurityProfileWorkspaceSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#etag ComplianceSecurityProfileWorkspaceSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#id ComplianceSecurityProfileWorkspaceSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#setting_name ComplianceSecurityProfileWorkspaceSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * compliance_security_profile_workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#compliance_security_profile_workspace ComplianceSecurityProfileWorkspaceSetting#compliance_security_profile_workspace}
    */
    readonly complianceSecurityProfileWorkspace: ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#provider_config ComplianceSecurityProfileWorkspaceSetting#provider_config}
    */
    readonly providerConfig?: ComplianceSecurityProfileWorkspaceSettingProviderConfig;
}
export interface ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#compliance_standards ComplianceSecurityProfileWorkspaceSetting#compliance_standards}
    */
    readonly complianceStandards: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#is_enabled ComplianceSecurityProfileWorkspaceSetting#is_enabled}
    */
    readonly isEnabled: boolean | cdktn.IResolvable;
}
export declare function complianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspaceToTerraform(struct?: ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspaceOutputReference | ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace): any;
export declare function complianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspaceToHclTerraform(struct?: ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspaceOutputReference | ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace): any;
export declare class ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace | undefined;
    set internalValue(value: ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace | undefined);
    private _complianceStandards?;
    get complianceStandards(): string[];
    set complianceStandards(value: string[]);
    get complianceStandardsInput(): string[] | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ComplianceSecurityProfileWorkspaceSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#workspace_id ComplianceSecurityProfileWorkspaceSetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function complianceSecurityProfileWorkspaceSettingProviderConfigToTerraform(struct?: ComplianceSecurityProfileWorkspaceSettingProviderConfigOutputReference | ComplianceSecurityProfileWorkspaceSettingProviderConfig): any;
export declare function complianceSecurityProfileWorkspaceSettingProviderConfigToHclTerraform(struct?: ComplianceSecurityProfileWorkspaceSettingProviderConfigOutputReference | ComplianceSecurityProfileWorkspaceSettingProviderConfig): any;
export declare class ComplianceSecurityProfileWorkspaceSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ComplianceSecurityProfileWorkspaceSettingProviderConfig | undefined;
    set internalValue(value: ComplianceSecurityProfileWorkspaceSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting databricks_compliance_security_profile_workspace_setting}
*/
export declare class ComplianceSecurityProfileWorkspaceSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_compliance_security_profile_workspace_setting";
    /**
    * Generates CDKTN code for importing a ComplianceSecurityProfileWorkspaceSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ComplianceSecurityProfileWorkspaceSetting to import
    * @param importFromId The id of the existing ComplianceSecurityProfileWorkspaceSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ComplianceSecurityProfileWorkspaceSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/compliance_security_profile_workspace_setting databricks_compliance_security_profile_workspace_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ComplianceSecurityProfileWorkspaceSettingConfig
    */
    constructor(scope: Construct, id: string, config: ComplianceSecurityProfileWorkspaceSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _complianceSecurityProfileWorkspace;
    get complianceSecurityProfileWorkspace(): ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspaceOutputReference;
    putComplianceSecurityProfileWorkspace(value: ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace): void;
    get complianceSecurityProfileWorkspaceInput(): ComplianceSecurityProfileWorkspaceSettingComplianceSecurityProfileWorkspace | undefined;
    private _providerConfig;
    get providerConfig(): ComplianceSecurityProfileWorkspaceSettingProviderConfigOutputReference;
    putProviderConfig(value: ComplianceSecurityProfileWorkspaceSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ComplianceSecurityProfileWorkspaceSettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
