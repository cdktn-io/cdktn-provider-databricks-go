/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountSettingUserPreferenceV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#boolean_val AccountSettingUserPreferenceV2#boolean_val}
    */
    readonly booleanVal?: AccountSettingUserPreferenceV2BooleanVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#name AccountSettingUserPreferenceV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#string_val AccountSettingUserPreferenceV2#string_val}
    */
    readonly stringVal?: AccountSettingUserPreferenceV2StringVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#user_id AccountSettingUserPreferenceV2#user_id}
    */
    readonly userId?: string;
}
export interface AccountSettingUserPreferenceV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#value AccountSettingUserPreferenceV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function accountSettingUserPreferenceV2BooleanValToTerraform(struct?: AccountSettingUserPreferenceV2BooleanVal | cdktn.IResolvable): any;
export declare function accountSettingUserPreferenceV2BooleanValToHclTerraform(struct?: AccountSettingUserPreferenceV2BooleanVal | cdktn.IResolvable): any;
export declare class AccountSettingUserPreferenceV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingUserPreferenceV2BooleanVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingUserPreferenceV2BooleanVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingUserPreferenceV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#value AccountSettingUserPreferenceV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function accountSettingUserPreferenceV2EffectiveBooleanValToTerraform(struct?: AccountSettingUserPreferenceV2EffectiveBooleanVal): any;
export declare function accountSettingUserPreferenceV2EffectiveBooleanValToHclTerraform(struct?: AccountSettingUserPreferenceV2EffectiveBooleanVal): any;
export declare class AccountSettingUserPreferenceV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingUserPreferenceV2EffectiveBooleanVal | undefined;
    set internalValue(value: AccountSettingUserPreferenceV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingUserPreferenceV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#value AccountSettingUserPreferenceV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingUserPreferenceV2EffectiveStringValToTerraform(struct?: AccountSettingUserPreferenceV2EffectiveStringVal): any;
export declare function accountSettingUserPreferenceV2EffectiveStringValToHclTerraform(struct?: AccountSettingUserPreferenceV2EffectiveStringVal): any;
export declare class AccountSettingUserPreferenceV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingUserPreferenceV2EffectiveStringVal | undefined;
    set internalValue(value: AccountSettingUserPreferenceV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingUserPreferenceV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#value AccountSettingUserPreferenceV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingUserPreferenceV2StringValToTerraform(struct?: AccountSettingUserPreferenceV2StringVal | cdktn.IResolvable): any;
export declare function accountSettingUserPreferenceV2StringValToHclTerraform(struct?: AccountSettingUserPreferenceV2StringVal | cdktn.IResolvable): any;
export declare class AccountSettingUserPreferenceV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingUserPreferenceV2StringVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingUserPreferenceV2StringVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2 databricks_account_setting_user_preference_v2}
*/
export declare class AccountSettingUserPreferenceV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_setting_user_preference_v2";
    /**
    * Generates CDKTN code for importing a AccountSettingUserPreferenceV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountSettingUserPreferenceV2 to import
    * @param importFromId The id of the existing AccountSettingUserPreferenceV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountSettingUserPreferenceV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/account_setting_user_preference_v2 databricks_account_setting_user_preference_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountSettingUserPreferenceV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: AccountSettingUserPreferenceV2Config);
    private _booleanVal;
    get booleanVal(): AccountSettingUserPreferenceV2BooleanValOutputReference;
    putBooleanVal(value: AccountSettingUserPreferenceV2BooleanVal): void;
    resetBooleanVal(): void;
    get booleanValInput(): cdktn.IResolvable | AccountSettingUserPreferenceV2BooleanVal | undefined;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): AccountSettingUserPreferenceV2EffectiveBooleanValOutputReference;
    private _effectiveStringVal;
    get effectiveStringVal(): AccountSettingUserPreferenceV2EffectiveStringValOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _stringVal;
    get stringVal(): AccountSettingUserPreferenceV2StringValOutputReference;
    putStringVal(value: AccountSettingUserPreferenceV2StringVal): void;
    resetStringVal(): void;
    get stringValInput(): cdktn.IResolvable | AccountSettingUserPreferenceV2StringVal | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
