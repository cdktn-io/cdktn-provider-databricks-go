/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#custom_description AlertV2#custom_description}
    */
    readonly customDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#custom_summary AlertV2#custom_summary}
    */
    readonly customSummary?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#display_name AlertV2#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#evaluation AlertV2#evaluation}
    */
    readonly evaluation: AlertV2Evaluation;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#parent_path AlertV2#parent_path}
    */
    readonly parentPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#provider_config AlertV2#provider_config}
    */
    readonly providerConfig?: AlertV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#purge_on_delete AlertV2#purge_on_delete}
    */
    readonly purgeOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#query_text AlertV2#query_text}
    */
    readonly queryText: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#run_as AlertV2#run_as}
    */
    readonly runAs?: AlertV2RunAs;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#run_as_user_name AlertV2#run_as_user_name}
    */
    readonly runAsUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#schedule AlertV2#schedule}
    */
    readonly schedule: AlertV2Schedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#warehouse_id AlertV2#warehouse_id}
    */
    readonly warehouseId: string;
}
export interface AlertV2EffectiveRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#service_principal_name AlertV2#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#user_name AlertV2#user_name}
    */
    readonly userName?: string;
}
export declare function alertV2EffectiveRunAsToTerraform(struct?: AlertV2EffectiveRunAs): any;
export declare function alertV2EffectiveRunAsToHclTerraform(struct?: AlertV2EffectiveRunAs): any;
export declare class AlertV2EffectiveRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2EffectiveRunAs | undefined;
    set internalValue(value: AlertV2EffectiveRunAs | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface AlertV2EvaluationNotificationSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#destination_id AlertV2#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#user_email AlertV2#user_email}
    */
    readonly userEmail?: string;
}
export declare function alertV2EvaluationNotificationSubscriptionsToTerraform(struct?: AlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable): any;
export declare function alertV2EvaluationNotificationSubscriptionsToHclTerraform(struct?: AlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable): any;
export declare class AlertV2EvaluationNotificationSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string;
    set userEmail(value: string);
    resetUserEmail(): void;
    get userEmailInput(): string | undefined;
}
export declare class AlertV2EvaluationNotificationSubscriptionsList extends cdktn.ComplexList {
    internalValue?: AlertV2EvaluationNotificationSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlertV2EvaluationNotificationSubscriptionsOutputReference;
}
export interface AlertV2EvaluationNotification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#notify_on_ok AlertV2#notify_on_ok}
    */
    readonly notifyOnOk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#retrigger_seconds AlertV2#retrigger_seconds}
    */
    readonly retriggerSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#subscriptions AlertV2#subscriptions}
    */
    readonly subscriptions?: AlertV2EvaluationNotificationSubscriptions[] | cdktn.IResolvable;
}
export declare function alertV2EvaluationNotificationToTerraform(struct?: AlertV2EvaluationNotification | cdktn.IResolvable): any;
export declare function alertV2EvaluationNotificationToHclTerraform(struct?: AlertV2EvaluationNotification | cdktn.IResolvable): any;
export declare class AlertV2EvaluationNotificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2EvaluationNotification | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2EvaluationNotification | cdktn.IResolvable | undefined);
    get effectiveNotifyOnOk(): cdktn.IResolvable;
    get effectiveRetriggerSeconds(): number;
    private _notifyOnOk?;
    get notifyOnOk(): boolean | cdktn.IResolvable;
    set notifyOnOk(value: boolean | cdktn.IResolvable);
    resetNotifyOnOk(): void;
    get notifyOnOkInput(): boolean | cdktn.IResolvable | undefined;
    private _retriggerSeconds?;
    get retriggerSeconds(): number;
    set retriggerSeconds(value: number);
    resetRetriggerSeconds(): void;
    get retriggerSecondsInput(): number | undefined;
    private _subscriptions;
    get subscriptions(): AlertV2EvaluationNotificationSubscriptionsList;
    putSubscriptions(value: AlertV2EvaluationNotificationSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | AlertV2EvaluationNotificationSubscriptions[] | undefined;
}
export interface AlertV2EvaluationSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#aggregation AlertV2#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#display AlertV2#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#name AlertV2#name}
    */
    readonly name: string;
}
export declare function alertV2EvaluationSourceToTerraform(struct?: AlertV2EvaluationSource | cdktn.IResolvable): any;
export declare function alertV2EvaluationSourceToHclTerraform(struct?: AlertV2EvaluationSource | cdktn.IResolvable): any;
export declare class AlertV2EvaluationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2EvaluationSource | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2EvaluationSource | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AlertV2EvaluationThresholdColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#aggregation AlertV2#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#display AlertV2#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#name AlertV2#name}
    */
    readonly name: string;
}
export declare function alertV2EvaluationThresholdColumnToTerraform(struct?: AlertV2EvaluationThresholdColumn | cdktn.IResolvable): any;
export declare function alertV2EvaluationThresholdColumnToHclTerraform(struct?: AlertV2EvaluationThresholdColumn | cdktn.IResolvable): any;
export declare class AlertV2EvaluationThresholdColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2EvaluationThresholdColumn | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2EvaluationThresholdColumn | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AlertV2EvaluationThresholdValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#bool_value AlertV2#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#double_value AlertV2#double_value}
    */
    readonly doubleValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#string_value AlertV2#string_value}
    */
    readonly stringValue?: string;
}
export declare function alertV2EvaluationThresholdValueToTerraform(struct?: AlertV2EvaluationThresholdValue | cdktn.IResolvable): any;
export declare function alertV2EvaluationThresholdValueToHclTerraform(struct?: AlertV2EvaluationThresholdValue | cdktn.IResolvable): any;
export declare class AlertV2EvaluationThresholdValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2EvaluationThresholdValue | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2EvaluationThresholdValue | cdktn.IResolvable | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface AlertV2EvaluationThreshold {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#column AlertV2#column}
    */
    readonly column?: AlertV2EvaluationThresholdColumn;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#value AlertV2#value}
    */
    readonly value?: AlertV2EvaluationThresholdValue;
}
export declare function alertV2EvaluationThresholdToTerraform(struct?: AlertV2EvaluationThreshold | cdktn.IResolvable): any;
export declare function alertV2EvaluationThresholdToHclTerraform(struct?: AlertV2EvaluationThreshold | cdktn.IResolvable): any;
export declare class AlertV2EvaluationThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2EvaluationThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2EvaluationThreshold | cdktn.IResolvable | undefined);
    private _column;
    get column(): AlertV2EvaluationThresholdColumnOutputReference;
    putColumn(value: AlertV2EvaluationThresholdColumn): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | AlertV2EvaluationThresholdColumn | undefined;
    private _value;
    get value(): AlertV2EvaluationThresholdValueOutputReference;
    putValue(value: AlertV2EvaluationThresholdValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | AlertV2EvaluationThresholdValue | undefined;
}
export interface AlertV2Evaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#comparison_operator AlertV2#comparison_operator}
    */
    readonly comparisonOperator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#empty_result_state AlertV2#empty_result_state}
    */
    readonly emptyResultState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#notification AlertV2#notification}
    */
    readonly notification?: AlertV2EvaluationNotification;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#source AlertV2#source}
    */
    readonly source: AlertV2EvaluationSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#threshold AlertV2#threshold}
    */
    readonly threshold?: AlertV2EvaluationThreshold;
}
export declare function alertV2EvaluationToTerraform(struct?: AlertV2Evaluation | cdktn.IResolvable): any;
export declare function alertV2EvaluationToHclTerraform(struct?: AlertV2Evaluation | cdktn.IResolvable): any;
export declare class AlertV2EvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2Evaluation | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2Evaluation | cdktn.IResolvable | undefined);
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    get comparisonOperatorInput(): string | undefined;
    private _emptyResultState?;
    get emptyResultState(): string;
    set emptyResultState(value: string);
    resetEmptyResultState(): void;
    get emptyResultStateInput(): string | undefined;
    get lastEvaluatedAt(): string;
    private _notification;
    get notification(): AlertV2EvaluationNotificationOutputReference;
    putNotification(value: AlertV2EvaluationNotification): void;
    resetNotification(): void;
    get notificationInput(): cdktn.IResolvable | AlertV2EvaluationNotification | undefined;
    private _source;
    get source(): AlertV2EvaluationSourceOutputReference;
    putSource(value: AlertV2EvaluationSource): void;
    get sourceInput(): cdktn.IResolvable | AlertV2EvaluationSource | undefined;
    get state(): string;
    private _threshold;
    get threshold(): AlertV2EvaluationThresholdOutputReference;
    putThreshold(value: AlertV2EvaluationThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | AlertV2EvaluationThreshold | undefined;
}
export interface AlertV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#workspace_id AlertV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function alertV2ProviderConfigToTerraform(struct?: AlertV2ProviderConfig | cdktn.IResolvable): any;
export declare function alertV2ProviderConfigToHclTerraform(struct?: AlertV2ProviderConfig | cdktn.IResolvable): any;
export declare class AlertV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface AlertV2RunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#service_principal_name AlertV2#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#user_name AlertV2#user_name}
    */
    readonly userName?: string;
}
export declare function alertV2RunAsToTerraform(struct?: AlertV2RunAs | cdktn.IResolvable): any;
export declare function alertV2RunAsToHclTerraform(struct?: AlertV2RunAs | cdktn.IResolvable): any;
export declare class AlertV2RunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2RunAs | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2RunAs | cdktn.IResolvable | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface AlertV2Schedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#pause_status AlertV2#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#quartz_cron_schedule AlertV2#quartz_cron_schedule}
    */
    readonly quartzCronSchedule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#timezone_id AlertV2#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function alertV2ScheduleToTerraform(struct?: AlertV2Schedule | cdktn.IResolvable): any;
export declare function alertV2ScheduleToHclTerraform(struct?: AlertV2Schedule | cdktn.IResolvable): any;
export declare class AlertV2ScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertV2Schedule | cdktn.IResolvable | undefined;
    set internalValue(value: AlertV2Schedule | cdktn.IResolvable | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _quartzCronSchedule?;
    get quartzCronSchedule(): string;
    set quartzCronSchedule(value: string);
    get quartzCronScheduleInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2 databricks_alert_v2}
*/
export declare class AlertV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_alert_v2";
    /**
    * Generates CDKTN code for importing a AlertV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlertV2 to import
    * @param importFromId The id of the existing AlertV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlertV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/alert_v2 databricks_alert_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertV2Config
    */
    constructor(scope: Construct, id: string, config: AlertV2Config);
    get createTime(): string;
    private _customDescription?;
    get customDescription(): string;
    set customDescription(value: string);
    resetCustomDescription(): void;
    get customDescriptionInput(): string | undefined;
    private _customSummary?;
    get customSummary(): string;
    set customSummary(value: string);
    resetCustomSummary(): void;
    get customSummaryInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _effectiveRunAs;
    get effectiveRunAs(): AlertV2EffectiveRunAsOutputReference;
    private _evaluation;
    get evaluation(): AlertV2EvaluationOutputReference;
    putEvaluation(value: AlertV2Evaluation): void;
    get evaluationInput(): cdktn.IResolvable | AlertV2Evaluation | undefined;
    get id(): string;
    get lifecycleState(): string;
    get ownerUserName(): string;
    private _parentPath?;
    get parentPath(): string;
    set parentPath(value: string);
    resetParentPath(): void;
    get parentPathInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AlertV2ProviderConfigOutputReference;
    putProviderConfig(value: AlertV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AlertV2ProviderConfig | undefined;
    private _purgeOnDelete?;
    get purgeOnDelete(): boolean | cdktn.IResolvable;
    set purgeOnDelete(value: boolean | cdktn.IResolvable);
    resetPurgeOnDelete(): void;
    get purgeOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _queryText?;
    get queryText(): string;
    set queryText(value: string);
    get queryTextInput(): string | undefined;
    private _runAs;
    get runAs(): AlertV2RunAsOutputReference;
    putRunAs(value: AlertV2RunAs): void;
    resetRunAs(): void;
    get runAsInput(): cdktn.IResolvable | AlertV2RunAs | undefined;
    private _runAsUserName?;
    get runAsUserName(): string;
    set runAsUserName(value: string);
    resetRunAsUserName(): void;
    get runAsUserNameInput(): string | undefined;
    private _schedule;
    get schedule(): AlertV2ScheduleOutputReference;
    putSchedule(value: AlertV2Schedule): void;
    get scheduleInput(): cdktn.IResolvable | AlertV2Schedule | undefined;
    get updateTime(): string;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
