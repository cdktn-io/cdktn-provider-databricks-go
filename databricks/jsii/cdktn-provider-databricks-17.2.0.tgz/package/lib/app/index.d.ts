/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#budget_policy_id App#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#compute_max_instances App#compute_max_instances}
    */
    readonly computeMaxInstances?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#compute_min_instances App#compute_min_instances}
    */
    readonly computeMinInstances?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#compute_size App#compute_size}
    */
    readonly computeSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#description App#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#git_repository App#git_repository}
    */
    readonly gitRepository?: AppGitRepository;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#no_compute App#no_compute}
    */
    readonly noCompute?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#provider_config App#provider_config}
    */
    readonly providerConfig?: AppProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#resources App#resources}
    */
    readonly resources?: AppResources[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#space App#space}
    */
    readonly space?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#telemetry_export_destinations App#telemetry_export_destinations}
    */
    readonly telemetryExportDestinations?: AppTelemetryExportDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#usage_policy_id App#usage_policy_id}
    */
    readonly usagePolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#user_api_scopes App#user_api_scopes}
    */
    readonly userApiScopes?: string[];
}
export interface AppActiveDeploymentDeploymentArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#source_code_path App#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function appActiveDeploymentDeploymentArtifactsToTerraform(struct?: AppActiveDeploymentDeploymentArtifacts): any;
export declare function appActiveDeploymentDeploymentArtifactsToHclTerraform(struct?: AppActiveDeploymentDeploymentArtifacts): any;
export declare class AppActiveDeploymentDeploymentArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppActiveDeploymentDeploymentArtifacts | undefined;
    set internalValue(value: AppActiveDeploymentDeploymentArtifacts | undefined);
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
}
export interface AppActiveDeploymentEnvVars {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#name App#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#value_from App#value_from}
    */
    readonly valueFrom?: string;
}
export declare function appActiveDeploymentEnvVarsToTerraform(struct?: AppActiveDeploymentEnvVars | cdktn.IResolvable): any;
export declare function appActiveDeploymentEnvVarsToHclTerraform(struct?: AppActiveDeploymentEnvVars | cdktn.IResolvable): any;
export declare class AppActiveDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppActiveDeploymentEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: AppActiveDeploymentEnvVars | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class AppActiveDeploymentEnvVarsList extends cdktn.ComplexList {
    internalValue?: AppActiveDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppActiveDeploymentEnvVarsOutputReference;
}
export interface AppActiveDeploymentGitSourceGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#provider App#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appActiveDeploymentGitSourceGitRepositoryToTerraform(struct?: AppActiveDeploymentGitSourceGitRepository): any;
export declare function appActiveDeploymentGitSourceGitRepositoryToHclTerraform(struct?: AppActiveDeploymentGitSourceGitRepository): any;
export declare class AppActiveDeploymentGitSourceGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppActiveDeploymentGitSourceGitRepository | undefined;
    set internalValue(value: AppActiveDeploymentGitSourceGitRepository | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AppActiveDeploymentGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#commit App#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#source_code_path App#source_code_path}
    */
    readonly sourceCodePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#tag App#tag}
    */
    readonly tag?: string;
}
export declare function appActiveDeploymentGitSourceToTerraform(struct?: AppActiveDeploymentGitSource | cdktn.IResolvable): any;
export declare function appActiveDeploymentGitSourceToHclTerraform(struct?: AppActiveDeploymentGitSource | cdktn.IResolvable): any;
export declare class AppActiveDeploymentGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppActiveDeploymentGitSource | cdktn.IResolvable | undefined;
    set internalValue(value: AppActiveDeploymentGitSource | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _gitRepository;
    get gitRepository(): AppActiveDeploymentGitSourceGitRepositoryOutputReference;
    get resolvedCommit(): string;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface AppActiveDeploymentStatus {
}
export declare function appActiveDeploymentStatusToTerraform(struct?: AppActiveDeploymentStatus): any;
export declare function appActiveDeploymentStatusToHclTerraform(struct?: AppActiveDeploymentStatus): any;
export declare class AppActiveDeploymentStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppActiveDeploymentStatus | undefined;
    set internalValue(value: AppActiveDeploymentStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface AppActiveDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#command App#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#deployment_id App#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#env_vars App#env_vars}
    */
    readonly envVars?: AppActiveDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#git_source App#git_source}
    */
    readonly gitSource?: AppActiveDeploymentGitSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#mode App#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#source_code_path App#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function appActiveDeploymentToTerraform(struct?: AppActiveDeployment): any;
export declare function appActiveDeploymentToHclTerraform(struct?: AppActiveDeployment): any;
export declare class AppActiveDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppActiveDeployment | undefined;
    set internalValue(value: AppActiveDeployment | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    get createTime(): string;
    get creator(): string;
    private _deploymentArtifacts;
    get deploymentArtifacts(): AppActiveDeploymentDeploymentArtifactsOutputReference;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _envVars;
    get envVars(): AppActiveDeploymentEnvVarsList;
    putEnvVars(value: AppActiveDeploymentEnvVars[] | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | AppActiveDeploymentEnvVars[] | undefined;
    private _gitSource;
    get gitSource(): AppActiveDeploymentGitSourceOutputReference;
    putGitSource(value: AppActiveDeploymentGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): cdktn.IResolvable | AppActiveDeploymentGitSource | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _status;
    get status(): AppActiveDeploymentStatusOutputReference;
    get updateTime(): string;
}
export interface AppAppStatus {
}
export declare function appAppStatusToTerraform(struct?: AppAppStatus): any;
export declare function appAppStatusToHclTerraform(struct?: AppAppStatus): any;
export declare class AppAppStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppAppStatus | undefined;
    set internalValue(value: AppAppStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface AppComputeStatus {
}
export declare function appComputeStatusToTerraform(struct?: AppComputeStatus): any;
export declare function appComputeStatusToHclTerraform(struct?: AppComputeStatus): any;
export declare class AppComputeStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppComputeStatus | undefined;
    set internalValue(value: AppComputeStatus | undefined);
    get activeInstances(): number;
    get message(): string;
    get state(): string;
}
export interface AppGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#provider App#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appGitRepositoryToTerraform(struct?: AppGitRepository | cdktn.IResolvable): any;
export declare function appGitRepositoryToHclTerraform(struct?: AppGitRepository | cdktn.IResolvable): any;
export declare class AppGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppGitRepository | cdktn.IResolvable | undefined;
    set internalValue(value: AppGitRepository | cdktn.IResolvable | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AppPendingDeploymentDeploymentArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#source_code_path App#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function appPendingDeploymentDeploymentArtifactsToTerraform(struct?: AppPendingDeploymentDeploymentArtifacts): any;
export declare function appPendingDeploymentDeploymentArtifactsToHclTerraform(struct?: AppPendingDeploymentDeploymentArtifacts): any;
export declare class AppPendingDeploymentDeploymentArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppPendingDeploymentDeploymentArtifacts | undefined;
    set internalValue(value: AppPendingDeploymentDeploymentArtifacts | undefined);
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
}
export interface AppPendingDeploymentEnvVars {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#name App#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#value App#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#value_from App#value_from}
    */
    readonly valueFrom?: string;
}
export declare function appPendingDeploymentEnvVarsToTerraform(struct?: AppPendingDeploymentEnvVars | cdktn.IResolvable): any;
export declare function appPendingDeploymentEnvVarsToHclTerraform(struct?: AppPendingDeploymentEnvVars | cdktn.IResolvable): any;
export declare class AppPendingDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppPendingDeploymentEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: AppPendingDeploymentEnvVars | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class AppPendingDeploymentEnvVarsList extends cdktn.ComplexList {
    internalValue?: AppPendingDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppPendingDeploymentEnvVarsOutputReference;
}
export interface AppPendingDeploymentGitSourceGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#provider App#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#url App#url}
    */
    readonly url: string;
}
export declare function appPendingDeploymentGitSourceGitRepositoryToTerraform(struct?: AppPendingDeploymentGitSourceGitRepository): any;
export declare function appPendingDeploymentGitSourceGitRepositoryToHclTerraform(struct?: AppPendingDeploymentGitSourceGitRepository): any;
export declare class AppPendingDeploymentGitSourceGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppPendingDeploymentGitSourceGitRepository | undefined;
    set internalValue(value: AppPendingDeploymentGitSourceGitRepository | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface AppPendingDeploymentGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#commit App#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#source_code_path App#source_code_path}
    */
    readonly sourceCodePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#tag App#tag}
    */
    readonly tag?: string;
}
export declare function appPendingDeploymentGitSourceToTerraform(struct?: AppPendingDeploymentGitSource | cdktn.IResolvable): any;
export declare function appPendingDeploymentGitSourceToHclTerraform(struct?: AppPendingDeploymentGitSource | cdktn.IResolvable): any;
export declare class AppPendingDeploymentGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppPendingDeploymentGitSource | cdktn.IResolvable | undefined;
    set internalValue(value: AppPendingDeploymentGitSource | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _gitRepository;
    get gitRepository(): AppPendingDeploymentGitSourceGitRepositoryOutputReference;
    get resolvedCommit(): string;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface AppPendingDeploymentStatus {
}
export declare function appPendingDeploymentStatusToTerraform(struct?: AppPendingDeploymentStatus): any;
export declare function appPendingDeploymentStatusToHclTerraform(struct?: AppPendingDeploymentStatus): any;
export declare class AppPendingDeploymentStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppPendingDeploymentStatus | undefined;
    set internalValue(value: AppPendingDeploymentStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface AppPendingDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#command App#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#deployment_id App#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#env_vars App#env_vars}
    */
    readonly envVars?: AppPendingDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#git_source App#git_source}
    */
    readonly gitSource?: AppPendingDeploymentGitSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#mode App#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#source_code_path App#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function appPendingDeploymentToTerraform(struct?: AppPendingDeployment): any;
export declare function appPendingDeploymentToHclTerraform(struct?: AppPendingDeployment): any;
export declare class AppPendingDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppPendingDeployment | undefined;
    set internalValue(value: AppPendingDeployment | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    get createTime(): string;
    get creator(): string;
    private _deploymentArtifacts;
    get deploymentArtifacts(): AppPendingDeploymentDeploymentArtifactsOutputReference;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _envVars;
    get envVars(): AppPendingDeploymentEnvVarsList;
    putEnvVars(value: AppPendingDeploymentEnvVars[] | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | AppPendingDeploymentEnvVars[] | undefined;
    private _gitSource;
    get gitSource(): AppPendingDeploymentGitSourceOutputReference;
    putGitSource(value: AppPendingDeploymentGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): cdktn.IResolvable | AppPendingDeploymentGitSource | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _status;
    get status(): AppPendingDeploymentStatusOutputReference;
    get updateTime(): string;
}
export interface AppProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#workspace_id App#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function appProviderConfigToTerraform(struct?: AppProviderConfig | cdktn.IResolvable): any;
export declare function appProviderConfigToHclTerraform(struct?: AppProviderConfig | cdktn.IResolvable): any;
export declare class AppProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface AppResourcesApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#name App#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission?: string;
}
export declare function appResourcesAppToTerraform(struct?: AppResourcesApp | cdktn.IResolvable): any;
export declare function appResourcesAppToHclTerraform(struct?: AppResourcesApp | cdktn.IResolvable): any;
export declare class AppResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesApp | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface AppResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#database_name App#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#instance_name App#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
}
export declare function appResourcesDatabaseToTerraform(struct?: AppResourcesDatabase | cdktn.IResolvable): any;
export declare function appResourcesDatabaseToHclTerraform(struct?: AppResourcesDatabase | cdktn.IResolvable): any;
export declare class AppResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#experiment_id App#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
}
export declare function appResourcesExperimentToTerraform(struct?: AppResourcesExperiment | cdktn.IResolvable): any;
export declare function appResourcesExperimentToHclTerraform(struct?: AppResourcesExperiment | cdktn.IResolvable): any;
export declare class AppResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#space_id App#space_id}
    */
    readonly spaceId: string;
}
export declare function appResourcesGenieSpaceToTerraform(struct?: AppResourcesGenieSpace | cdktn.IResolvable): any;
export declare function appResourcesGenieSpaceToHclTerraform(struct?: AppResourcesGenieSpace | cdktn.IResolvable): any;
export declare class AppResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface AppResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#id App#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
}
export declare function appResourcesJobToTerraform(struct?: AppResourcesJob | cdktn.IResolvable): any;
export declare function appResourcesJobToHclTerraform(struct?: AppResourcesJob | cdktn.IResolvable): any;
export declare class AppResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppResourcesPostgres {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#branch App#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#database App#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission?: string;
}
export declare function appResourcesPostgresToTerraform(struct?: AppResourcesPostgres | cdktn.IResolvable): any;
export declare function appResourcesPostgresToHclTerraform(struct?: AppResourcesPostgres | cdktn.IResolvable): any;
export declare class AppResourcesPostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesPostgres | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesPostgres | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface AppResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#key App#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#scope App#scope}
    */
    readonly scope: string;
}
export declare function appResourcesSecretToTerraform(struct?: AppResourcesSecret | cdktn.IResolvable): any;
export declare function appResourcesSecretToHclTerraform(struct?: AppResourcesSecret | cdktn.IResolvable): any;
export declare class AppResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface AppResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
}
export declare function appResourcesServingEndpointToTerraform(struct?: AppResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function appResourcesServingEndpointToHclTerraform(struct?: AppResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class AppResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#id App#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
}
export declare function appResourcesSqlWarehouseToTerraform(struct?: AppResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function appResourcesSqlWarehouseToHclTerraform(struct?: AppResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class AppResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#permission App#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#securable_full_name App#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#securable_type App#securable_type}
    */
    readonly securableType: string;
}
export declare function appResourcesUcSecurableToTerraform(struct?: AppResourcesUcSecurable | cdktn.IResolvable): any;
export declare function appResourcesUcSecurableToHclTerraform(struct?: AppResourcesUcSecurable | cdktn.IResolvable): any;
export declare class AppResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: AppResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface AppResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#app App#app}
    */
    readonly app?: AppResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#database App#database}
    */
    readonly database?: AppResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#description App#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#experiment App#experiment}
    */
    readonly experiment?: AppResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#genie_space App#genie_space}
    */
    readonly genieSpace?: AppResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#job App#job}
    */
    readonly job?: AppResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#name App#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#postgres App#postgres}
    */
    readonly postgres?: AppResourcesPostgres;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#secret App#secret}
    */
    readonly secret?: AppResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#serving_endpoint App#serving_endpoint}
    */
    readonly servingEndpoint?: AppResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#sql_warehouse App#sql_warehouse}
    */
    readonly sqlWarehouse?: AppResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#uc_securable App#uc_securable}
    */
    readonly ucSecurable?: AppResourcesUcSecurable;
}
export declare function appResourcesToTerraform(struct?: AppResources | cdktn.IResolvable): any;
export declare function appResourcesToHclTerraform(struct?: AppResources | cdktn.IResolvable): any;
export declare class AppResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppResources | cdktn.IResolvable | undefined;
    set internalValue(value: AppResources | cdktn.IResolvable | undefined);
    private _app;
    get app(): AppResourcesAppOutputReference;
    putApp(value: AppResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | AppResourcesApp | undefined;
    private _database;
    get database(): AppResourcesDatabaseOutputReference;
    putDatabase(value: AppResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | AppResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): AppResourcesExperimentOutputReference;
    putExperiment(value: AppResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | AppResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): AppResourcesGenieSpaceOutputReference;
    putGenieSpace(value: AppResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | AppResourcesGenieSpace | undefined;
    private _job;
    get job(): AppResourcesJobOutputReference;
    putJob(value: AppResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | AppResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _postgres;
    get postgres(): AppResourcesPostgresOutputReference;
    putPostgres(value: AppResourcesPostgres): void;
    resetPostgres(): void;
    get postgresInput(): cdktn.IResolvable | AppResourcesPostgres | undefined;
    private _secret;
    get secret(): AppResourcesSecretOutputReference;
    putSecret(value: AppResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | AppResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): AppResourcesServingEndpointOutputReference;
    putServingEndpoint(value: AppResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | AppResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): AppResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: AppResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | AppResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): AppResourcesUcSecurableOutputReference;
    putUcSecurable(value: AppResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | AppResourcesUcSecurable | undefined;
}
export declare class AppResourcesList extends cdktn.ComplexList {
    internalValue?: AppResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppResourcesOutputReference;
}
export interface AppTelemetryExportDestinationsUnityCatalog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#logs_table App#logs_table}
    */
    readonly logsTable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#metrics_table App#metrics_table}
    */
    readonly metricsTable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#traces_table App#traces_table}
    */
    readonly tracesTable: string;
}
export declare function appTelemetryExportDestinationsUnityCatalogToTerraform(struct?: AppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable): any;
export declare function appTelemetryExportDestinationsUnityCatalogToHclTerraform(struct?: AppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable): any;
export declare class AppTelemetryExportDestinationsUnityCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable | undefined;
    set internalValue(value: AppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable | undefined);
    private _logsTable?;
    get logsTable(): string;
    set logsTable(value: string);
    get logsTableInput(): string | undefined;
    private _metricsTable?;
    get metricsTable(): string;
    set metricsTable(value: string);
    get metricsTableInput(): string | undefined;
    private _tracesTable?;
    get tracesTable(): string;
    set tracesTable(value: string);
    get tracesTableInput(): string | undefined;
}
export interface AppTelemetryExportDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#unity_catalog App#unity_catalog}
    */
    readonly unityCatalog?: AppTelemetryExportDestinationsUnityCatalog;
}
export declare function appTelemetryExportDestinationsToTerraform(struct?: AppTelemetryExportDestinations | cdktn.IResolvable): any;
export declare function appTelemetryExportDestinationsToHclTerraform(struct?: AppTelemetryExportDestinations | cdktn.IResolvable): any;
export declare class AppTelemetryExportDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppTelemetryExportDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AppTelemetryExportDestinations | cdktn.IResolvable | undefined);
    private _unityCatalog;
    get unityCatalog(): AppTelemetryExportDestinationsUnityCatalogOutputReference;
    putUnityCatalog(value: AppTelemetryExportDestinationsUnityCatalog): void;
    resetUnityCatalog(): void;
    get unityCatalogInput(): cdktn.IResolvable | AppTelemetryExportDestinationsUnityCatalog | undefined;
}
export declare class AppTelemetryExportDestinationsList extends cdktn.ComplexList {
    internalValue?: AppTelemetryExportDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppTelemetryExportDestinationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app databricks_app}
*/
export declare class App extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_app";
    /**
    * Generates CDKTN code for importing a App resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the App to import
    * @param importFromId The id of the existing App that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the App to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/app databricks_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppConfig
    */
    constructor(scope: Construct, id: string, config: AppConfig);
    private _activeDeployment;
    get activeDeployment(): AppActiveDeploymentOutputReference;
    private _appStatus;
    get appStatus(): AppAppStatusOutputReference;
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _computeMaxInstances?;
    get computeMaxInstances(): number;
    set computeMaxInstances(value: number);
    resetComputeMaxInstances(): void;
    get computeMaxInstancesInput(): number | undefined;
    private _computeMinInstances?;
    get computeMinInstances(): number;
    set computeMinInstances(value: number);
    resetComputeMinInstances(): void;
    get computeMinInstancesInput(): number | undefined;
    private _computeSize?;
    get computeSize(): string;
    set computeSize(value: string);
    resetComputeSize(): void;
    get computeSizeInput(): string | undefined;
    private _computeStatus;
    get computeStatus(): AppComputeStatusOutputReference;
    get createTime(): string;
    get creator(): string;
    get defaultSourceCodePath(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveBudgetPolicyId(): string;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    private _gitRepository;
    get gitRepository(): AppGitRepositoryOutputReference;
    putGitRepository(value: AppGitRepository): void;
    resetGitRepository(): void;
    get gitRepositoryInput(): cdktn.IResolvable | AppGitRepository | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _noCompute?;
    get noCompute(): boolean | cdktn.IResolvable;
    set noCompute(value: boolean | cdktn.IResolvable);
    resetNoCompute(): void;
    get noComputeInput(): boolean | cdktn.IResolvable | undefined;
    get oauth2AppClientId(): string;
    get oauth2AppIntegrationId(): string;
    private _pendingDeployment;
    get pendingDeployment(): AppPendingDeploymentOutputReference;
    private _providerConfig;
    get providerConfig(): AppProviderConfigOutputReference;
    putProviderConfig(value: AppProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AppProviderConfig | undefined;
    private _resources;
    get resources(): AppResourcesList;
    putResources(value: AppResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | AppResources[] | undefined;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _space?;
    get space(): string;
    set space(value: string);
    resetSpace(): void;
    get spaceInput(): string | undefined;
    private _telemetryExportDestinations;
    get telemetryExportDestinations(): AppTelemetryExportDestinationsList;
    putTelemetryExportDestinations(value: AppTelemetryExportDestinations[] | cdktn.IResolvable): void;
    resetTelemetryExportDestinations(): void;
    get telemetryExportDestinationsInput(): cdktn.IResolvable | AppTelemetryExportDestinations[] | undefined;
    get thumbnailUrl(): string;
    get updateTime(): string;
    get updater(): string;
    get url(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    private _userApiScopes?;
    get userApiScopes(): string[];
    set userApiScopes(value: string[]);
    resetUserApiScopes(): void;
    get userApiScopesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
