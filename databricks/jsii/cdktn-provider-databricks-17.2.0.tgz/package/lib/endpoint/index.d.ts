/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint#azure_private_endpoint_info Endpoint#azure_private_endpoint_info}
    */
    readonly azurePrivateEndpointInfo?: EndpointAzurePrivateEndpointInfo;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint#display_name Endpoint#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint#parent Endpoint#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint#region Endpoint#region}
    */
    readonly region: string;
}
export interface EndpointAzurePrivateEndpointInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint#private_endpoint_name Endpoint#private_endpoint_name}
    */
    readonly privateEndpointName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint#private_endpoint_resource_guid Endpoint#private_endpoint_resource_guid}
    */
    readonly privateEndpointResourceGuid: string;
}
export declare function endpointAzurePrivateEndpointInfoToTerraform(struct?: EndpointAzurePrivateEndpointInfo | cdktn.IResolvable): any;
export declare function endpointAzurePrivateEndpointInfoToHclTerraform(struct?: EndpointAzurePrivateEndpointInfo | cdktn.IResolvable): any;
export declare class EndpointAzurePrivateEndpointInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EndpointAzurePrivateEndpointInfo | cdktn.IResolvable | undefined;
    set internalValue(value: EndpointAzurePrivateEndpointInfo | cdktn.IResolvable | undefined);
    private _privateEndpointName?;
    get privateEndpointName(): string;
    set privateEndpointName(value: string);
    get privateEndpointNameInput(): string | undefined;
    private _privateEndpointResourceGuid?;
    get privateEndpointResourceGuid(): string;
    set privateEndpointResourceGuid(value: string);
    get privateEndpointResourceGuidInput(): string | undefined;
    get privateEndpointResourceId(): string;
    get privateLinkServiceId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint databricks_endpoint}
*/
export declare class Endpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_endpoint";
    /**
    * Generates CDKTN code for importing a Endpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Endpoint to import
    * @param importFromId The id of the existing Endpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Endpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/endpoint databricks_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EndpointConfig
    */
    constructor(scope: Construct, id: string, config: EndpointConfig);
    get accountId(): string;
    private _azurePrivateEndpointInfo;
    get azurePrivateEndpointInfo(): EndpointAzurePrivateEndpointInfoOutputReference;
    putAzurePrivateEndpointInfo(value: EndpointAzurePrivateEndpointInfo): void;
    resetAzurePrivateEndpointInfo(): void;
    get azurePrivateEndpointInfoInput(): cdktn.IResolvable | EndpointAzurePrivateEndpointInfo | undefined;
    get createTime(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get endpointId(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get state(): string;
    get useCase(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
