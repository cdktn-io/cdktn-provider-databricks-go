/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretUcConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#catalog_name SecretUc#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#comment SecretUc#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#expire_time SecretUc#expire_time}
    */
    readonly expireTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#name SecretUc#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#owner SecretUc#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#provider_config SecretUc#provider_config}
    */
    readonly providerConfig?: SecretUcProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#schema_name SecretUc#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#value SecretUc#value}
    */
    readonly value: string;
}
export interface SecretUcProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#workspace_id SecretUc#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function secretUcProviderConfigToTerraform(struct?: SecretUcProviderConfig | cdktn.IResolvable): any;
export declare function secretUcProviderConfigToHclTerraform(struct?: SecretUcProviderConfig | cdktn.IResolvable): any;
export declare class SecretUcProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecretUcProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: SecretUcProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc databricks_secret_uc}
*/
export declare class SecretUc extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_secret_uc";
    /**
    * Generates CDKTN code for importing a SecretUc resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretUc to import
    * @param importFromId The id of the existing SecretUc that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretUc to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/resources/secret_uc databricks_secret_uc} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretUcConfig
    */
    constructor(scope: Construct, id: string, config: SecretUcConfig);
    get browseOnly(): cdktn.IResolvable;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get effectiveValue(): string;
    private _expireTime?;
    get expireTime(): string;
    set expireTime(value: string);
    resetExpireTime(): void;
    get expireTimeInput(): string | undefined;
    get externalSecretId(): string;
    get fullName(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): SecretUcProviderConfigOutputReference;
    putProviderConfig(value: SecretUcProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | SecretUcProviderConfig | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    get updateTime(): string;
    get updatedBy(): string;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
