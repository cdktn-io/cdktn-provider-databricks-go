/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksFunctionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#catalog_name DataDatabricksFunctions#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#functions DataDatabricksFunctions#functions}
    */
    readonly functions?: DataDatabricksFunctionsFunctions[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#include_browse DataDatabricksFunctions#include_browse}
    */
    readonly includeBrowse?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#provider_config DataDatabricksFunctions#provider_config}
    */
    readonly providerConfig?: DataDatabricksFunctionsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#schema_name DataDatabricksFunctions#schema_name}
    */
    readonly schemaName: string;
}
export interface DataDatabricksFunctionsFunctionsInputParamsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#comment DataDatabricksFunctions#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#name DataDatabricksFunctions#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameter_default DataDatabricksFunctions#parameter_default}
    */
    readonly parameterDefault?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameter_mode DataDatabricksFunctions#parameter_mode}
    */
    readonly parameterMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameter_type DataDatabricksFunctions#parameter_type}
    */
    readonly parameterType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#position DataDatabricksFunctions#position}
    */
    readonly position: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_interval_type DataDatabricksFunctions#type_interval_type}
    */
    readonly typeIntervalType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_json DataDatabricksFunctions#type_json}
    */
    readonly typeJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_name DataDatabricksFunctions#type_name}
    */
    readonly typeName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_precision DataDatabricksFunctions#type_precision}
    */
    readonly typePrecision?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_scale DataDatabricksFunctions#type_scale}
    */
    readonly typeScale?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_text DataDatabricksFunctions#type_text}
    */
    readonly typeText: string;
}
export declare function dataDatabricksFunctionsFunctionsInputParamsParametersToTerraform(struct?: DataDatabricksFunctionsFunctionsInputParamsParameters | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsInputParamsParametersToHclTerraform(struct?: DataDatabricksFunctionsFunctionsInputParamsParameters | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsInputParamsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFunctionsFunctionsInputParamsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsInputParamsParameters | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameterDefault?;
    get parameterDefault(): string;
    set parameterDefault(value: string);
    resetParameterDefault(): void;
    get parameterDefaultInput(): string | undefined;
    private _parameterMode?;
    get parameterMode(): string;
    set parameterMode(value: string);
    resetParameterMode(): void;
    get parameterModeInput(): string | undefined;
    private _parameterType?;
    get parameterType(): string;
    set parameterType(value: string);
    resetParameterType(): void;
    get parameterTypeInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    get positionInput(): number | undefined;
    private _typeIntervalType?;
    get typeIntervalType(): string;
    set typeIntervalType(value: string);
    resetTypeIntervalType(): void;
    get typeIntervalTypeInput(): string | undefined;
    private _typeJson?;
    get typeJson(): string;
    set typeJson(value: string);
    resetTypeJson(): void;
    get typeJsonInput(): string | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    get typeNameInput(): string | undefined;
    private _typePrecision?;
    get typePrecision(): number;
    set typePrecision(value: number);
    resetTypePrecision(): void;
    get typePrecisionInput(): number | undefined;
    private _typeScale?;
    get typeScale(): number;
    set typeScale(value: number);
    resetTypeScale(): void;
    get typeScaleInput(): number | undefined;
    private _typeText?;
    get typeText(): string;
    set typeText(value: string);
    get typeTextInput(): string | undefined;
}
export declare class DataDatabricksFunctionsFunctionsInputParamsParametersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFunctionsFunctionsInputParamsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFunctionsFunctionsInputParamsParametersOutputReference;
}
export interface DataDatabricksFunctionsFunctionsInputParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameters DataDatabricksFunctions#parameters}
    */
    readonly parameters?: DataDatabricksFunctionsFunctionsInputParamsParameters[] | cdktn.IResolvable;
}
export declare function dataDatabricksFunctionsFunctionsInputParamsToTerraform(struct?: DataDatabricksFunctionsFunctionsInputParams | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsInputParamsToHclTerraform(struct?: DataDatabricksFunctionsFunctionsInputParams | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsInputParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsFunctionsInputParams | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsInputParams | cdktn.IResolvable | undefined);
    private _parameters;
    get parameters(): DataDatabricksFunctionsFunctionsInputParamsParametersList;
    putParameters(value: DataDatabricksFunctionsFunctionsInputParamsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsInputParamsParameters[] | undefined;
}
export interface DataDatabricksFunctionsFunctionsReturnParamsParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#comment DataDatabricksFunctions#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#name DataDatabricksFunctions#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameter_default DataDatabricksFunctions#parameter_default}
    */
    readonly parameterDefault?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameter_mode DataDatabricksFunctions#parameter_mode}
    */
    readonly parameterMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameter_type DataDatabricksFunctions#parameter_type}
    */
    readonly parameterType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#position DataDatabricksFunctions#position}
    */
    readonly position: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_interval_type DataDatabricksFunctions#type_interval_type}
    */
    readonly typeIntervalType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_json DataDatabricksFunctions#type_json}
    */
    readonly typeJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_name DataDatabricksFunctions#type_name}
    */
    readonly typeName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_precision DataDatabricksFunctions#type_precision}
    */
    readonly typePrecision?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_scale DataDatabricksFunctions#type_scale}
    */
    readonly typeScale?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#type_text DataDatabricksFunctions#type_text}
    */
    readonly typeText: string;
}
export declare function dataDatabricksFunctionsFunctionsReturnParamsParametersToTerraform(struct?: DataDatabricksFunctionsFunctionsReturnParamsParameters | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsReturnParamsParametersToHclTerraform(struct?: DataDatabricksFunctionsFunctionsReturnParamsParameters | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsReturnParamsParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFunctionsFunctionsReturnParamsParameters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsReturnParamsParameters | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameterDefault?;
    get parameterDefault(): string;
    set parameterDefault(value: string);
    resetParameterDefault(): void;
    get parameterDefaultInput(): string | undefined;
    private _parameterMode?;
    get parameterMode(): string;
    set parameterMode(value: string);
    resetParameterMode(): void;
    get parameterModeInput(): string | undefined;
    private _parameterType?;
    get parameterType(): string;
    set parameterType(value: string);
    resetParameterType(): void;
    get parameterTypeInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    get positionInput(): number | undefined;
    private _typeIntervalType?;
    get typeIntervalType(): string;
    set typeIntervalType(value: string);
    resetTypeIntervalType(): void;
    get typeIntervalTypeInput(): string | undefined;
    private _typeJson?;
    get typeJson(): string;
    set typeJson(value: string);
    resetTypeJson(): void;
    get typeJsonInput(): string | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    get typeNameInput(): string | undefined;
    private _typePrecision?;
    get typePrecision(): number;
    set typePrecision(value: number);
    resetTypePrecision(): void;
    get typePrecisionInput(): number | undefined;
    private _typeScale?;
    get typeScale(): number;
    set typeScale(value: number);
    resetTypeScale(): void;
    get typeScaleInput(): number | undefined;
    private _typeText?;
    get typeText(): string;
    set typeText(value: string);
    get typeTextInput(): string | undefined;
}
export declare class DataDatabricksFunctionsFunctionsReturnParamsParametersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFunctionsFunctionsReturnParamsParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFunctionsFunctionsReturnParamsParametersOutputReference;
}
export interface DataDatabricksFunctionsFunctionsReturnParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameters DataDatabricksFunctions#parameters}
    */
    readonly parameters?: DataDatabricksFunctionsFunctionsReturnParamsParameters[] | cdktn.IResolvable;
}
export declare function dataDatabricksFunctionsFunctionsReturnParamsToTerraform(struct?: DataDatabricksFunctionsFunctionsReturnParams | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsReturnParamsToHclTerraform(struct?: DataDatabricksFunctionsFunctionsReturnParams | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsReturnParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsFunctionsReturnParams | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsReturnParams | cdktn.IResolvable | undefined);
    private _parameters;
    get parameters(): DataDatabricksFunctionsFunctionsReturnParamsParametersList;
    putParameters(value: DataDatabricksFunctionsFunctionsReturnParamsParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsReturnParamsParameters[] | undefined;
}
export interface DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#connection_name DataDatabricksFunctions#connection_name}
    */
    readonly connectionName?: string;
}
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnectionToTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnectionToHclTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection | cdktn.IResolvable | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
}
export interface DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#credential_name DataDatabricksFunctions#credential_name}
    */
    readonly credentialName?: string;
}
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredentialToTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredentialToHclTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential | cdktn.IResolvable | undefined);
    private _credentialName?;
    get credentialName(): string;
    set credentialName(value: string);
    resetCredentialName(): void;
    get credentialNameInput(): string | undefined;
}
export interface DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#function_full_name DataDatabricksFunctions#function_full_name}
    */
    readonly functionFullName: string;
}
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunctionToTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunctionToHclTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction | cdktn.IResolvable | undefined);
    private _functionFullName?;
    get functionFullName(): string;
    set functionFullName(value: string);
    get functionFullNameInput(): string | undefined;
}
export interface DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#table_full_name DataDatabricksFunctions#table_full_name}
    */
    readonly tableFullName: string;
}
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTableToTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTableToHclTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable | cdktn.IResolvable | undefined);
    private _tableFullName?;
    get tableFullName(): string;
    set tableFullName(value: string);
    get tableFullNameInput(): string | undefined;
}
export interface DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#connection DataDatabricksFunctions#connection}
    */
    readonly connection?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#credential DataDatabricksFunctions#credential}
    */
    readonly credential?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#function DataDatabricksFunctions#function}
    */
    readonly function?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#table DataDatabricksFunctions#table}
    */
    readonly table?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable;
}
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesToTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesToHclTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies | cdktn.IResolvable | undefined);
    private _connection;
    get connection(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnectionOutputReference;
    putConnection(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection): void;
    resetConnection(): void;
    get connectionInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesConnection | undefined;
    private _credential;
    get credential(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredentialOutputReference;
    putCredential(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential): void;
    resetCredential(): void;
    get credentialInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesCredential | undefined;
    private _function;
    get function(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunctionOutputReference;
    putFunction(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction): void;
    resetFunction(): void;
    get functionInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesFunction | undefined;
    private _table;
    get table(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTableOutputReference;
    putTable(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable): void;
    resetTable(): void;
    get tableInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesTable | undefined;
}
export declare class DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesOutputReference;
}
export interface DataDatabricksFunctionsFunctionsRoutineDependencies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#dependencies DataDatabricksFunctions#dependencies}
    */
    readonly dependencies?: DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies[] | cdktn.IResolvable;
}
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesToTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependencies | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsRoutineDependenciesToHclTerraform(struct?: DataDatabricksFunctionsFunctionsRoutineDependencies | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsRoutineDependenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsFunctionsRoutineDependencies | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctionsRoutineDependencies | cdktn.IResolvable | undefined);
    private _dependencies;
    get dependencies(): DataDatabricksFunctionsFunctionsRoutineDependenciesDependenciesList;
    putDependencies(value: DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies[] | cdktn.IResolvable): void;
    resetDependencies(): void;
    get dependenciesInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsRoutineDependenciesDependencies[] | undefined;
}
export interface DataDatabricksFunctionsFunctions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#browse_only DataDatabricksFunctions#browse_only}
    */
    readonly browseOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#catalog_name DataDatabricksFunctions#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#comment DataDatabricksFunctions#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#created_at DataDatabricksFunctions#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#created_by DataDatabricksFunctions#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#data_type DataDatabricksFunctions#data_type}
    */
    readonly dataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#external_language DataDatabricksFunctions#external_language}
    */
    readonly externalLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#external_name DataDatabricksFunctions#external_name}
    */
    readonly externalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#full_data_type DataDatabricksFunctions#full_data_type}
    */
    readonly fullDataType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#full_name DataDatabricksFunctions#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#function_id DataDatabricksFunctions#function_id}
    */
    readonly functionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#input_params DataDatabricksFunctions#input_params}
    */
    readonly inputParams?: DataDatabricksFunctionsFunctionsInputParams;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#is_deterministic DataDatabricksFunctions#is_deterministic}
    */
    readonly isDeterministic?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#is_null_call DataDatabricksFunctions#is_null_call}
    */
    readonly isNullCall?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#metastore_id DataDatabricksFunctions#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#name DataDatabricksFunctions#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#owner DataDatabricksFunctions#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#parameter_style DataDatabricksFunctions#parameter_style}
    */
    readonly parameterStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#properties DataDatabricksFunctions#properties}
    */
    readonly properties?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#return_params DataDatabricksFunctions#return_params}
    */
    readonly returnParams?: DataDatabricksFunctionsFunctionsReturnParams;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#routine_body DataDatabricksFunctions#routine_body}
    */
    readonly routineBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#routine_definition DataDatabricksFunctions#routine_definition}
    */
    readonly routineDefinition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#routine_dependencies DataDatabricksFunctions#routine_dependencies}
    */
    readonly routineDependencies?: DataDatabricksFunctionsFunctionsRoutineDependencies;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#schema_name DataDatabricksFunctions#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#security_type DataDatabricksFunctions#security_type}
    */
    readonly securityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#specific_name DataDatabricksFunctions#specific_name}
    */
    readonly specificName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#sql_data_access DataDatabricksFunctions#sql_data_access}
    */
    readonly sqlDataAccess?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#sql_path DataDatabricksFunctions#sql_path}
    */
    readonly sqlPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#updated_at DataDatabricksFunctions#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#updated_by DataDatabricksFunctions#updated_by}
    */
    readonly updatedBy?: string;
}
export declare function dataDatabricksFunctionsFunctionsToTerraform(struct?: DataDatabricksFunctionsFunctions | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsFunctionsToHclTerraform(struct?: DataDatabricksFunctionsFunctions | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsFunctionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFunctionsFunctions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsFunctions | cdktn.IResolvable | undefined);
    private _browseOnly?;
    get browseOnly(): boolean | cdktn.IResolvable;
    set browseOnly(value: boolean | cdktn.IResolvable);
    resetBrowseOnly(): void;
    get browseOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    resetDataType(): void;
    get dataTypeInput(): string | undefined;
    private _externalLanguage?;
    get externalLanguage(): string;
    set externalLanguage(value: string);
    resetExternalLanguage(): void;
    get externalLanguageInput(): string | undefined;
    private _externalName?;
    get externalName(): string;
    set externalName(value: string);
    resetExternalName(): void;
    get externalNameInput(): string | undefined;
    private _fullDataType?;
    get fullDataType(): string;
    set fullDataType(value: string);
    resetFullDataType(): void;
    get fullDataTypeInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _functionId?;
    get functionId(): string;
    set functionId(value: string);
    resetFunctionId(): void;
    get functionIdInput(): string | undefined;
    private _inputParams;
    get inputParams(): DataDatabricksFunctionsFunctionsInputParamsOutputReference;
    putInputParams(value: DataDatabricksFunctionsFunctionsInputParams): void;
    resetInputParams(): void;
    get inputParamsInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsInputParams | undefined;
    private _isDeterministic?;
    get isDeterministic(): boolean | cdktn.IResolvable;
    set isDeterministic(value: boolean | cdktn.IResolvable);
    resetIsDeterministic(): void;
    get isDeterministicInput(): boolean | cdktn.IResolvable | undefined;
    private _isNullCall?;
    get isNullCall(): boolean | cdktn.IResolvable;
    set isNullCall(value: boolean | cdktn.IResolvable);
    resetIsNullCall(): void;
    get isNullCallInput(): boolean | cdktn.IResolvable | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _parameterStyle?;
    get parameterStyle(): string;
    set parameterStyle(value: string);
    resetParameterStyle(): void;
    get parameterStyleInput(): string | undefined;
    private _properties?;
    get properties(): string;
    set properties(value: string);
    resetProperties(): void;
    get propertiesInput(): string | undefined;
    private _returnParams;
    get returnParams(): DataDatabricksFunctionsFunctionsReturnParamsOutputReference;
    putReturnParams(value: DataDatabricksFunctionsFunctionsReturnParams): void;
    resetReturnParams(): void;
    get returnParamsInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsReturnParams | undefined;
    private _routineBody?;
    get routineBody(): string;
    set routineBody(value: string);
    resetRoutineBody(): void;
    get routineBodyInput(): string | undefined;
    private _routineDefinition?;
    get routineDefinition(): string;
    set routineDefinition(value: string);
    resetRoutineDefinition(): void;
    get routineDefinitionInput(): string | undefined;
    private _routineDependencies;
    get routineDependencies(): DataDatabricksFunctionsFunctionsRoutineDependenciesOutputReference;
    putRoutineDependencies(value: DataDatabricksFunctionsFunctionsRoutineDependencies): void;
    resetRoutineDependencies(): void;
    get routineDependenciesInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctionsRoutineDependencies | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _securityType?;
    get securityType(): string;
    set securityType(value: string);
    resetSecurityType(): void;
    get securityTypeInput(): string | undefined;
    private _specificName?;
    get specificName(): string;
    set specificName(value: string);
    resetSpecificName(): void;
    get specificNameInput(): string | undefined;
    private _sqlDataAccess?;
    get sqlDataAccess(): string;
    set sqlDataAccess(value: string);
    resetSqlDataAccess(): void;
    get sqlDataAccessInput(): string | undefined;
    private _sqlPath?;
    get sqlPath(): string;
    set sqlPath(value: string);
    resetSqlPath(): void;
    get sqlPathInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
}
export declare class DataDatabricksFunctionsFunctionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFunctionsFunctions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFunctionsFunctionsOutputReference;
}
export interface DataDatabricksFunctionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#workspace_id DataDatabricksFunctions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksFunctionsProviderConfigToTerraform(struct?: DataDatabricksFunctionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFunctionsProviderConfigToHclTerraform(struct?: DataDatabricksFunctionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFunctionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFunctionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFunctionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions databricks_functions}
*/
export declare class DataDatabricksFunctions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_functions";
    /**
    * Generates CDKTN code for importing a DataDatabricksFunctions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksFunctions to import
    * @param importFromId The id of the existing DataDatabricksFunctions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksFunctions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/functions databricks_functions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksFunctionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksFunctionsConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _functions;
    get functions(): DataDatabricksFunctionsFunctionsList;
    putFunctions(value: DataDatabricksFunctionsFunctions[] | cdktn.IResolvable): void;
    resetFunctions(): void;
    get functionsInput(): cdktn.IResolvable | DataDatabricksFunctionsFunctions[] | undefined;
    private _includeBrowse?;
    get includeBrowse(): boolean | cdktn.IResolvable;
    set includeBrowse(value: boolean | cdktn.IResolvable);
    resetIncludeBrowse(): void;
    get includeBrowseInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksFunctionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFunctionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFunctionsProviderConfig | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
