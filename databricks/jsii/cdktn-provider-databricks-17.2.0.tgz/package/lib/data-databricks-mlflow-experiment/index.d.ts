/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMlflowExperimentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#artifact_location DataDatabricksMlflowExperiment#artifact_location}
    */
    readonly artifactLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#creation_time DataDatabricksMlflowExperiment#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#experiment_id DataDatabricksMlflowExperiment#experiment_id}
    */
    readonly experimentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#id DataDatabricksMlflowExperiment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#last_update_time DataDatabricksMlflowExperiment#last_update_time}
    */
    readonly lastUpdateTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#lifecycle_stage DataDatabricksMlflowExperiment#lifecycle_stage}
    */
    readonly lifecycleStage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#name DataDatabricksMlflowExperiment#name}
    */
    readonly name?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#provider_config DataDatabricksMlflowExperiment#provider_config}
    */
    readonly providerConfig?: DataDatabricksMlflowExperimentProviderConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#tags DataDatabricksMlflowExperiment#tags}
    */
    readonly tags?: DataDatabricksMlflowExperimentTags[] | cdktn.IResolvable;
}
export interface DataDatabricksMlflowExperimentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#workspace_id DataDatabricksMlflowExperiment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMlflowExperimentProviderConfigToTerraform(struct?: DataDatabricksMlflowExperimentProviderConfigOutputReference | DataDatabricksMlflowExperimentProviderConfig): any;
export declare function dataDatabricksMlflowExperimentProviderConfigToHclTerraform(struct?: DataDatabricksMlflowExperimentProviderConfigOutputReference | DataDatabricksMlflowExperimentProviderConfig): any;
export declare class DataDatabricksMlflowExperimentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMlflowExperimentProviderConfig | undefined;
    set internalValue(value: DataDatabricksMlflowExperimentProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksMlflowExperimentTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#key DataDatabricksMlflowExperiment#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#value DataDatabricksMlflowExperiment#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksMlflowExperimentTagsToTerraform(struct?: DataDatabricksMlflowExperimentTags | cdktn.IResolvable): any;
export declare function dataDatabricksMlflowExperimentTagsToHclTerraform(struct?: DataDatabricksMlflowExperimentTags | cdktn.IResolvable): any;
export declare class DataDatabricksMlflowExperimentTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksMlflowExperimentTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksMlflowExperimentTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksMlflowExperimentTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksMlflowExperimentTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksMlflowExperimentTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment databricks_mlflow_experiment}
*/
export declare class DataDatabricksMlflowExperiment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mlflow_experiment";
    /**
    * Generates CDKTN code for importing a DataDatabricksMlflowExperiment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMlflowExperiment to import
    * @param importFromId The id of the existing DataDatabricksMlflowExperiment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMlflowExperiment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.116.0/docs/data-sources/mlflow_experiment databricks_mlflow_experiment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMlflowExperimentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksMlflowExperimentConfig);
    private _artifactLocation?;
    get artifactLocation(): string;
    set artifactLocation(value: string);
    resetArtifactLocation(): void;
    get artifactLocationInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    resetExperimentId(): void;
    get experimentIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastUpdateTime?;
    get lastUpdateTime(): number;
    set lastUpdateTime(value: number);
    resetLastUpdateTime(): void;
    get lastUpdateTimeInput(): number | undefined;
    private _lifecycleStage?;
    get lifecycleStage(): string;
    set lifecycleStage(value: string);
    resetLifecycleStage(): void;
    get lifecycleStageInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMlflowExperimentProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMlflowExperimentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksMlflowExperimentProviderConfig | undefined;
    private _tags;
    get tags(): DataDatabricksMlflowExperimentTagsList;
    putTags(value: DataDatabricksMlflowExperimentTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | DataDatabricksMlflowExperimentTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
