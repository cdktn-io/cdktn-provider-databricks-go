/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiSearchIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#delta_sync_index_spec AiSearchIndex#delta_sync_index_spec}
    */
    readonly deltaSyncIndexSpec?: AiSearchIndexDeltaSyncIndexSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#direct_access_index_spec AiSearchIndex#direct_access_index_spec}
    */
    readonly directAccessIndexSpec?: AiSearchIndexDirectAccessIndexSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#index_id AiSearchIndex#index_id}
    */
    readonly indexId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#index_subtype AiSearchIndex#index_subtype}
    */
    readonly indexSubtype?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#index_type AiSearchIndex#index_type}
    */
    readonly indexType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#parent AiSearchIndex#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#primary_key AiSearchIndex#primary_key}
    */
    readonly primaryKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#provider_config AiSearchIndex#provider_config}
    */
    readonly providerConfig?: AiSearchIndexProviderConfig;
}
export interface AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_model_endpoint AiSearchIndex#embedding_model_endpoint}
    */
    readonly embeddingModelEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#model_endpoint_name_for_query AiSearchIndex#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#name AiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function aiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsToTerraform(struct?: AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function aiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpoint?;
    get embeddingModelEndpoint(): string;
    set embeddingModelEndpoint(value: string);
    resetEmbeddingModelEndpoint(): void;
    get embeddingModelEndpointInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_dimension AiSearchIndex#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#name AiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function aiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsToTerraform(struct?: AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function aiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface AiSearchIndexDeltaSyncIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#columns_to_sync AiSearchIndex#columns_to_sync}
    */
    readonly columnsToSync?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_source_columns AiSearchIndex#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_vector_columns AiSearchIndex#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_writeback_table AiSearchIndex#embedding_writeback_table}
    */
    readonly embeddingWritebackTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#pipeline_type AiSearchIndex#pipeline_type}
    */
    readonly pipelineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#source_table AiSearchIndex#source_table}
    */
    readonly sourceTable?: string;
}
export declare function aiSearchIndexDeltaSyncIndexSpecToTerraform(struct?: AiSearchIndexDeltaSyncIndexSpec | cdktn.IResolvable): any;
export declare function aiSearchIndexDeltaSyncIndexSpecToHclTerraform(struct?: AiSearchIndexDeltaSyncIndexSpec | cdktn.IResolvable): any;
export declare class AiSearchIndexDeltaSyncIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchIndexDeltaSyncIndexSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchIndexDeltaSyncIndexSpec | cdktn.IResolvable | undefined);
    private _columnsToSync?;
    get columnsToSync(): string[];
    set columnsToSync(value: string[]);
    resetColumnsToSync(): void;
    get columnsToSyncInput(): string[] | undefined;
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | AiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | AiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | undefined;
    private _embeddingWritebackTable?;
    get embeddingWritebackTable(): string;
    set embeddingWritebackTable(value: string);
    resetEmbeddingWritebackTable(): void;
    get embeddingWritebackTableInput(): string | undefined;
    get pipelineId(): string;
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    get pipelineTypeInput(): string | undefined;
    private _sourceTable?;
    get sourceTable(): string;
    set sourceTable(value: string);
    resetSourceTable(): void;
    get sourceTableInput(): string | undefined;
}
export interface AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_model_endpoint AiSearchIndex#embedding_model_endpoint}
    */
    readonly embeddingModelEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#model_endpoint_name_for_query AiSearchIndex#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#name AiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function aiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsToTerraform(struct?: AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function aiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpoint?;
    get embeddingModelEndpoint(): string;
    set embeddingModelEndpoint(value: string);
    resetEmbeddingModelEndpoint(): void;
    get embeddingModelEndpointInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_dimension AiSearchIndex#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#name AiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function aiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsToTerraform(struct?: AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function aiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface AiSearchIndexDirectAccessIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_source_columns AiSearchIndex#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#embedding_vector_columns AiSearchIndex#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#schema_json AiSearchIndex#schema_json}
    */
    readonly schemaJson?: string;
}
export declare function aiSearchIndexDirectAccessIndexSpecToTerraform(struct?: AiSearchIndexDirectAccessIndexSpec | cdktn.IResolvable): any;
export declare function aiSearchIndexDirectAccessIndexSpecToHclTerraform(struct?: AiSearchIndexDirectAccessIndexSpec | cdktn.IResolvable): any;
export declare class AiSearchIndexDirectAccessIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchIndexDirectAccessIndexSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchIndexDirectAccessIndexSpec | cdktn.IResolvable | undefined);
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | AiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | AiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | undefined;
    private _schemaJson?;
    get schemaJson(): string;
    set schemaJson(value: string);
    resetSchemaJson(): void;
    get schemaJsonInput(): string | undefined;
}
export interface AiSearchIndexProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#workspace_id AiSearchIndex#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function aiSearchIndexProviderConfigToTerraform(struct?: AiSearchIndexProviderConfig | cdktn.IResolvable): any;
export declare function aiSearchIndexProviderConfigToHclTerraform(struct?: AiSearchIndexProviderConfig | cdktn.IResolvable): any;
export declare class AiSearchIndexProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchIndexProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiSearchIndexProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface AiSearchIndexStatus {
}
export declare function aiSearchIndexStatusToTerraform(struct?: AiSearchIndexStatus): any;
export declare function aiSearchIndexStatusToHclTerraform(struct?: AiSearchIndexStatus): any;
export declare class AiSearchIndexStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiSearchIndexStatus | undefined;
    set internalValue(value: AiSearchIndexStatus | undefined);
    get indexUrl(): string;
    get indexedRowCount(): number;
    get message(): string;
    get ready(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index databricks_ai_search_index}
*/
export declare class AiSearchIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_ai_search_index";
    /**
    * Generates CDKTN code for importing a AiSearchIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiSearchIndex to import
    * @param importFromId The id of the existing AiSearchIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiSearchIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/ai_search_index databricks_ai_search_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiSearchIndexConfig
    */
    constructor(scope: Construct, id: string, config: AiSearchIndexConfig);
    get creator(): string;
    private _deltaSyncIndexSpec;
    get deltaSyncIndexSpec(): AiSearchIndexDeltaSyncIndexSpecOutputReference;
    putDeltaSyncIndexSpec(value: AiSearchIndexDeltaSyncIndexSpec): void;
    resetDeltaSyncIndexSpec(): void;
    get deltaSyncIndexSpecInput(): cdktn.IResolvable | AiSearchIndexDeltaSyncIndexSpec | undefined;
    private _directAccessIndexSpec;
    get directAccessIndexSpec(): AiSearchIndexDirectAccessIndexSpecOutputReference;
    putDirectAccessIndexSpec(value: AiSearchIndexDirectAccessIndexSpec): void;
    resetDirectAccessIndexSpec(): void;
    get directAccessIndexSpecInput(): cdktn.IResolvable | AiSearchIndexDirectAccessIndexSpec | undefined;
    get endpoint(): string;
    private _indexId?;
    get indexId(): string;
    set indexId(value: string);
    resetIndexId(): void;
    get indexIdInput(): string | undefined;
    private _indexSubtype?;
    get indexSubtype(): string;
    set indexSubtype(value: string);
    resetIndexSubtype(): void;
    get indexSubtypeInput(): string | undefined;
    private _indexType?;
    get indexType(): string;
    set indexType(value: string);
    get indexTypeInput(): string | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _primaryKey?;
    get primaryKey(): string;
    set primaryKey(value: string);
    get primaryKeyInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AiSearchIndexProviderConfigOutputReference;
    putProviderConfig(value: AiSearchIndexProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AiSearchIndexProviderConfig | undefined;
    private _status;
    get status(): AiSearchIndexStatusOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
