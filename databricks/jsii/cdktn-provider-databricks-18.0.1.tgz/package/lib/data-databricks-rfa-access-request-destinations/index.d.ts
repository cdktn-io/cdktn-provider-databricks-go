/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksRfaAccessRequestDestinationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#full_name DataDatabricksRfaAccessRequestDestinations#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#provider_config DataDatabricksRfaAccessRequestDestinations#provider_config}
    */
    readonly providerConfig?: DataDatabricksRfaAccessRequestDestinationsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#securable_type DataDatabricksRfaAccessRequestDestinations#securable_type}
    */
    readonly securableType: string;
}
export interface DataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#full_name DataDatabricksRfaAccessRequestDestinations#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#provider_share DataDatabricksRfaAccessRequestDestinations#provider_share}
    */
    readonly providerShare?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#type DataDatabricksRfaAccessRequestDestinations#type}
    */
    readonly type?: string;
}
export declare function dataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurableToTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurable): any;
export declare function dataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurableToHclTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurable): any;
export declare class DataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurable | undefined;
    set internalValue(value: DataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurable | undefined);
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _providerShare?;
    get providerShare(): string;
    set providerShare(value: string);
    resetProviderShare(): void;
    get providerShareInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DataDatabricksRfaAccessRequestDestinationsDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#destination_id DataDatabricksRfaAccessRequestDestinations#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#destination_type DataDatabricksRfaAccessRequestDestinations#destination_type}
    */
    readonly destinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#special_destination DataDatabricksRfaAccessRequestDestinations#special_destination}
    */
    readonly specialDestination?: string;
}
export declare function dataDatabricksRfaAccessRequestDestinationsDestinationsToTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsDestinations): any;
export declare function dataDatabricksRfaAccessRequestDestinationsDestinationsToHclTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsDestinations): any;
export declare class DataDatabricksRfaAccessRequestDestinationsDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRfaAccessRequestDestinationsDestinations | undefined;
    set internalValue(value: DataDatabricksRfaAccessRequestDestinationsDestinations | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    resetDestinationType(): void;
    get destinationTypeInput(): string | undefined;
    private _specialDestination?;
    get specialDestination(): string;
    set specialDestination(value: string);
    resetSpecialDestination(): void;
    get specialDestinationInput(): string | undefined;
}
export declare class DataDatabricksRfaAccessRequestDestinationsDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRfaAccessRequestDestinationsDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRfaAccessRequestDestinationsDestinationsOutputReference;
}
export interface DataDatabricksRfaAccessRequestDestinationsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#workspace_id DataDatabricksRfaAccessRequestDestinations#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksRfaAccessRequestDestinationsProviderConfigToTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksRfaAccessRequestDestinationsProviderConfigToHclTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksRfaAccessRequestDestinationsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksRfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRfaAccessRequestDestinationsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksRfaAccessRequestDestinationsSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#full_name DataDatabricksRfaAccessRequestDestinations#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#provider_share DataDatabricksRfaAccessRequestDestinations#provider_share}
    */
    readonly providerShare?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#type DataDatabricksRfaAccessRequestDestinations#type}
    */
    readonly type?: string;
}
export declare function dataDatabricksRfaAccessRequestDestinationsSecurableToTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsSecurable): any;
export declare function dataDatabricksRfaAccessRequestDestinationsSecurableToHclTerraform(struct?: DataDatabricksRfaAccessRequestDestinationsSecurable): any;
export declare class DataDatabricksRfaAccessRequestDestinationsSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksRfaAccessRequestDestinationsSecurable | undefined;
    set internalValue(value: DataDatabricksRfaAccessRequestDestinationsSecurable | undefined);
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _providerShare?;
    get providerShare(): string;
    set providerShare(value: string);
    resetProviderShare(): void;
    get providerShareInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations databricks_rfa_access_request_destinations}
*/
export declare class DataDatabricksRfaAccessRequestDestinations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_rfa_access_request_destinations";
    /**
    * Generates CDKTN code for importing a DataDatabricksRfaAccessRequestDestinations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksRfaAccessRequestDestinations to import
    * @param importFromId The id of the existing DataDatabricksRfaAccessRequestDestinations that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksRfaAccessRequestDestinations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/rfa_access_request_destinations databricks_rfa_access_request_destinations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksRfaAccessRequestDestinationsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksRfaAccessRequestDestinationsConfig);
    get areAnyDestinationsHidden(): cdktn.IResolvable;
    private _destinationSourceSecurable;
    get destinationSourceSecurable(): DataDatabricksRfaAccessRequestDestinationsDestinationSourceSecurableOutputReference;
    private _destinations;
    get destinations(): DataDatabricksRfaAccessRequestDestinationsDestinationsList;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksRfaAccessRequestDestinationsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksRfaAccessRequestDestinationsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksRfaAccessRequestDestinationsProviderConfig | undefined;
    private _securable;
    get securable(): DataDatabricksRfaAccessRequestDestinationsSecurableOutputReference;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
