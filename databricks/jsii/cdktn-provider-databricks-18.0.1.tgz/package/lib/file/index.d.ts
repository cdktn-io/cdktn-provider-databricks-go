/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#content_base64 File#content_base64}
    */
    readonly contentBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#id File#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#md5 File#md5}
    */
    readonly md5?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#path File#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#remote_file_modified File#remote_file_modified}
    */
    readonly remoteFileModified?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#source File#source}
    */
    readonly source?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#provider_config File#provider_config}
    */
    readonly providerConfig?: FileProviderConfig;
}
export interface FileProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#workspace_id File#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function fileProviderConfigToTerraform(struct?: FileProviderConfigOutputReference | FileProviderConfig): any;
export declare function fileProviderConfigToHclTerraform(struct?: FileProviderConfigOutputReference | FileProviderConfig): any;
export declare class FileProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FileProviderConfig | undefined;
    set internalValue(value: FileProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file databricks_file}
*/
export declare class File extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_file";
    /**
    * Generates CDKTN code for importing a File resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the File to import
    * @param importFromId The id of the existing File that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the File to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/file databricks_file} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FileConfig
    */
    constructor(scope: Construct, id: string, config: FileConfig);
    private _contentBase64?;
    get contentBase64(): string;
    set contentBase64(value: string);
    resetContentBase64(): void;
    get contentBase64Input(): string | undefined;
    get fileSize(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _md5?;
    get md5(): string;
    set md5(value: string);
    resetMd5(): void;
    get md5Input(): string | undefined;
    get modificationTime(): string;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _remoteFileModified?;
    get remoteFileModified(): boolean | cdktn.IResolvable;
    set remoteFileModified(value: boolean | cdktn.IResolvable);
    resetRemoteFileModified(): void;
    get remoteFileModifiedInput(): boolean | cdktn.IResolvable | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): FileProviderConfigOutputReference;
    putProviderConfig(value: FileProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): FileProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
