/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppSpacesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#page_size DataDatabricksAppSpaces#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#provider_config DataDatabricksAppSpaces#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppSpacesProviderConfig;
}
export interface DataDatabricksAppSpacesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#workspace_id DataDatabricksAppSpaces#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAppSpacesProviderConfigToTerraform(struct?: DataDatabricksAppSpacesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesProviderConfigToHclTerraform(struct?: DataDatabricksAppSpacesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#workspace_id DataDatabricksAppSpaces#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAppSpacesSpacesProviderConfigToTerraform(struct?: DataDatabricksAppSpacesSpacesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesProviderConfigToHclTerraform(struct?: DataDatabricksAppSpacesSpacesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#name DataDatabricksAppSpaces#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission?: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesAppToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesApp | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesAppToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesApp | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesApp | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#database_name DataDatabricksAppSpaces#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#instance_name DataDatabricksAppSpaces#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesDatabaseToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesDatabase | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesDatabaseToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesDatabase | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#experiment_id DataDatabricksAppSpaces#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesExperimentToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesExperiment | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesExperimentToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesExperiment | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#name DataDatabricksAppSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#space_id DataDatabricksAppSpaces#space_id}
    */
    readonly spaceId: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesGenieSpaceToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesGenieSpace | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesGenieSpaceToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesGenieSpace | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#id DataDatabricksAppSpaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesJobToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesJob | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesJobToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesJob | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesPostgres {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#branch DataDatabricksAppSpaces#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#database DataDatabricksAppSpaces#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission?: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesPostgresToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesPostgres | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesPostgresToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesPostgres | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesPostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesPostgres | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesPostgres | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#key DataDatabricksAppSpaces#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#scope DataDatabricksAppSpaces#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesSecretToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesSecretToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#name DataDatabricksAppSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesServingEndpointToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesServingEndpointToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#id DataDatabricksAppSpaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesSqlWarehouseToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesSqlWarehouseToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#permission DataDatabricksAppSpaces#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#securable_full_name DataDatabricksAppSpaces#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#securable_type DataDatabricksAppSpaces#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppSpacesSpacesResourcesUcSecurableToTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesUcSecurable | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpacesSpacesResourcesUcSecurableToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResourcesUcSecurable | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpacesSpacesResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppSpacesSpacesResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#app DataDatabricksAppSpaces#app}
    */
    readonly app?: DataDatabricksAppSpacesSpacesResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#database DataDatabricksAppSpaces#database}
    */
    readonly database?: DataDatabricksAppSpacesSpacesResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#description DataDatabricksAppSpaces#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#experiment DataDatabricksAppSpaces#experiment}
    */
    readonly experiment?: DataDatabricksAppSpacesSpacesResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#genie_space DataDatabricksAppSpaces#genie_space}
    */
    readonly genieSpace?: DataDatabricksAppSpacesSpacesResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#job DataDatabricksAppSpaces#job}
    */
    readonly job?: DataDatabricksAppSpacesSpacesResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#name DataDatabricksAppSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#postgres DataDatabricksAppSpaces#postgres}
    */
    readonly postgres?: DataDatabricksAppSpacesSpacesResourcesPostgres;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#secret DataDatabricksAppSpaces#secret}
    */
    readonly secret?: DataDatabricksAppSpacesSpacesResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#serving_endpoint DataDatabricksAppSpaces#serving_endpoint}
    */
    readonly servingEndpoint?: DataDatabricksAppSpacesSpacesResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#sql_warehouse DataDatabricksAppSpaces#sql_warehouse}
    */
    readonly sqlWarehouse?: DataDatabricksAppSpacesSpacesResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#uc_securable DataDatabricksAppSpaces#uc_securable}
    */
    readonly ucSecurable?: DataDatabricksAppSpacesSpacesResourcesUcSecurable;
}
export declare function dataDatabricksAppSpacesSpacesResourcesToTerraform(struct?: DataDatabricksAppSpacesSpacesResources): any;
export declare function dataDatabricksAppSpacesSpacesResourcesToHclTerraform(struct?: DataDatabricksAppSpacesSpacesResources): any;
export declare class DataDatabricksAppSpacesSpacesResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppSpacesSpacesResources | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesResources | undefined);
    private _app;
    get app(): DataDatabricksAppSpacesSpacesResourcesAppOutputReference;
    putApp(value: DataDatabricksAppSpacesSpacesResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesApp | undefined;
    private _database;
    get database(): DataDatabricksAppSpacesSpacesResourcesDatabaseOutputReference;
    putDatabase(value: DataDatabricksAppSpacesSpacesResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): DataDatabricksAppSpacesSpacesResourcesExperimentOutputReference;
    putExperiment(value: DataDatabricksAppSpacesSpacesResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): DataDatabricksAppSpacesSpacesResourcesGenieSpaceOutputReference;
    putGenieSpace(value: DataDatabricksAppSpacesSpacesResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesGenieSpace | undefined;
    private _job;
    get job(): DataDatabricksAppSpacesSpacesResourcesJobOutputReference;
    putJob(value: DataDatabricksAppSpacesSpacesResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _postgres;
    get postgres(): DataDatabricksAppSpacesSpacesResourcesPostgresOutputReference;
    putPostgres(value: DataDatabricksAppSpacesSpacesResourcesPostgres): void;
    resetPostgres(): void;
    get postgresInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesPostgres | undefined;
    private _secret;
    get secret(): DataDatabricksAppSpacesSpacesResourcesSecretOutputReference;
    putSecret(value: DataDatabricksAppSpacesSpacesResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): DataDatabricksAppSpacesSpacesResourcesServingEndpointOutputReference;
    putServingEndpoint(value: DataDatabricksAppSpacesSpacesResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): DataDatabricksAppSpacesSpacesResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: DataDatabricksAppSpacesSpacesResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): DataDatabricksAppSpacesSpacesResourcesUcSecurableOutputReference;
    putUcSecurable(value: DataDatabricksAppSpacesSpacesResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesResourcesUcSecurable | undefined;
}
export declare class DataDatabricksAppSpacesSpacesResourcesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppSpacesSpacesResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppSpacesSpacesResourcesOutputReference;
}
export interface DataDatabricksAppSpacesSpacesStatus {
}
export declare function dataDatabricksAppSpacesSpacesStatusToTerraform(struct?: DataDatabricksAppSpacesSpacesStatus): any;
export declare function dataDatabricksAppSpacesSpacesStatusToHclTerraform(struct?: DataDatabricksAppSpacesSpacesStatus): any;
export declare class DataDatabricksAppSpacesSpacesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpacesSpacesStatus | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpacesStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppSpacesSpaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#name DataDatabricksAppSpaces#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#provider_config DataDatabricksAppSpaces#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppSpacesSpacesProviderConfig;
}
export declare function dataDatabricksAppSpacesSpacesToTerraform(struct?: DataDatabricksAppSpacesSpaces): any;
export declare function dataDatabricksAppSpacesSpacesToHclTerraform(struct?: DataDatabricksAppSpacesSpaces): any;
export declare class DataDatabricksAppSpacesSpacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppSpacesSpaces | undefined;
    set internalValue(value: DataDatabricksAppSpacesSpaces | undefined);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppSpacesSpacesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppSpacesSpacesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppSpacesSpacesProviderConfig | undefined;
    private _resources;
    get resources(): DataDatabricksAppSpacesSpacesResourcesList;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _status;
    get status(): DataDatabricksAppSpacesSpacesStatusOutputReference;
    get updateTime(): string;
    get updater(): string;
    get usagePolicyId(): string;
    get userApiScopes(): string[];
}
export declare class DataDatabricksAppSpacesSpacesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppSpacesSpaces[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppSpacesSpacesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces databricks_app_spaces}
*/
export declare class DataDatabricksAppSpaces extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_app_spaces";
    /**
    * Generates CDKTN code for importing a DataDatabricksAppSpaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAppSpaces to import
    * @param importFromId The id of the existing DataDatabricksAppSpaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAppSpaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/app_spaces databricks_app_spaces} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppSpacesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAppSpacesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppSpacesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppSpacesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppSpacesProviderConfig | undefined;
    private _spaces;
    get spaces(): DataDatabricksAppSpacesSpacesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
