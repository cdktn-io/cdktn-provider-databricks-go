/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDbfsFilePathsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths#id DataDatabricksDbfsFilePaths#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths#path DataDatabricksDbfsFilePaths#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths#recursive DataDatabricksDbfsFilePaths#recursive}
    */
    readonly recursive: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths#provider_config DataDatabricksDbfsFilePaths#provider_config}
    */
    readonly providerConfig?: DataDatabricksDbfsFilePathsProviderConfig;
}
export interface DataDatabricksDbfsFilePathsPathListStruct {
}
export declare function dataDatabricksDbfsFilePathsPathListStructToTerraform(struct?: DataDatabricksDbfsFilePathsPathListStruct): any;
export declare function dataDatabricksDbfsFilePathsPathListStructToHclTerraform(struct?: DataDatabricksDbfsFilePathsPathListStruct): any;
export declare class DataDatabricksDbfsFilePathsPathListStructOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDbfsFilePathsPathListStruct | undefined;
    set internalValue(value: DataDatabricksDbfsFilePathsPathListStruct | undefined);
    get fileSize(): number;
    get path(): string;
}
export declare class DataDatabricksDbfsFilePathsPathListStructList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDbfsFilePathsPathListStructOutputReference;
}
export interface DataDatabricksDbfsFilePathsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths#workspace_id DataDatabricksDbfsFilePaths#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDbfsFilePathsProviderConfigToTerraform(struct?: DataDatabricksDbfsFilePathsProviderConfigOutputReference | DataDatabricksDbfsFilePathsProviderConfig): any;
export declare function dataDatabricksDbfsFilePathsProviderConfigToHclTerraform(struct?: DataDatabricksDbfsFilePathsProviderConfigOutputReference | DataDatabricksDbfsFilePathsProviderConfig): any;
export declare class DataDatabricksDbfsFilePathsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDbfsFilePathsProviderConfig | undefined;
    set internalValue(value: DataDatabricksDbfsFilePathsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths databricks_dbfs_file_paths}
*/
export declare class DataDatabricksDbfsFilePaths extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_dbfs_file_paths";
    /**
    * Generates CDKTN code for importing a DataDatabricksDbfsFilePaths resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDbfsFilePaths to import
    * @param importFromId The id of the existing DataDatabricksDbfsFilePaths that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDbfsFilePaths to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/dbfs_file_paths databricks_dbfs_file_paths} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDbfsFilePathsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDbfsFilePathsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _pathList;
    get pathList(): DataDatabricksDbfsFilePathsPathListStructList;
    private _recursive?;
    get recursive(): boolean | cdktn.IResolvable;
    set recursive(value: boolean | cdktn.IResolvable);
    get recursiveInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDbfsFilePathsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDbfsFilePathsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksDbfsFilePathsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
