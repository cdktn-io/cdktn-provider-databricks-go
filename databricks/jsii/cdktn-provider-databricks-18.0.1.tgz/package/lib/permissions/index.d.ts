/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#alert_v2_id Permissions#alert_v2_id}
    */
    readonly alertV2Id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#app_name Permissions#app_name}
    */
    readonly appName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#authorization Permissions#authorization}
    */
    readonly authorization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#cluster_id Permissions#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#cluster_policy_id Permissions#cluster_policy_id}
    */
    readonly clusterPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#dashboard_id Permissions#dashboard_id}
    */
    readonly dashboardId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#database_instance_name Permissions#database_instance_name}
    */
    readonly databaseInstanceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#database_project_name Permissions#database_project_name}
    */
    readonly databaseProjectName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#directory_id Permissions#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#directory_path Permissions#directory_path}
    */
    readonly directoryPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#experiment_id Permissions#experiment_id}
    */
    readonly experimentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#id Permissions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#instance_pool_id Permissions#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#job_id Permissions#job_id}
    */
    readonly jobId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#knowledge_assistant_id Permissions#knowledge_assistant_id}
    */
    readonly knowledgeAssistantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#notebook_id Permissions#notebook_id}
    */
    readonly notebookId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#notebook_path Permissions#notebook_path}
    */
    readonly notebookPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#object_type Permissions#object_type}
    */
    readonly objectType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#pipeline_id Permissions#pipeline_id}
    */
    readonly pipelineId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#registered_model_id Permissions#registered_model_id}
    */
    readonly registeredModelId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#repo_id Permissions#repo_id}
    */
    readonly repoId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#repo_path Permissions#repo_path}
    */
    readonly repoPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#serving_endpoint_id Permissions#serving_endpoint_id}
    */
    readonly servingEndpointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#sql_alert_id Permissions#sql_alert_id}
    */
    readonly sqlAlertId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#sql_dashboard_id Permissions#sql_dashboard_id}
    */
    readonly sqlDashboardId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#sql_endpoint_id Permissions#sql_endpoint_id}
    */
    readonly sqlEndpointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#sql_query_id Permissions#sql_query_id}
    */
    readonly sqlQueryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#supervisor_agent_id Permissions#supervisor_agent_id}
    */
    readonly supervisorAgentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#vector_search_endpoint_id Permissions#vector_search_endpoint_id}
    */
    readonly vectorSearchEndpointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#workspace_file_id Permissions#workspace_file_id}
    */
    readonly workspaceFileId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#workspace_file_path Permissions#workspace_file_path}
    */
    readonly workspaceFilePath?: string;
    /**
    * access_control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#access_control Permissions#access_control}
    */
    readonly accessControl: PermissionsAccessControl[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#provider_config Permissions#provider_config}
    */
    readonly providerConfig?: PermissionsProviderConfig;
}
export interface PermissionsAccessControl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#group_name Permissions#group_name}
    */
    readonly groupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#permission_level Permissions#permission_level}
    */
    readonly permissionLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#service_principal_name Permissions#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#user_name Permissions#user_name}
    */
    readonly userName?: string;
}
export declare function permissionsAccessControlToTerraform(struct?: PermissionsAccessControl | cdktn.IResolvable): any;
export declare function permissionsAccessControlToHclTerraform(struct?: PermissionsAccessControl | cdktn.IResolvable): any;
export declare class PermissionsAccessControlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PermissionsAccessControl | cdktn.IResolvable | undefined;
    set internalValue(value: PermissionsAccessControl | cdktn.IResolvable | undefined);
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
    private _permissionLevel?;
    get permissionLevel(): string;
    set permissionLevel(value: string);
    resetPermissionLevel(): void;
    get permissionLevelInput(): string | undefined;
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class PermissionsAccessControlList extends cdktn.ComplexList {
    internalValue?: PermissionsAccessControl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PermissionsAccessControlOutputReference;
}
export interface PermissionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#workspace_id Permissions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function permissionsProviderConfigToTerraform(struct?: PermissionsProviderConfigOutputReference | PermissionsProviderConfig): any;
export declare function permissionsProviderConfigToHclTerraform(struct?: PermissionsProviderConfigOutputReference | PermissionsProviderConfig): any;
export declare class PermissionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PermissionsProviderConfig | undefined;
    set internalValue(value: PermissionsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions databricks_permissions}
*/
export declare class Permissions extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_permissions";
    /**
    * Generates CDKTN code for importing a Permissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Permissions to import
    * @param importFromId The id of the existing Permissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Permissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/permissions databricks_permissions} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PermissionsConfig
    */
    constructor(scope: Construct, id: string, config: PermissionsConfig);
    private _alertV2Id?;
    get alertV2Id(): string;
    set alertV2Id(value: string);
    resetAlertV2Id(): void;
    get alertV2IdInput(): string | undefined;
    private _appName?;
    get appName(): string;
    set appName(value: string);
    resetAppName(): void;
    get appNameInput(): string | undefined;
    private _authorization?;
    get authorization(): string;
    set authorization(value: string);
    resetAuthorization(): void;
    get authorizationInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterPolicyId?;
    get clusterPolicyId(): string;
    set clusterPolicyId(value: string);
    resetClusterPolicyId(): void;
    get clusterPolicyIdInput(): string | undefined;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    resetDashboardId(): void;
    get dashboardIdInput(): string | undefined;
    private _databaseInstanceName?;
    get databaseInstanceName(): string;
    set databaseInstanceName(value: string);
    resetDatabaseInstanceName(): void;
    get databaseInstanceNameInput(): string | undefined;
    private _databaseProjectName?;
    get databaseProjectName(): string;
    set databaseProjectName(value: string);
    resetDatabaseProjectName(): void;
    get databaseProjectNameInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    private _directoryPath?;
    get directoryPath(): string;
    set directoryPath(value: string);
    resetDirectoryPath(): void;
    get directoryPathInput(): string | undefined;
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    resetExperimentId(): void;
    get experimentIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _jobId?;
    get jobId(): string;
    set jobId(value: string);
    resetJobId(): void;
    get jobIdInput(): string | undefined;
    private _knowledgeAssistantId?;
    get knowledgeAssistantId(): string;
    set knowledgeAssistantId(value: string);
    resetKnowledgeAssistantId(): void;
    get knowledgeAssistantIdInput(): string | undefined;
    private _notebookId?;
    get notebookId(): string;
    set notebookId(value: string);
    resetNotebookId(): void;
    get notebookIdInput(): string | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    resetNotebookPath(): void;
    get notebookPathInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    resetObjectType(): void;
    get objectTypeInput(): string | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    resetPipelineId(): void;
    get pipelineIdInput(): string | undefined;
    private _registeredModelId?;
    get registeredModelId(): string;
    set registeredModelId(value: string);
    resetRegisteredModelId(): void;
    get registeredModelIdInput(): string | undefined;
    private _repoId?;
    get repoId(): string;
    set repoId(value: string);
    resetRepoId(): void;
    get repoIdInput(): string | undefined;
    private _repoPath?;
    get repoPath(): string;
    set repoPath(value: string);
    resetRepoPath(): void;
    get repoPathInput(): string | undefined;
    private _servingEndpointId?;
    get servingEndpointId(): string;
    set servingEndpointId(value: string);
    resetServingEndpointId(): void;
    get servingEndpointIdInput(): string | undefined;
    private _sqlAlertId?;
    get sqlAlertId(): string;
    set sqlAlertId(value: string);
    resetSqlAlertId(): void;
    get sqlAlertIdInput(): string | undefined;
    private _sqlDashboardId?;
    get sqlDashboardId(): string;
    set sqlDashboardId(value: string);
    resetSqlDashboardId(): void;
    get sqlDashboardIdInput(): string | undefined;
    private _sqlEndpointId?;
    get sqlEndpointId(): string;
    set sqlEndpointId(value: string);
    resetSqlEndpointId(): void;
    get sqlEndpointIdInput(): string | undefined;
    private _sqlQueryId?;
    get sqlQueryId(): string;
    set sqlQueryId(value: string);
    resetSqlQueryId(): void;
    get sqlQueryIdInput(): string | undefined;
    private _supervisorAgentId?;
    get supervisorAgentId(): string;
    set supervisorAgentId(value: string);
    resetSupervisorAgentId(): void;
    get supervisorAgentIdInput(): string | undefined;
    private _vectorSearchEndpointId?;
    get vectorSearchEndpointId(): string;
    set vectorSearchEndpointId(value: string);
    resetVectorSearchEndpointId(): void;
    get vectorSearchEndpointIdInput(): string | undefined;
    private _workspaceFileId?;
    get workspaceFileId(): string;
    set workspaceFileId(value: string);
    resetWorkspaceFileId(): void;
    get workspaceFileIdInput(): string | undefined;
    private _workspaceFilePath?;
    get workspaceFilePath(): string;
    set workspaceFilePath(value: string);
    resetWorkspaceFilePath(): void;
    get workspaceFilePathInput(): string | undefined;
    private _accessControl;
    get accessControl(): PermissionsAccessControlList;
    putAccessControl(value: PermissionsAccessControl[] | cdktn.IResolvable): void;
    get accessControlInput(): cdktn.IResolvable | PermissionsAccessControl[] | undefined;
    private _providerConfig;
    get providerConfig(): PermissionsProviderConfigOutputReference;
    putProviderConfig(value: PermissionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): PermissionsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
