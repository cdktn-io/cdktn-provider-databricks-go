/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDisasterRecoveryStableUrlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/disaster_recovery_stable_url#name DataDatabricksDisasterRecoveryStableUrl#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/disaster_recovery_stable_url databricks_disaster_recovery_stable_url}
*/
export declare class DataDatabricksDisasterRecoveryStableUrl extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_disaster_recovery_stable_url";
    /**
    * Generates CDKTN code for importing a DataDatabricksDisasterRecoveryStableUrl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDisasterRecoveryStableUrl to import
    * @param importFromId The id of the existing DataDatabricksDisasterRecoveryStableUrl that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/disaster_recovery_stable_url#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDisasterRecoveryStableUrl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/disaster_recovery_stable_url databricks_disaster_recovery_stable_url} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDisasterRecoveryStableUrlConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDisasterRecoveryStableUrlConfig);
    get effectiveWorkspaceId(): string;
    get failoverGroupName(): string;
    get initialWorkspaceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get stableWorkspaceId(): string;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
