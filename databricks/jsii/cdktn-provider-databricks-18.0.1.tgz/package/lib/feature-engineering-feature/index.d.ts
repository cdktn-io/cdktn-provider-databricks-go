/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FeatureEngineeringFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#description FeatureEngineeringFeature#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#entities FeatureEngineeringFeature#entities}
    */
    readonly entities?: FeatureEngineeringFeatureEntities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#filter_condition FeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#full_name FeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#function FeatureEngineeringFeature#function}
    */
    readonly function: FeatureEngineeringFeatureFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#inputs FeatureEngineeringFeature#inputs}
    */
    readonly inputs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#lineage_context FeatureEngineeringFeature#lineage_context}
    */
    readonly lineageContext?: FeatureEngineeringFeatureLineageContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#provider_config FeatureEngineeringFeature#provider_config}
    */
    readonly providerConfig?: FeatureEngineeringFeatureProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#source FeatureEngineeringFeature#source}
    */
    readonly source: FeatureEngineeringFeatureSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#time_window FeatureEngineeringFeature#time_window}
    */
    readonly timeWindow?: FeatureEngineeringFeatureTimeWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#timeseries_column FeatureEngineeringFeature#timeseries_column}
    */
    readonly timeseriesColumn?: FeatureEngineeringFeatureTimeseriesColumn;
}
export interface FeatureEngineeringFeatureEntities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#name FeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function featureEngineeringFeatureEntitiesToTerraform(struct?: FeatureEngineeringFeatureEntities | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureEntitiesToHclTerraform(struct?: FeatureEngineeringFeatureEntities | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FeatureEngineeringFeatureEntities | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureEntities | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class FeatureEngineeringFeatureEntitiesList extends cdktn.ComplexList {
    internalValue?: FeatureEngineeringFeatureEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FeatureEngineeringFeatureEntitiesOutputReference;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#relative_sd FeatureEngineeringFeature#relative_sd}
    */
    readonly relativeSd?: number;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _relativeSd?;
    get relativeSd(): number;
    set relativeSd(value: number);
    resetRelativeSd(): void;
    get relativeSdInput(): number | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#accuracy FeatureEngineeringFeature#accuracy}
    */
    readonly accuracy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#percentile FeatureEngineeringFeature#percentile}
    */
    readonly percentile: number;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionApproxPercentileToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionApproxPercentileToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined);
    private _accuracy?;
    get accuracy(): number;
    set accuracy(value: number);
    resetAccuracy(): void;
    get accuracyInput(): number | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    get percentileInput(): number | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionAvg {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionAvgToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionAvgToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionAvgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionCountFunctionToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionCountFunctionToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionFirst {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionFirstToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionFirstToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionFirstOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#n FeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionFirstDistinctToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionFirstDistinctToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionFirstN {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#n FeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionFirstNToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionFirstNToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionFirstNOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionLast {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionLastToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionLastToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionLastOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#n FeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionLastDistinctToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionLastDistinctToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionLastN {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#n FeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionLastNToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionLastNToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionLastNOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionMax {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionMaxToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionMaxToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionMaxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionMin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionMinToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionMinToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionMinOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionStddevPopToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionStddevPopToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionStddevPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionStddevSampToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionStddevSampToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionStddevSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionSum {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionSumToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionSumToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionSumOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#offset FeatureEngineeringFeature#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#delay FeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#delay FeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#slide_duration FeatureEngineeringFeature#slide_duration}
    */
    readonly slideDuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined);
    private _slideDuration?;
    get slideDuration(): string;
    set slideDuration(value: string);
    get slideDurationInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined);
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#continuous FeatureEngineeringFeature#continuous}
    */
    readonly continuous?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#rolling FeatureEngineeringFeature#rolling}
    */
    readonly rolling?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#sawtooth FeatureEngineeringFeature#sawtooth}
    */
    readonly sawtooth?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#sliding FeatureEngineeringFeature#sliding}
    */
    readonly sliding?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#tumbling FeatureEngineeringFeature#tumbling}
    */
    readonly tumbling?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionTimeWindowToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined);
    private _continuous;
    get continuous(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuousOutputReference;
    putContinuous(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous): void;
    resetContinuous(): void;
    get continuousInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowContinuous | undefined;
    private _rolling;
    get rolling(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingOutputReference;
    putRolling(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling): void;
    resetRolling(): void;
    get rollingInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | undefined;
    private _sawtooth;
    get sawtooth(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothOutputReference;
    putSawtooth(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth): void;
    resetSawtooth(): void;
    get sawtoothInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | undefined;
    private _sliding;
    get sliding(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingOutputReference;
    putSliding(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding): void;
    resetSliding(): void;
    get slidingInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | undefined;
    private _tumbling;
    get tumbling(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingOutputReference;
    putTumbling(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling): void;
    resetTumbling(): void;
    get tumblingInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionVarPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionVarPopToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionVarPopToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionVarPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#input FeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionVarSampToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionVarSampToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionVarSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionAggregationFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#approx_count_distinct FeatureEngineeringFeature#approx_count_distinct}
    */
    readonly approxCountDistinct?: FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#approx_percentile FeatureEngineeringFeature#approx_percentile}
    */
    readonly approxPercentile?: FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#avg FeatureEngineeringFeature#avg}
    */
    readonly avg?: FeatureEngineeringFeatureFunctionAggregationFunctionAvg;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#count_function FeatureEngineeringFeature#count_function}
    */
    readonly countFunction?: FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#first FeatureEngineeringFeature#first}
    */
    readonly first?: FeatureEngineeringFeatureFunctionAggregationFunctionFirst;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#first_distinct FeatureEngineeringFeature#first_distinct}
    */
    readonly firstDistinct?: FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#first_n FeatureEngineeringFeature#first_n}
    */
    readonly firstN?: FeatureEngineeringFeatureFunctionAggregationFunctionFirstN;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#last FeatureEngineeringFeature#last}
    */
    readonly last?: FeatureEngineeringFeatureFunctionAggregationFunctionLast;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#last_distinct FeatureEngineeringFeature#last_distinct}
    */
    readonly lastDistinct?: FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#last_n FeatureEngineeringFeature#last_n}
    */
    readonly lastN?: FeatureEngineeringFeatureFunctionAggregationFunctionLastN;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#max FeatureEngineeringFeature#max}
    */
    readonly max?: FeatureEngineeringFeatureFunctionAggregationFunctionMax;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#min FeatureEngineeringFeature#min}
    */
    readonly min?: FeatureEngineeringFeatureFunctionAggregationFunctionMin;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#stddev_pop FeatureEngineeringFeature#stddev_pop}
    */
    readonly stddevPop?: FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#stddev_samp FeatureEngineeringFeature#stddev_samp}
    */
    readonly stddevSamp?: FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#sum FeatureEngineeringFeature#sum}
    */
    readonly sum?: FeatureEngineeringFeatureFunctionAggregationFunctionSum;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#time_window FeatureEngineeringFeature#time_window}
    */
    readonly timeWindow?: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#var_pop FeatureEngineeringFeature#var_pop}
    */
    readonly varPop?: FeatureEngineeringFeatureFunctionAggregationFunctionVarPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#var_samp FeatureEngineeringFeature#var_samp}
    */
    readonly varSamp?: FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp;
}
export declare function featureEngineeringFeatureFunctionAggregationFunctionToTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionAggregationFunctionToHclTerraform(struct?: FeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionAggregationFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable | undefined);
    private _approxCountDistinct;
    get approxCountDistinct(): FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctOutputReference;
    putApproxCountDistinct(value: FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct): void;
    resetApproxCountDistinct(): void;
    get approxCountDistinctInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | undefined;
    private _approxPercentile;
    get approxPercentile(): FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileOutputReference;
    putApproxPercentile(value: FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile): void;
    resetApproxPercentile(): void;
    get approxPercentileInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | undefined;
    private _avg;
    get avg(): FeatureEngineeringFeatureFunctionAggregationFunctionAvgOutputReference;
    putAvg(value: FeatureEngineeringFeatureFunctionAggregationFunctionAvg): void;
    resetAvg(): void;
    get avgInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionAvg | undefined;
    private _countFunction;
    get countFunction(): FeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionOutputReference;
    putCountFunction(value: FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction): void;
    resetCountFunction(): void;
    get countFunctionInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | undefined;
    private _first;
    get first(): FeatureEngineeringFeatureFunctionAggregationFunctionFirstOutputReference;
    putFirst(value: FeatureEngineeringFeatureFunctionAggregationFunctionFirst): void;
    resetFirst(): void;
    get firstInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionFirst | undefined;
    private _firstDistinct;
    get firstDistinct(): FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinctOutputReference;
    putFirstDistinct(value: FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct): void;
    resetFirstDistinct(): void;
    get firstDistinctInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | undefined;
    private _firstN;
    get firstN(): FeatureEngineeringFeatureFunctionAggregationFunctionFirstNOutputReference;
    putFirstN(value: FeatureEngineeringFeatureFunctionAggregationFunctionFirstN): void;
    resetFirstN(): void;
    get firstNInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionFirstN | undefined;
    private _last;
    get last(): FeatureEngineeringFeatureFunctionAggregationFunctionLastOutputReference;
    putLast(value: FeatureEngineeringFeatureFunctionAggregationFunctionLast): void;
    resetLast(): void;
    get lastInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionLast | undefined;
    private _lastDistinct;
    get lastDistinct(): FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinctOutputReference;
    putLastDistinct(value: FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct): void;
    resetLastDistinct(): void;
    get lastDistinctInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | undefined;
    private _lastN;
    get lastN(): FeatureEngineeringFeatureFunctionAggregationFunctionLastNOutputReference;
    putLastN(value: FeatureEngineeringFeatureFunctionAggregationFunctionLastN): void;
    resetLastN(): void;
    get lastNInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionLastN | undefined;
    private _max;
    get max(): FeatureEngineeringFeatureFunctionAggregationFunctionMaxOutputReference;
    putMax(value: FeatureEngineeringFeatureFunctionAggregationFunctionMax): void;
    resetMax(): void;
    get maxInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionMax | undefined;
    private _min;
    get min(): FeatureEngineeringFeatureFunctionAggregationFunctionMinOutputReference;
    putMin(value: FeatureEngineeringFeatureFunctionAggregationFunctionMin): void;
    resetMin(): void;
    get minInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionMin | undefined;
    private _stddevPop;
    get stddevPop(): FeatureEngineeringFeatureFunctionAggregationFunctionStddevPopOutputReference;
    putStddevPop(value: FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop): void;
    resetStddevPop(): void;
    get stddevPopInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | undefined;
    private _stddevSamp;
    get stddevSamp(): FeatureEngineeringFeatureFunctionAggregationFunctionStddevSampOutputReference;
    putStddevSamp(value: FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp): void;
    resetStddevSamp(): void;
    get stddevSampInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | undefined;
    private _sum;
    get sum(): FeatureEngineeringFeatureFunctionAggregationFunctionSumOutputReference;
    putSum(value: FeatureEngineeringFeatureFunctionAggregationFunctionSum): void;
    resetSum(): void;
    get sumInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionSum | undefined;
    private _timeWindow;
    get timeWindow(): FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowOutputReference;
    putTimeWindow(value: FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | undefined;
    private _varPop;
    get varPop(): FeatureEngineeringFeatureFunctionAggregationFunctionVarPopOutputReference;
    putVarPop(value: FeatureEngineeringFeatureFunctionAggregationFunctionVarPop): void;
    resetVarPop(): void;
    get varPopInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionVarPop | undefined;
    private _varSamp;
    get varSamp(): FeatureEngineeringFeatureFunctionAggregationFunctionVarSampOutputReference;
    putVarSamp(value: FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp): void;
    resetVarSamp(): void;
    get varSampInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | undefined;
}
export interface FeatureEngineeringFeatureFunctionColumnSelection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#column FeatureEngineeringFeature#column}
    */
    readonly column: string;
}
export declare function featureEngineeringFeatureFunctionColumnSelectionToTerraform(struct?: FeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionColumnSelectionToHclTerraform(struct?: FeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionColumnSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
}
export interface FeatureEngineeringFeatureFunctionExtraParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#key FeatureEngineeringFeature#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#value FeatureEngineeringFeature#value}
    */
    readonly value: string;
}
export declare function featureEngineeringFeatureFunctionExtraParametersToTerraform(struct?: FeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionExtraParametersToHclTerraform(struct?: FeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionExtraParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunctionExtraParameters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class FeatureEngineeringFeatureFunctionExtraParametersList extends cdktn.ComplexList {
    internalValue?: FeatureEngineeringFeatureFunctionExtraParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FeatureEngineeringFeatureFunctionExtraParametersOutputReference;
}
export interface FeatureEngineeringFeatureFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#aggregation_function FeatureEngineeringFeature#aggregation_function}
    */
    readonly aggregationFunction?: FeatureEngineeringFeatureFunctionAggregationFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#column_selection FeatureEngineeringFeature#column_selection}
    */
    readonly columnSelection?: FeatureEngineeringFeatureFunctionColumnSelection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#extra_parameters FeatureEngineeringFeature#extra_parameters}
    */
    readonly extraParameters?: FeatureEngineeringFeatureFunctionExtraParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#function_type FeatureEngineeringFeature#function_type}
    */
    readonly functionType?: string;
}
export declare function featureEngineeringFeatureFunctionToTerraform(struct?: FeatureEngineeringFeatureFunction | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureFunctionToHclTerraform(struct?: FeatureEngineeringFeatureFunction | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureFunction | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureFunction | cdktn.IResolvable | undefined);
    private _aggregationFunction;
    get aggregationFunction(): FeatureEngineeringFeatureFunctionAggregationFunctionOutputReference;
    putAggregationFunction(value: FeatureEngineeringFeatureFunctionAggregationFunction): void;
    resetAggregationFunction(): void;
    get aggregationFunctionInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionAggregationFunction | undefined;
    private _columnSelection;
    get columnSelection(): FeatureEngineeringFeatureFunctionColumnSelectionOutputReference;
    putColumnSelection(value: FeatureEngineeringFeatureFunctionColumnSelection): void;
    resetColumnSelection(): void;
    get columnSelectionInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionColumnSelection | undefined;
    private _extraParameters;
    get extraParameters(): FeatureEngineeringFeatureFunctionExtraParametersList;
    putExtraParameters(value: FeatureEngineeringFeatureFunctionExtraParameters[] | cdktn.IResolvable): void;
    resetExtraParameters(): void;
    get extraParametersInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunctionExtraParameters[] | undefined;
    private _functionType?;
    get functionType(): string;
    set functionType(value: string);
    resetFunctionType(): void;
    get functionTypeInput(): string | undefined;
}
export interface FeatureEngineeringFeatureLineageContextJobContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#job_id FeatureEngineeringFeature#job_id}
    */
    readonly jobId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#job_run_id FeatureEngineeringFeature#job_run_id}
    */
    readonly jobRunId?: number;
}
export declare function featureEngineeringFeatureLineageContextJobContextToTerraform(struct?: FeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureLineageContextJobContextToHclTerraform(struct?: FeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureLineageContextJobContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    resetJobId(): void;
    get jobIdInput(): number | undefined;
    private _jobRunId?;
    get jobRunId(): number;
    set jobRunId(value: number);
    resetJobRunId(): void;
    get jobRunIdInput(): number | undefined;
}
export interface FeatureEngineeringFeatureLineageContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#job_context FeatureEngineeringFeature#job_context}
    */
    readonly jobContext?: FeatureEngineeringFeatureLineageContextJobContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#notebook_id FeatureEngineeringFeature#notebook_id}
    */
    readonly notebookId?: number;
}
export declare function featureEngineeringFeatureLineageContextToTerraform(struct?: FeatureEngineeringFeatureLineageContext | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureLineageContextToHclTerraform(struct?: FeatureEngineeringFeatureLineageContext | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureLineageContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureLineageContext | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureLineageContext | cdktn.IResolvable | undefined);
    private _jobContext;
    get jobContext(): FeatureEngineeringFeatureLineageContextJobContextOutputReference;
    putJobContext(value: FeatureEngineeringFeatureLineageContextJobContext): void;
    resetJobContext(): void;
    get jobContextInput(): cdktn.IResolvable | FeatureEngineeringFeatureLineageContextJobContext | undefined;
    private _notebookId?;
    get notebookId(): number;
    set notebookId(value: number);
    resetNotebookId(): void;
    get notebookIdInput(): number | undefined;
}
export interface FeatureEngineeringFeatureProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#workspace_id FeatureEngineeringFeature#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function featureEngineeringFeatureProviderConfigToTerraform(struct?: FeatureEngineeringFeatureProviderConfig | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureProviderConfigToHclTerraform(struct?: FeatureEngineeringFeatureProviderConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface FeatureEngineeringFeatureSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#dataframe_schema FeatureEngineeringFeature#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#entity_columns FeatureEngineeringFeature#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#filter_condition FeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#full_name FeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#timeseries_column FeatureEngineeringFeature#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#transformation_sql FeatureEngineeringFeature#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function featureEngineeringFeatureSourceDeltaTableSourceToTerraform(struct?: FeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceDeltaTableSourceToHclTerraform(struct?: FeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#variant_expr_path FeatureEngineeringFeature#variant_expr_path}
    */
    readonly variantExprPath: string;
}
export declare function featureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersToTerraform(struct?: FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersToHclTerraform(struct?: FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable | undefined);
    private _variantExprPath?;
    get variantExprPath(): string;
    set variantExprPath(value: string);
    get variantExprPathInput(): string | undefined;
}
export declare class FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersList extends cdktn.ComplexList {
    internalValue?: FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersOutputReference;
}
export interface FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#variant_expr_path FeatureEngineeringFeature#variant_expr_path}
    */
    readonly variantExprPath: string;
}
export declare function featureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierToTerraform(struct?: FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierToHclTerraform(struct?: FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable | undefined);
    private _variantExprPath?;
    get variantExprPath(): string;
    set variantExprPath(value: string);
    get variantExprPathInput(): string | undefined;
}
export interface FeatureEngineeringFeatureSourceKafkaSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#entity_column_identifiers FeatureEngineeringFeature#entity_column_identifiers}
    */
    readonly entityColumnIdentifiers?: FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#filter_condition FeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#name FeatureEngineeringFeature#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#timeseries_column_identifier FeatureEngineeringFeature#timeseries_column_identifier}
    */
    readonly timeseriesColumnIdentifier?: FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier;
}
export declare function featureEngineeringFeatureSourceKafkaSourceToTerraform(struct?: FeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceKafkaSourceToHclTerraform(struct?: FeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceKafkaSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable | undefined);
    private _entityColumnIdentifiers;
    get entityColumnIdentifiers(): FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiersList;
    putEntityColumnIdentifiers(value: FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable): void;
    resetEntityColumnIdentifiers(): void;
    get entityColumnIdentifiersInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceKafkaSourceEntityColumnIdentifiers[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _timeseriesColumnIdentifier;
    get timeseriesColumnIdentifier(): FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifierOutputReference;
    putTimeseriesColumnIdentifier(value: FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier): void;
    resetTimeseriesColumnIdentifier(): void;
    get timeseriesColumnIdentifierInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceKafkaSourceTimeseriesColumnIdentifier | undefined;
}
export interface FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#data_type FeatureEngineeringFeature#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#name FeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function featureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsToTerraform(struct?: FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsToHclTerraform(struct?: FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | cdktn.IResolvable | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsList extends cdktn.ComplexList {
    internalValue?: FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsOutputReference;
}
export interface FeatureEngineeringFeatureSourceRequestSourceFlatSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#fields FeatureEngineeringFeature#fields}
    */
    readonly fields: FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable;
}
export declare function featureEngineeringFeatureSourceRequestSourceFlatSchemaToTerraform(struct?: FeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceRequestSourceFlatSchemaToHclTerraform(struct?: FeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceRequestSourceFlatSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable | undefined);
    private _fields;
    get fields(): FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsList;
    putFields(value: FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | undefined;
}
export interface FeatureEngineeringFeatureSourceRequestSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#flat_schema FeatureEngineeringFeature#flat_schema}
    */
    readonly flatSchema?: FeatureEngineeringFeatureSourceRequestSourceFlatSchema;
}
export declare function featureEngineeringFeatureSourceRequestSourceToTerraform(struct?: FeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceRequestSourceToHclTerraform(struct?: FeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceRequestSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable | undefined);
    private _flatSchema;
    get flatSchema(): FeatureEngineeringFeatureSourceRequestSourceFlatSchemaOutputReference;
    putFlatSchema(value: FeatureEngineeringFeatureSourceRequestSourceFlatSchema): void;
    resetFlatSchema(): void;
    get flatSchemaInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceRequestSourceFlatSchema | undefined;
}
export interface FeatureEngineeringFeatureSourceStreamSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#dataframe_schema FeatureEngineeringFeature#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#filter_condition FeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#full_name FeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#transformation_sql FeatureEngineeringFeature#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function featureEngineeringFeatureSourceStreamSourceToTerraform(struct?: FeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceStreamSourceToHclTerraform(struct?: FeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceStreamSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface FeatureEngineeringFeatureSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#delta_table_source FeatureEngineeringFeature#delta_table_source}
    */
    readonly deltaTableSource?: FeatureEngineeringFeatureSourceDeltaTableSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#kafka_source FeatureEngineeringFeature#kafka_source}
    */
    readonly kafkaSource?: FeatureEngineeringFeatureSourceKafkaSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#request_source FeatureEngineeringFeature#request_source}
    */
    readonly requestSource?: FeatureEngineeringFeatureSourceRequestSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#stream_source FeatureEngineeringFeature#stream_source}
    */
    readonly streamSource?: FeatureEngineeringFeatureSourceStreamSource;
}
export declare function featureEngineeringFeatureSourceToTerraform(struct?: FeatureEngineeringFeatureSource | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureSourceToHclTerraform(struct?: FeatureEngineeringFeatureSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureSource | cdktn.IResolvable | undefined);
    private _deltaTableSource;
    get deltaTableSource(): FeatureEngineeringFeatureSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: FeatureEngineeringFeatureSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceDeltaTableSource | undefined;
    private _kafkaSource;
    get kafkaSource(): FeatureEngineeringFeatureSourceKafkaSourceOutputReference;
    putKafkaSource(value: FeatureEngineeringFeatureSourceKafkaSource): void;
    resetKafkaSource(): void;
    get kafkaSourceInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceKafkaSource | undefined;
    private _requestSource;
    get requestSource(): FeatureEngineeringFeatureSourceRequestSourceOutputReference;
    putRequestSource(value: FeatureEngineeringFeatureSourceRequestSource): void;
    resetRequestSource(): void;
    get requestSourceInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceRequestSource | undefined;
    private _streamSource;
    get streamSource(): FeatureEngineeringFeatureSourceStreamSourceOutputReference;
    putStreamSource(value: FeatureEngineeringFeatureSourceStreamSource): void;
    resetStreamSource(): void;
    get streamSourceInput(): cdktn.IResolvable | FeatureEngineeringFeatureSourceStreamSource | undefined;
}
export interface FeatureEngineeringFeatureTimeWindowContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#offset FeatureEngineeringFeature#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function featureEngineeringFeatureTimeWindowContinuousToTerraform(struct?: FeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureTimeWindowContinuousToHclTerraform(struct?: FeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureTimeWindowContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureTimeWindowContinuous | cdktn.IResolvable | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureTimeWindowRolling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#delay FeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function featureEngineeringFeatureTimeWindowRollingToTerraform(struct?: FeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureTimeWindowRollingToHclTerraform(struct?: FeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureTimeWindowRollingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureTimeWindowRolling | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureTimeWindowSawtooth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#delay FeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function featureEngineeringFeatureTimeWindowSawtoothToTerraform(struct?: FeatureEngineeringFeatureTimeWindowSawtooth | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureTimeWindowSawtoothToHclTerraform(struct?: FeatureEngineeringFeatureTimeWindowSawtooth | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureTimeWindowSawtoothOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureTimeWindowSawtooth | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureTimeWindowSawtooth | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureTimeWindowSliding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#slide_duration FeatureEngineeringFeature#slide_duration}
    */
    readonly slideDuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function featureEngineeringFeatureTimeWindowSlidingToTerraform(struct?: FeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureTimeWindowSlidingToHclTerraform(struct?: FeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureTimeWindowSlidingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureTimeWindowSliding | cdktn.IResolvable | undefined);
    private _slideDuration?;
    get slideDuration(): string;
    set slideDuration(value: string);
    get slideDurationInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureTimeWindowTumbling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#window_duration FeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function featureEngineeringFeatureTimeWindowTumblingToTerraform(struct?: FeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureTimeWindowTumblingToHclTerraform(struct?: FeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureTimeWindowTumblingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureTimeWindowTumbling | cdktn.IResolvable | undefined);
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface FeatureEngineeringFeatureTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#continuous FeatureEngineeringFeature#continuous}
    */
    readonly continuous?: FeatureEngineeringFeatureTimeWindowContinuous;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#rolling FeatureEngineeringFeature#rolling}
    */
    readonly rolling?: FeatureEngineeringFeatureTimeWindowRolling;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#sawtooth FeatureEngineeringFeature#sawtooth}
    */
    readonly sawtooth?: FeatureEngineeringFeatureTimeWindowSawtooth;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#sliding FeatureEngineeringFeature#sliding}
    */
    readonly sliding?: FeatureEngineeringFeatureTimeWindowSliding;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#tumbling FeatureEngineeringFeature#tumbling}
    */
    readonly tumbling?: FeatureEngineeringFeatureTimeWindowTumbling;
}
export declare function featureEngineeringFeatureTimeWindowToTerraform(struct?: FeatureEngineeringFeatureTimeWindow | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureTimeWindowToHclTerraform(struct?: FeatureEngineeringFeatureTimeWindow | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureTimeWindow | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureTimeWindow | cdktn.IResolvable | undefined);
    private _continuous;
    get continuous(): FeatureEngineeringFeatureTimeWindowContinuousOutputReference;
    putContinuous(value: FeatureEngineeringFeatureTimeWindowContinuous): void;
    resetContinuous(): void;
    get continuousInput(): cdktn.IResolvable | FeatureEngineeringFeatureTimeWindowContinuous | undefined;
    private _rolling;
    get rolling(): FeatureEngineeringFeatureTimeWindowRollingOutputReference;
    putRolling(value: FeatureEngineeringFeatureTimeWindowRolling): void;
    resetRolling(): void;
    get rollingInput(): cdktn.IResolvable | FeatureEngineeringFeatureTimeWindowRolling | undefined;
    private _sawtooth;
    get sawtooth(): FeatureEngineeringFeatureTimeWindowSawtoothOutputReference;
    putSawtooth(value: FeatureEngineeringFeatureTimeWindowSawtooth): void;
    resetSawtooth(): void;
    get sawtoothInput(): cdktn.IResolvable | FeatureEngineeringFeatureTimeWindowSawtooth | undefined;
    private _sliding;
    get sliding(): FeatureEngineeringFeatureTimeWindowSlidingOutputReference;
    putSliding(value: FeatureEngineeringFeatureTimeWindowSliding): void;
    resetSliding(): void;
    get slidingInput(): cdktn.IResolvable | FeatureEngineeringFeatureTimeWindowSliding | undefined;
    private _tumbling;
    get tumbling(): FeatureEngineeringFeatureTimeWindowTumblingOutputReference;
    putTumbling(value: FeatureEngineeringFeatureTimeWindowTumbling): void;
    resetTumbling(): void;
    get tumblingInput(): cdktn.IResolvable | FeatureEngineeringFeatureTimeWindowTumbling | undefined;
}
export interface FeatureEngineeringFeatureTimeseriesColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#name FeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function featureEngineeringFeatureTimeseriesColumnToTerraform(struct?: FeatureEngineeringFeatureTimeseriesColumn | cdktn.IResolvable): any;
export declare function featureEngineeringFeatureTimeseriesColumnToHclTerraform(struct?: FeatureEngineeringFeatureTimeseriesColumn | cdktn.IResolvable): any;
export declare class FeatureEngineeringFeatureTimeseriesColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringFeatureTimeseriesColumn | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringFeatureTimeseriesColumn | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature databricks_feature_engineering_feature}
*/
export declare class FeatureEngineeringFeature extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_feature_engineering_feature";
    /**
    * Generates CDKTN code for importing a FeatureEngineeringFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FeatureEngineeringFeature to import
    * @param importFromId The id of the existing FeatureEngineeringFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FeatureEngineeringFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/feature_engineering_feature databricks_feature_engineering_feature} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FeatureEngineeringFeatureConfig
    */
    constructor(scope: Construct, id: string, config: FeatureEngineeringFeatureConfig);
    get catalogName(): string;
    get createdAt(): string;
    get createdBy(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _entities;
    get entities(): FeatureEngineeringFeatureEntitiesList;
    putEntities(value: FeatureEngineeringFeatureEntities[] | cdktn.IResolvable): void;
    resetEntities(): void;
    get entitiesInput(): cdktn.IResolvable | FeatureEngineeringFeatureEntities[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _function;
    get function(): FeatureEngineeringFeatureFunctionOutputReference;
    putFunction(value: FeatureEngineeringFeatureFunction): void;
    get functionInput(): cdktn.IResolvable | FeatureEngineeringFeatureFunction | undefined;
    private _inputs?;
    get inputs(): string[];
    set inputs(value: string[]);
    resetInputs(): void;
    get inputsInput(): string[] | undefined;
    private _lineageContext;
    get lineageContext(): FeatureEngineeringFeatureLineageContextOutputReference;
    putLineageContext(value: FeatureEngineeringFeatureLineageContext): void;
    resetLineageContext(): void;
    get lineageContextInput(): cdktn.IResolvable | FeatureEngineeringFeatureLineageContext | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): FeatureEngineeringFeatureProviderConfigOutputReference;
    putProviderConfig(value: FeatureEngineeringFeatureProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | FeatureEngineeringFeatureProviderConfig | undefined;
    get schemaName(): string;
    private _source;
    get source(): FeatureEngineeringFeatureSourceOutputReference;
    putSource(value: FeatureEngineeringFeatureSource): void;
    get sourceInput(): cdktn.IResolvable | FeatureEngineeringFeatureSource | undefined;
    private _timeWindow;
    get timeWindow(): FeatureEngineeringFeatureTimeWindowOutputReference;
    putTimeWindow(value: FeatureEngineeringFeatureTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): cdktn.IResolvable | FeatureEngineeringFeatureTimeWindow | undefined;
    private _timeseriesColumn;
    get timeseriesColumn(): FeatureEngineeringFeatureTimeseriesColumnOutputReference;
    putTimeseriesColumn(value: FeatureEngineeringFeatureTimeseriesColumn): void;
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): cdktn.IResolvable | FeatureEngineeringFeatureTimeseriesColumn | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
