/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#id DataDatabricksCatalog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#name DataDatabricksCatalog#name}
    */
    readonly name: string;
    /**
    * catalog_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#catalog_info DataDatabricksCatalog#catalog_info}
    */
    readonly catalogInfo?: DataDatabricksCatalogCatalogInfo;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#provider_config DataDatabricksCatalog#provider_config}
    */
    readonly providerConfig?: DataDatabricksCatalogProviderConfig;
}
export interface DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#inherited_from_name DataDatabricksCatalog#inherited_from_name}
    */
    readonly inheritedFromName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#inherited_from_type DataDatabricksCatalog#inherited_from_type}
    */
    readonly inheritedFromType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#value DataDatabricksCatalog#value}
    */
    readonly value: string;
}
export declare function dataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlagToTerraform(struct?: DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlagOutputReference | DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag): any;
export declare function dataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlagToHclTerraform(struct?: DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlagOutputReference | DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag): any;
export declare class DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag | undefined;
    set internalValue(value: DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag | undefined);
    private _inheritedFromName?;
    get inheritedFromName(): string;
    set inheritedFromName(value: string);
    resetInheritedFromName(): void;
    get inheritedFromNameInput(): string | undefined;
    private _inheritedFromType?;
    get inheritedFromType(): string;
    set inheritedFromType(value: string);
    resetInheritedFromType(): void;
    get inheritedFromTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#azure_cmk_access_connector_id DataDatabricksCatalog#azure_cmk_access_connector_id}
    */
    readonly azureCmkAccessConnectorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#azure_cmk_managed_identity_id DataDatabricksCatalog#azure_cmk_managed_identity_id}
    */
    readonly azureCmkManagedIdentityId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#azure_tenant_id DataDatabricksCatalog#azure_tenant_id}
    */
    readonly azureTenantId: string;
}
export declare function dataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettingsToTerraform(struct?: DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettingsOutputReference | DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings): any;
export declare function dataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettingsToHclTerraform(struct?: DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettingsOutputReference | DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings): any;
export declare class DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings | undefined;
    set internalValue(value: DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings | undefined);
    private _azureCmkAccessConnectorId?;
    get azureCmkAccessConnectorId(): string;
    set azureCmkAccessConnectorId(value: string);
    resetAzureCmkAccessConnectorId(): void;
    get azureCmkAccessConnectorIdInput(): string | undefined;
    private _azureCmkManagedIdentityId?;
    get azureCmkManagedIdentityId(): string;
    set azureCmkManagedIdentityId(value: string);
    resetAzureCmkManagedIdentityId(): void;
    get azureCmkManagedIdentityIdInput(): string | undefined;
    private _azureTenantId?;
    get azureTenantId(): string;
    set azureTenantId(value: string);
    get azureTenantIdInput(): string | undefined;
}
export interface DataDatabricksCatalogCatalogInfoManagedEncryptionSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#azure_key_vault_key_id DataDatabricksCatalog#azure_key_vault_key_id}
    */
    readonly azureKeyVaultKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#customer_managed_key_id DataDatabricksCatalog#customer_managed_key_id}
    */
    readonly customerManagedKeyId?: string;
    /**
    * azure_encryption_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#azure_encryption_settings DataDatabricksCatalog#azure_encryption_settings}
    */
    readonly azureEncryptionSettings?: DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings;
}
export declare function dataDatabricksCatalogCatalogInfoManagedEncryptionSettingsToTerraform(struct?: DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsOutputReference | DataDatabricksCatalogCatalogInfoManagedEncryptionSettings): any;
export declare function dataDatabricksCatalogCatalogInfoManagedEncryptionSettingsToHclTerraform(struct?: DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsOutputReference | DataDatabricksCatalogCatalogInfoManagedEncryptionSettings): any;
export declare class DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCatalogCatalogInfoManagedEncryptionSettings | undefined;
    set internalValue(value: DataDatabricksCatalogCatalogInfoManagedEncryptionSettings | undefined);
    private _azureKeyVaultKeyId?;
    get azureKeyVaultKeyId(): string;
    set azureKeyVaultKeyId(value: string);
    resetAzureKeyVaultKeyId(): void;
    get azureKeyVaultKeyIdInput(): string | undefined;
    private _customerManagedKeyId?;
    get customerManagedKeyId(): string;
    set customerManagedKeyId(value: string);
    resetCustomerManagedKeyId(): void;
    get customerManagedKeyIdInput(): string | undefined;
    private _azureEncryptionSettings;
    get azureEncryptionSettings(): DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettingsOutputReference;
    putAzureEncryptionSettings(value: DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings): void;
    resetAzureEncryptionSettings(): void;
    get azureEncryptionSettingsInput(): DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsAzureEncryptionSettings | undefined;
}
export interface DataDatabricksCatalogCatalogInfoProvisioningInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#state DataDatabricksCatalog#state}
    */
    readonly state?: string;
}
export declare function dataDatabricksCatalogCatalogInfoProvisioningInfoToTerraform(struct?: DataDatabricksCatalogCatalogInfoProvisioningInfoOutputReference | DataDatabricksCatalogCatalogInfoProvisioningInfo): any;
export declare function dataDatabricksCatalogCatalogInfoProvisioningInfoToHclTerraform(struct?: DataDatabricksCatalogCatalogInfoProvisioningInfoOutputReference | DataDatabricksCatalogCatalogInfoProvisioningInfo): any;
export declare class DataDatabricksCatalogCatalogInfoProvisioningInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCatalogCatalogInfoProvisioningInfo | undefined;
    set internalValue(value: DataDatabricksCatalogCatalogInfoProvisioningInfo | undefined);
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface DataDatabricksCatalogCatalogInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#browse_only DataDatabricksCatalog#browse_only}
    */
    readonly browseOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#catalog_type DataDatabricksCatalog#catalog_type}
    */
    readonly catalogType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#comment DataDatabricksCatalog#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#connection_name DataDatabricksCatalog#connection_name}
    */
    readonly connectionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#created_at DataDatabricksCatalog#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#created_by DataDatabricksCatalog#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#custom_max_retention_hours DataDatabricksCatalog#custom_max_retention_hours}
    */
    readonly customMaxRetentionHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#enable_predictive_optimization DataDatabricksCatalog#enable_predictive_optimization}
    */
    readonly enablePredictiveOptimization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#full_name DataDatabricksCatalog#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#isolation_mode DataDatabricksCatalog#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#metastore_id DataDatabricksCatalog#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#name DataDatabricksCatalog#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#options DataDatabricksCatalog#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#owner DataDatabricksCatalog#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#properties DataDatabricksCatalog#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#provider_name DataDatabricksCatalog#provider_name}
    */
    readonly providerName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#securable_type DataDatabricksCatalog#securable_type}
    */
    readonly securableType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#share_name DataDatabricksCatalog#share_name}
    */
    readonly shareName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#storage_location DataDatabricksCatalog#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#storage_root DataDatabricksCatalog#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#updated_at DataDatabricksCatalog#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#updated_by DataDatabricksCatalog#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * effective_predictive_optimization_flag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#effective_predictive_optimization_flag DataDatabricksCatalog#effective_predictive_optimization_flag}
    */
    readonly effectivePredictiveOptimizationFlag?: DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag;
    /**
    * managed_encryption_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#managed_encryption_settings DataDatabricksCatalog#managed_encryption_settings}
    */
    readonly managedEncryptionSettings?: DataDatabricksCatalogCatalogInfoManagedEncryptionSettings;
    /**
    * provisioning_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#provisioning_info DataDatabricksCatalog#provisioning_info}
    */
    readonly provisioningInfo?: DataDatabricksCatalogCatalogInfoProvisioningInfo;
}
export declare function dataDatabricksCatalogCatalogInfoToTerraform(struct?: DataDatabricksCatalogCatalogInfoOutputReference | DataDatabricksCatalogCatalogInfo): any;
export declare function dataDatabricksCatalogCatalogInfoToHclTerraform(struct?: DataDatabricksCatalogCatalogInfoOutputReference | DataDatabricksCatalogCatalogInfo): any;
export declare class DataDatabricksCatalogCatalogInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCatalogCatalogInfo | undefined;
    set internalValue(value: DataDatabricksCatalogCatalogInfo | undefined);
    private _browseOnly?;
    get browseOnly(): boolean | cdktn.IResolvable;
    set browseOnly(value: boolean | cdktn.IResolvable);
    resetBrowseOnly(): void;
    get browseOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _catalogType?;
    get catalogType(): string;
    set catalogType(value: string);
    resetCatalogType(): void;
    get catalogTypeInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _customMaxRetentionHours?;
    get customMaxRetentionHours(): number;
    set customMaxRetentionHours(value: number);
    resetCustomMaxRetentionHours(): void;
    get customMaxRetentionHoursInput(): number | undefined;
    private _enablePredictiveOptimization?;
    get enablePredictiveOptimization(): string;
    set enablePredictiveOptimization(value: string);
    resetEnablePredictiveOptimization(): void;
    get enablePredictiveOptimizationInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _providerName?;
    get providerName(): string;
    set providerName(value: string);
    resetProviderName(): void;
    get providerNameInput(): string | undefined;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    resetSecurableType(): void;
    get securableTypeInput(): string | undefined;
    private _shareName?;
    get shareName(): string;
    set shareName(value: string);
    resetShareName(): void;
    get shareNameInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _effectivePredictiveOptimizationFlag;
    get effectivePredictiveOptimizationFlag(): DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlagOutputReference;
    putEffectivePredictiveOptimizationFlag(value: DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag): void;
    resetEffectivePredictiveOptimizationFlag(): void;
    get effectivePredictiveOptimizationFlagInput(): DataDatabricksCatalogCatalogInfoEffectivePredictiveOptimizationFlag | undefined;
    private _managedEncryptionSettings;
    get managedEncryptionSettings(): DataDatabricksCatalogCatalogInfoManagedEncryptionSettingsOutputReference;
    putManagedEncryptionSettings(value: DataDatabricksCatalogCatalogInfoManagedEncryptionSettings): void;
    resetManagedEncryptionSettings(): void;
    get managedEncryptionSettingsInput(): DataDatabricksCatalogCatalogInfoManagedEncryptionSettings | undefined;
    private _provisioningInfo;
    get provisioningInfo(): DataDatabricksCatalogCatalogInfoProvisioningInfoOutputReference;
    putProvisioningInfo(value: DataDatabricksCatalogCatalogInfoProvisioningInfo): void;
    resetProvisioningInfo(): void;
    get provisioningInfoInput(): DataDatabricksCatalogCatalogInfoProvisioningInfo | undefined;
}
export interface DataDatabricksCatalogProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#workspace_id DataDatabricksCatalog#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksCatalogProviderConfigToTerraform(struct?: DataDatabricksCatalogProviderConfigOutputReference | DataDatabricksCatalogProviderConfig): any;
export declare function dataDatabricksCatalogProviderConfigToHclTerraform(struct?: DataDatabricksCatalogProviderConfigOutputReference | DataDatabricksCatalogProviderConfig): any;
export declare class DataDatabricksCatalogProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCatalogProviderConfig | undefined;
    set internalValue(value: DataDatabricksCatalogProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog databricks_catalog}
*/
export declare class DataDatabricksCatalog extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_catalog";
    /**
    * Generates CDKTN code for importing a DataDatabricksCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksCatalog to import
    * @param importFromId The id of the existing DataDatabricksCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/data-sources/catalog databricks_catalog} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksCatalogConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksCatalogConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _catalogInfo;
    get catalogInfo(): DataDatabricksCatalogCatalogInfoOutputReference;
    putCatalogInfo(value: DataDatabricksCatalogCatalogInfo): void;
    resetCatalogInfo(): void;
    get catalogInfoInput(): DataDatabricksCatalogCatalogInfo | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksCatalogProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksCatalogProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksCatalogProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
