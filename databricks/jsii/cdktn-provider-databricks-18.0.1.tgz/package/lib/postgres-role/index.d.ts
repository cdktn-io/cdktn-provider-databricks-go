/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#parent PostgresRole#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#provider_config PostgresRole#provider_config}
    */
    readonly providerConfig?: PostgresRoleProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#replace_existing PostgresRole#replace_existing}
    */
    readonly replaceExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#role_id PostgresRole#role_id}
    */
    readonly roleId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#spec PostgresRole#spec}
    */
    readonly spec?: PostgresRoleSpec;
}
export interface PostgresRoleProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#workspace_id PostgresRole#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresRoleProviderConfigToTerraform(struct?: PostgresRoleProviderConfig | cdktn.IResolvable): any;
export declare function postgresRoleProviderConfigToHclTerraform(struct?: PostgresRoleProviderConfig | cdktn.IResolvable): any;
export declare class PostgresRoleProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresRoleProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresRoleProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresRoleSpecAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#bypassrls PostgresRole#bypassrls}
    */
    readonly bypassrls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#createdb PostgresRole#createdb}
    */
    readonly createdb?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#createrole PostgresRole#createrole}
    */
    readonly createrole?: boolean | cdktn.IResolvable;
}
export declare function postgresRoleSpecAttributesToTerraform(struct?: PostgresRoleSpecAttributes | cdktn.IResolvable): any;
export declare function postgresRoleSpecAttributesToHclTerraform(struct?: PostgresRoleSpecAttributes | cdktn.IResolvable): any;
export declare class PostgresRoleSpecAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresRoleSpecAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresRoleSpecAttributes | cdktn.IResolvable | undefined);
    private _bypassrls?;
    get bypassrls(): boolean | cdktn.IResolvable;
    set bypassrls(value: boolean | cdktn.IResolvable);
    resetBypassrls(): void;
    get bypassrlsInput(): boolean | cdktn.IResolvable | undefined;
    private _createdb?;
    get createdb(): boolean | cdktn.IResolvable;
    set createdb(value: boolean | cdktn.IResolvable);
    resetCreatedb(): void;
    get createdbInput(): boolean | cdktn.IResolvable | undefined;
    private _createrole?;
    get createrole(): boolean | cdktn.IResolvable;
    set createrole(value: boolean | cdktn.IResolvable);
    resetCreaterole(): void;
    get createroleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PostgresRoleSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#attributes PostgresRole#attributes}
    */
    readonly attributes?: PostgresRoleSpecAttributes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#auth_method PostgresRole#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#identity_type PostgresRole#identity_type}
    */
    readonly identityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#membership_roles PostgresRole#membership_roles}
    */
    readonly membershipRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#postgres_role PostgresRole#postgres_role}
    */
    readonly postgresRole?: string;
}
export declare function postgresRoleSpecToTerraform(struct?: PostgresRoleSpec | cdktn.IResolvable): any;
export declare function postgresRoleSpecToHclTerraform(struct?: PostgresRoleSpec | cdktn.IResolvable): any;
export declare class PostgresRoleSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresRoleSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresRoleSpec | cdktn.IResolvable | undefined);
    private _attributes;
    get attributes(): PostgresRoleSpecAttributesOutputReference;
    putAttributes(value: PostgresRoleSpecAttributes): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | PostgresRoleSpecAttributes | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _membershipRoles?;
    get membershipRoles(): string[];
    set membershipRoles(value: string[]);
    resetMembershipRoles(): void;
    get membershipRolesInput(): string[] | undefined;
    private _postgresRole?;
    get postgresRole(): string;
    set postgresRole(value: string);
    resetPostgresRole(): void;
    get postgresRoleInput(): string | undefined;
}
export interface PostgresRoleStatusAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#bypassrls PostgresRole#bypassrls}
    */
    readonly bypassrls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#createdb PostgresRole#createdb}
    */
    readonly createdb?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#createrole PostgresRole#createrole}
    */
    readonly createrole?: boolean | cdktn.IResolvable;
}
export declare function postgresRoleStatusAttributesToTerraform(struct?: PostgresRoleStatusAttributes | cdktn.IResolvable): any;
export declare function postgresRoleStatusAttributesToHclTerraform(struct?: PostgresRoleStatusAttributes | cdktn.IResolvable): any;
export declare class PostgresRoleStatusAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresRoleStatusAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresRoleStatusAttributes | cdktn.IResolvable | undefined);
    private _bypassrls?;
    get bypassrls(): boolean | cdktn.IResolvable;
    set bypassrls(value: boolean | cdktn.IResolvable);
    resetBypassrls(): void;
    get bypassrlsInput(): boolean | cdktn.IResolvable | undefined;
    private _createdb?;
    get createdb(): boolean | cdktn.IResolvable;
    set createdb(value: boolean | cdktn.IResolvable);
    resetCreatedb(): void;
    get createdbInput(): boolean | cdktn.IResolvable | undefined;
    private _createrole?;
    get createrole(): boolean | cdktn.IResolvable;
    set createrole(value: boolean | cdktn.IResolvable);
    resetCreaterole(): void;
    get createroleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PostgresRoleStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#attributes PostgresRole#attributes}
    */
    readonly attributes?: PostgresRoleStatusAttributes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#auth_method PostgresRole#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#identity_type PostgresRole#identity_type}
    */
    readonly identityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#membership_roles PostgresRole#membership_roles}
    */
    readonly membershipRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#postgres_role PostgresRole#postgres_role}
    */
    readonly postgresRole?: string;
}
export declare function postgresRoleStatusToTerraform(struct?: PostgresRoleStatus): any;
export declare function postgresRoleStatusToHclTerraform(struct?: PostgresRoleStatus): any;
export declare class PostgresRoleStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresRoleStatus | undefined;
    set internalValue(value: PostgresRoleStatus | undefined);
    private _attributes;
    get attributes(): PostgresRoleStatusAttributesOutputReference;
    putAttributes(value: PostgresRoleStatusAttributes): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | PostgresRoleStatusAttributes | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _membershipRoles?;
    get membershipRoles(): string[];
    set membershipRoles(value: string[]);
    resetMembershipRoles(): void;
    get membershipRolesInput(): string[] | undefined;
    private _postgresRole?;
    get postgresRole(): string;
    set postgresRole(value: string);
    resetPostgresRole(): void;
    get postgresRoleInput(): string | undefined;
    get roleId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role databricks_postgres_role}
*/
export declare class PostgresRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_role";
    /**
    * Generates CDKTN code for importing a PostgresRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresRole to import
    * @param importFromId The id of the existing PostgresRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.125.0/docs/resources/postgres_role databricks_postgres_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresRoleConfig
    */
    constructor(scope: Construct, id: string, config: PostgresRoleConfig);
    get createTime(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresRoleProviderConfigOutputReference;
    putProviderConfig(value: PostgresRoleProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresRoleProviderConfig | undefined;
    private _replaceExisting?;
    get replaceExisting(): boolean | cdktn.IResolvable;
    set replaceExisting(value: boolean | cdktn.IResolvable);
    resetReplaceExisting(): void;
    get replaceExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    resetRoleId(): void;
    get roleIdInput(): string | undefined;
    private _spec;
    get spec(): PostgresRoleSpecOutputReference;
    putSpec(value: PostgresRoleSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresRoleSpec | undefined;
    private _status;
    get status(): PostgresRoleStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
