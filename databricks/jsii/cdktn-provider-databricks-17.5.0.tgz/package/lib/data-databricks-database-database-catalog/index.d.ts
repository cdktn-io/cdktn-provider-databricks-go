/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDatabaseDatabaseCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/database_database_catalog#name DataDatabricksDatabaseDatabaseCatalog#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/database_database_catalog#provider_config DataDatabricksDatabaseDatabaseCatalog#provider_config}
    */
    readonly providerConfig?: DataDatabricksDatabaseDatabaseCatalogProviderConfig;
}
export interface DataDatabricksDatabaseDatabaseCatalogProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/database_database_catalog#workspace_id DataDatabricksDatabaseDatabaseCatalog#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDatabaseDatabaseCatalogProviderConfigToTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseDatabaseCatalogProviderConfigToHclTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseDatabaseCatalogProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/database_database_catalog databricks_database_database_catalog}
*/
export declare class DataDatabricksDatabaseDatabaseCatalog extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_database_database_catalog";
    /**
    * Generates CDKTN code for importing a DataDatabricksDatabaseDatabaseCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDatabaseDatabaseCatalog to import
    * @param importFromId The id of the existing DataDatabricksDatabaseDatabaseCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/database_database_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDatabaseDatabaseCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/database_database_catalog databricks_database_database_catalog} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDatabaseDatabaseCatalogConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDatabaseDatabaseCatalogConfig);
    get createDatabaseIfNotExists(): cdktn.IResolvable;
    get databaseInstanceName(): string;
    get databaseName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDatabaseDatabaseCatalogProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDatabaseDatabaseCatalogProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDatabaseDatabaseCatalogProviderConfig | undefined;
    get uid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
