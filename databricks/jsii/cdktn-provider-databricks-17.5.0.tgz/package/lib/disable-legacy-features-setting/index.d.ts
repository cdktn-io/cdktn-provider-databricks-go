/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DisableLegacyFeaturesSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#etag DisableLegacyFeaturesSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#id DisableLegacyFeaturesSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#setting_name DisableLegacyFeaturesSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * disable_legacy_features block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#disable_legacy_features DisableLegacyFeaturesSetting#disable_legacy_features}
    */
    readonly disableLegacyFeatures: DisableLegacyFeaturesSettingDisableLegacyFeatures;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#provider_config DisableLegacyFeaturesSetting#provider_config}
    */
    readonly providerConfig?: DisableLegacyFeaturesSettingProviderConfig;
}
export interface DisableLegacyFeaturesSettingDisableLegacyFeatures {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#value DisableLegacyFeaturesSetting#value}
    */
    readonly value: boolean | cdktn.IResolvable;
}
export declare function disableLegacyFeaturesSettingDisableLegacyFeaturesToTerraform(struct?: DisableLegacyFeaturesSettingDisableLegacyFeaturesOutputReference | DisableLegacyFeaturesSettingDisableLegacyFeatures): any;
export declare function disableLegacyFeaturesSettingDisableLegacyFeaturesToHclTerraform(struct?: DisableLegacyFeaturesSettingDisableLegacyFeaturesOutputReference | DisableLegacyFeaturesSettingDisableLegacyFeatures): any;
export declare class DisableLegacyFeaturesSettingDisableLegacyFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisableLegacyFeaturesSettingDisableLegacyFeatures | undefined;
    set internalValue(value: DisableLegacyFeaturesSettingDisableLegacyFeatures | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DisableLegacyFeaturesSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#workspace_id DisableLegacyFeaturesSetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function disableLegacyFeaturesSettingProviderConfigToTerraform(struct?: DisableLegacyFeaturesSettingProviderConfigOutputReference | DisableLegacyFeaturesSettingProviderConfig): any;
export declare function disableLegacyFeaturesSettingProviderConfigToHclTerraform(struct?: DisableLegacyFeaturesSettingProviderConfigOutputReference | DisableLegacyFeaturesSettingProviderConfig): any;
export declare class DisableLegacyFeaturesSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisableLegacyFeaturesSettingProviderConfig | undefined;
    set internalValue(value: DisableLegacyFeaturesSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting databricks_disable_legacy_features_setting}
*/
export declare class DisableLegacyFeaturesSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_disable_legacy_features_setting";
    /**
    * Generates CDKTN code for importing a DisableLegacyFeaturesSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisableLegacyFeaturesSetting to import
    * @param importFromId The id of the existing DisableLegacyFeaturesSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisableLegacyFeaturesSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/disable_legacy_features_setting databricks_disable_legacy_features_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisableLegacyFeaturesSettingConfig
    */
    constructor(scope: Construct, id: string, config: DisableLegacyFeaturesSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _disableLegacyFeatures;
    get disableLegacyFeatures(): DisableLegacyFeaturesSettingDisableLegacyFeaturesOutputReference;
    putDisableLegacyFeatures(value: DisableLegacyFeaturesSettingDisableLegacyFeatures): void;
    get disableLegacyFeaturesInput(): DisableLegacyFeaturesSettingDisableLegacyFeatures | undefined;
    private _providerConfig;
    get providerConfig(): DisableLegacyFeaturesSettingProviderConfigOutputReference;
    putProviderConfig(value: DisableLegacyFeaturesSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DisableLegacyFeaturesSettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
