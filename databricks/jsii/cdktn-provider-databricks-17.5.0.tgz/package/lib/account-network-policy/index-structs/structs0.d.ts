/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ids AccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function accountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsOutputReference;
}
export interface AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#internet_destination_type AccountNetworkPolicy#internet_destination_type}
    */
    readonly internetDestinationType?: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _internetDestinationType?;
    get internetDestinationType(): string;
    set internetDestinationType(value: string);
    resetInternetDestinationType(): void;
    get internetDestinationTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsOutputReference;
}
export interface AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#azure_storage_account AccountNetworkPolicy#azure_storage_account}
    */
    readonly azureStorageAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#azure_storage_service AccountNetworkPolicy#azure_storage_service}
    */
    readonly azureStorageService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#bucket_name AccountNetworkPolicy#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#region AccountNetworkPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#storage_destination_type AccountNetworkPolicy#storage_destination_type}
    */
    readonly storageDestinationType?: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined);
    private _azureStorageAccount?;
    get azureStorageAccount(): string;
    set azureStorageAccount(value: string);
    resetAzureStorageAccount(): void;
    get azureStorageAccountInput(): string | undefined;
    private _azureStorageService?;
    get azureStorageService(): string;
    set azureStorageService(value: string);
    resetAzureStorageService(): void;
    get azureStorageServiceInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageDestinationType?;
    get storageDestinationType(): string;
    set storageDestinationType(value: string);
    resetStorageDestinationType(): void;
    get storageDestinationTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsOutputReference;
}
export interface AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#internet_destination_type AccountNetworkPolicy#internet_destination_type}
    */
    readonly internetDestinationType?: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _internetDestinationType?;
    get internetDestinationType(): string;
    set internetDestinationType(value: string);
    resetInternetDestinationType(): void;
    get internetDestinationTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsOutputReference;
}
export interface AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#dry_run_mode_product_filter AccountNetworkPolicy#dry_run_mode_product_filter}
    */
    readonly dryRunModeProductFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#enforcement_mode AccountNetworkPolicy#enforcement_mode}
    */
    readonly enforcementMode?: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessPolicyEnforcementToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessPolicyEnforcementToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessPolicyEnforcementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined);
    private _dryRunModeProductFilter?;
    get dryRunModeProductFilter(): string[];
    set dryRunModeProductFilter(value: string[]);
    resetDryRunModeProductFilter(): void;
    get dryRunModeProductFilterInput(): string[] | undefined;
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    resetEnforcementMode(): void;
    get enforcementModeInput(): string | undefined;
}
export interface AccountNetworkPolicyEgressNetworkAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allowed_databricks_destinations AccountNetworkPolicy#allowed_databricks_destinations}
    */
    readonly allowedDatabricksDestinations?: AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allowed_internet_destinations AccountNetworkPolicy#allowed_internet_destinations}
    */
    readonly allowedInternetDestinations?: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allowed_storage_destinations AccountNetworkPolicy#allowed_storage_destinations}
    */
    readonly allowedStorageDestinations?: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#blocked_internet_destinations AccountNetworkPolicy#blocked_internet_destinations}
    */
    readonly blockedInternetDestinations?: AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#policy_enforcement AccountNetworkPolicy#policy_enforcement}
    */
    readonly policyEnforcement?: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyEgressNetworkAccessToTerraform(struct?: AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressNetworkAccessToHclTerraform(struct?: AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressNetworkAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable | undefined);
    private _allowedDatabricksDestinations;
    get allowedDatabricksDestinations(): AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsList;
    putAllowedDatabricksDestinations(value: AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | cdktn.IResolvable): void;
    resetAllowedDatabricksDestinations(): void;
    get allowedDatabricksDestinationsInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | undefined;
    private _allowedInternetDestinations;
    get allowedInternetDestinations(): AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsList;
    putAllowedInternetDestinations(value: AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable): void;
    resetAllowedInternetDestinations(): void;
    get allowedInternetDestinationsInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | undefined;
    private _allowedStorageDestinations;
    get allowedStorageDestinations(): AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsList;
    putAllowedStorageDestinations(value: AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable): void;
    resetAllowedStorageDestinations(): void;
    get allowedStorageDestinationsInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | undefined;
    private _blockedInternetDestinations;
    get blockedInternetDestinations(): AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsList;
    putBlockedInternetDestinations(value: AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable): void;
    resetBlockedInternetDestinations(): void;
    get blockedInternetDestinationsInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | undefined;
    private _policyEnforcement;
    get policyEnforcement(): AccountNetworkPolicyEgressNetworkAccessPolicyEnforcementOutputReference;
    putPolicyEnforcement(value: AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement): void;
    resetPolicyEnforcement(): void;
    get policyEnforcementInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyEgress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#network_access AccountNetworkPolicy#network_access}
    */
    readonly networkAccess?: AccountNetworkPolicyEgressNetworkAccess;
}
export declare function accountNetworkPolicyEgressToTerraform(struct?: AccountNetworkPolicyEgress | cdktn.IResolvable): any;
export declare function accountNetworkPolicyEgressToHclTerraform(struct?: AccountNetworkPolicyEgress | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyEgress | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyEgress | cdktn.IResolvable | undefined);
    private _networkAccess;
    get networkAccess(): AccountNetworkPolicyEgressNetworkAccessOutputReference;
    putNetworkAccess(value: AccountNetworkPolicyEgressNetworkAccess): void;
    resetNetworkAccess(): void;
    get networkAccessInput(): cdktn.IResolvable | AccountNetworkPolicyEgressNetworkAccess | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ids AccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_source_workspaces AccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#selected_workspaces AccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ids AccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_source_workspaces AccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#selected_workspaces AccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | undefined;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressCrossWorkspaceAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessToTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressCrossWorkspaceAccessToHclTerraform(struct?: AccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressCrossWorkspaceAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoint_ids AccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_private_access AccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_registered_endpoints AccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#azure_workspace_private_link AccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoints AccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsOutputReference;
    putEndpoints(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressPrivateAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressPrivateAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPrivateAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoint_ids AccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_private_access AccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_registered_endpoints AccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#azure_workspace_private_link AccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoints AccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsOutputReference;
    putEndpoints(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | undefined;
}
export interface AccountNetworkPolicyIngressPrivateAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressPrivateAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressPrivateAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPrivateAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressPrivateAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressPrivateAccessToTerraform(struct?: AccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPrivateAccessToHclTerraform(struct?: AccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPrivateAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressPrivateAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressPrivateAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressPrivateAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressPrivateAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
export interface AccountNetworkPolicyIngressPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressPublicAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressPublicAccessToTerraform(struct?: AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressPublicAccessToHclTerraform(struct?: AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressPublicAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressPublicAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#cross_workspace_access AccountNetworkPolicy#cross_workspace_access}
    */
    readonly crossWorkspaceAccess?: AccountNetworkPolicyIngressCrossWorkspaceAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#private_access AccountNetworkPolicy#private_access}
    */
    readonly privateAccess?: AccountNetworkPolicyIngressPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#public_access AccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: AccountNetworkPolicyIngressPublicAccess;
}
export declare function accountNetworkPolicyIngressToTerraform(struct?: AccountNetworkPolicyIngress | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressToHclTerraform(struct?: AccountNetworkPolicyIngress | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngress | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngress | cdktn.IResolvable | undefined);
    private _crossWorkspaceAccess;
    get crossWorkspaceAccess(): AccountNetworkPolicyIngressCrossWorkspaceAccessOutputReference;
    putCrossWorkspaceAccess(value: AccountNetworkPolicyIngressCrossWorkspaceAccess): void;
    resetCrossWorkspaceAccess(): void;
    get crossWorkspaceAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressCrossWorkspaceAccess | undefined;
    private _privateAccess;
    get privateAccess(): AccountNetworkPolicyIngressPrivateAccessOutputReference;
    putPrivateAccess(value: AccountNetworkPolicyIngressPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): AccountNetworkPolicyIngressPublicAccessOutputReference;
    putPublicAccess(value: AccountNetworkPolicyIngressPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressPublicAccess | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ids AccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_source_workspaces AccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#selected_workspaces AccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ids AccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_source_workspaces AccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#selected_workspaces AccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | undefined;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessToTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunCrossWorkspaceAccessToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoint_ids AccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_private_access AccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_registered_endpoints AccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#azure_workspace_private_link AccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoints AccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsOutputReference;
    putEndpoints(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoint_ids AccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_private_access AccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_registered_endpoints AccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#azure_workspace_private_link AccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#endpoints AccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsOutputReference;
    putEndpoints(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPrivateAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressDryRunPrivateAccessToTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPrivateAccessToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPrivateAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessAllowRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_id AccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#principal_type AccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identities AccountNetworkPolicy#identities}
    */
    readonly identities?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#identity_type AccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scope_qualifier AccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#scopes AccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_api AccountNetworkPolicy#account_api}
    */
    readonly accountApi?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_databricks_one AccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#account_ui AccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_destinations AccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#apps_runtime AccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#lakebase_runtime AccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_api AccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#workspace_ui AccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#ip_ranges AccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#all_ip_ranges AccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#excluded_ip_ranges AccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/account_network_policy#included_ip_ranges AccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
