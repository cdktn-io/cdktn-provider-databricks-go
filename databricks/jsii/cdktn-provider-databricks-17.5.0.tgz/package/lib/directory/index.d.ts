/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory#delete_recursive Directory#delete_recursive}
    */
    readonly deleteRecursive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory#id Directory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory#object_id Directory#object_id}
    */
    readonly objectId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory#path Directory#path}
    */
    readonly path: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory#provider_config Directory#provider_config}
    */
    readonly providerConfig?: DirectoryProviderConfig;
}
export interface DirectoryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory#workspace_id Directory#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function directoryProviderConfigToTerraform(struct?: DirectoryProviderConfigOutputReference | DirectoryProviderConfig): any;
export declare function directoryProviderConfigToHclTerraform(struct?: DirectoryProviderConfigOutputReference | DirectoryProviderConfig): any;
export declare class DirectoryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectoryProviderConfig | undefined;
    set internalValue(value: DirectoryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory databricks_directory}
*/
export declare class Directory extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_directory";
    /**
    * Generates CDKTN code for importing a Directory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Directory to import
    * @param importFromId The id of the existing Directory that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Directory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/directory databricks_directory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectoryConfig
    */
    constructor(scope: Construct, id: string, config: DirectoryConfig);
    private _deleteRecursive?;
    get deleteRecursive(): boolean | cdktn.IResolvable;
    set deleteRecursive(value: boolean | cdktn.IResolvable);
    resetDeleteRecursive(): void;
    get deleteRecursiveInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): number;
    set objectId(value: number);
    resetObjectId(): void;
    get objectIdInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    get workspacePath(): string;
    private _providerConfig;
    get providerConfig(): DirectoryProviderConfigOutputReference;
    putProviderConfig(value: DirectoryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DirectoryProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
