/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceNetworkOptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_network_option#network_policy_id WorkspaceNetworkOption#network_policy_id}
    */
    readonly networkPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_network_option#workspace_id WorkspaceNetworkOption#workspace_id}
    */
    readonly workspaceId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_network_option databricks_workspace_network_option}
*/
export declare class WorkspaceNetworkOption extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_network_option";
    /**
    * Generates CDKTN code for importing a WorkspaceNetworkOption resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceNetworkOption to import
    * @param importFromId The id of the existing WorkspaceNetworkOption that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_network_option#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceNetworkOption to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_network_option databricks_workspace_network_option} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceNetworkOptionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: WorkspaceNetworkOptionConfig);
    private _networkPolicyId?;
    get networkPolicyId(): string;
    set networkPolicyId(value: string);
    resetNetworkPolicyId(): void;
    get networkPolicyIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    resetWorkspaceId(): void;
    get workspaceIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
