/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SqlEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#auto_stop_mins SqlEndpoint#auto_stop_mins}
    */
    readonly autoStopMins?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#cluster_size SqlEndpoint#cluster_size}
    */
    readonly clusterSize: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#data_source_id SqlEndpoint#data_source_id}
    */
    readonly dataSourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#enable_photon SqlEndpoint#enable_photon}
    */
    readonly enablePhoton?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#enable_serverless_compute SqlEndpoint#enable_serverless_compute}
    */
    readonly enableServerlessCompute?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#id SqlEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#instance_profile_arn SqlEndpoint#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#max_num_clusters SqlEndpoint#max_num_clusters}
    */
    readonly maxNumClusters?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#min_num_clusters SqlEndpoint#min_num_clusters}
    */
    readonly minNumClusters?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#name SqlEndpoint#name}
    */
    readonly name: string;
    /**
    * If true, skip waiting for the warehouse to start after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#no_wait SqlEndpoint#no_wait}
    */
    readonly noWait?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#spot_instance_policy SqlEndpoint#spot_instance_policy}
    */
    readonly spotInstancePolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#warehouse_type SqlEndpoint#warehouse_type}
    */
    readonly warehouseType?: string;
    /**
    * channel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#channel SqlEndpoint#channel}
    */
    readonly channel?: SqlEndpointChannel;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#provider_config SqlEndpoint#provider_config}
    */
    readonly providerConfig?: SqlEndpointProviderConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#tags SqlEndpoint#tags}
    */
    readonly tags?: SqlEndpointTags;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#timeouts SqlEndpoint#timeouts}
    */
    readonly timeouts?: SqlEndpointTimeouts;
}
export interface SqlEndpointHealthFailureReason {
}
export declare function sqlEndpointHealthFailureReasonToTerraform(struct?: SqlEndpointHealthFailureReason): any;
export declare function sqlEndpointHealthFailureReasonToHclTerraform(struct?: SqlEndpointHealthFailureReason): any;
export declare class SqlEndpointHealthFailureReasonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SqlEndpointHealthFailureReason | undefined;
    set internalValue(value: SqlEndpointHealthFailureReason | undefined);
    get code(): string;
    private _parameters;
    get parameters(): cdktn.StringMap;
    get type(): string;
}
export declare class SqlEndpointHealthFailureReasonList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SqlEndpointHealthFailureReasonOutputReference;
}
export interface SqlEndpointHealth {
}
export declare function sqlEndpointHealthToTerraform(struct?: SqlEndpointHealth): any;
export declare function sqlEndpointHealthToHclTerraform(struct?: SqlEndpointHealth): any;
export declare class SqlEndpointHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SqlEndpointHealth | undefined;
    set internalValue(value: SqlEndpointHealth | undefined);
    get details(): string;
    private _failureReason;
    get failureReason(): SqlEndpointHealthFailureReasonList;
    get message(): string;
    get status(): string;
    get summary(): string;
}
export declare class SqlEndpointHealthList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SqlEndpointHealthOutputReference;
}
export interface SqlEndpointOdbcParams {
}
export declare function sqlEndpointOdbcParamsToTerraform(struct?: SqlEndpointOdbcParams): any;
export declare function sqlEndpointOdbcParamsToHclTerraform(struct?: SqlEndpointOdbcParams): any;
export declare class SqlEndpointOdbcParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SqlEndpointOdbcParams | undefined;
    set internalValue(value: SqlEndpointOdbcParams | undefined);
    get hostname(): string;
    get path(): string;
    get port(): number;
    get protocol(): string;
}
export declare class SqlEndpointOdbcParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SqlEndpointOdbcParamsOutputReference;
}
export interface SqlEndpointChannel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#dbsql_version SqlEndpoint#dbsql_version}
    */
    readonly dbsqlVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#name SqlEndpoint#name}
    */
    readonly name?: string;
}
export declare function sqlEndpointChannelToTerraform(struct?: SqlEndpointChannelOutputReference | SqlEndpointChannel): any;
export declare function sqlEndpointChannelToHclTerraform(struct?: SqlEndpointChannelOutputReference | SqlEndpointChannel): any;
export declare class SqlEndpointChannelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlEndpointChannel | undefined;
    set internalValue(value: SqlEndpointChannel | undefined);
    private _dbsqlVersion?;
    get dbsqlVersion(): string;
    set dbsqlVersion(value: string);
    resetDbsqlVersion(): void;
    get dbsqlVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface SqlEndpointProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#workspace_id SqlEndpoint#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function sqlEndpointProviderConfigToTerraform(struct?: SqlEndpointProviderConfigOutputReference | SqlEndpointProviderConfig): any;
export declare function sqlEndpointProviderConfigToHclTerraform(struct?: SqlEndpointProviderConfigOutputReference | SqlEndpointProviderConfig): any;
export declare class SqlEndpointProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlEndpointProviderConfig | undefined;
    set internalValue(value: SqlEndpointProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface SqlEndpointTagsCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#key SqlEndpoint#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#value SqlEndpoint#value}
    */
    readonly value: string;
}
export declare function sqlEndpointTagsCustomTagsToTerraform(struct?: SqlEndpointTagsCustomTags | cdktn.IResolvable): any;
export declare function sqlEndpointTagsCustomTagsToHclTerraform(struct?: SqlEndpointTagsCustomTags | cdktn.IResolvable): any;
export declare class SqlEndpointTagsCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SqlEndpointTagsCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: SqlEndpointTagsCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SqlEndpointTagsCustomTagsList extends cdktn.ComplexList {
    internalValue?: SqlEndpointTagsCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SqlEndpointTagsCustomTagsOutputReference;
}
export interface SqlEndpointTags {
    /**
    * custom_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#custom_tags SqlEndpoint#custom_tags}
    */
    readonly customTags?: SqlEndpointTagsCustomTags[] | cdktn.IResolvable;
}
export declare function sqlEndpointTagsToTerraform(struct?: SqlEndpointTagsOutputReference | SqlEndpointTags): any;
export declare function sqlEndpointTagsToHclTerraform(struct?: SqlEndpointTagsOutputReference | SqlEndpointTags): any;
export declare class SqlEndpointTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlEndpointTags | undefined;
    set internalValue(value: SqlEndpointTags | undefined);
    private _customTags;
    get customTags(): SqlEndpointTagsCustomTagsList;
    putCustomTags(value: SqlEndpointTagsCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | SqlEndpointTagsCustomTags[] | undefined;
}
export interface SqlEndpointTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#create SqlEndpoint#create}
    */
    readonly create?: string;
}
export declare function sqlEndpointTimeoutsToTerraform(struct?: SqlEndpointTimeouts | cdktn.IResolvable): any;
export declare function sqlEndpointTimeoutsToHclTerraform(struct?: SqlEndpointTimeouts | cdktn.IResolvable): any;
export declare class SqlEndpointTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlEndpointTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: SqlEndpointTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint databricks_sql_endpoint}
*/
export declare class SqlEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sql_endpoint";
    /**
    * Generates CDKTN code for importing a SqlEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlEndpoint to import
    * @param importFromId The id of the existing SqlEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_endpoint databricks_sql_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlEndpointConfig
    */
    constructor(scope: Construct, id: string, config: SqlEndpointConfig);
    private _autoStopMins?;
    get autoStopMins(): number;
    set autoStopMins(value: number);
    resetAutoStopMins(): void;
    get autoStopMinsInput(): number | undefined;
    private _clusterSize?;
    get clusterSize(): string;
    set clusterSize(value: string);
    get clusterSizeInput(): string | undefined;
    get creatorName(): string;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    resetDataSourceId(): void;
    get dataSourceIdInput(): string | undefined;
    private _enablePhoton?;
    get enablePhoton(): boolean | cdktn.IResolvable;
    set enablePhoton(value: boolean | cdktn.IResolvable);
    resetEnablePhoton(): void;
    get enablePhotonInput(): boolean | cdktn.IResolvable | undefined;
    private _enableServerlessCompute?;
    get enableServerlessCompute(): boolean | cdktn.IResolvable;
    set enableServerlessCompute(value: boolean | cdktn.IResolvable);
    resetEnableServerlessCompute(): void;
    get enableServerlessComputeInput(): boolean | cdktn.IResolvable | undefined;
    private _health;
    get health(): SqlEndpointHealthList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    get jdbcUrl(): string;
    private _maxNumClusters?;
    get maxNumClusters(): number;
    set maxNumClusters(value: number);
    resetMaxNumClusters(): void;
    get maxNumClustersInput(): number | undefined;
    private _minNumClusters?;
    get minNumClusters(): number;
    set minNumClusters(value: number);
    resetMinNumClusters(): void;
    get minNumClustersInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _noWait?;
    get noWait(): boolean | cdktn.IResolvable;
    set noWait(value: boolean | cdktn.IResolvable);
    resetNoWait(): void;
    get noWaitInput(): boolean | cdktn.IResolvable | undefined;
    get numActiveSessions(): number;
    get numClusters(): number;
    private _odbcParams;
    get odbcParams(): SqlEndpointOdbcParamsList;
    private _spotInstancePolicy?;
    get spotInstancePolicy(): string;
    set spotInstancePolicy(value: string);
    resetSpotInstancePolicy(): void;
    get spotInstancePolicyInput(): string | undefined;
    get state(): string;
    private _warehouseType?;
    get warehouseType(): string;
    set warehouseType(value: string);
    resetWarehouseType(): void;
    get warehouseTypeInput(): string | undefined;
    private _channel;
    get channel(): SqlEndpointChannelOutputReference;
    putChannel(value: SqlEndpointChannel): void;
    resetChannel(): void;
    get channelInput(): SqlEndpointChannel | undefined;
    private _providerConfig;
    get providerConfig(): SqlEndpointProviderConfigOutputReference;
    putProviderConfig(value: SqlEndpointProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SqlEndpointProviderConfig | undefined;
    private _tags;
    get tags(): SqlEndpointTagsOutputReference;
    putTags(value: SqlEndpointTags): void;
    resetTags(): void;
    get tagsInput(): SqlEndpointTags | undefined;
    private _timeouts;
    get timeouts(): SqlEndpointTimeoutsOutputReference;
    putTimeouts(value: SqlEndpointTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | SqlEndpointTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
