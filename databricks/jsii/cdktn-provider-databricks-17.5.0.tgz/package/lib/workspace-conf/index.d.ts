/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceConfConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_conf#custom_config WorkspaceConf#custom_config}
    */
    readonly customConfig?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_conf#id WorkspaceConf#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_conf#provider_config WorkspaceConf#provider_config}
    */
    readonly providerConfig?: WorkspaceConfProviderConfig;
}
export interface WorkspaceConfProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_conf#workspace_id WorkspaceConf#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceConfProviderConfigToTerraform(struct?: WorkspaceConfProviderConfigOutputReference | WorkspaceConfProviderConfig): any;
export declare function workspaceConfProviderConfigToHclTerraform(struct?: WorkspaceConfProviderConfigOutputReference | WorkspaceConfProviderConfig): any;
export declare class WorkspaceConfProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceConfProviderConfig | undefined;
    set internalValue(value: WorkspaceConfProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_conf databricks_workspace_conf}
*/
export declare class WorkspaceConf extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_conf";
    /**
    * Generates CDKTN code for importing a WorkspaceConf resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceConf to import
    * @param importFromId The id of the existing WorkspaceConf that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_conf#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceConf to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/workspace_conf databricks_workspace_conf} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceConfConfig = {}
    */
    constructor(scope: Construct, id: string, config?: WorkspaceConfConfig);
    private _customConfig?;
    get customConfig(): {
        [key: string]: string;
    };
    set customConfig(value: {
        [key: string]: string;
    });
    resetCustomConfig(): void;
    get customConfigInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): WorkspaceConfProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceConfProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): WorkspaceConfProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
