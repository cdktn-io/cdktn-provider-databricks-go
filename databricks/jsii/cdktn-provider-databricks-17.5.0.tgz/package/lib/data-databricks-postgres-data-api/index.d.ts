/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresDataApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#name DataDatabricksPostgresDataApi#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#provider_config DataDatabricksPostgresDataApi#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresDataApiProviderConfig;
}
export interface DataDatabricksPostgresDataApiProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#workspace_id DataDatabricksPostgresDataApi#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresDataApiProviderConfigToTerraform(struct?: DataDatabricksPostgresDataApiProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresDataApiProviderConfigToHclTerraform(struct?: DataDatabricksPostgresDataApiProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresDataApiProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDataApiProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresDataApiProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresDataApiSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#db_aggregates_enabled DataDatabricksPostgresDataApi#db_aggregates_enabled}
    */
    readonly dbAggregatesEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#db_extra_search_path DataDatabricksPostgresDataApi#db_extra_search_path}
    */
    readonly dbExtraSearchPath?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#db_max_rows DataDatabricksPostgresDataApi#db_max_rows}
    */
    readonly dbMaxRows?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#db_schemas DataDatabricksPostgresDataApi#db_schemas}
    */
    readonly dbSchemas?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#jwt_cache_max_lifetime DataDatabricksPostgresDataApi#jwt_cache_max_lifetime}
    */
    readonly jwtCacheMaxLifetime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#jwt_role_claim_key DataDatabricksPostgresDataApi#jwt_role_claim_key}
    */
    readonly jwtRoleClaimKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#openapi_mode DataDatabricksPostgresDataApi#openapi_mode}
    */
    readonly openapiMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#server_cors_allowed_origins DataDatabricksPostgresDataApi#server_cors_allowed_origins}
    */
    readonly serverCorsAllowedOrigins?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#server_timing_enabled DataDatabricksPostgresDataApi#server_timing_enabled}
    */
    readonly serverTimingEnabled?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresDataApiSpecToTerraform(struct?: DataDatabricksPostgresDataApiSpec): any;
export declare function dataDatabricksPostgresDataApiSpecToHclTerraform(struct?: DataDatabricksPostgresDataApiSpec): any;
export declare class DataDatabricksPostgresDataApiSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDataApiSpec | undefined;
    set internalValue(value: DataDatabricksPostgresDataApiSpec | undefined);
    private _dbAggregatesEnabled?;
    get dbAggregatesEnabled(): boolean | cdktn.IResolvable;
    set dbAggregatesEnabled(value: boolean | cdktn.IResolvable);
    resetDbAggregatesEnabled(): void;
    get dbAggregatesEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _dbExtraSearchPath?;
    get dbExtraSearchPath(): string[];
    set dbExtraSearchPath(value: string[]);
    resetDbExtraSearchPath(): void;
    get dbExtraSearchPathInput(): string[] | undefined;
    private _dbMaxRows?;
    get dbMaxRows(): number;
    set dbMaxRows(value: number);
    resetDbMaxRows(): void;
    get dbMaxRowsInput(): number | undefined;
    private _dbSchemas?;
    get dbSchemas(): string[];
    set dbSchemas(value: string[]);
    resetDbSchemas(): void;
    get dbSchemasInput(): string[] | undefined;
    private _jwtCacheMaxLifetime?;
    get jwtCacheMaxLifetime(): string;
    set jwtCacheMaxLifetime(value: string);
    resetJwtCacheMaxLifetime(): void;
    get jwtCacheMaxLifetimeInput(): string | undefined;
    private _jwtRoleClaimKey?;
    get jwtRoleClaimKey(): string;
    set jwtRoleClaimKey(value: string);
    resetJwtRoleClaimKey(): void;
    get jwtRoleClaimKeyInput(): string | undefined;
    private _openapiMode?;
    get openapiMode(): string;
    set openapiMode(value: string);
    resetOpenapiMode(): void;
    get openapiModeInput(): string | undefined;
    private _serverCorsAllowedOrigins?;
    get serverCorsAllowedOrigins(): string[];
    set serverCorsAllowedOrigins(value: string[]);
    resetServerCorsAllowedOrigins(): void;
    get serverCorsAllowedOriginsInput(): string[] | undefined;
    private _serverTimingEnabled?;
    get serverTimingEnabled(): boolean | cdktn.IResolvable;
    set serverTimingEnabled(value: boolean | cdktn.IResolvable);
    resetServerTimingEnabled(): void;
    get serverTimingEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksPostgresDataApiStatus {
}
export declare function dataDatabricksPostgresDataApiStatusToTerraform(struct?: DataDatabricksPostgresDataApiStatus): any;
export declare function dataDatabricksPostgresDataApiStatusToHclTerraform(struct?: DataDatabricksPostgresDataApiStatus): any;
export declare class DataDatabricksPostgresDataApiStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDataApiStatus | undefined;
    set internalValue(value: DataDatabricksPostgresDataApiStatus | undefined);
    get availableSchemas(): string[];
    get dbAggregatesEnabled(): cdktn.IResolvable;
    get dbExtraSearchPath(): string[];
    get dbMaxRows(): number;
    get dbSchemas(): string[];
    get jwtCacheMaxLifetime(): string;
    get jwtRoleClaimKey(): string;
    get openapiMode(): string;
    get serverCorsAllowedOrigins(): string[];
    get serverTimingEnabled(): cdktn.IResolvable;
    get url(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api databricks_postgres_data_api}
*/
export declare class DataDatabricksPostgresDataApi extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_data_api";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresDataApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresDataApi to import
    * @param importFromId The id of the existing DataDatabricksPostgresDataApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresDataApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/postgres_data_api databricks_postgres_data_api} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresDataApiConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresDataApiConfig);
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresDataApiProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresDataApiProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresDataApiProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresDataApiSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresDataApiStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
