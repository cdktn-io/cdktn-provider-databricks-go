/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiSearchIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#name DataDatabricksAiSearchIndex#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#provider_config DataDatabricksAiSearchIndex#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiSearchIndexProviderConfig;
}
export interface DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_model_endpoint DataDatabricksAiSearchIndex#embedding_model_endpoint}
    */
    readonly embeddingModelEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#model_endpoint_name_for_query DataDatabricksAiSearchIndex#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#name DataDatabricksAiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsToTerraform(struct?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpoint?;
    get embeddingModelEndpoint(): string;
    set embeddingModelEndpoint(value: string);
    resetEmbeddingModelEndpoint(): void;
    get embeddingModelEndpointInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_dimension DataDatabricksAiSearchIndex#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#name DataDatabricksAiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsToTerraform(struct?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexDeltaSyncIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#columns_to_sync DataDatabricksAiSearchIndex#columns_to_sync}
    */
    readonly columnsToSync?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_source_columns DataDatabricksAiSearchIndex#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_vector_columns DataDatabricksAiSearchIndex#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_writeback_table DataDatabricksAiSearchIndex#embedding_writeback_table}
    */
    readonly embeddingWritebackTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#pipeline_type DataDatabricksAiSearchIndex#pipeline_type}
    */
    readonly pipelineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#source_table DataDatabricksAiSearchIndex#source_table}
    */
    readonly sourceTable?: string;
}
export declare function dataDatabricksAiSearchIndexDeltaSyncIndexSpecToTerraform(struct?: DataDatabricksAiSearchIndexDeltaSyncIndexSpec): any;
export declare function dataDatabricksAiSearchIndexDeltaSyncIndexSpecToHclTerraform(struct?: DataDatabricksAiSearchIndexDeltaSyncIndexSpec): any;
export declare class DataDatabricksAiSearchIndexDeltaSyncIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexDeltaSyncIndexSpec | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexDeltaSyncIndexSpec | undefined);
    private _columnsToSync?;
    get columnsToSync(): string[];
    set columnsToSync(value: string[]);
    resetColumnsToSync(): void;
    get columnsToSyncInput(): string[] | undefined;
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | undefined;
    private _embeddingWritebackTable?;
    get embeddingWritebackTable(): string;
    set embeddingWritebackTable(value: string);
    resetEmbeddingWritebackTable(): void;
    get embeddingWritebackTableInput(): string | undefined;
    get pipelineId(): string;
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    get pipelineTypeInput(): string | undefined;
    private _sourceTable?;
    get sourceTable(): string;
    set sourceTable(value: string);
    resetSourceTable(): void;
    get sourceTableInput(): string | undefined;
}
export interface DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_model_endpoint DataDatabricksAiSearchIndex#embedding_model_endpoint}
    */
    readonly embeddingModelEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#model_endpoint_name_for_query DataDatabricksAiSearchIndex#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#name DataDatabricksAiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsToTerraform(struct?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpoint?;
    get embeddingModelEndpoint(): string;
    set embeddingModelEndpoint(value: string);
    resetEmbeddingModelEndpoint(): void;
    get embeddingModelEndpointInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_dimension DataDatabricksAiSearchIndex#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#name DataDatabricksAiSearchIndex#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsToTerraform(struct?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexDirectAccessIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_source_columns DataDatabricksAiSearchIndex#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#embedding_vector_columns DataDatabricksAiSearchIndex#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#schema_json DataDatabricksAiSearchIndex#schema_json}
    */
    readonly schemaJson?: string;
}
export declare function dataDatabricksAiSearchIndexDirectAccessIndexSpecToTerraform(struct?: DataDatabricksAiSearchIndexDirectAccessIndexSpec): any;
export declare function dataDatabricksAiSearchIndexDirectAccessIndexSpecToHclTerraform(struct?: DataDatabricksAiSearchIndexDirectAccessIndexSpec): any;
export declare class DataDatabricksAiSearchIndexDirectAccessIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexDirectAccessIndexSpec | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexDirectAccessIndexSpec | undefined);
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | undefined;
    private _schemaJson?;
    get schemaJson(): string;
    set schemaJson(value: string);
    resetSchemaJson(): void;
    get schemaJsonInput(): string | undefined;
}
export interface DataDatabricksAiSearchIndexProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#workspace_id DataDatabricksAiSearchIndex#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiSearchIndexProviderConfigToTerraform(struct?: DataDatabricksAiSearchIndexProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexProviderConfigToHclTerraform(struct?: DataDatabricksAiSearchIndexProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAiSearchIndexStatus {
}
export declare function dataDatabricksAiSearchIndexStatusToTerraform(struct?: DataDatabricksAiSearchIndexStatus): any;
export declare function dataDatabricksAiSearchIndexStatusToHclTerraform(struct?: DataDatabricksAiSearchIndexStatus): any;
export declare class DataDatabricksAiSearchIndexStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexStatus | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexStatus | undefined);
    get indexUrl(): string;
    get indexedRowCount(): number;
    get message(): string;
    get ready(): cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index databricks_ai_search_index}
*/
export declare class DataDatabricksAiSearchIndex extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_search_index";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiSearchIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiSearchIndex to import
    * @param importFromId The id of the existing DataDatabricksAiSearchIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiSearchIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/data-sources/ai_search_index databricks_ai_search_index} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiSearchIndexConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAiSearchIndexConfig);
    get creator(): string;
    private _deltaSyncIndexSpec;
    get deltaSyncIndexSpec(): DataDatabricksAiSearchIndexDeltaSyncIndexSpecOutputReference;
    private _directAccessIndexSpec;
    get directAccessIndexSpec(): DataDatabricksAiSearchIndexDirectAccessIndexSpecOutputReference;
    get endpoint(): string;
    get indexSubtype(): string;
    get indexType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get primaryKey(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiSearchIndexProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiSearchIndexProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexProviderConfig | undefined;
    private _status;
    get status(): DataDatabricksAiSearchIndexStatusOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
