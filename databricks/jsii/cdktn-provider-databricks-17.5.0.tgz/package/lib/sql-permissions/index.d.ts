/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SqlPermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#anonymous_function SqlPermissions#anonymous_function}
    */
    readonly anonymousFunction?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#any_file SqlPermissions#any_file}
    */
    readonly anyFile?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#catalog SqlPermissions#catalog}
    */
    readonly catalog?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#cluster_id SqlPermissions#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#database SqlPermissions#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#id SqlPermissions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#table SqlPermissions#table}
    */
    readonly table?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#view SqlPermissions#view}
    */
    readonly view?: string;
    /**
    * privilege_assignments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#privilege_assignments SqlPermissions#privilege_assignments}
    */
    readonly privilegeAssignments?: SqlPermissionsPrivilegeAssignments[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#provider_config SqlPermissions#provider_config}
    */
    readonly providerConfig?: SqlPermissionsProviderConfig;
}
export interface SqlPermissionsPrivilegeAssignments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#principal SqlPermissions#principal}
    */
    readonly principal: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#privileges SqlPermissions#privileges}
    */
    readonly privileges: string[];
}
export declare function sqlPermissionsPrivilegeAssignmentsToTerraform(struct?: SqlPermissionsPrivilegeAssignments | cdktn.IResolvable): any;
export declare function sqlPermissionsPrivilegeAssignmentsToHclTerraform(struct?: SqlPermissionsPrivilegeAssignments | cdktn.IResolvable): any;
export declare class SqlPermissionsPrivilegeAssignmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SqlPermissionsPrivilegeAssignments | cdktn.IResolvable | undefined;
    set internalValue(value: SqlPermissionsPrivilegeAssignments | cdktn.IResolvable | undefined);
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
}
export declare class SqlPermissionsPrivilegeAssignmentsList extends cdktn.ComplexList {
    internalValue?: SqlPermissionsPrivilegeAssignments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SqlPermissionsPrivilegeAssignmentsOutputReference;
}
export interface SqlPermissionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#workspace_id SqlPermissions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function sqlPermissionsProviderConfigToTerraform(struct?: SqlPermissionsProviderConfigOutputReference | SqlPermissionsProviderConfig): any;
export declare function sqlPermissionsProviderConfigToHclTerraform(struct?: SqlPermissionsProviderConfigOutputReference | SqlPermissionsProviderConfig): any;
export declare class SqlPermissionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlPermissionsProviderConfig | undefined;
    set internalValue(value: SqlPermissionsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions databricks_sql_permissions}
*/
export declare class SqlPermissions extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sql_permissions";
    /**
    * Generates CDKTN code for importing a SqlPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlPermissions to import
    * @param importFromId The id of the existing SqlPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.120.0/docs/resources/sql_permissions databricks_sql_permissions} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlPermissionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: SqlPermissionsConfig);
    private _anonymousFunction?;
    get anonymousFunction(): boolean | cdktn.IResolvable;
    set anonymousFunction(value: boolean | cdktn.IResolvable);
    resetAnonymousFunction(): void;
    get anonymousFunctionInput(): boolean | cdktn.IResolvable | undefined;
    private _anyFile?;
    get anyFile(): boolean | cdktn.IResolvable;
    set anyFile(value: boolean | cdktn.IResolvable);
    resetAnyFile(): void;
    get anyFileInput(): boolean | cdktn.IResolvable | undefined;
    private _catalog?;
    get catalog(): boolean | cdktn.IResolvable;
    set catalog(value: boolean | cdktn.IResolvable);
    resetCatalog(): void;
    get catalogInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    resetTable(): void;
    get tableInput(): string | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    private _privilegeAssignments;
    get privilegeAssignments(): SqlPermissionsPrivilegeAssignmentsList;
    putPrivilegeAssignments(value: SqlPermissionsPrivilegeAssignments[] | cdktn.IResolvable): void;
    resetPrivilegeAssignments(): void;
    get privilegeAssignmentsInput(): cdktn.IResolvable | SqlPermissionsPrivilegeAssignments[] | undefined;
    private _providerConfig;
    get providerConfig(): SqlPermissionsProviderConfigOutputReference;
    putProviderConfig(value: SqlPermissionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SqlPermissionsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
