/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksInstanceProfilesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#id DataDatabricksInstanceProfiles#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * instance_profiles block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#instance_profiles DataDatabricksInstanceProfiles#instance_profiles}
    */
    readonly instanceProfiles?: DataDatabricksInstanceProfilesInstanceProfiles[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#provider_config DataDatabricksInstanceProfiles#provider_config}
    */
    readonly providerConfig?: DataDatabricksInstanceProfilesProviderConfig;
}
export interface DataDatabricksInstanceProfilesInstanceProfiles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#arn DataDatabricksInstanceProfiles#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#is_meta DataDatabricksInstanceProfiles#is_meta}
    */
    readonly isMeta?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#name DataDatabricksInstanceProfiles#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#role_arn DataDatabricksInstanceProfiles#role_arn}
    */
    readonly roleArn?: string;
}
export declare function dataDatabricksInstanceProfilesInstanceProfilesToTerraform(struct?: DataDatabricksInstanceProfilesInstanceProfiles | cdktn.IResolvable): any;
export declare function dataDatabricksInstanceProfilesInstanceProfilesToHclTerraform(struct?: DataDatabricksInstanceProfilesInstanceProfiles | cdktn.IResolvable): any;
export declare class DataDatabricksInstanceProfilesInstanceProfilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksInstanceProfilesInstanceProfiles | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksInstanceProfilesInstanceProfiles | cdktn.IResolvable | undefined);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _isMeta?;
    get isMeta(): boolean | cdktn.IResolvable;
    set isMeta(value: boolean | cdktn.IResolvable);
    resetIsMeta(): void;
    get isMetaInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
}
export declare class DataDatabricksInstanceProfilesInstanceProfilesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksInstanceProfilesInstanceProfiles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksInstanceProfilesInstanceProfilesOutputReference;
}
export interface DataDatabricksInstanceProfilesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#workspace_id DataDatabricksInstanceProfiles#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksInstanceProfilesProviderConfigToTerraform(struct?: DataDatabricksInstanceProfilesProviderConfigOutputReference | DataDatabricksInstanceProfilesProviderConfig): any;
export declare function dataDatabricksInstanceProfilesProviderConfigToHclTerraform(struct?: DataDatabricksInstanceProfilesProviderConfigOutputReference | DataDatabricksInstanceProfilesProviderConfig): any;
export declare class DataDatabricksInstanceProfilesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksInstanceProfilesProviderConfig | undefined;
    set internalValue(value: DataDatabricksInstanceProfilesProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles databricks_instance_profiles}
*/
export declare class DataDatabricksInstanceProfiles extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_instance_profiles";
    /**
    * Generates CDKTN code for importing a DataDatabricksInstanceProfiles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksInstanceProfiles to import
    * @param importFromId The id of the existing DataDatabricksInstanceProfiles that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksInstanceProfiles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/instance_profiles databricks_instance_profiles} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksInstanceProfilesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksInstanceProfilesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfiles;
    get instanceProfiles(): DataDatabricksInstanceProfilesInstanceProfilesList;
    putInstanceProfiles(value: DataDatabricksInstanceProfilesInstanceProfiles[] | cdktn.IResolvable): void;
    resetInstanceProfiles(): void;
    get instanceProfilesInput(): cdktn.IResolvable | DataDatabricksInstanceProfilesInstanceProfiles[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksInstanceProfilesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksInstanceProfilesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksInstanceProfilesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
