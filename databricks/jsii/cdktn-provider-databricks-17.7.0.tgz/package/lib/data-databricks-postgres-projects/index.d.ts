/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresProjectsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#page_size DataDatabricksPostgresProjects#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#provider_config DataDatabricksPostgresProjects#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresProjectsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#show_deleted DataDatabricksPostgresProjects#show_deleted}
    */
    readonly showDeleted?: boolean | cdktn.IResolvable;
}
export interface DataDatabricksPostgresProjectsProjectsInitialBranchSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#is_protected DataDatabricksPostgresProjects#is_protected}
    */
    readonly isProtected?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresProjectsProjectsInitialBranchSpecToTerraform(struct?: DataDatabricksPostgresProjectsProjectsInitialBranchSpec): any;
export declare function dataDatabricksPostgresProjectsProjectsInitialBranchSpecToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsInitialBranchSpec): any;
export declare class DataDatabricksPostgresProjectsProjectsInitialBranchSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsInitialBranchSpec | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsInitialBranchSpec | undefined);
    private _isProtected?;
    get isProtected(): boolean | cdktn.IResolvable;
    set isProtected(value: boolean | cdktn.IResolvable);
    resetIsProtected(): void;
    get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#enable_readable_secondaries DataDatabricksPostgresProjects#enable_readable_secondaries}
    */
    readonly enableReadableSecondaries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#max DataDatabricksPostgresProjects#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#min DataDatabricksPostgresProjects#min}
    */
    readonly min: number;
}
export declare function dataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroupToTerraform(struct?: DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroupToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup | cdktn.IResolvable | undefined);
    private _enableReadableSecondaries?;
    get enableReadableSecondaries(): boolean | cdktn.IResolvable;
    set enableReadableSecondaries(value: boolean | cdktn.IResolvable);
    resetEnableReadableSecondaries(): void;
    get enableReadableSecondariesInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface DataDatabricksPostgresProjectsProjectsInitialEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#autoscaling_limit_max_cu DataDatabricksPostgresProjects#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#autoscaling_limit_min_cu DataDatabricksPostgresProjects#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#group DataDatabricksPostgresProjects#group}
    */
    readonly group?: DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#no_suspension DataDatabricksPostgresProjects#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#suspend_timeout_duration DataDatabricksPostgresProjects#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresProjectsProjectsInitialEndpointSpecToTerraform(struct?: DataDatabricksPostgresProjectsProjectsInitialEndpointSpec): any;
export declare function dataDatabricksPostgresProjectsProjectsInitialEndpointSpecToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsInitialEndpointSpec): any;
export declare class DataDatabricksPostgresProjectsProjectsInitialEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsInitialEndpointSpec | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsInitialEndpointSpec | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _group;
    get group(): DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroupOutputReference;
    putGroup(value: DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | DataDatabricksPostgresProjectsProjectsInitialEndpointSpecGroup | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectsProjectsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#workspace_id DataDatabricksPostgresProjects#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresProjectsProjectsProviderConfigToTerraform(struct?: DataDatabricksPostgresProjectsProjectsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectsProjectsProviderConfigToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectsProjectsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectsProjectsSpecCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#key DataDatabricksPostgresProjects#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#value DataDatabricksPostgresProjects#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksPostgresProjectsProjectsSpecCustomTagsToTerraform(struct?: DataDatabricksPostgresProjectsProjectsSpecCustomTags | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectsProjectsSpecCustomTagsToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsSpecCustomTags | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectsProjectsSpecCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresProjectsProjectsSpecCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsSpecCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPostgresProjectsProjectsSpecCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresProjectsProjectsSpecCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresProjectsProjectsSpecCustomTagsOutputReference;
}
export interface DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#autoscaling_limit_max_cu DataDatabricksPostgresProjects#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#autoscaling_limit_min_cu DataDatabricksPostgresProjects#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#no_suspension DataDatabricksPostgresProjects#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#pg_settings DataDatabricksPostgresProjects#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#suspend_timeout_duration DataDatabricksPostgresProjects#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettingsToTerraform(struct?: DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettingsToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings | cdktn.IResolvable | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectsProjectsSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#budget_policy_id DataDatabricksPostgresProjects#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#custom_tags DataDatabricksPostgresProjects#custom_tags}
    */
    readonly customTags?: DataDatabricksPostgresProjectsProjectsSpecCustomTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#default_branch DataDatabricksPostgresProjects#default_branch}
    */
    readonly defaultBranch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#default_endpoint_settings DataDatabricksPostgresProjects#default_endpoint_settings}
    */
    readonly defaultEndpointSettings?: DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#display_name DataDatabricksPostgresProjects#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#enable_pg_native_login DataDatabricksPostgresProjects#enable_pg_native_login}
    */
    readonly enablePgNativeLogin?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#history_retention_duration DataDatabricksPostgresProjects#history_retention_duration}
    */
    readonly historyRetentionDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#pg_version DataDatabricksPostgresProjects#pg_version}
    */
    readonly pgVersion?: number;
}
export declare function dataDatabricksPostgresProjectsProjectsSpecToTerraform(struct?: DataDatabricksPostgresProjectsProjectsSpec): any;
export declare function dataDatabricksPostgresProjectsProjectsSpecToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsSpec): any;
export declare class DataDatabricksPostgresProjectsProjectsSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsSpec | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsSpec | undefined);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _customTags;
    get customTags(): DataDatabricksPostgresProjectsProjectsSpecCustomTagsList;
    putCustomTags(value: DataDatabricksPostgresProjectsProjectsSpecCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | DataDatabricksPostgresProjectsProjectsSpecCustomTags[] | undefined;
    private _defaultBranch?;
    get defaultBranch(): string;
    set defaultBranch(value: string);
    resetDefaultBranch(): void;
    get defaultBranchInput(): string | undefined;
    private _defaultEndpointSettings;
    get defaultEndpointSettings(): DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettingsOutputReference;
    putDefaultEndpointSettings(value: DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings): void;
    resetDefaultEndpointSettings(): void;
    get defaultEndpointSettingsInput(): cdktn.IResolvable | DataDatabricksPostgresProjectsProjectsSpecDefaultEndpointSettings | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enablePgNativeLogin?;
    get enablePgNativeLogin(): boolean | cdktn.IResolvable;
    set enablePgNativeLogin(value: boolean | cdktn.IResolvable);
    resetEnablePgNativeLogin(): void;
    get enablePgNativeLoginInput(): boolean | cdktn.IResolvable | undefined;
    private _historyRetentionDuration?;
    get historyRetentionDuration(): string;
    set historyRetentionDuration(value: string);
    resetHistoryRetentionDuration(): void;
    get historyRetentionDurationInput(): string | undefined;
    private _pgVersion?;
    get pgVersion(): number;
    set pgVersion(value: number);
    resetPgVersion(): void;
    get pgVersionInput(): number | undefined;
}
export interface DataDatabricksPostgresProjectsProjectsStatusCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#key DataDatabricksPostgresProjects#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#value DataDatabricksPostgresProjects#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksPostgresProjectsProjectsStatusCustomTagsToTerraform(struct?: DataDatabricksPostgresProjectsProjectsStatusCustomTags): any;
export declare function dataDatabricksPostgresProjectsProjectsStatusCustomTagsToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsStatusCustomTags): any;
export declare class DataDatabricksPostgresProjectsProjectsStatusCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresProjectsProjectsStatusCustomTags | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsStatusCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPostgresProjectsProjectsStatusCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresProjectsProjectsStatusCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresProjectsProjectsStatusCustomTagsOutputReference;
}
export interface DataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#autoscaling_limit_max_cu DataDatabricksPostgresProjects#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#autoscaling_limit_min_cu DataDatabricksPostgresProjects#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#no_suspension DataDatabricksPostgresProjects#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#pg_settings DataDatabricksPostgresProjects#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#suspend_timeout_duration DataDatabricksPostgresProjects#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettingsToTerraform(struct?: DataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettings): any;
export declare function dataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettingsToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettings): any;
export declare class DataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettings | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettings | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectsProjectsStatus {
}
export declare function dataDatabricksPostgresProjectsProjectsStatusToTerraform(struct?: DataDatabricksPostgresProjectsProjectsStatus): any;
export declare function dataDatabricksPostgresProjectsProjectsStatusToHclTerraform(struct?: DataDatabricksPostgresProjectsProjectsStatus): any;
export declare class DataDatabricksPostgresProjectsProjectsStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProjectsStatus | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjectsStatus | undefined);
    get branchLogicalSizeLimitBytes(): number;
    get budgetPolicyId(): string;
    get computeLastActiveTime(): string;
    private _customTags;
    get customTags(): DataDatabricksPostgresProjectsProjectsStatusCustomTagsList;
    get defaultBranch(): string;
    private _defaultEndpointSettings;
    get defaultEndpointSettings(): DataDatabricksPostgresProjectsProjectsStatusDefaultEndpointSettingsOutputReference;
    get displayName(): string;
    get enablePgNativeLogin(): cdktn.IResolvable;
    get historyRetentionDuration(): string;
    get owner(): string;
    get pgVersion(): number;
    get projectId(): string;
    get syntheticStorageSizeBytes(): number;
}
export interface DataDatabricksPostgresProjectsProjects {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#name DataDatabricksPostgresProjects#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#provider_config DataDatabricksPostgresProjects#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresProjectsProjectsProviderConfig;
}
export declare function dataDatabricksPostgresProjectsProjectsToTerraform(struct?: DataDatabricksPostgresProjectsProjects): any;
export declare function dataDatabricksPostgresProjectsProjectsToHclTerraform(struct?: DataDatabricksPostgresProjectsProjects): any;
export declare class DataDatabricksPostgresProjectsProjectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresProjectsProjects | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProjects | undefined);
    get createTime(): string;
    get deleteTime(): string;
    private _initialBranchSpec;
    get initialBranchSpec(): DataDatabricksPostgresProjectsProjectsInitialBranchSpecOutputReference;
    private _initialEndpointSpec;
    get initialEndpointSpec(): DataDatabricksPostgresProjectsProjectsInitialEndpointSpecOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get projectId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresProjectsProjectsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresProjectsProjectsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresProjectsProjectsProviderConfig | undefined;
    get purgeTime(): string;
    private _spec;
    get spec(): DataDatabricksPostgresProjectsProjectsSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresProjectsProjectsStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
}
export declare class DataDatabricksPostgresProjectsProjectsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresProjectsProjects[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresProjectsProjectsOutputReference;
}
export interface DataDatabricksPostgresProjectsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#workspace_id DataDatabricksPostgresProjects#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresProjectsProviderConfigToTerraform(struct?: DataDatabricksPostgresProjectsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectsProviderConfigToHclTerraform(struct?: DataDatabricksPostgresProjectsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects databricks_postgres_projects}
*/
export declare class DataDatabricksPostgresProjects extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_projects";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresProjects resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresProjects to import
    * @param importFromId The id of the existing DataDatabricksPostgresProjects that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresProjects to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_projects databricks_postgres_projects} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresProjectsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksPostgresProjectsConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _projects;
    get projects(): DataDatabricksPostgresProjectsProjectsList;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresProjectsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresProjectsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresProjectsProviderConfig | undefined;
    private _showDeleted?;
    get showDeleted(): boolean | cdktn.IResolvable;
    set showDeleted(value: boolean | cdktn.IResolvable);
    resetShowDeleted(): void;
    get showDeletedInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
