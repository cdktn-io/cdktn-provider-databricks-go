/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksExternalMetadataConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/external_metadata#name DataDatabricksExternalMetadata#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/external_metadata#provider_config DataDatabricksExternalMetadata#provider_config}
    */
    readonly providerConfig?: DataDatabricksExternalMetadataProviderConfig;
}
export interface DataDatabricksExternalMetadataProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/external_metadata#workspace_id DataDatabricksExternalMetadata#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksExternalMetadataProviderConfigToTerraform(struct?: DataDatabricksExternalMetadataProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksExternalMetadataProviderConfigToHclTerraform(struct?: DataDatabricksExternalMetadataProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksExternalMetadataProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalMetadataProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksExternalMetadataProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/external_metadata databricks_external_metadata}
*/
export declare class DataDatabricksExternalMetadata extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_external_metadata";
    /**
    * Generates CDKTN code for importing a DataDatabricksExternalMetadata resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksExternalMetadata to import
    * @param importFromId The id of the existing DataDatabricksExternalMetadata that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/external_metadata#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksExternalMetadata to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/external_metadata databricks_external_metadata} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksExternalMetadataConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksExternalMetadataConfig);
    get columns(): string[];
    get createTime(): string;
    get createdBy(): string;
    get description(): string;
    get entityType(): string;
    get id(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get owner(): string;
    private _properties;
    get properties(): cdktn.StringMap;
    private _providerConfig;
    get providerConfig(): DataDatabricksExternalMetadataProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksExternalMetadataProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksExternalMetadataProviderConfig | undefined;
    get systemType(): string;
    get updateTime(): string;
    get updatedBy(): string;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
