/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AlertConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#custom_body Alert#custom_body}
    */
    readonly customBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#custom_subject Alert#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#display_name Alert#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#notify_on_ok Alert#notify_on_ok}
    */
    readonly notifyOnOk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#owner_user_name Alert#owner_user_name}
    */
    readonly ownerUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#parent_path Alert#parent_path}
    */
    readonly parentPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#query_id Alert#query_id}
    */
    readonly queryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#seconds_to_retrigger Alert#seconds_to_retrigger}
    */
    readonly secondsToRetrigger?: number;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#condition Alert#condition}
    */
    readonly condition: AlertCondition;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#provider_config Alert#provider_config}
    */
    readonly providerConfig?: AlertProviderConfig;
}
export interface AlertConditionOperandColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#name Alert#name}
    */
    readonly name: string;
}
export declare function alertConditionOperandColumnToTerraform(struct?: AlertConditionOperandColumnOutputReference | AlertConditionOperandColumn): any;
export declare function alertConditionOperandColumnToHclTerraform(struct?: AlertConditionOperandColumnOutputReference | AlertConditionOperandColumn): any;
export declare class AlertConditionOperandColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertConditionOperandColumn | undefined;
    set internalValue(value: AlertConditionOperandColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AlertConditionOperand {
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#column Alert#column}
    */
    readonly column: AlertConditionOperandColumn;
}
export declare function alertConditionOperandToTerraform(struct?: AlertConditionOperandOutputReference | AlertConditionOperand): any;
export declare function alertConditionOperandToHclTerraform(struct?: AlertConditionOperandOutputReference | AlertConditionOperand): any;
export declare class AlertConditionOperandOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertConditionOperand | undefined;
    set internalValue(value: AlertConditionOperand | undefined);
    private _column;
    get column(): AlertConditionOperandColumnOutputReference;
    putColumn(value: AlertConditionOperandColumn): void;
    get columnInput(): AlertConditionOperandColumn | undefined;
}
export interface AlertConditionThresholdValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#bool_value Alert#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#double_value Alert#double_value}
    */
    readonly doubleValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#string_value Alert#string_value}
    */
    readonly stringValue?: string;
}
export declare function alertConditionThresholdValueToTerraform(struct?: AlertConditionThresholdValueOutputReference | AlertConditionThresholdValue): any;
export declare function alertConditionThresholdValueToHclTerraform(struct?: AlertConditionThresholdValueOutputReference | AlertConditionThresholdValue): any;
export declare class AlertConditionThresholdValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertConditionThresholdValue | undefined;
    set internalValue(value: AlertConditionThresholdValue | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface AlertConditionThreshold {
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#value Alert#value}
    */
    readonly value: AlertConditionThresholdValue;
}
export declare function alertConditionThresholdToTerraform(struct?: AlertConditionThresholdOutputReference | AlertConditionThreshold): any;
export declare function alertConditionThresholdToHclTerraform(struct?: AlertConditionThresholdOutputReference | AlertConditionThreshold): any;
export declare class AlertConditionThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertConditionThreshold | undefined;
    set internalValue(value: AlertConditionThreshold | undefined);
    private _value;
    get value(): AlertConditionThresholdValueOutputReference;
    putValue(value: AlertConditionThresholdValue): void;
    get valueInput(): AlertConditionThresholdValue | undefined;
}
export interface AlertCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#empty_result_state Alert#empty_result_state}
    */
    readonly emptyResultState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#op Alert#op}
    */
    readonly op: string;
    /**
    * operand block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#operand Alert#operand}
    */
    readonly operand: AlertConditionOperand;
    /**
    * threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#threshold Alert#threshold}
    */
    readonly threshold?: AlertConditionThreshold;
}
export declare function alertConditionToTerraform(struct?: AlertConditionOutputReference | AlertCondition): any;
export declare function alertConditionToHclTerraform(struct?: AlertConditionOutputReference | AlertCondition): any;
export declare class AlertConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertCondition | undefined;
    set internalValue(value: AlertCondition | undefined);
    private _emptyResultState?;
    get emptyResultState(): string;
    set emptyResultState(value: string);
    resetEmptyResultState(): void;
    get emptyResultStateInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _operand;
    get operand(): AlertConditionOperandOutputReference;
    putOperand(value: AlertConditionOperand): void;
    get operandInput(): AlertConditionOperand | undefined;
    private _threshold;
    get threshold(): AlertConditionThresholdOutputReference;
    putThreshold(value: AlertConditionThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): AlertConditionThreshold | undefined;
}
export interface AlertProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#workspace_id Alert#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function alertProviderConfigToTerraform(struct?: AlertProviderConfigOutputReference | AlertProviderConfig): any;
export declare function alertProviderConfigToHclTerraform(struct?: AlertProviderConfigOutputReference | AlertProviderConfig): any;
export declare class AlertProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlertProviderConfig | undefined;
    set internalValue(value: AlertProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert databricks_alert}
*/
export declare class Alert extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_alert";
    /**
    * Generates CDKTN code for importing a Alert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Alert to import
    * @param importFromId The id of the existing Alert that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Alert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/alert databricks_alert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlertConfig
    */
    constructor(scope: Construct, id: string, config: AlertConfig);
    get createTime(): string;
    private _customBody?;
    get customBody(): string;
    set customBody(value: string);
    resetCustomBody(): void;
    get customBodyInput(): string | undefined;
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    get lifecycleState(): string;
    private _notifyOnOk?;
    get notifyOnOk(): boolean | cdktn.IResolvable;
    set notifyOnOk(value: boolean | cdktn.IResolvable);
    resetNotifyOnOk(): void;
    get notifyOnOkInput(): boolean | cdktn.IResolvable | undefined;
    private _ownerUserName?;
    get ownerUserName(): string;
    set ownerUserName(value: string);
    resetOwnerUserName(): void;
    get ownerUserNameInput(): string | undefined;
    private _parentPath?;
    get parentPath(): string;
    set parentPath(value: string);
    resetParentPath(): void;
    get parentPathInput(): string | undefined;
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
    private _secondsToRetrigger?;
    get secondsToRetrigger(): number;
    set secondsToRetrigger(value: number);
    resetSecondsToRetrigger(): void;
    get secondsToRetriggerInput(): number | undefined;
    get state(): string;
    get triggerTime(): string;
    get updateTime(): string;
    private _condition;
    get condition(): AlertConditionOutputReference;
    putCondition(value: AlertCondition): void;
    get conditionInput(): AlertCondition | undefined;
    private _providerConfig;
    get providerConfig(): AlertProviderConfigOutputReference;
    putProviderConfig(value: AlertProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): AlertProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
