/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LakehouseMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#assets_dir LakehouseMonitor#assets_dir}
    */
    readonly assetsDir: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#baseline_table_name LakehouseMonitor#baseline_table_name}
    */
    readonly baselineTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#id LakehouseMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#latest_monitor_failure_msg LakehouseMonitor#latest_monitor_failure_msg}
    */
    readonly latestMonitorFailureMsg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#output_schema_name LakehouseMonitor#output_schema_name}
    */
    readonly outputSchemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#skip_builtin_dashboard LakehouseMonitor#skip_builtin_dashboard}
    */
    readonly skipBuiltinDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#slicing_exprs LakehouseMonitor#slicing_exprs}
    */
    readonly slicingExprs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#table_name LakehouseMonitor#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#warehouse_id LakehouseMonitor#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * custom_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#custom_metrics LakehouseMonitor#custom_metrics}
    */
    readonly customMetrics?: LakehouseMonitorCustomMetrics[] | cdktn.IResolvable;
    /**
    * data_classification_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#data_classification_config LakehouseMonitor#data_classification_config}
    */
    readonly dataClassificationConfig?: LakehouseMonitorDataClassificationConfig;
    /**
    * inference_log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#inference_log LakehouseMonitor#inference_log}
    */
    readonly inferenceLog?: LakehouseMonitorInferenceLog;
    /**
    * notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#notifications LakehouseMonitor#notifications}
    */
    readonly notifications?: LakehouseMonitorNotifications;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#provider_config LakehouseMonitor#provider_config}
    */
    readonly providerConfig?: LakehouseMonitorProviderConfig;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#schedule LakehouseMonitor#schedule}
    */
    readonly schedule?: LakehouseMonitorSchedule;
    /**
    * snapshot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#snapshot LakehouseMonitor#snapshot}
    */
    readonly snapshot?: LakehouseMonitorSnapshot;
    /**
    * time_series block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#time_series LakehouseMonitor#time_series}
    */
    readonly timeSeries?: LakehouseMonitorTimeSeries;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#timeouts LakehouseMonitor#timeouts}
    */
    readonly timeouts?: LakehouseMonitorTimeouts;
}
export interface LakehouseMonitorCustomMetrics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#definition LakehouseMonitor#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#input_columns LakehouseMonitor#input_columns}
    */
    readonly inputColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#name LakehouseMonitor#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#output_data_type LakehouseMonitor#output_data_type}
    */
    readonly outputDataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#type LakehouseMonitor#type}
    */
    readonly type: string;
}
export declare function lakehouseMonitorCustomMetricsToTerraform(struct?: LakehouseMonitorCustomMetrics | cdktn.IResolvable): any;
export declare function lakehouseMonitorCustomMetricsToHclTerraform(struct?: LakehouseMonitorCustomMetrics | cdktn.IResolvable): any;
export declare class LakehouseMonitorCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LakehouseMonitorCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: LakehouseMonitorCustomMetrics | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _inputColumns?;
    get inputColumns(): string[];
    set inputColumns(value: string[]);
    get inputColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputDataType?;
    get outputDataType(): string;
    set outputDataType(value: string);
    get outputDataTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class LakehouseMonitorCustomMetricsList extends cdktn.ComplexList {
    internalValue?: LakehouseMonitorCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LakehouseMonitorCustomMetricsOutputReference;
}
export interface LakehouseMonitorDataClassificationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#enabled LakehouseMonitor#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function lakehouseMonitorDataClassificationConfigToTerraform(struct?: LakehouseMonitorDataClassificationConfigOutputReference | LakehouseMonitorDataClassificationConfig): any;
export declare function lakehouseMonitorDataClassificationConfigToHclTerraform(struct?: LakehouseMonitorDataClassificationConfigOutputReference | LakehouseMonitorDataClassificationConfig): any;
export declare class LakehouseMonitorDataClassificationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorDataClassificationConfig | undefined;
    set internalValue(value: LakehouseMonitorDataClassificationConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface LakehouseMonitorInferenceLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#granularities LakehouseMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#label_col LakehouseMonitor#label_col}
    */
    readonly labelCol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#model_id_col LakehouseMonitor#model_id_col}
    */
    readonly modelIdCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#prediction_col LakehouseMonitor#prediction_col}
    */
    readonly predictionCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#prediction_proba_col LakehouseMonitor#prediction_proba_col}
    */
    readonly predictionProbaCol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#problem_type LakehouseMonitor#problem_type}
    */
    readonly problemType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#timestamp_col LakehouseMonitor#timestamp_col}
    */
    readonly timestampCol: string;
}
export declare function lakehouseMonitorInferenceLogToTerraform(struct?: LakehouseMonitorInferenceLogOutputReference | LakehouseMonitorInferenceLog): any;
export declare function lakehouseMonitorInferenceLogToHclTerraform(struct?: LakehouseMonitorInferenceLogOutputReference | LakehouseMonitorInferenceLog): any;
export declare class LakehouseMonitorInferenceLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorInferenceLog | undefined;
    set internalValue(value: LakehouseMonitorInferenceLog | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _labelCol?;
    get labelCol(): string;
    set labelCol(value: string);
    resetLabelCol(): void;
    get labelColInput(): string | undefined;
    private _modelIdCol?;
    get modelIdCol(): string;
    set modelIdCol(value: string);
    get modelIdColInput(): string | undefined;
    private _predictionCol?;
    get predictionCol(): string;
    set predictionCol(value: string);
    get predictionColInput(): string | undefined;
    private _predictionProbaCol?;
    get predictionProbaCol(): string;
    set predictionProbaCol(value: string);
    resetPredictionProbaCol(): void;
    get predictionProbaColInput(): string | undefined;
    private _problemType?;
    get problemType(): string;
    set problemType(value: string);
    get problemTypeInput(): string | undefined;
    private _timestampCol?;
    get timestampCol(): string;
    set timestampCol(value: string);
    get timestampColInput(): string | undefined;
}
export interface LakehouseMonitorNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#email_addresses LakehouseMonitor#email_addresses}
    */
    readonly emailAddresses?: string[];
}
export declare function lakehouseMonitorNotificationsOnFailureToTerraform(struct?: LakehouseMonitorNotificationsOnFailureOutputReference | LakehouseMonitorNotificationsOnFailure): any;
export declare function lakehouseMonitorNotificationsOnFailureToHclTerraform(struct?: LakehouseMonitorNotificationsOnFailureOutputReference | LakehouseMonitorNotificationsOnFailure): any;
export declare class LakehouseMonitorNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorNotificationsOnFailure | undefined;
    set internalValue(value: LakehouseMonitorNotificationsOnFailure | undefined);
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
}
export interface LakehouseMonitorNotificationsOnNewClassificationTagDetected {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#email_addresses LakehouseMonitor#email_addresses}
    */
    readonly emailAddresses?: string[];
}
export declare function lakehouseMonitorNotificationsOnNewClassificationTagDetectedToTerraform(struct?: LakehouseMonitorNotificationsOnNewClassificationTagDetectedOutputReference | LakehouseMonitorNotificationsOnNewClassificationTagDetected): any;
export declare function lakehouseMonitorNotificationsOnNewClassificationTagDetectedToHclTerraform(struct?: LakehouseMonitorNotificationsOnNewClassificationTagDetectedOutputReference | LakehouseMonitorNotificationsOnNewClassificationTagDetected): any;
export declare class LakehouseMonitorNotificationsOnNewClassificationTagDetectedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorNotificationsOnNewClassificationTagDetected | undefined;
    set internalValue(value: LakehouseMonitorNotificationsOnNewClassificationTagDetected | undefined);
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
}
export interface LakehouseMonitorNotifications {
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#on_failure LakehouseMonitor#on_failure}
    */
    readonly onFailure?: LakehouseMonitorNotificationsOnFailure;
    /**
    * on_new_classification_tag_detected block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#on_new_classification_tag_detected LakehouseMonitor#on_new_classification_tag_detected}
    */
    readonly onNewClassificationTagDetected?: LakehouseMonitorNotificationsOnNewClassificationTagDetected;
}
export declare function lakehouseMonitorNotificationsToTerraform(struct?: LakehouseMonitorNotificationsOutputReference | LakehouseMonitorNotifications): any;
export declare function lakehouseMonitorNotificationsToHclTerraform(struct?: LakehouseMonitorNotificationsOutputReference | LakehouseMonitorNotifications): any;
export declare class LakehouseMonitorNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorNotifications | undefined;
    set internalValue(value: LakehouseMonitorNotifications | undefined);
    private _onFailure;
    get onFailure(): LakehouseMonitorNotificationsOnFailureOutputReference;
    putOnFailure(value: LakehouseMonitorNotificationsOnFailure): void;
    resetOnFailure(): void;
    get onFailureInput(): LakehouseMonitorNotificationsOnFailure | undefined;
    private _onNewClassificationTagDetected;
    get onNewClassificationTagDetected(): LakehouseMonitorNotificationsOnNewClassificationTagDetectedOutputReference;
    putOnNewClassificationTagDetected(value: LakehouseMonitorNotificationsOnNewClassificationTagDetected): void;
    resetOnNewClassificationTagDetected(): void;
    get onNewClassificationTagDetectedInput(): LakehouseMonitorNotificationsOnNewClassificationTagDetected | undefined;
}
export interface LakehouseMonitorProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#workspace_id LakehouseMonitor#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakehouseMonitorProviderConfigToTerraform(struct?: LakehouseMonitorProviderConfigOutputReference | LakehouseMonitorProviderConfig): any;
export declare function lakehouseMonitorProviderConfigToHclTerraform(struct?: LakehouseMonitorProviderConfigOutputReference | LakehouseMonitorProviderConfig): any;
export declare class LakehouseMonitorProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorProviderConfig | undefined;
    set internalValue(value: LakehouseMonitorProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakehouseMonitorSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#quartz_cron_expression LakehouseMonitor#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#timezone_id LakehouseMonitor#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function lakehouseMonitorScheduleToTerraform(struct?: LakehouseMonitorScheduleOutputReference | LakehouseMonitorSchedule): any;
export declare function lakehouseMonitorScheduleToHclTerraform(struct?: LakehouseMonitorScheduleOutputReference | LakehouseMonitorSchedule): any;
export declare class LakehouseMonitorScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorSchedule | undefined;
    set internalValue(value: LakehouseMonitorSchedule | undefined);
    get pauseStatus(): string;
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface LakehouseMonitorSnapshot {
}
export declare function lakehouseMonitorSnapshotToTerraform(struct?: LakehouseMonitorSnapshotOutputReference | LakehouseMonitorSnapshot): any;
export declare function lakehouseMonitorSnapshotToHclTerraform(struct?: LakehouseMonitorSnapshotOutputReference | LakehouseMonitorSnapshot): any;
export declare class LakehouseMonitorSnapshotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorSnapshot | undefined;
    set internalValue(value: LakehouseMonitorSnapshot | undefined);
}
export interface LakehouseMonitorTimeSeries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#granularities LakehouseMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#timestamp_col LakehouseMonitor#timestamp_col}
    */
    readonly timestampCol: string;
}
export declare function lakehouseMonitorTimeSeriesToTerraform(struct?: LakehouseMonitorTimeSeriesOutputReference | LakehouseMonitorTimeSeries): any;
export declare function lakehouseMonitorTimeSeriesToHclTerraform(struct?: LakehouseMonitorTimeSeriesOutputReference | LakehouseMonitorTimeSeries): any;
export declare class LakehouseMonitorTimeSeriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorTimeSeries | undefined;
    set internalValue(value: LakehouseMonitorTimeSeries | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _timestampCol?;
    get timestampCol(): string;
    set timestampCol(value: string);
    get timestampColInput(): string | undefined;
}
export interface LakehouseMonitorTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#create LakehouseMonitor#create}
    */
    readonly create?: string;
}
export declare function lakehouseMonitorTimeoutsToTerraform(struct?: LakehouseMonitorTimeouts | cdktn.IResolvable): any;
export declare function lakehouseMonitorTimeoutsToHclTerraform(struct?: LakehouseMonitorTimeouts | cdktn.IResolvable): any;
export declare class LakehouseMonitorTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakehouseMonitorTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: LakehouseMonitorTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor databricks_lakehouse_monitor}
*/
export declare class LakehouseMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_lakehouse_monitor";
    /**
    * Generates CDKTN code for importing a LakehouseMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LakehouseMonitor to import
    * @param importFromId The id of the existing LakehouseMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LakehouseMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/lakehouse_monitor databricks_lakehouse_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LakehouseMonitorConfig
    */
    constructor(scope: Construct, id: string, config: LakehouseMonitorConfig);
    private _assetsDir?;
    get assetsDir(): string;
    set assetsDir(value: string);
    get assetsDirInput(): string | undefined;
    private _baselineTableName?;
    get baselineTableName(): string;
    set baselineTableName(value: string);
    resetBaselineTableName(): void;
    get baselineTableNameInput(): string | undefined;
    get dashboardId(): string;
    get driftMetricsTableName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _latestMonitorFailureMsg?;
    get latestMonitorFailureMsg(): string;
    set latestMonitorFailureMsg(value: string);
    resetLatestMonitorFailureMsg(): void;
    get latestMonitorFailureMsgInput(): string | undefined;
    get monitorVersion(): number;
    private _outputSchemaName?;
    get outputSchemaName(): string;
    set outputSchemaName(value: string);
    get outputSchemaNameInput(): string | undefined;
    get profileMetricsTableName(): string;
    private _skipBuiltinDashboard?;
    get skipBuiltinDashboard(): boolean | cdktn.IResolvable;
    set skipBuiltinDashboard(value: boolean | cdktn.IResolvable);
    resetSkipBuiltinDashboard(): void;
    get skipBuiltinDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _slicingExprs?;
    get slicingExprs(): string[];
    set slicingExprs(value: string[]);
    resetSlicingExprs(): void;
    get slicingExprsInput(): string[] | undefined;
    get status(): string;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _customMetrics;
    get customMetrics(): LakehouseMonitorCustomMetricsList;
    putCustomMetrics(value: LakehouseMonitorCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | LakehouseMonitorCustomMetrics[] | undefined;
    private _dataClassificationConfig;
    get dataClassificationConfig(): LakehouseMonitorDataClassificationConfigOutputReference;
    putDataClassificationConfig(value: LakehouseMonitorDataClassificationConfig): void;
    resetDataClassificationConfig(): void;
    get dataClassificationConfigInput(): LakehouseMonitorDataClassificationConfig | undefined;
    private _inferenceLog;
    get inferenceLog(): LakehouseMonitorInferenceLogOutputReference;
    putInferenceLog(value: LakehouseMonitorInferenceLog): void;
    resetInferenceLog(): void;
    get inferenceLogInput(): LakehouseMonitorInferenceLog | undefined;
    private _notifications;
    get notifications(): LakehouseMonitorNotificationsOutputReference;
    putNotifications(value: LakehouseMonitorNotifications): void;
    resetNotifications(): void;
    get notificationsInput(): LakehouseMonitorNotifications | undefined;
    private _providerConfig;
    get providerConfig(): LakehouseMonitorProviderConfigOutputReference;
    putProviderConfig(value: LakehouseMonitorProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): LakehouseMonitorProviderConfig | undefined;
    private _schedule;
    get schedule(): LakehouseMonitorScheduleOutputReference;
    putSchedule(value: LakehouseMonitorSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): LakehouseMonitorSchedule | undefined;
    private _snapshot;
    get snapshot(): LakehouseMonitorSnapshotOutputReference;
    putSnapshot(value: LakehouseMonitorSnapshot): void;
    resetSnapshot(): void;
    get snapshotInput(): LakehouseMonitorSnapshot | undefined;
    private _timeSeries;
    get timeSeries(): LakehouseMonitorTimeSeriesOutputReference;
    putTimeSeries(value: LakehouseMonitorTimeSeries): void;
    resetTimeSeries(): void;
    get timeSeriesInput(): LakehouseMonitorTimeSeries | undefined;
    private _timeouts;
    get timeouts(): LakehouseMonitorTimeoutsOutputReference;
    putTimeouts(value: LakehouseMonitorTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | LakehouseMonitorTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
