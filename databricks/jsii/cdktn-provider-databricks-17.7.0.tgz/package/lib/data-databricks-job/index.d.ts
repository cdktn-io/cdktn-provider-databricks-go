/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { DataDatabricksJobJobSettings, DataDatabricksJobJobSettingsOutputReference, DataDatabricksJobProviderConfig, DataDatabricksJobProviderConfigOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job#id DataDatabricksJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job#job_id DataDatabricksJob#job_id}
    */
    readonly jobId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job#job_name DataDatabricksJob#job_name}
    */
    readonly jobName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job#name DataDatabricksJob#name}
    */
    readonly name?: string;
    /**
    * job_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job#job_settings DataDatabricksJob#job_settings}
    */
    readonly jobSettings?: DataDatabricksJobJobSettings;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job#provider_config DataDatabricksJob#provider_config}
    */
    readonly providerConfig?: DataDatabricksJobProviderConfig;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job databricks_job}
*/
export declare class DataDatabricksJob extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_job";
    /**
    * Generates CDKTN code for importing a DataDatabricksJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksJob to import
    * @param importFromId The id of the existing DataDatabricksJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/job databricks_job} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksJobConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksJobConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobId?;
    get jobId(): string;
    set jobId(value: string);
    resetJobId(): void;
    get jobIdInput(): string | undefined;
    private _jobName?;
    get jobName(): string;
    set jobName(value: string);
    resetJobName(): void;
    get jobNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _jobSettings;
    get jobSettings(): DataDatabricksJobJobSettingsOutputReference;
    putJobSettings(value: DataDatabricksJobJobSettings): void;
    resetJobSettings(): void;
    get jobSettingsInput(): DataDatabricksJobJobSettings | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksJobProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksJobProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksJobProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
