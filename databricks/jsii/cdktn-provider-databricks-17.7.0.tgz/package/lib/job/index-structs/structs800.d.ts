/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { JobTaskAiRuntimeTask, JobTaskAiRuntimeTaskOutputReference, JobTaskAlertTask, JobTaskAlertTaskOutputReference, JobTaskCleanRoomsNotebookTask, JobTaskCleanRoomsNotebookTaskOutputReference, JobTaskCompute, JobTaskComputeOutputReference, JobTaskConditionTask, JobTaskConditionTaskOutputReference, JobTaskDashboardTask, JobTaskDashboardTaskOutputReference, JobTaskDbtCloudTask, JobTaskDbtCloudTaskOutputReference, JobTaskDbtPlatformTask, JobTaskDbtPlatformTaskOutputReference, JobTaskDbtTask, JobTaskDbtTaskOutputReference, JobTaskDependsOn, JobTaskDependsOnList, JobTaskEmailNotifications, JobTaskEmailNotificationsOutputReference } from './structs0';
import { JobTaskForEachTask, JobTaskForEachTaskOutputReference, JobTaskGenAiComputeTask, JobTaskGenAiComputeTaskOutputReference, JobTaskHealth, JobTaskHealthOutputReference, JobTaskLibrary, JobTaskLibraryList, JobTaskNewCluster, JobTaskNewClusterOutputReference, JobTaskNotebookTask, JobTaskNotebookTaskOutputReference, JobTaskNotificationSettings, JobTaskNotificationSettingsOutputReference, JobTaskPipelineTask, JobTaskPipelineTaskOutputReference, JobTaskPowerBiTask, JobTaskPowerBiTaskOutputReference, JobTaskPythonOperatorTask, JobTaskPythonOperatorTaskOutputReference, JobTaskPythonWheelTask, JobTaskPythonWheelTaskOutputReference, JobTaskRunJobTask, JobTaskRunJobTaskOutputReference, JobTaskSparkJarTask, JobTaskSparkJarTaskOutputReference, JobTaskSparkPythonTask, JobTaskSparkPythonTaskOutputReference, JobTaskSparkSubmitTask, JobTaskSparkSubmitTaskOutputReference } from './structs400';
export interface JobTaskSqlTaskAlertSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskSqlTaskAlertSubscriptionsToTerraform(struct?: JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare function jobTaskSqlTaskAlertSubscriptionsToHclTerraform(struct?: JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare class JobTaskSqlTaskAlertSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskSqlTaskAlertSubscriptionsList extends cdktn.ComplexList {
    internalValue?: JobTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskSqlTaskAlertSubscriptionsOutputReference;
}
export interface JobTaskSqlTaskAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#alert_id Job#alert_id}
    */
    readonly alertId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#pause_subscriptions Job#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#subscriptions Job#subscriptions}
    */
    readonly subscriptions?: JobTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
}
export declare function jobTaskSqlTaskAlertToTerraform(struct?: JobTaskSqlTaskAlertOutputReference | JobTaskSqlTaskAlert): any;
export declare function jobTaskSqlTaskAlertToHclTerraform(struct?: JobTaskSqlTaskAlertOutputReference | JobTaskSqlTaskAlert): any;
export declare class JobTaskSqlTaskAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskAlert | undefined;
    set internalValue(value: JobTaskSqlTaskAlert | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): JobTaskSqlTaskAlertSubscriptionsList;
    putSubscriptions(value: JobTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | JobTaskSqlTaskAlertSubscriptions[] | undefined;
}
export interface JobTaskSqlTaskDashboardSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskSqlTaskDashboardSubscriptionsToTerraform(struct?: JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare function jobTaskSqlTaskDashboardSubscriptionsToHclTerraform(struct?: JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare class JobTaskSqlTaskDashboardSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskSqlTaskDashboardSubscriptionsList extends cdktn.ComplexList {
    internalValue?: JobTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskSqlTaskDashboardSubscriptionsOutputReference;
}
export interface JobTaskSqlTaskDashboard {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#custom_subject Job#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#dashboard_id Job#dashboard_id}
    */
    readonly dashboardId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#pause_subscriptions Job#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#subscriptions Job#subscriptions}
    */
    readonly subscriptions?: JobTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
}
export declare function jobTaskSqlTaskDashboardToTerraform(struct?: JobTaskSqlTaskDashboardOutputReference | JobTaskSqlTaskDashboard): any;
export declare function jobTaskSqlTaskDashboardToHclTerraform(struct?: JobTaskSqlTaskDashboardOutputReference | JobTaskSqlTaskDashboard): any;
export declare class JobTaskSqlTaskDashboardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskDashboard | undefined;
    set internalValue(value: JobTaskSqlTaskDashboard | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    get dashboardIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): JobTaskSqlTaskDashboardSubscriptionsList;
    putSubscriptions(value: JobTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | JobTaskSqlTaskDashboardSubscriptions[] | undefined;
}
export interface JobTaskSqlTaskFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#path Job#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
}
export declare function jobTaskSqlTaskFileToTerraform(struct?: JobTaskSqlTaskFileOutputReference | JobTaskSqlTaskFile): any;
export declare function jobTaskSqlTaskFileToHclTerraform(struct?: JobTaskSqlTaskFileOutputReference | JobTaskSqlTaskFile): any;
export declare class JobTaskSqlTaskFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskFile | undefined;
    set internalValue(value: JobTaskSqlTaskFile | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface JobTaskSqlTaskQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#query_id Job#query_id}
    */
    readonly queryId: string;
}
export declare function jobTaskSqlTaskQueryToTerraform(struct?: JobTaskSqlTaskQueryOutputReference | JobTaskSqlTaskQuery): any;
export declare function jobTaskSqlTaskQueryToHclTerraform(struct?: JobTaskSqlTaskQueryOutputReference | JobTaskSqlTaskQuery): any;
export declare class JobTaskSqlTaskQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskQuery | undefined;
    set internalValue(value: JobTaskSqlTaskQuery | undefined);
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
}
export interface JobTaskSqlTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#alert Job#alert}
    */
    readonly alert?: JobTaskSqlTaskAlert;
    /**
    * dashboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#dashboard Job#dashboard}
    */
    readonly dashboard?: JobTaskSqlTaskDashboard;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobTaskSqlTaskFile;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#query Job#query}
    */
    readonly query?: JobTaskSqlTaskQuery;
}
export declare function jobTaskSqlTaskToTerraform(struct?: JobTaskSqlTaskOutputReference | JobTaskSqlTask): any;
export declare function jobTaskSqlTaskToHclTerraform(struct?: JobTaskSqlTaskOutputReference | JobTaskSqlTask): any;
export declare class JobTaskSqlTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTask | undefined;
    set internalValue(value: JobTaskSqlTask | undefined);
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    private _alert;
    get alert(): JobTaskSqlTaskAlertOutputReference;
    putAlert(value: JobTaskSqlTaskAlert): void;
    resetAlert(): void;
    get alertInput(): JobTaskSqlTaskAlert | undefined;
    private _dashboard;
    get dashboard(): JobTaskSqlTaskDashboardOutputReference;
    putDashboard(value: JobTaskSqlTaskDashboard): void;
    resetDashboard(): void;
    get dashboardInput(): JobTaskSqlTaskDashboard | undefined;
    private _file;
    get file(): JobTaskSqlTaskFileOutputReference;
    putFile(value: JobTaskSqlTaskFile): void;
    resetFile(): void;
    get fileInput(): JobTaskSqlTaskFile | undefined;
    private _query;
    get query(): JobTaskSqlTaskQueryOutputReference;
    putQuery(value: JobTaskSqlTaskQuery): void;
    resetQuery(): void;
    get queryInput(): JobTaskSqlTaskQuery | undefined;
}
export interface JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface JobTaskWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnFailureToTerraform(struct?: JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnFailureToHclTerraform(struct?: JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnFailureOutputReference;
}
export interface JobTaskWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnStartToTerraform(struct?: JobTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnStartToHclTerraform(struct?: JobTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnStartOutputReference;
}
export interface JobTaskWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface JobTaskWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnSuccessToTerraform(struct?: JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnSuccessToHclTerraform(struct?: JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnSuccessOutputReference;
}
export interface JobTaskWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: JobTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: JobTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: JobTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function jobTaskWebhookNotificationsToTerraform(struct?: JobTaskWebhookNotificationsOutputReference | JobTaskWebhookNotifications): any;
export declare function jobTaskWebhookNotificationsToHclTerraform(struct?: JobTaskWebhookNotificationsOutputReference | JobTaskWebhookNotifications): any;
export declare class JobTaskWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskWebhookNotifications | undefined;
    set internalValue(value: JobTaskWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): JobTaskWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): JobTaskWebhookNotificationsOnFailureList;
    putOnFailure(value: JobTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnFailure[] | undefined;
    private _onStart;
    get onStart(): JobTaskWebhookNotificationsOnStartList;
    putOnStart(value: JobTaskWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): JobTaskWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): JobTaskWebhookNotificationsOnSuccessList;
    putOnSuccess(value: JobTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnSuccess[] | undefined;
}
export interface JobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#description Job#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#disable_auto_optimization Job#disable_auto_optimization}
    */
    readonly disableAutoOptimization?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#disabled Job#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#environment_key Job#environment_key}
    */
    readonly environmentKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#existing_cluster_id Job#existing_cluster_id}
    */
    readonly existingClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#job_cluster_key Job#job_cluster_key}
    */
    readonly jobClusterKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#max_retries Job#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#min_retry_interval_millis Job#min_retry_interval_millis}
    */
    readonly minRetryIntervalMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#retry_on_timeout Job#retry_on_timeout}
    */
    readonly retryOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#run_if Job#run_if}
    */
    readonly runIf?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#task_key Job#task_key}
    */
    readonly taskKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#timeout_seconds Job#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * ai_runtime_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#ai_runtime_task Job#ai_runtime_task}
    */
    readonly aiRuntimeTask?: JobTaskAiRuntimeTask;
    /**
    * alert_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#alert_task Job#alert_task}
    */
    readonly alertTask?: JobTaskAlertTask;
    /**
    * clean_rooms_notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#clean_rooms_notebook_task Job#clean_rooms_notebook_task}
    */
    readonly cleanRoomsNotebookTask?: JobTaskCleanRoomsNotebookTask;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#compute Job#compute}
    */
    readonly compute?: JobTaskCompute;
    /**
    * condition_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#condition_task Job#condition_task}
    */
    readonly conditionTask?: JobTaskConditionTask;
    /**
    * dashboard_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#dashboard_task Job#dashboard_task}
    */
    readonly dashboardTask?: JobTaskDashboardTask;
    /**
    * dbt_cloud_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#dbt_cloud_task Job#dbt_cloud_task}
    */
    readonly dbtCloudTask?: JobTaskDbtCloudTask;
    /**
    * dbt_platform_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#dbt_platform_task Job#dbt_platform_task}
    */
    readonly dbtPlatformTask?: JobTaskDbtPlatformTask;
    /**
    * dbt_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#dbt_task Job#dbt_task}
    */
    readonly dbtTask?: JobTaskDbtTask;
    /**
    * depends_on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#depends_on Job#depends_on}
    */
    readonly dependsOn?: JobTaskDependsOn[] | cdktn.IResolvable;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#email_notifications Job#email_notifications}
    */
    readonly emailNotifications?: JobTaskEmailNotifications;
    /**
    * for_each_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#for_each_task Job#for_each_task}
    */
    readonly forEachTask?: JobTaskForEachTask;
    /**
    * gen_ai_compute_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#gen_ai_compute_task Job#gen_ai_compute_task}
    */
    readonly genAiComputeTask?: JobTaskGenAiComputeTask;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#health Job#health}
    */
    readonly health?: JobTaskHealth;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobTaskLibrary[] | cdktn.IResolvable;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#new_cluster Job#new_cluster}
    */
    readonly newCluster?: JobTaskNewCluster;
    /**
    * notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#notebook_task Job#notebook_task}
    */
    readonly notebookTask?: JobTaskNotebookTask;
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#notification_settings Job#notification_settings}
    */
    readonly notificationSettings?: JobTaskNotificationSettings;
    /**
    * pipeline_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#pipeline_task Job#pipeline_task}
    */
    readonly pipelineTask?: JobTaskPipelineTask;
    /**
    * power_bi_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#power_bi_task Job#power_bi_task}
    */
    readonly powerBiTask?: JobTaskPowerBiTask;
    /**
    * python_operator_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#python_operator_task Job#python_operator_task}
    */
    readonly pythonOperatorTask?: JobTaskPythonOperatorTask;
    /**
    * python_wheel_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#python_wheel_task Job#python_wheel_task}
    */
    readonly pythonWheelTask?: JobTaskPythonWheelTask;
    /**
    * run_job_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#run_job_task Job#run_job_task}
    */
    readonly runJobTask?: JobTaskRunJobTask;
    /**
    * spark_jar_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#spark_jar_task Job#spark_jar_task}
    */
    readonly sparkJarTask?: JobTaskSparkJarTask;
    /**
    * spark_python_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#spark_python_task Job#spark_python_task}
    */
    readonly sparkPythonTask?: JobTaskSparkPythonTask;
    /**
    * spark_submit_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#spark_submit_task Job#spark_submit_task}
    */
    readonly sparkSubmitTask?: JobTaskSparkSubmitTask;
    /**
    * sql_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#sql_task Job#sql_task}
    */
    readonly sqlTask?: JobTaskSqlTask;
    /**
    * webhook_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#webhook_notifications Job#webhook_notifications}
    */
    readonly webhookNotifications?: JobTaskWebhookNotifications;
}
export declare function jobTaskToTerraform(struct?: JobTask | cdktn.IResolvable): any;
export declare function jobTaskToHclTerraform(struct?: JobTask | cdktn.IResolvable): any;
export declare class JobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTask | cdktn.IResolvable | undefined;
    set internalValue(value: JobTask | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableAutoOptimization?;
    get disableAutoOptimization(): boolean | cdktn.IResolvable;
    set disableAutoOptimization(value: boolean | cdktn.IResolvable);
    resetDisableAutoOptimization(): void;
    get disableAutoOptimizationInput(): boolean | cdktn.IResolvable | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentKey?;
    get environmentKey(): string;
    set environmentKey(value: string);
    resetEnvironmentKey(): void;
    get environmentKeyInput(): string | undefined;
    private _existingClusterId?;
    get existingClusterId(): string;
    set existingClusterId(value: string);
    resetExistingClusterId(): void;
    get existingClusterIdInput(): string | undefined;
    private _jobClusterKey?;
    get jobClusterKey(): string;
    set jobClusterKey(value: string);
    resetJobClusterKey(): void;
    get jobClusterKeyInput(): string | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minRetryIntervalMillis?;
    get minRetryIntervalMillis(): number;
    set minRetryIntervalMillis(value: number);
    resetMinRetryIntervalMillis(): void;
    get minRetryIntervalMillisInput(): number | undefined;
    private _retryOnTimeout?;
    get retryOnTimeout(): boolean | cdktn.IResolvable;
    set retryOnTimeout(value: boolean | cdktn.IResolvable);
    resetRetryOnTimeout(): void;
    get retryOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _runIf?;
    get runIf(): string;
    set runIf(value: string);
    resetRunIf(): void;
    get runIfInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _aiRuntimeTask;
    get aiRuntimeTask(): JobTaskAiRuntimeTaskOutputReference;
    putAiRuntimeTask(value: JobTaskAiRuntimeTask): void;
    resetAiRuntimeTask(): void;
    get aiRuntimeTaskInput(): JobTaskAiRuntimeTask | undefined;
    private _alertTask;
    get alertTask(): JobTaskAlertTaskOutputReference;
    putAlertTask(value: JobTaskAlertTask): void;
    resetAlertTask(): void;
    get alertTaskInput(): JobTaskAlertTask | undefined;
    private _cleanRoomsNotebookTask;
    get cleanRoomsNotebookTask(): JobTaskCleanRoomsNotebookTaskOutputReference;
    putCleanRoomsNotebookTask(value: JobTaskCleanRoomsNotebookTask): void;
    resetCleanRoomsNotebookTask(): void;
    get cleanRoomsNotebookTaskInput(): JobTaskCleanRoomsNotebookTask | undefined;
    private _compute;
    get compute(): JobTaskComputeOutputReference;
    putCompute(value: JobTaskCompute): void;
    resetCompute(): void;
    get computeInput(): JobTaskCompute | undefined;
    private _conditionTask;
    get conditionTask(): JobTaskConditionTaskOutputReference;
    putConditionTask(value: JobTaskConditionTask): void;
    resetConditionTask(): void;
    get conditionTaskInput(): JobTaskConditionTask | undefined;
    private _dashboardTask;
    get dashboardTask(): JobTaskDashboardTaskOutputReference;
    putDashboardTask(value: JobTaskDashboardTask): void;
    resetDashboardTask(): void;
    get dashboardTaskInput(): JobTaskDashboardTask | undefined;
    private _dbtCloudTask;
    get dbtCloudTask(): JobTaskDbtCloudTaskOutputReference;
    putDbtCloudTask(value: JobTaskDbtCloudTask): void;
    resetDbtCloudTask(): void;
    get dbtCloudTaskInput(): JobTaskDbtCloudTask | undefined;
    private _dbtPlatformTask;
    get dbtPlatformTask(): JobTaskDbtPlatformTaskOutputReference;
    putDbtPlatformTask(value: JobTaskDbtPlatformTask): void;
    resetDbtPlatformTask(): void;
    get dbtPlatformTaskInput(): JobTaskDbtPlatformTask | undefined;
    private _dbtTask;
    get dbtTask(): JobTaskDbtTaskOutputReference;
    putDbtTask(value: JobTaskDbtTask): void;
    resetDbtTask(): void;
    get dbtTaskInput(): JobTaskDbtTask | undefined;
    private _dependsOn;
    get dependsOn(): JobTaskDependsOnList;
    putDependsOn(value: JobTaskDependsOn[] | cdktn.IResolvable): void;
    resetDependsOn(): void;
    get dependsOnInput(): cdktn.IResolvable | JobTaskDependsOn[] | undefined;
    private _emailNotifications;
    get emailNotifications(): JobTaskEmailNotificationsOutputReference;
    putEmailNotifications(value: JobTaskEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): JobTaskEmailNotifications | undefined;
    private _forEachTask;
    get forEachTask(): JobTaskForEachTaskOutputReference;
    putForEachTask(value: JobTaskForEachTask): void;
    resetForEachTask(): void;
    get forEachTaskInput(): JobTaskForEachTask | undefined;
    private _genAiComputeTask;
    get genAiComputeTask(): JobTaskGenAiComputeTaskOutputReference;
    putGenAiComputeTask(value: JobTaskGenAiComputeTask): void;
    resetGenAiComputeTask(): void;
    get genAiComputeTaskInput(): JobTaskGenAiComputeTask | undefined;
    private _health;
    get health(): JobTaskHealthOutputReference;
    putHealth(value: JobTaskHealth): void;
    resetHealth(): void;
    get healthInput(): JobTaskHealth | undefined;
    private _library;
    get library(): JobTaskLibraryList;
    putLibrary(value: JobTaskLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobTaskLibrary[] | undefined;
    private _newCluster;
    get newCluster(): JobTaskNewClusterOutputReference;
    putNewCluster(value: JobTaskNewCluster): void;
    resetNewCluster(): void;
    get newClusterInput(): JobTaskNewCluster | undefined;
    private _notebookTask;
    get notebookTask(): JobTaskNotebookTaskOutputReference;
    putNotebookTask(value: JobTaskNotebookTask): void;
    resetNotebookTask(): void;
    get notebookTaskInput(): JobTaskNotebookTask | undefined;
    private _notificationSettings;
    get notificationSettings(): JobTaskNotificationSettingsOutputReference;
    putNotificationSettings(value: JobTaskNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): JobTaskNotificationSettings | undefined;
    private _pipelineTask;
    get pipelineTask(): JobTaskPipelineTaskOutputReference;
    putPipelineTask(value: JobTaskPipelineTask): void;
    resetPipelineTask(): void;
    get pipelineTaskInput(): JobTaskPipelineTask | undefined;
    private _powerBiTask;
    get powerBiTask(): JobTaskPowerBiTaskOutputReference;
    putPowerBiTask(value: JobTaskPowerBiTask): void;
    resetPowerBiTask(): void;
    get powerBiTaskInput(): JobTaskPowerBiTask | undefined;
    private _pythonOperatorTask;
    get pythonOperatorTask(): JobTaskPythonOperatorTaskOutputReference;
    putPythonOperatorTask(value: JobTaskPythonOperatorTask): void;
    resetPythonOperatorTask(): void;
    get pythonOperatorTaskInput(): JobTaskPythonOperatorTask | undefined;
    private _pythonWheelTask;
    get pythonWheelTask(): JobTaskPythonWheelTaskOutputReference;
    putPythonWheelTask(value: JobTaskPythonWheelTask): void;
    resetPythonWheelTask(): void;
    get pythonWheelTaskInput(): JobTaskPythonWheelTask | undefined;
    private _runJobTask;
    get runJobTask(): JobTaskRunJobTaskOutputReference;
    putRunJobTask(value: JobTaskRunJobTask): void;
    resetRunJobTask(): void;
    get runJobTaskInput(): JobTaskRunJobTask | undefined;
    private _sparkJarTask;
    get sparkJarTask(): JobTaskSparkJarTaskOutputReference;
    putSparkJarTask(value: JobTaskSparkJarTask): void;
    resetSparkJarTask(): void;
    get sparkJarTaskInput(): JobTaskSparkJarTask | undefined;
    private _sparkPythonTask;
    get sparkPythonTask(): JobTaskSparkPythonTaskOutputReference;
    putSparkPythonTask(value: JobTaskSparkPythonTask): void;
    resetSparkPythonTask(): void;
    get sparkPythonTaskInput(): JobTaskSparkPythonTask | undefined;
    private _sparkSubmitTask;
    get sparkSubmitTask(): JobTaskSparkSubmitTaskOutputReference;
    putSparkSubmitTask(value: JobTaskSparkSubmitTask): void;
    resetSparkSubmitTask(): void;
    get sparkSubmitTaskInput(): JobTaskSparkSubmitTask | undefined;
    private _sqlTask;
    get sqlTask(): JobTaskSqlTaskOutputReference;
    putSqlTask(value: JobTaskSqlTask): void;
    resetSqlTask(): void;
    get sqlTaskInput(): JobTaskSqlTask | undefined;
    private _webhookNotifications;
    get webhookNotifications(): JobTaskWebhookNotificationsOutputReference;
    putWebhookNotifications(value: JobTaskWebhookNotifications): void;
    resetWebhookNotifications(): void;
    get webhookNotificationsInput(): JobTaskWebhookNotifications | undefined;
}
export declare class JobTaskList extends cdktn.ComplexList {
    internalValue?: JobTask[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskOutputReference;
}
export interface JobTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#create Job#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#update Job#update}
    */
    readonly update?: string;
}
export declare function jobTimeoutsToTerraform(struct?: JobTimeouts | cdktn.IResolvable): any;
export declare function jobTimeoutsToHclTerraform(struct?: JobTimeouts | cdktn.IResolvable): any;
export declare class JobTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: JobTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface JobTriggerFileArrival {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerFileArrivalToTerraform(struct?: JobTriggerFileArrivalOutputReference | JobTriggerFileArrival): any;
export declare function jobTriggerFileArrivalToHclTerraform(struct?: JobTriggerFileArrivalOutputReference | JobTriggerFileArrival): any;
export declare class JobTriggerFileArrivalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerFileArrival | undefined;
    set internalValue(value: JobTriggerFileArrival | undefined);
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggerModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#aliases Job#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#condition Job#condition}
    */
    readonly condition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#securable_name Job#securable_name}
    */
    readonly securableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerModelToTerraform(struct?: JobTriggerModelOutputReference | JobTriggerModel): any;
export declare function jobTriggerModelToHclTerraform(struct?: JobTriggerModelOutputReference | JobTriggerModel): any;
export declare class JobTriggerModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerModel | undefined;
    set internalValue(value: JobTriggerModel | undefined);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _securableName?;
    get securableName(): string;
    set securableName(value: string);
    resetSecurableName(): void;
    get securableNameInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggerPeriodic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#interval Job#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#unit Job#unit}
    */
    readonly unit: string;
}
export declare function jobTriggerPeriodicToTerraform(struct?: JobTriggerPeriodicOutputReference | JobTriggerPeriodic): any;
export declare function jobTriggerPeriodicToHclTerraform(struct?: JobTriggerPeriodicOutputReference | JobTriggerPeriodic): any;
export declare class JobTriggerPeriodicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerPeriodic | undefined;
    set internalValue(value: JobTriggerPeriodic | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface JobTriggerSqlCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#sql_query_id Job#sql_query_id}
    */
    readonly sqlQueryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#trigger_mode Job#trigger_mode}
    */
    readonly triggerMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId: string;
}
export declare function jobTriggerSqlConditionToTerraform(struct?: JobTriggerSqlConditionOutputReference | JobTriggerSqlCondition): any;
export declare function jobTriggerSqlConditionToHclTerraform(struct?: JobTriggerSqlConditionOutputReference | JobTriggerSqlCondition): any;
export declare class JobTriggerSqlConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerSqlCondition | undefined;
    set internalValue(value: JobTriggerSqlCondition | undefined);
    private _sqlQueryId?;
    get sqlQueryId(): string;
    set sqlQueryId(value: string);
    get sqlQueryIdInput(): string | undefined;
    private _triggerMode?;
    get triggerMode(): string;
    set triggerMode(value: string);
    resetTriggerMode(): void;
    get triggerModeInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
}
export interface JobTriggerTableUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#condition Job#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#table_names Job#table_names}
    */
    readonly tableNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerTableUpdateToTerraform(struct?: JobTriggerTableUpdateOutputReference | JobTriggerTableUpdate): any;
export declare function jobTriggerTableUpdateToHclTerraform(struct?: JobTriggerTableUpdateOutputReference | JobTriggerTableUpdate): any;
export declare class JobTriggerTableUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerTableUpdate | undefined;
    set internalValue(value: JobTriggerTableUpdate | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _tableNames?;
    get tableNames(): string[];
    set tableNames(value: string[]);
    get tableNamesInput(): string[] | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#pause_status Job#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * file_arrival block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#file_arrival Job#file_arrival}
    */
    readonly fileArrival?: JobTriggerFileArrival;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#model Job#model}
    */
    readonly model?: JobTriggerModel;
    /**
    * periodic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#periodic Job#periodic}
    */
    readonly periodic?: JobTriggerPeriodic;
    /**
    * sql_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#sql_condition Job#sql_condition}
    */
    readonly sqlCondition?: JobTriggerSqlCondition;
    /**
    * table_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#table_update Job#table_update}
    */
    readonly tableUpdate?: JobTriggerTableUpdate;
}
export declare function jobTriggerToTerraform(struct?: JobTriggerOutputReference | JobTrigger): any;
export declare function jobTriggerToHclTerraform(struct?: JobTriggerOutputReference | JobTrigger): any;
export declare class JobTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTrigger | undefined;
    set internalValue(value: JobTrigger | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _fileArrival;
    get fileArrival(): JobTriggerFileArrivalOutputReference;
    putFileArrival(value: JobTriggerFileArrival): void;
    resetFileArrival(): void;
    get fileArrivalInput(): JobTriggerFileArrival | undefined;
    private _model;
    get model(): JobTriggerModelOutputReference;
    putModel(value: JobTriggerModel): void;
    resetModel(): void;
    get modelInput(): JobTriggerModel | undefined;
    private _periodic;
    get periodic(): JobTriggerPeriodicOutputReference;
    putPeriodic(value: JobTriggerPeriodic): void;
    resetPeriodic(): void;
    get periodicInput(): JobTriggerPeriodic | undefined;
    private _sqlCondition;
    get sqlCondition(): JobTriggerSqlConditionOutputReference;
    putSqlCondition(value: JobTriggerSqlCondition): void;
    resetSqlCondition(): void;
    get sqlConditionInput(): JobTriggerSqlCondition | undefined;
    private _tableUpdate;
    get tableUpdate(): JobTriggerTableUpdateOutputReference;
    putTableUpdate(value: JobTriggerTableUpdate): void;
    resetTableUpdate(): void;
    get tableUpdateInput(): JobTriggerTableUpdate | undefined;
}
export interface JobWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface JobWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnFailureToTerraform(struct?: JobWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnFailureToHclTerraform(struct?: JobWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnFailureOutputReference;
}
export interface JobWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnStartToTerraform(struct?: JobWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnStartToHclTerraform(struct?: JobWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnStartOutputReference;
}
export interface JobWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface JobWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnSuccessToTerraform(struct?: JobWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnSuccessToHclTerraform(struct?: JobWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnSuccessOutputReference;
}
export interface JobWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: JobWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function jobWebhookNotificationsToTerraform(struct?: JobWebhookNotificationsOutputReference | JobWebhookNotifications): any;
export declare function jobWebhookNotificationsToHclTerraform(struct?: JobWebhookNotificationsOutputReference | JobWebhookNotifications): any;
export declare class JobWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobWebhookNotifications | undefined;
    set internalValue(value: JobWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): JobWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): JobWebhookNotificationsOnFailureList;
    putOnFailure(value: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | JobWebhookNotificationsOnFailure[] | undefined;
    private _onStart;
    get onStart(): JobWebhookNotificationsOnStartList;
    putOnStart(value: JobWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | JobWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): JobWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | JobWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): JobWebhookNotificationsOnSuccessList;
    putOnSuccess(value: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | JobWebhookNotificationsOnSuccess[] | undefined;
}
