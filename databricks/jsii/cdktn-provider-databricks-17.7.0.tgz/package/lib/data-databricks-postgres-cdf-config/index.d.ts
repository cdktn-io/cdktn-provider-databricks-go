/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresCdfConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_config#name DataDatabricksPostgresCdfConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_config#provider_config DataDatabricksPostgresCdfConfig#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresCdfConfigProviderConfig;
}
export interface DataDatabricksPostgresCdfConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_config#workspace_id DataDatabricksPostgresCdfConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresCdfConfigProviderConfigToTerraform(struct?: DataDatabricksPostgresCdfConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresCdfConfigProviderConfigToHclTerraform(struct?: DataDatabricksPostgresCdfConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresCdfConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCdfConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresCdfConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_config databricks_postgres_cdf_config}
*/
export declare class DataDatabricksPostgresCdfConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_cdf_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresCdfConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresCdfConfig to import
    * @param importFromId The id of the existing DataDatabricksPostgresCdfConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresCdfConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_config databricks_postgres_cdf_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresCdfConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresCdfConfigConfig);
    get catalog(): string;
    get cdfConfigId(): string;
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get postgresSchema(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresCdfConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresCdfConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresCdfConfigProviderConfig | undefined;
    get schema(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
