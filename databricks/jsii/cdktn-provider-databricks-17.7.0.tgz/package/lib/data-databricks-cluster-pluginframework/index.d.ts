/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksClusterPluginframeworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_id DataDatabricksClusterPluginframework#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_info DataDatabricksClusterPluginframework#cluster_info}
    */
    readonly clusterInfo?: DataDatabricksClusterPluginframeworkClusterInfo[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_name DataDatabricksClusterPluginframework#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#provider_config DataDatabricksClusterPluginframework#provider_config}
    */
    readonly providerConfig?: DataDatabricksClusterPluginframeworkProviderConfig;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#max_workers DataDatabricksClusterPluginframework#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#min_workers DataDatabricksClusterPluginframework#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoAutoscaleToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAutoscale | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoAutoscaleToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAutoscale | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoAutoscale | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoAutoscale | cdktn.IResolvable | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoAutoscaleList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoAutoscale[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoAutoscaleOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#availability DataDatabricksClusterPluginframework#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_count DataDatabricksClusterPluginframework#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_iops DataDatabricksClusterPluginframework#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_size DataDatabricksClusterPluginframework#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_throughput DataDatabricksClusterPluginframework#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_type DataDatabricksClusterPluginframework#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#first_on_demand DataDatabricksClusterPluginframework#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#instance_profile_arn DataDatabricksClusterPluginframework#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spot_bid_price_percent DataDatabricksClusterPluginframework#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#zone_id DataDatabricksClusterPluginframework#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoAwsAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoAwsAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes | cdktn.IResolvable | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoAwsAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoAwsAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#log_analytics_primary_key DataDatabricksClusterPluginframework#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#log_analytics_workspace_id DataDatabricksClusterPluginframework#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfoToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo | cdktn.IResolvable | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfoOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#availability DataDatabricksClusterPluginframework#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#capacity_reservation_group DataDatabricksClusterPluginframework#capacity_reservation_group}
    */
    readonly capacityReservationGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#first_on_demand DataDatabricksClusterPluginframework#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#log_analytics_info DataDatabricksClusterPluginframework#log_analytics_info}
    */
    readonly logAnalyticsInfo?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spot_bid_max_price DataDatabricksClusterPluginframework#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoAzureAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoAzureAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes | cdktn.IResolvable | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _capacityReservationGroup?;
    get capacityReservationGroup(): string;
    set capacityReservationGroup(value: string);
    resetCapacityReservationGroup(): void;
    get capacityReservationGroupInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfoList;
    putLogAnalyticsInfo(value: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo[] | cdktn.IResolvable): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesLogAnalyticsInfo[] | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#canned_acl DataDatabricksClusterPluginframework#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_encryption DataDatabricksClusterPluginframework#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#encryption_type DataDatabricksClusterPluginframework#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#endpoint DataDatabricksClusterPluginframework#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#kms_key DataDatabricksClusterPluginframework#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#region DataDatabricksClusterPluginframework#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3ToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3 | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3ToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3 | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3 | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3 | cdktn.IResolvable | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3List extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3OutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#dbfs DataDatabricksClusterPluginframework#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#s3 DataDatabricksClusterPluginframework#s3}
    */
    readonly s3?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#volumes DataDatabricksClusterPluginframework#volumes}
    */
    readonly volumes?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogConfToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf | cdktn.IResolvable | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfsList;
    putDbfs(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs[] | cdktn.IResolvable): void;
    resetDbfs(): void;
    get dbfsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfDbfs[] | undefined;
    private _s3;
    get s3(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3List;
    putS3(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfS3[] | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumesList;
    putVolumes(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfVolumes[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#last_attempted DataDatabricksClusterPluginframework#last_attempted}
    */
    readonly lastAttempted?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#last_exception DataDatabricksClusterPluginframework#last_exception}
    */
    readonly lastException?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogStatusToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoClusterLogStatusToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus | cdktn.IResolvable | undefined);
    private _lastAttempted?;
    get lastAttempted(): number;
    set lastAttempted(value: number);
    resetLastAttempted(): void;
    get lastAttemptedInput(): number | undefined;
    private _lastException?;
    get lastException(): string;
    set lastException(value: string);
    resetLastException(): void;
    get lastExceptionInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatusList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatusOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#password DataDatabricksClusterPluginframework#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#username DataDatabricksClusterPluginframework#username}
    */
    readonly username?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuthToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuthList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuthOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#basic_auth DataDatabricksClusterPluginframework#basic_auth}
    */
    readonly basicAuth?: DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#url DataDatabricksClusterPluginframework#url}
    */
    readonly url?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoDockerImageToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDockerImage | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoDockerImageToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDockerImage | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoDockerImage | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoDockerImage | cdktn.IResolvable | undefined);
    private _basicAuth;
    get basicAuth(): DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuthList;
    putBasicAuth(value: DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth[] | cdktn.IResolvable): void;
    resetBasicAuth(): void;
    get basicAuthInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoDockerImageBasicAuth[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoDockerImageList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoDockerImage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoDockerImageOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#is_spot DataDatabricksClusterPluginframework#is_spot}
    */
    readonly isSpot?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes | cdktn.IResolvable | undefined);
    private _isSpot?;
    get isSpot(): boolean | cdktn.IResolvable;
    set isSpot(value: boolean | cdktn.IResolvable);
    resetIsSpot(): void;
    get isSpotInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoDriver {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#host_private_ip DataDatabricksClusterPluginframework#host_private_ip}
    */
    readonly hostPrivateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#instance_id DataDatabricksClusterPluginframework#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#node_aws_attributes DataDatabricksClusterPluginframework#node_aws_attributes}
    */
    readonly nodeAwsAttributes?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#node_id DataDatabricksClusterPluginframework#node_id}
    */
    readonly nodeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#private_ip DataDatabricksClusterPluginframework#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#public_dns DataDatabricksClusterPluginframework#public_dns}
    */
    readonly publicDns?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#start_timestamp DataDatabricksClusterPluginframework#start_timestamp}
    */
    readonly startTimestamp?: number;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoDriverToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDriver | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoDriverToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDriver | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoDriverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoDriver | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoDriver | cdktn.IResolvable | undefined);
    private _hostPrivateIp?;
    get hostPrivateIp(): string;
    set hostPrivateIp(value: string);
    resetHostPrivateIp(): void;
    get hostPrivateIpInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _nodeAwsAttributes;
    get nodeAwsAttributes(): DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributesList;
    putNodeAwsAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes[] | cdktn.IResolvable): void;
    resetNodeAwsAttributes(): void;
    get nodeAwsAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoDriverNodeAwsAttributes[] | undefined;
    private _nodeId?;
    get nodeId(): string;
    set nodeId(value: string);
    resetNodeId(): void;
    get nodeIdInput(): string | undefined;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    private _publicDns?;
    get publicDns(): string;
    set publicDns(value: string);
    resetPublicDns(): void;
    get publicDnsInput(): string | undefined;
    private _startTimestamp?;
    get startTimestamp(): number;
    set startTimestamp(value: number);
    resetStartTimestamp(): void;
    get startTimestampInput(): number | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoDriverList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoDriver[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoDriverOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#alternate_node_type_ids DataDatabricksClusterPluginframework#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility | cdktn.IResolvable | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibilityList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibilityOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#is_spot DataDatabricksClusterPluginframework#is_spot}
    */
    readonly isSpot?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes | cdktn.IResolvable | undefined);
    private _isSpot?;
    get isSpot(): boolean | cdktn.IResolvable;
    set isSpot(value: boolean | cdktn.IResolvable);
    resetIsSpot(): void;
    get isSpotInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoExecutors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#host_private_ip DataDatabricksClusterPluginframework#host_private_ip}
    */
    readonly hostPrivateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#instance_id DataDatabricksClusterPluginframework#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#node_aws_attributes DataDatabricksClusterPluginframework#node_aws_attributes}
    */
    readonly nodeAwsAttributes?: DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#node_id DataDatabricksClusterPluginframework#node_id}
    */
    readonly nodeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#private_ip DataDatabricksClusterPluginframework#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#public_dns DataDatabricksClusterPluginframework#public_dns}
    */
    readonly publicDns?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#start_timestamp DataDatabricksClusterPluginframework#start_timestamp}
    */
    readonly startTimestamp?: number;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoExecutorsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoExecutors | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoExecutorsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoExecutors | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoExecutorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoExecutors | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoExecutors | cdktn.IResolvable | undefined);
    private _hostPrivateIp?;
    get hostPrivateIp(): string;
    set hostPrivateIp(value: string);
    resetHostPrivateIp(): void;
    get hostPrivateIpInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _nodeAwsAttributes;
    get nodeAwsAttributes(): DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributesList;
    putNodeAwsAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes[] | cdktn.IResolvable): void;
    resetNodeAwsAttributes(): void;
    get nodeAwsAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoExecutorsNodeAwsAttributes[] | undefined;
    private _nodeId?;
    get nodeId(): string;
    set nodeId(value: string);
    resetNodeId(): void;
    get nodeIdInput(): string | undefined;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    private _publicDns?;
    get publicDns(): string;
    set publicDns(value: string);
    resetPublicDns(): void;
    get publicDnsInput(): string | undefined;
    private _startTimestamp?;
    get startTimestamp(): number;
    set startTimestamp(value: number);
    resetStartTimestamp(): void;
    get startTimestampInput(): number | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoExecutorsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoExecutors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoExecutorsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#availability DataDatabricksClusterPluginframework#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#boot_disk_size DataDatabricksClusterPluginframework#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#confidential_compute_type DataDatabricksClusterPluginframework#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#first_on_demand DataDatabricksClusterPluginframework#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#google_service_account DataDatabricksClusterPluginframework#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#local_ssd_count DataDatabricksClusterPluginframework#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#use_preemptible_executors DataDatabricksClusterPluginframework#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#zone_id DataDatabricksClusterPluginframework#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoGcpAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoGcpAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes | cdktn.IResolvable | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoGcpAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoGcpAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfssToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfssToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfssList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfssOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsFileToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsFileToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFileList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFileOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#canned_acl DataDatabricksClusterPluginframework#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_encryption DataDatabricksClusterPluginframework#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#encryption_type DataDatabricksClusterPluginframework#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#endpoint DataDatabricksClusterPluginframework#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#kms_key DataDatabricksClusterPluginframework#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#region DataDatabricksClusterPluginframework#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3ToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3 | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3ToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3 | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3 | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3 | cdktn.IResolvable | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3List extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3OutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspaceToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspaceList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspaceOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoInitScripts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#abfss DataDatabricksClusterPluginframework#abfss}
    */
    readonly abfss?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#dbfs DataDatabricksClusterPluginframework#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#file DataDatabricksClusterPluginframework#file}
    */
    readonly file?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#gcs DataDatabricksClusterPluginframework#gcs}
    */
    readonly gcs?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#s3 DataDatabricksClusterPluginframework#s3}
    */
    readonly s3?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#volumes DataDatabricksClusterPluginframework#volumes}
    */
    readonly volumes?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#workspace DataDatabricksClusterPluginframework#workspace}
    */
    readonly workspace?: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoInitScriptsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfssList;
    putAbfss(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss[] | cdktn.IResolvable): void;
    resetAbfss(): void;
    get abfssInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScriptsAbfss[] | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfsList;
    putDbfs(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs[] | cdktn.IResolvable): void;
    resetDbfs(): void;
    get dbfsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScriptsDbfs[] | undefined;
    private _file;
    get file(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFileList;
    putFile(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile[] | cdktn.IResolvable): void;
    resetFile(): void;
    get fileInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScriptsFile[] | undefined;
    private _gcs;
    get gcs(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcsList;
    putGcs(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs[] | cdktn.IResolvable): void;
    resetGcs(): void;
    get gcsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScriptsGcs[] | undefined;
    private _s3;
    get s3(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3List;
    putS3(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScriptsS3[] | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumesList;
    putVolumes(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScriptsVolumes[] | undefined;
    private _workspace;
    get workspace(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspaceList;
    putWorkspace(value: DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace[] | cdktn.IResolvable): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScriptsWorkspace[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#max_workers DataDatabricksClusterPluginframework#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#min_workers DataDatabricksClusterPluginframework#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAutoscaleToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAutoscaleToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale | cdktn.IResolvable | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscaleList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscaleOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#availability DataDatabricksClusterPluginframework#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_count DataDatabricksClusterPluginframework#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_iops DataDatabricksClusterPluginframework#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_size DataDatabricksClusterPluginframework#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_throughput DataDatabricksClusterPluginframework#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ebs_volume_type DataDatabricksClusterPluginframework#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#first_on_demand DataDatabricksClusterPluginframework#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#instance_profile_arn DataDatabricksClusterPluginframework#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spot_bid_price_percent DataDatabricksClusterPluginframework#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#zone_id DataDatabricksClusterPluginframework#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes | cdktn.IResolvable | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#log_analytics_primary_key DataDatabricksClusterPluginframework#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#log_analytics_workspace_id DataDatabricksClusterPluginframework#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfoToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo | cdktn.IResolvable | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfoOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#availability DataDatabricksClusterPluginframework#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#capacity_reservation_group DataDatabricksClusterPluginframework#capacity_reservation_group}
    */
    readonly capacityReservationGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#first_on_demand DataDatabricksClusterPluginframework#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#log_analytics_info DataDatabricksClusterPluginframework#log_analytics_info}
    */
    readonly logAnalyticsInfo?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spot_bid_max_price DataDatabricksClusterPluginframework#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes | cdktn.IResolvable | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _capacityReservationGroup?;
    get capacityReservationGroup(): string;
    set capacityReservationGroup(value: string);
    resetCapacityReservationGroup(): void;
    get capacityReservationGroupInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfoList;
    putLogAnalyticsInfo(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo[] | cdktn.IResolvable): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesLogAnalyticsInfo[] | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#canned_acl DataDatabricksClusterPluginframework#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_encryption DataDatabricksClusterPluginframework#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#encryption_type DataDatabricksClusterPluginframework#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#endpoint DataDatabricksClusterPluginframework#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#kms_key DataDatabricksClusterPluginframework#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#region DataDatabricksClusterPluginframework#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3ToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3 | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3ToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3 | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3 | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3 | cdktn.IResolvable | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3List extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3OutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#dbfs DataDatabricksClusterPluginframework#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#s3 DataDatabricksClusterPluginframework#s3}
    */
    readonly s3?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#volumes DataDatabricksClusterPluginframework#volumes}
    */
    readonly volumes?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf | cdktn.IResolvable | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfsList;
    putDbfs(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs[] | cdktn.IResolvable): void;
    resetDbfs(): void;
    get dbfsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfDbfs[] | undefined;
    private _s3;
    get s3(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3List;
    putS3(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfS3[] | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumesList;
    putVolumes(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfVolumes[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#password DataDatabricksClusterPluginframework#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#username DataDatabricksClusterPluginframework#username}
    */
    readonly username?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuthToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth | cdktn.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuthList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuthOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#basic_auth DataDatabricksClusterPluginframework#basic_auth}
    */
    readonly basicAuth?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#url DataDatabricksClusterPluginframework#url}
    */
    readonly url?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage | cdktn.IResolvable | undefined);
    private _basicAuth;
    get basicAuth(): DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuthList;
    putBasicAuth(value: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth[] | cdktn.IResolvable): void;
    resetBasicAuth(): void;
    get basicAuthInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageBasicAuth[] | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#alternate_node_type_ids DataDatabricksClusterPluginframework#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility | cdktn.IResolvable | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibilityList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibilityOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#availability DataDatabricksClusterPluginframework#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#boot_disk_size DataDatabricksClusterPluginframework#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#confidential_compute_type DataDatabricksClusterPluginframework#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#first_on_demand DataDatabricksClusterPluginframework#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#google_service_account DataDatabricksClusterPluginframework#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#local_ssd_count DataDatabricksClusterPluginframework#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#use_preemptible_executors DataDatabricksClusterPluginframework#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#zone_id DataDatabricksClusterPluginframework#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes | cdktn.IResolvable | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfssToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfssToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfssList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfssOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFileToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFileToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFileList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFileOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#canned_acl DataDatabricksClusterPluginframework#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_encryption DataDatabricksClusterPluginframework#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#encryption_type DataDatabricksClusterPluginframework#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#endpoint DataDatabricksClusterPluginframework#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#kms_key DataDatabricksClusterPluginframework#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#region DataDatabricksClusterPluginframework#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3ToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3 | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3ToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3 | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3 | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3 | cdktn.IResolvable | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3List extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3OutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumesToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumesToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumesOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#destination DataDatabricksClusterPluginframework#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspaceToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspaceList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspaceOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#abfss DataDatabricksClusterPluginframework#abfss}
    */
    readonly abfss?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#dbfs DataDatabricksClusterPluginframework#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#file DataDatabricksClusterPluginframework#file}
    */
    readonly file?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#gcs DataDatabricksClusterPluginframework#gcs}
    */
    readonly gcs?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#s3 DataDatabricksClusterPluginframework#s3}
    */
    readonly s3?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#volumes DataDatabricksClusterPluginframework#volumes}
    */
    readonly volumes?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#workspace DataDatabricksClusterPluginframework#workspace}
    */
    readonly workspace?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfssList;
    putAbfss(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss[] | cdktn.IResolvable): void;
    resetAbfss(): void;
    get abfssInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsAbfss[] | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfsList;
    putDbfs(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs[] | cdktn.IResolvable): void;
    resetDbfs(): void;
    get dbfsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsDbfs[] | undefined;
    private _file;
    get file(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFileList;
    putFile(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile[] | cdktn.IResolvable): void;
    resetFile(): void;
    get fileInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsFile[] | undefined;
    private _gcs;
    get gcs(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcsList;
    putGcs(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs[] | cdktn.IResolvable): void;
    resetGcs(): void;
    get gcsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsGcs[] | undefined;
    private _s3;
    get s3(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3List;
    putS3(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsS3[] | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumesList;
    putVolumes(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes[] | cdktn.IResolvable): void;
    resetVolumes(): void;
    get volumesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsVolumes[] | undefined;
    private _workspace;
    get workspace(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspaceList;
    putWorkspace(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace[] | cdktn.IResolvable): void;
    resetWorkspace(): void;
    get workspaceInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsWorkspace[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#alternate_node_type_ids DataDatabricksClusterPluginframework#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility | cdktn.IResolvable | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibilityList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibilityOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#jobs DataDatabricksClusterPluginframework#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#notebooks DataDatabricksClusterPluginframework#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClientsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClientsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClientsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#clients DataDatabricksClusterPluginframework#clients}
    */
    readonly clients: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType | cdktn.IResolvable | undefined);
    private _clients;
    get clients(): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClientsList;
    putClients(value: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients[] | cdktn.IResolvable): void;
    get clientsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeClients[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#apply_policy_default_values DataDatabricksClusterPluginframework#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#autoscale DataDatabricksClusterPluginframework#autoscale}
    */
    readonly autoscale?: DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#autotermination_minutes DataDatabricksClusterPluginframework#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#aws_attributes DataDatabricksClusterPluginframework#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#azure_attributes DataDatabricksClusterPluginframework#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_log_conf DataDatabricksClusterPluginframework#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_name DataDatabricksClusterPluginframework#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#custom_tags DataDatabricksClusterPluginframework#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#data_security_mode DataDatabricksClusterPluginframework#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#docker_image DataDatabricksClusterPluginframework#docker_image}
    */
    readonly dockerImage?: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#driver_instance_pool_id DataDatabricksClusterPluginframework#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#driver_node_type_flexibility DataDatabricksClusterPluginframework#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#driver_node_type_id DataDatabricksClusterPluginframework#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_elastic_disk DataDatabricksClusterPluginframework#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_local_disk_encryption DataDatabricksClusterPluginframework#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#gcp_attributes DataDatabricksClusterPluginframework#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#init_scripts DataDatabricksClusterPluginframework#init_scripts}
    */
    readonly initScripts?: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#instance_pool_id DataDatabricksClusterPluginframework#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#is_single_node DataDatabricksClusterPluginframework#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#kind DataDatabricksClusterPluginframework#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#node_type_id DataDatabricksClusterPluginframework#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#num_workers DataDatabricksClusterPluginframework#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#policy_id DataDatabricksClusterPluginframework#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#remote_disk_throughput DataDatabricksClusterPluginframework#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#runtime_engine DataDatabricksClusterPluginframework#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#single_user_name DataDatabricksClusterPluginframework#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spark_conf DataDatabricksClusterPluginframework#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spark_env_vars DataDatabricksClusterPluginframework#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spark_version DataDatabricksClusterPluginframework#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ssh_public_keys DataDatabricksClusterPluginframework#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#total_initial_remote_disk_size DataDatabricksClusterPluginframework#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#use_ml_runtime DataDatabricksClusterPluginframework#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#worker_node_type_flexibility DataDatabricksClusterPluginframework#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#workload_type DataDatabricksClusterPluginframework#workload_type}
    */
    readonly workloadType?: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpec | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoSpecToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoSpec | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoSpec | cdktn.IResolvable | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscaleList;
    putAutoscale(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale[] | cdktn.IResolvable): void;
    resetAutoscale(): void;
    get autoscaleInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecAutoscale[] | undefined;
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributesList;
    putAwsAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes[] | cdktn.IResolvable): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecAwsAttributes[] | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributesList;
    putAzureAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes[] | cdktn.IResolvable): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecAzureAttributes[] | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConfList;
    putClusterLogConf(value: DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf[] | cdktn.IResolvable): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecClusterLogConf[] | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImageList;
    putDockerImage(value: DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage[] | cdktn.IResolvable): void;
    resetDockerImage(): void;
    get dockerImageInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecDockerImage[] | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibilityList;
    putDriverNodeTypeFlexibility(value: DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility[] | cdktn.IResolvable): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecDriverNodeTypeFlexibility[] | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributesList;
    putGcpAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes[] | cdktn.IResolvable): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecGcpAttributes[] | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksClusterPluginframeworkClusterInfoSpecInitScriptsList;
    putInitScripts(value: DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecInitScripts[] | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibilityList;
    putWorkerNodeTypeFlexibility(value: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility[] | cdktn.IResolvable): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecWorkerNodeTypeFlexibility[] | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadTypeList;
    putWorkloadType(value: DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType[] | cdktn.IResolvable): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpecWorkloadType[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoSpecList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoSpec[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoSpecOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoTerminationReason {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#code DataDatabricksClusterPluginframework#code}
    */
    readonly code?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#parameters DataDatabricksClusterPluginframework#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#type DataDatabricksClusterPluginframework#type}
    */
    readonly type?: string;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoTerminationReasonToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoTerminationReason | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoTerminationReasonToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoTerminationReason | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoTerminationReasonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoTerminationReason | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoTerminationReason | cdktn.IResolvable | undefined);
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoTerminationReasonList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoTerminationReason[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoTerminationReasonOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#alternate_node_type_ids DataDatabricksClusterPluginframework#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility | cdktn.IResolvable | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibilityList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibilityOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#jobs DataDatabricksClusterPluginframework#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#notebooks DataDatabricksClusterPluginframework#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClientsToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClientsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClientsOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfoWorkloadType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#clients DataDatabricksClusterPluginframework#clients}
    */
    readonly clients: DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoWorkloadType | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfoWorkloadType | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfoWorkloadType | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfoWorkloadType | cdktn.IResolvable | undefined);
    private _clients;
    get clients(): DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClientsList;
    putClients(value: DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients[] | cdktn.IResolvable): void;
    get clientsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeClients[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfoWorkloadType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeOutputReference;
}
export interface DataDatabricksClusterPluginframeworkClusterInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#autoscale DataDatabricksClusterPluginframework#autoscale}
    */
    readonly autoscale?: DataDatabricksClusterPluginframeworkClusterInfoAutoscale[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#autotermination_minutes DataDatabricksClusterPluginframework#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#aws_attributes DataDatabricksClusterPluginframework#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#azure_attributes DataDatabricksClusterPluginframework#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_cores DataDatabricksClusterPluginframework#cluster_cores}
    */
    readonly clusterCores?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_id DataDatabricksClusterPluginframework#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_log_conf DataDatabricksClusterPluginframework#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_log_status DataDatabricksClusterPluginframework#cluster_log_status}
    */
    readonly clusterLogStatus?: DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_memory_mb DataDatabricksClusterPluginframework#cluster_memory_mb}
    */
    readonly clusterMemoryMb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_name DataDatabricksClusterPluginframework#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#cluster_source DataDatabricksClusterPluginframework#cluster_source}
    */
    readonly clusterSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#creator_user_name DataDatabricksClusterPluginframework#creator_user_name}
    */
    readonly creatorUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#custom_tags DataDatabricksClusterPluginframework#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#data_security_mode DataDatabricksClusterPluginframework#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#default_tags DataDatabricksClusterPluginframework#default_tags}
    */
    readonly defaultTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#docker_image DataDatabricksClusterPluginframework#docker_image}
    */
    readonly dockerImage?: DataDatabricksClusterPluginframeworkClusterInfoDockerImage[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#driver DataDatabricksClusterPluginframework#driver}
    */
    readonly driver?: DataDatabricksClusterPluginframeworkClusterInfoDriver[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#driver_instance_pool_id DataDatabricksClusterPluginframework#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#driver_node_type_flexibility DataDatabricksClusterPluginframework#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#driver_node_type_id DataDatabricksClusterPluginframework#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_elastic_disk DataDatabricksClusterPluginframework#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#enable_local_disk_encryption DataDatabricksClusterPluginframework#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#executors DataDatabricksClusterPluginframework#executors}
    */
    readonly executors?: DataDatabricksClusterPluginframeworkClusterInfoExecutors[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#gcp_attributes DataDatabricksClusterPluginframework#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#init_scripts DataDatabricksClusterPluginframework#init_scripts}
    */
    readonly initScripts?: DataDatabricksClusterPluginframeworkClusterInfoInitScripts[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#instance_pool_id DataDatabricksClusterPluginframework#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#is_single_node DataDatabricksClusterPluginframework#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#jdbc_port DataDatabricksClusterPluginframework#jdbc_port}
    */
    readonly jdbcPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#kind DataDatabricksClusterPluginframework#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#last_restarted_time DataDatabricksClusterPluginframework#last_restarted_time}
    */
    readonly lastRestartedTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#last_state_loss_time DataDatabricksClusterPluginframework#last_state_loss_time}
    */
    readonly lastStateLossTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#node_type_id DataDatabricksClusterPluginframework#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#num_workers DataDatabricksClusterPluginframework#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#policy_id DataDatabricksClusterPluginframework#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#remote_disk_throughput DataDatabricksClusterPluginframework#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#runtime_engine DataDatabricksClusterPluginframework#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#single_user_name DataDatabricksClusterPluginframework#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spark_conf DataDatabricksClusterPluginframework#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spark_context_id DataDatabricksClusterPluginframework#spark_context_id}
    */
    readonly sparkContextId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spark_env_vars DataDatabricksClusterPluginframework#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spark_version DataDatabricksClusterPluginframework#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#spec DataDatabricksClusterPluginframework#spec}
    */
    readonly spec?: DataDatabricksClusterPluginframeworkClusterInfoSpec[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#ssh_public_keys DataDatabricksClusterPluginframework#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#start_time DataDatabricksClusterPluginframework#start_time}
    */
    readonly startTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#state DataDatabricksClusterPluginframework#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#state_message DataDatabricksClusterPluginframework#state_message}
    */
    readonly stateMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#terminated_time DataDatabricksClusterPluginframework#terminated_time}
    */
    readonly terminatedTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#termination_reason DataDatabricksClusterPluginframework#termination_reason}
    */
    readonly terminationReason?: DataDatabricksClusterPluginframeworkClusterInfoTerminationReason[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#total_initial_remote_disk_size DataDatabricksClusterPluginframework#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#use_ml_runtime DataDatabricksClusterPluginframework#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#worker_node_type_flexibility DataDatabricksClusterPluginframework#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#workload_type DataDatabricksClusterPluginframework#workload_type}
    */
    readonly workloadType?: DataDatabricksClusterPluginframeworkClusterInfoWorkloadType[] | cdktn.IResolvable;
}
export declare function dataDatabricksClusterPluginframeworkClusterInfoToTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfo | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkClusterInfoToHclTerraform(struct?: DataDatabricksClusterPluginframeworkClusterInfo | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkClusterInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterPluginframeworkClusterInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkClusterInfo | cdktn.IResolvable | undefined);
    private _autoscale;
    get autoscale(): DataDatabricksClusterPluginframeworkClusterInfoAutoscaleList;
    putAutoscale(value: DataDatabricksClusterPluginframeworkClusterInfoAutoscale[] | cdktn.IResolvable): void;
    resetAutoscale(): void;
    get autoscaleInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoAutoscale[] | undefined;
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksClusterPluginframeworkClusterInfoAwsAttributesList;
    putAwsAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes[] | cdktn.IResolvable): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoAwsAttributes[] | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksClusterPluginframeworkClusterInfoAzureAttributesList;
    putAzureAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes[] | cdktn.IResolvable): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoAzureAttributes[] | undefined;
    private _clusterCores?;
    get clusterCores(): number;
    set clusterCores(value: number);
    resetClusterCores(): void;
    get clusterCoresInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogConfList;
    putClusterLogConf(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf[] | cdktn.IResolvable): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoClusterLogConf[] | undefined;
    private _clusterLogStatus;
    get clusterLogStatus(): DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatusList;
    putClusterLogStatus(value: DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus[] | cdktn.IResolvable): void;
    resetClusterLogStatus(): void;
    get clusterLogStatusInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoClusterLogStatus[] | undefined;
    private _clusterMemoryMb?;
    get clusterMemoryMb(): number;
    set clusterMemoryMb(value: number);
    resetClusterMemoryMb(): void;
    get clusterMemoryMbInput(): number | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _clusterSource?;
    get clusterSource(): string;
    set clusterSource(value: string);
    resetClusterSource(): void;
    get clusterSourceInput(): string | undefined;
    private _creatorUserName?;
    get creatorUserName(): string;
    set creatorUserName(value: string);
    resetCreatorUserName(): void;
    get creatorUserNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _defaultTags?;
    get defaultTags(): {
        [key: string]: string;
    };
    set defaultTags(value: {
        [key: string]: string;
    });
    resetDefaultTags(): void;
    get defaultTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksClusterPluginframeworkClusterInfoDockerImageList;
    putDockerImage(value: DataDatabricksClusterPluginframeworkClusterInfoDockerImage[] | cdktn.IResolvable): void;
    resetDockerImage(): void;
    get dockerImageInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoDockerImage[] | undefined;
    private _driver;
    get driver(): DataDatabricksClusterPluginframeworkClusterInfoDriverList;
    putDriver(value: DataDatabricksClusterPluginframeworkClusterInfoDriver[] | cdktn.IResolvable): void;
    resetDriver(): void;
    get driverInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoDriver[] | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibilityList;
    putDriverNodeTypeFlexibility(value: DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility[] | cdktn.IResolvable): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoDriverNodeTypeFlexibility[] | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _executors;
    get executors(): DataDatabricksClusterPluginframeworkClusterInfoExecutorsList;
    putExecutors(value: DataDatabricksClusterPluginframeworkClusterInfoExecutors[] | cdktn.IResolvable): void;
    resetExecutors(): void;
    get executorsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoExecutors[] | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksClusterPluginframeworkClusterInfoGcpAttributesList;
    putGcpAttributes(value: DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes[] | cdktn.IResolvable): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoGcpAttributes[] | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksClusterPluginframeworkClusterInfoInitScriptsList;
    putInitScripts(value: DataDatabricksClusterPluginframeworkClusterInfoInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoInitScripts[] | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _jdbcPort?;
    get jdbcPort(): number;
    set jdbcPort(value: number);
    resetJdbcPort(): void;
    get jdbcPortInput(): number | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _lastRestartedTime?;
    get lastRestartedTime(): number;
    set lastRestartedTime(value: number);
    resetLastRestartedTime(): void;
    get lastRestartedTimeInput(): number | undefined;
    private _lastStateLossTime?;
    get lastStateLossTime(): number;
    set lastStateLossTime(value: number);
    resetLastStateLossTime(): void;
    get lastStateLossTimeInput(): number | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkContextId?;
    get sparkContextId(): number;
    set sparkContextId(value: number);
    resetSparkContextId(): void;
    get sparkContextIdInput(): number | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _spec;
    get spec(): DataDatabricksClusterPluginframeworkClusterInfoSpecList;
    putSpec(value: DataDatabricksClusterPluginframeworkClusterInfoSpec[] | cdktn.IResolvable): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoSpec[] | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _stateMessage?;
    get stateMessage(): string;
    set stateMessage(value: string);
    resetStateMessage(): void;
    get stateMessageInput(): string | undefined;
    private _terminatedTime?;
    get terminatedTime(): number;
    set terminatedTime(value: number);
    resetTerminatedTime(): void;
    get terminatedTimeInput(): number | undefined;
    private _terminationReason;
    get terminationReason(): DataDatabricksClusterPluginframeworkClusterInfoTerminationReasonList;
    putTerminationReason(value: DataDatabricksClusterPluginframeworkClusterInfoTerminationReason[] | cdktn.IResolvable): void;
    resetTerminationReason(): void;
    get terminationReasonInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoTerminationReason[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibilityList;
    putWorkerNodeTypeFlexibility(value: DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility[] | cdktn.IResolvable): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoWorkerNodeTypeFlexibility[] | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksClusterPluginframeworkClusterInfoWorkloadTypeList;
    putWorkloadType(value: DataDatabricksClusterPluginframeworkClusterInfoWorkloadType[] | cdktn.IResolvable): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfoWorkloadType[] | undefined;
}
export declare class DataDatabricksClusterPluginframeworkClusterInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterPluginframeworkClusterInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterPluginframeworkClusterInfoOutputReference;
}
export interface DataDatabricksClusterPluginframeworkProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#workspace_id DataDatabricksClusterPluginframework#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksClusterPluginframeworkProviderConfigToTerraform(struct?: DataDatabricksClusterPluginframeworkProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksClusterPluginframeworkProviderConfigToHclTerraform(struct?: DataDatabricksClusterPluginframeworkProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksClusterPluginframeworkProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterPluginframeworkProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterPluginframeworkProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework databricks_cluster_pluginframework}
*/
export declare class DataDatabricksClusterPluginframework extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_cluster_pluginframework";
    /**
    * Generates CDKTN code for importing a DataDatabricksClusterPluginframework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksClusterPluginframework to import
    * @param importFromId The id of the existing DataDatabricksClusterPluginframework that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksClusterPluginframework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/cluster_pluginframework databricks_cluster_pluginframework} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksClusterPluginframeworkConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksClusterPluginframeworkConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterInfo;
    get clusterInfo(): DataDatabricksClusterPluginframeworkClusterInfoList;
    putClusterInfo(value: DataDatabricksClusterPluginframeworkClusterInfo[] | cdktn.IResolvable): void;
    resetClusterInfo(): void;
    get clusterInfoInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkClusterInfo[] | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksClusterPluginframeworkProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksClusterPluginframeworkProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksClusterPluginframeworkProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
