/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresCdfStatusesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#page_size DataDatabricksPostgresCdfStatuses#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#parent DataDatabricksPostgresCdfStatuses#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#provider_config DataDatabricksPostgresCdfStatuses#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresCdfStatusesProviderConfig;
}
export interface DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#workspace_id DataDatabricksPostgresCdfStatuses#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresCdfStatusesCdfStatusesProviderConfigToTerraform(struct?: DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresCdfStatusesCdfStatusesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresCdfStatusesCdfStatuses {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#name DataDatabricksPostgresCdfStatuses#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#provider_config DataDatabricksPostgresCdfStatuses#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig;
}
export declare function dataDatabricksPostgresCdfStatusesCdfStatusesToTerraform(struct?: DataDatabricksPostgresCdfStatusesCdfStatuses): any;
export declare function dataDatabricksPostgresCdfStatusesCdfStatusesToHclTerraform(struct?: DataDatabricksPostgresCdfStatusesCdfStatuses): any;
export declare class DataDatabricksPostgresCdfStatusesCdfStatusesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresCdfStatusesCdfStatuses | undefined;
    set internalValue(value: DataDatabricksPostgresCdfStatusesCdfStatuses | undefined);
    get committedLsn(): string;
    get createTime(): string;
    get lastSyncTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get postgresTable(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresCdfStatusesCdfStatusesProviderConfig | undefined;
    get state(): string;
    get statusDetail(): string;
    get ucTable(): string;
}
export declare class DataDatabricksPostgresCdfStatusesCdfStatusesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresCdfStatusesCdfStatuses[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresCdfStatusesCdfStatusesOutputReference;
}
export interface DataDatabricksPostgresCdfStatusesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#workspace_id DataDatabricksPostgresCdfStatuses#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresCdfStatusesProviderConfigToTerraform(struct?: DataDatabricksPostgresCdfStatusesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresCdfStatusesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresCdfStatusesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresCdfStatusesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCdfStatusesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresCdfStatusesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses databricks_postgres_cdf_statuses}
*/
export declare class DataDatabricksPostgresCdfStatuses extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_cdf_statuses";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresCdfStatuses resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresCdfStatuses to import
    * @param importFromId The id of the existing DataDatabricksPostgresCdfStatuses that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresCdfStatuses to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/postgres_cdf_statuses databricks_postgres_cdf_statuses} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresCdfStatusesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresCdfStatusesConfig);
    private _cdfStatuses;
    get cdfStatuses(): DataDatabricksPostgresCdfStatusesCdfStatusesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresCdfStatusesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresCdfStatusesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresCdfStatusesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
