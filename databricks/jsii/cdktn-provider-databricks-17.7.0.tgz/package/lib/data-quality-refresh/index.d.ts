/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataQualityRefreshConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/data_quality_refresh#object_id DataQualityRefresh#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/data_quality_refresh#object_type DataQualityRefresh#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/data_quality_refresh#provider_config DataQualityRefresh#provider_config}
    */
    readonly providerConfig?: DataQualityRefreshProviderConfig;
}
export interface DataQualityRefreshProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/data_quality_refresh#workspace_id DataQualityRefresh#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataQualityRefreshProviderConfigToTerraform(struct?: DataQualityRefreshProviderConfig | cdktn.IResolvable): any;
export declare function dataQualityRefreshProviderConfigToHclTerraform(struct?: DataQualityRefreshProviderConfig | cdktn.IResolvable): any;
export declare class DataQualityRefreshProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataQualityRefreshProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataQualityRefreshProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/data_quality_refresh databricks_data_quality_refresh}
*/
export declare class DataQualityRefresh extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_data_quality_refresh";
    /**
    * Generates CDKTN code for importing a DataQualityRefresh resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataQualityRefresh to import
    * @param importFromId The id of the existing DataQualityRefresh that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/data_quality_refresh#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataQualityRefresh to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/resources/data_quality_refresh databricks_data_quality_refresh} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataQualityRefreshConfig
    */
    constructor(scope: Construct, id: string, config: DataQualityRefreshConfig);
    get endTimeMs(): number;
    get message(): string;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataQualityRefreshProviderConfigOutputReference;
    putProviderConfig(value: DataQualityRefreshProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataQualityRefreshProviderConfig | undefined;
    get refreshId(): number;
    get startTimeMs(): number;
    get state(): string;
    get trigger(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
