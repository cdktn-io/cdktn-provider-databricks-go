/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksEndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints#page_size DataDatabricksEndpoints#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints#parent DataDatabricksEndpoints#parent}
    */
    readonly parent: string;
}
export interface DataDatabricksEndpointsItemsAzurePrivateEndpointInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints#private_endpoint_name DataDatabricksEndpoints#private_endpoint_name}
    */
    readonly privateEndpointName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints#private_endpoint_resource_guid DataDatabricksEndpoints#private_endpoint_resource_guid}
    */
    readonly privateEndpointResourceGuid: string;
}
export declare function dataDatabricksEndpointsItemsAzurePrivateEndpointInfoToTerraform(struct?: DataDatabricksEndpointsItemsAzurePrivateEndpointInfo): any;
export declare function dataDatabricksEndpointsItemsAzurePrivateEndpointInfoToHclTerraform(struct?: DataDatabricksEndpointsItemsAzurePrivateEndpointInfo): any;
export declare class DataDatabricksEndpointsItemsAzurePrivateEndpointInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEndpointsItemsAzurePrivateEndpointInfo | undefined;
    set internalValue(value: DataDatabricksEndpointsItemsAzurePrivateEndpointInfo | undefined);
    private _privateEndpointName?;
    get privateEndpointName(): string;
    set privateEndpointName(value: string);
    get privateEndpointNameInput(): string | undefined;
    private _privateEndpointResourceGuid?;
    get privateEndpointResourceGuid(): string;
    set privateEndpointResourceGuid(value: string);
    get privateEndpointResourceGuidInput(): string | undefined;
    get privateEndpointResourceId(): string;
    get privateLinkServiceId(): string;
}
export interface DataDatabricksEndpointsItems {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints#name DataDatabricksEndpoints#name}
    */
    readonly name: string;
}
export declare function dataDatabricksEndpointsItemsToTerraform(struct?: DataDatabricksEndpointsItems): any;
export declare function dataDatabricksEndpointsItemsToHclTerraform(struct?: DataDatabricksEndpointsItems): any;
export declare class DataDatabricksEndpointsItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksEndpointsItems | undefined;
    set internalValue(value: DataDatabricksEndpointsItems | undefined);
    get accountId(): string;
    private _azurePrivateEndpointInfo;
    get azurePrivateEndpointInfo(): DataDatabricksEndpointsItemsAzurePrivateEndpointInfoOutputReference;
    get createTime(): string;
    get displayName(): string;
    get endpointId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get state(): string;
    get useCase(): string;
}
export declare class DataDatabricksEndpointsItemsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksEndpointsItems[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksEndpointsItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints databricks_endpoints}
*/
export declare class DataDatabricksEndpoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_endpoints";
    /**
    * Generates CDKTN code for importing a DataDatabricksEndpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksEndpoints to import
    * @param importFromId The id of the existing DataDatabricksEndpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksEndpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.122.0/docs/data-sources/endpoints databricks_endpoints} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksEndpointsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksEndpointsConfig);
    private _items;
    get items(): DataDatabricksEndpointsItemsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
