/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#aibi_dashboard_embedding_access_policy WorkspaceSettingV2#aibi_dashboard_embedding_access_policy}
    */
    readonly aibiDashboardEmbeddingAccessPolicy?: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#aibi_dashboard_embedding_approved_domains WorkspaceSettingV2#aibi_dashboard_embedding_approved_domains}
    */
    readonly aibiDashboardEmbeddingApprovedDomains?: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#automatic_cluster_update_workspace WorkspaceSettingV2#automatic_cluster_update_workspace}
    */
    readonly automaticClusterUpdateWorkspace?: WorkspaceSettingV2AutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#boolean_val WorkspaceSettingV2#boolean_val}
    */
    readonly booleanVal?: WorkspaceSettingV2BooleanVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#effective_aibi_dashboard_embedding_access_policy WorkspaceSettingV2#effective_aibi_dashboard_embedding_access_policy}
    */
    readonly effectiveAibiDashboardEmbeddingAccessPolicy?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#effective_aibi_dashboard_embedding_approved_domains WorkspaceSettingV2#effective_aibi_dashboard_embedding_approved_domains}
    */
    readonly effectiveAibiDashboardEmbeddingApprovedDomains?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#effective_automatic_cluster_update_workspace WorkspaceSettingV2#effective_automatic_cluster_update_workspace}
    */
    readonly effectiveAutomaticClusterUpdateWorkspace?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#effective_personal_compute WorkspaceSettingV2#effective_personal_compute}
    */
    readonly effectivePersonalCompute?: WorkspaceSettingV2EffectivePersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#effective_restrict_workspace_admins WorkspaceSettingV2#effective_restrict_workspace_admins}
    */
    readonly effectiveRestrictWorkspaceAdmins?: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#integer_val WorkspaceSettingV2#integer_val}
    */
    readonly integerVal?: WorkspaceSettingV2IntegerVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#name WorkspaceSettingV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#personal_compute WorkspaceSettingV2#personal_compute}
    */
    readonly personalCompute?: WorkspaceSettingV2PersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#provider_config WorkspaceSettingV2#provider_config}
    */
    readonly providerConfig?: WorkspaceSettingV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#restrict_workspace_admins WorkspaceSettingV2#restrict_workspace_admins}
    */
    readonly restrictWorkspaceAdmins?: WorkspaceSettingV2RestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#string_val WorkspaceSettingV2#string_val}
    */
    readonly stringVal?: WorkspaceSettingV2StringVal;
}
export interface WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#access_policy_type WorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function workspaceSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function workspaceSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#approved_domains WorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function workspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function workspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#forced_for_compliance_mode WorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#unavailable_for_disabled_entitlement WorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#unavailable_for_non_enterprise_tier WorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#hours WorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#minutes WorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#day_of_week WorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#frequency WorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#window_start_time WorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#week_day_based_schedule WorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface WorkspaceSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#can_toggle WorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#enabled WorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#enablement_details WorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#maintenance_window WorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#restart_even_if_no_updates_available WorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function workspaceSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2BooleanValToTerraform(struct?: WorkspaceSettingV2BooleanVal | cdktn.IResolvable): any;
export declare function workspaceSettingV2BooleanValToHclTerraform(struct?: WorkspaceSettingV2BooleanVal | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2BooleanVal | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2BooleanVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#access_policy_type WorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#approved_domains WorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#forced_for_compliance_mode WorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#unavailable_for_disabled_entitlement WorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#unavailable_for_non_enterprise_tier WorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#hours WorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#minutes WorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#day_of_week WorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#frequency WorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#window_start_time WorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#week_day_based_schedule WorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#can_toggle WorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#enabled WorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#enablement_details WorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#maintenance_window WorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#restart_even_if_no_updates_available WorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function workspaceSettingV2EffectiveBooleanValToTerraform(struct?: WorkspaceSettingV2EffectiveBooleanVal): any;
export declare function workspaceSettingV2EffectiveBooleanValToHclTerraform(struct?: WorkspaceSettingV2EffectiveBooleanVal): any;
export declare class WorkspaceSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface WorkspaceSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function workspaceSettingV2EffectiveIntegerValToTerraform(struct?: WorkspaceSettingV2EffectiveIntegerVal): any;
export declare function workspaceSettingV2EffectiveIntegerValToHclTerraform(struct?: WorkspaceSettingV2EffectiveIntegerVal): any;
export declare class WorkspaceSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface WorkspaceSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2EffectivePersonalComputeToTerraform(struct?: WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectivePersonalComputeToHclTerraform(struct?: WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#status WorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function workspaceSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function workspaceSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface WorkspaceSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2EffectiveStringValToTerraform(struct?: WorkspaceSettingV2EffectiveStringVal): any;
export declare function workspaceSettingV2EffectiveStringValToHclTerraform(struct?: WorkspaceSettingV2EffectiveStringVal): any;
export declare class WorkspaceSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2EffectiveStringVal | undefined;
    set internalValue(value: WorkspaceSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface WorkspaceSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function workspaceSettingV2IntegerValToTerraform(struct?: WorkspaceSettingV2IntegerVal | cdktn.IResolvable): any;
export declare function workspaceSettingV2IntegerValToHclTerraform(struct?: WorkspaceSettingV2IntegerVal | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2IntegerVal | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2IntegerVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface WorkspaceSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2PersonalComputeToTerraform(struct?: WorkspaceSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare function workspaceSettingV2PersonalComputeToHclTerraform(struct?: WorkspaceSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2PersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2PersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface WorkspaceSettingV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#workspace_id WorkspaceSettingV2#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function workspaceSettingV2ProviderConfigToTerraform(struct?: WorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceSettingV2ProviderConfigToHclTerraform(struct?: WorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface WorkspaceSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#status WorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function workspaceSettingV2RestrictWorkspaceAdminsToTerraform(struct?: WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function workspaceSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface WorkspaceSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#value WorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function workspaceSettingV2StringValToTerraform(struct?: WorkspaceSettingV2StringVal | cdktn.IResolvable): any;
export declare function workspaceSettingV2StringValToHclTerraform(struct?: WorkspaceSettingV2StringVal | cdktn.IResolvable): any;
export declare class WorkspaceSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceSettingV2StringVal | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceSettingV2StringVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2 databricks_workspace_setting_v2}
*/
export declare class WorkspaceSettingV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_setting_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceSettingV2 to import
    * @param importFromId The id of the existing WorkspaceSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/workspace_setting_v2 databricks_workspace_setting_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceSettingV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: WorkspaceSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    putAibiDashboardEmbeddingAccessPolicy(value: WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy): void;
    resetAibiDashboardEmbeddingAccessPolicy(): void;
    get aibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | WorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    putAibiDashboardEmbeddingApprovedDomains(value: WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains): void;
    resetAibiDashboardEmbeddingApprovedDomains(): void;
    get aibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | WorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): WorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    putAutomaticClusterUpdateWorkspace(value: WorkspaceSettingV2AutomaticClusterUpdateWorkspace): void;
    resetAutomaticClusterUpdateWorkspace(): void;
    get automaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | WorkspaceSettingV2AutomaticClusterUpdateWorkspace | undefined;
    private _booleanVal;
    get booleanVal(): WorkspaceSettingV2BooleanValOutputReference;
    putBooleanVal(value: WorkspaceSettingV2BooleanVal): void;
    resetBooleanVal(): void;
    get booleanValInput(): cdktn.IResolvable | WorkspaceSettingV2BooleanVal | undefined;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    putEffectiveAibiDashboardEmbeddingAccessPolicy(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): void;
    resetEffectiveAibiDashboardEmbeddingAccessPolicy(): void;
    get effectiveAibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    putEffectiveAibiDashboardEmbeddingApprovedDomains(value: WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): void;
    resetEffectiveAibiDashboardEmbeddingApprovedDomains(): void;
    get effectiveAibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    putEffectiveAutomaticClusterUpdateWorkspace(value: WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace): void;
    resetEffectiveAutomaticClusterUpdateWorkspace(): void;
    get effectiveAutomaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): WorkspaceSettingV2EffectiveBooleanValOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): WorkspaceSettingV2EffectiveIntegerValOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): WorkspaceSettingV2EffectivePersonalComputeOutputReference;
    putEffectivePersonalCompute(value: WorkspaceSettingV2EffectivePersonalCompute): void;
    resetEffectivePersonalCompute(): void;
    get effectivePersonalComputeInput(): cdktn.IResolvable | WorkspaceSettingV2EffectivePersonalCompute | undefined;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): WorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    putEffectiveRestrictWorkspaceAdmins(value: WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins): void;
    resetEffectiveRestrictWorkspaceAdmins(): void;
    get effectiveRestrictWorkspaceAdminsInput(): cdktn.IResolvable | WorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    private _effectiveStringVal;
    get effectiveStringVal(): WorkspaceSettingV2EffectiveStringValOutputReference;
    private _integerVal;
    get integerVal(): WorkspaceSettingV2IntegerValOutputReference;
    putIntegerVal(value: WorkspaceSettingV2IntegerVal): void;
    resetIntegerVal(): void;
    get integerValInput(): cdktn.IResolvable | WorkspaceSettingV2IntegerVal | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _personalCompute;
    get personalCompute(): WorkspaceSettingV2PersonalComputeOutputReference;
    putPersonalCompute(value: WorkspaceSettingV2PersonalCompute): void;
    resetPersonalCompute(): void;
    get personalComputeInput(): cdktn.IResolvable | WorkspaceSettingV2PersonalCompute | undefined;
    private _providerConfig;
    get providerConfig(): WorkspaceSettingV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceSettingV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceSettingV2ProviderConfig | undefined;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): WorkspaceSettingV2RestrictWorkspaceAdminsOutputReference;
    putRestrictWorkspaceAdmins(value: WorkspaceSettingV2RestrictWorkspaceAdmins): void;
    resetRestrictWorkspaceAdmins(): void;
    get restrictWorkspaceAdminsInput(): cdktn.IResolvable | WorkspaceSettingV2RestrictWorkspaceAdmins | undefined;
    private _stringVal;
    get stringVal(): WorkspaceSettingV2StringValOutputReference;
    putStringVal(value: WorkspaceSettingV2StringVal): void;
    resetStringVal(): void;
    get stringValInput(): cdktn.IResolvable | WorkspaceSettingV2StringVal | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
