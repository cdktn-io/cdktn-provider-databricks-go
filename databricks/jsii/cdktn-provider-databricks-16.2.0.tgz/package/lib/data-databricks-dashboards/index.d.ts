/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDashboardsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards#dashboard_name_contains DataDatabricksDashboards#dashboard_name_contains}
    */
    readonly dashboardNameContains?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards#provider_config DataDatabricksDashboards#provider_config}
    */
    readonly providerConfig?: DataDatabricksDashboardsProviderConfig;
}
export interface DataDatabricksDashboardsDashboards {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards#display_name DataDatabricksDashboards#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards#serialized_dashboard DataDatabricksDashboards#serialized_dashboard}
    */
    readonly serializedDashboard?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards#warehouse_id DataDatabricksDashboards#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksDashboardsDashboardsToTerraform(struct?: DataDatabricksDashboardsDashboards): any;
export declare function dataDatabricksDashboardsDashboardsToHclTerraform(struct?: DataDatabricksDashboardsDashboards): any;
export declare class DataDatabricksDashboardsDashboardsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDashboardsDashboards | undefined;
    set internalValue(value: DataDatabricksDashboardsDashboards | undefined);
    get createTime(): string;
    get dashboardId(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get etag(): string;
    get lifecycleState(): string;
    get parentPath(): string;
    get path(): string;
    private _serializedDashboard?;
    get serializedDashboard(): string;
    set serializedDashboard(value: string);
    resetSerializedDashboard(): void;
    get serializedDashboardInput(): string | undefined;
    get updateTime(): string;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export declare class DataDatabricksDashboardsDashboardsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksDashboardsDashboards[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDashboardsDashboardsOutputReference;
}
export interface DataDatabricksDashboardsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards#workspace_id DataDatabricksDashboards#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksDashboardsProviderConfigToTerraform(struct?: DataDatabricksDashboardsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDashboardsProviderConfigToHclTerraform(struct?: DataDatabricksDashboardsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDashboardsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDashboardsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDashboardsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards databricks_dashboards}
*/
export declare class DataDatabricksDashboards extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_dashboards";
    /**
    * Generates CDKTN code for importing a DataDatabricksDashboards resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDashboards to import
    * @param importFromId The id of the existing DataDatabricksDashboards that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDashboards to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/dashboards databricks_dashboards} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDashboardsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksDashboardsConfig);
    private _dashboardNameContains?;
    get dashboardNameContains(): string;
    set dashboardNameContains(value: string);
    resetDashboardNameContains(): void;
    get dashboardNameContainsInput(): string | undefined;
    private _dashboards;
    get dashboards(): DataDatabricksDashboardsDashboardsList;
    private _providerConfig;
    get providerConfig(): DataDatabricksDashboardsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDashboardsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDashboardsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
