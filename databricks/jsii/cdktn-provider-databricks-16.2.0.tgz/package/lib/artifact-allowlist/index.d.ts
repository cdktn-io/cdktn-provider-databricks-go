/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ArtifactAllowlistConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#artifact_type ArtifactAllowlist#artifact_type}
    */
    readonly artifactType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#created_at ArtifactAllowlist#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#created_by ArtifactAllowlist#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#id ArtifactAllowlist#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#metastore_id ArtifactAllowlist#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * artifact_matcher block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#artifact_matcher ArtifactAllowlist#artifact_matcher}
    */
    readonly artifactMatcher: ArtifactAllowlistArtifactMatcher[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#provider_config ArtifactAllowlist#provider_config}
    */
    readonly providerConfig?: ArtifactAllowlistProviderConfig;
}
export interface ArtifactAllowlistArtifactMatcher {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#artifact ArtifactAllowlist#artifact}
    */
    readonly artifact: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#match_type ArtifactAllowlist#match_type}
    */
    readonly matchType: string;
}
export declare function artifactAllowlistArtifactMatcherToTerraform(struct?: ArtifactAllowlistArtifactMatcher | cdktn.IResolvable): any;
export declare function artifactAllowlistArtifactMatcherToHclTerraform(struct?: ArtifactAllowlistArtifactMatcher | cdktn.IResolvable): any;
export declare class ArtifactAllowlistArtifactMatcherOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ArtifactAllowlistArtifactMatcher | cdktn.IResolvable | undefined;
    set internalValue(value: ArtifactAllowlistArtifactMatcher | cdktn.IResolvable | undefined);
    private _artifact?;
    get artifact(): string;
    set artifact(value: string);
    get artifactInput(): string | undefined;
    private _matchType?;
    get matchType(): string;
    set matchType(value: string);
    get matchTypeInput(): string | undefined;
}
export declare class ArtifactAllowlistArtifactMatcherList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ArtifactAllowlistArtifactMatcher[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ArtifactAllowlistArtifactMatcherOutputReference;
}
export interface ArtifactAllowlistProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#workspace_id ArtifactAllowlist#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function artifactAllowlistProviderConfigToTerraform(struct?: ArtifactAllowlistProviderConfigOutputReference | ArtifactAllowlistProviderConfig): any;
export declare function artifactAllowlistProviderConfigToHclTerraform(struct?: ArtifactAllowlistProviderConfigOutputReference | ArtifactAllowlistProviderConfig): any;
export declare class ArtifactAllowlistProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ArtifactAllowlistProviderConfig | undefined;
    set internalValue(value: ArtifactAllowlistProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist databricks_artifact_allowlist}
*/
export declare class ArtifactAllowlist extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_artifact_allowlist";
    /**
    * Generates CDKTN code for importing a ArtifactAllowlist resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ArtifactAllowlist to import
    * @param importFromId The id of the existing ArtifactAllowlist that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ArtifactAllowlist to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/artifact_allowlist databricks_artifact_allowlist} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ArtifactAllowlistConfig
    */
    constructor(scope: Construct, id: string, config: ArtifactAllowlistConfig);
    private _artifactType?;
    get artifactType(): string;
    set artifactType(value: string);
    get artifactTypeInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _artifactMatcher;
    get artifactMatcher(): ArtifactAllowlistArtifactMatcherList;
    putArtifactMatcher(value: ArtifactAllowlistArtifactMatcher[] | cdktn.IResolvable): void;
    get artifactMatcherInput(): cdktn.IResolvable | ArtifactAllowlistArtifactMatcher[] | undefined;
    private _providerConfig;
    get providerConfig(): ArtifactAllowlistProviderConfigOutputReference;
    putProviderConfig(value: ArtifactAllowlistProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ArtifactAllowlistProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
