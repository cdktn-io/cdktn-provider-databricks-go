/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SqlAlertConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#created_at SqlAlert#created_at}
    */
    readonly createdAt?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#id SqlAlert#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#name SqlAlert#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#parent SqlAlert#parent}
    */
    readonly parent?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#query_id SqlAlert#query_id}
    */
    readonly queryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#rearm SqlAlert#rearm}
    */
    readonly rearm?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#updated_at SqlAlert#updated_at}
    */
    readonly updatedAt?: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#options SqlAlert#options}
    */
    readonly options: SqlAlertOptions;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#provider_config SqlAlert#provider_config}
    */
    readonly providerConfig?: SqlAlertProviderConfig;
}
export interface SqlAlertOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#column SqlAlert#column}
    */
    readonly column: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#custom_body SqlAlert#custom_body}
    */
    readonly customBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#custom_subject SqlAlert#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#empty_result_state SqlAlert#empty_result_state}
    */
    readonly emptyResultState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#muted SqlAlert#muted}
    */
    readonly muted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#op SqlAlert#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#value SqlAlert#value}
    */
    readonly value: string;
}
export declare function sqlAlertOptionsToTerraform(struct?: SqlAlertOptionsOutputReference | SqlAlertOptions): any;
export declare function sqlAlertOptionsToHclTerraform(struct?: SqlAlertOptionsOutputReference | SqlAlertOptions): any;
export declare class SqlAlertOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlAlertOptions | undefined;
    set internalValue(value: SqlAlertOptions | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _customBody?;
    get customBody(): string;
    set customBody(value: string);
    resetCustomBody(): void;
    get customBodyInput(): string | undefined;
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _emptyResultState?;
    get emptyResultState(): string;
    set emptyResultState(value: string);
    resetEmptyResultState(): void;
    get emptyResultStateInput(): string | undefined;
    private _muted?;
    get muted(): boolean | cdktn.IResolvable;
    set muted(value: boolean | cdktn.IResolvable);
    resetMuted(): void;
    get mutedInput(): boolean | cdktn.IResolvable | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface SqlAlertProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#workspace_id SqlAlert#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function sqlAlertProviderConfigToTerraform(struct?: SqlAlertProviderConfigOutputReference | SqlAlertProviderConfig): any;
export declare function sqlAlertProviderConfigToHclTerraform(struct?: SqlAlertProviderConfigOutputReference | SqlAlertProviderConfig): any;
export declare class SqlAlertProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlAlertProviderConfig | undefined;
    set internalValue(value: SqlAlertProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert databricks_sql_alert}
*/
export declare class SqlAlert extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sql_alert";
    /**
    * Generates CDKTN code for importing a SqlAlert resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlAlert to import
    * @param importFromId The id of the existing SqlAlert that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlAlert to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/sql_alert databricks_sql_alert} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlAlertConfig
    */
    constructor(scope: Construct, id: string, config: SqlAlertConfig);
    private _createdAt?;
    get createdAt(): string;
    set createdAt(value: string);
    resetCreatedAt(): void;
    get createdAtInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
    private _rearm?;
    get rearm(): number;
    set rearm(value: number);
    resetRearm(): void;
    get rearmInput(): number | undefined;
    private _updatedAt?;
    get updatedAt(): string;
    set updatedAt(value: string);
    resetUpdatedAt(): void;
    get updatedAtInput(): string | undefined;
    private _options;
    get options(): SqlAlertOptionsOutputReference;
    putOptions(value: SqlAlertOptions): void;
    get optionsInput(): SqlAlertOptions | undefined;
    private _providerConfig;
    get providerConfig(): SqlAlertProviderConfigOutputReference;
    putProviderConfig(value: SqlAlertProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SqlAlertProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
