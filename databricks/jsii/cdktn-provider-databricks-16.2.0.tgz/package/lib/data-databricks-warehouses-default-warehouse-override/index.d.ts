/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWarehousesDefaultWarehouseOverrideConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/warehouses_default_warehouse_override#name DataDatabricksWarehousesDefaultWarehouseOverride#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/warehouses_default_warehouse_override#provider_config DataDatabricksWarehousesDefaultWarehouseOverride#provider_config}
    */
    readonly providerConfig?: DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig;
}
export interface DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/warehouses_default_warehouse_override#workspace_id DataDatabricksWarehousesDefaultWarehouseOverride#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksWarehousesDefaultWarehouseOverrideProviderConfigToTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWarehousesDefaultWarehouseOverrideProviderConfigToHclTerraform(struct?: DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/warehouses_default_warehouse_override databricks_warehouses_default_warehouse_override}
*/
export declare class DataDatabricksWarehousesDefaultWarehouseOverride extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_warehouses_default_warehouse_override";
    /**
    * Generates CDKTN code for importing a DataDatabricksWarehousesDefaultWarehouseOverride resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWarehousesDefaultWarehouseOverride to import
    * @param importFromId The id of the existing DataDatabricksWarehousesDefaultWarehouseOverride that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/warehouses_default_warehouse_override#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWarehousesDefaultWarehouseOverride to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/warehouses_default_warehouse_override databricks_warehouses_default_warehouse_override} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWarehousesDefaultWarehouseOverrideConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWarehousesDefaultWarehouseOverrideConfig);
    get defaultWarehouseOverrideId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWarehousesDefaultWarehouseOverrideProviderConfig | undefined;
    get type(): string;
    get warehouseId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
