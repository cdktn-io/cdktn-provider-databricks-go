/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CredentialConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#comment Credential#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#created_at Credential#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#created_by Credential#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#force_destroy Credential#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#force_update Credential#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#full_name Credential#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#id Credential#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#isolation_mode Credential#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#metastore_id Credential#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#name Credential#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#owner Credential#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#purpose Credential#purpose}
    */
    readonly purpose: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#read_only Credential#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#skip_validation Credential#skip_validation}
    */
    readonly skipValidation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#updated_at Credential#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#updated_by Credential#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#used_for_managed_storage Credential#used_for_managed_storage}
    */
    readonly usedForManagedStorage?: boolean | cdktn.IResolvable;
    /**
    * aws_iam_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#aws_iam_role Credential#aws_iam_role}
    */
    readonly awsIamRole?: CredentialAwsIamRole;
    /**
    * azure_managed_identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#azure_managed_identity Credential#azure_managed_identity}
    */
    readonly azureManagedIdentity?: CredentialAzureManagedIdentity;
    /**
    * azure_service_principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#azure_service_principal Credential#azure_service_principal}
    */
    readonly azureServicePrincipal?: CredentialAzureServicePrincipal;
    /**
    * databricks_gcp_service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#databricks_gcp_service_account Credential#databricks_gcp_service_account}
    */
    readonly databricksGcpServiceAccount?: CredentialDatabricksGcpServiceAccount;
}
export interface CredentialAwsIamRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#external_id Credential#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#role_arn Credential#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#unity_catalog_iam_arn Credential#unity_catalog_iam_arn}
    */
    readonly unityCatalogIamArn?: string;
}
export declare function credentialAwsIamRoleToTerraform(struct?: CredentialAwsIamRoleOutputReference | CredentialAwsIamRole): any;
export declare function credentialAwsIamRoleToHclTerraform(struct?: CredentialAwsIamRoleOutputReference | CredentialAwsIamRole): any;
export declare class CredentialAwsIamRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CredentialAwsIamRole | undefined;
    set internalValue(value: CredentialAwsIamRole | undefined);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _unityCatalogIamArn?;
    get unityCatalogIamArn(): string;
    set unityCatalogIamArn(value: string);
    resetUnityCatalogIamArn(): void;
    get unityCatalogIamArnInput(): string | undefined;
}
export interface CredentialAzureManagedIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#access_connector_id Credential#access_connector_id}
    */
    readonly accessConnectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#credential_id Credential#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#managed_identity_id Credential#managed_identity_id}
    */
    readonly managedIdentityId?: string;
}
export declare function credentialAzureManagedIdentityToTerraform(struct?: CredentialAzureManagedIdentityOutputReference | CredentialAzureManagedIdentity): any;
export declare function credentialAzureManagedIdentityToHclTerraform(struct?: CredentialAzureManagedIdentityOutputReference | CredentialAzureManagedIdentity): any;
export declare class CredentialAzureManagedIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CredentialAzureManagedIdentity | undefined;
    set internalValue(value: CredentialAzureManagedIdentity | undefined);
    private _accessConnectorId?;
    get accessConnectorId(): string;
    set accessConnectorId(value: string);
    get accessConnectorIdInput(): string | undefined;
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _managedIdentityId?;
    get managedIdentityId(): string;
    set managedIdentityId(value: string);
    resetManagedIdentityId(): void;
    get managedIdentityIdInput(): string | undefined;
}
export interface CredentialAzureServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#application_id Credential#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#client_secret Credential#client_secret}
    */
    readonly clientSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#directory_id Credential#directory_id}
    */
    readonly directoryId: string;
}
export declare function credentialAzureServicePrincipalToTerraform(struct?: CredentialAzureServicePrincipalOutputReference | CredentialAzureServicePrincipal): any;
export declare function credentialAzureServicePrincipalToHclTerraform(struct?: CredentialAzureServicePrincipalOutputReference | CredentialAzureServicePrincipal): any;
export declare class CredentialAzureServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CredentialAzureServicePrincipal | undefined;
    set internalValue(value: CredentialAzureServicePrincipal | undefined);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
}
export interface CredentialDatabricksGcpServiceAccount {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#credential_id Credential#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#email Credential#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#private_key_id Credential#private_key_id}
    */
    readonly privateKeyId?: string;
}
export declare function credentialDatabricksGcpServiceAccountToTerraform(struct?: CredentialDatabricksGcpServiceAccountOutputReference | CredentialDatabricksGcpServiceAccount): any;
export declare function credentialDatabricksGcpServiceAccountToHclTerraform(struct?: CredentialDatabricksGcpServiceAccountOutputReference | CredentialDatabricksGcpServiceAccount): any;
export declare class CredentialDatabricksGcpServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CredentialDatabricksGcpServiceAccount | undefined;
    set internalValue(value: CredentialDatabricksGcpServiceAccount | undefined);
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _privateKeyId?;
    get privateKeyId(): string;
    set privateKeyId(value: string);
    resetPrivateKeyId(): void;
    get privateKeyIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential databricks_credential}
*/
export declare class Credential extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_credential";
    /**
    * Generates CDKTN code for importing a Credential resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Credential to import
    * @param importFromId The id of the existing Credential that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Credential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/resources/credential databricks_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CredentialConfig
    */
    constructor(scope: Construct, id: string, config: CredentialConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    get credentialId(): string;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _purpose?;
    get purpose(): string;
    set purpose(value: string);
    get purposeInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _skipValidation?;
    get skipValidation(): boolean | cdktn.IResolvable;
    set skipValidation(value: boolean | cdktn.IResolvable);
    resetSkipValidation(): void;
    get skipValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _usedForManagedStorage?;
    get usedForManagedStorage(): boolean | cdktn.IResolvable;
    set usedForManagedStorage(value: boolean | cdktn.IResolvable);
    resetUsedForManagedStorage(): void;
    get usedForManagedStorageInput(): boolean | cdktn.IResolvable | undefined;
    private _awsIamRole;
    get awsIamRole(): CredentialAwsIamRoleOutputReference;
    putAwsIamRole(value: CredentialAwsIamRole): void;
    resetAwsIamRole(): void;
    get awsIamRoleInput(): CredentialAwsIamRole | undefined;
    private _azureManagedIdentity;
    get azureManagedIdentity(): CredentialAzureManagedIdentityOutputReference;
    putAzureManagedIdentity(value: CredentialAzureManagedIdentity): void;
    resetAzureManagedIdentity(): void;
    get azureManagedIdentityInput(): CredentialAzureManagedIdentity | undefined;
    private _azureServicePrincipal;
    get azureServicePrincipal(): CredentialAzureServicePrincipalOutputReference;
    putAzureServicePrincipal(value: CredentialAzureServicePrincipal): void;
    resetAzureServicePrincipal(): void;
    get azureServicePrincipalInput(): CredentialAzureServicePrincipal | undefined;
    private _databricksGcpServiceAccount;
    get databricksGcpServiceAccount(): CredentialDatabricksGcpServiceAccountOutputReference;
    putDatabricksGcpServiceAccount(value: CredentialDatabricksGcpServiceAccount): void;
    resetDatabricksGcpServiceAccount(): void;
    get databricksGcpServiceAccountInput(): CredentialDatabricksGcpServiceAccount | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
