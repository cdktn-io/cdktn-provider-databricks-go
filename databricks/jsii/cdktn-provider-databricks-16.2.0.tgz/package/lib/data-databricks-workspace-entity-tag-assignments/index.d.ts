/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceEntityTagAssignmentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#entity_id DataDatabricksWorkspaceEntityTagAssignments#entity_id}
    */
    readonly entityId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#entity_type DataDatabricksWorkspaceEntityTagAssignments#entity_type}
    */
    readonly entityType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#page_size DataDatabricksWorkspaceEntityTagAssignments#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#provider_config DataDatabricksWorkspaceEntityTagAssignments#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig;
}
export interface DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#workspace_id DataDatabricksWorkspaceEntityTagAssignments#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksWorkspaceEntityTagAssignmentsProviderConfigToTerraform(struct?: DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceEntityTagAssignmentsProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceEntityTagAssignmentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#workspace_id DataDatabricksWorkspaceEntityTagAssignments#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfigToTerraform(struct?: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceEntityTagAssignmentsTagAssignments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#entity_id DataDatabricksWorkspaceEntityTagAssignments#entity_id}
    */
    readonly entityId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#entity_type DataDatabricksWorkspaceEntityTagAssignments#entity_type}
    */
    readonly entityType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#provider_config DataDatabricksWorkspaceEntityTagAssignments#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#tag_key DataDatabricksWorkspaceEntityTagAssignments#tag_key}
    */
    readonly tagKey: string;
}
export declare function dataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsToTerraform(struct?: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignments): any;
export declare function dataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsToHclTerraform(struct?: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignments): any;
export declare class DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksWorkspaceEntityTagAssignmentsTagAssignments | undefined;
    set internalValue(value: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignments | undefined);
    private _entityId?;
    get entityId(): string;
    set entityId(value: string);
    get entityIdInput(): string | undefined;
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    get entityTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsProviderConfig | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    get tagValue(): string;
}
export declare class DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksWorkspaceEntityTagAssignmentsTagAssignments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments databricks_workspace_entity_tag_assignments}
*/
export declare class DataDatabricksWorkspaceEntityTagAssignments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_entity_tag_assignments";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceEntityTagAssignments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceEntityTagAssignments to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceEntityTagAssignments that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceEntityTagAssignments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/workspace_entity_tag_assignments databricks_workspace_entity_tag_assignments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceEntityTagAssignmentsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceEntityTagAssignmentsConfig);
    private _entityId?;
    get entityId(): string;
    set entityId(value: string);
    get entityIdInput(): string | undefined;
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    get entityTypeInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceEntityTagAssignmentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceEntityTagAssignmentsProviderConfig | undefined;
    private _tagAssignments;
    get tagAssignments(): DataDatabricksWorkspaceEntityTagAssignmentsTagAssignmentsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
