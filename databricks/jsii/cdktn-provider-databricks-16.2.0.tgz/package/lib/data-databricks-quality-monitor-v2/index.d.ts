/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksQualityMonitorV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#object_id DataDatabricksQualityMonitorV2#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#object_type DataDatabricksQualityMonitorV2#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#provider_config DataDatabricksQualityMonitorV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksQualityMonitorV2ProviderConfig;
}
export interface DataDatabricksQualityMonitorV2AnomalyDetectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#excluded_table_full_names DataDatabricksQualityMonitorV2#excluded_table_full_names}
    */
    readonly excludedTableFullNames?: string[];
}
export declare function dataDatabricksQualityMonitorV2AnomalyDetectionConfigToTerraform(struct?: DataDatabricksQualityMonitorV2AnomalyDetectionConfig): any;
export declare function dataDatabricksQualityMonitorV2AnomalyDetectionConfigToHclTerraform(struct?: DataDatabricksQualityMonitorV2AnomalyDetectionConfig): any;
export declare class DataDatabricksQualityMonitorV2AnomalyDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorV2AnomalyDetectionConfig | undefined;
    set internalValue(value: DataDatabricksQualityMonitorV2AnomalyDetectionConfig | undefined);
    private _excludedTableFullNames?;
    get excludedTableFullNames(): string[];
    set excludedTableFullNames(value: string[]);
    resetExcludedTableFullNames(): void;
    get excludedTableFullNamesInput(): string[] | undefined;
    get lastRunId(): string;
    get latestRunStatus(): string;
}
export interface DataDatabricksQualityMonitorV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#workspace_id DataDatabricksQualityMonitorV2#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksQualityMonitorV2ProviderConfigToTerraform(struct?: DataDatabricksQualityMonitorV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorV2ProviderConfigToHclTerraform(struct?: DataDatabricksQualityMonitorV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#column_names DataDatabricksQualityMonitorV2#column_names}
    */
    readonly columnNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#upper_bound DataDatabricksQualityMonitorV2#upper_bound}
    */
    readonly upperBound?: number;
}
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckToTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckToHclTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
    private _upperBound?;
    get upperBound(): number;
    set upperBound(value: number);
    resetUpperBound(): void;
    get upperBoundInput(): number | undefined;
}
export interface DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#column_names DataDatabricksQualityMonitorV2#column_names}
    */
    readonly columnNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#lower_bound DataDatabricksQualityMonitorV2#lower_bound}
    */
    readonly lowerBound?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#upper_bound DataDatabricksQualityMonitorV2#upper_bound}
    */
    readonly upperBound?: number;
}
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckToTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckToHclTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
    private _lowerBound?;
    get lowerBound(): number;
    set lowerBound(value: number);
    resetLowerBound(): void;
    get lowerBoundInput(): number | undefined;
    private _upperBound?;
    get upperBound(): number;
    set upperBound(value: number);
    resetUpperBound(): void;
    get upperBoundInput(): number | undefined;
}
export interface DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#column_names DataDatabricksQualityMonitorV2#column_names}
    */
    readonly columnNames?: string[];
}
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckToTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable): any;
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckToHclTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable): any;
export declare class DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | cdktn.IResolvable | undefined);
    private _columnNames?;
    get columnNames(): string[];
    set columnNames(value: string[]);
    resetColumnNames(): void;
    get columnNamesInput(): string[] | undefined;
}
export interface DataDatabricksQualityMonitorV2ValidityCheckConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#name DataDatabricksQualityMonitorV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#percent_null_validity_check DataDatabricksQualityMonitorV2#percent_null_validity_check}
    */
    readonly percentNullValidityCheck?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#range_validity_check DataDatabricksQualityMonitorV2#range_validity_check}
    */
    readonly rangeValidityCheck?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#uniqueness_validity_check DataDatabricksQualityMonitorV2#uniqueness_validity_check}
    */
    readonly uniquenessValidityCheck?: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck;
}
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsToTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurations): any;
export declare function dataDatabricksQualityMonitorV2ValidityCheckConfigurationsToHclTerraform(struct?: DataDatabricksQualityMonitorV2ValidityCheckConfigurations): any;
export declare class DataDatabricksQualityMonitorV2ValidityCheckConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksQualityMonitorV2ValidityCheckConfigurations | undefined;
    set internalValue(value: DataDatabricksQualityMonitorV2ValidityCheckConfigurations | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _percentNullValidityCheck;
    get percentNullValidityCheck(): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheckOutputReference;
    putPercentNullValidityCheck(value: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck): void;
    resetPercentNullValidityCheck(): void;
    get percentNullValidityCheckInput(): cdktn.IResolvable | DataDatabricksQualityMonitorV2ValidityCheckConfigurationsPercentNullValidityCheck | undefined;
    private _rangeValidityCheck;
    get rangeValidityCheck(): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheckOutputReference;
    putRangeValidityCheck(value: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck): void;
    resetRangeValidityCheck(): void;
    get rangeValidityCheckInput(): cdktn.IResolvable | DataDatabricksQualityMonitorV2ValidityCheckConfigurationsRangeValidityCheck | undefined;
    private _uniquenessValidityCheck;
    get uniquenessValidityCheck(): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheckOutputReference;
    putUniquenessValidityCheck(value: DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck): void;
    resetUniquenessValidityCheck(): void;
    get uniquenessValidityCheckInput(): cdktn.IResolvable | DataDatabricksQualityMonitorV2ValidityCheckConfigurationsUniquenessValidityCheck | undefined;
}
export declare class DataDatabricksQualityMonitorV2ValidityCheckConfigurationsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksQualityMonitorV2ValidityCheckConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2 databricks_quality_monitor_v2}
*/
export declare class DataDatabricksQualityMonitorV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_quality_monitor_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksQualityMonitorV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksQualityMonitorV2 to import
    * @param importFromId The id of the existing DataDatabricksQualityMonitorV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksQualityMonitorV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/quality_monitor_v2 databricks_quality_monitor_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksQualityMonitorV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksQualityMonitorV2Config);
    private _anomalyDetectionConfig;
    get anomalyDetectionConfig(): DataDatabricksQualityMonitorV2AnomalyDetectionConfigOutputReference;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksQualityMonitorV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksQualityMonitorV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksQualityMonitorV2ProviderConfig | undefined;
    private _validityCheckConfigurations;
    get validityCheckConfigurations(): DataDatabricksQualityMonitorV2ValidityCheckConfigurationsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
