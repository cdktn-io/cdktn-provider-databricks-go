/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksFeatureEngineeringFeaturesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#page_size DataDatabricksFeatureEngineeringFeatures#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#provider_config DataDatabricksFeatureEngineeringFeatures#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringFeaturesProviderConfig;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesEntities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#name DataDatabricksFeatureEngineeringFeatures#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesEntitiesToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesEntities): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesEntitiesToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesEntities): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesEntities | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesEntities | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesEntitiesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksFeatureEngineeringFeaturesFeaturesEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeaturesFeaturesEntitiesOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#relative_sd DataDatabricksFeatureEngineeringFeatures#relative_sd}
    */
    readonly relativeSd?: number;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinctToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinctToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _relativeSd?;
    get relativeSd(): number;
    set relativeSd(value: number);
    resetRelativeSd(): void;
    get relativeSdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#accuracy DataDatabricksFeatureEngineeringFeatures#accuracy}
    */
    readonly accuracy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#percentile DataDatabricksFeatureEngineeringFeatures#percentile}
    */
    readonly percentile: number;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentileToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentileToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined);
    private _accuracy?;
    get accuracy(): number;
    set accuracy(value: number);
    resetAccuracy(): void;
    get accuracyInput(): number | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    get percentileInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvgToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvgToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirstToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirstToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirstOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLastToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLastToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLastOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMaxToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMaxToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMaxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMinToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMinToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMinOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPopToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPopToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSampToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSampToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSumToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSumToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSumOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#offset DataDatabricksFeatureEngineeringFeatures#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#window_duration DataDatabricksFeatureEngineeringFeatures#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuousToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuousToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous | cdktn.IResolvable | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#slide_duration DataDatabricksFeatureEngineeringFeatures#slide_duration}
    */
    readonly slideDuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#window_duration DataDatabricksFeatureEngineeringFeatures#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSlidingToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSlidingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSlidingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined);
    private _slideDuration?;
    get slideDuration(): string;
    set slideDuration(value: string);
    get slideDurationInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#window_duration DataDatabricksFeatureEngineeringFeatures#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumblingToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumblingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumblingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined);
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#continuous DataDatabricksFeatureEngineeringFeatures#continuous}
    */
    readonly continuous?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#sliding DataDatabricksFeatureEngineeringFeatures#sliding}
    */
    readonly sliding?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#tumbling DataDatabricksFeatureEngineeringFeatures#tumbling}
    */
    readonly tumbling?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined);
    private _continuous;
    get continuous(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuousOutputReference;
    putContinuous(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous): void;
    resetContinuous(): void;
    get continuousInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowContinuous | undefined;
    private _sliding;
    get sliding(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSlidingOutputReference;
    putSliding(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding): void;
    resetSliding(): void;
    get slidingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowSliding | undefined;
    private _tumbling;
    get tumbling(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumblingOutputReference;
    putTumbling(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling): void;
    resetTumbling(): void;
    get tumblingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowTumbling | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPopToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPopToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#input DataDatabricksFeatureEngineeringFeatures#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSampToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSampToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#approx_count_distinct DataDatabricksFeatureEngineeringFeatures#approx_count_distinct}
    */
    readonly approxCountDistinct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#approx_percentile DataDatabricksFeatureEngineeringFeatures#approx_percentile}
    */
    readonly approxPercentile?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#avg DataDatabricksFeatureEngineeringFeatures#avg}
    */
    readonly avg?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#count_function DataDatabricksFeatureEngineeringFeatures#count_function}
    */
    readonly countFunction?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#first DataDatabricksFeatureEngineeringFeatures#first}
    */
    readonly first?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#last DataDatabricksFeatureEngineeringFeatures#last}
    */
    readonly last?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#max DataDatabricksFeatureEngineeringFeatures#max}
    */
    readonly max?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#min DataDatabricksFeatureEngineeringFeatures#min}
    */
    readonly min?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#stddev_pop DataDatabricksFeatureEngineeringFeatures#stddev_pop}
    */
    readonly stddevPop?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#stddev_samp DataDatabricksFeatureEngineeringFeatures#stddev_samp}
    */
    readonly stddevSamp?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#sum DataDatabricksFeatureEngineeringFeatures#sum}
    */
    readonly sum?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#time_window DataDatabricksFeatureEngineeringFeatures#time_window}
    */
    readonly timeWindow?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#var_pop DataDatabricksFeatureEngineeringFeatures#var_pop}
    */
    readonly varPop?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#var_samp DataDatabricksFeatureEngineeringFeatures#var_samp}
    */
    readonly varSamp?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction | cdktn.IResolvable | undefined);
    private _approxCountDistinct;
    get approxCountDistinct(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinctOutputReference;
    putApproxCountDistinct(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct): void;
    resetApproxCountDistinct(): void;
    get approxCountDistinctInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxCountDistinct | undefined;
    private _approxPercentile;
    get approxPercentile(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentileOutputReference;
    putApproxPercentile(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile): void;
    resetApproxPercentile(): void;
    get approxPercentileInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionApproxPercentile | undefined;
    private _avg;
    get avg(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvgOutputReference;
    putAvg(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg): void;
    resetAvg(): void;
    get avgInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionAvg | undefined;
    private _countFunction;
    get countFunction(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunctionOutputReference;
    putCountFunction(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction): void;
    resetCountFunction(): void;
    get countFunctionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionCountFunction | undefined;
    private _first;
    get first(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirstOutputReference;
    putFirst(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst): void;
    resetFirst(): void;
    get firstInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionFirst | undefined;
    private _last;
    get last(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLastOutputReference;
    putLast(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast): void;
    resetLast(): void;
    get lastInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionLast | undefined;
    private _max;
    get max(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMaxOutputReference;
    putMax(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax): void;
    resetMax(): void;
    get maxInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMax | undefined;
    private _min;
    get min(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMinOutputReference;
    putMin(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin): void;
    resetMin(): void;
    get minInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionMin | undefined;
    private _stddevPop;
    get stddevPop(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPopOutputReference;
    putStddevPop(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop): void;
    resetStddevPop(): void;
    get stddevPopInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevPop | undefined;
    private _stddevSamp;
    get stddevSamp(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSampOutputReference;
    putStddevSamp(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp): void;
    resetStddevSamp(): void;
    get stddevSampInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionStddevSamp | undefined;
    private _sum;
    get sum(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSumOutputReference;
    putSum(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum): void;
    resetSum(): void;
    get sumInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionSum | undefined;
    private _timeWindow;
    get timeWindow(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindowOutputReference;
    putTimeWindow(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionTimeWindow | undefined;
    private _varPop;
    get varPop(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPopOutputReference;
    putVarPop(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop): void;
    resetVarPop(): void;
    get varPopInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarPop | undefined;
    private _varSamp;
    get varSamp(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSampOutputReference;
    putVarSamp(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp): void;
    resetVarSamp(): void;
    get varSampInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionVarSamp | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#key DataDatabricksFeatureEngineeringFeatures#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#value DataDatabricksFeatureEngineeringFeatures#value}
    */
    readonly value: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParametersToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParametersToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParametersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParametersOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#aggregation_function DataDatabricksFeatureEngineeringFeatures#aggregation_function}
    */
    readonly aggregationFunction?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#extra_parameters DataDatabricksFeatureEngineeringFeatures#extra_parameters}
    */
    readonly extraParameters?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#function_type DataDatabricksFeatureEngineeringFeatures#function_type}
    */
    readonly functionType?: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunction): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesFunction): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunction | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunction | undefined);
    private _aggregationFunction;
    get aggregationFunction(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunctionOutputReference;
    putAggregationFunction(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction): void;
    resetAggregationFunction(): void;
    get aggregationFunctionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionAggregationFunction | undefined;
    private _extraParameters;
    get extraParameters(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParametersList;
    putExtraParameters(value: DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters[] | cdktn.IResolvable): void;
    resetExtraParameters(): void;
    get extraParametersInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionExtraParameters[] | undefined;
    private _functionType?;
    get functionType(): string;
    set functionType(value: string);
    resetFunctionType(): void;
    get functionTypeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#job_id DataDatabricksFeatureEngineeringFeatures#job_id}
    */
    readonly jobId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#job_run_id DataDatabricksFeatureEngineeringFeatures#job_run_id}
    */
    readonly jobRunId?: number;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContextToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContextToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext | cdktn.IResolvable | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    resetJobId(): void;
    get jobIdInput(): number | undefined;
    private _jobRunId?;
    get jobRunId(): number;
    set jobRunId(value: number);
    resetJobRunId(): void;
    get jobRunIdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#job_context DataDatabricksFeatureEngineeringFeatures#job_context}
    */
    readonly jobContext?: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#notebook_id DataDatabricksFeatureEngineeringFeatures#notebook_id}
    */
    readonly notebookId?: number;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContext): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContext): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContext | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContext | undefined);
    private _jobContext;
    get jobContext(): DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContextOutputReference;
    putJobContext(value: DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext): void;
    resetJobContext(): void;
    get jobContextInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextJobContext | undefined;
    private _notebookId?;
    get notebookId(): number;
    set notebookId(value: number);
    resetNotebookId(): void;
    get notebookIdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#workspace_id DataDatabricksFeatureEngineeringFeatures#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#dataframe_schema DataDatabricksFeatureEngineeringFeatures#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#entity_columns DataDatabricksFeatureEngineeringFeatures#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#filter_condition DataDatabricksFeatureEngineeringFeatures#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#full_name DataDatabricksFeatureEngineeringFeatures#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#timeseries_column DataDatabricksFeatureEngineeringFeatures#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#transformation_sql DataDatabricksFeatureEngineeringFeatures#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#variant_expr_path DataDatabricksFeatureEngineeringFeatures#variant_expr_path}
    */
    readonly variantExprPath: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiersToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiersToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers | cdktn.IResolvable | undefined);
    private _variantExprPath?;
    get variantExprPath(): string;
    set variantExprPath(value: string);
    get variantExprPathInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiersOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#variant_expr_path DataDatabricksFeatureEngineeringFeatures#variant_expr_path}
    */
    readonly variantExprPath: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifierToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifierToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifierOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier | cdktn.IResolvable | undefined);
    private _variantExprPath?;
    get variantExprPath(): string;
    set variantExprPath(value: string);
    get variantExprPathInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#entity_column_identifiers DataDatabricksFeatureEngineeringFeatures#entity_column_identifiers}
    */
    readonly entityColumnIdentifiers?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#filter_condition DataDatabricksFeatureEngineeringFeatures#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#name DataDatabricksFeatureEngineeringFeatures#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#timeseries_column_identifier DataDatabricksFeatureEngineeringFeatures#timeseries_column_identifier}
    */
    readonly timeseriesColumnIdentifier?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource | cdktn.IResolvable | undefined);
    private _entityColumnIdentifiers;
    get entityColumnIdentifiers(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiersList;
    putEntityColumnIdentifiers(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers[] | cdktn.IResolvable): void;
    resetEntityColumnIdentifiers(): void;
    get entityColumnIdentifiersInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceEntityColumnIdentifiers[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _timeseriesColumnIdentifier;
    get timeseriesColumnIdentifier(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifierOutputReference;
    putTimeseriesColumnIdentifier(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier): void;
    resetTimeseriesColumnIdentifier(): void;
    get timeseriesColumnIdentifierInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceTimeseriesColumnIdentifier | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#delta_table_source DataDatabricksFeatureEngineeringFeatures#delta_table_source}
    */
    readonly deltaTableSource?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#kafka_source DataDatabricksFeatureEngineeringFeatures#kafka_source}
    */
    readonly kafkaSource?: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSource): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesSource): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesSource | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSource | undefined);
    private _deltaTableSource;
    get deltaTableSource(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesSourceDeltaTableSource | undefined;
    private _kafkaSource;
    get kafkaSource(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSourceOutputReference;
    putKafkaSource(value: DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource): void;
    resetKafkaSource(): void;
    get kafkaSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesSourceKafkaSource | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#offset DataDatabricksFeatureEngineeringFeatures#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#window_duration DataDatabricksFeatureEngineeringFeatures#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuousToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuousToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous | cdktn.IResolvable | undefined);
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#slide_duration DataDatabricksFeatureEngineeringFeatures#slide_duration}
    */
    readonly slideDuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#window_duration DataDatabricksFeatureEngineeringFeatures#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSlidingToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSlidingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSlidingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding | cdktn.IResolvable | undefined);
    private _slideDuration?;
    get slideDuration(): string;
    set slideDuration(value: string);
    get slideDurationInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#window_duration DataDatabricksFeatureEngineeringFeatures#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumblingToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumblingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumblingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling | cdktn.IResolvable | undefined);
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#continuous DataDatabricksFeatureEngineeringFeatures#continuous}
    */
    readonly continuous?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#sliding DataDatabricksFeatureEngineeringFeatures#sliding}
    */
    readonly sliding?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#tumbling DataDatabricksFeatureEngineeringFeatures#tumbling}
    */
    readonly tumbling?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindow): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindow): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindow | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindow | undefined);
    private _continuous;
    get continuous(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuousOutputReference;
    putContinuous(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous): void;
    resetContinuous(): void;
    get continuousInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowContinuous | undefined;
    private _sliding;
    get sliding(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSlidingOutputReference;
    putSliding(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding): void;
    resetSliding(): void;
    get slidingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowSliding | undefined;
    private _tumbling;
    get tumbling(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumblingOutputReference;
    putTumbling(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling): void;
    resetTumbling(): void;
    get tumblingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowTumbling | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#name DataDatabricksFeatureEngineeringFeatures#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumnToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumn): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumnToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumn): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumn | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeaturesFeatures {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#full_name DataDatabricksFeatureEngineeringFeatures#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#provider_config DataDatabricksFeatureEngineeringFeatures#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig;
}
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeatures): any;
export declare function dataDatabricksFeatureEngineeringFeaturesFeaturesToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesFeatures): any;
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesFeatures | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesFeatures | undefined);
    get description(): string;
    private _entities;
    get entities(): DataDatabricksFeatureEngineeringFeaturesFeaturesEntitiesList;
    get filterCondition(): string;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _function;
    get function(): DataDatabricksFeatureEngineeringFeaturesFeaturesFunctionOutputReference;
    get inputs(): string[];
    private _lineageContext;
    get lineageContext(): DataDatabricksFeatureEngineeringFeaturesFeaturesLineageContextOutputReference;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesFeaturesProviderConfig | undefined;
    private _source;
    get source(): DataDatabricksFeatureEngineeringFeaturesFeaturesSourceOutputReference;
    private _timeWindow;
    get timeWindow(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeWindowOutputReference;
    private _timeseriesColumn;
    get timeseriesColumn(): DataDatabricksFeatureEngineeringFeaturesFeaturesTimeseriesColumnOutputReference;
}
export declare class DataDatabricksFeatureEngineeringFeaturesFeaturesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksFeatureEngineeringFeaturesFeatures[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeaturesFeaturesOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeaturesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#workspace_id DataDatabricksFeatureEngineeringFeatures#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksFeatureEngineeringFeaturesProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeaturesProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeaturesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeaturesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeaturesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeaturesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features databricks_feature_engineering_features}
*/
export declare class DataDatabricksFeatureEngineeringFeatures extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_feature_engineering_features";
    /**
    * Generates CDKTN code for importing a DataDatabricksFeatureEngineeringFeatures resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksFeatureEngineeringFeatures to import
    * @param importFromId The id of the existing DataDatabricksFeatureEngineeringFeatures that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksFeatureEngineeringFeatures to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.112.0/docs/data-sources/feature_engineering_features databricks_feature_engineering_features} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksFeatureEngineeringFeaturesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksFeatureEngineeringFeaturesConfig);
    private _features;
    get features(): DataDatabricksFeatureEngineeringFeaturesFeaturesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringFeaturesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringFeaturesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeaturesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
