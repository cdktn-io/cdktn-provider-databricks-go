/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/endpoint#name DataDatabricksEndpoint#name}
    */
    readonly name: string;
}
export interface DataDatabricksEndpointAzurePrivateEndpointInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/endpoint#private_endpoint_name DataDatabricksEndpoint#private_endpoint_name}
    */
    readonly privateEndpointName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/endpoint#private_endpoint_resource_guid DataDatabricksEndpoint#private_endpoint_resource_guid}
    */
    readonly privateEndpointResourceGuid: string;
}
export declare function dataDatabricksEndpointAzurePrivateEndpointInfoToTerraform(struct?: DataDatabricksEndpointAzurePrivateEndpointInfo): any;
export declare function dataDatabricksEndpointAzurePrivateEndpointInfoToHclTerraform(struct?: DataDatabricksEndpointAzurePrivateEndpointInfo): any;
export declare class DataDatabricksEndpointAzurePrivateEndpointInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEndpointAzurePrivateEndpointInfo | undefined;
    set internalValue(value: DataDatabricksEndpointAzurePrivateEndpointInfo | undefined);
    private _privateEndpointName?;
    get privateEndpointName(): string;
    set privateEndpointName(value: string);
    get privateEndpointNameInput(): string | undefined;
    private _privateEndpointResourceGuid?;
    get privateEndpointResourceGuid(): string;
    set privateEndpointResourceGuid(value: string);
    get privateEndpointResourceGuidInput(): string | undefined;
    get privateEndpointResourceId(): string;
    get privateLinkServiceId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/endpoint databricks_endpoint}
*/
export declare class DataDatabricksEndpoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_endpoint";
    /**
    * Generates CDKTN code for importing a DataDatabricksEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksEndpoint to import
    * @param importFromId The id of the existing DataDatabricksEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/endpoint databricks_endpoint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksEndpointConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksEndpointConfig);
    get accountId(): string;
    private _azurePrivateEndpointInfo;
    get azurePrivateEndpointInfo(): DataDatabricksEndpointAzurePrivateEndpointInfoOutputReference;
    get createTime(): string;
    get displayName(): string;
    get endpointId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get region(): string;
    get state(): string;
    get useCase(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
