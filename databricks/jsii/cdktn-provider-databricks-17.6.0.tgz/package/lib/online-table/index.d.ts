/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OnlineTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#id OnlineTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#name OnlineTable#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#provider_config OnlineTable#provider_config}
    */
    readonly providerConfig?: OnlineTableProviderConfig;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#spec OnlineTable#spec}
    */
    readonly spec?: OnlineTableSpec;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#timeouts OnlineTable#timeouts}
    */
    readonly timeouts?: OnlineTableTimeouts;
}
export interface OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgress {
}
export declare function onlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgressToTerraform(struct?: OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgress): any;
export declare function onlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgressToHclTerraform(struct?: OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgress): any;
export declare class OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgress | undefined;
    set internalValue(value: OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export declare class OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgressOutputReference;
}
export interface OnlineTableStatusContinuousUpdateStatus {
}
export declare function onlineTableStatusContinuousUpdateStatusToTerraform(struct?: OnlineTableStatusContinuousUpdateStatus): any;
export declare function onlineTableStatusContinuousUpdateStatusToHclTerraform(struct?: OnlineTableStatusContinuousUpdateStatus): any;
export declare class OnlineTableStatusContinuousUpdateStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatusContinuousUpdateStatus | undefined;
    set internalValue(value: OnlineTableStatusContinuousUpdateStatus | undefined);
    private _initialPipelineSyncProgress;
    get initialPipelineSyncProgress(): OnlineTableStatusContinuousUpdateStatusInitialPipelineSyncProgressList;
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
}
export declare class OnlineTableStatusContinuousUpdateStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusContinuousUpdateStatusOutputReference;
}
export interface OnlineTableStatusFailedStatus {
}
export declare function onlineTableStatusFailedStatusToTerraform(struct?: OnlineTableStatusFailedStatus): any;
export declare function onlineTableStatusFailedStatusToHclTerraform(struct?: OnlineTableStatusFailedStatus): any;
export declare class OnlineTableStatusFailedStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatusFailedStatus | undefined;
    set internalValue(value: OnlineTableStatusFailedStatus | undefined);
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
}
export declare class OnlineTableStatusFailedStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusFailedStatusOutputReference;
}
export interface OnlineTableStatusProvisioningStatusInitialPipelineSyncProgress {
}
export declare function onlineTableStatusProvisioningStatusInitialPipelineSyncProgressToTerraform(struct?: OnlineTableStatusProvisioningStatusInitialPipelineSyncProgress): any;
export declare function onlineTableStatusProvisioningStatusInitialPipelineSyncProgressToHclTerraform(struct?: OnlineTableStatusProvisioningStatusInitialPipelineSyncProgress): any;
export declare class OnlineTableStatusProvisioningStatusInitialPipelineSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatusProvisioningStatusInitialPipelineSyncProgress | undefined;
    set internalValue(value: OnlineTableStatusProvisioningStatusInitialPipelineSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export declare class OnlineTableStatusProvisioningStatusInitialPipelineSyncProgressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusProvisioningStatusInitialPipelineSyncProgressOutputReference;
}
export interface OnlineTableStatusProvisioningStatus {
}
export declare function onlineTableStatusProvisioningStatusToTerraform(struct?: OnlineTableStatusProvisioningStatus): any;
export declare function onlineTableStatusProvisioningStatusToHclTerraform(struct?: OnlineTableStatusProvisioningStatus): any;
export declare class OnlineTableStatusProvisioningStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatusProvisioningStatus | undefined;
    set internalValue(value: OnlineTableStatusProvisioningStatus | undefined);
    private _initialPipelineSyncProgress;
    get initialPipelineSyncProgress(): OnlineTableStatusProvisioningStatusInitialPipelineSyncProgressList;
}
export declare class OnlineTableStatusProvisioningStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusProvisioningStatusOutputReference;
}
export interface OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgress {
}
export declare function onlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgressToTerraform(struct?: OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgress): any;
export declare function onlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgressToHclTerraform(struct?: OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgress): any;
export declare class OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgress | undefined;
    set internalValue(value: OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export declare class OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgressOutputReference;
}
export interface OnlineTableStatusTriggeredUpdateStatus {
}
export declare function onlineTableStatusTriggeredUpdateStatusToTerraform(struct?: OnlineTableStatusTriggeredUpdateStatus): any;
export declare function onlineTableStatusTriggeredUpdateStatusToHclTerraform(struct?: OnlineTableStatusTriggeredUpdateStatus): any;
export declare class OnlineTableStatusTriggeredUpdateStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatusTriggeredUpdateStatus | undefined;
    set internalValue(value: OnlineTableStatusTriggeredUpdateStatus | undefined);
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
    private _triggeredUpdateProgress;
    get triggeredUpdateProgress(): OnlineTableStatusTriggeredUpdateStatusTriggeredUpdateProgressList;
}
export declare class OnlineTableStatusTriggeredUpdateStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusTriggeredUpdateStatusOutputReference;
}
export interface OnlineTableStatus {
}
export declare function onlineTableStatusToTerraform(struct?: OnlineTableStatus): any;
export declare function onlineTableStatusToHclTerraform(struct?: OnlineTableStatus): any;
export declare class OnlineTableStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): OnlineTableStatus | undefined;
    set internalValue(value: OnlineTableStatus | undefined);
    private _continuousUpdateStatus;
    get continuousUpdateStatus(): OnlineTableStatusContinuousUpdateStatusList;
    get detailedState(): string;
    private _failedStatus;
    get failedStatus(): OnlineTableStatusFailedStatusList;
    get message(): string;
    private _provisioningStatus;
    get provisioningStatus(): OnlineTableStatusProvisioningStatusList;
    private _triggeredUpdateStatus;
    get triggeredUpdateStatus(): OnlineTableStatusTriggeredUpdateStatusList;
}
export declare class OnlineTableStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): OnlineTableStatusOutputReference;
}
export interface OnlineTableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#workspace_id OnlineTable#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function onlineTableProviderConfigToTerraform(struct?: OnlineTableProviderConfigOutputReference | OnlineTableProviderConfig): any;
export declare function onlineTableProviderConfigToHclTerraform(struct?: OnlineTableProviderConfigOutputReference | OnlineTableProviderConfig): any;
export declare class OnlineTableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnlineTableProviderConfig | undefined;
    set internalValue(value: OnlineTableProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface OnlineTableSpecRunContinuously {
}
export declare function onlineTableSpecRunContinuouslyToTerraform(struct?: OnlineTableSpecRunContinuouslyOutputReference | OnlineTableSpecRunContinuously): any;
export declare function onlineTableSpecRunContinuouslyToHclTerraform(struct?: OnlineTableSpecRunContinuouslyOutputReference | OnlineTableSpecRunContinuously): any;
export declare class OnlineTableSpecRunContinuouslyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnlineTableSpecRunContinuously | undefined;
    set internalValue(value: OnlineTableSpecRunContinuously | undefined);
}
export interface OnlineTableSpecRunTriggered {
}
export declare function onlineTableSpecRunTriggeredToTerraform(struct?: OnlineTableSpecRunTriggeredOutputReference | OnlineTableSpecRunTriggered): any;
export declare function onlineTableSpecRunTriggeredToHclTerraform(struct?: OnlineTableSpecRunTriggeredOutputReference | OnlineTableSpecRunTriggered): any;
export declare class OnlineTableSpecRunTriggeredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnlineTableSpecRunTriggered | undefined;
    set internalValue(value: OnlineTableSpecRunTriggered | undefined);
}
export interface OnlineTableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#perform_full_copy OnlineTable#perform_full_copy}
    */
    readonly performFullCopy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#primary_key_columns OnlineTable#primary_key_columns}
    */
    readonly primaryKeyColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#source_table_full_name OnlineTable#source_table_full_name}
    */
    readonly sourceTableFullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#timeseries_key OnlineTable#timeseries_key}
    */
    readonly timeseriesKey?: string;
    /**
    * run_continuously block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#run_continuously OnlineTable#run_continuously}
    */
    readonly runContinuously?: OnlineTableSpecRunContinuously;
    /**
    * run_triggered block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#run_triggered OnlineTable#run_triggered}
    */
    readonly runTriggered?: OnlineTableSpecRunTriggered;
}
export declare function onlineTableSpecToTerraform(struct?: OnlineTableSpecOutputReference | OnlineTableSpec): any;
export declare function onlineTableSpecToHclTerraform(struct?: OnlineTableSpecOutputReference | OnlineTableSpec): any;
export declare class OnlineTableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnlineTableSpec | undefined;
    set internalValue(value: OnlineTableSpec | undefined);
    private _performFullCopy?;
    get performFullCopy(): boolean | cdktn.IResolvable;
    set performFullCopy(value: boolean | cdktn.IResolvable);
    resetPerformFullCopy(): void;
    get performFullCopyInput(): boolean | cdktn.IResolvable | undefined;
    get pipelineId(): string;
    private _primaryKeyColumns?;
    get primaryKeyColumns(): string[];
    set primaryKeyColumns(value: string[]);
    resetPrimaryKeyColumns(): void;
    get primaryKeyColumnsInput(): string[] | undefined;
    private _sourceTableFullName?;
    get sourceTableFullName(): string;
    set sourceTableFullName(value: string);
    resetSourceTableFullName(): void;
    get sourceTableFullNameInput(): string | undefined;
    private _timeseriesKey?;
    get timeseriesKey(): string;
    set timeseriesKey(value: string);
    resetTimeseriesKey(): void;
    get timeseriesKeyInput(): string | undefined;
    private _runContinuously;
    get runContinuously(): OnlineTableSpecRunContinuouslyOutputReference;
    putRunContinuously(value: OnlineTableSpecRunContinuously): void;
    resetRunContinuously(): void;
    get runContinuouslyInput(): OnlineTableSpecRunContinuously | undefined;
    private _runTriggered;
    get runTriggered(): OnlineTableSpecRunTriggeredOutputReference;
    putRunTriggered(value: OnlineTableSpecRunTriggered): void;
    resetRunTriggered(): void;
    get runTriggeredInput(): OnlineTableSpecRunTriggered | undefined;
}
export interface OnlineTableTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#create OnlineTable#create}
    */
    readonly create?: string;
}
export declare function onlineTableTimeoutsToTerraform(struct?: OnlineTableTimeouts | cdktn.IResolvable): any;
export declare function onlineTableTimeoutsToHclTerraform(struct?: OnlineTableTimeouts | cdktn.IResolvable): any;
export declare class OnlineTableTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnlineTableTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: OnlineTableTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table databricks_online_table}
*/
export declare class OnlineTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_online_table";
    /**
    * Generates CDKTN code for importing a OnlineTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OnlineTable to import
    * @param importFromId The id of the existing OnlineTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OnlineTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/online_table databricks_online_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OnlineTableConfig
    */
    constructor(scope: Construct, id: string, config: OnlineTableConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _status;
    get status(): OnlineTableStatusList;
    get tableServingUrl(): string;
    get unityCatalogProvisioningState(): string;
    private _providerConfig;
    get providerConfig(): OnlineTableProviderConfigOutputReference;
    putProviderConfig(value: OnlineTableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): OnlineTableProviderConfig | undefined;
    private _spec;
    get spec(): OnlineTableSpecOutputReference;
    putSpec(value: OnlineTableSpec): void;
    resetSpec(): void;
    get specInput(): OnlineTableSpec | undefined;
    private _timeouts;
    get timeouts(): OnlineTableTimeoutsOutputReference;
    putTimeouts(value: OnlineTableTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | OnlineTableTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
