/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksServicePrincipalFederationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#policy_id DataDatabricksServicePrincipalFederationPolicy#policy_id}
    */
    readonly policyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#service_principal_id DataDatabricksServicePrincipalFederationPolicy#service_principal_id}
    */
    readonly servicePrincipalId: number;
}
export interface DataDatabricksServicePrincipalFederationPolicyOidcPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#audiences DataDatabricksServicePrincipalFederationPolicy#audiences}
    */
    readonly audiences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#issuer DataDatabricksServicePrincipalFederationPolicy#issuer}
    */
    readonly issuer?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#jwks_json DataDatabricksServicePrincipalFederationPolicy#jwks_json}
    */
    readonly jwksJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#jwks_uri DataDatabricksServicePrincipalFederationPolicy#jwks_uri}
    */
    readonly jwksUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#subject DataDatabricksServicePrincipalFederationPolicy#subject}
    */
    readonly subject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#subject_claim DataDatabricksServicePrincipalFederationPolicy#subject_claim}
    */
    readonly subjectClaim?: string;
}
export declare function dataDatabricksServicePrincipalFederationPolicyOidcPolicyToTerraform(struct?: DataDatabricksServicePrincipalFederationPolicyOidcPolicy): any;
export declare function dataDatabricksServicePrincipalFederationPolicyOidcPolicyToHclTerraform(struct?: DataDatabricksServicePrincipalFederationPolicyOidcPolicy): any;
export declare class DataDatabricksServicePrincipalFederationPolicyOidcPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksServicePrincipalFederationPolicyOidcPolicy | undefined;
    set internalValue(value: DataDatabricksServicePrincipalFederationPolicyOidcPolicy | undefined);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    resetAudiences(): void;
    get audiencesInput(): string[] | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
    private _jwksJson?;
    get jwksJson(): string;
    set jwksJson(value: string);
    resetJwksJson(): void;
    get jwksJsonInput(): string | undefined;
    private _jwksUri?;
    get jwksUri(): string;
    set jwksUri(value: string);
    resetJwksUri(): void;
    get jwksUriInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
    private _subjectClaim?;
    get subjectClaim(): string;
    set subjectClaim(value: string);
    resetSubjectClaim(): void;
    get subjectClaimInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy databricks_service_principal_federation_policy}
*/
export declare class DataDatabricksServicePrincipalFederationPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_service_principal_federation_policy";
    /**
    * Generates CDKTN code for importing a DataDatabricksServicePrincipalFederationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksServicePrincipalFederationPolicy to import
    * @param importFromId The id of the existing DataDatabricksServicePrincipalFederationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksServicePrincipalFederationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/service_principal_federation_policy databricks_service_principal_federation_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksServicePrincipalFederationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksServicePrincipalFederationPolicyConfig);
    get createTime(): string;
    get description(): string;
    get name(): string;
    private _oidcPolicy;
    get oidcPolicy(): DataDatabricksServicePrincipalFederationPolicyOidcPolicyOutputReference;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): number;
    set servicePrincipalId(value: number);
    get servicePrincipalIdInput(): number | undefined;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
