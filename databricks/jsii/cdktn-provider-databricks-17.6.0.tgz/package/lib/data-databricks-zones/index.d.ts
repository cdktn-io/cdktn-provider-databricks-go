/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksZonesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones#default_zone DataDatabricksZones#default_zone}
    */
    readonly defaultZone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones#id DataDatabricksZones#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones#zones DataDatabricksZones#zones}
    */
    readonly zones?: string[];
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones#provider_config DataDatabricksZones#provider_config}
    */
    readonly providerConfig?: DataDatabricksZonesProviderConfig;
}
export interface DataDatabricksZonesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones#workspace_id DataDatabricksZones#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksZonesProviderConfigToTerraform(struct?: DataDatabricksZonesProviderConfigOutputReference | DataDatabricksZonesProviderConfig): any;
export declare function dataDatabricksZonesProviderConfigToHclTerraform(struct?: DataDatabricksZonesProviderConfigOutputReference | DataDatabricksZonesProviderConfig): any;
export declare class DataDatabricksZonesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksZonesProviderConfig | undefined;
    set internalValue(value: DataDatabricksZonesProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones databricks_zones}
*/
export declare class DataDatabricksZones extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_zones";
    /**
    * Generates CDKTN code for importing a DataDatabricksZones resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksZones to import
    * @param importFromId The id of the existing DataDatabricksZones that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksZones to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/zones databricks_zones} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksZonesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksZonesConfig);
    private _defaultZone?;
    get defaultZone(): string;
    set defaultZone(value: string);
    resetDefaultZone(): void;
    get defaultZoneInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _zones?;
    get zones(): string[];
    set zones(value: string[]);
    resetZones(): void;
    get zonesInput(): string[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksZonesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksZonesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksZonesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
