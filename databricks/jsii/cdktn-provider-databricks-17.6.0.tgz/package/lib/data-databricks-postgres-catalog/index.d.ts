/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog#name DataDatabricksPostgresCatalog#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog#provider_config DataDatabricksPostgresCatalog#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresCatalogProviderConfig;
}
export interface DataDatabricksPostgresCatalogProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog#workspace_id DataDatabricksPostgresCatalog#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresCatalogProviderConfigToTerraform(struct?: DataDatabricksPostgresCatalogProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresCatalogProviderConfigToHclTerraform(struct?: DataDatabricksPostgresCatalogProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresCatalogProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCatalogProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresCatalogProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresCatalogSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog#branch DataDatabricksPostgresCatalog#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog#create_database_if_missing DataDatabricksPostgresCatalog#create_database_if_missing}
    */
    readonly createDatabaseIfMissing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog#postgres_database DataDatabricksPostgresCatalog#postgres_database}
    */
    readonly postgresDatabase: string;
}
export declare function dataDatabricksPostgresCatalogSpecToTerraform(struct?: DataDatabricksPostgresCatalogSpec): any;
export declare function dataDatabricksPostgresCatalogSpecToHclTerraform(struct?: DataDatabricksPostgresCatalogSpec): any;
export declare class DataDatabricksPostgresCatalogSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCatalogSpec | undefined;
    set internalValue(value: DataDatabricksPostgresCatalogSpec | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _createDatabaseIfMissing?;
    get createDatabaseIfMissing(): boolean | cdktn.IResolvable;
    set createDatabaseIfMissing(value: boolean | cdktn.IResolvable);
    resetCreateDatabaseIfMissing(): void;
    get createDatabaseIfMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    get postgresDatabaseInput(): string | undefined;
}
export interface DataDatabricksPostgresCatalogStatus {
}
export declare function dataDatabricksPostgresCatalogStatusToTerraform(struct?: DataDatabricksPostgresCatalogStatus): any;
export declare function dataDatabricksPostgresCatalogStatusToHclTerraform(struct?: DataDatabricksPostgresCatalogStatus): any;
export declare class DataDatabricksPostgresCatalogStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCatalogStatus | undefined;
    set internalValue(value: DataDatabricksPostgresCatalogStatus | undefined);
    get branch(): string;
    get postgresDatabase(): string;
    get project(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog databricks_postgres_catalog}
*/
export declare class DataDatabricksPostgresCatalog extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_catalog";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresCatalog to import
    * @param importFromId The id of the existing DataDatabricksPostgresCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/postgres_catalog databricks_postgres_catalog} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresCatalogConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresCatalogConfig);
    get catalogId(): string;
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresCatalogProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresCatalogProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresCatalogProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresCatalogSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresCatalogStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
