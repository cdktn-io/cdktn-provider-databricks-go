/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication, AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference, AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination, AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference, AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin, AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference, AccountNetworkPolicyIngressDryRunPublicAccessAllowRules, AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList, AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess, AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference, AccountNetworkPolicyIngressDryRunPrivateAccess, AccountNetworkPolicyIngressDryRunPrivateAccessOutputReference } from './structs0';
export interface AccountNetworkPolicyIngressDryRunPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#authentication AccountNetworkPolicy#authentication}
    */
    readonly authentication?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#destination AccountNetworkPolicy#destination}
    */
    readonly destination?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#label AccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#origin AccountNetworkPolicy#origin}
    */
    readonly origin?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessDenyRulesToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | undefined;
}
export declare class AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOutputReference;
}
export interface AccountNetworkPolicyIngressDryRunPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#allow_rules AccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#deny_rules AccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#restriction_mode AccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function accountNetworkPolicyIngressDryRunPublicAccessToTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunPublicAccessToHclTerraform(struct?: AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): AccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList;
    putAllowRules(value: AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): AccountNetworkPolicyIngressDryRunPublicAccessDenyRulesList;
    putDenyRules(value: AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface AccountNetworkPolicyIngressDryRun {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#cross_workspace_access AccountNetworkPolicy#cross_workspace_access}
    */
    readonly crossWorkspaceAccess?: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#private_access AccountNetworkPolicy#private_access}
    */
    readonly privateAccess?: AccountNetworkPolicyIngressDryRunPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/account_network_policy#public_access AccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: AccountNetworkPolicyIngressDryRunPublicAccess;
}
export declare function accountNetworkPolicyIngressDryRunToTerraform(struct?: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable): any;
export declare function accountNetworkPolicyIngressDryRunToHclTerraform(struct?: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable): any;
export declare class AccountNetworkPolicyIngressDryRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountNetworkPolicyIngressDryRun | cdktn.IResolvable | undefined;
    set internalValue(value: AccountNetworkPolicyIngressDryRun | cdktn.IResolvable | undefined);
    private _crossWorkspaceAccess;
    get crossWorkspaceAccess(): AccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference;
    putCrossWorkspaceAccess(value: AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess): void;
    resetCrossWorkspaceAccess(): void;
    get crossWorkspaceAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | undefined;
    private _privateAccess;
    get privateAccess(): AccountNetworkPolicyIngressDryRunPrivateAccessOutputReference;
    putPrivateAccess(value: AccountNetworkPolicyIngressDryRunPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): AccountNetworkPolicyIngressDryRunPublicAccessOutputReference;
    putPublicAccess(value: AccountNetworkPolicyIngressDryRunPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | AccountNetworkPolicyIngressDryRunPublicAccess | undefined;
}
