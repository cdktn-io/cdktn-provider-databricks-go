/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDatabaseSyncedDatabaseTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#name DataDatabricksDatabaseSyncedDatabaseTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#provider_config DataDatabricksDatabaseSyncedDatabaseTable#provider_config}
    */
    readonly providerConfig?: DataDatabricksDatabaseSyncedDatabaseTableProviderConfig;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get provisioningPhase(): string;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable | undefined);
    private _initialPipelineSyncProgress;
    get initialPipelineSyncProgress(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressOutputReference;
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable | undefined);
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo | undefined);
    get deltaCommitTimestamp(): string;
    get deltaCommitVersion(): number;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync | undefined);
    private _deltaTableSyncInfo;
    get deltaTableSyncInfo(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoOutputReference;
    get syncEndTimestamp(): string;
    get syncStartTimestamp(): string;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get provisioningPhase(): string;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable | undefined);
    private _initialPipelineSyncProgress;
    get initialPipelineSyncProgress(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressOutputReference;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get provisioningPhase(): string;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus {
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable | undefined);
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
    private _triggeredUpdateProgress;
    get triggeredUpdateProgress(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressOutputReference;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#continuous_update_status DataDatabricksDatabaseSyncedDatabaseTable#continuous_update_status}
    */
    readonly continuousUpdateStatus?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#failed_status DataDatabricksDatabaseSyncedDatabaseTable#failed_status}
    */
    readonly failedStatus?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#provisioning_status DataDatabricksDatabaseSyncedDatabaseTable#provisioning_status}
    */
    readonly provisioningStatus?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#triggered_update_status DataDatabricksDatabaseSyncedDatabaseTable#triggered_update_status}
    */
    readonly triggeredUpdateStatus?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus;
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatus): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatus): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatus | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatus | undefined);
    private _continuousUpdateStatus;
    get continuousUpdateStatus(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusOutputReference;
    putContinuousUpdateStatus(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus): void;
    resetContinuousUpdateStatus(): void;
    get continuousUpdateStatusInput(): cdktn.IResolvable | DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | undefined;
    get detailedState(): string;
    private _failedStatus;
    get failedStatus(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusOutputReference;
    putFailedStatus(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus): void;
    resetFailedStatus(): void;
    get failedStatusInput(): cdktn.IResolvable | DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | undefined;
    private _lastSync;
    get lastSync(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncOutputReference;
    get message(): string;
    get pipelineId(): string;
    private _provisioningStatus;
    get provisioningStatus(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusOutputReference;
    putProvisioningStatus(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus): void;
    resetProvisioningStatus(): void;
    get provisioningStatusInput(): cdktn.IResolvable | DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | undefined;
    private _triggeredUpdateStatus;
    get triggeredUpdateStatus(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusOutputReference;
    putTriggeredUpdateStatus(value: DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus): void;
    resetTriggeredUpdateStatus(): void;
    get triggeredUpdateStatusInput(): cdktn.IResolvable | DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | undefined;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#workspace_id DataDatabricksDatabaseSyncedDatabaseTable#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableProviderConfigToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableProviderConfigToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#budget_policy_id DataDatabricksDatabaseSyncedDatabaseTable#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#storage_catalog DataDatabricksDatabaseSyncedDatabaseTable#storage_catalog}
    */
    readonly storageCatalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#storage_schema DataDatabricksDatabaseSyncedDatabaseTable#storage_schema}
    */
    readonly storageSchema?: string;
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpecToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpecToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable | undefined);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _storageCatalog?;
    get storageCatalog(): string;
    set storageCatalog(value: string);
    resetStorageCatalog(): void;
    get storageCatalogInput(): string | undefined;
    private _storageSchema?;
    get storageSchema(): string;
    set storageSchema(value: string);
    resetStorageSchema(): void;
    get storageSchemaInput(): string | undefined;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#column_name DataDatabricksDatabaseSyncedDatabaseTable#column_name}
    */
    readonly columnName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#pg_type DataDatabricksDatabaseSyncedDatabaseTable#pg_type}
    */
    readonly pgType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#size DataDatabricksDatabaseSyncedDatabaseTable#size}
    */
    readonly size?: number;
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverridesToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverridesToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    get columnNameInput(): string | undefined;
    private _pgType?;
    get pgType(): string;
    set pgType(value: string);
    get pgTypeInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverridesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverridesOutputReference;
}
export interface DataDatabricksDatabaseSyncedDatabaseTableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#accelerated_sync DataDatabricksDatabaseSyncedDatabaseTable#accelerated_sync}
    */
    readonly acceleratedSync?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#create_database_objects_if_missing DataDatabricksDatabaseSyncedDatabaseTable#create_database_objects_if_missing}
    */
    readonly createDatabaseObjectsIfMissing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#existing_pipeline_id DataDatabricksDatabaseSyncedDatabaseTable#existing_pipeline_id}
    */
    readonly existingPipelineId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#new_pipeline_spec DataDatabricksDatabaseSyncedDatabaseTable#new_pipeline_spec}
    */
    readonly newPipelineSpec?: DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#primary_key_columns DataDatabricksDatabaseSyncedDatabaseTable#primary_key_columns}
    */
    readonly primaryKeyColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#scheduling_policy DataDatabricksDatabaseSyncedDatabaseTable#scheduling_policy}
    */
    readonly schedulingPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#source_table_full_name DataDatabricksDatabaseSyncedDatabaseTable#source_table_full_name}
    */
    readonly sourceTableFullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#timeseries_key DataDatabricksDatabaseSyncedDatabaseTable#timeseries_key}
    */
    readonly timeseriesKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#type_overrides DataDatabricksDatabaseSyncedDatabaseTable#type_overrides}
    */
    readonly typeOverrides?: DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides[] | cdktn.IResolvable;
}
export declare function dataDatabricksDatabaseSyncedDatabaseTableSpecToTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableSpec): any;
export declare function dataDatabricksDatabaseSyncedDatabaseTableSpecToHclTerraform(struct?: DataDatabricksDatabaseSyncedDatabaseTableSpec): any;
export declare class DataDatabricksDatabaseSyncedDatabaseTableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseSyncedDatabaseTableSpec | undefined;
    set internalValue(value: DataDatabricksDatabaseSyncedDatabaseTableSpec | undefined);
    private _acceleratedSync?;
    get acceleratedSync(): boolean | cdktn.IResolvable;
    set acceleratedSync(value: boolean | cdktn.IResolvable);
    resetAcceleratedSync(): void;
    get acceleratedSyncInput(): boolean | cdktn.IResolvable | undefined;
    private _createDatabaseObjectsIfMissing?;
    get createDatabaseObjectsIfMissing(): boolean | cdktn.IResolvable;
    set createDatabaseObjectsIfMissing(value: boolean | cdktn.IResolvable);
    resetCreateDatabaseObjectsIfMissing(): void;
    get createDatabaseObjectsIfMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _existingPipelineId?;
    get existingPipelineId(): string;
    set existingPipelineId(value: string);
    resetExistingPipelineId(): void;
    get existingPipelineIdInput(): string | undefined;
    private _newPipelineSpec;
    get newPipelineSpec(): DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpecOutputReference;
    putNewPipelineSpec(value: DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec): void;
    resetNewPipelineSpec(): void;
    get newPipelineSpecInput(): cdktn.IResolvable | DataDatabricksDatabaseSyncedDatabaseTableSpecNewPipelineSpec | undefined;
    private _primaryKeyColumns?;
    get primaryKeyColumns(): string[];
    set primaryKeyColumns(value: string[]);
    resetPrimaryKeyColumns(): void;
    get primaryKeyColumnsInput(): string[] | undefined;
    private _schedulingPolicy?;
    get schedulingPolicy(): string;
    set schedulingPolicy(value: string);
    resetSchedulingPolicy(): void;
    get schedulingPolicyInput(): string | undefined;
    private _sourceTableFullName?;
    get sourceTableFullName(): string;
    set sourceTableFullName(value: string);
    resetSourceTableFullName(): void;
    get sourceTableFullNameInput(): string | undefined;
    private _timeseriesKey?;
    get timeseriesKey(): string;
    set timeseriesKey(value: string);
    resetTimeseriesKey(): void;
    get timeseriesKeyInput(): string | undefined;
    private _typeOverrides;
    get typeOverrides(): DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverridesList;
    putTypeOverrides(value: DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides[] | cdktn.IResolvable): void;
    resetTypeOverrides(): void;
    get typeOverridesInput(): cdktn.IResolvable | DataDatabricksDatabaseSyncedDatabaseTableSpecTypeOverrides[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table databricks_database_synced_database_table}
*/
export declare class DataDatabricksDatabaseSyncedDatabaseTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_database_synced_database_table";
    /**
    * Generates CDKTN code for importing a DataDatabricksDatabaseSyncedDatabaseTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDatabaseSyncedDatabaseTable to import
    * @param importFromId The id of the existing DataDatabricksDatabaseSyncedDatabaseTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDatabaseSyncedDatabaseTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/database_synced_database_table databricks_database_synced_database_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDatabaseSyncedDatabaseTableConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDatabaseSyncedDatabaseTableConfig);
    private _dataSynchronizationStatus;
    get dataSynchronizationStatus(): DataDatabricksDatabaseSyncedDatabaseTableDataSynchronizationStatusOutputReference;
    get databaseInstanceName(): string;
    get effectiveDatabaseInstanceName(): string;
    get effectiveLogicalDatabaseName(): string;
    get logicalDatabaseName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDatabaseSyncedDatabaseTableProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDatabaseSyncedDatabaseTableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDatabaseSyncedDatabaseTableProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksDatabaseSyncedDatabaseTableSpecOutputReference;
    get unityCatalogProvisioningState(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
