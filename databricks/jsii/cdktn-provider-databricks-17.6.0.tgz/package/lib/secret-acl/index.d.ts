/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SecretAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl#id SecretAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl#permission SecretAcl#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl#principal SecretAcl#principal}
    */
    readonly principal: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl#scope SecretAcl#scope}
    */
    readonly scope: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl#provider_config SecretAcl#provider_config}
    */
    readonly providerConfig?: SecretAclProviderConfig;
}
export interface SecretAclProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl#workspace_id SecretAcl#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function secretAclProviderConfigToTerraform(struct?: SecretAclProviderConfigOutputReference | SecretAclProviderConfig): any;
export declare function secretAclProviderConfigToHclTerraform(struct?: SecretAclProviderConfigOutputReference | SecretAclProviderConfig): any;
export declare class SecretAclProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecretAclProviderConfig | undefined;
    set internalValue(value: SecretAclProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl databricks_secret_acl}
*/
export declare class SecretAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_secret_acl";
    /**
    * Generates CDKTN code for importing a SecretAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretAcl to import
    * @param importFromId The id of the existing SecretAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/secret_acl databricks_secret_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretAclConfig
    */
    constructor(scope: Construct, id: string, config: SecretAclConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): SecretAclProviderConfigOutputReference;
    putProviderConfig(value: SecretAclProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SecretAclProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
