/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiSearchEndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#page_size DataDatabricksAiSearchEndpoints#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#parent DataDatabricksAiSearchEndpoints#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#provider_config DataDatabricksAiSearchEndpoints#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiSearchEndpointsProviderConfig;
}
export interface DataDatabricksAiSearchEndpointsEndpointsCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#key DataDatabricksAiSearchEndpoints#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#value DataDatabricksAiSearchEndpoints#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAiSearchEndpointsEndpointsCustomTagsToTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsCustomTags): any;
export declare function dataDatabricksAiSearchEndpointsEndpointsCustomTagsToHclTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsCustomTags): any;
export declare class DataDatabricksAiSearchEndpointsEndpointsCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchEndpointsEndpointsCustomTags | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointsEndpointsCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksAiSearchEndpointsEndpointsCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchEndpointsEndpointsCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchEndpointsEndpointsCustomTagsOutputReference;
}
export interface DataDatabricksAiSearchEndpointsEndpointsEndpointStatus {
}
export declare function dataDatabricksAiSearchEndpointsEndpointsEndpointStatusToTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsEndpointStatus): any;
export declare function dataDatabricksAiSearchEndpointsEndpointsEndpointStatusToHclTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsEndpointStatus): any;
export declare class DataDatabricksAiSearchEndpointsEndpointsEndpointStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointsEndpointsEndpointStatus | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointsEndpointsEndpointStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAiSearchEndpointsEndpointsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#workspace_id DataDatabricksAiSearchEndpoints#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiSearchEndpointsEndpointsProviderConfigToTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchEndpointsEndpointsProviderConfigToHclTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchEndpointsEndpointsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointsEndpointsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointsEndpointsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAiSearchEndpointsEndpointsScalingInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#requested_target_qps DataDatabricksAiSearchEndpoints#requested_target_qps}
    */
    readonly requestedTargetQps?: number;
}
export declare function dataDatabricksAiSearchEndpointsEndpointsScalingInfoToTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsScalingInfo): any;
export declare function dataDatabricksAiSearchEndpointsEndpointsScalingInfoToHclTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsScalingInfo): any;
export declare class DataDatabricksAiSearchEndpointsEndpointsScalingInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointsEndpointsScalingInfo | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointsEndpointsScalingInfo | undefined);
    private _requestedTargetQps?;
    get requestedTargetQps(): number;
    set requestedTargetQps(value: number);
    resetRequestedTargetQps(): void;
    get requestedTargetQpsInput(): number | undefined;
    get state(): string;
}
export interface DataDatabricksAiSearchEndpointsEndpointsThroughputInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#maximum_concurrency_allowed DataDatabricksAiSearchEndpoints#maximum_concurrency_allowed}
    */
    readonly maximumConcurrencyAllowed?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#minimal_concurrency_allowed DataDatabricksAiSearchEndpoints#minimal_concurrency_allowed}
    */
    readonly minimalConcurrencyAllowed?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#requested_concurrency DataDatabricksAiSearchEndpoints#requested_concurrency}
    */
    readonly requestedConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#requested_num_replicas DataDatabricksAiSearchEndpoints#requested_num_replicas}
    */
    readonly requestedNumReplicas?: number;
}
export declare function dataDatabricksAiSearchEndpointsEndpointsThroughputInfoToTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsThroughputInfo): any;
export declare function dataDatabricksAiSearchEndpointsEndpointsThroughputInfoToHclTerraform(struct?: DataDatabricksAiSearchEndpointsEndpointsThroughputInfo): any;
export declare class DataDatabricksAiSearchEndpointsEndpointsThroughputInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointsEndpointsThroughputInfo | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointsEndpointsThroughputInfo | undefined);
    get changeRequestMessage(): string;
    get changeRequestState(): string;
    get currentConcurrency(): number;
    get currentConcurrencyUtilizationPercentage(): number;
    get currentNumReplicas(): number;
    private _maximumConcurrencyAllowed?;
    get maximumConcurrencyAllowed(): number;
    set maximumConcurrencyAllowed(value: number);
    resetMaximumConcurrencyAllowed(): void;
    get maximumConcurrencyAllowedInput(): number | undefined;
    private _minimalConcurrencyAllowed?;
    get minimalConcurrencyAllowed(): number;
    set minimalConcurrencyAllowed(value: number);
    resetMinimalConcurrencyAllowed(): void;
    get minimalConcurrencyAllowedInput(): number | undefined;
    private _requestedConcurrency?;
    get requestedConcurrency(): number;
    set requestedConcurrency(value: number);
    resetRequestedConcurrency(): void;
    get requestedConcurrencyInput(): number | undefined;
    private _requestedNumReplicas?;
    get requestedNumReplicas(): number;
    set requestedNumReplicas(value: number);
    resetRequestedNumReplicas(): void;
    get requestedNumReplicasInput(): number | undefined;
}
export interface DataDatabricksAiSearchEndpointsEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#name DataDatabricksAiSearchEndpoints#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#provider_config DataDatabricksAiSearchEndpoints#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiSearchEndpointsEndpointsProviderConfig;
}
export declare function dataDatabricksAiSearchEndpointsEndpointsToTerraform(struct?: DataDatabricksAiSearchEndpointsEndpoints): any;
export declare function dataDatabricksAiSearchEndpointsEndpointsToHclTerraform(struct?: DataDatabricksAiSearchEndpointsEndpoints): any;
export declare class DataDatabricksAiSearchEndpointsEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchEndpointsEndpoints | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointsEndpoints | undefined);
    get budgetPolicyId(): string;
    get createTime(): string;
    get creator(): string;
    private _customTags;
    get customTags(): DataDatabricksAiSearchEndpointsEndpointsCustomTagsList;
    get effectiveBudgetPolicyId(): string;
    private _endpointStatus;
    get endpointStatus(): DataDatabricksAiSearchEndpointsEndpointsEndpointStatusOutputReference;
    get endpointType(): string;
    get id(): string;
    get indexCount(): number;
    get lastUpdatedUser(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiSearchEndpointsEndpointsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiSearchEndpointsEndpointsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiSearchEndpointsEndpointsProviderConfig | undefined;
    get replicaCount(): number;
    private _scalingInfo;
    get scalingInfo(): DataDatabricksAiSearchEndpointsEndpointsScalingInfoOutputReference;
    get targetQps(): number;
    private _throughputInfo;
    get throughputInfo(): DataDatabricksAiSearchEndpointsEndpointsThroughputInfoOutputReference;
    get updateTime(): string;
    get usagePolicyId(): string;
}
export declare class DataDatabricksAiSearchEndpointsEndpointsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchEndpointsEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchEndpointsEndpointsOutputReference;
}
export interface DataDatabricksAiSearchEndpointsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#workspace_id DataDatabricksAiSearchEndpoints#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiSearchEndpointsProviderConfigToTerraform(struct?: DataDatabricksAiSearchEndpointsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchEndpointsProviderConfigToHclTerraform(struct?: DataDatabricksAiSearchEndpointsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchEndpointsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints databricks_ai_search_endpoints}
*/
export declare class DataDatabricksAiSearchEndpoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_search_endpoints";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiSearchEndpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiSearchEndpoints to import
    * @param importFromId The id of the existing DataDatabricksAiSearchEndpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiSearchEndpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/ai_search_endpoints databricks_ai_search_endpoints} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiSearchEndpointsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAiSearchEndpointsConfig);
    private _endpoints;
    get endpoints(): DataDatabricksAiSearchEndpointsEndpointsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiSearchEndpointsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiSearchEndpointsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiSearchEndpointsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
