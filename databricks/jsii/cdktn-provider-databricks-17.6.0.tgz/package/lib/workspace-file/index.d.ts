/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceFileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#content_base64 WorkspaceFile#content_base64}
    */
    readonly contentBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#id WorkspaceFile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#md5 WorkspaceFile#md5}
    */
    readonly md5?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#object_id WorkspaceFile#object_id}
    */
    readonly objectId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#path WorkspaceFile#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#source WorkspaceFile#source}
    */
    readonly source?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#provider_config WorkspaceFile#provider_config}
    */
    readonly providerConfig?: WorkspaceFileProviderConfig;
}
export interface WorkspaceFileProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#workspace_id WorkspaceFile#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceFileProviderConfigToTerraform(struct?: WorkspaceFileProviderConfigOutputReference | WorkspaceFileProviderConfig): any;
export declare function workspaceFileProviderConfigToHclTerraform(struct?: WorkspaceFileProviderConfigOutputReference | WorkspaceFileProviderConfig): any;
export declare class WorkspaceFileProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceFileProviderConfig | undefined;
    set internalValue(value: WorkspaceFileProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file databricks_workspace_file}
*/
export declare class WorkspaceFile extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_file";
    /**
    * Generates CDKTN code for importing a WorkspaceFile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceFile to import
    * @param importFromId The id of the existing WorkspaceFile that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceFile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/workspace_file databricks_workspace_file} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceFileConfig
    */
    constructor(scope: Construct, id: string, config: WorkspaceFileConfig);
    private _contentBase64?;
    get contentBase64(): string;
    set contentBase64(value: string);
    resetContentBase64(): void;
    get contentBase64Input(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _md5?;
    get md5(): string;
    set md5(value: string);
    resetMd5(): void;
    get md5Input(): string | undefined;
    private _objectId?;
    get objectId(): number;
    set objectId(value: number);
    resetObjectId(): void;
    get objectIdInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    get url(): string;
    get workspacePath(): string;
    private _providerConfig;
    get providerConfig(): WorkspaceFileProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceFileProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): WorkspaceFileProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
