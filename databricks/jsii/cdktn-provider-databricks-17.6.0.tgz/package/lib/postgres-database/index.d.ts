/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresDatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#database_id PostgresDatabase#database_id}
    */
    readonly databaseId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#parent PostgresDatabase#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#provider_config PostgresDatabase#provider_config}
    */
    readonly providerConfig?: PostgresDatabaseProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#replace_existing PostgresDatabase#replace_existing}
    */
    readonly replaceExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#spec PostgresDatabase#spec}
    */
    readonly spec?: PostgresDatabaseSpec;
}
export interface PostgresDatabaseProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#workspace_id PostgresDatabase#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresDatabaseProviderConfigToTerraform(struct?: PostgresDatabaseProviderConfig | cdktn.IResolvable): any;
export declare function postgresDatabaseProviderConfigToHclTerraform(struct?: PostgresDatabaseProviderConfig | cdktn.IResolvable): any;
export declare class PostgresDatabaseProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresDatabaseProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresDatabaseProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresDatabaseSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#postgres_database PostgresDatabase#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#role PostgresDatabase#role}
    */
    readonly role?: string;
}
export declare function postgresDatabaseSpecToTerraform(struct?: PostgresDatabaseSpec | cdktn.IResolvable): any;
export declare function postgresDatabaseSpecToHclTerraform(struct?: PostgresDatabaseSpec | cdktn.IResolvable): any;
export declare class PostgresDatabaseSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresDatabaseSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresDatabaseSpec | cdktn.IResolvable | undefined);
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
}
export interface PostgresDatabaseStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#postgres_database PostgresDatabase#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#role PostgresDatabase#role}
    */
    readonly role?: string;
}
export declare function postgresDatabaseStatusToTerraform(struct?: PostgresDatabaseStatus): any;
export declare function postgresDatabaseStatusToHclTerraform(struct?: PostgresDatabaseStatus): any;
export declare class PostgresDatabaseStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresDatabaseStatus | undefined;
    set internalValue(value: PostgresDatabaseStatus | undefined);
    get databaseId(): string;
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database databricks_postgres_database}
*/
export declare class PostgresDatabase extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_database";
    /**
    * Generates CDKTN code for importing a PostgresDatabase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresDatabase to import
    * @param importFromId The id of the existing PostgresDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/postgres_database databricks_postgres_database} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: PostgresDatabaseConfig);
    get createTime(): string;
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    resetDatabaseId(): void;
    get databaseIdInput(): string | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresDatabaseProviderConfigOutputReference;
    putProviderConfig(value: PostgresDatabaseProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresDatabaseProviderConfig | undefined;
    private _replaceExisting?;
    get replaceExisting(): boolean | cdktn.IResolvable;
    set replaceExisting(value: boolean | cdktn.IResolvable);
    resetReplaceExisting(): void;
    get replaceExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _spec;
    get spec(): PostgresDatabaseSpecOutputReference;
    putSpec(value: PostgresDatabaseSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresDatabaseSpec | undefined;
    private _status;
    get status(): PostgresDatabaseStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
