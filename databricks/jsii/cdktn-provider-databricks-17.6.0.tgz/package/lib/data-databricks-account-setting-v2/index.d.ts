/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#name DataDatabricksAccountSettingV2#name}
    */
    readonly name: string;
}
export interface DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#access_policy_type DataDatabricksAccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#approved_domains DataDatabricksAccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2AllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#allowed_scopes DataDatabricksAccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksAccountSettingV2AllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksAccountSettingV2AllowedAppsUserApiScopes): any;
export declare function dataDatabricksAccountSettingV2AllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksAccountSettingV2AllowedAppsUserApiScopes): any;
export declare class DataDatabricksAccountSettingV2AllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#forced_for_compliance_mode DataDatabricksAccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#unavailable_for_disabled_entitlement DataDatabricksAccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksAccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#hours DataDatabricksAccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#minutes DataDatabricksAccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#day_of_week DataDatabricksAccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#frequency DataDatabricksAccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#window_start_time DataDatabricksAccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#week_day_based_schedule DataDatabricksAccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#can_toggle DataDatabricksAccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#enabled DataDatabricksAccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#enablement_details DataDatabricksAccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#maintenance_window DataDatabricksAccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#restart_even_if_no_updates_available DataDatabricksAccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2BooleanValToTerraform(struct?: DataDatabricksAccountSettingV2BooleanVal): any;
export declare function dataDatabricksAccountSettingV2BooleanValToHclTerraform(struct?: DataDatabricksAccountSettingV2BooleanVal): any;
export declare class DataDatabricksAccountSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2BooleanVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2BooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2CollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#connectivity DataDatabricksAccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksAccountSettingV2CollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksAccountSettingV2CollaborationPlatformConnectivity): any;
export declare function dataDatabricksAccountSettingV2CollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksAccountSettingV2CollaborationPlatformConnectivity): any;
export declare class DataDatabricksAccountSettingV2CollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2CollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2CollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#access_policy_type DataDatabricksAccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#approved_domains DataDatabricksAccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#allowed_scopes DataDatabricksAccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare function dataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare class DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#forced_for_compliance_mode DataDatabricksAccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#unavailable_for_disabled_entitlement DataDatabricksAccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksAccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#hours DataDatabricksAccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#minutes DataDatabricksAccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#day_of_week DataDatabricksAccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#frequency DataDatabricksAccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#window_start_time DataDatabricksAccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#week_day_based_schedule DataDatabricksAccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#can_toggle DataDatabricksAccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#enabled DataDatabricksAccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#enablement_details DataDatabricksAccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#maintenance_window DataDatabricksAccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#restart_even_if_no_updates_available DataDatabricksAccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountSettingV2EffectiveBooleanValToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveBooleanVal): any;
export declare function dataDatabricksAccountSettingV2EffectiveBooleanValToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveBooleanVal): any;
export declare class DataDatabricksAccountSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#connectivity DataDatabricksAccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare function dataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare class DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksAccountSettingV2EffectiveIntegerValToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveIntegerVal): any;
export declare function dataDatabricksAccountSettingV2EffectiveIntegerValToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveIntegerVal): any;
export declare class DataDatabricksAccountSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#email DataDatabricksAccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare function dataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare class DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2EffectivePersonalComputeToTerraform(struct?: DataDatabricksAccountSettingV2EffectivePersonalCompute): any;
export declare function dataDatabricksAccountSettingV2EffectivePersonalComputeToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectivePersonalCompute): any;
export declare class DataDatabricksAccountSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectivePersonalCompute | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectivePersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#disable_gov_tag_creation DataDatabricksAccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#status DataDatabricksAccountSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare function dataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare class DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2EffectiveStringValToTerraform(struct?: DataDatabricksAccountSettingV2EffectiveStringVal): any;
export declare function dataDatabricksAccountSettingV2EffectiveStringValToHclTerraform(struct?: DataDatabricksAccountSettingV2EffectiveStringVal): any;
export declare class DataDatabricksAccountSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2EffectiveStringVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksAccountSettingV2IntegerValToTerraform(struct?: DataDatabricksAccountSettingV2IntegerVal): any;
export declare function dataDatabricksAccountSettingV2IntegerValToHclTerraform(struct?: DataDatabricksAccountSettingV2IntegerVal): any;
export declare class DataDatabricksAccountSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2IntegerVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2IntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksAccountSettingV2OperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#email DataDatabricksAccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksAccountSettingV2OperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksAccountSettingV2OperationalEmailCustomRecipient): any;
export declare function dataDatabricksAccountSettingV2OperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksAccountSettingV2OperationalEmailCustomRecipient): any;
export declare class DataDatabricksAccountSettingV2OperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2OperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2OperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2PersonalComputeToTerraform(struct?: DataDatabricksAccountSettingV2PersonalCompute): any;
export declare function dataDatabricksAccountSettingV2PersonalComputeToHclTerraform(struct?: DataDatabricksAccountSettingV2PersonalCompute): any;
export declare class DataDatabricksAccountSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2PersonalCompute | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2PersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#disable_gov_tag_creation DataDatabricksAccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#status DataDatabricksAccountSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksAccountSettingV2RestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksAccountSettingV2RestrictWorkspaceAdmins): any;
export declare function dataDatabricksAccountSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksAccountSettingV2RestrictWorkspaceAdmins): any;
export declare class DataDatabricksAccountSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2RestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2RestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksAccountSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#value DataDatabricksAccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAccountSettingV2StringValToTerraform(struct?: DataDatabricksAccountSettingV2StringVal): any;
export declare function dataDatabricksAccountSettingV2StringValToHclTerraform(struct?: DataDatabricksAccountSettingV2StringVal): any;
export declare class DataDatabricksAccountSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountSettingV2StringVal | undefined;
    set internalValue(value: DataDatabricksAccountSettingV2StringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2 databricks_account_setting_v2}
*/
export declare class DataDatabricksAccountSettingV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_setting_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountSettingV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_setting_v2 databricks_account_setting_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountSettingV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): DataDatabricksAccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _allowedAppsUserApiScopes;
    get allowedAppsUserApiScopes(): DataDatabricksAccountSettingV2AllowedAppsUserApiScopesOutputReference;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): DataDatabricksAccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    private _booleanVal;
    get booleanVal(): DataDatabricksAccountSettingV2BooleanValOutputReference;
    private _collaborationPlatformConnectivity;
    get collaborationPlatformConnectivity(): DataDatabricksAccountSettingV2CollaborationPlatformConnectivityOutputReference;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): DataDatabricksAccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _effectiveAllowedAppsUserApiScopes;
    get effectiveAllowedAppsUserApiScopes(): DataDatabricksAccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): DataDatabricksAccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): DataDatabricksAccountSettingV2EffectiveBooleanValOutputReference;
    private _effectiveCollaborationPlatformConnectivity;
    get effectiveCollaborationPlatformConnectivity(): DataDatabricksAccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): DataDatabricksAccountSettingV2EffectiveIntegerValOutputReference;
    private _effectiveOperationalEmailCustomRecipient;
    get effectiveOperationalEmailCustomRecipient(): DataDatabricksAccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): DataDatabricksAccountSettingV2EffectivePersonalComputeOutputReference;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): DataDatabricksAccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    private _effectiveStringVal;
    get effectiveStringVal(): DataDatabricksAccountSettingV2EffectiveStringValOutputReference;
    private _integerVal;
    get integerVal(): DataDatabricksAccountSettingV2IntegerValOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationalEmailCustomRecipient;
    get operationalEmailCustomRecipient(): DataDatabricksAccountSettingV2OperationalEmailCustomRecipientOutputReference;
    private _personalCompute;
    get personalCompute(): DataDatabricksAccountSettingV2PersonalComputeOutputReference;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): DataDatabricksAccountSettingV2RestrictWorkspaceAdminsOutputReference;
    private _stringVal;
    get stringVal(): DataDatabricksAccountSettingV2StringValOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
