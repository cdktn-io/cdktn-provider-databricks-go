/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { DataDatabricksAccountNetworkPolicyEgressOutputReference, DataDatabricksAccountNetworkPolicyIngressOutputReference, DataDatabricksAccountNetworkPolicyIngressDryRunOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountNetworkPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_network_policy#network_policy_id DataDatabricksAccountNetworkPolicy#network_policy_id}
    */
    readonly networkPolicyId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_network_policy databricks_account_network_policy}
*/
export declare class DataDatabricksAccountNetworkPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_network_policy";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountNetworkPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountNetworkPolicy to import
    * @param importFromId The id of the existing DataDatabricksAccountNetworkPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_network_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountNetworkPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/account_network_policy databricks_account_network_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountNetworkPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountNetworkPolicyConfig);
    get accountId(): string;
    private _egress;
    get egress(): DataDatabricksAccountNetworkPolicyEgressOutputReference;
    private _ingress;
    get ingress(): DataDatabricksAccountNetworkPolicyIngressOutputReference;
    private _ingressDryRun;
    get ingressDryRun(): DataDatabricksAccountNetworkPolicyIngressDryRunOutputReference;
    private _networkPolicyId?;
    get networkPolicyId(): string;
    set networkPolicyId(value: string);
    get networkPolicyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
