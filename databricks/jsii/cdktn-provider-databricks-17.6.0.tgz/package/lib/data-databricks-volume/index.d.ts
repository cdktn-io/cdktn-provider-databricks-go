/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksVolumeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#id DataDatabricksVolume#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#name DataDatabricksVolume#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#provider_config DataDatabricksVolume#provider_config}
    */
    readonly providerConfig?: DataDatabricksVolumeProviderConfig;
    /**
    * volume_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#volume_info DataDatabricksVolume#volume_info}
    */
    readonly volumeInfo?: DataDatabricksVolumeVolumeInfo;
}
export interface DataDatabricksVolumeProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#workspace_id DataDatabricksVolume#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksVolumeProviderConfigToTerraform(struct?: DataDatabricksVolumeProviderConfigOutputReference | DataDatabricksVolumeProviderConfig): any;
export declare function dataDatabricksVolumeProviderConfigToHclTerraform(struct?: DataDatabricksVolumeProviderConfigOutputReference | DataDatabricksVolumeProviderConfig): any;
export declare class DataDatabricksVolumeProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksVolumeProviderConfig | undefined;
    set internalValue(value: DataDatabricksVolumeProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#algorithm DataDatabricksVolume#algorithm}
    */
    readonly algorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#aws_kms_key_arn DataDatabricksVolume#aws_kms_key_arn}
    */
    readonly awsKmsKeyArn?: string;
}
export declare function dataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetailsToTerraform(struct?: DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetailsOutputReference | DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails): any;
export declare function dataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetailsToHclTerraform(struct?: DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetailsOutputReference | DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails): any;
export declare class DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails | undefined;
    set internalValue(value: DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _awsKmsKeyArn?;
    get awsKmsKeyArn(): string;
    set awsKmsKeyArn(value: string);
    resetAwsKmsKeyArn(): void;
    get awsKmsKeyArnInput(): string | undefined;
}
export interface DataDatabricksVolumeVolumeInfoEncryptionDetails {
    /**
    * sse_encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#sse_encryption_details DataDatabricksVolume#sse_encryption_details}
    */
    readonly sseEncryptionDetails?: DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails;
}
export declare function dataDatabricksVolumeVolumeInfoEncryptionDetailsToTerraform(struct?: DataDatabricksVolumeVolumeInfoEncryptionDetailsOutputReference | DataDatabricksVolumeVolumeInfoEncryptionDetails): any;
export declare function dataDatabricksVolumeVolumeInfoEncryptionDetailsToHclTerraform(struct?: DataDatabricksVolumeVolumeInfoEncryptionDetailsOutputReference | DataDatabricksVolumeVolumeInfoEncryptionDetails): any;
export declare class DataDatabricksVolumeVolumeInfoEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksVolumeVolumeInfoEncryptionDetails | undefined;
    set internalValue(value: DataDatabricksVolumeVolumeInfoEncryptionDetails | undefined);
    private _sseEncryptionDetails;
    get sseEncryptionDetails(): DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetailsOutputReference;
    putSseEncryptionDetails(value: DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails): void;
    resetSseEncryptionDetails(): void;
    get sseEncryptionDetailsInput(): DataDatabricksVolumeVolumeInfoEncryptionDetailsSseEncryptionDetails | undefined;
}
export interface DataDatabricksVolumeVolumeInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#access_point DataDatabricksVolume#access_point}
    */
    readonly accessPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#browse_only DataDatabricksVolume#browse_only}
    */
    readonly browseOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#catalog_name DataDatabricksVolume#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#comment DataDatabricksVolume#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#created_at DataDatabricksVolume#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#created_by DataDatabricksVolume#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#full_name DataDatabricksVolume#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#metastore_id DataDatabricksVolume#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#name DataDatabricksVolume#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#owner DataDatabricksVolume#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#schema_name DataDatabricksVolume#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#storage_location DataDatabricksVolume#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#updated_at DataDatabricksVolume#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#updated_by DataDatabricksVolume#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#volume_id DataDatabricksVolume#volume_id}
    */
    readonly volumeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#volume_type DataDatabricksVolume#volume_type}
    */
    readonly volumeType?: string;
    /**
    * encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#encryption_details DataDatabricksVolume#encryption_details}
    */
    readonly encryptionDetails?: DataDatabricksVolumeVolumeInfoEncryptionDetails;
}
export declare function dataDatabricksVolumeVolumeInfoToTerraform(struct?: DataDatabricksVolumeVolumeInfoOutputReference | DataDatabricksVolumeVolumeInfo): any;
export declare function dataDatabricksVolumeVolumeInfoToHclTerraform(struct?: DataDatabricksVolumeVolumeInfoOutputReference | DataDatabricksVolumeVolumeInfo): any;
export declare class DataDatabricksVolumeVolumeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksVolumeVolumeInfo | undefined;
    set internalValue(value: DataDatabricksVolumeVolumeInfo | undefined);
    private _accessPoint?;
    get accessPoint(): string;
    set accessPoint(value: string);
    resetAccessPoint(): void;
    get accessPointInput(): string | undefined;
    private _browseOnly?;
    get browseOnly(): boolean | cdktn.IResolvable;
    set browseOnly(value: boolean | cdktn.IResolvable);
    resetBrowseOnly(): void;
    get browseOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    resetVolumeId(): void;
    get volumeIdInput(): string | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
    private _encryptionDetails;
    get encryptionDetails(): DataDatabricksVolumeVolumeInfoEncryptionDetailsOutputReference;
    putEncryptionDetails(value: DataDatabricksVolumeVolumeInfoEncryptionDetails): void;
    resetEncryptionDetails(): void;
    get encryptionDetailsInput(): DataDatabricksVolumeVolumeInfoEncryptionDetails | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume databricks_volume}
*/
export declare class DataDatabricksVolume extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_volume";
    /**
    * Generates CDKTN code for importing a DataDatabricksVolume resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksVolume to import
    * @param importFromId The id of the existing DataDatabricksVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/data-sources/volume databricks_volume} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksVolumeConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksVolumeConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksVolumeProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksVolumeProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksVolumeProviderConfig | undefined;
    private _volumeInfo;
    get volumeInfo(): DataDatabricksVolumeVolumeInfoOutputReference;
    putVolumeInfo(value: DataDatabricksVolumeVolumeInfo): void;
    resetVolumeInfo(): void;
    get volumeInfoInput(): DataDatabricksVolumeVolumeInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
