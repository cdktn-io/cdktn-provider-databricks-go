/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LibraryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#cluster_id Library#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#egg Library#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#id Library#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#jar Library#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#requirements Library#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#whl Library#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#cran Library#cran}
    */
    readonly cran?: LibraryCran[] | cdktn.IResolvable;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#maven Library#maven}
    */
    readonly maven?: LibraryMaven[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#provider_config Library#provider_config}
    */
    readonly providerConfig?: LibraryProviderConfig[] | cdktn.IResolvable;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#pypi Library#pypi}
    */
    readonly pypi?: LibraryPypi[] | cdktn.IResolvable;
}
export interface LibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#package Library#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#repo Library#repo}
    */
    readonly repo?: string;
}
export declare function libraryCranToTerraform(struct?: LibraryCran | cdktn.IResolvable): any;
export declare function libraryCranToHclTerraform(struct?: LibraryCran | cdktn.IResolvable): any;
export declare class LibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LibraryCran | cdktn.IResolvable | undefined;
    set internalValue(value: LibraryCran | cdktn.IResolvable | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export declare class LibraryCranList extends cdktn.ComplexList {
    internalValue?: LibraryCran[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LibraryCranOutputReference;
}
export interface LibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#coordinates Library#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#exclusions Library#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#repo Library#repo}
    */
    readonly repo?: string;
}
export declare function libraryMavenToTerraform(struct?: LibraryMaven | cdktn.IResolvable): any;
export declare function libraryMavenToHclTerraform(struct?: LibraryMaven | cdktn.IResolvable): any;
export declare class LibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LibraryMaven | cdktn.IResolvable | undefined;
    set internalValue(value: LibraryMaven | cdktn.IResolvable | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export declare class LibraryMavenList extends cdktn.ComplexList {
    internalValue?: LibraryMaven[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LibraryMavenOutputReference;
}
export interface LibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#workspace_id Library#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function libraryProviderConfigToTerraform(struct?: LibraryProviderConfig | cdktn.IResolvable): any;
export declare function libraryProviderConfigToHclTerraform(struct?: LibraryProviderConfig | cdktn.IResolvable): any;
export declare class LibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LibraryProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LibraryProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class LibraryProviderConfigList extends cdktn.ComplexList {
    internalValue?: LibraryProviderConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LibraryProviderConfigOutputReference;
}
export interface LibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#package Library#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#repo Library#repo}
    */
    readonly repo?: string;
}
export declare function libraryPypiToTerraform(struct?: LibraryPypi | cdktn.IResolvable): any;
export declare function libraryPypiToHclTerraform(struct?: LibraryPypi | cdktn.IResolvable): any;
export declare class LibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LibraryPypi | cdktn.IResolvable | undefined;
    set internalValue(value: LibraryPypi | cdktn.IResolvable | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export declare class LibraryPypiList extends cdktn.ComplexList {
    internalValue?: LibraryPypi[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LibraryPypiOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library databricks_library}
*/
export declare class Library extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_library";
    /**
    * Generates CDKTN code for importing a Library resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Library to import
    * @param importFromId The id of the existing Library that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Library to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.121.0/docs/resources/library databricks_library} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LibraryConfig
    */
    constructor(scope: Construct, id: string, config: LibraryConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): LibraryCranList;
    putCran(value: LibraryCran[] | cdktn.IResolvable): void;
    resetCran(): void;
    get cranInput(): cdktn.IResolvable | LibraryCran[] | undefined;
    private _maven;
    get maven(): LibraryMavenList;
    putMaven(value: LibraryMaven[] | cdktn.IResolvable): void;
    resetMaven(): void;
    get mavenInput(): cdktn.IResolvable | LibraryMaven[] | undefined;
    private _providerConfig;
    get providerConfig(): LibraryProviderConfigList;
    putProviderConfig(value: LibraryProviderConfig[] | cdktn.IResolvable): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | LibraryProviderConfig[] | undefined;
    private _pypi;
    get pypi(): LibraryPypiList;
    putPypi(value: LibraryPypi[] | cdktn.IResolvable): void;
    resetPypi(): void;
    get pypiInput(): cdktn.IResolvable | LibraryPypi[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
