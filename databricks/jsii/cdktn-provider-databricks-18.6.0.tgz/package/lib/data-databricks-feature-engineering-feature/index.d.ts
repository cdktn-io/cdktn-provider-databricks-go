/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksFeatureEngineeringFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#full_name DataDatabricksFeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#provider_config DataDatabricksFeatureEngineeringFeature#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringFeatureProviderConfig;
}
export interface DataDatabricksFeatureEngineeringFeatureEntities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureEntitiesToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureEntities): any;
export declare function dataDatabricksFeatureEngineeringFeatureEntitiesToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureEntities): any;
export declare class DataDatabricksFeatureEngineeringFeatureEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureEntities | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureEntities | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeatureEntitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringFeatureEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeatureEntitiesOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#relative_sd DataDatabricksFeatureEngineeringFeature#relative_sd}
    */
    readonly relativeSd?: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _relativeSd?;
    get relativeSd(): number;
    set relativeSd(value: number);
    resetRelativeSd(): void;
    get relativeSdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#accuracy DataDatabricksFeatureEngineeringFeature#accuracy}
    */
    readonly accuracy?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#percentile DataDatabricksFeatureEngineeringFeature#percentile}
    */
    readonly percentile: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | cdktn.IResolvable | undefined);
    private _accuracy?;
    get accuracy(): number;
    set accuracy(value: number);
    resetAccuracy(): void;
    get accuracyInput(): number | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _percentile?;
    get percentile(): number;
    set percentile(value: number);
    get percentileInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#n DataDatabricksFeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinctToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinctToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#n DataDatabricksFeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstNToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstNToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstNOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#n DataDatabricksFeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinctToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinctToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinctOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#n DataDatabricksFeatureEngineeringFeature#n}
    */
    readonly n: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastNToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastNToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastNOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
    private _n?;
    get n(): number;
    set n(value: number);
    get nInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#delay DataDatabricksFeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#delay DataDatabricksFeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#delay DataDatabricksFeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#offset DataDatabricksFeatureEngineeringFeature#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#slide_duration DataDatabricksFeatureEngineeringFeature#slide_duration}
    */
    readonly slideDuration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _slideDuration?;
    get slideDuration(): string;
    set slideDuration(value: string);
    get slideDurationInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    resetWindowDuration(): void;
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#delay DataDatabricksFeatureEngineeringFeature#delay}
    */
    readonly delay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#offset DataDatabricksFeatureEngineeringFeature#offset}
    */
    readonly offset?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#window_duration DataDatabricksFeatureEngineeringFeature#window_duration}
    */
    readonly windowDuration: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | cdktn.IResolvable | undefined);
    private _delay?;
    get delay(): string;
    set delay(value: string);
    resetDelay(): void;
    get delayInput(): string | undefined;
    private _offset?;
    get offset(): string;
    set offset(value: string);
    resetOffset(): void;
    get offsetInput(): string | undefined;
    private _windowDuration?;
    get windowDuration(): string;
    set windowDuration(value: string);
    get windowDurationInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#rolling DataDatabricksFeatureEngineeringFeature#rolling}
    */
    readonly rolling?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#sawtooth DataDatabricksFeatureEngineeringFeature#sawtooth}
    */
    readonly sawtooth?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#sliding DataDatabricksFeatureEngineeringFeature#sliding}
    */
    readonly sliding?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#start_time DataDatabricksFeatureEngineeringFeature#start_time}
    */
    readonly startTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#tumbling DataDatabricksFeatureEngineeringFeature#tumbling}
    */
    readonly tumbling?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | cdktn.IResolvable | undefined);
    private _rolling;
    get rolling(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRollingOutputReference;
    putRolling(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling): void;
    resetRolling(): void;
    get rollingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowRolling | undefined;
    private _sawtooth;
    get sawtooth(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtoothOutputReference;
    putSawtooth(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth): void;
    resetSawtooth(): void;
    get sawtoothInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSawtooth | undefined;
    private _sliding;
    get sliding(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSlidingOutputReference;
    putSliding(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding): void;
    resetSliding(): void;
    get slidingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowSliding | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    private _tumbling;
    get tumbling(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumblingOutputReference;
    putTumbling(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling): void;
    resetTumbling(): void;
    get tumblingInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowTumbling | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input DataDatabricksFeatureEngineeringFeature#input}
    */
    readonly input: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | cdktn.IResolvable | undefined);
    private _input?;
    get input(): string;
    set input(value: string);
    get inputInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#approx_count_distinct DataDatabricksFeatureEngineeringFeature#approx_count_distinct}
    */
    readonly approxCountDistinct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#approx_percentile DataDatabricksFeatureEngineeringFeature#approx_percentile}
    */
    readonly approxPercentile?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#avg DataDatabricksFeatureEngineeringFeature#avg}
    */
    readonly avg?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#count_function DataDatabricksFeatureEngineeringFeature#count_function}
    */
    readonly countFunction?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#first DataDatabricksFeatureEngineeringFeature#first}
    */
    readonly first?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#first_distinct DataDatabricksFeatureEngineeringFeature#first_distinct}
    */
    readonly firstDistinct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#first_n DataDatabricksFeatureEngineeringFeature#first_n}
    */
    readonly firstN?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#last DataDatabricksFeatureEngineeringFeature#last}
    */
    readonly last?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#last_distinct DataDatabricksFeatureEngineeringFeature#last_distinct}
    */
    readonly lastDistinct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#last_n DataDatabricksFeatureEngineeringFeature#last_n}
    */
    readonly lastN?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#max DataDatabricksFeatureEngineeringFeature#max}
    */
    readonly max?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#min DataDatabricksFeatureEngineeringFeature#min}
    */
    readonly min?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#stddev_pop DataDatabricksFeatureEngineeringFeature#stddev_pop}
    */
    readonly stddevPop?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#stddev_samp DataDatabricksFeatureEngineeringFeature#stddev_samp}
    */
    readonly stddevSamp?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#sum DataDatabricksFeatureEngineeringFeature#sum}
    */
    readonly sum?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#time_window DataDatabricksFeatureEngineeringFeature#time_window}
    */
    readonly timeWindow?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#var_pop DataDatabricksFeatureEngineeringFeature#var_pop}
    */
    readonly varPop?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#var_samp DataDatabricksFeatureEngineeringFeature#var_samp}
    */
    readonly varSamp?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | cdktn.IResolvable | undefined);
    private _approxCountDistinct;
    get approxCountDistinct(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinctOutputReference;
    putApproxCountDistinct(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct): void;
    resetApproxCountDistinct(): void;
    get approxCountDistinctInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxCountDistinct | undefined;
    private _approxPercentile;
    get approxPercentile(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentileOutputReference;
    putApproxPercentile(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile): void;
    resetApproxPercentile(): void;
    get approxPercentileInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionApproxPercentile | undefined;
    private _avg;
    get avg(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvgOutputReference;
    putAvg(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg): void;
    resetAvg(): void;
    get avgInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionAvg | undefined;
    private _countFunction;
    get countFunction(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunctionOutputReference;
    putCountFunction(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction): void;
    resetCountFunction(): void;
    get countFunctionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionCountFunction | undefined;
    private _first;
    get first(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstOutputReference;
    putFirst(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst): void;
    resetFirst(): void;
    get firstInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirst | undefined;
    private _firstDistinct;
    get firstDistinct(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinctOutputReference;
    putFirstDistinct(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct): void;
    resetFirstDistinct(): void;
    get firstDistinctInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstDistinct | undefined;
    private _firstN;
    get firstN(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstNOutputReference;
    putFirstN(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN): void;
    resetFirstN(): void;
    get firstNInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionFirstN | undefined;
    private _last;
    get last(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastOutputReference;
    putLast(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast): void;
    resetLast(): void;
    get lastInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLast | undefined;
    private _lastDistinct;
    get lastDistinct(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinctOutputReference;
    putLastDistinct(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct): void;
    resetLastDistinct(): void;
    get lastDistinctInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastDistinct | undefined;
    private _lastN;
    get lastN(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastNOutputReference;
    putLastN(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN): void;
    resetLastN(): void;
    get lastNInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionLastN | undefined;
    private _max;
    get max(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMaxOutputReference;
    putMax(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax): void;
    resetMax(): void;
    get maxInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMax | undefined;
    private _min;
    get min(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMinOutputReference;
    putMin(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin): void;
    resetMin(): void;
    get minInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionMin | undefined;
    private _stddevPop;
    get stddevPop(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPopOutputReference;
    putStddevPop(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop): void;
    resetStddevPop(): void;
    get stddevPopInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevPop | undefined;
    private _stddevSamp;
    get stddevSamp(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSampOutputReference;
    putStddevSamp(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp): void;
    resetStddevSamp(): void;
    get stddevSampInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionStddevSamp | undefined;
    private _sum;
    get sum(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSumOutputReference;
    putSum(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum): void;
    resetSum(): void;
    get sumInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionSum | undefined;
    private _timeWindow;
    get timeWindow(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindowOutputReference;
    putTimeWindow(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow): void;
    resetTimeWindow(): void;
    get timeWindowInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionTimeWindow | undefined;
    private _varPop;
    get varPop(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPopOutputReference;
    putVarPop(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop): void;
    resetVarPop(): void;
    get varPopInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarPop | undefined;
    private _varSamp;
    get varSamp(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSampOutputReference;
    putVarSamp(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp): void;
    resetVarSamp(): void;
    get varSampInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionVarSamp | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#column DataDatabricksFeatureEngineeringFeature#column}
    */
    readonly column: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#column DataDatabricksFeatureEngineeringFeature#column}
    */
    readonly column: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#parameter DataDatabricksFeatureEngineeringFeature#parameter}
    */
    readonly parameter: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindingsToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindingsToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    get columnInput(): string | undefined;
    private _parameter?;
    get parameter(): string;
    set parameter(value: string);
    get parameterInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindingsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindingsOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#function_path DataDatabricksFeatureEngineeringFeature#function_path}
    */
    readonly functionPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#input_bindings DataDatabricksFeatureEngineeringFeature#input_bindings}
    */
    readonly inputBindings?: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings[] | cdktn.IResolvable;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionCustomUdfToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionCustomUdfToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf | cdktn.IResolvable | undefined);
    private _functionPath?;
    get functionPath(): string;
    set functionPath(value: string);
    get functionPathInput(): string | undefined;
    private _inputBindings;
    get inputBindings(): DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindingsList;
    putInputBindings(value: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings[] | cdktn.IResolvable): void;
    resetInputBindings(): void;
    get inputBindingsInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfInputBindings[] | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#aggregation_function DataDatabricksFeatureEngineeringFeature#aggregation_function}
    */
    readonly aggregationFunction?: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#column_selection DataDatabricksFeatureEngineeringFeature#column_selection}
    */
    readonly columnSelection?: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#custom_udf DataDatabricksFeatureEngineeringFeature#custom_udf}
    */
    readonly customUdf?: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf;
}
export declare function dataDatabricksFeatureEngineeringFeatureFunctionToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunction): any;
export declare function dataDatabricksFeatureEngineeringFeatureFunctionToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureFunction): any;
export declare class DataDatabricksFeatureEngineeringFeatureFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureFunction | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureFunction | undefined);
    private _aggregationFunction;
    get aggregationFunction(): DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunctionOutputReference;
    putAggregationFunction(value: DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction): void;
    resetAggregationFunction(): void;
    get aggregationFunctionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionAggregationFunction | undefined;
    private _columnSelection;
    get columnSelection(): DataDatabricksFeatureEngineeringFeatureFunctionColumnSelectionOutputReference;
    putColumnSelection(value: DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection): void;
    resetColumnSelection(): void;
    get columnSelectionInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionColumnSelection | undefined;
    private _customUdf;
    get customUdf(): DataDatabricksFeatureEngineeringFeatureFunctionCustomUdfOutputReference;
    putCustomUdf(value: DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf): void;
    resetCustomUdf(): void;
    get customUdfInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureFunctionCustomUdf | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureLineageContextJobContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#job_id DataDatabricksFeatureEngineeringFeature#job_id}
    */
    readonly jobId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#job_run_id DataDatabricksFeatureEngineeringFeature#job_run_id}
    */
    readonly jobRunId?: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextJobContextToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextJobContextToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureLineageContextJobContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | cdktn.IResolvable | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    resetJobId(): void;
    get jobIdInput(): number | undefined;
    private _jobRunId?;
    get jobRunId(): number;
    set jobRunId(value: number);
    resetJobRunId(): void;
    get jobRunIdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureLineageContext {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#job_context DataDatabricksFeatureEngineeringFeature#job_context}
    */
    readonly jobContext?: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#notebook_id DataDatabricksFeatureEngineeringFeature#notebook_id}
    */
    readonly notebookId?: number;
}
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContext): any;
export declare function dataDatabricksFeatureEngineeringFeatureLineageContextToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureLineageContext): any;
export declare class DataDatabricksFeatureEngineeringFeatureLineageContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureLineageContext | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureLineageContext | undefined);
    private _jobContext;
    get jobContext(): DataDatabricksFeatureEngineeringFeatureLineageContextJobContextOutputReference;
    putJobContext(value: DataDatabricksFeatureEngineeringFeatureLineageContextJobContext): void;
    resetJobContext(): void;
    get jobContextInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureLineageContextJobContext | undefined;
    private _notebookId?;
    get notebookId(): number;
    set notebookId(value: number);
    resetNotebookId(): void;
    get notebookIdInput(): number | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#workspace_id DataDatabricksFeatureEngineeringFeature#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#dataframe_schema DataDatabricksFeatureEngineeringFeature#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#filter_condition DataDatabricksFeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#full_name DataDatabricksFeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#transformation_sql DataDatabricksFeatureEngineeringFeature#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceKafkaSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#filter_condition DataDatabricksFeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceKafkaSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | cdktn.IResolvable | undefined);
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceLateness {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#settling_delay DataDatabricksFeatureEngineeringFeature#settling_delay}
    */
    readonly settlingDelay?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceLatenessToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceLateness | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceLatenessToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceLateness | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceLatenessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceLateness | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceLateness | cdktn.IResolvable | undefined);
    private _settlingDelay?;
    get settlingDelay(): string;
    set settlingDelay(value: string);
    resetSettlingDelay(): void;
    get settlingDelayInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#data_type DataDatabricksFeatureEngineeringFeature#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields | undefined);
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsOutputReference;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#fields DataDatabricksFeatureEngineeringFeature#fields}
    */
    readonly fields: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | cdktn.IResolvable | undefined);
    private _fields;
    get fields(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFieldsList;
    putFields(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | cdktn.IResolvable): void;
    get fieldsInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaFields[] | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceRequestSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#flat_schema DataDatabricksFeatureEngineeringFeature#flat_schema}
    */
    readonly flatSchema?: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceRequestSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceRequestSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSource | cdktn.IResolvable | undefined);
    private _flatSchema;
    get flatSchema(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchemaOutputReference;
    putFlatSchema(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema): void;
    resetFlatSchema(): void;
    get flatSchemaInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceRequestSourceFlatSchema | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSourceStreamSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#dataframe_schema DataDatabricksFeatureEngineeringFeature#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#filter_condition DataDatabricksFeatureEngineeringFeature#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#full_name DataDatabricksFeatureEngineeringFeature#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#transformation_sql DataDatabricksFeatureEngineeringFeature#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceStreamSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceStreamSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceStreamSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSourceStreamSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#delta_table_source DataDatabricksFeatureEngineeringFeature#delta_table_source}
    */
    readonly deltaTableSource?: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#kafka_source DataDatabricksFeatureEngineeringFeature#kafka_source}
    */
    readonly kafkaSource?: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#lateness DataDatabricksFeatureEngineeringFeature#lateness}
    */
    readonly lateness?: DataDatabricksFeatureEngineeringFeatureSourceLateness;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#request_source DataDatabricksFeatureEngineeringFeature#request_source}
    */
    readonly requestSource?: DataDatabricksFeatureEngineeringFeatureSourceRequestSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#stream_source DataDatabricksFeatureEngineeringFeature#stream_source}
    */
    readonly streamSource?: DataDatabricksFeatureEngineeringFeatureSourceStreamSource;
}
export declare function dataDatabricksFeatureEngineeringFeatureSourceToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSource): any;
export declare function dataDatabricksFeatureEngineeringFeatureSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureSource): any;
export declare class DataDatabricksFeatureEngineeringFeatureSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureSource | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureSource | undefined);
    private _deltaTableSource;
    get deltaTableSource(): DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceDeltaTableSource | undefined;
    private _kafkaSource;
    get kafkaSource(): DataDatabricksFeatureEngineeringFeatureSourceKafkaSourceOutputReference;
    putKafkaSource(value: DataDatabricksFeatureEngineeringFeatureSourceKafkaSource): void;
    resetKafkaSource(): void;
    get kafkaSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceKafkaSource | undefined;
    private _lateness;
    get lateness(): DataDatabricksFeatureEngineeringFeatureSourceLatenessOutputReference;
    putLateness(value: DataDatabricksFeatureEngineeringFeatureSourceLateness): void;
    resetLateness(): void;
    get latenessInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceLateness | undefined;
    private _requestSource;
    get requestSource(): DataDatabricksFeatureEngineeringFeatureSourceRequestSourceOutputReference;
    putRequestSource(value: DataDatabricksFeatureEngineeringFeatureSourceRequestSource): void;
    resetRequestSource(): void;
    get requestSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceRequestSource | undefined;
    private _streamSource;
    get streamSource(): DataDatabricksFeatureEngineeringFeatureSourceStreamSourceOutputReference;
    putStreamSource(value: DataDatabricksFeatureEngineeringFeatureSourceStreamSource): void;
    resetStreamSource(): void;
    get streamSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureSourceStreamSource | undefined;
}
export interface DataDatabricksFeatureEngineeringFeatureTimeseriesColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#name DataDatabricksFeatureEngineeringFeature#name}
    */
    readonly name: string;
}
export declare function dataDatabricksFeatureEngineeringFeatureTimeseriesColumnToTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeseriesColumn): any;
export declare function dataDatabricksFeatureEngineeringFeatureTimeseriesColumnToHclTerraform(struct?: DataDatabricksFeatureEngineeringFeatureTimeseriesColumn): any;
export declare class DataDatabricksFeatureEngineeringFeatureTimeseriesColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringFeatureTimeseriesColumn | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringFeatureTimeseriesColumn | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature databricks_feature_engineering_feature}
*/
export declare class DataDatabricksFeatureEngineeringFeature extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_feature_engineering_feature";
    /**
    * Generates CDKTN code for importing a DataDatabricksFeatureEngineeringFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksFeatureEngineeringFeature to import
    * @param importFromId The id of the existing DataDatabricksFeatureEngineeringFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksFeatureEngineeringFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/feature_engineering_feature databricks_feature_engineering_feature} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksFeatureEngineeringFeatureConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksFeatureEngineeringFeatureConfig);
    get catalogName(): string;
    get createdAt(): string;
    get createdBy(): string;
    get description(): string;
    private _entities;
    get entities(): DataDatabricksFeatureEngineeringFeatureEntitiesList;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _function;
    get function(): DataDatabricksFeatureEngineeringFeatureFunctionOutputReference;
    private _lineageContext;
    get lineageContext(): DataDatabricksFeatureEngineeringFeatureLineageContextOutputReference;
    get name(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringFeatureProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringFeatureProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringFeatureProviderConfig | undefined;
    get schemaName(): string;
    private _source;
    get source(): DataDatabricksFeatureEngineeringFeatureSourceOutputReference;
    private _timeseriesColumn;
    get timeseriesColumn(): DataDatabricksFeatureEngineeringFeatureTimeseriesColumnOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
