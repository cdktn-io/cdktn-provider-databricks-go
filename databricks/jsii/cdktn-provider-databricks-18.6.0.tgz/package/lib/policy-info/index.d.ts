/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PolicyInfoConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#column_mask PolicyInfo#column_mask}
    */
    readonly columnMask?: PolicyInfoColumnMask;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#comment PolicyInfo#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#except_principals PolicyInfo#except_principals}
    */
    readonly exceptPrincipals?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#for_securable_type PolicyInfo#for_securable_type}
    */
    readonly forSecurableType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#grant PolicyInfo#grant}
    */
    readonly grant?: PolicyInfoGrant;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#match_columns PolicyInfo#match_columns}
    */
    readonly matchColumns?: PolicyInfoMatchColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#name PolicyInfo#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#on_securable_fullname PolicyInfo#on_securable_fullname}
    */
    readonly onSecurableFullname?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#on_securable_type PolicyInfo#on_securable_type}
    */
    readonly onSecurableType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#policy_type PolicyInfo#policy_type}
    */
    readonly policyType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#provider_config PolicyInfo#provider_config}
    */
    readonly providerConfig?: PolicyInfoProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#row_filter PolicyInfo#row_filter}
    */
    readonly rowFilter?: PolicyInfoRowFilter;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#to_principals PolicyInfo#to_principals}
    */
    readonly toPrincipals: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#when_condition PolicyInfo#when_condition}
    */
    readonly whenCondition?: string;
}
export interface PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#column_alias PolicyInfo#column_alias}
    */
    readonly columnAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_key PolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function policyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueToTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare function policyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueToHclTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare class PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined);
    private _columnAlias?;
    get columnAlias(): string;
    set columnAlias(value: string);
    get columnAliasInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_key PolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function policyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueToTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare function policyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueToHclTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare class PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#column_tag_value PolicyInfo#column_tag_value}
    */
    readonly columnTagValue?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_value PolicyInfo#tag_value}
    */
    readonly tagValue?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue;
}
export declare function policyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionToTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare function policyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionToHclTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare class PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined);
    private _columnTagValue;
    get columnTagValue(): PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference;
    putColumnTagValue(value: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue): void;
    resetColumnTagValue(): void;
    get columnTagValueInput(): cdktn.IResolvable | PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionColumnTagValue | undefined;
    private _tagValue;
    get tagValue(): PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference;
    putTagValue(value: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue): void;
    resetTagValue(): void;
    get tagValueInput(): cdktn.IResolvable | PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionTagValue | undefined;
}
export interface PolicyInfoColumnMaskUsingFunctionArgExpression {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_introspection PolicyInfo#tag_introspection}
    */
    readonly tagIntrospection?: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection;
}
export declare function policyInfoColumnMaskUsingFunctionArgExpressionToTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare function policyInfoColumnMaskUsingFunctionArgExpressionToHclTerraform(struct?: PolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare class PolicyInfoColumnMaskUsingFunctionArgExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoColumnMaskUsingFunctionArgExpression | cdktn.IResolvable | undefined);
    private _tagIntrospection;
    get tagIntrospection(): PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospectionOutputReference;
    putTagIntrospection(value: PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection): void;
    resetTagIntrospection(): void;
    get tagIntrospectionInput(): cdktn.IResolvable | PolicyInfoColumnMaskUsingFunctionArgExpressionTagIntrospection | undefined;
}
export interface PolicyInfoColumnMaskUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#alias PolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#constant PolicyInfo#constant}
    */
    readonly constant?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#function_arg_expression PolicyInfo#function_arg_expression}
    */
    readonly functionArgExpression?: PolicyInfoColumnMaskUsingFunctionArgExpression;
}
export declare function policyInfoColumnMaskUsingToTerraform(struct?: PolicyInfoColumnMaskUsing | cdktn.IResolvable): any;
export declare function policyInfoColumnMaskUsingToHclTerraform(struct?: PolicyInfoColumnMaskUsing | cdktn.IResolvable): any;
export declare class PolicyInfoColumnMaskUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PolicyInfoColumnMaskUsing | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoColumnMaskUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
    private _functionArgExpression;
    get functionArgExpression(): PolicyInfoColumnMaskUsingFunctionArgExpressionOutputReference;
    putFunctionArgExpression(value: PolicyInfoColumnMaskUsingFunctionArgExpression): void;
    resetFunctionArgExpression(): void;
    get functionArgExpressionInput(): cdktn.IResolvable | PolicyInfoColumnMaskUsingFunctionArgExpression | undefined;
}
export declare class PolicyInfoColumnMaskUsingList extends cdktn.ComplexList {
    internalValue?: PolicyInfoColumnMaskUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PolicyInfoColumnMaskUsingOutputReference;
}
export interface PolicyInfoColumnMask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#function_name PolicyInfo#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#on_column PolicyInfo#on_column}
    */
    readonly onColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#using PolicyInfo#using}
    */
    readonly using?: PolicyInfoColumnMaskUsing[] | cdktn.IResolvable;
}
export declare function policyInfoColumnMaskToTerraform(struct?: PolicyInfoColumnMask | cdktn.IResolvable): any;
export declare function policyInfoColumnMaskToHclTerraform(struct?: PolicyInfoColumnMask | cdktn.IResolvable): any;
export declare class PolicyInfoColumnMaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoColumnMask | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoColumnMask | cdktn.IResolvable | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _onColumn?;
    get onColumn(): string;
    set onColumn(value: string);
    get onColumnInput(): string | undefined;
    private _using;
    get using(): PolicyInfoColumnMaskUsingList;
    putUsing(value: PolicyInfoColumnMaskUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | PolicyInfoColumnMaskUsing[] | undefined;
}
export interface PolicyInfoGrant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#privileges PolicyInfo#privileges}
    */
    readonly privileges: string[];
}
export declare function policyInfoGrantToTerraform(struct?: PolicyInfoGrant | cdktn.IResolvable): any;
export declare function policyInfoGrantToHclTerraform(struct?: PolicyInfoGrant | cdktn.IResolvable): any;
export declare class PolicyInfoGrantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoGrant | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoGrant | cdktn.IResolvable | undefined);
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
}
export interface PolicyInfoMatchColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#alias PolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#condition PolicyInfo#condition}
    */
    readonly condition?: string;
}
export declare function policyInfoMatchColumnsToTerraform(struct?: PolicyInfoMatchColumns | cdktn.IResolvable): any;
export declare function policyInfoMatchColumnsToHclTerraform(struct?: PolicyInfoMatchColumns | cdktn.IResolvable): any;
export declare class PolicyInfoMatchColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PolicyInfoMatchColumns | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoMatchColumns | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
}
export declare class PolicyInfoMatchColumnsList extends cdktn.ComplexList {
    internalValue?: PolicyInfoMatchColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PolicyInfoMatchColumnsOutputReference;
}
export interface PolicyInfoProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#workspace_id PolicyInfo#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function policyInfoProviderConfigToTerraform(struct?: PolicyInfoProviderConfig | cdktn.IResolvable): any;
export declare function policyInfoProviderConfigToHclTerraform(struct?: PolicyInfoProviderConfig | cdktn.IResolvable): any;
export declare class PolicyInfoProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#column_alias PolicyInfo#column_alias}
    */
    readonly columnAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_key PolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function policyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueToTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare function policyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueToHclTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable): any;
export declare class PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | cdktn.IResolvable | undefined);
    private _columnAlias?;
    get columnAlias(): string;
    set columnAlias(value: string);
    get columnAliasInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_key PolicyInfo#tag_key}
    */
    readonly tagKey: string;
}
export declare function policyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueToTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare function policyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueToHclTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable): any;
export declare class PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | cdktn.IResolvable | undefined);
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
}
export interface PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#column_tag_value PolicyInfo#column_tag_value}
    */
    readonly columnTagValue?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_value PolicyInfo#tag_value}
    */
    readonly tagValue?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue;
}
export declare function policyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionToTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare function policyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionToHclTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable): any;
export declare class PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | cdktn.IResolvable | undefined);
    private _columnTagValue;
    get columnTagValue(): PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValueOutputReference;
    putColumnTagValue(value: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue): void;
    resetColumnTagValue(): void;
    get columnTagValueInput(): cdktn.IResolvable | PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionColumnTagValue | undefined;
    private _tagValue;
    get tagValue(): PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValueOutputReference;
    putTagValue(value: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue): void;
    resetTagValue(): void;
    get tagValueInput(): cdktn.IResolvable | PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionTagValue | undefined;
}
export interface PolicyInfoRowFilterUsingFunctionArgExpression {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#tag_introspection PolicyInfo#tag_introspection}
    */
    readonly tagIntrospection?: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection;
}
export declare function policyInfoRowFilterUsingFunctionArgExpressionToTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare function policyInfoRowFilterUsingFunctionArgExpressionToHclTerraform(struct?: PolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable): any;
export declare class PolicyInfoRowFilterUsingFunctionArgExpressionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoRowFilterUsingFunctionArgExpression | cdktn.IResolvable | undefined);
    private _tagIntrospection;
    get tagIntrospection(): PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospectionOutputReference;
    putTagIntrospection(value: PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection): void;
    resetTagIntrospection(): void;
    get tagIntrospectionInput(): cdktn.IResolvable | PolicyInfoRowFilterUsingFunctionArgExpressionTagIntrospection | undefined;
}
export interface PolicyInfoRowFilterUsing {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#alias PolicyInfo#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#constant PolicyInfo#constant}
    */
    readonly constant?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#function_arg_expression PolicyInfo#function_arg_expression}
    */
    readonly functionArgExpression?: PolicyInfoRowFilterUsingFunctionArgExpression;
}
export declare function policyInfoRowFilterUsingToTerraform(struct?: PolicyInfoRowFilterUsing | cdktn.IResolvable): any;
export declare function policyInfoRowFilterUsingToHclTerraform(struct?: PolicyInfoRowFilterUsing | cdktn.IResolvable): any;
export declare class PolicyInfoRowFilterUsingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): PolicyInfoRowFilterUsing | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoRowFilterUsing | cdktn.IResolvable | undefined);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
    private _functionArgExpression;
    get functionArgExpression(): PolicyInfoRowFilterUsingFunctionArgExpressionOutputReference;
    putFunctionArgExpression(value: PolicyInfoRowFilterUsingFunctionArgExpression): void;
    resetFunctionArgExpression(): void;
    get functionArgExpressionInput(): cdktn.IResolvable | PolicyInfoRowFilterUsingFunctionArgExpression | undefined;
}
export declare class PolicyInfoRowFilterUsingList extends cdktn.ComplexList {
    internalValue?: PolicyInfoRowFilterUsing[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): PolicyInfoRowFilterUsingOutputReference;
}
export interface PolicyInfoRowFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#function_name PolicyInfo#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#using PolicyInfo#using}
    */
    readonly using?: PolicyInfoRowFilterUsing[] | cdktn.IResolvable;
}
export declare function policyInfoRowFilterToTerraform(struct?: PolicyInfoRowFilter | cdktn.IResolvable): any;
export declare function policyInfoRowFilterToHclTerraform(struct?: PolicyInfoRowFilter | cdktn.IResolvable): any;
export declare class PolicyInfoRowFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PolicyInfoRowFilter | cdktn.IResolvable | undefined;
    set internalValue(value: PolicyInfoRowFilter | cdktn.IResolvable | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _using;
    get using(): PolicyInfoRowFilterUsingList;
    putUsing(value: PolicyInfoRowFilterUsing[] | cdktn.IResolvable): void;
    resetUsing(): void;
    get usingInput(): cdktn.IResolvable | PolicyInfoRowFilterUsing[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info databricks_policy_info}
*/
export declare class PolicyInfo extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_policy_info";
    /**
    * Generates CDKTN code for importing a PolicyInfo resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PolicyInfo to import
    * @param importFromId The id of the existing PolicyInfo that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PolicyInfo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/policy_info databricks_policy_info} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PolicyInfoConfig
    */
    constructor(scope: Construct, id: string, config: PolicyInfoConfig);
    private _columnMask;
    get columnMask(): PolicyInfoColumnMaskOutputReference;
    putColumnMask(value: PolicyInfoColumnMask): void;
    resetColumnMask(): void;
    get columnMaskInput(): cdktn.IResolvable | PolicyInfoColumnMask | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdAt(): number;
    get createdBy(): string;
    private _exceptPrincipals?;
    get exceptPrincipals(): string[];
    set exceptPrincipals(value: string[]);
    resetExceptPrincipals(): void;
    get exceptPrincipalsInput(): string[] | undefined;
    private _forSecurableType?;
    get forSecurableType(): string;
    set forSecurableType(value: string);
    get forSecurableTypeInput(): string | undefined;
    private _grant;
    get grant(): PolicyInfoGrantOutputReference;
    putGrant(value: PolicyInfoGrant): void;
    resetGrant(): void;
    get grantInput(): cdktn.IResolvable | PolicyInfoGrant | undefined;
    get id(): string;
    private _matchColumns;
    get matchColumns(): PolicyInfoMatchColumnsList;
    putMatchColumns(value: PolicyInfoMatchColumns[] | cdktn.IResolvable): void;
    resetMatchColumns(): void;
    get matchColumnsInput(): cdktn.IResolvable | PolicyInfoMatchColumns[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _onSecurableFullname?;
    get onSecurableFullname(): string;
    set onSecurableFullname(value: string);
    resetOnSecurableFullname(): void;
    get onSecurableFullnameInput(): string | undefined;
    private _onSecurableType?;
    get onSecurableType(): string;
    set onSecurableType(value: string);
    resetOnSecurableType(): void;
    get onSecurableTypeInput(): string | undefined;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    get policyTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PolicyInfoProviderConfigOutputReference;
    putProviderConfig(value: PolicyInfoProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PolicyInfoProviderConfig | undefined;
    private _rowFilter;
    get rowFilter(): PolicyInfoRowFilterOutputReference;
    putRowFilter(value: PolicyInfoRowFilter): void;
    resetRowFilter(): void;
    get rowFilterInput(): cdktn.IResolvable | PolicyInfoRowFilter | undefined;
    private _toPrincipals?;
    get toPrincipals(): string[];
    set toPrincipals(value: string[]);
    get toPrincipalsInput(): string[] | undefined;
    get updatedAt(): number;
    get updatedBy(): string;
    private _whenCondition?;
    get whenCondition(): string;
    set whenCondition(value: string);
    resetWhenCondition(): void;
    get whenConditionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
