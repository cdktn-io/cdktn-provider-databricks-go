/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KnowledgeAssistantKnowledgeSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#description KnowledgeAssistantKnowledgeSource#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#display_name KnowledgeAssistantKnowledgeSource#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#file_table KnowledgeAssistantKnowledgeSource#file_table}
    */
    readonly fileTable?: KnowledgeAssistantKnowledgeSourceFileTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#files KnowledgeAssistantKnowledgeSource#files}
    */
    readonly files?: KnowledgeAssistantKnowledgeSourceFiles;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#index KnowledgeAssistantKnowledgeSource#index}
    */
    readonly index?: KnowledgeAssistantKnowledgeSourceIndex;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#parent KnowledgeAssistantKnowledgeSource#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#provider_config KnowledgeAssistantKnowledgeSource#provider_config}
    */
    readonly providerConfig?: KnowledgeAssistantKnowledgeSourceProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#source_type KnowledgeAssistantKnowledgeSource#source_type}
    */
    readonly sourceType: string;
}
export interface KnowledgeAssistantKnowledgeSourceFileTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#file_col KnowledgeAssistantKnowledgeSource#file_col}
    */
    readonly fileCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#table_name KnowledgeAssistantKnowledgeSource#table_name}
    */
    readonly tableName: string;
}
export declare function knowledgeAssistantKnowledgeSourceFileTableToTerraform(struct?: KnowledgeAssistantKnowledgeSourceFileTable | cdktn.IResolvable): any;
export declare function knowledgeAssistantKnowledgeSourceFileTableToHclTerraform(struct?: KnowledgeAssistantKnowledgeSourceFileTable | cdktn.IResolvable): any;
export declare class KnowledgeAssistantKnowledgeSourceFileTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KnowledgeAssistantKnowledgeSourceFileTable | cdktn.IResolvable | undefined;
    set internalValue(value: KnowledgeAssistantKnowledgeSourceFileTable | cdktn.IResolvable | undefined);
    private _fileCol?;
    get fileCol(): string;
    set fileCol(value: string);
    get fileColInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface KnowledgeAssistantKnowledgeSourceFiles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#path KnowledgeAssistantKnowledgeSource#path}
    */
    readonly path: string;
}
export declare function knowledgeAssistantKnowledgeSourceFilesToTerraform(struct?: KnowledgeAssistantKnowledgeSourceFiles | cdktn.IResolvable): any;
export declare function knowledgeAssistantKnowledgeSourceFilesToHclTerraform(struct?: KnowledgeAssistantKnowledgeSourceFiles | cdktn.IResolvable): any;
export declare class KnowledgeAssistantKnowledgeSourceFilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KnowledgeAssistantKnowledgeSourceFiles | cdktn.IResolvable | undefined;
    set internalValue(value: KnowledgeAssistantKnowledgeSourceFiles | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface KnowledgeAssistantKnowledgeSourceIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#doc_uri_col KnowledgeAssistantKnowledgeSource#doc_uri_col}
    */
    readonly docUriCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#index_name KnowledgeAssistantKnowledgeSource#index_name}
    */
    readonly indexName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#text_col KnowledgeAssistantKnowledgeSource#text_col}
    */
    readonly textCol: string;
}
export declare function knowledgeAssistantKnowledgeSourceIndexToTerraform(struct?: KnowledgeAssistantKnowledgeSourceIndex | cdktn.IResolvable): any;
export declare function knowledgeAssistantKnowledgeSourceIndexToHclTerraform(struct?: KnowledgeAssistantKnowledgeSourceIndex | cdktn.IResolvable): any;
export declare class KnowledgeAssistantKnowledgeSourceIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KnowledgeAssistantKnowledgeSourceIndex | cdktn.IResolvable | undefined;
    set internalValue(value: KnowledgeAssistantKnowledgeSourceIndex | cdktn.IResolvable | undefined);
    private _docUriCol?;
    get docUriCol(): string;
    set docUriCol(value: string);
    get docUriColInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _textCol?;
    get textCol(): string;
    set textCol(value: string);
    get textColInput(): string | undefined;
}
export interface KnowledgeAssistantKnowledgeSourceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#workspace_id KnowledgeAssistantKnowledgeSource#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function knowledgeAssistantKnowledgeSourceProviderConfigToTerraform(struct?: KnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable): any;
export declare function knowledgeAssistantKnowledgeSourceProviderConfigToHclTerraform(struct?: KnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable): any;
export declare class KnowledgeAssistantKnowledgeSourceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: KnowledgeAssistantKnowledgeSourceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source databricks_knowledge_assistant_knowledge_source}
*/
export declare class KnowledgeAssistantKnowledgeSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_knowledge_assistant_knowledge_source";
    /**
    * Generates CDKTN code for importing a KnowledgeAssistantKnowledgeSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KnowledgeAssistantKnowledgeSource to import
    * @param importFromId The id of the existing KnowledgeAssistantKnowledgeSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KnowledgeAssistantKnowledgeSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant_knowledge_source databricks_knowledge_assistant_knowledge_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KnowledgeAssistantKnowledgeSourceConfig
    */
    constructor(scope: Construct, id: string, config: KnowledgeAssistantKnowledgeSourceConfig);
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _fileTable;
    get fileTable(): KnowledgeAssistantKnowledgeSourceFileTableOutputReference;
    putFileTable(value: KnowledgeAssistantKnowledgeSourceFileTable): void;
    resetFileTable(): void;
    get fileTableInput(): cdktn.IResolvable | KnowledgeAssistantKnowledgeSourceFileTable | undefined;
    private _files;
    get files(): KnowledgeAssistantKnowledgeSourceFilesOutputReference;
    putFiles(value: KnowledgeAssistantKnowledgeSourceFiles): void;
    resetFiles(): void;
    get filesInput(): cdktn.IResolvable | KnowledgeAssistantKnowledgeSourceFiles | undefined;
    get id(): string;
    private _index;
    get index(): KnowledgeAssistantKnowledgeSourceIndexOutputReference;
    putIndex(value: KnowledgeAssistantKnowledgeSourceIndex): void;
    resetIndex(): void;
    get indexInput(): cdktn.IResolvable | KnowledgeAssistantKnowledgeSourceIndex | undefined;
    get knowledgeCutoffTime(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): KnowledgeAssistantKnowledgeSourceProviderConfigOutputReference;
    putProviderConfig(value: KnowledgeAssistantKnowledgeSourceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | KnowledgeAssistantKnowledgeSourceProviderConfig | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
