/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RepoConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#branch Repo#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#commit_hash Repo#commit_hash}
    */
    readonly commitHash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#git_credential_id Repo#git_credential_id}
    */
    readonly gitCredentialId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#git_provider Repo#git_provider}
    */
    readonly gitProvider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#id Repo#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#path Repo#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#tag Repo#tag}
    */
    readonly tag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#url Repo#url}
    */
    readonly url: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#provider_config Repo#provider_config}
    */
    readonly providerConfig?: RepoProviderConfig;
    /**
    * sparse_checkout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#sparse_checkout Repo#sparse_checkout}
    */
    readonly sparseCheckout?: RepoSparseCheckout;
}
export interface RepoProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#workspace_id Repo#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function repoProviderConfigToTerraform(struct?: RepoProviderConfigOutputReference | RepoProviderConfig): any;
export declare function repoProviderConfigToHclTerraform(struct?: RepoProviderConfigOutputReference | RepoProviderConfig): any;
export declare class RepoProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RepoProviderConfig | undefined;
    set internalValue(value: RepoProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface RepoSparseCheckout {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#patterns Repo#patterns}
    */
    readonly patterns: string[];
}
export declare function repoSparseCheckoutToTerraform(struct?: RepoSparseCheckoutOutputReference | RepoSparseCheckout): any;
export declare function repoSparseCheckoutToHclTerraform(struct?: RepoSparseCheckoutOutputReference | RepoSparseCheckout): any;
export declare class RepoSparseCheckoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RepoSparseCheckout | undefined;
    set internalValue(value: RepoSparseCheckout | undefined);
    private _patterns?;
    get patterns(): string[];
    set patterns(value: string[]);
    get patternsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo databricks_repo}
*/
export declare class Repo extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_repo";
    /**
    * Generates CDKTN code for importing a Repo resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Repo to import
    * @param importFromId The id of the existing Repo that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Repo to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/repo databricks_repo} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RepoConfig
    */
    constructor(scope: Construct, id: string, config: RepoConfig);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commitHash?;
    get commitHash(): string;
    set commitHash(value: string);
    resetCommitHash(): void;
    get commitHashInput(): string | undefined;
    private _gitCredentialId?;
    get gitCredentialId(): number;
    set gitCredentialId(value: number);
    resetGitCredentialId(): void;
    get gitCredentialIdInput(): number | undefined;
    private _gitProvider?;
    get gitProvider(): string;
    set gitProvider(value: string);
    resetGitProvider(): void;
    get gitProviderInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    get workspacePath(): string;
    private _providerConfig;
    get providerConfig(): RepoProviderConfigOutputReference;
    putProviderConfig(value: RepoProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): RepoProviderConfig | undefined;
    private _sparseCheckout;
    get sparseCheckout(): RepoSparseCheckoutOutputReference;
    putSparseCheckout(value: RepoSparseCheckout): void;
    resetSparseCheckout(): void;
    get sparseCheckoutInput(): RepoSparseCheckout | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
