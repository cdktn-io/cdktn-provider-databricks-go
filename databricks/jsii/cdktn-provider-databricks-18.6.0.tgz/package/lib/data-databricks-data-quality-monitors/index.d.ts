/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDataQualityMonitorsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#page_size DataDatabricksDataQualityMonitors#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#provider_config DataDatabricksDataQualityMonitors#provider_config}
    */
    readonly providerConfig?: DataDatabricksDataQualityMonitorsProviderConfig;
}
export interface DataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#excluded_table_full_names DataDatabricksDataQualityMonitors#excluded_table_full_names}
    */
    readonly excludedTableFullNames?: string[];
}
export declare function dataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfigToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfig): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfigToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfig): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfig | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfig | undefined);
    private _excludedTableFullNames?;
    get excludedTableFullNames(): string[];
    set excludedTableFullNames(value: string[]);
    resetExcludedTableFullNames(): void;
    get excludedTableFullNamesInput(): string[] | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#definition DataDatabricksDataQualityMonitors#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#input_columns DataDatabricksDataQualityMonitors#input_columns}
    */
    readonly inputColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#name DataDatabricksDataQualityMonitors#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#output_data_type DataDatabricksDataQualityMonitors#output_data_type}
    */
    readonly outputDataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#type DataDatabricksDataQualityMonitors#type}
    */
    readonly type: string;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetricsToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetricsToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _inputColumns?;
    get inputColumns(): string[];
    set inputColumns(value: string[]);
    get inputColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputDataType?;
    get outputDataType(): string;
    set outputDataType(value: string);
    get outputDataTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetricsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetricsOutputReference;
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#granularities DataDatabricksDataQualityMonitors#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#label_column DataDatabricksDataQualityMonitors#label_column}
    */
    readonly labelColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#model_id_column DataDatabricksDataQualityMonitors#model_id_column}
    */
    readonly modelIdColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#prediction_column DataDatabricksDataQualityMonitors#prediction_column}
    */
    readonly predictionColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#problem_type DataDatabricksDataQualityMonitors#problem_type}
    */
    readonly problemType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#timestamp_column DataDatabricksDataQualityMonitors#timestamp_column}
    */
    readonly timestampColumn: string;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLogToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLogToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _labelColumn?;
    get labelColumn(): string;
    set labelColumn(value: string);
    resetLabelColumn(): void;
    get labelColumnInput(): string | undefined;
    private _modelIdColumn?;
    get modelIdColumn(): string;
    set modelIdColumn(value: string);
    get modelIdColumnInput(): string | undefined;
    private _predictionColumn?;
    get predictionColumn(): string;
    set predictionColumn(value: string);
    get predictionColumnInput(): string | undefined;
    private _problemType?;
    get problemType(): string;
    set problemType(value: string);
    get problemTypeInput(): string | undefined;
    private _timestampColumn?;
    get timestampColumn(): string;
    set timestampColumn(value: string);
    get timestampColumnInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#email_addresses DataDatabricksDataQualityMonitors#email_addresses}
    */
    readonly emailAddresses?: string[];
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailureToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailureToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable | undefined);
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#on_failure DataDatabricksDataQualityMonitors#on_failure}
    */
    readonly onFailure?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings | cdktn.IResolvable | undefined);
    private _onFailure;
    get onFailure(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailureOutputReference;
    putOnFailure(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOnFailure | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#quartz_cron_expression DataDatabricksDataQualityMonitors#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#timezone_id DataDatabricksDataQualityMonitors#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigScheduleToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigScheduleToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule | cdktn.IResolvable | undefined);
    get pauseStatus(): string;
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot {
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshotToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshotToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot | cdktn.IResolvable | undefined);
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#granularities DataDatabricksDataQualityMonitors#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#timestamp_column DataDatabricksDataQualityMonitors#timestamp_column}
    */
    readonly timestampColumn: string;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeriesToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeriesToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _timestampColumn?;
    get timestampColumn(): string;
    set timestampColumn(value: string);
    get timestampColumnInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#assets_dir DataDatabricksDataQualityMonitors#assets_dir}
    */
    readonly assetsDir?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#baseline_table_name DataDatabricksDataQualityMonitors#baseline_table_name}
    */
    readonly baselineTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#custom_metrics DataDatabricksDataQualityMonitors#custom_metrics}
    */
    readonly customMetrics?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#inference_log DataDatabricksDataQualityMonitors#inference_log}
    */
    readonly inferenceLog?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#notification_settings DataDatabricksDataQualityMonitors#notification_settings}
    */
    readonly notificationSettings?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#output_schema_id DataDatabricksDataQualityMonitors#output_schema_id}
    */
    readonly outputSchemaId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#schedule DataDatabricksDataQualityMonitors#schedule}
    */
    readonly schedule?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#skip_builtin_dashboard DataDatabricksDataQualityMonitors#skip_builtin_dashboard}
    */
    readonly skipBuiltinDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#slicing_exprs DataDatabricksDataQualityMonitors#slicing_exprs}
    */
    readonly slicingExprs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#snapshot DataDatabricksDataQualityMonitors#snapshot}
    */
    readonly snapshot?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#time_series DataDatabricksDataQualityMonitors#time_series}
    */
    readonly timeSeries?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#warehouse_id DataDatabricksDataQualityMonitors#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfig): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfig): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfig | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfig | undefined);
    private _assetsDir?;
    get assetsDir(): string;
    set assetsDir(value: string);
    resetAssetsDir(): void;
    get assetsDirInput(): string | undefined;
    private _baselineTableName?;
    get baselineTableName(): string;
    set baselineTableName(value: string);
    resetBaselineTableName(): void;
    get baselineTableNameInput(): string | undefined;
    private _customMetrics;
    get customMetrics(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetricsList;
    putCustomMetrics(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigCustomMetrics[] | undefined;
    get dashboardId(): string;
    get driftMetricsTableName(): string;
    get effectiveWarehouseId(): string;
    private _inferenceLog;
    get inferenceLog(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLogOutputReference;
    putInferenceLog(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog): void;
    resetInferenceLog(): void;
    get inferenceLogInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigInferenceLog | undefined;
    get latestMonitorFailureMessage(): string;
    get monitorVersion(): number;
    get monitoredTableName(): string;
    private _notificationSettings;
    get notificationSettings(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettingsOutputReference;
    putNotificationSettings(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigNotificationSettings | undefined;
    private _outputSchemaId?;
    get outputSchemaId(): string;
    set outputSchemaId(value: string);
    get outputSchemaIdInput(): string | undefined;
    get profileMetricsTableName(): string;
    private _schedule;
    get schedule(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigScheduleOutputReference;
    putSchedule(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSchedule | undefined;
    private _skipBuiltinDashboard?;
    get skipBuiltinDashboard(): boolean | cdktn.IResolvable;
    set skipBuiltinDashboard(value: boolean | cdktn.IResolvable);
    resetSkipBuiltinDashboard(): void;
    get skipBuiltinDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _slicingExprs?;
    get slicingExprs(): string[];
    set slicingExprs(value: string[]);
    resetSlicingExprs(): void;
    get slicingExprsInput(): string[] | undefined;
    private _snapshot;
    get snapshot(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshotOutputReference;
    putSnapshot(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot): void;
    resetSnapshot(): void;
    get snapshotInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigSnapshot | undefined;
    get status(): string;
    private _timeSeries;
    get timeSeries(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeriesOutputReference;
    putTimeSeries(value: DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries): void;
    resetTimeSeries(): void;
    get timeSeriesInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigTimeSeries | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitorsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#workspace_id DataDatabricksDataQualityMonitors#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsProviderConfigToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsProviderConfigToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitorsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitorsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitorsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorsMonitors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#object_id DataDatabricksDataQualityMonitors#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#object_type DataDatabricksDataQualityMonitors#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#provider_config DataDatabricksDataQualityMonitors#provider_config}
    */
    readonly providerConfig?: DataDatabricksDataQualityMonitorsMonitorsProviderConfig;
}
export declare function dataDatabricksDataQualityMonitorsMonitorsToTerraform(struct?: DataDatabricksDataQualityMonitorsMonitors): any;
export declare function dataDatabricksDataQualityMonitorsMonitorsToHclTerraform(struct?: DataDatabricksDataQualityMonitorsMonitors): any;
export declare class DataDatabricksDataQualityMonitorsMonitorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDataQualityMonitorsMonitors | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsMonitors | undefined);
    private _anomalyDetectionConfig;
    get anomalyDetectionConfig(): DataDatabricksDataQualityMonitorsMonitorsAnomalyDetectionConfigOutputReference;
    private _dataProfilingConfig;
    get dataProfilingConfig(): DataDatabricksDataQualityMonitorsMonitorsDataProfilingConfigOutputReference;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDataQualityMonitorsMonitorsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDataQualityMonitorsMonitorsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsMonitorsProviderConfig | undefined;
}
export declare class DataDatabricksDataQualityMonitorsMonitorsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDataQualityMonitorsMonitors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDataQualityMonitorsMonitorsOutputReference;
}
export interface DataDatabricksDataQualityMonitorsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#workspace_id DataDatabricksDataQualityMonitors#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDataQualityMonitorsProviderConfigToTerraform(struct?: DataDatabricksDataQualityMonitorsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorsProviderConfigToHclTerraform(struct?: DataDatabricksDataQualityMonitorsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors databricks_data_quality_monitors}
*/
export declare class DataDatabricksDataQualityMonitors extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_data_quality_monitors";
    /**
    * Generates CDKTN code for importing a DataDatabricksDataQualityMonitors resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDataQualityMonitors to import
    * @param importFromId The id of the existing DataDatabricksDataQualityMonitors that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDataQualityMonitors to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/data_quality_monitors databricks_data_quality_monitors} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDataQualityMonitorsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksDataQualityMonitorsConfig);
    private _monitors;
    get monitors(): DataDatabricksDataQualityMonitorsMonitorsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDataQualityMonitorsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDataQualityMonitorsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
