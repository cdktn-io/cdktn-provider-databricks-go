/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface StorageCredentialConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#api StorageCredential#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#comment StorageCredential#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#force_destroy StorageCredential#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#force_update StorageCredential#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#id StorageCredential#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#isolation_mode StorageCredential#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#metastore_id StorageCredential#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#name StorageCredential#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#owner StorageCredential#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#read_only StorageCredential#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#skip_validation StorageCredential#skip_validation}
    */
    readonly skipValidation?: boolean | cdktn.IResolvable;
    /**
    * aws_iam_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#aws_iam_role StorageCredential#aws_iam_role}
    */
    readonly awsIamRole?: StorageCredentialAwsIamRole;
    /**
    * azure_managed_identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#azure_managed_identity StorageCredential#azure_managed_identity}
    */
    readonly azureManagedIdentity?: StorageCredentialAzureManagedIdentity;
    /**
    * azure_service_principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#azure_service_principal StorageCredential#azure_service_principal}
    */
    readonly azureServicePrincipal?: StorageCredentialAzureServicePrincipal;
    /**
    * cloudflare_api_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#cloudflare_api_token StorageCredential#cloudflare_api_token}
    */
    readonly cloudflareApiToken?: StorageCredentialCloudflareApiToken;
    /**
    * databricks_gcp_service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#databricks_gcp_service_account StorageCredential#databricks_gcp_service_account}
    */
    readonly databricksGcpServiceAccount?: StorageCredentialDatabricksGcpServiceAccount;
    /**
    * gcp_service_account_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#gcp_service_account_key StorageCredential#gcp_service_account_key}
    */
    readonly gcpServiceAccountKey?: StorageCredentialGcpServiceAccountKey;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#provider_config StorageCredential#provider_config}
    */
    readonly providerConfig?: StorageCredentialProviderConfig;
}
export interface StorageCredentialAwsIamRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#external_id StorageCredential#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#role_arn StorageCredential#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#unity_catalog_iam_arn StorageCredential#unity_catalog_iam_arn}
    */
    readonly unityCatalogIamArn?: string;
}
export declare function storageCredentialAwsIamRoleToTerraform(struct?: StorageCredentialAwsIamRoleOutputReference | StorageCredentialAwsIamRole): any;
export declare function storageCredentialAwsIamRoleToHclTerraform(struct?: StorageCredentialAwsIamRoleOutputReference | StorageCredentialAwsIamRole): any;
export declare class StorageCredentialAwsIamRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageCredentialAwsIamRole | undefined;
    set internalValue(value: StorageCredentialAwsIamRole | undefined);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _unityCatalogIamArn?;
    get unityCatalogIamArn(): string;
    set unityCatalogIamArn(value: string);
    resetUnityCatalogIamArn(): void;
    get unityCatalogIamArnInput(): string | undefined;
}
export interface StorageCredentialAzureManagedIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#access_connector_id StorageCredential#access_connector_id}
    */
    readonly accessConnectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#credential_id StorageCredential#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#managed_identity_id StorageCredential#managed_identity_id}
    */
    readonly managedIdentityId?: string;
}
export declare function storageCredentialAzureManagedIdentityToTerraform(struct?: StorageCredentialAzureManagedIdentityOutputReference | StorageCredentialAzureManagedIdentity): any;
export declare function storageCredentialAzureManagedIdentityToHclTerraform(struct?: StorageCredentialAzureManagedIdentityOutputReference | StorageCredentialAzureManagedIdentity): any;
export declare class StorageCredentialAzureManagedIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageCredentialAzureManagedIdentity | undefined;
    set internalValue(value: StorageCredentialAzureManagedIdentity | undefined);
    private _accessConnectorId?;
    get accessConnectorId(): string;
    set accessConnectorId(value: string);
    get accessConnectorIdInput(): string | undefined;
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _managedIdentityId?;
    get managedIdentityId(): string;
    set managedIdentityId(value: string);
    resetManagedIdentityId(): void;
    get managedIdentityIdInput(): string | undefined;
}
export interface StorageCredentialAzureServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#application_id StorageCredential#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#client_secret StorageCredential#client_secret}
    */
    readonly clientSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#directory_id StorageCredential#directory_id}
    */
    readonly directoryId: string;
}
export declare function storageCredentialAzureServicePrincipalToTerraform(struct?: StorageCredentialAzureServicePrincipalOutputReference | StorageCredentialAzureServicePrincipal): any;
export declare function storageCredentialAzureServicePrincipalToHclTerraform(struct?: StorageCredentialAzureServicePrincipalOutputReference | StorageCredentialAzureServicePrincipal): any;
export declare class StorageCredentialAzureServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageCredentialAzureServicePrincipal | undefined;
    set internalValue(value: StorageCredentialAzureServicePrincipal | undefined);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
}
export interface StorageCredentialCloudflareApiToken {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#access_key_id StorageCredential#access_key_id}
    */
    readonly accessKeyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#account_id StorageCredential#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#secret_access_key StorageCredential#secret_access_key}
    */
    readonly secretAccessKey: string;
}
export declare function storageCredentialCloudflareApiTokenToTerraform(struct?: StorageCredentialCloudflareApiTokenOutputReference | StorageCredentialCloudflareApiToken): any;
export declare function storageCredentialCloudflareApiTokenToHclTerraform(struct?: StorageCredentialCloudflareApiTokenOutputReference | StorageCredentialCloudflareApiToken): any;
export declare class StorageCredentialCloudflareApiTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageCredentialCloudflareApiToken | undefined;
    set internalValue(value: StorageCredentialCloudflareApiToken | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    get accessKeyIdInput(): string | undefined;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    get secretAccessKeyInput(): string | undefined;
}
export interface StorageCredentialDatabricksGcpServiceAccount {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#credential_id StorageCredential#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#email StorageCredential#email}
    */
    readonly email?: string;
}
export declare function storageCredentialDatabricksGcpServiceAccountToTerraform(struct?: StorageCredentialDatabricksGcpServiceAccountOutputReference | StorageCredentialDatabricksGcpServiceAccount): any;
export declare function storageCredentialDatabricksGcpServiceAccountToHclTerraform(struct?: StorageCredentialDatabricksGcpServiceAccountOutputReference | StorageCredentialDatabricksGcpServiceAccount): any;
export declare class StorageCredentialDatabricksGcpServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageCredentialDatabricksGcpServiceAccount | undefined;
    set internalValue(value: StorageCredentialDatabricksGcpServiceAccount | undefined);
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface StorageCredentialGcpServiceAccountKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#email StorageCredential#email}
    */
    readonly email: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#private_key StorageCredential#private_key}
    */
    readonly privateKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#private_key_id StorageCredential#private_key_id}
    */
    readonly privateKeyId: string;
}
export declare function storageCredentialGcpServiceAccountKeyToTerraform(struct?: StorageCredentialGcpServiceAccountKeyOutputReference | StorageCredentialGcpServiceAccountKey): any;
export declare function storageCredentialGcpServiceAccountKeyToHclTerraform(struct?: StorageCredentialGcpServiceAccountKeyOutputReference | StorageCredentialGcpServiceAccountKey): any;
export declare class StorageCredentialGcpServiceAccountKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageCredentialGcpServiceAccountKey | undefined;
    set internalValue(value: StorageCredentialGcpServiceAccountKey | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _privateKeyId?;
    get privateKeyId(): string;
    set privateKeyId(value: string);
    get privateKeyIdInput(): string | undefined;
}
export interface StorageCredentialProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#workspace_id StorageCredential#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function storageCredentialProviderConfigToTerraform(struct?: StorageCredentialProviderConfigOutputReference | StorageCredentialProviderConfig): any;
export declare function storageCredentialProviderConfigToHclTerraform(struct?: StorageCredentialProviderConfigOutputReference | StorageCredentialProviderConfig): any;
export declare class StorageCredentialProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): StorageCredentialProviderConfig | undefined;
    set internalValue(value: StorageCredentialProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential databricks_storage_credential}
*/
export declare class StorageCredential extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_storage_credential";
    /**
    * Generates CDKTN code for importing a StorageCredential resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StorageCredential to import
    * @param importFromId The id of the existing StorageCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StorageCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/storage_credential databricks_storage_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StorageCredentialConfig
    */
    constructor(scope: Construct, id: string, config: StorageCredentialConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _skipValidation?;
    get skipValidation(): boolean | cdktn.IResolvable;
    set skipValidation(value: boolean | cdktn.IResolvable);
    resetSkipValidation(): void;
    get skipValidationInput(): boolean | cdktn.IResolvable | undefined;
    get storageCredentialId(): string;
    private _awsIamRole;
    get awsIamRole(): StorageCredentialAwsIamRoleOutputReference;
    putAwsIamRole(value: StorageCredentialAwsIamRole): void;
    resetAwsIamRole(): void;
    get awsIamRoleInput(): StorageCredentialAwsIamRole | undefined;
    private _azureManagedIdentity;
    get azureManagedIdentity(): StorageCredentialAzureManagedIdentityOutputReference;
    putAzureManagedIdentity(value: StorageCredentialAzureManagedIdentity): void;
    resetAzureManagedIdentity(): void;
    get azureManagedIdentityInput(): StorageCredentialAzureManagedIdentity | undefined;
    private _azureServicePrincipal;
    get azureServicePrincipal(): StorageCredentialAzureServicePrincipalOutputReference;
    putAzureServicePrincipal(value: StorageCredentialAzureServicePrincipal): void;
    resetAzureServicePrincipal(): void;
    get azureServicePrincipalInput(): StorageCredentialAzureServicePrincipal | undefined;
    private _cloudflareApiToken;
    get cloudflareApiToken(): StorageCredentialCloudflareApiTokenOutputReference;
    putCloudflareApiToken(value: StorageCredentialCloudflareApiToken): void;
    resetCloudflareApiToken(): void;
    get cloudflareApiTokenInput(): StorageCredentialCloudflareApiToken | undefined;
    private _databricksGcpServiceAccount;
    get databricksGcpServiceAccount(): StorageCredentialDatabricksGcpServiceAccountOutputReference;
    putDatabricksGcpServiceAccount(value: StorageCredentialDatabricksGcpServiceAccount): void;
    resetDatabricksGcpServiceAccount(): void;
    get databricksGcpServiceAccountInput(): StorageCredentialDatabricksGcpServiceAccount | undefined;
    private _gcpServiceAccountKey;
    get gcpServiceAccountKey(): StorageCredentialGcpServiceAccountKeyOutputReference;
    putGcpServiceAccountKey(value: StorageCredentialGcpServiceAccountKey): void;
    resetGcpServiceAccountKey(): void;
    get gcpServiceAccountKeyInput(): StorageCredentialGcpServiceAccountKey | undefined;
    private _providerConfig;
    get providerConfig(): StorageCredentialProviderConfigOutputReference;
    putProviderConfig(value: StorageCredentialProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): StorageCredentialProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
