/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresSnapshotScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#name DataDatabricksPostgresSnapshotSchedule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#provider_config DataDatabricksPostgresSnapshotSchedule#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresSnapshotScheduleProviderConfig;
}
export interface DataDatabricksPostgresSnapshotScheduleProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#workspace_id DataDatabricksPostgresSnapshotSchedule#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresSnapshotScheduleProviderConfigToTerraform(struct?: DataDatabricksPostgresSnapshotScheduleProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSnapshotScheduleProviderConfigToHclTerraform(struct?: DataDatabricksPostgresSnapshotScheduleProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSnapshotScheduleProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSnapshotScheduleProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSnapshotScheduleProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#hour DataDatabricksPostgresSnapshotSchedule#hour}
    */
    readonly hour?: number;
}
export declare function dataDatabricksPostgresSnapshotScheduleScheduleDailyScheduleToTerraform(struct?: DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSnapshotScheduleScheduleDailyScheduleToHclTerraform(struct?: DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSnapshotScheduleScheduleDailyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule | cdktn.IResolvable | undefined);
    private _hour?;
    get hour(): number;
    set hour(value: number);
    resetHour(): void;
    get hourInput(): number | undefined;
}
export interface DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#day DataDatabricksPostgresSnapshotSchedule#day}
    */
    readonly day: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#hour DataDatabricksPostgresSnapshotSchedule#hour}
    */
    readonly hour?: number;
}
export declare function dataDatabricksPostgresSnapshotScheduleScheduleMonthlyScheduleToTerraform(struct?: DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSnapshotScheduleScheduleMonthlyScheduleToHclTerraform(struct?: DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSnapshotScheduleScheduleMonthlyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule | cdktn.IResolvable | undefined);
    private _day?;
    get day(): number;
    set day(value: number);
    get dayInput(): number | undefined;
    private _hour?;
    get hour(): number;
    set hour(value: number);
    resetHour(): void;
    get hourInput(): number | undefined;
}
export interface DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#day_of_week DataDatabricksPostgresSnapshotSchedule#day_of_week}
    */
    readonly dayOfWeek: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#hour DataDatabricksPostgresSnapshotSchedule#hour}
    */
    readonly hour?: number;
}
export declare function dataDatabricksPostgresSnapshotScheduleScheduleWeeklyScheduleToTerraform(struct?: DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSnapshotScheduleScheduleWeeklyScheduleToHclTerraform(struct?: DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSnapshotScheduleScheduleWeeklyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    get dayOfWeekInput(): string | undefined;
    private _hour?;
    get hour(): number;
    set hour(value: number);
    resetHour(): void;
    get hourInput(): number | undefined;
}
export interface DataDatabricksPostgresSnapshotScheduleSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#daily_schedule DataDatabricksPostgresSnapshotSchedule#daily_schedule}
    */
    readonly dailySchedule?: DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#monthly_schedule DataDatabricksPostgresSnapshotSchedule#monthly_schedule}
    */
    readonly monthlySchedule?: DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#retention DataDatabricksPostgresSnapshotSchedule#retention}
    */
    readonly retention: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#weekly_schedule DataDatabricksPostgresSnapshotSchedule#weekly_schedule}
    */
    readonly weeklySchedule?: DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule;
}
export declare function dataDatabricksPostgresSnapshotScheduleScheduleToTerraform(struct?: DataDatabricksPostgresSnapshotScheduleSchedule): any;
export declare function dataDatabricksPostgresSnapshotScheduleScheduleToHclTerraform(struct?: DataDatabricksPostgresSnapshotScheduleSchedule): any;
export declare class DataDatabricksPostgresSnapshotScheduleScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresSnapshotScheduleSchedule | undefined;
    set internalValue(value: DataDatabricksPostgresSnapshotScheduleSchedule | undefined);
    private _dailySchedule;
    get dailySchedule(): DataDatabricksPostgresSnapshotScheduleScheduleDailyScheduleOutputReference;
    putDailySchedule(value: DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule): void;
    resetDailySchedule(): void;
    get dailyScheduleInput(): cdktn.IResolvable | DataDatabricksPostgresSnapshotScheduleScheduleDailySchedule | undefined;
    private _monthlySchedule;
    get monthlySchedule(): DataDatabricksPostgresSnapshotScheduleScheduleMonthlyScheduleOutputReference;
    putMonthlySchedule(value: DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule): void;
    resetMonthlySchedule(): void;
    get monthlyScheduleInput(): cdktn.IResolvable | DataDatabricksPostgresSnapshotScheduleScheduleMonthlySchedule | undefined;
    private _retention?;
    get retention(): string;
    set retention(value: string);
    get retentionInput(): string | undefined;
    private _weeklySchedule;
    get weeklySchedule(): DataDatabricksPostgresSnapshotScheduleScheduleWeeklyScheduleOutputReference;
    putWeeklySchedule(value: DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule): void;
    resetWeeklySchedule(): void;
    get weeklyScheduleInput(): cdktn.IResolvable | DataDatabricksPostgresSnapshotScheduleScheduleWeeklySchedule | undefined;
}
export declare class DataDatabricksPostgresSnapshotScheduleScheduleList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresSnapshotScheduleSchedule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresSnapshotScheduleScheduleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule databricks_postgres_snapshot_schedule}
*/
export declare class DataDatabricksPostgresSnapshotSchedule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_snapshot_schedule";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresSnapshotSchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresSnapshotSchedule to import
    * @param importFromId The id of the existing DataDatabricksPostgresSnapshotSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresSnapshotSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_snapshot_schedule databricks_postgres_snapshot_schedule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresSnapshotScheduleConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresSnapshotScheduleConfig);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresSnapshotScheduleProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresSnapshotScheduleProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresSnapshotScheduleProviderConfig | undefined;
    private _schedule;
    get schedule(): DataDatabricksPostgresSnapshotScheduleScheduleList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
