/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EnhancedSecurityMonitoringWorkspaceSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#etag EnhancedSecurityMonitoringWorkspaceSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#id EnhancedSecurityMonitoringWorkspaceSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#setting_name EnhancedSecurityMonitoringWorkspaceSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * enhanced_security_monitoring_workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#enhanced_security_monitoring_workspace EnhancedSecurityMonitoringWorkspaceSetting#enhanced_security_monitoring_workspace}
    */
    readonly enhancedSecurityMonitoringWorkspace: EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#provider_config EnhancedSecurityMonitoringWorkspaceSetting#provider_config}
    */
    readonly providerConfig?: EnhancedSecurityMonitoringWorkspaceSettingProviderConfig;
}
export interface EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#is_enabled EnhancedSecurityMonitoringWorkspaceSetting#is_enabled}
    */
    readonly isEnabled: boolean | cdktn.IResolvable;
}
export declare function enhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspaceToTerraform(struct?: EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspaceOutputReference | EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace): any;
export declare function enhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspaceToHclTerraform(struct?: EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspaceOutputReference | EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace): any;
export declare class EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace | undefined;
    set internalValue(value: EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace | undefined);
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface EnhancedSecurityMonitoringWorkspaceSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#workspace_id EnhancedSecurityMonitoringWorkspaceSetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function enhancedSecurityMonitoringWorkspaceSettingProviderConfigToTerraform(struct?: EnhancedSecurityMonitoringWorkspaceSettingProviderConfigOutputReference | EnhancedSecurityMonitoringWorkspaceSettingProviderConfig): any;
export declare function enhancedSecurityMonitoringWorkspaceSettingProviderConfigToHclTerraform(struct?: EnhancedSecurityMonitoringWorkspaceSettingProviderConfigOutputReference | EnhancedSecurityMonitoringWorkspaceSettingProviderConfig): any;
export declare class EnhancedSecurityMonitoringWorkspaceSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnhancedSecurityMonitoringWorkspaceSettingProviderConfig | undefined;
    set internalValue(value: EnhancedSecurityMonitoringWorkspaceSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting databricks_enhanced_security_monitoring_workspace_setting}
*/
export declare class EnhancedSecurityMonitoringWorkspaceSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_enhanced_security_monitoring_workspace_setting";
    /**
    * Generates CDKTN code for importing a EnhancedSecurityMonitoringWorkspaceSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EnhancedSecurityMonitoringWorkspaceSetting to import
    * @param importFromId The id of the existing EnhancedSecurityMonitoringWorkspaceSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EnhancedSecurityMonitoringWorkspaceSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/enhanced_security_monitoring_workspace_setting databricks_enhanced_security_monitoring_workspace_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EnhancedSecurityMonitoringWorkspaceSettingConfig
    */
    constructor(scope: Construct, id: string, config: EnhancedSecurityMonitoringWorkspaceSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _enhancedSecurityMonitoringWorkspace;
    get enhancedSecurityMonitoringWorkspace(): EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspaceOutputReference;
    putEnhancedSecurityMonitoringWorkspace(value: EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace): void;
    get enhancedSecurityMonitoringWorkspaceInput(): EnhancedSecurityMonitoringWorkspaceSettingEnhancedSecurityMonitoringWorkspace | undefined;
    private _providerConfig;
    get providerConfig(): EnhancedSecurityMonitoringWorkspaceSettingProviderConfigOutputReference;
    putProviderConfig(value: EnhancedSecurityMonitoringWorkspaceSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): EnhancedSecurityMonitoringWorkspaceSettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
