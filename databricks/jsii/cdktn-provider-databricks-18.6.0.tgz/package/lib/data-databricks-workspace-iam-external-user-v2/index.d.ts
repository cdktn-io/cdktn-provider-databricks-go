/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamExternalUserV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_user_v2#name DataDatabricksWorkspaceIamExternalUserV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_user_v2#provider_config DataDatabricksWorkspaceIamExternalUserV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamExternalUserV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamExternalUserV2FullName {
}
export declare function dataDatabricksWorkspaceIamExternalUserV2FullNameToTerraform(struct?: DataDatabricksWorkspaceIamExternalUserV2FullName): any;
export declare function dataDatabricksWorkspaceIamExternalUserV2FullNameToHclTerraform(struct?: DataDatabricksWorkspaceIamExternalUserV2FullName): any;
export declare class DataDatabricksWorkspaceIamExternalUserV2FullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamExternalUserV2FullName | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamExternalUserV2FullName | undefined);
    get familyName(): string;
    get givenName(): string;
}
export interface DataDatabricksWorkspaceIamExternalUserV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_user_v2#workspace_id DataDatabricksWorkspaceIamExternalUserV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamExternalUserV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamExternalUserV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamExternalUserV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamExternalUserV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamExternalUserV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamExternalUserV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamExternalUserV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_user_v2 databricks_workspace_iam_external_user_v2}
*/
export declare class DataDatabricksWorkspaceIamExternalUserV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_external_user_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamExternalUserV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamExternalUserV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamExternalUserV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_user_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamExternalUserV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_user_v2 databricks_workspace_iam_external_user_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamExternalUserV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamExternalUserV2Config);
    get accountId(): string;
    get accountUserStatus(): string;
    get displayName(): string;
    get externalUserId(): string;
    private _fullName;
    get fullName(): DataDatabricksWorkspaceIamExternalUserV2FullNameOutputReference;
    get internalId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamExternalUserV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamExternalUserV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamExternalUserV2ProviderConfig | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
