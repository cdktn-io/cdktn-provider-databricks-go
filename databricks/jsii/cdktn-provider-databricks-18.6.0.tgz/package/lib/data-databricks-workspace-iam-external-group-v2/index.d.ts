/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamExternalGroupV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_group_v2#name DataDatabricksWorkspaceIamExternalGroupV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_group_v2#provider_config DataDatabricksWorkspaceIamExternalGroupV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_group_v2#workspace_id DataDatabricksWorkspaceIamExternalGroupV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamExternalGroupV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamExternalGroupV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamExternalGroupV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_group_v2 databricks_workspace_iam_external_group_v2}
*/
export declare class DataDatabricksWorkspaceIamExternalGroupV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_external_group_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamExternalGroupV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamExternalGroupV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamExternalGroupV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_group_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamExternalGroupV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_external_group_v2 databricks_workspace_iam_external_group_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamExternalGroupV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamExternalGroupV2Config);
    get accountId(): string;
    get displayName(): string;
    get externalGroupId(): string;
    get internalId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamExternalGroupV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamExternalGroupV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
