/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupInstanceProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile#api GroupInstanceProfile#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile#group_id GroupInstanceProfile#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile#id GroupInstanceProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile#instance_profile_id GroupInstanceProfile#instance_profile_id}
    */
    readonly instanceProfileId: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile#provider_config GroupInstanceProfile#provider_config}
    */
    readonly providerConfig?: GroupInstanceProfileProviderConfig;
}
export interface GroupInstanceProfileProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile#workspace_id GroupInstanceProfile#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function groupInstanceProfileProviderConfigToTerraform(struct?: GroupInstanceProfileProviderConfigOutputReference | GroupInstanceProfileProviderConfig): any;
export declare function groupInstanceProfileProviderConfigToHclTerraform(struct?: GroupInstanceProfileProviderConfigOutputReference | GroupInstanceProfileProviderConfig): any;
export declare class GroupInstanceProfileProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupInstanceProfileProviderConfig | undefined;
    set internalValue(value: GroupInstanceProfileProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile databricks_group_instance_profile}
*/
export declare class GroupInstanceProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_group_instance_profile";
    /**
    * Generates CDKTN code for importing a GroupInstanceProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupInstanceProfile to import
    * @param importFromId The id of the existing GroupInstanceProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupInstanceProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/group_instance_profile databricks_group_instance_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupInstanceProfileConfig
    */
    constructor(scope: Construct, id: string, config: GroupInstanceProfileConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfileId?;
    get instanceProfileId(): string;
    set instanceProfileId(value: string);
    get instanceProfileIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): GroupInstanceProfileProviderConfigOutputReference;
    putProviderConfig(value: GroupInstanceProfileProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): GroupInstanceProfileProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
