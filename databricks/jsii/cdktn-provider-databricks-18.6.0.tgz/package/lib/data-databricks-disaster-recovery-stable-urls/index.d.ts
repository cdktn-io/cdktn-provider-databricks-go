/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDisasterRecoveryStableUrlsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/disaster_recovery_stable_urls#page_size DataDatabricksDisasterRecoveryStableUrls#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/disaster_recovery_stable_urls#parent DataDatabricksDisasterRecoveryStableUrls#parent}
    */
    readonly parent: string;
}
export interface DataDatabricksDisasterRecoveryStableUrlsStableUrls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/disaster_recovery_stable_urls#name DataDatabricksDisasterRecoveryStableUrls#name}
    */
    readonly name: string;
}
export declare function dataDatabricksDisasterRecoveryStableUrlsStableUrlsToTerraform(struct?: DataDatabricksDisasterRecoveryStableUrlsStableUrls): any;
export declare function dataDatabricksDisasterRecoveryStableUrlsStableUrlsToHclTerraform(struct?: DataDatabricksDisasterRecoveryStableUrlsStableUrls): any;
export declare class DataDatabricksDisasterRecoveryStableUrlsStableUrlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDisasterRecoveryStableUrlsStableUrls | undefined;
    set internalValue(value: DataDatabricksDisasterRecoveryStableUrlsStableUrls | undefined);
    get effectiveWorkspaceId(): string;
    get failoverGroupName(): string;
    get initialWorkspaceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get stableWorkspaceId(): string;
    get url(): string;
}
export declare class DataDatabricksDisasterRecoveryStableUrlsStableUrlsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDisasterRecoveryStableUrlsStableUrls[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDisasterRecoveryStableUrlsStableUrlsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/disaster_recovery_stable_urls databricks_disaster_recovery_stable_urls}
*/
export declare class DataDatabricksDisasterRecoveryStableUrls extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_disaster_recovery_stable_urls";
    /**
    * Generates CDKTN code for importing a DataDatabricksDisasterRecoveryStableUrls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDisasterRecoveryStableUrls to import
    * @param importFromId The id of the existing DataDatabricksDisasterRecoveryStableUrls that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/disaster_recovery_stable_urls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDisasterRecoveryStableUrls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/disaster_recovery_stable_urls databricks_disaster_recovery_stable_urls} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDisasterRecoveryStableUrlsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDisasterRecoveryStableUrlsConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _stableUrls;
    get stableUrls(): DataDatabricksDisasterRecoveryStableUrlsStableUrlsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
