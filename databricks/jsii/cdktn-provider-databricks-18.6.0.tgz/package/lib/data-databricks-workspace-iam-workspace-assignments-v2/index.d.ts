/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamWorkspaceAssignmentsV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2#page_size DataDatabricksWorkspaceIamWorkspaceAssignmentsV2#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2#provider_config DataDatabricksWorkspaceIamWorkspaceAssignmentsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2#workspace_id DataDatabricksWorkspaceIamWorkspaceAssignmentsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2#workspace_id DataDatabricksWorkspaceIamWorkspaceAssignmentsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2#principal_id DataDatabricksWorkspaceIamWorkspaceAssignmentsV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2#provider_config DataDatabricksWorkspaceIamWorkspaceAssignmentsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig;
}
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsToTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignments): any;
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsToHclTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignments): any;
export declare class DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignments | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignments | undefined);
    get accountId(): string;
    get effectiveEntitlements(): string[];
    get entitlements(): string[];
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsProviderConfig | undefined;
    get workspaceId(): number;
}
export declare class DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2 databricks_workspace_iam_workspace_assignments_v2}
*/
export declare class DataDatabricksWorkspaceIamWorkspaceAssignmentsV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_workspace_assignments_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamWorkspaceAssignmentsV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamWorkspaceAssignmentsV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamWorkspaceAssignmentsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamWorkspaceAssignmentsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_workspace_assignments_v2 databricks_workspace_iam_workspace_assignments_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamWorkspaceAssignmentsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2Config);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamWorkspaceAssignmentsV2ProviderConfig | undefined;
    private _workspaceAssignments;
    get workspaceAssignments(): DataDatabricksWorkspaceIamWorkspaceAssignmentsV2WorkspaceAssignmentsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
