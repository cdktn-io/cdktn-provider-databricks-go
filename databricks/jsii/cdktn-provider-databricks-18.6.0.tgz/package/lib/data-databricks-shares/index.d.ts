/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSharesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/shares#provider_config DataDatabricksShares#provider_config}
    */
    readonly providerConfig?: DataDatabricksSharesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/shares#shares DataDatabricksShares#shares}
    */
    readonly shares?: string[];
}
export interface DataDatabricksSharesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/shares#workspace_id DataDatabricksShares#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSharesProviderConfigToTerraform(struct?: DataDatabricksSharesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSharesProviderConfigToHclTerraform(struct?: DataDatabricksSharesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSharesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSharesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSharesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/shares databricks_shares}
*/
export declare class DataDatabricksShares extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_shares";
    /**
    * Generates CDKTN code for importing a DataDatabricksShares resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksShares to import
    * @param importFromId The id of the existing DataDatabricksShares that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/shares#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksShares to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/shares databricks_shares} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSharesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksSharesConfig);
    private _providerConfig;
    get providerConfig(): DataDatabricksSharesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSharesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSharesProviderConfig | undefined;
    private _shares?;
    get shares(): string[];
    set shares(value: string[]);
    resetShares(): void;
    get sharesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
