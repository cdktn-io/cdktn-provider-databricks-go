/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDatabaseInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#name DataDatabricksDatabaseInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#provider_config DataDatabricksDatabaseInstance#provider_config}
    */
    readonly providerConfig?: DataDatabricksDatabaseInstanceProviderConfig;
}
export interface DataDatabricksDatabaseInstanceChildInstanceRefs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#branch_time DataDatabricksDatabaseInstance#branch_time}
    */
    readonly branchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#lsn DataDatabricksDatabaseInstance#lsn}
    */
    readonly lsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#name DataDatabricksDatabaseInstance#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksDatabaseInstanceChildInstanceRefsToTerraform(struct?: DataDatabricksDatabaseInstanceChildInstanceRefs): any;
export declare function dataDatabricksDatabaseInstanceChildInstanceRefsToHclTerraform(struct?: DataDatabricksDatabaseInstanceChildInstanceRefs): any;
export declare class DataDatabricksDatabaseInstanceChildInstanceRefsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseInstanceChildInstanceRefs | undefined;
    set internalValue(value: DataDatabricksDatabaseInstanceChildInstanceRefs | undefined);
    private _branchTime?;
    get branchTime(): string;
    set branchTime(value: string);
    resetBranchTime(): void;
    get branchTimeInput(): string | undefined;
    get effectiveLsn(): string;
    private _lsn?;
    get lsn(): string;
    set lsn(value: string);
    resetLsn(): void;
    get lsnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get uid(): string;
}
export declare class DataDatabricksDatabaseInstanceChildInstanceRefsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseInstanceChildInstanceRefs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseInstanceChildInstanceRefsOutputReference;
}
export interface DataDatabricksDatabaseInstanceCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#key DataDatabricksDatabaseInstance#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#value DataDatabricksDatabaseInstance#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksDatabaseInstanceCustomTagsToTerraform(struct?: DataDatabricksDatabaseInstanceCustomTags): any;
export declare function dataDatabricksDatabaseInstanceCustomTagsToHclTerraform(struct?: DataDatabricksDatabaseInstanceCustomTags): any;
export declare class DataDatabricksDatabaseInstanceCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseInstanceCustomTags | undefined;
    set internalValue(value: DataDatabricksDatabaseInstanceCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksDatabaseInstanceCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseInstanceCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseInstanceCustomTagsOutputReference;
}
export interface DataDatabricksDatabaseInstanceEffectiveCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#key DataDatabricksDatabaseInstance#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#value DataDatabricksDatabaseInstance#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksDatabaseInstanceEffectiveCustomTagsToTerraform(struct?: DataDatabricksDatabaseInstanceEffectiveCustomTags): any;
export declare function dataDatabricksDatabaseInstanceEffectiveCustomTagsToHclTerraform(struct?: DataDatabricksDatabaseInstanceEffectiveCustomTags): any;
export declare class DataDatabricksDatabaseInstanceEffectiveCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseInstanceEffectiveCustomTags | undefined;
    set internalValue(value: DataDatabricksDatabaseInstanceEffectiveCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksDatabaseInstanceEffectiveCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseInstanceEffectiveCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseInstanceEffectiveCustomTagsOutputReference;
}
export interface DataDatabricksDatabaseInstanceParentInstanceRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#branch_time DataDatabricksDatabaseInstance#branch_time}
    */
    readonly branchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#lsn DataDatabricksDatabaseInstance#lsn}
    */
    readonly lsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#name DataDatabricksDatabaseInstance#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksDatabaseInstanceParentInstanceRefToTerraform(struct?: DataDatabricksDatabaseInstanceParentInstanceRef): any;
export declare function dataDatabricksDatabaseInstanceParentInstanceRefToHclTerraform(struct?: DataDatabricksDatabaseInstanceParentInstanceRef): any;
export declare class DataDatabricksDatabaseInstanceParentInstanceRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseInstanceParentInstanceRef | undefined;
    set internalValue(value: DataDatabricksDatabaseInstanceParentInstanceRef | undefined);
    private _branchTime?;
    get branchTime(): string;
    set branchTime(value: string);
    resetBranchTime(): void;
    get branchTimeInput(): string | undefined;
    get effectiveLsn(): string;
    private _lsn?;
    get lsn(): string;
    set lsn(value: string);
    resetLsn(): void;
    get lsnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get uid(): string;
}
export interface DataDatabricksDatabaseInstanceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#workspace_id DataDatabricksDatabaseInstance#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDatabaseInstanceProviderConfigToTerraform(struct?: DataDatabricksDatabaseInstanceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseInstanceProviderConfigToHclTerraform(struct?: DataDatabricksDatabaseInstanceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseInstanceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseInstanceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseInstanceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance databricks_database_instance}
*/
export declare class DataDatabricksDatabaseInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_database_instance";
    /**
    * Generates CDKTN code for importing a DataDatabricksDatabaseInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDatabaseInstance to import
    * @param importFromId The id of the existing DataDatabricksDatabaseInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDatabaseInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/database_instance databricks_database_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDatabaseInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDatabaseInstanceConfig);
    get capacity(): string;
    private _childInstanceRefs;
    get childInstanceRefs(): DataDatabricksDatabaseInstanceChildInstanceRefsList;
    get creationTime(): string;
    get creator(): string;
    private _customTags;
    get customTags(): DataDatabricksDatabaseInstanceCustomTagsList;
    get effectiveCapacity(): string;
    private _effectiveCustomTags;
    get effectiveCustomTags(): DataDatabricksDatabaseInstanceEffectiveCustomTagsList;
    get effectiveEnablePgNativeLogin(): cdktn.IResolvable;
    get effectiveEnableReadableSecondaries(): cdktn.IResolvable;
    get effectiveNodeCount(): number;
    get effectiveRetentionWindowInDays(): number;
    get effectiveStopped(): cdktn.IResolvable;
    get effectiveUsagePolicyId(): string;
    get enablePgNativeLogin(): cdktn.IResolvable;
    get enableReadableSecondaries(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeCount(): number;
    private _parentInstanceRef;
    get parentInstanceRef(): DataDatabricksDatabaseInstanceParentInstanceRefOutputReference;
    get pgVersion(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksDatabaseInstanceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDatabaseInstanceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDatabaseInstanceProviderConfig | undefined;
    get readOnlyDns(): string;
    get readWriteDns(): string;
    get retentionWindowInDays(): number;
    get state(): string;
    get stopped(): cdktn.IResolvable;
    get uid(): string;
    get usagePolicyId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
