/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamUserV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2#provider_config DataDatabricksWorkspaceIamUserV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamUserV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2#user_id DataDatabricksWorkspaceIamUserV2#user_id}
    */
    readonly userId: string;
}
export interface DataDatabricksWorkspaceIamUserV2FullName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2#family_name DataDatabricksWorkspaceIamUserV2#family_name}
    */
    readonly familyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2#given_name DataDatabricksWorkspaceIamUserV2#given_name}
    */
    readonly givenName?: string;
}
export declare function dataDatabricksWorkspaceIamUserV2FullNameToTerraform(struct?: DataDatabricksWorkspaceIamUserV2FullName): any;
export declare function dataDatabricksWorkspaceIamUserV2FullNameToHclTerraform(struct?: DataDatabricksWorkspaceIamUserV2FullName): any;
export declare class DataDatabricksWorkspaceIamUserV2FullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamUserV2FullName | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamUserV2FullName | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    resetFamilyName(): void;
    get familyNameInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamUserV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2#workspace_id DataDatabricksWorkspaceIamUserV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamUserV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamUserV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamUserV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamUserV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamUserV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamUserV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamUserV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2 databricks_workspace_iam_user_v2}
*/
export declare class DataDatabricksWorkspaceIamUserV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_user_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamUserV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamUserV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamUserV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamUserV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/workspace_iam_user_v2 databricks_workspace_iam_user_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamUserV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamUserV2Config);
    get accountId(): string;
    get accountUserStatus(): string;
    get externalId(): string;
    private _fullName;
    get fullName(): DataDatabricksWorkspaceIamUserV2FullNameOutputReference;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamUserV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamUserV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamUserV2ProviderConfig | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
