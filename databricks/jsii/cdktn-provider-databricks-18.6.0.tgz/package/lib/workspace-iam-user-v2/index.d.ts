/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceIamUserV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#account_user_status WorkspaceIamUserV2#account_user_status}
    */
    readonly accountUserStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#external_id WorkspaceIamUserV2#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#full_name WorkspaceIamUserV2#full_name}
    */
    readonly fullName: WorkspaceIamUserV2FullName;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#provider_config WorkspaceIamUserV2#provider_config}
    */
    readonly providerConfig?: WorkspaceIamUserV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#username WorkspaceIamUserV2#username}
    */
    readonly username: string;
}
export interface WorkspaceIamUserV2FullName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#family_name WorkspaceIamUserV2#family_name}
    */
    readonly familyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#given_name WorkspaceIamUserV2#given_name}
    */
    readonly givenName?: string;
}
export declare function workspaceIamUserV2FullNameToTerraform(struct?: WorkspaceIamUserV2FullName | cdktn.IResolvable): any;
export declare function workspaceIamUserV2FullNameToHclTerraform(struct?: WorkspaceIamUserV2FullName | cdktn.IResolvable): any;
export declare class WorkspaceIamUserV2FullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceIamUserV2FullName | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceIamUserV2FullName | cdktn.IResolvable | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    resetFamilyName(): void;
    get familyNameInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
}
export interface WorkspaceIamUserV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#workspace_id WorkspaceIamUserV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceIamUserV2ProviderConfigToTerraform(struct?: WorkspaceIamUserV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceIamUserV2ProviderConfigToHclTerraform(struct?: WorkspaceIamUserV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceIamUserV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceIamUserV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceIamUserV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2 databricks_workspace_iam_user_v2}
*/
export declare class WorkspaceIamUserV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_iam_user_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceIamUserV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceIamUserV2 to import
    * @param importFromId The id of the existing WorkspaceIamUserV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceIamUserV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/workspace_iam_user_v2 databricks_workspace_iam_user_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceIamUserV2Config
    */
    constructor(scope: Construct, id: string, config: WorkspaceIamUserV2Config);
    get accountId(): string;
    private _accountUserStatus?;
    get accountUserStatus(): string;
    set accountUserStatus(value: string);
    get accountUserStatusInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _fullName;
    get fullName(): WorkspaceIamUserV2FullNameOutputReference;
    putFullName(value: WorkspaceIamUserV2FullName): void;
    get fullNameInput(): cdktn.IResolvable | WorkspaceIamUserV2FullName | undefined;
    private _providerConfig;
    get providerConfig(): WorkspaceIamUserV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceIamUserV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceIamUserV2ProviderConfig | undefined;
    get userId(): string;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
