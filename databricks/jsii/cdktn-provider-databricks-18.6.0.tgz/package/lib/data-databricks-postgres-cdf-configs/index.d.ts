/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresCdfConfigsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#page_size DataDatabricksPostgresCdfConfigs#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#parent DataDatabricksPostgresCdfConfigs#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#provider_config DataDatabricksPostgresCdfConfigs#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresCdfConfigsProviderConfig;
}
export interface DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#workspace_id DataDatabricksPostgresCdfConfigs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresCdfConfigsCdfConfigsProviderConfigToTerraform(struct?: DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresCdfConfigsCdfConfigsProviderConfigToHclTerraform(struct?: DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresCdfConfigsCdfConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#name DataDatabricksPostgresCdfConfigs#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#provider_config DataDatabricksPostgresCdfConfigs#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig;
}
export declare function dataDatabricksPostgresCdfConfigsCdfConfigsToTerraform(struct?: DataDatabricksPostgresCdfConfigsCdfConfigs): any;
export declare function dataDatabricksPostgresCdfConfigsCdfConfigsToHclTerraform(struct?: DataDatabricksPostgresCdfConfigsCdfConfigs): any;
export declare class DataDatabricksPostgresCdfConfigsCdfConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresCdfConfigsCdfConfigs | undefined;
    set internalValue(value: DataDatabricksPostgresCdfConfigsCdfConfigs | undefined);
    get catalog(): string;
    get cdfConfigId(): string;
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get postgresSchema(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresCdfConfigsCdfConfigsProviderConfig | undefined;
    get schema(): string;
}
export declare class DataDatabricksPostgresCdfConfigsCdfConfigsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresCdfConfigsCdfConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresCdfConfigsCdfConfigsOutputReference;
}
export interface DataDatabricksPostgresCdfConfigsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#workspace_id DataDatabricksPostgresCdfConfigs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresCdfConfigsProviderConfigToTerraform(struct?: DataDatabricksPostgresCdfConfigsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresCdfConfigsProviderConfigToHclTerraform(struct?: DataDatabricksPostgresCdfConfigsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresCdfConfigsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCdfConfigsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresCdfConfigsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs databricks_postgres_cdf_configs}
*/
export declare class DataDatabricksPostgresCdfConfigs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_cdf_configs";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresCdfConfigs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresCdfConfigs to import
    * @param importFromId The id of the existing DataDatabricksPostgresCdfConfigs that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresCdfConfigs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/data-sources/postgres_cdf_configs databricks_postgres_cdf_configs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresCdfConfigsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresCdfConfigsConfig);
    private _cdfConfigs;
    get cdfConfigs(): DataDatabricksPostgresCdfConfigsCdfConfigsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresCdfConfigsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresCdfConfigsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresCdfConfigsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
