/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SqlTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#catalog_name SqlTable#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#cluster_id SqlTable#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#cluster_keys SqlTable#cluster_keys}
    */
    readonly clusterKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#comment SqlTable#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#data_source_format SqlTable#data_source_format}
    */
    readonly dataSourceFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#id SqlTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#name SqlTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#options SqlTable#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#owner SqlTable#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#partitions SqlTable#partitions}
    */
    readonly partitions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#properties SqlTable#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#schema_name SqlTable#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#storage_credential_name SqlTable#storage_credential_name}
    */
    readonly storageCredentialName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#storage_location SqlTable#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#table_type SqlTable#table_type}
    */
    readonly tableType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#view_definition SqlTable#view_definition}
    */
    readonly viewDefinition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#warehouse_id SqlTable#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#column SqlTable#column}
    */
    readonly column?: SqlTableColumn[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#provider_config SqlTable#provider_config}
    */
    readonly providerConfig?: SqlTableProviderConfig;
}
export interface SqlTableColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#comment SqlTable#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#identity SqlTable#identity}
    */
    readonly identity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#name SqlTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#nullable SqlTable#nullable}
    */
    readonly nullable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#type SqlTable#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#type_json SqlTable#type_json}
    */
    readonly typeJson?: string;
}
export declare function sqlTableColumnToTerraform(struct?: SqlTableColumn | cdktn.IResolvable): any;
export declare function sqlTableColumnToHclTerraform(struct?: SqlTableColumn | cdktn.IResolvable): any;
export declare class SqlTableColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SqlTableColumn | cdktn.IResolvable | undefined;
    set internalValue(value: SqlTableColumn | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nullable?;
    get nullable(): boolean | cdktn.IResolvable;
    set nullable(value: boolean | cdktn.IResolvable);
    resetNullable(): void;
    get nullableInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _typeJson?;
    get typeJson(): string;
    set typeJson(value: string);
    resetTypeJson(): void;
    get typeJsonInput(): string | undefined;
}
export declare class SqlTableColumnList extends cdktn.ComplexList {
    internalValue?: SqlTableColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SqlTableColumnOutputReference;
}
export interface SqlTableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#workspace_id SqlTable#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function sqlTableProviderConfigToTerraform(struct?: SqlTableProviderConfigOutputReference | SqlTableProviderConfig): any;
export declare function sqlTableProviderConfigToHclTerraform(struct?: SqlTableProviderConfigOutputReference | SqlTableProviderConfig): any;
export declare class SqlTableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlTableProviderConfig | undefined;
    set internalValue(value: SqlTableProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table databricks_sql_table}
*/
export declare class SqlTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sql_table";
    /**
    * Generates CDKTN code for importing a SqlTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlTable to import
    * @param importFromId The id of the existing SqlTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_table databricks_sql_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlTableConfig
    */
    constructor(scope: Construct, id: string, config: SqlTableConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterKeys?;
    get clusterKeys(): string[];
    set clusterKeys(value: string[]);
    resetClusterKeys(): void;
    get clusterKeysInput(): string[] | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _dataSourceFormat?;
    get dataSourceFormat(): string;
    set dataSourceFormat(value: string);
    resetDataSourceFormat(): void;
    get dataSourceFormatInput(): string | undefined;
    private _effectiveProperties;
    get effectiveProperties(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _partitions?;
    get partitions(): string[];
    set partitions(value: string[]);
    resetPartitions(): void;
    get partitionsInput(): string[] | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _storageCredentialName?;
    get storageCredentialName(): string;
    set storageCredentialName(value: string);
    resetStorageCredentialName(): void;
    get storageCredentialNameInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    get tableId(): string;
    private _tableType?;
    get tableType(): string;
    set tableType(value: string);
    get tableTypeInput(): string | undefined;
    private _viewDefinition?;
    get viewDefinition(): string;
    set viewDefinition(value: string);
    resetViewDefinition(): void;
    get viewDefinitionInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _column;
    get column(): SqlTableColumnList;
    putColumn(value: SqlTableColumn[] | cdktn.IResolvable): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | SqlTableColumn[] | undefined;
    private _providerConfig;
    get providerConfig(): SqlTableProviderConfigOutputReference;
    putProviderConfig(value: SqlTableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SqlTableProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
