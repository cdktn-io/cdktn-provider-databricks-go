/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SqlGlobalConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#data_access_config SqlGlobalConfig#data_access_config}
    */
    readonly dataAccessConfig?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#enable_serverless_compute SqlGlobalConfig#enable_serverless_compute}
    */
    readonly enableServerlessCompute?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#google_service_account SqlGlobalConfig#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#id SqlGlobalConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#instance_profile_arn SqlGlobalConfig#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#security_policy SqlGlobalConfig#security_policy}
    */
    readonly securityPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#sql_config_params SqlGlobalConfig#sql_config_params}
    */
    readonly sqlConfigParams?: {
        [key: string]: string;
    };
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#provider_config SqlGlobalConfig#provider_config}
    */
    readonly providerConfig?: SqlGlobalConfigProviderConfig;
}
export interface SqlGlobalConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#workspace_id SqlGlobalConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function sqlGlobalConfigProviderConfigToTerraform(struct?: SqlGlobalConfigProviderConfigOutputReference | SqlGlobalConfigProviderConfig): any;
export declare function sqlGlobalConfigProviderConfigToHclTerraform(struct?: SqlGlobalConfigProviderConfigOutputReference | SqlGlobalConfigProviderConfig): any;
export declare class SqlGlobalConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlGlobalConfigProviderConfig | undefined;
    set internalValue(value: SqlGlobalConfigProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config databricks_sql_global_config}
*/
export declare class SqlGlobalConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sql_global_config";
    /**
    * Generates CDKTN code for importing a SqlGlobalConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlGlobalConfig to import
    * @param importFromId The id of the existing SqlGlobalConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlGlobalConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/sql_global_config databricks_sql_global_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlGlobalConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: SqlGlobalConfigConfig);
    private _dataAccessConfig?;
    get dataAccessConfig(): {
        [key: string]: string;
    };
    set dataAccessConfig(value: {
        [key: string]: string;
    });
    resetDataAccessConfig(): void;
    get dataAccessConfigInput(): {
        [key: string]: string;
    } | undefined;
    private _enableServerlessCompute?;
    get enableServerlessCompute(): boolean | cdktn.IResolvable;
    set enableServerlessCompute(value: boolean | cdktn.IResolvable);
    resetEnableServerlessCompute(): void;
    get enableServerlessComputeInput(): boolean | cdktn.IResolvable | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    resetSecurityPolicy(): void;
    get securityPolicyInput(): string | undefined;
    private _sqlConfigParams?;
    get sqlConfigParams(): {
        [key: string]: string;
    };
    set sqlConfigParams(value: {
        [key: string]: string;
    });
    resetSqlConfigParams(): void;
    get sqlConfigParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _providerConfig;
    get providerConfig(): SqlGlobalConfigProviderConfigOutputReference;
    putProviderConfig(value: SqlGlobalConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SqlGlobalConfigProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
