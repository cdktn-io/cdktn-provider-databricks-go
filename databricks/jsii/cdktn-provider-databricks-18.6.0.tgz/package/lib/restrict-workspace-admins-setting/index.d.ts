/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface RestrictWorkspaceAdminsSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#etag RestrictWorkspaceAdminsSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#id RestrictWorkspaceAdminsSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#setting_name RestrictWorkspaceAdminsSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#provider_config RestrictWorkspaceAdminsSetting#provider_config}
    */
    readonly providerConfig?: RestrictWorkspaceAdminsSettingProviderConfig;
    /**
    * restrict_workspace_admins block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#restrict_workspace_admins RestrictWorkspaceAdminsSetting#restrict_workspace_admins}
    */
    readonly restrictWorkspaceAdmins: RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins;
}
export interface RestrictWorkspaceAdminsSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#workspace_id RestrictWorkspaceAdminsSetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function restrictWorkspaceAdminsSettingProviderConfigToTerraform(struct?: RestrictWorkspaceAdminsSettingProviderConfigOutputReference | RestrictWorkspaceAdminsSettingProviderConfig): any;
export declare function restrictWorkspaceAdminsSettingProviderConfigToHclTerraform(struct?: RestrictWorkspaceAdminsSettingProviderConfigOutputReference | RestrictWorkspaceAdminsSettingProviderConfig): any;
export declare class RestrictWorkspaceAdminsSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RestrictWorkspaceAdminsSettingProviderConfig | undefined;
    set internalValue(value: RestrictWorkspaceAdminsSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#disable_gov_tag_creation RestrictWorkspaceAdminsSetting#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#status RestrictWorkspaceAdminsSetting#status}
    */
    readonly status: string;
}
export declare function restrictWorkspaceAdminsSettingRestrictWorkspaceAdminsToTerraform(struct?: RestrictWorkspaceAdminsSettingRestrictWorkspaceAdminsOutputReference | RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins): any;
export declare function restrictWorkspaceAdminsSettingRestrictWorkspaceAdminsToHclTerraform(struct?: RestrictWorkspaceAdminsSettingRestrictWorkspaceAdminsOutputReference | RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins): any;
export declare class RestrictWorkspaceAdminsSettingRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins | undefined;
    set internalValue(value: RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting databricks_restrict_workspace_admins_setting}
*/
export declare class RestrictWorkspaceAdminsSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_restrict_workspace_admins_setting";
    /**
    * Generates CDKTN code for importing a RestrictWorkspaceAdminsSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RestrictWorkspaceAdminsSetting to import
    * @param importFromId The id of the existing RestrictWorkspaceAdminsSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RestrictWorkspaceAdminsSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/restrict_workspace_admins_setting databricks_restrict_workspace_admins_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RestrictWorkspaceAdminsSettingConfig
    */
    constructor(scope: Construct, id: string, config: RestrictWorkspaceAdminsSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): RestrictWorkspaceAdminsSettingProviderConfigOutputReference;
    putProviderConfig(value: RestrictWorkspaceAdminsSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): RestrictWorkspaceAdminsSettingProviderConfig | undefined;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): RestrictWorkspaceAdminsSettingRestrictWorkspaceAdminsOutputReference;
    putRestrictWorkspaceAdmins(value: RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins): void;
    get restrictWorkspaceAdminsInput(): RestrictWorkspaceAdminsSettingRestrictWorkspaceAdmins | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
