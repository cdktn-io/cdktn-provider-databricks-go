/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface KnowledgeAssistantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant#description KnowledgeAssistant#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant#display_name KnowledgeAssistant#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant#instructions KnowledgeAssistant#instructions}
    */
    readonly instructions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant#provider_config KnowledgeAssistant#provider_config}
    */
    readonly providerConfig?: KnowledgeAssistantProviderConfig;
}
export interface KnowledgeAssistantProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant#workspace_id KnowledgeAssistant#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function knowledgeAssistantProviderConfigToTerraform(struct?: KnowledgeAssistantProviderConfig | cdktn.IResolvable): any;
export declare function knowledgeAssistantProviderConfigToHclTerraform(struct?: KnowledgeAssistantProviderConfig | cdktn.IResolvable): any;
export declare class KnowledgeAssistantProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): KnowledgeAssistantProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: KnowledgeAssistantProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant databricks_knowledge_assistant}
*/
export declare class KnowledgeAssistant extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_knowledge_assistant";
    /**
    * Generates CDKTN code for importing a KnowledgeAssistant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KnowledgeAssistant to import
    * @param importFromId The id of the existing KnowledgeAssistant that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KnowledgeAssistant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/knowledge_assistant databricks_knowledge_assistant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KnowledgeAssistantConfig
    */
    constructor(scope: Construct, id: string, config: KnowledgeAssistantConfig);
    get createTime(): string;
    get creator(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get endpointName(): string;
    get errorInfo(): string;
    get experimentId(): string;
    get id(): string;
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    resetInstructions(): void;
    get instructionsInput(): string | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): KnowledgeAssistantProviderConfigOutputReference;
    putProviderConfig(value: KnowledgeAssistantProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | KnowledgeAssistantProviderConfig | undefined;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
