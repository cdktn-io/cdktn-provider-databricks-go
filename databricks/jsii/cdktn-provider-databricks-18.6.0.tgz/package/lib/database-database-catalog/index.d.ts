/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseDatabaseCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog#create_database_if_not_exists DatabaseDatabaseCatalog#create_database_if_not_exists}
    */
    readonly createDatabaseIfNotExists?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog#database_instance_name DatabaseDatabaseCatalog#database_instance_name}
    */
    readonly databaseInstanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog#database_name DatabaseDatabaseCatalog#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog#name DatabaseDatabaseCatalog#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog#provider_config DatabaseDatabaseCatalog#provider_config}
    */
    readonly providerConfig?: DatabaseDatabaseCatalogProviderConfig;
}
export interface DatabaseDatabaseCatalogProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog#workspace_id DatabaseDatabaseCatalog#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function databaseDatabaseCatalogProviderConfigToTerraform(struct?: DatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable): any;
export declare function databaseDatabaseCatalogProviderConfigToHclTerraform(struct?: DatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable): any;
export declare class DatabaseDatabaseCatalogProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseDatabaseCatalogProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog databricks_database_database_catalog}
*/
export declare class DatabaseDatabaseCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_database_database_catalog";
    /**
    * Generates CDKTN code for importing a DatabaseDatabaseCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseDatabaseCatalog to import
    * @param importFromId The id of the existing DatabaseDatabaseCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseDatabaseCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.131.0/docs/resources/database_database_catalog databricks_database_database_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseDatabaseCatalogConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseDatabaseCatalogConfig);
    private _createDatabaseIfNotExists?;
    get createDatabaseIfNotExists(): boolean | cdktn.IResolvable;
    set createDatabaseIfNotExists(value: boolean | cdktn.IResolvable);
    resetCreateDatabaseIfNotExists(): void;
    get createDatabaseIfNotExistsInput(): boolean | cdktn.IResolvable | undefined;
    private _databaseInstanceName?;
    get databaseInstanceName(): string;
    set databaseInstanceName(value: string);
    get databaseInstanceNameInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DatabaseDatabaseCatalogProviderConfigOutputReference;
    putProviderConfig(value: DatabaseDatabaseCatalogProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DatabaseDatabaseCatalogProviderConfig | undefined;
    get uid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
