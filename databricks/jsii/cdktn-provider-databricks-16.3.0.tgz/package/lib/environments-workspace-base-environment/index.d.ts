/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EnvironmentsWorkspaceBaseEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment#base_environment_type EnvironmentsWorkspaceBaseEnvironment#base_environment_type}
    */
    readonly baseEnvironmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment#display_name EnvironmentsWorkspaceBaseEnvironment#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment#filepath EnvironmentsWorkspaceBaseEnvironment#filepath}
    */
    readonly filepath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment#provider_config EnvironmentsWorkspaceBaseEnvironment#provider_config}
    */
    readonly providerConfig?: EnvironmentsWorkspaceBaseEnvironmentProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment#workspace_base_environment_id EnvironmentsWorkspaceBaseEnvironment#workspace_base_environment_id}
    */
    readonly workspaceBaseEnvironmentId?: string;
}
export interface EnvironmentsWorkspaceBaseEnvironmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment#workspace_id EnvironmentsWorkspaceBaseEnvironment#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function environmentsWorkspaceBaseEnvironmentProviderConfigToTerraform(struct?: EnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare function environmentsWorkspaceBaseEnvironmentProviderConfigToHclTerraform(struct?: EnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare class EnvironmentsWorkspaceBaseEnvironmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: EnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment databricks_environments_workspace_base_environment}
*/
export declare class EnvironmentsWorkspaceBaseEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_environments_workspace_base_environment";
    /**
    * Generates CDKTN code for importing a EnvironmentsWorkspaceBaseEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EnvironmentsWorkspaceBaseEnvironment to import
    * @param importFromId The id of the existing EnvironmentsWorkspaceBaseEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EnvironmentsWorkspaceBaseEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/environments_workspace_base_environment databricks_environments_workspace_base_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EnvironmentsWorkspaceBaseEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: EnvironmentsWorkspaceBaseEnvironmentConfig);
    private _baseEnvironmentType?;
    get baseEnvironmentType(): string;
    set baseEnvironmentType(value: string);
    resetBaseEnvironmentType(): void;
    get baseEnvironmentTypeInput(): string | undefined;
    get createTime(): string;
    get creatorUserId(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get effectiveBaseEnvironmentType(): string;
    private _filepath?;
    get filepath(): string;
    set filepath(value: string);
    resetFilepath(): void;
    get filepathInput(): string | undefined;
    get isDefault(): cdktn.IResolvable;
    get lastUpdatedUserId(): string;
    get message(): string;
    get name(): string;
    private _providerConfig;
    get providerConfig(): EnvironmentsWorkspaceBaseEnvironmentProviderConfigOutputReference;
    putProviderConfig(value: EnvironmentsWorkspaceBaseEnvironmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | EnvironmentsWorkspaceBaseEnvironmentProviderConfig | undefined;
    get status(): string;
    get updateTime(): string;
    private _workspaceBaseEnvironmentId?;
    get workspaceBaseEnvironmentId(): string;
    set workspaceBaseEnvironmentId(value: string);
    resetWorkspaceBaseEnvironmentId(): void;
    get workspaceBaseEnvironmentIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
