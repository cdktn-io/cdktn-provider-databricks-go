/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DbfsFileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#content_base64 DbfsFile#content_base64}
    */
    readonly contentBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#id DbfsFile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#md5 DbfsFile#md5}
    */
    readonly md5?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#path DbfsFile#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#source DbfsFile#source}
    */
    readonly source?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#provider_config DbfsFile#provider_config}
    */
    readonly providerConfig?: DbfsFileProviderConfig;
}
export interface DbfsFileProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#workspace_id DbfsFile#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dbfsFileProviderConfigToTerraform(struct?: DbfsFileProviderConfigOutputReference | DbfsFileProviderConfig): any;
export declare function dbfsFileProviderConfigToHclTerraform(struct?: DbfsFileProviderConfigOutputReference | DbfsFileProviderConfig): any;
export declare class DbfsFileProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DbfsFileProviderConfig | undefined;
    set internalValue(value: DbfsFileProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file databricks_dbfs_file}
*/
export declare class DbfsFile extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_dbfs_file";
    /**
    * Generates CDKTN code for importing a DbfsFile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DbfsFile to import
    * @param importFromId The id of the existing DbfsFile that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DbfsFile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/dbfs_file databricks_dbfs_file} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DbfsFileConfig
    */
    constructor(scope: Construct, id: string, config: DbfsFileConfig);
    private _contentBase64?;
    get contentBase64(): string;
    set contentBase64(value: string);
    resetContentBase64(): void;
    get contentBase64Input(): string | undefined;
    get dbfsPath(): string;
    get fileSize(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _md5?;
    get md5(): string;
    set md5(value: string);
    resetMd5(): void;
    get md5Input(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DbfsFileProviderConfigOutputReference;
    putProviderConfig(value: DbfsFileProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DbfsFileProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
