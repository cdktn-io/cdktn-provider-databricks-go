/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksCurrentUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/current_user#id DataDatabricksCurrentUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/current_user#provider_config DataDatabricksCurrentUser#provider_config}
    */
    readonly providerConfig?: DataDatabricksCurrentUserProviderConfig;
}
export interface DataDatabricksCurrentUserProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/current_user#workspace_id DataDatabricksCurrentUser#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksCurrentUserProviderConfigToTerraform(struct?: DataDatabricksCurrentUserProviderConfigOutputReference | DataDatabricksCurrentUserProviderConfig): any;
export declare function dataDatabricksCurrentUserProviderConfigToHclTerraform(struct?: DataDatabricksCurrentUserProviderConfigOutputReference | DataDatabricksCurrentUserProviderConfig): any;
export declare class DataDatabricksCurrentUserProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCurrentUserProviderConfig | undefined;
    set internalValue(value: DataDatabricksCurrentUserProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/current_user databricks_current_user}
*/
export declare class DataDatabricksCurrentUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_current_user";
    /**
    * Generates CDKTN code for importing a DataDatabricksCurrentUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksCurrentUser to import
    * @param importFromId The id of the existing DataDatabricksCurrentUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/current_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksCurrentUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/current_user databricks_current_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksCurrentUserConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksCurrentUserConfig);
    get aclPrincipalId(): string;
    get alphanumeric(): string;
    get externalId(): string;
    get home(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get repos(): string;
    get userName(): string;
    get workspaceUrl(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksCurrentUserProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksCurrentUserProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksCurrentUserProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
