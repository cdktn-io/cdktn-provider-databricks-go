/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksCatalogsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/catalogs#id DataDatabricksCatalogs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/catalogs#ids DataDatabricksCatalogs#ids}
    */
    readonly ids?: string[];
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/catalogs#provider_config DataDatabricksCatalogs#provider_config}
    */
    readonly providerConfig?: DataDatabricksCatalogsProviderConfig;
}
export interface DataDatabricksCatalogsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/catalogs#workspace_id DataDatabricksCatalogs#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksCatalogsProviderConfigToTerraform(struct?: DataDatabricksCatalogsProviderConfigOutputReference | DataDatabricksCatalogsProviderConfig): any;
export declare function dataDatabricksCatalogsProviderConfigToHclTerraform(struct?: DataDatabricksCatalogsProviderConfigOutputReference | DataDatabricksCatalogsProviderConfig): any;
export declare class DataDatabricksCatalogsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCatalogsProviderConfig | undefined;
    set internalValue(value: DataDatabricksCatalogsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/catalogs databricks_catalogs}
*/
export declare class DataDatabricksCatalogs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_catalogs";
    /**
    * Generates CDKTN code for importing a DataDatabricksCatalogs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksCatalogs to import
    * @param importFromId The id of the existing DataDatabricksCatalogs that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/catalogs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksCatalogs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/catalogs databricks_catalogs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksCatalogsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksCatalogsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksCatalogsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksCatalogsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksCatalogsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
