/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GrantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#catalog Grant#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#credential Grant#credential}
    */
    readonly credential?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#external_location Grant#external_location}
    */
    readonly externalLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#foreign_connection Grant#foreign_connection}
    */
    readonly foreignConnection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#function Grant#function}
    */
    readonly function?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#id Grant#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#metastore Grant#metastore}
    */
    readonly metastore?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#model Grant#model}
    */
    readonly model?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#pipeline Grant#pipeline}
    */
    readonly pipeline?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#principal Grant#principal}
    */
    readonly principal: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#privileges Grant#privileges}
    */
    readonly privileges: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#recipient Grant#recipient}
    */
    readonly recipient?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#schema Grant#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#share Grant#share}
    */
    readonly share?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#storage_credential Grant#storage_credential}
    */
    readonly storageCredential?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#table Grant#table}
    */
    readonly table?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#volume Grant#volume}
    */
    readonly volume?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#provider_config Grant#provider_config}
    */
    readonly providerConfig?: GrantProviderConfig;
}
export interface GrantProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#workspace_id Grant#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function grantProviderConfigToTerraform(struct?: GrantProviderConfigOutputReference | GrantProviderConfig): any;
export declare function grantProviderConfigToHclTerraform(struct?: GrantProviderConfigOutputReference | GrantProviderConfig): any;
export declare class GrantProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantProviderConfig | undefined;
    set internalValue(value: GrantProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant databricks_grant}
*/
export declare class Grant extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_grant";
    /**
    * Generates CDKTN code for importing a Grant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Grant to import
    * @param importFromId The id of the existing Grant that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Grant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/grant databricks_grant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GrantConfig
    */
    constructor(scope: Construct, id: string, config: GrantConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _credential?;
    get credential(): string;
    set credential(value: string);
    resetCredential(): void;
    get credentialInput(): string | undefined;
    private _externalLocation?;
    get externalLocation(): string;
    set externalLocation(value: string);
    resetExternalLocation(): void;
    get externalLocationInput(): string | undefined;
    private _foreignConnection?;
    get foreignConnection(): string;
    set foreignConnection(value: string);
    resetForeignConnection(): void;
    get foreignConnectionInput(): string | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    resetFunction(): void;
    get functionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastore?;
    get metastore(): string;
    set metastore(value: string);
    resetMetastore(): void;
    get metastoreInput(): string | undefined;
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _pipeline?;
    get pipeline(): string;
    set pipeline(value: string);
    resetPipeline(): void;
    get pipelineInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
    private _recipient?;
    get recipient(): string;
    set recipient(value: string);
    resetRecipient(): void;
    get recipientInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _share?;
    get share(): string;
    set share(value: string);
    resetShare(): void;
    get shareInput(): string | undefined;
    private _storageCredential?;
    get storageCredential(): string;
    set storageCredential(value: string);
    resetStorageCredential(): void;
    get storageCredentialInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    resetTable(): void;
    get tableInput(): string | undefined;
    private _volume?;
    get volume(): string;
    set volume(value: string);
    resetVolume(): void;
    get volumeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): GrantProviderConfigOutputReference;
    putProviderConfig(value: GrantProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): GrantProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
