/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksServingEndpointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#endpoints DataDatabricksServingEndpoints#endpoints}
    */
    readonly endpoints?: DataDatabricksServingEndpointsEndpoints[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#provider_config DataDatabricksServingEndpoints#provider_config}
    */
    readonly providerConfig?: DataDatabricksServingEndpointsProviderConfig;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#enabled DataDatabricksServingEndpoints#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#behavior DataDatabricksServingEndpoints#behavior}
    */
    readonly behavior?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPiiToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPiiToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPiiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPiiList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPiiOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#invalid_keywords DataDatabricksServingEndpoints#invalid_keywords}
    */
    readonly invalidKeywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#pii DataDatabricksServingEndpoints#pii}
    */
    readonly pii?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#safety DataDatabricksServingEndpoints#safety}
    */
    readonly safety?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#valid_topics DataDatabricksServingEndpoints#valid_topics}
    */
    readonly validTopics?: string[];
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput | cdktn.IResolvable | undefined);
    private _invalidKeywords?;
    get invalidKeywords(): string[];
    set invalidKeywords(value: string[]);
    resetInvalidKeywords(): void;
    get invalidKeywordsInput(): string[] | undefined;
    private _pii;
    get pii(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPiiList;
    putPii(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii[] | cdktn.IResolvable): void;
    resetPii(): void;
    get piiInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputPii[] | undefined;
    private _safety?;
    get safety(): boolean | cdktn.IResolvable;
    set safety(value: boolean | cdktn.IResolvable);
    resetSafety(): void;
    get safetyInput(): boolean | cdktn.IResolvable | undefined;
    private _validTopics?;
    get validTopics(): string[];
    set validTopics(value: string[]);
    resetValidTopics(): void;
    get validTopicsInput(): string[] | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#behavior DataDatabricksServingEndpoints#behavior}
    */
    readonly behavior?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPiiToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPiiToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPiiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii | cdktn.IResolvable | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPiiList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPiiOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#invalid_keywords DataDatabricksServingEndpoints#invalid_keywords}
    */
    readonly invalidKeywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#pii DataDatabricksServingEndpoints#pii}
    */
    readonly pii?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#safety DataDatabricksServingEndpoints#safety}
    */
    readonly safety?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#valid_topics DataDatabricksServingEndpoints#valid_topics}
    */
    readonly validTopics?: string[];
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput | cdktn.IResolvable | undefined);
    private _invalidKeywords?;
    get invalidKeywords(): string[];
    set invalidKeywords(value: string[]);
    resetInvalidKeywords(): void;
    get invalidKeywordsInput(): string[] | undefined;
    private _pii;
    get pii(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPiiList;
    putPii(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii[] | cdktn.IResolvable): void;
    resetPii(): void;
    get piiInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputPii[] | undefined;
    private _safety?;
    get safety(): boolean | cdktn.IResolvable;
    set safety(value: boolean | cdktn.IResolvable);
    resetSafety(): void;
    get safetyInput(): boolean | cdktn.IResolvable | undefined;
    private _validTopics?;
    get validTopics(): string[];
    set validTopics(value: string[]);
    resetValidTopics(): void;
    get validTopicsInput(): string[] | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#input DataDatabricksServingEndpoints#input}
    */
    readonly input?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#output DataDatabricksServingEndpoints#output}
    */
    readonly output?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput[] | cdktn.IResolvable;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails | cdktn.IResolvable | undefined);
    private _input;
    get input(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInputList;
    putInput(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput[] | cdktn.IResolvable): void;
    resetInput(): void;
    get inputInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsInput[] | undefined;
    private _output;
    get output(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputList;
    putOutput(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput[] | cdktn.IResolvable): void;
    resetOutput(): void;
    get outputInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutput[] | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#catalog_name DataDatabricksServingEndpoints#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#enabled DataDatabricksServingEndpoints#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#schema_name DataDatabricksServingEndpoints#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#table_name_prefix DataDatabricksServingEndpoints#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#calls DataDatabricksServingEndpoints#calls}
    */
    readonly calls?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#key DataDatabricksServingEndpoints#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#principal DataDatabricksServingEndpoints#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#renewal_period DataDatabricksServingEndpoints#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#tokens DataDatabricksServingEndpoints#tokens}
    */
    readonly tokens?: number;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayRateLimitsToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayRateLimitsToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits | cdktn.IResolvable | undefined);
    private _calls?;
    get calls(): number;
    set calls(value: number);
    resetCalls(): void;
    get callsInput(): number | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayRateLimitsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayRateLimitsOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#enabled DataDatabricksServingEndpoints#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsAiGateway {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#fallback_config DataDatabricksServingEndpoints#fallback_config}
    */
    readonly fallbackConfig?: DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#guardrails DataDatabricksServingEndpoints#guardrails}
    */
    readonly guardrails?: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#inference_table_config DataDatabricksServingEndpoints#inference_table_config}
    */
    readonly inferenceTableConfig?: DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#rate_limits DataDatabricksServingEndpoints#rate_limits}
    */
    readonly rateLimits?: DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#usage_tracking_config DataDatabricksServingEndpoints#usage_tracking_config}
    */
    readonly usageTrackingConfig?: DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig[] | cdktn.IResolvable;
}
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayToTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGateway | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsAiGatewayToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsAiGateway | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsAiGateway | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsAiGateway | cdktn.IResolvable | undefined);
    private _fallbackConfig;
    get fallbackConfig(): DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfigList;
    putFallbackConfig(value: DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig[] | cdktn.IResolvable): void;
    resetFallbackConfig(): void;
    get fallbackConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayFallbackConfig[] | undefined;
    private _guardrails;
    get guardrails(): DataDatabricksServingEndpointsEndpointsAiGatewayGuardrailsList;
    putGuardrails(value: DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails[] | cdktn.IResolvable): void;
    resetGuardrails(): void;
    get guardrailsInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayGuardrails[] | undefined;
    private _inferenceTableConfig;
    get inferenceTableConfig(): DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfigList;
    putInferenceTableConfig(value: DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig[] | cdktn.IResolvable): void;
    resetInferenceTableConfig(): void;
    get inferenceTableConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayInferenceTableConfig[] | undefined;
    private _rateLimits;
    get rateLimits(): DataDatabricksServingEndpointsEndpointsAiGatewayRateLimitsList;
    putRateLimits(value: DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayRateLimits[] | undefined;
    private _usageTrackingConfig;
    get usageTrackingConfig(): DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfigList;
    putUsageTrackingConfig(value: DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig[] | cdktn.IResolvable): void;
    resetUsageTrackingConfig(): void;
    get usageTrackingConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGatewayUsageTrackingConfig[] | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsAiGatewayList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsAiGateway[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsAiGatewayOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#ai21labs_api_key DataDatabricksServingEndpoints#ai21labs_api_key}
    */
    readonly ai21LabsApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#ai21labs_api_key_plaintext DataDatabricksServingEndpoints#ai21labs_api_key_plaintext}
    */
    readonly ai21LabsApiKeyPlaintext?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig | cdktn.IResolvable | undefined);
    private _ai21LabsApiKey?;
    get ai21LabsApiKey(): string;
    set ai21LabsApiKey(value: string);
    resetAi21LabsApiKey(): void;
    get ai21LabsApiKeyInput(): string | undefined;
    private _ai21LabsApiKeyPlaintext?;
    get ai21LabsApiKeyPlaintext(): string;
    set ai21LabsApiKeyPlaintext(value: string);
    resetAi21LabsApiKeyPlaintext(): void;
    get ai21LabsApiKeyPlaintextInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#aws_access_key_id DataDatabricksServingEndpoints#aws_access_key_id}
    */
    readonly awsAccessKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#aws_access_key_id_plaintext DataDatabricksServingEndpoints#aws_access_key_id_plaintext}
    */
    readonly awsAccessKeyIdPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#aws_region DataDatabricksServingEndpoints#aws_region}
    */
    readonly awsRegion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#aws_secret_access_key DataDatabricksServingEndpoints#aws_secret_access_key}
    */
    readonly awsSecretAccessKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#aws_secret_access_key_plaintext DataDatabricksServingEndpoints#aws_secret_access_key_plaintext}
    */
    readonly awsSecretAccessKeyPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#bedrock_provider DataDatabricksServingEndpoints#bedrock_provider}
    */
    readonly bedrockProvider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#instance_profile_arn DataDatabricksServingEndpoints#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig | cdktn.IResolvable | undefined);
    private _awsAccessKeyId?;
    get awsAccessKeyId(): string;
    set awsAccessKeyId(value: string);
    resetAwsAccessKeyId(): void;
    get awsAccessKeyIdInput(): string | undefined;
    private _awsAccessKeyIdPlaintext?;
    get awsAccessKeyIdPlaintext(): string;
    set awsAccessKeyIdPlaintext(value: string);
    resetAwsAccessKeyIdPlaintext(): void;
    get awsAccessKeyIdPlaintextInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    get awsRegionInput(): string | undefined;
    private _awsSecretAccessKey?;
    get awsSecretAccessKey(): string;
    set awsSecretAccessKey(value: string);
    resetAwsSecretAccessKey(): void;
    get awsSecretAccessKeyInput(): string | undefined;
    private _awsSecretAccessKeyPlaintext?;
    get awsSecretAccessKeyPlaintext(): string;
    set awsSecretAccessKeyPlaintext(value: string);
    resetAwsSecretAccessKeyPlaintext(): void;
    get awsSecretAccessKeyPlaintextInput(): string | undefined;
    private _bedrockProvider?;
    get bedrockProvider(): string;
    set bedrockProvider(value: string);
    get bedrockProviderInput(): string | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#anthropic_api_key DataDatabricksServingEndpoints#anthropic_api_key}
    */
    readonly anthropicApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#anthropic_api_key_plaintext DataDatabricksServingEndpoints#anthropic_api_key_plaintext}
    */
    readonly anthropicApiKeyPlaintext?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig | cdktn.IResolvable | undefined);
    private _anthropicApiKey?;
    get anthropicApiKey(): string;
    set anthropicApiKey(value: string);
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): string | undefined;
    private _anthropicApiKeyPlaintext?;
    get anthropicApiKeyPlaintext(): string;
    set anthropicApiKeyPlaintext(value: string);
    resetAnthropicApiKeyPlaintext(): void;
    get anthropicApiKeyPlaintextInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#cohere_api_base DataDatabricksServingEndpoints#cohere_api_base}
    */
    readonly cohereApiBase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#cohere_api_key DataDatabricksServingEndpoints#cohere_api_key}
    */
    readonly cohereApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#cohere_api_key_plaintext DataDatabricksServingEndpoints#cohere_api_key_plaintext}
    */
    readonly cohereApiKeyPlaintext?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig | cdktn.IResolvable | undefined);
    private _cohereApiBase?;
    get cohereApiBase(): string;
    set cohereApiBase(value: string);
    resetCohereApiBase(): void;
    get cohereApiBaseInput(): string | undefined;
    private _cohereApiKey?;
    get cohereApiKey(): string;
    set cohereApiKey(value: string);
    resetCohereApiKey(): void;
    get cohereApiKeyInput(): string | undefined;
    private _cohereApiKeyPlaintext?;
    get cohereApiKeyPlaintext(): string;
    set cohereApiKeyPlaintext(value: string);
    resetCohereApiKeyPlaintext(): void;
    get cohereApiKeyPlaintextInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#key DataDatabricksServingEndpoints#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#value DataDatabricksServingEndpoints#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#value_plaintext DataDatabricksServingEndpoints#value_plaintext}
    */
    readonly valuePlaintext?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valuePlaintext?;
    get valuePlaintext(): string;
    set valuePlaintext(value: string);
    resetValuePlaintext(): void;
    get valuePlaintextInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#token DataDatabricksServingEndpoints#token}
    */
    readonly token?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#token_plaintext DataDatabricksServingEndpoints#token_plaintext}
    */
    readonly tokenPlaintext?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth | cdktn.IResolvable | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _tokenPlaintext?;
    get tokenPlaintext(): string;
    set tokenPlaintext(value: string);
    resetTokenPlaintext(): void;
    get tokenPlaintextInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#api_key_auth DataDatabricksServingEndpoints#api_key_auth}
    */
    readonly apiKeyAuth?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#bearer_token_auth DataDatabricksServingEndpoints#bearer_token_auth}
    */
    readonly bearerTokenAuth?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#custom_provider_url DataDatabricksServingEndpoints#custom_provider_url}
    */
    readonly customProviderUrl: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig | cdktn.IResolvable | undefined);
    private _apiKeyAuth;
    get apiKeyAuth(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthList;
    putApiKeyAuth(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth[] | cdktn.IResolvable): void;
    resetApiKeyAuth(): void;
    get apiKeyAuthInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth[] | undefined;
    private _bearerTokenAuth;
    get bearerTokenAuth(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthList;
    putBearerTokenAuth(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth[] | cdktn.IResolvable): void;
    resetBearerTokenAuth(): void;
    get bearerTokenAuthInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth[] | undefined;
    private _customProviderUrl?;
    get customProviderUrl(): string;
    set customProviderUrl(value: string);
    get customProviderUrlInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#databricks_api_token DataDatabricksServingEndpoints#databricks_api_token}
    */
    readonly databricksApiToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#databricks_api_token_plaintext DataDatabricksServingEndpoints#databricks_api_token_plaintext}
    */
    readonly databricksApiTokenPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#databricks_workspace_url DataDatabricksServingEndpoints#databricks_workspace_url}
    */
    readonly databricksWorkspaceUrl: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig | cdktn.IResolvable | undefined);
    private _databricksApiToken?;
    get databricksApiToken(): string;
    set databricksApiToken(value: string);
    resetDatabricksApiToken(): void;
    get databricksApiTokenInput(): string | undefined;
    private _databricksApiTokenPlaintext?;
    get databricksApiTokenPlaintext(): string;
    set databricksApiTokenPlaintext(value: string);
    resetDatabricksApiTokenPlaintext(): void;
    get databricksApiTokenPlaintextInput(): string | undefined;
    private _databricksWorkspaceUrl?;
    get databricksWorkspaceUrl(): string;
    set databricksWorkspaceUrl(value: string);
    get databricksWorkspaceUrlInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#private_key DataDatabricksServingEndpoints#private_key}
    */
    readonly privateKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#private_key_plaintext DataDatabricksServingEndpoints#private_key_plaintext}
    */
    readonly privateKeyPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#project_id DataDatabricksServingEndpoints#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#region DataDatabricksServingEndpoints#region}
    */
    readonly region: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig | cdktn.IResolvable | undefined);
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _privateKeyPlaintext?;
    get privateKeyPlaintext(): string;
    set privateKeyPlaintext(value: string);
    resetPrivateKeyPlaintext(): void;
    get privateKeyPlaintextInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#microsoft_entra_client_id DataDatabricksServingEndpoints#microsoft_entra_client_id}
    */
    readonly microsoftEntraClientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#microsoft_entra_client_secret DataDatabricksServingEndpoints#microsoft_entra_client_secret}
    */
    readonly microsoftEntraClientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#microsoft_entra_client_secret_plaintext DataDatabricksServingEndpoints#microsoft_entra_client_secret_plaintext}
    */
    readonly microsoftEntraClientSecretPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#microsoft_entra_tenant_id DataDatabricksServingEndpoints#microsoft_entra_tenant_id}
    */
    readonly microsoftEntraTenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_api_base DataDatabricksServingEndpoints#openai_api_base}
    */
    readonly openaiApiBase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_api_key DataDatabricksServingEndpoints#openai_api_key}
    */
    readonly openaiApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_api_key_plaintext DataDatabricksServingEndpoints#openai_api_key_plaintext}
    */
    readonly openaiApiKeyPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_api_type DataDatabricksServingEndpoints#openai_api_type}
    */
    readonly openaiApiType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_api_version DataDatabricksServingEndpoints#openai_api_version}
    */
    readonly openaiApiVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_deployment_name DataDatabricksServingEndpoints#openai_deployment_name}
    */
    readonly openaiDeploymentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_organization DataDatabricksServingEndpoints#openai_organization}
    */
    readonly openaiOrganization?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig | cdktn.IResolvable | undefined);
    private _microsoftEntraClientId?;
    get microsoftEntraClientId(): string;
    set microsoftEntraClientId(value: string);
    resetMicrosoftEntraClientId(): void;
    get microsoftEntraClientIdInput(): string | undefined;
    private _microsoftEntraClientSecret?;
    get microsoftEntraClientSecret(): string;
    set microsoftEntraClientSecret(value: string);
    resetMicrosoftEntraClientSecret(): void;
    get microsoftEntraClientSecretInput(): string | undefined;
    private _microsoftEntraClientSecretPlaintext?;
    get microsoftEntraClientSecretPlaintext(): string;
    set microsoftEntraClientSecretPlaintext(value: string);
    resetMicrosoftEntraClientSecretPlaintext(): void;
    get microsoftEntraClientSecretPlaintextInput(): string | undefined;
    private _microsoftEntraTenantId?;
    get microsoftEntraTenantId(): string;
    set microsoftEntraTenantId(value: string);
    resetMicrosoftEntraTenantId(): void;
    get microsoftEntraTenantIdInput(): string | undefined;
    private _openaiApiBase?;
    get openaiApiBase(): string;
    set openaiApiBase(value: string);
    resetOpenaiApiBase(): void;
    get openaiApiBaseInput(): string | undefined;
    private _openaiApiKey?;
    get openaiApiKey(): string;
    set openaiApiKey(value: string);
    resetOpenaiApiKey(): void;
    get openaiApiKeyInput(): string | undefined;
    private _openaiApiKeyPlaintext?;
    get openaiApiKeyPlaintext(): string;
    set openaiApiKeyPlaintext(value: string);
    resetOpenaiApiKeyPlaintext(): void;
    get openaiApiKeyPlaintextInput(): string | undefined;
    private _openaiApiType?;
    get openaiApiType(): string;
    set openaiApiType(value: string);
    resetOpenaiApiType(): void;
    get openaiApiTypeInput(): string | undefined;
    private _openaiApiVersion?;
    get openaiApiVersion(): string;
    set openaiApiVersion(value: string);
    resetOpenaiApiVersion(): void;
    get openaiApiVersionInput(): string | undefined;
    private _openaiDeploymentName?;
    get openaiDeploymentName(): string;
    set openaiDeploymentName(value: string);
    resetOpenaiDeploymentName(): void;
    get openaiDeploymentNameInput(): string | undefined;
    private _openaiOrganization?;
    get openaiOrganization(): string;
    set openaiOrganization(value: string);
    resetOpenaiOrganization(): void;
    get openaiOrganizationInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#palm_api_key DataDatabricksServingEndpoints#palm_api_key}
    */
    readonly palmApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#palm_api_key_plaintext DataDatabricksServingEndpoints#palm_api_key_plaintext}
    */
    readonly palmApiKeyPlaintext?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig | cdktn.IResolvable | undefined);
    private _palmApiKey?;
    get palmApiKey(): string;
    set palmApiKey(value: string);
    resetPalmApiKey(): void;
    get palmApiKeyInput(): string | undefined;
    private _palmApiKeyPlaintext?;
    get palmApiKeyPlaintext(): string;
    set palmApiKeyPlaintext(value: string);
    resetPalmApiKeyPlaintext(): void;
    get palmApiKeyPlaintextInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#ai21labs_config DataDatabricksServingEndpoints#ai21labs_config}
    */
    readonly ai21LabsConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#amazon_bedrock_config DataDatabricksServingEndpoints#amazon_bedrock_config}
    */
    readonly amazonBedrockConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#anthropic_config DataDatabricksServingEndpoints#anthropic_config}
    */
    readonly anthropicConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#cohere_config DataDatabricksServingEndpoints#cohere_config}
    */
    readonly cohereConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#custom_provider_config DataDatabricksServingEndpoints#custom_provider_config}
    */
    readonly customProviderConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#databricks_model_serving_config DataDatabricksServingEndpoints#databricks_model_serving_config}
    */
    readonly databricksModelServingConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#google_cloud_vertex_ai_config DataDatabricksServingEndpoints#google_cloud_vertex_ai_config}
    */
    readonly googleCloudVertexAiConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#name DataDatabricksServingEndpoints#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#openai_config DataDatabricksServingEndpoints#openai_config}
    */
    readonly openaiConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#palm_config DataDatabricksServingEndpoints#palm_config}
    */
    readonly palmConfig?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#provider DataDatabricksServingEndpoints#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#task DataDatabricksServingEndpoints#task}
    */
    readonly task: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel | cdktn.IResolvable | undefined);
    private _ai21LabsConfig;
    get ai21LabsConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfigList;
    putAi21LabsConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig[] | cdktn.IResolvable): void;
    resetAi21LabsConfig(): void;
    get ai21LabsConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAi21LabsConfig[] | undefined;
    private _amazonBedrockConfig;
    get amazonBedrockConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfigList;
    putAmazonBedrockConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig[] | cdktn.IResolvable): void;
    resetAmazonBedrockConfig(): void;
    get amazonBedrockConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAmazonBedrockConfig[] | undefined;
    private _anthropicConfig;
    get anthropicConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfigList;
    putAnthropicConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig[] | cdktn.IResolvable): void;
    resetAnthropicConfig(): void;
    get anthropicConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelAnthropicConfig[] | undefined;
    private _cohereConfig;
    get cohereConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfigList;
    putCohereConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig[] | cdktn.IResolvable): void;
    resetCohereConfig(): void;
    get cohereConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCohereConfig[] | undefined;
    private _customProviderConfig;
    get customProviderConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfigList;
    putCustomProviderConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig[] | cdktn.IResolvable): void;
    resetCustomProviderConfig(): void;
    get customProviderConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelCustomProviderConfig[] | undefined;
    private _databricksModelServingConfig;
    get databricksModelServingConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfigList;
    putDatabricksModelServingConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig[] | cdktn.IResolvable): void;
    resetDatabricksModelServingConfig(): void;
    get databricksModelServingConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelDatabricksModelServingConfig[] | undefined;
    private _googleCloudVertexAiConfig;
    get googleCloudVertexAiConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigList;
    putGoogleCloudVertexAiConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig[] | cdktn.IResolvable): void;
    resetGoogleCloudVertexAiConfig(): void;
    get googleCloudVertexAiConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _openaiConfig;
    get openaiConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfigList;
    putOpenaiConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig[] | cdktn.IResolvable): void;
    resetOpenaiConfig(): void;
    get openaiConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOpenaiConfig[] | undefined;
    private _palmConfig;
    get palmConfig(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfigList;
    putPalmConfig(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig[] | cdktn.IResolvable): void;
    resetPalmConfig(): void;
    get palmConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelPalmConfig[] | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _task?;
    get task(): string;
    set task(value: string);
    get taskInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#description DataDatabricksServingEndpoints#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#display_name DataDatabricksServingEndpoints#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#docs DataDatabricksServingEndpoints#docs}
    */
    readonly docs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#name DataDatabricksServingEndpoints#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModelToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModelToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _docs?;
    get docs(): string;
    set docs(value: string);
    resetDocs(): void;
    get docsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModelList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModelOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedEntities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#entity_name DataDatabricksServingEndpoints#entity_name}
    */
    readonly entityName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#entity_version DataDatabricksServingEndpoints#entity_version}
    */
    readonly entityVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#external_model DataDatabricksServingEndpoints#external_model}
    */
    readonly externalModel?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#foundation_model DataDatabricksServingEndpoints#foundation_model}
    */
    readonly foundationModel?: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#name DataDatabricksServingEndpoints#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntities | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedEntitiesToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedEntities | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedEntities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedEntities | cdktn.IResolvable | undefined);
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    resetEntityName(): void;
    get entityNameInput(): string | undefined;
    private _entityVersion?;
    get entityVersion(): string;
    set entityVersion(value: string);
    resetEntityVersion(): void;
    get entityVersionInput(): string | undefined;
    private _externalModel;
    get externalModel(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModelList;
    putExternalModel(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel[] | cdktn.IResolvable): void;
    resetExternalModel(): void;
    get externalModelInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesExternalModel[] | undefined;
    private _foundationModel;
    get foundationModel(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModelList;
    putFoundationModel(value: DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel[] | cdktn.IResolvable): void;
    resetFoundationModel(): void;
    get foundationModelInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntitiesFoundationModel[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedEntitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfigServedModels {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#model_name DataDatabricksServingEndpoints#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#model_version DataDatabricksServingEndpoints#model_version}
    */
    readonly modelVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#name DataDatabricksServingEndpoints#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigServedModelsToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedModels | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigServedModelsToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfigServedModels | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigServedModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfigServedModels | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfigServedModels | cdktn.IResolvable | undefined);
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _modelVersion?;
    get modelVersion(): string;
    set modelVersion(value: string);
    resetModelVersion(): void;
    get modelVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigServedModelsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfigServedModels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigServedModelsOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#served_entities DataDatabricksServingEndpoints#served_entities}
    */
    readonly servedEntities?: DataDatabricksServingEndpointsEndpointsConfigServedEntities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#served_models DataDatabricksServingEndpoints#served_models}
    */
    readonly servedModels?: DataDatabricksServingEndpointsEndpointsConfigServedModels[] | cdktn.IResolvable;
}
export declare function dataDatabricksServingEndpointsEndpointsConfigToTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsConfigToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsConfig | cdktn.IResolvable | undefined);
    private _servedEntities;
    get servedEntities(): DataDatabricksServingEndpointsEndpointsConfigServedEntitiesList;
    putServedEntities(value: DataDatabricksServingEndpointsEndpointsConfigServedEntities[] | cdktn.IResolvable): void;
    resetServedEntities(): void;
    get servedEntitiesInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedEntities[] | undefined;
    private _servedModels;
    get servedModels(): DataDatabricksServingEndpointsEndpointsConfigServedModelsList;
    putServedModels(value: DataDatabricksServingEndpointsEndpointsConfigServedModels[] | cdktn.IResolvable): void;
    resetServedModels(): void;
    get servedModelsInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfigServedModels[] | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsConfigList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsConfigOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsState {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#config_update DataDatabricksServingEndpoints#config_update}
    */
    readonly configUpdate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#ready DataDatabricksServingEndpoints#ready}
    */
    readonly ready?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsStateToTerraform(struct?: DataDatabricksServingEndpointsEndpointsState | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsStateToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsState | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsState | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsState | cdktn.IResolvable | undefined);
    private _configUpdate?;
    get configUpdate(): string;
    set configUpdate(value: string);
    resetConfigUpdate(): void;
    get configUpdateInput(): string | undefined;
    private _ready?;
    get ready(): string;
    set ready(value: string);
    resetReady(): void;
    get readyInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsStateList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsState[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsStateOutputReference;
}
export interface DataDatabricksServingEndpointsEndpointsTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#key DataDatabricksServingEndpoints#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#value DataDatabricksServingEndpoints#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsTagsToTerraform(struct?: DataDatabricksServingEndpointsEndpointsTags | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsTagsToHclTerraform(struct?: DataDatabricksServingEndpointsEndpointsTags | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpointsTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpointsTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpointsTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsTagsOutputReference;
}
export interface DataDatabricksServingEndpointsEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#ai_gateway DataDatabricksServingEndpoints#ai_gateway}
    */
    readonly aiGateway?: DataDatabricksServingEndpointsEndpointsAiGateway[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#budget_policy_id DataDatabricksServingEndpoints#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#config DataDatabricksServingEndpoints#config}
    */
    readonly config?: DataDatabricksServingEndpointsEndpointsConfig[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#creation_timestamp DataDatabricksServingEndpoints#creation_timestamp}
    */
    readonly creationTimestamp?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#creator DataDatabricksServingEndpoints#creator}
    */
    readonly creator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#description DataDatabricksServingEndpoints#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#id DataDatabricksServingEndpoints#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#last_updated_timestamp DataDatabricksServingEndpoints#last_updated_timestamp}
    */
    readonly lastUpdatedTimestamp?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#name DataDatabricksServingEndpoints#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#state DataDatabricksServingEndpoints#state}
    */
    readonly state?: DataDatabricksServingEndpointsEndpointsState[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#tags DataDatabricksServingEndpoints#tags}
    */
    readonly tags?: DataDatabricksServingEndpointsEndpointsTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#task DataDatabricksServingEndpoints#task}
    */
    readonly task?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#usage_policy_id DataDatabricksServingEndpoints#usage_policy_id}
    */
    readonly usagePolicyId?: string;
}
export declare function dataDatabricksServingEndpointsEndpointsToTerraform(struct?: DataDatabricksServingEndpointsEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsEndpointsToHclTerraform(struct?: DataDatabricksServingEndpointsEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServingEndpointsEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsEndpoints | cdktn.IResolvable | undefined);
    private _aiGateway;
    get aiGateway(): DataDatabricksServingEndpointsEndpointsAiGatewayList;
    putAiGateway(value: DataDatabricksServingEndpointsEndpointsAiGateway[] | cdktn.IResolvable): void;
    resetAiGateway(): void;
    get aiGatewayInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsAiGateway[] | undefined;
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _config;
    get config(): DataDatabricksServingEndpointsEndpointsConfigList;
    putConfig(value: DataDatabricksServingEndpointsEndpointsConfig[] | cdktn.IResolvable): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsConfig[] | undefined;
    private _creationTimestamp?;
    get creationTimestamp(): number;
    set creationTimestamp(value: number);
    resetCreationTimestamp(): void;
    get creationTimestampInput(): number | undefined;
    private _creator?;
    get creator(): string;
    set creator(value: string);
    resetCreator(): void;
    get creatorInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastUpdatedTimestamp?;
    get lastUpdatedTimestamp(): number;
    set lastUpdatedTimestamp(value: number);
    resetLastUpdatedTimestamp(): void;
    get lastUpdatedTimestampInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _state;
    get state(): DataDatabricksServingEndpointsEndpointsStateList;
    putState(value: DataDatabricksServingEndpointsEndpointsState[] | cdktn.IResolvable): void;
    resetState(): void;
    get stateInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsState[] | undefined;
    private _tags;
    get tags(): DataDatabricksServingEndpointsEndpointsTagsList;
    putTags(value: DataDatabricksServingEndpointsEndpointsTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpointsTags[] | undefined;
    private _task?;
    get task(): string;
    set task(value: string);
    resetTask(): void;
    get taskInput(): string | undefined;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
}
export declare class DataDatabricksServingEndpointsEndpointsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksServingEndpointsEndpoints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServingEndpointsEndpointsOutputReference;
}
export interface DataDatabricksServingEndpointsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#workspace_id DataDatabricksServingEndpoints#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksServingEndpointsProviderConfigToTerraform(struct?: DataDatabricksServingEndpointsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksServingEndpointsProviderConfigToHclTerraform(struct?: DataDatabricksServingEndpointsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksServingEndpointsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksServingEndpointsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServingEndpointsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints databricks_serving_endpoints}
*/
export declare class DataDatabricksServingEndpoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_serving_endpoints";
    /**
    * Generates CDKTN code for importing a DataDatabricksServingEndpoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksServingEndpoints to import
    * @param importFromId The id of the existing DataDatabricksServingEndpoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksServingEndpoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/serving_endpoints databricks_serving_endpoints} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksServingEndpointsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksServingEndpointsConfig);
    private _endpoints;
    get endpoints(): DataDatabricksServingEndpointsEndpointsList;
    putEndpoints(value: DataDatabricksServingEndpointsEndpoints[] | cdktn.IResolvable): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksServingEndpointsEndpoints[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksServingEndpointsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksServingEndpointsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksServingEndpointsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
