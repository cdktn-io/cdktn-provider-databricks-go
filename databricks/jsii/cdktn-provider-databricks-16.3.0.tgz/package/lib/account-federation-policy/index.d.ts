/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountFederationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#description AccountFederationPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#oidc_policy AccountFederationPolicy#oidc_policy}
    */
    readonly oidcPolicy?: AccountFederationPolicyOidcPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#policy_id AccountFederationPolicy#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#service_principal_id AccountFederationPolicy#service_principal_id}
    */
    readonly servicePrincipalId?: number;
}
export interface AccountFederationPolicyOidcPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#audiences AccountFederationPolicy#audiences}
    */
    readonly audiences?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#issuer AccountFederationPolicy#issuer}
    */
    readonly issuer?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#jwks_json AccountFederationPolicy#jwks_json}
    */
    readonly jwksJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#jwks_uri AccountFederationPolicy#jwks_uri}
    */
    readonly jwksUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#subject AccountFederationPolicy#subject}
    */
    readonly subject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#subject_claim AccountFederationPolicy#subject_claim}
    */
    readonly subjectClaim?: string;
}
export declare function accountFederationPolicyOidcPolicyToTerraform(struct?: AccountFederationPolicyOidcPolicy | cdktn.IResolvable): any;
export declare function accountFederationPolicyOidcPolicyToHclTerraform(struct?: AccountFederationPolicyOidcPolicy | cdktn.IResolvable): any;
export declare class AccountFederationPolicyOidcPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountFederationPolicyOidcPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AccountFederationPolicyOidcPolicy | cdktn.IResolvable | undefined);
    private _audiences?;
    get audiences(): string[];
    set audiences(value: string[]);
    resetAudiences(): void;
    get audiencesInput(): string[] | undefined;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    resetIssuer(): void;
    get issuerInput(): string | undefined;
    private _jwksJson?;
    get jwksJson(): string;
    set jwksJson(value: string);
    resetJwksJson(): void;
    get jwksJsonInput(): string | undefined;
    private _jwksUri?;
    get jwksUri(): string;
    set jwksUri(value: string);
    resetJwksUri(): void;
    get jwksUriInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    resetSubject(): void;
    get subjectInput(): string | undefined;
    private _subjectClaim?;
    get subjectClaim(): string;
    set subjectClaim(value: string);
    resetSubjectClaim(): void;
    get subjectClaimInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy databricks_account_federation_policy}
*/
export declare class AccountFederationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_federation_policy";
    /**
    * Generates CDKTN code for importing a AccountFederationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountFederationPolicy to import
    * @param importFromId The id of the existing AccountFederationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountFederationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/account_federation_policy databricks_account_federation_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountFederationPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AccountFederationPolicyConfig);
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get name(): string;
    private _oidcPolicy;
    get oidcPolicy(): AccountFederationPolicyOidcPolicyOutputReference;
    putOidcPolicy(value: AccountFederationPolicyOidcPolicy): void;
    resetOidcPolicy(): void;
    get oidcPolicyInput(): cdktn.IResolvable | AccountFederationPolicyOidcPolicy | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): number;
    set servicePrincipalId(value: number);
    resetServicePrincipalId(): void;
    get servicePrincipalIdInput(): number | undefined;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
