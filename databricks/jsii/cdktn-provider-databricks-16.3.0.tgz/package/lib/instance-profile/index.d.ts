/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface InstanceProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#iam_role_arn InstanceProfile#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#id InstanceProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#instance_profile_arn InstanceProfile#instance_profile_arn}
    */
    readonly instanceProfileArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#is_meta_instance_profile InstanceProfile#is_meta_instance_profile}
    */
    readonly isMetaInstanceProfile?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#skip_validation InstanceProfile#skip_validation}
    */
    readonly skipValidation?: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#provider_config InstanceProfile#provider_config}
    */
    readonly providerConfig?: InstanceProfileProviderConfig;
}
export interface InstanceProfileProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#workspace_id InstanceProfile#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function instanceProfileProviderConfigToTerraform(struct?: InstanceProfileProviderConfigOutputReference | InstanceProfileProviderConfig): any;
export declare function instanceProfileProviderConfigToHclTerraform(struct?: InstanceProfileProviderConfigOutputReference | InstanceProfileProviderConfig): any;
export declare class InstanceProfileProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InstanceProfileProviderConfig | undefined;
    set internalValue(value: InstanceProfileProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile databricks_instance_profile}
*/
export declare class InstanceProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_instance_profile";
    /**
    * Generates CDKTN code for importing a InstanceProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the InstanceProfile to import
    * @param importFromId The id of the existing InstanceProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the InstanceProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/instance_profile databricks_instance_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options InstanceProfileConfig
    */
    constructor(scope: Construct, id: string, config: InstanceProfileConfig);
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    get instanceProfileArnInput(): string | undefined;
    private _isMetaInstanceProfile?;
    get isMetaInstanceProfile(): boolean | cdktn.IResolvable;
    set isMetaInstanceProfile(value: boolean | cdktn.IResolvable);
    resetIsMetaInstanceProfile(): void;
    get isMetaInstanceProfileInput(): boolean | cdktn.IResolvable | undefined;
    private _skipValidation?;
    get skipValidation(): boolean | cdktn.IResolvable;
    set skipValidation(value: boolean | cdktn.IResolvable);
    resetSkipValidation(): void;
    get skipValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): InstanceProfileProviderConfigOutputReference;
    putProviderConfig(value: InstanceProfileProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): InstanceProfileProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
