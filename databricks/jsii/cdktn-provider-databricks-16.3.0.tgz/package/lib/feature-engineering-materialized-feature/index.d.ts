/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FeatureEngineeringMaterializedFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#cron_schedule FeatureEngineeringMaterializedFeature#cron_schedule}
    */
    readonly cronSchedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#feature_name FeatureEngineeringMaterializedFeature#feature_name}
    */
    readonly featureName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#materialized_feature_id FeatureEngineeringMaterializedFeature#materialized_feature_id}
    */
    readonly materializedFeatureId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#offline_store_config FeatureEngineeringMaterializedFeature#offline_store_config}
    */
    readonly offlineStoreConfig?: FeatureEngineeringMaterializedFeatureOfflineStoreConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#online_store_config FeatureEngineeringMaterializedFeature#online_store_config}
    */
    readonly onlineStoreConfig?: FeatureEngineeringMaterializedFeatureOnlineStoreConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#pipeline_schedule_state FeatureEngineeringMaterializedFeature#pipeline_schedule_state}
    */
    readonly pipelineScheduleState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#provider_config FeatureEngineeringMaterializedFeature#provider_config}
    */
    readonly providerConfig?: FeatureEngineeringMaterializedFeatureProviderConfig;
}
export interface FeatureEngineeringMaterializedFeatureOfflineStoreConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#catalog_name FeatureEngineeringMaterializedFeature#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#schema_name FeatureEngineeringMaterializedFeature#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#table_name_prefix FeatureEngineeringMaterializedFeature#table_name_prefix}
    */
    readonly tableNamePrefix: string;
}
export declare function featureEngineeringMaterializedFeatureOfflineStoreConfigToTerraform(struct?: FeatureEngineeringMaterializedFeatureOfflineStoreConfig | cdktn.IResolvable): any;
export declare function featureEngineeringMaterializedFeatureOfflineStoreConfigToHclTerraform(struct?: FeatureEngineeringMaterializedFeatureOfflineStoreConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringMaterializedFeatureOfflineStoreConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringMaterializedFeatureOfflineStoreConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringMaterializedFeatureOfflineStoreConfig | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    get tableNamePrefixInput(): string | undefined;
}
export interface FeatureEngineeringMaterializedFeatureOnlineStoreConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#catalog_name FeatureEngineeringMaterializedFeature#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#online_store_name FeatureEngineeringMaterializedFeature#online_store_name}
    */
    readonly onlineStoreName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#schema_name FeatureEngineeringMaterializedFeature#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#table_name_prefix FeatureEngineeringMaterializedFeature#table_name_prefix}
    */
    readonly tableNamePrefix: string;
}
export declare function featureEngineeringMaterializedFeatureOnlineStoreConfigToTerraform(struct?: FeatureEngineeringMaterializedFeatureOnlineStoreConfig | cdktn.IResolvable): any;
export declare function featureEngineeringMaterializedFeatureOnlineStoreConfigToHclTerraform(struct?: FeatureEngineeringMaterializedFeatureOnlineStoreConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringMaterializedFeatureOnlineStoreConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringMaterializedFeatureOnlineStoreConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringMaterializedFeatureOnlineStoreConfig | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _onlineStoreName?;
    get onlineStoreName(): string;
    set onlineStoreName(value: string);
    get onlineStoreNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    get tableNamePrefixInput(): string | undefined;
}
export interface FeatureEngineeringMaterializedFeatureProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#workspace_id FeatureEngineeringMaterializedFeature#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function featureEngineeringMaterializedFeatureProviderConfigToTerraform(struct?: FeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable): any;
export declare function featureEngineeringMaterializedFeatureProviderConfigToHclTerraform(struct?: FeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringMaterializedFeatureProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature databricks_feature_engineering_materialized_feature}
*/
export declare class FeatureEngineeringMaterializedFeature extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_feature_engineering_materialized_feature";
    /**
    * Generates CDKTN code for importing a FeatureEngineeringMaterializedFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FeatureEngineeringMaterializedFeature to import
    * @param importFromId The id of the existing FeatureEngineeringMaterializedFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FeatureEngineeringMaterializedFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/resources/feature_engineering_materialized_feature databricks_feature_engineering_materialized_feature} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FeatureEngineeringMaterializedFeatureConfig
    */
    constructor(scope: Construct, id: string, config: FeatureEngineeringMaterializedFeatureConfig);
    private _cronSchedule?;
    get cronSchedule(): string;
    set cronSchedule(value: string);
    resetCronSchedule(): void;
    get cronScheduleInput(): string | undefined;
    private _featureName?;
    get featureName(): string;
    set featureName(value: string);
    get featureNameInput(): string | undefined;
    get isOnline(): cdktn.IResolvable;
    get lastMaterializationTime(): string;
    private _materializedFeatureId?;
    get materializedFeatureId(): string;
    set materializedFeatureId(value: string);
    resetMaterializedFeatureId(): void;
    get materializedFeatureIdInput(): string | undefined;
    private _offlineStoreConfig;
    get offlineStoreConfig(): FeatureEngineeringMaterializedFeatureOfflineStoreConfigOutputReference;
    putOfflineStoreConfig(value: FeatureEngineeringMaterializedFeatureOfflineStoreConfig): void;
    resetOfflineStoreConfig(): void;
    get offlineStoreConfigInput(): cdktn.IResolvable | FeatureEngineeringMaterializedFeatureOfflineStoreConfig | undefined;
    private _onlineStoreConfig;
    get onlineStoreConfig(): FeatureEngineeringMaterializedFeatureOnlineStoreConfigOutputReference;
    putOnlineStoreConfig(value: FeatureEngineeringMaterializedFeatureOnlineStoreConfig): void;
    resetOnlineStoreConfig(): void;
    get onlineStoreConfigInput(): cdktn.IResolvable | FeatureEngineeringMaterializedFeatureOnlineStoreConfig | undefined;
    private _pipelineScheduleState?;
    get pipelineScheduleState(): string;
    set pipelineScheduleState(value: string);
    resetPipelineScheduleState(): void;
    get pipelineScheduleStateInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): FeatureEngineeringMaterializedFeatureProviderConfigOutputReference;
    putProviderConfig(value: FeatureEngineeringMaterializedFeatureProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | FeatureEngineeringMaterializedFeatureProviderConfig | undefined;
    get tableName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
