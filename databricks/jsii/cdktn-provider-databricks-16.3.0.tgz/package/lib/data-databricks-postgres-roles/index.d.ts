/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresRolesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#page_size DataDatabricksPostgresRoles#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#parent DataDatabricksPostgresRoles#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#provider_config DataDatabricksPostgresRoles#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresRolesProviderConfig;
}
export interface DataDatabricksPostgresRolesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#workspace_id DataDatabricksPostgresRoles#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksPostgresRolesProviderConfigToTerraform(struct?: DataDatabricksPostgresRolesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresRolesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresRolesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresRolesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRolesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresRolesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresRolesRolesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#workspace_id DataDatabricksPostgresRoles#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksPostgresRolesRolesProviderConfigToTerraform(struct?: DataDatabricksPostgresRolesRolesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresRolesRolesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresRolesRolesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresRolesRolesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRolesRolesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresRolesRolesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresRolesRolesSpecAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#bypassrls DataDatabricksPostgresRoles#bypassrls}
    */
    readonly bypassrls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#createdb DataDatabricksPostgresRoles#createdb}
    */
    readonly createdb?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#createrole DataDatabricksPostgresRoles#createrole}
    */
    readonly createrole?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresRolesRolesSpecAttributesToTerraform(struct?: DataDatabricksPostgresRolesRolesSpecAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresRolesRolesSpecAttributesToHclTerraform(struct?: DataDatabricksPostgresRolesRolesSpecAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresRolesRolesSpecAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRolesRolesSpecAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresRolesRolesSpecAttributes | cdktn.IResolvable | undefined);
    private _bypassrls?;
    get bypassrls(): boolean | cdktn.IResolvable;
    set bypassrls(value: boolean | cdktn.IResolvable);
    resetBypassrls(): void;
    get bypassrlsInput(): boolean | cdktn.IResolvable | undefined;
    private _createdb?;
    get createdb(): boolean | cdktn.IResolvable;
    set createdb(value: boolean | cdktn.IResolvable);
    resetCreatedb(): void;
    get createdbInput(): boolean | cdktn.IResolvable | undefined;
    private _createrole?;
    get createrole(): boolean | cdktn.IResolvable;
    set createrole(value: boolean | cdktn.IResolvable);
    resetCreaterole(): void;
    get createroleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksPostgresRolesRolesSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#attributes DataDatabricksPostgresRoles#attributes}
    */
    readonly attributes?: DataDatabricksPostgresRolesRolesSpecAttributes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#auth_method DataDatabricksPostgresRoles#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#identity_type DataDatabricksPostgresRoles#identity_type}
    */
    readonly identityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#membership_roles DataDatabricksPostgresRoles#membership_roles}
    */
    readonly membershipRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#postgres_role DataDatabricksPostgresRoles#postgres_role}
    */
    readonly postgresRole?: string;
}
export declare function dataDatabricksPostgresRolesRolesSpecToTerraform(struct?: DataDatabricksPostgresRolesRolesSpec): any;
export declare function dataDatabricksPostgresRolesRolesSpecToHclTerraform(struct?: DataDatabricksPostgresRolesRolesSpec): any;
export declare class DataDatabricksPostgresRolesRolesSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRolesRolesSpec | undefined;
    set internalValue(value: DataDatabricksPostgresRolesRolesSpec | undefined);
    private _attributes;
    get attributes(): DataDatabricksPostgresRolesRolesSpecAttributesOutputReference;
    putAttributes(value: DataDatabricksPostgresRolesRolesSpecAttributes): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | DataDatabricksPostgresRolesRolesSpecAttributes | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _membershipRoles?;
    get membershipRoles(): string[];
    set membershipRoles(value: string[]);
    resetMembershipRoles(): void;
    get membershipRolesInput(): string[] | undefined;
    private _postgresRole?;
    get postgresRole(): string;
    set postgresRole(value: string);
    resetPostgresRole(): void;
    get postgresRoleInput(): string | undefined;
}
export interface DataDatabricksPostgresRolesRolesStatusAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#bypassrls DataDatabricksPostgresRoles#bypassrls}
    */
    readonly bypassrls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#createdb DataDatabricksPostgresRoles#createdb}
    */
    readonly createdb?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#createrole DataDatabricksPostgresRoles#createrole}
    */
    readonly createrole?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresRolesRolesStatusAttributesToTerraform(struct?: DataDatabricksPostgresRolesRolesStatusAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresRolesRolesStatusAttributesToHclTerraform(struct?: DataDatabricksPostgresRolesRolesStatusAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresRolesRolesStatusAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRolesRolesStatusAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresRolesRolesStatusAttributes | cdktn.IResolvable | undefined);
    private _bypassrls?;
    get bypassrls(): boolean | cdktn.IResolvable;
    set bypassrls(value: boolean | cdktn.IResolvable);
    resetBypassrls(): void;
    get bypassrlsInput(): boolean | cdktn.IResolvable | undefined;
    private _createdb?;
    get createdb(): boolean | cdktn.IResolvable;
    set createdb(value: boolean | cdktn.IResolvable);
    resetCreatedb(): void;
    get createdbInput(): boolean | cdktn.IResolvable | undefined;
    private _createrole?;
    get createrole(): boolean | cdktn.IResolvable;
    set createrole(value: boolean | cdktn.IResolvable);
    resetCreaterole(): void;
    get createroleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksPostgresRolesRolesStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#attributes DataDatabricksPostgresRoles#attributes}
    */
    readonly attributes?: DataDatabricksPostgresRolesRolesStatusAttributes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#auth_method DataDatabricksPostgresRoles#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#identity_type DataDatabricksPostgresRoles#identity_type}
    */
    readonly identityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#membership_roles DataDatabricksPostgresRoles#membership_roles}
    */
    readonly membershipRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#postgres_role DataDatabricksPostgresRoles#postgres_role}
    */
    readonly postgresRole?: string;
}
export declare function dataDatabricksPostgresRolesRolesStatusToTerraform(struct?: DataDatabricksPostgresRolesRolesStatus): any;
export declare function dataDatabricksPostgresRolesRolesStatusToHclTerraform(struct?: DataDatabricksPostgresRolesRolesStatus): any;
export declare class DataDatabricksPostgresRolesRolesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRolesRolesStatus | undefined;
    set internalValue(value: DataDatabricksPostgresRolesRolesStatus | undefined);
    private _attributes;
    get attributes(): DataDatabricksPostgresRolesRolesStatusAttributesOutputReference;
    putAttributes(value: DataDatabricksPostgresRolesRolesStatusAttributes): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | DataDatabricksPostgresRolesRolesStatusAttributes | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _membershipRoles?;
    get membershipRoles(): string[];
    set membershipRoles(value: string[]);
    resetMembershipRoles(): void;
    get membershipRolesInput(): string[] | undefined;
    private _postgresRole?;
    get postgresRole(): string;
    set postgresRole(value: string);
    resetPostgresRole(): void;
    get postgresRoleInput(): string | undefined;
}
export interface DataDatabricksPostgresRolesRoles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#name DataDatabricksPostgresRoles#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#provider_config DataDatabricksPostgresRoles#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresRolesRolesProviderConfig;
}
export declare function dataDatabricksPostgresRolesRolesToTerraform(struct?: DataDatabricksPostgresRolesRoles): any;
export declare function dataDatabricksPostgresRolesRolesToHclTerraform(struct?: DataDatabricksPostgresRolesRoles): any;
export declare class DataDatabricksPostgresRolesRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresRolesRoles | undefined;
    set internalValue(value: DataDatabricksPostgresRolesRoles | undefined);
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresRolesRolesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresRolesRolesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresRolesRolesProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresRolesRolesSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresRolesRolesStatusOutputReference;
    get updateTime(): string;
}
export declare class DataDatabricksPostgresRolesRolesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresRolesRoles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresRolesRolesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles databricks_postgres_roles}
*/
export declare class DataDatabricksPostgresRoles extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_roles";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresRoles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresRoles to import
    * @param importFromId The id of the existing DataDatabricksPostgresRoles that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresRoles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.113.0/docs/data-sources/postgres_roles databricks_postgres_roles} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresRolesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresRolesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresRolesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresRolesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresRolesProviderConfig | undefined;
    private _roles;
    get roles(): DataDatabricksPostgresRolesRolesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
