/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#comment DataDatabricksShare#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#name DataDatabricksShare#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#object DataDatabricksShare#object}
    */
    readonly object?: DataDatabricksShareObject[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#owner DataDatabricksShare#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#provider_config DataDatabricksShare#provider_config}
    */
    readonly providerConfig?: DataDatabricksShareProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#storage_root DataDatabricksShare#storage_root}
    */
    readonly storageRoot?: string;
}
export interface DataDatabricksShareObjectPartitionValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#name DataDatabricksShare#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#op DataDatabricksShare#op}
    */
    readonly op?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#recipient_property_key DataDatabricksShare#recipient_property_key}
    */
    readonly recipientPropertyKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#value DataDatabricksShare#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksShareObjectPartitionValueToTerraform(struct?: DataDatabricksShareObjectPartitionValue | cdktn.IResolvable): any;
export declare function dataDatabricksShareObjectPartitionValueToHclTerraform(struct?: DataDatabricksShareObjectPartitionValue | cdktn.IResolvable): any;
export declare class DataDatabricksShareObjectPartitionValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksShareObjectPartitionValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksShareObjectPartitionValue | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    resetOp(): void;
    get opInput(): string | undefined;
    private _recipientPropertyKey?;
    get recipientPropertyKey(): string;
    set recipientPropertyKey(value: string);
    resetRecipientPropertyKey(): void;
    get recipientPropertyKeyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksShareObjectPartitionValueList extends cdktn.ComplexList {
    internalValue?: DataDatabricksShareObjectPartitionValue[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksShareObjectPartitionValueOutputReference;
}
export interface DataDatabricksShareObjectPartition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#value DataDatabricksShare#value}
    */
    readonly value?: DataDatabricksShareObjectPartitionValue[] | cdktn.IResolvable;
}
export declare function dataDatabricksShareObjectPartitionToTerraform(struct?: DataDatabricksShareObjectPartition | cdktn.IResolvable): any;
export declare function dataDatabricksShareObjectPartitionToHclTerraform(struct?: DataDatabricksShareObjectPartition | cdktn.IResolvable): any;
export declare class DataDatabricksShareObjectPartitionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksShareObjectPartition | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksShareObjectPartition | cdktn.IResolvable | undefined);
    private _value;
    get value(): DataDatabricksShareObjectPartitionValueList;
    putValue(value: DataDatabricksShareObjectPartitionValue[] | cdktn.IResolvable): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | DataDatabricksShareObjectPartitionValue[] | undefined;
}
export declare class DataDatabricksShareObjectPartitionList extends cdktn.ComplexList {
    internalValue?: DataDatabricksShareObjectPartition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksShareObjectPartitionOutputReference;
}
export interface DataDatabricksShareObject {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#cdf_enabled DataDatabricksShare#cdf_enabled}
    */
    readonly cdfEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#comment DataDatabricksShare#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#content DataDatabricksShare#content}
    */
    readonly content?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#data_object_type DataDatabricksShare#data_object_type}
    */
    readonly dataObjectType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#history_data_sharing_status DataDatabricksShare#history_data_sharing_status}
    */
    readonly historyDataSharingStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#name DataDatabricksShare#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#partition DataDatabricksShare#partition}
    */
    readonly partition?: DataDatabricksShareObjectPartition[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#shared_as DataDatabricksShare#shared_as}
    */
    readonly sharedAs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#start_version DataDatabricksShare#start_version}
    */
    readonly startVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#string_shared_as DataDatabricksShare#string_shared_as}
    */
    readonly stringSharedAs?: string;
}
export declare function dataDatabricksShareObjectToTerraform(struct?: DataDatabricksShareObject | cdktn.IResolvable): any;
export declare function dataDatabricksShareObjectToHclTerraform(struct?: DataDatabricksShareObject | cdktn.IResolvable): any;
export declare class DataDatabricksShareObjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksShareObject | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksShareObject | cdktn.IResolvable | undefined);
    get addedAt(): number;
    get addedBy(): string;
    private _cdfEnabled?;
    get cdfEnabled(): boolean | cdktn.IResolvable;
    set cdfEnabled(value: boolean | cdktn.IResolvable);
    resetCdfEnabled(): void;
    get cdfEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _dataObjectType?;
    get dataObjectType(): string;
    set dataObjectType(value: string);
    resetDataObjectType(): void;
    get dataObjectTypeInput(): string | undefined;
    get effectiveCdfEnabled(): cdktn.IResolvable;
    get effectiveHistoryDataSharingStatus(): string;
    get effectiveSharedAs(): string;
    get effectiveStartVersion(): number;
    get effectiveStringSharedAs(): string;
    private _historyDataSharingStatus?;
    get historyDataSharingStatus(): string;
    set historyDataSharingStatus(value: string);
    resetHistoryDataSharingStatus(): void;
    get historyDataSharingStatusInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partition;
    get partition(): DataDatabricksShareObjectPartitionList;
    putPartition(value: DataDatabricksShareObjectPartition[] | cdktn.IResolvable): void;
    resetPartition(): void;
    get partitionInput(): cdktn.IResolvable | DataDatabricksShareObjectPartition[] | undefined;
    private _sharedAs?;
    get sharedAs(): string;
    set sharedAs(value: string);
    resetSharedAs(): void;
    get sharedAsInput(): string | undefined;
    private _startVersion?;
    get startVersion(): number;
    set startVersion(value: number);
    resetStartVersion(): void;
    get startVersionInput(): number | undefined;
    get status(): string;
    private _stringSharedAs?;
    get stringSharedAs(): string;
    set stringSharedAs(value: string);
    resetStringSharedAs(): void;
    get stringSharedAsInput(): string | undefined;
}
export declare class DataDatabricksShareObjectList extends cdktn.ComplexList {
    internalValue?: DataDatabricksShareObject[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksShareObjectOutputReference;
}
export interface DataDatabricksShareProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#workspace_id DataDatabricksShare#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksShareProviderConfigToTerraform(struct?: DataDatabricksShareProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksShareProviderConfigToHclTerraform(struct?: DataDatabricksShareProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksShareProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksShareProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksShareProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share databricks_share}
*/
export declare class DataDatabricksShare extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_share";
    /**
    * Generates CDKTN code for importing a DataDatabricksShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksShare to import
    * @param importFromId The id of the existing DataDatabricksShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/share databricks_share} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksShareConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksShareConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdAt(): number;
    get createdBy(): string;
    get effectiveOwner(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _object;
    get object(): DataDatabricksShareObjectList;
    putObject(value: DataDatabricksShareObject[] | cdktn.IResolvable): void;
    resetObject(): void;
    get objectInput(): cdktn.IResolvable | DataDatabricksShareObject[] | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksShareProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksShareProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksShareProviderConfig | undefined;
    get storageLocation(): string;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    get updatedAt(): number;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
