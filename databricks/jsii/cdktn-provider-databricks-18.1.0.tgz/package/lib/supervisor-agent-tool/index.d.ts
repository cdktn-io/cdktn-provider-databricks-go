/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SupervisorAgentToolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#app SupervisorAgentTool#app}
    */
    readonly app?: SupervisorAgentToolApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#description SupervisorAgentTool#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#genie_space SupervisorAgentTool#genie_space}
    */
    readonly genieSpace?: SupervisorAgentToolGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#knowledge_assistant SupervisorAgentTool#knowledge_assistant}
    */
    readonly knowledgeAssistant?: SupervisorAgentToolKnowledgeAssistant;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#parent SupervisorAgentTool#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#provider_config SupervisorAgentTool#provider_config}
    */
    readonly providerConfig?: SupervisorAgentToolProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#tool_id SupervisorAgentTool#tool_id}
    */
    readonly toolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#tool_type SupervisorAgentTool#tool_type}
    */
    readonly toolType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#uc_connection SupervisorAgentTool#uc_connection}
    */
    readonly ucConnection?: SupervisorAgentToolUcConnection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#uc_function SupervisorAgentTool#uc_function}
    */
    readonly ucFunction?: SupervisorAgentToolUcFunction;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#volume SupervisorAgentTool#volume}
    */
    readonly volume?: SupervisorAgentToolVolume;
}
export interface SupervisorAgentToolApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#name SupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function supervisorAgentToolAppToTerraform(struct?: SupervisorAgentToolApp | cdktn.IResolvable): any;
export declare function supervisorAgentToolAppToHclTerraform(struct?: SupervisorAgentToolApp | cdktn.IResolvable): any;
export declare class SupervisorAgentToolAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentToolApp | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentToolApp | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface SupervisorAgentToolGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#id SupervisorAgentTool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function supervisorAgentToolGenieSpaceToTerraform(struct?: SupervisorAgentToolGenieSpace | cdktn.IResolvable): any;
export declare function supervisorAgentToolGenieSpaceToHclTerraform(struct?: SupervisorAgentToolGenieSpace | cdktn.IResolvable): any;
export declare class SupervisorAgentToolGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentToolGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentToolGenieSpace | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export interface SupervisorAgentToolKnowledgeAssistant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#knowledge_assistant_id SupervisorAgentTool#knowledge_assistant_id}
    */
    readonly knowledgeAssistantId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#serving_endpoint_name SupervisorAgentTool#serving_endpoint_name}
    */
    readonly servingEndpointName?: string;
}
export declare function supervisorAgentToolKnowledgeAssistantToTerraform(struct?: SupervisorAgentToolKnowledgeAssistant | cdktn.IResolvable): any;
export declare function supervisorAgentToolKnowledgeAssistantToHclTerraform(struct?: SupervisorAgentToolKnowledgeAssistant | cdktn.IResolvable): any;
export declare class SupervisorAgentToolKnowledgeAssistantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentToolKnowledgeAssistant | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentToolKnowledgeAssistant | cdktn.IResolvable | undefined);
    private _knowledgeAssistantId?;
    get knowledgeAssistantId(): string;
    set knowledgeAssistantId(value: string);
    get knowledgeAssistantIdInput(): string | undefined;
    private _servingEndpointName?;
    get servingEndpointName(): string;
    set servingEndpointName(value: string);
    resetServingEndpointName(): void;
    get servingEndpointNameInput(): string | undefined;
}
export interface SupervisorAgentToolProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#workspace_id SupervisorAgentTool#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function supervisorAgentToolProviderConfigToTerraform(struct?: SupervisorAgentToolProviderConfig | cdktn.IResolvable): any;
export declare function supervisorAgentToolProviderConfigToHclTerraform(struct?: SupervisorAgentToolProviderConfig | cdktn.IResolvable): any;
export declare class SupervisorAgentToolProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentToolProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentToolProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface SupervisorAgentToolUcConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#name SupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function supervisorAgentToolUcConnectionToTerraform(struct?: SupervisorAgentToolUcConnection | cdktn.IResolvable): any;
export declare function supervisorAgentToolUcConnectionToHclTerraform(struct?: SupervisorAgentToolUcConnection | cdktn.IResolvable): any;
export declare class SupervisorAgentToolUcConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentToolUcConnection | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentToolUcConnection | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface SupervisorAgentToolUcFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#name SupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function supervisorAgentToolUcFunctionToTerraform(struct?: SupervisorAgentToolUcFunction | cdktn.IResolvable): any;
export declare function supervisorAgentToolUcFunctionToHclTerraform(struct?: SupervisorAgentToolUcFunction | cdktn.IResolvable): any;
export declare class SupervisorAgentToolUcFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentToolUcFunction | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentToolUcFunction | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface SupervisorAgentToolVolume {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#name SupervisorAgentTool#name}
    */
    readonly name: string;
}
export declare function supervisorAgentToolVolumeToTerraform(struct?: SupervisorAgentToolVolume | cdktn.IResolvable): any;
export declare function supervisorAgentToolVolumeToHclTerraform(struct?: SupervisorAgentToolVolume | cdktn.IResolvable): any;
export declare class SupervisorAgentToolVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentToolVolume | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentToolVolume | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool databricks_supervisor_agent_tool}
*/
export declare class SupervisorAgentTool extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_supervisor_agent_tool";
    /**
    * Generates CDKTN code for importing a SupervisorAgentTool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SupervisorAgentTool to import
    * @param importFromId The id of the existing SupervisorAgentTool that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SupervisorAgentTool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/supervisor_agent_tool databricks_supervisor_agent_tool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SupervisorAgentToolConfig
    */
    constructor(scope: Construct, id: string, config: SupervisorAgentToolConfig);
    private _app;
    get app(): SupervisorAgentToolAppOutputReference;
    putApp(value: SupervisorAgentToolApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | SupervisorAgentToolApp | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _genieSpace;
    get genieSpace(): SupervisorAgentToolGenieSpaceOutputReference;
    putGenieSpace(value: SupervisorAgentToolGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | SupervisorAgentToolGenieSpace | undefined;
    get id(): string;
    private _knowledgeAssistant;
    get knowledgeAssistant(): SupervisorAgentToolKnowledgeAssistantOutputReference;
    putKnowledgeAssistant(value: SupervisorAgentToolKnowledgeAssistant): void;
    resetKnowledgeAssistant(): void;
    get knowledgeAssistantInput(): cdktn.IResolvable | SupervisorAgentToolKnowledgeAssistant | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): SupervisorAgentToolProviderConfigOutputReference;
    putProviderConfig(value: SupervisorAgentToolProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | SupervisorAgentToolProviderConfig | undefined;
    private _toolId?;
    get toolId(): string;
    set toolId(value: string);
    get toolIdInput(): string | undefined;
    private _toolType?;
    get toolType(): string;
    set toolType(value: string);
    get toolTypeInput(): string | undefined;
    private _ucConnection;
    get ucConnection(): SupervisorAgentToolUcConnectionOutputReference;
    putUcConnection(value: SupervisorAgentToolUcConnection): void;
    resetUcConnection(): void;
    get ucConnectionInput(): cdktn.IResolvable | SupervisorAgentToolUcConnection | undefined;
    private _ucFunction;
    get ucFunction(): SupervisorAgentToolUcFunctionOutputReference;
    putUcFunction(value: SupervisorAgentToolUcFunction): void;
    resetUcFunction(): void;
    get ucFunctionInput(): cdktn.IResolvable | SupervisorAgentToolUcFunction | undefined;
    private _volume;
    get volume(): SupervisorAgentToolVolumeOutputReference;
    putVolume(value: SupervisorAgentToolVolume): void;
    resetVolume(): void;
    get volumeInput(): cdktn.IResolvable | SupervisorAgentToolVolume | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
