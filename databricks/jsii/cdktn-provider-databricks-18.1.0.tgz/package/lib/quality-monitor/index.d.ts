/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface QualityMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#assets_dir QualityMonitor#assets_dir}
    */
    readonly assetsDir: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#baseline_table_name QualityMonitor#baseline_table_name}
    */
    readonly baselineTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#id QualityMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#latest_monitor_failure_msg QualityMonitor#latest_monitor_failure_msg}
    */
    readonly latestMonitorFailureMsg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#output_schema_name QualityMonitor#output_schema_name}
    */
    readonly outputSchemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#skip_builtin_dashboard QualityMonitor#skip_builtin_dashboard}
    */
    readonly skipBuiltinDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#slicing_exprs QualityMonitor#slicing_exprs}
    */
    readonly slicingExprs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#table_name QualityMonitor#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#warehouse_id QualityMonitor#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * custom_metrics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#custom_metrics QualityMonitor#custom_metrics}
    */
    readonly customMetrics?: QualityMonitorCustomMetrics[] | cdktn.IResolvable;
    /**
    * data_classification_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#data_classification_config QualityMonitor#data_classification_config}
    */
    readonly dataClassificationConfig?: QualityMonitorDataClassificationConfig[] | cdktn.IResolvable;
    /**
    * inference_log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#inference_log QualityMonitor#inference_log}
    */
    readonly inferenceLog?: QualityMonitorInferenceLog[] | cdktn.IResolvable;
    /**
    * notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#notifications QualityMonitor#notifications}
    */
    readonly notifications?: QualityMonitorNotifications[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#provider_config QualityMonitor#provider_config}
    */
    readonly providerConfig?: QualityMonitorProviderConfig[] | cdktn.IResolvable;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#schedule QualityMonitor#schedule}
    */
    readonly schedule?: QualityMonitorSchedule[] | cdktn.IResolvable;
    /**
    * snapshot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#snapshot QualityMonitor#snapshot}
    */
    readonly snapshot?: QualityMonitorSnapshot[] | cdktn.IResolvable;
    /**
    * time_series block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#time_series QualityMonitor#time_series}
    */
    readonly timeSeries?: QualityMonitorTimeSeries[] | cdktn.IResolvable;
}
export interface QualityMonitorCustomMetrics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#definition QualityMonitor#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#input_columns QualityMonitor#input_columns}
    */
    readonly inputColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#name QualityMonitor#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#output_data_type QualityMonitor#output_data_type}
    */
    readonly outputDataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#type QualityMonitor#type}
    */
    readonly type: string;
}
export declare function qualityMonitorCustomMetricsToTerraform(struct?: QualityMonitorCustomMetrics | cdktn.IResolvable): any;
export declare function qualityMonitorCustomMetricsToHclTerraform(struct?: QualityMonitorCustomMetrics | cdktn.IResolvable): any;
export declare class QualityMonitorCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorCustomMetrics | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _inputColumns?;
    get inputColumns(): string[];
    set inputColumns(value: string[]);
    get inputColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputDataType?;
    get outputDataType(): string;
    set outputDataType(value: string);
    get outputDataTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class QualityMonitorCustomMetricsList extends cdktn.ComplexList {
    internalValue?: QualityMonitorCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorCustomMetricsOutputReference;
}
export interface QualityMonitorDataClassificationConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#enabled QualityMonitor#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function qualityMonitorDataClassificationConfigToTerraform(struct?: QualityMonitorDataClassificationConfig | cdktn.IResolvable): any;
export declare function qualityMonitorDataClassificationConfigToHclTerraform(struct?: QualityMonitorDataClassificationConfig | cdktn.IResolvable): any;
export declare class QualityMonitorDataClassificationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorDataClassificationConfig | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorDataClassificationConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class QualityMonitorDataClassificationConfigList extends cdktn.ComplexList {
    internalValue?: QualityMonitorDataClassificationConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorDataClassificationConfigOutputReference;
}
export interface QualityMonitorInferenceLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#granularities QualityMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#label_col QualityMonitor#label_col}
    */
    readonly labelCol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#model_id_col QualityMonitor#model_id_col}
    */
    readonly modelIdCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#prediction_col QualityMonitor#prediction_col}
    */
    readonly predictionCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#prediction_proba_col QualityMonitor#prediction_proba_col}
    */
    readonly predictionProbaCol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#problem_type QualityMonitor#problem_type}
    */
    readonly problemType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#timestamp_col QualityMonitor#timestamp_col}
    */
    readonly timestampCol: string;
}
export declare function qualityMonitorInferenceLogToTerraform(struct?: QualityMonitorInferenceLog | cdktn.IResolvable): any;
export declare function qualityMonitorInferenceLogToHclTerraform(struct?: QualityMonitorInferenceLog | cdktn.IResolvable): any;
export declare class QualityMonitorInferenceLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorInferenceLog | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorInferenceLog | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _labelCol?;
    get labelCol(): string;
    set labelCol(value: string);
    resetLabelCol(): void;
    get labelColInput(): string | undefined;
    private _modelIdCol?;
    get modelIdCol(): string;
    set modelIdCol(value: string);
    get modelIdColInput(): string | undefined;
    private _predictionCol?;
    get predictionCol(): string;
    set predictionCol(value: string);
    get predictionColInput(): string | undefined;
    private _predictionProbaCol?;
    get predictionProbaCol(): string;
    set predictionProbaCol(value: string);
    resetPredictionProbaCol(): void;
    get predictionProbaColInput(): string | undefined;
    private _problemType?;
    get problemType(): string;
    set problemType(value: string);
    get problemTypeInput(): string | undefined;
    private _timestampCol?;
    get timestampCol(): string;
    set timestampCol(value: string);
    get timestampColInput(): string | undefined;
}
export declare class QualityMonitorInferenceLogList extends cdktn.ComplexList {
    internalValue?: QualityMonitorInferenceLog[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorInferenceLogOutputReference;
}
export interface QualityMonitorNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#email_addresses QualityMonitor#email_addresses}
    */
    readonly emailAddresses?: string[];
}
export declare function qualityMonitorNotificationsOnFailureToTerraform(struct?: QualityMonitorNotificationsOnFailure | cdktn.IResolvable): any;
export declare function qualityMonitorNotificationsOnFailureToHclTerraform(struct?: QualityMonitorNotificationsOnFailure | cdktn.IResolvable): any;
export declare class QualityMonitorNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
}
export declare class QualityMonitorNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: QualityMonitorNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorNotificationsOnFailureOutputReference;
}
export interface QualityMonitorNotificationsOnNewClassificationTagDetected {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#email_addresses QualityMonitor#email_addresses}
    */
    readonly emailAddresses?: string[];
}
export declare function qualityMonitorNotificationsOnNewClassificationTagDetectedToTerraform(struct?: QualityMonitorNotificationsOnNewClassificationTagDetected | cdktn.IResolvable): any;
export declare function qualityMonitorNotificationsOnNewClassificationTagDetectedToHclTerraform(struct?: QualityMonitorNotificationsOnNewClassificationTagDetected | cdktn.IResolvable): any;
export declare class QualityMonitorNotificationsOnNewClassificationTagDetectedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorNotificationsOnNewClassificationTagDetected | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorNotificationsOnNewClassificationTagDetected | cdktn.IResolvable | undefined);
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
}
export declare class QualityMonitorNotificationsOnNewClassificationTagDetectedList extends cdktn.ComplexList {
    internalValue?: QualityMonitorNotificationsOnNewClassificationTagDetected[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorNotificationsOnNewClassificationTagDetectedOutputReference;
}
export interface QualityMonitorNotifications {
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#on_failure QualityMonitor#on_failure}
    */
    readonly onFailure?: QualityMonitorNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_new_classification_tag_detected block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#on_new_classification_tag_detected QualityMonitor#on_new_classification_tag_detected}
    */
    readonly onNewClassificationTagDetected?: QualityMonitorNotificationsOnNewClassificationTagDetected[] | cdktn.IResolvable;
}
export declare function qualityMonitorNotificationsToTerraform(struct?: QualityMonitorNotifications | cdktn.IResolvable): any;
export declare function qualityMonitorNotificationsToHclTerraform(struct?: QualityMonitorNotifications | cdktn.IResolvable): any;
export declare class QualityMonitorNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorNotifications | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorNotifications | cdktn.IResolvable | undefined);
    private _onFailure;
    get onFailure(): QualityMonitorNotificationsOnFailureList;
    putOnFailure(value: QualityMonitorNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | QualityMonitorNotificationsOnFailure[] | undefined;
    private _onNewClassificationTagDetected;
    get onNewClassificationTagDetected(): QualityMonitorNotificationsOnNewClassificationTagDetectedList;
    putOnNewClassificationTagDetected(value: QualityMonitorNotificationsOnNewClassificationTagDetected[] | cdktn.IResolvable): void;
    resetOnNewClassificationTagDetected(): void;
    get onNewClassificationTagDetectedInput(): cdktn.IResolvable | QualityMonitorNotificationsOnNewClassificationTagDetected[] | undefined;
}
export declare class QualityMonitorNotificationsList extends cdktn.ComplexList {
    internalValue?: QualityMonitorNotifications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorNotificationsOutputReference;
}
export interface QualityMonitorProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#workspace_id QualityMonitor#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function qualityMonitorProviderConfigToTerraform(struct?: QualityMonitorProviderConfig | cdktn.IResolvable): any;
export declare function qualityMonitorProviderConfigToHclTerraform(struct?: QualityMonitorProviderConfig | cdktn.IResolvable): any;
export declare class QualityMonitorProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class QualityMonitorProviderConfigList extends cdktn.ComplexList {
    internalValue?: QualityMonitorProviderConfig[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorProviderConfigOutputReference;
}
export interface QualityMonitorSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#quartz_cron_expression QualityMonitor#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#timezone_id QualityMonitor#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function qualityMonitorScheduleToTerraform(struct?: QualityMonitorSchedule | cdktn.IResolvable): any;
export declare function qualityMonitorScheduleToHclTerraform(struct?: QualityMonitorSchedule | cdktn.IResolvable): any;
export declare class QualityMonitorScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorSchedule | cdktn.IResolvable | undefined);
    get pauseStatus(): string;
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export declare class QualityMonitorScheduleList extends cdktn.ComplexList {
    internalValue?: QualityMonitorSchedule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorScheduleOutputReference;
}
export interface QualityMonitorSnapshot {
}
export declare function qualityMonitorSnapshotToTerraform(struct?: QualityMonitorSnapshot | cdktn.IResolvable): any;
export declare function qualityMonitorSnapshotToHclTerraform(struct?: QualityMonitorSnapshot | cdktn.IResolvable): any;
export declare class QualityMonitorSnapshotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorSnapshot | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorSnapshot | cdktn.IResolvable | undefined);
}
export declare class QualityMonitorSnapshotList extends cdktn.ComplexList {
    internalValue?: QualityMonitorSnapshot[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorSnapshotOutputReference;
}
export interface QualityMonitorTimeSeries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#granularities QualityMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#timestamp_col QualityMonitor#timestamp_col}
    */
    readonly timestampCol: string;
}
export declare function qualityMonitorTimeSeriesToTerraform(struct?: QualityMonitorTimeSeries | cdktn.IResolvable): any;
export declare function qualityMonitorTimeSeriesToHclTerraform(struct?: QualityMonitorTimeSeries | cdktn.IResolvable): any;
export declare class QualityMonitorTimeSeriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): QualityMonitorTimeSeries | cdktn.IResolvable | undefined;
    set internalValue(value: QualityMonitorTimeSeries | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _timestampCol?;
    get timestampCol(): string;
    set timestampCol(value: string);
    get timestampColInput(): string | undefined;
}
export declare class QualityMonitorTimeSeriesList extends cdktn.ComplexList {
    internalValue?: QualityMonitorTimeSeries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): QualityMonitorTimeSeriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor databricks_quality_monitor}
*/
export declare class QualityMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_quality_monitor";
    /**
    * Generates CDKTN code for importing a QualityMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the QualityMonitor to import
    * @param importFromId The id of the existing QualityMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the QualityMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/quality_monitor databricks_quality_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options QualityMonitorConfig
    */
    constructor(scope: Construct, id: string, config: QualityMonitorConfig);
    private _assetsDir?;
    get assetsDir(): string;
    set assetsDir(value: string);
    get assetsDirInput(): string | undefined;
    private _baselineTableName?;
    get baselineTableName(): string;
    set baselineTableName(value: string);
    resetBaselineTableName(): void;
    get baselineTableNameInput(): string | undefined;
    get dashboardId(): string;
    get driftMetricsTableName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _latestMonitorFailureMsg?;
    get latestMonitorFailureMsg(): string;
    set latestMonitorFailureMsg(value: string);
    resetLatestMonitorFailureMsg(): void;
    get latestMonitorFailureMsgInput(): string | undefined;
    get monitorVersion(): number;
    private _outputSchemaName?;
    get outputSchemaName(): string;
    set outputSchemaName(value: string);
    get outputSchemaNameInput(): string | undefined;
    get profileMetricsTableName(): string;
    private _skipBuiltinDashboard?;
    get skipBuiltinDashboard(): boolean | cdktn.IResolvable;
    set skipBuiltinDashboard(value: boolean | cdktn.IResolvable);
    resetSkipBuiltinDashboard(): void;
    get skipBuiltinDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _slicingExprs?;
    get slicingExprs(): string[];
    set slicingExprs(value: string[]);
    resetSlicingExprs(): void;
    get slicingExprsInput(): string[] | undefined;
    get status(): string;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _customMetrics;
    get customMetrics(): QualityMonitorCustomMetricsList;
    putCustomMetrics(value: QualityMonitorCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | QualityMonitorCustomMetrics[] | undefined;
    private _dataClassificationConfig;
    get dataClassificationConfig(): QualityMonitorDataClassificationConfigList;
    putDataClassificationConfig(value: QualityMonitorDataClassificationConfig[] | cdktn.IResolvable): void;
    resetDataClassificationConfig(): void;
    get dataClassificationConfigInput(): cdktn.IResolvable | QualityMonitorDataClassificationConfig[] | undefined;
    private _inferenceLog;
    get inferenceLog(): QualityMonitorInferenceLogList;
    putInferenceLog(value: QualityMonitorInferenceLog[] | cdktn.IResolvable): void;
    resetInferenceLog(): void;
    get inferenceLogInput(): cdktn.IResolvable | QualityMonitorInferenceLog[] | undefined;
    private _notifications;
    get notifications(): QualityMonitorNotificationsList;
    putNotifications(value: QualityMonitorNotifications[] | cdktn.IResolvable): void;
    resetNotifications(): void;
    get notificationsInput(): cdktn.IResolvable | QualityMonitorNotifications[] | undefined;
    private _providerConfig;
    get providerConfig(): QualityMonitorProviderConfigList;
    putProviderConfig(value: QualityMonitorProviderConfig[] | cdktn.IResolvable): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | QualityMonitorProviderConfig[] | undefined;
    private _schedule;
    get schedule(): QualityMonitorScheduleList;
    putSchedule(value: QualityMonitorSchedule[] | cdktn.IResolvable): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | QualityMonitorSchedule[] | undefined;
    private _snapshot;
    get snapshot(): QualityMonitorSnapshotList;
    putSnapshot(value: QualityMonitorSnapshot[] | cdktn.IResolvable): void;
    resetSnapshot(): void;
    get snapshotInput(): cdktn.IResolvable | QualityMonitorSnapshot[] | undefined;
    private _timeSeries;
    get timeSeries(): QualityMonitorTimeSeriesList;
    putTimeSeries(value: QualityMonitorTimeSeries[] | cdktn.IResolvable): void;
    resetTimeSeries(): void;
    get timeSeriesInput(): cdktn.IResolvable | QualityMonitorTimeSeries[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
