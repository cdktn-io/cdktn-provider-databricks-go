/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#provider_config DataDatabricksApp#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppProviderConfig;
}
export interface DataDatabricksAppAppActiveDeploymentDeploymentArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#source_code_path DataDatabricksApp#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppAppActiveDeploymentDeploymentArtifactsToTerraform(struct?: DataDatabricksAppAppActiveDeploymentDeploymentArtifacts): any;
export declare function dataDatabricksAppAppActiveDeploymentDeploymentArtifactsToHclTerraform(struct?: DataDatabricksAppAppActiveDeploymentDeploymentArtifacts): any;
export declare class DataDatabricksAppAppActiveDeploymentDeploymentArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppActiveDeploymentDeploymentArtifacts | undefined;
    set internalValue(value: DataDatabricksAppAppActiveDeploymentDeploymentArtifacts | undefined);
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
}
export interface DataDatabricksAppAppActiveDeploymentEnvVars {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#value DataDatabricksApp#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#value_from DataDatabricksApp#value_from}
    */
    readonly valueFrom?: string;
}
export declare function dataDatabricksAppAppActiveDeploymentEnvVarsToTerraform(struct?: DataDatabricksAppAppActiveDeploymentEnvVars | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppActiveDeploymentEnvVarsToHclTerraform(struct?: DataDatabricksAppAppActiveDeploymentEnvVars | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppActiveDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppAppActiveDeploymentEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppActiveDeploymentEnvVars | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class DataDatabricksAppAppActiveDeploymentEnvVarsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppAppActiveDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppAppActiveDeploymentEnvVarsOutputReference;
}
export interface DataDatabricksAppAppActiveDeploymentGitSourceGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#provider DataDatabricksApp#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#url DataDatabricksApp#url}
    */
    readonly url: string;
}
export declare function dataDatabricksAppAppActiveDeploymentGitSourceGitRepositoryToTerraform(struct?: DataDatabricksAppAppActiveDeploymentGitSourceGitRepository): any;
export declare function dataDatabricksAppAppActiveDeploymentGitSourceGitRepositoryToHclTerraform(struct?: DataDatabricksAppAppActiveDeploymentGitSourceGitRepository): any;
export declare class DataDatabricksAppAppActiveDeploymentGitSourceGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppActiveDeploymentGitSourceGitRepository | undefined;
    set internalValue(value: DataDatabricksAppAppActiveDeploymentGitSourceGitRepository | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface DataDatabricksAppAppActiveDeploymentGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#branch DataDatabricksApp#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#commit DataDatabricksApp#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#source_code_path DataDatabricksApp#source_code_path}
    */
    readonly sourceCodePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#tag DataDatabricksApp#tag}
    */
    readonly tag?: string;
}
export declare function dataDatabricksAppAppActiveDeploymentGitSourceToTerraform(struct?: DataDatabricksAppAppActiveDeploymentGitSource | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppActiveDeploymentGitSourceToHclTerraform(struct?: DataDatabricksAppAppActiveDeploymentGitSource | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppActiveDeploymentGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppActiveDeploymentGitSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppActiveDeploymentGitSource | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _gitRepository;
    get gitRepository(): DataDatabricksAppAppActiveDeploymentGitSourceGitRepositoryOutputReference;
    get resolvedCommit(): string;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface DataDatabricksAppAppActiveDeploymentStatus {
}
export declare function dataDatabricksAppAppActiveDeploymentStatusToTerraform(struct?: DataDatabricksAppAppActiveDeploymentStatus): any;
export declare function dataDatabricksAppAppActiveDeploymentStatusToHclTerraform(struct?: DataDatabricksAppAppActiveDeploymentStatus): any;
export declare class DataDatabricksAppAppActiveDeploymentStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppActiveDeploymentStatus | undefined;
    set internalValue(value: DataDatabricksAppAppActiveDeploymentStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppAppActiveDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#command DataDatabricksApp#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#deployment_id DataDatabricksApp#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#env_vars DataDatabricksApp#env_vars}
    */
    readonly envVars?: DataDatabricksAppAppActiveDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#git_source DataDatabricksApp#git_source}
    */
    readonly gitSource?: DataDatabricksAppAppActiveDeploymentGitSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#mode DataDatabricksApp#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#source_code_path DataDatabricksApp#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppAppActiveDeploymentToTerraform(struct?: DataDatabricksAppAppActiveDeployment): any;
export declare function dataDatabricksAppAppActiveDeploymentToHclTerraform(struct?: DataDatabricksAppAppActiveDeployment): any;
export declare class DataDatabricksAppAppActiveDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppActiveDeployment | undefined;
    set internalValue(value: DataDatabricksAppAppActiveDeployment | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    get createTime(): string;
    get creator(): string;
    private _deploymentArtifacts;
    get deploymentArtifacts(): DataDatabricksAppAppActiveDeploymentDeploymentArtifactsOutputReference;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _envVars;
    get envVars(): DataDatabricksAppAppActiveDeploymentEnvVarsList;
    putEnvVars(value: DataDatabricksAppAppActiveDeploymentEnvVars[] | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | DataDatabricksAppAppActiveDeploymentEnvVars[] | undefined;
    private _gitSource;
    get gitSource(): DataDatabricksAppAppActiveDeploymentGitSourceOutputReference;
    putGitSource(value: DataDatabricksAppAppActiveDeploymentGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): cdktn.IResolvable | DataDatabricksAppAppActiveDeploymentGitSource | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _status;
    get status(): DataDatabricksAppAppActiveDeploymentStatusOutputReference;
    get updateTime(): string;
}
export interface DataDatabricksAppAppAppStatus {
}
export declare function dataDatabricksAppAppAppStatusToTerraform(struct?: DataDatabricksAppAppAppStatus): any;
export declare function dataDatabricksAppAppAppStatusToHclTerraform(struct?: DataDatabricksAppAppAppStatus): any;
export declare class DataDatabricksAppAppAppStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppAppStatus | undefined;
    set internalValue(value: DataDatabricksAppAppAppStatus | undefined);
    get message(): string;
    get runningInstances(): number;
    get state(): string;
}
export interface DataDatabricksAppAppComputeStatus {
}
export declare function dataDatabricksAppAppComputeStatusToTerraform(struct?: DataDatabricksAppAppComputeStatus): any;
export declare function dataDatabricksAppAppComputeStatusToHclTerraform(struct?: DataDatabricksAppAppComputeStatus): any;
export declare class DataDatabricksAppAppComputeStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppComputeStatus | undefined;
    set internalValue(value: DataDatabricksAppAppComputeStatus | undefined);
    get activeInstances(): number;
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppAppGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#provider DataDatabricksApp#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#url DataDatabricksApp#url}
    */
    readonly url: string;
}
export declare function dataDatabricksAppAppGitRepositoryToTerraform(struct?: DataDatabricksAppAppGitRepository | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppGitRepositoryToHclTerraform(struct?: DataDatabricksAppAppGitRepository | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppGitRepository | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppGitRepository | cdktn.IResolvable | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface DataDatabricksAppAppPendingDeploymentDeploymentArtifacts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#source_code_path DataDatabricksApp#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppAppPendingDeploymentDeploymentArtifactsToTerraform(struct?: DataDatabricksAppAppPendingDeploymentDeploymentArtifacts): any;
export declare function dataDatabricksAppAppPendingDeploymentDeploymentArtifactsToHclTerraform(struct?: DataDatabricksAppAppPendingDeploymentDeploymentArtifacts): any;
export declare class DataDatabricksAppAppPendingDeploymentDeploymentArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppPendingDeploymentDeploymentArtifacts | undefined;
    set internalValue(value: DataDatabricksAppAppPendingDeploymentDeploymentArtifacts | undefined);
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
}
export interface DataDatabricksAppAppPendingDeploymentEnvVars {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#value DataDatabricksApp#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#value_from DataDatabricksApp#value_from}
    */
    readonly valueFrom?: string;
}
export declare function dataDatabricksAppAppPendingDeploymentEnvVarsToTerraform(struct?: DataDatabricksAppAppPendingDeploymentEnvVars | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppPendingDeploymentEnvVarsToHclTerraform(struct?: DataDatabricksAppAppPendingDeploymentEnvVars | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppPendingDeploymentEnvVarsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppAppPendingDeploymentEnvVars | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppPendingDeploymentEnvVars | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valueFrom?;
    get valueFrom(): string;
    set valueFrom(value: string);
    resetValueFrom(): void;
    get valueFromInput(): string | undefined;
}
export declare class DataDatabricksAppAppPendingDeploymentEnvVarsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppAppPendingDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppAppPendingDeploymentEnvVarsOutputReference;
}
export interface DataDatabricksAppAppPendingDeploymentGitSourceGitRepository {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#provider DataDatabricksApp#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#url DataDatabricksApp#url}
    */
    readonly url: string;
}
export declare function dataDatabricksAppAppPendingDeploymentGitSourceGitRepositoryToTerraform(struct?: DataDatabricksAppAppPendingDeploymentGitSourceGitRepository): any;
export declare function dataDatabricksAppAppPendingDeploymentGitSourceGitRepositoryToHclTerraform(struct?: DataDatabricksAppAppPendingDeploymentGitSourceGitRepository): any;
export declare class DataDatabricksAppAppPendingDeploymentGitSourceGitRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppPendingDeploymentGitSourceGitRepository | undefined;
    set internalValue(value: DataDatabricksAppAppPendingDeploymentGitSourceGitRepository | undefined);
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface DataDatabricksAppAppPendingDeploymentGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#branch DataDatabricksApp#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#commit DataDatabricksApp#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#source_code_path DataDatabricksApp#source_code_path}
    */
    readonly sourceCodePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#tag DataDatabricksApp#tag}
    */
    readonly tag?: string;
}
export declare function dataDatabricksAppAppPendingDeploymentGitSourceToTerraform(struct?: DataDatabricksAppAppPendingDeploymentGitSource | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppPendingDeploymentGitSourceToHclTerraform(struct?: DataDatabricksAppAppPendingDeploymentGitSource | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppPendingDeploymentGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppPendingDeploymentGitSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppPendingDeploymentGitSource | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _gitRepository;
    get gitRepository(): DataDatabricksAppAppPendingDeploymentGitSourceGitRepositoryOutputReference;
    get resolvedCommit(): string;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
}
export interface DataDatabricksAppAppPendingDeploymentStatus {
}
export declare function dataDatabricksAppAppPendingDeploymentStatusToTerraform(struct?: DataDatabricksAppAppPendingDeploymentStatus): any;
export declare function dataDatabricksAppAppPendingDeploymentStatusToHclTerraform(struct?: DataDatabricksAppAppPendingDeploymentStatus): any;
export declare class DataDatabricksAppAppPendingDeploymentStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppPendingDeploymentStatus | undefined;
    set internalValue(value: DataDatabricksAppAppPendingDeploymentStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAppAppPendingDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#command DataDatabricksApp#command}
    */
    readonly command?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#deployment_id DataDatabricksApp#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#env_vars DataDatabricksApp#env_vars}
    */
    readonly envVars?: DataDatabricksAppAppPendingDeploymentEnvVars[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#git_source DataDatabricksApp#git_source}
    */
    readonly gitSource?: DataDatabricksAppAppPendingDeploymentGitSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#mode DataDatabricksApp#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#source_code_path DataDatabricksApp#source_code_path}
    */
    readonly sourceCodePath?: string;
}
export declare function dataDatabricksAppAppPendingDeploymentToTerraform(struct?: DataDatabricksAppAppPendingDeployment): any;
export declare function dataDatabricksAppAppPendingDeploymentToHclTerraform(struct?: DataDatabricksAppAppPendingDeployment): any;
export declare class DataDatabricksAppAppPendingDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppPendingDeployment | undefined;
    set internalValue(value: DataDatabricksAppAppPendingDeployment | undefined);
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    get createTime(): string;
    get creator(): string;
    private _deploymentArtifacts;
    get deploymentArtifacts(): DataDatabricksAppAppPendingDeploymentDeploymentArtifactsOutputReference;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _envVars;
    get envVars(): DataDatabricksAppAppPendingDeploymentEnvVarsList;
    putEnvVars(value: DataDatabricksAppAppPendingDeploymentEnvVars[] | cdktn.IResolvable): void;
    resetEnvVars(): void;
    get envVarsInput(): cdktn.IResolvable | DataDatabricksAppAppPendingDeploymentEnvVars[] | undefined;
    private _gitSource;
    get gitSource(): DataDatabricksAppAppPendingDeploymentGitSourceOutputReference;
    putGitSource(value: DataDatabricksAppAppPendingDeploymentGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): cdktn.IResolvable | DataDatabricksAppAppPendingDeploymentGitSource | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _sourceCodePath?;
    get sourceCodePath(): string;
    set sourceCodePath(value: string);
    resetSourceCodePath(): void;
    get sourceCodePathInput(): string | undefined;
    private _status;
    get status(): DataDatabricksAppAppPendingDeploymentStatusOutputReference;
    get updateTime(): string;
}
export interface DataDatabricksAppAppResourcesApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission?: string;
}
export declare function dataDatabricksAppAppResourcesAppToTerraform(struct?: DataDatabricksAppAppResourcesApp | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesAppToHclTerraform(struct?: DataDatabricksAppAppResourcesApp | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesApp | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#database_name DataDatabricksApp#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#instance_name DataDatabricksApp#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppAppResourcesDatabaseToTerraform(struct?: DataDatabricksAppAppResourcesDatabase | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesDatabaseToHclTerraform(struct?: DataDatabricksAppAppResourcesDatabase | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#experiment_id DataDatabricksApp#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppAppResourcesExperimentToTerraform(struct?: DataDatabricksAppAppResourcesExperiment | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesExperimentToHclTerraform(struct?: DataDatabricksAppAppResourcesExperiment | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#space_id DataDatabricksApp#space_id}
    */
    readonly spaceId: string;
}
export declare function dataDatabricksAppAppResourcesGenieSpaceToTerraform(struct?: DataDatabricksAppAppResourcesGenieSpace | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesGenieSpaceToHclTerraform(struct?: DataDatabricksAppAppResourcesGenieSpace | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#id DataDatabricksApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppAppResourcesJobToTerraform(struct?: DataDatabricksAppAppResourcesJob | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesJobToHclTerraform(struct?: DataDatabricksAppAppResourcesJob | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesPostgres {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#branch DataDatabricksApp#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#database DataDatabricksApp#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission?: string;
}
export declare function dataDatabricksAppAppResourcesPostgresToTerraform(struct?: DataDatabricksAppAppResourcesPostgres | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesPostgresToHclTerraform(struct?: DataDatabricksAppAppResourcesPostgres | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesPostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesPostgres | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesPostgres | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#key DataDatabricksApp#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#scope DataDatabricksApp#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksAppAppResourcesSecretToTerraform(struct?: DataDatabricksAppAppResourcesSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesSecretToHclTerraform(struct?: DataDatabricksAppAppResourcesSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppAppResourcesServingEndpointToTerraform(struct?: DataDatabricksAppAppResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesServingEndpointToHclTerraform(struct?: DataDatabricksAppAppResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#id DataDatabricksApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppAppResourcesSqlWarehouseToTerraform(struct?: DataDatabricksAppAppResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesSqlWarehouseToHclTerraform(struct?: DataDatabricksAppAppResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppAppResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#permission DataDatabricksApp#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#securable_full_name DataDatabricksApp#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#securable_type DataDatabricksApp#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppAppResourcesUcSecurableToTerraform(struct?: DataDatabricksAppAppResourcesUcSecurable | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesUcSecurableToHclTerraform(struct?: DataDatabricksAppAppResourcesUcSecurable | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppAppResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#app DataDatabricksApp#app}
    */
    readonly app?: DataDatabricksAppAppResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#database DataDatabricksApp#database}
    */
    readonly database?: DataDatabricksAppAppResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#description DataDatabricksApp#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#experiment DataDatabricksApp#experiment}
    */
    readonly experiment?: DataDatabricksAppAppResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#genie_space DataDatabricksApp#genie_space}
    */
    readonly genieSpace?: DataDatabricksAppAppResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#job DataDatabricksApp#job}
    */
    readonly job?: DataDatabricksAppAppResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#postgres DataDatabricksApp#postgres}
    */
    readonly postgres?: DataDatabricksAppAppResourcesPostgres;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#secret DataDatabricksApp#secret}
    */
    readonly secret?: DataDatabricksAppAppResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#serving_endpoint DataDatabricksApp#serving_endpoint}
    */
    readonly servingEndpoint?: DataDatabricksAppAppResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#sql_warehouse DataDatabricksApp#sql_warehouse}
    */
    readonly sqlWarehouse?: DataDatabricksAppAppResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#uc_securable DataDatabricksApp#uc_securable}
    */
    readonly ucSecurable?: DataDatabricksAppAppResourcesUcSecurable;
}
export declare function dataDatabricksAppAppResourcesToTerraform(struct?: DataDatabricksAppAppResources | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppResourcesToHclTerraform(struct?: DataDatabricksAppAppResources | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppAppResources | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppResources | cdktn.IResolvable | undefined);
    private _app;
    get app(): DataDatabricksAppAppResourcesAppOutputReference;
    putApp(value: DataDatabricksAppAppResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesApp | undefined;
    private _database;
    get database(): DataDatabricksAppAppResourcesDatabaseOutputReference;
    putDatabase(value: DataDatabricksAppAppResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): DataDatabricksAppAppResourcesExperimentOutputReference;
    putExperiment(value: DataDatabricksAppAppResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): DataDatabricksAppAppResourcesGenieSpaceOutputReference;
    putGenieSpace(value: DataDatabricksAppAppResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesGenieSpace | undefined;
    private _job;
    get job(): DataDatabricksAppAppResourcesJobOutputReference;
    putJob(value: DataDatabricksAppAppResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _postgres;
    get postgres(): DataDatabricksAppAppResourcesPostgresOutputReference;
    putPostgres(value: DataDatabricksAppAppResourcesPostgres): void;
    resetPostgres(): void;
    get postgresInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesPostgres | undefined;
    private _secret;
    get secret(): DataDatabricksAppAppResourcesSecretOutputReference;
    putSecret(value: DataDatabricksAppAppResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): DataDatabricksAppAppResourcesServingEndpointOutputReference;
    putServingEndpoint(value: DataDatabricksAppAppResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): DataDatabricksAppAppResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: DataDatabricksAppAppResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): DataDatabricksAppAppResourcesUcSecurableOutputReference;
    putUcSecurable(value: DataDatabricksAppAppResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | DataDatabricksAppAppResourcesUcSecurable | undefined;
}
export declare class DataDatabricksAppAppResourcesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppAppResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppAppResourcesOutputReference;
}
export interface DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#logs_table DataDatabricksApp#logs_table}
    */
    readonly logsTable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#metrics_table DataDatabricksApp#metrics_table}
    */
    readonly metricsTable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#traces_table DataDatabricksApp#traces_table}
    */
    readonly tracesTable: string;
}
export declare function dataDatabricksAppAppTelemetryExportDestinationsUnityCatalogToTerraform(struct?: DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppTelemetryExportDestinationsUnityCatalogToHclTerraform(struct?: DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppTelemetryExportDestinationsUnityCatalogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog | cdktn.IResolvable | undefined);
    private _logsTable?;
    get logsTable(): string;
    set logsTable(value: string);
    get logsTableInput(): string | undefined;
    private _metricsTable?;
    get metricsTable(): string;
    set metricsTable(value: string);
    get metricsTableInput(): string | undefined;
    private _tracesTable?;
    get tracesTable(): string;
    set tracesTable(value: string);
    get tracesTableInput(): string | undefined;
}
export interface DataDatabricksAppAppTelemetryExportDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#unity_catalog DataDatabricksApp#unity_catalog}
    */
    readonly unityCatalog?: DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog;
}
export declare function dataDatabricksAppAppTelemetryExportDestinationsToTerraform(struct?: DataDatabricksAppAppTelemetryExportDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAppAppTelemetryExportDestinationsToHclTerraform(struct?: DataDatabricksAppAppTelemetryExportDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAppAppTelemetryExportDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppAppTelemetryExportDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppAppTelemetryExportDestinations | cdktn.IResolvable | undefined);
    private _unityCatalog;
    get unityCatalog(): DataDatabricksAppAppTelemetryExportDestinationsUnityCatalogOutputReference;
    putUnityCatalog(value: DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog): void;
    resetUnityCatalog(): void;
    get unityCatalogInput(): cdktn.IResolvable | DataDatabricksAppAppTelemetryExportDestinationsUnityCatalog | undefined;
}
export declare class DataDatabricksAppAppTelemetryExportDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAppAppTelemetryExportDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppAppTelemetryExportDestinationsOutputReference;
}
export interface DataDatabricksAppApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#budget_policy_id DataDatabricksApp#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#compute_max_instances DataDatabricksApp#compute_max_instances}
    */
    readonly computeMaxInstances?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#compute_min_instances DataDatabricksApp#compute_min_instances}
    */
    readonly computeMinInstances?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#compute_size DataDatabricksApp#compute_size}
    */
    readonly computeSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#description DataDatabricksApp#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#git_repository DataDatabricksApp#git_repository}
    */
    readonly gitRepository?: DataDatabricksAppAppGitRepository;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#name DataDatabricksApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#resources DataDatabricksApp#resources}
    */
    readonly resources?: DataDatabricksAppAppResources[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#space DataDatabricksApp#space}
    */
    readonly space?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#telemetry_export_destinations DataDatabricksApp#telemetry_export_destinations}
    */
    readonly telemetryExportDestinations?: DataDatabricksAppAppTelemetryExportDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#usage_policy_id DataDatabricksApp#usage_policy_id}
    */
    readonly usagePolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#user_api_scopes DataDatabricksApp#user_api_scopes}
    */
    readonly userApiScopes?: string[];
}
export declare function dataDatabricksAppAppToTerraform(struct?: DataDatabricksAppApp): any;
export declare function dataDatabricksAppAppToHclTerraform(struct?: DataDatabricksAppApp): any;
export declare class DataDatabricksAppAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppApp | undefined;
    set internalValue(value: DataDatabricksAppApp | undefined);
    private _activeDeployment;
    get activeDeployment(): DataDatabricksAppAppActiveDeploymentOutputReference;
    private _appStatus;
    get appStatus(): DataDatabricksAppAppAppStatusOutputReference;
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _computeMaxInstances?;
    get computeMaxInstances(): number;
    set computeMaxInstances(value: number);
    resetComputeMaxInstances(): void;
    get computeMaxInstancesInput(): number | undefined;
    private _computeMinInstances?;
    get computeMinInstances(): number;
    set computeMinInstances(value: number);
    resetComputeMinInstances(): void;
    get computeMinInstancesInput(): number | undefined;
    private _computeSize?;
    get computeSize(): string;
    set computeSize(value: string);
    resetComputeSize(): void;
    get computeSizeInput(): string | undefined;
    private _computeStatus;
    get computeStatus(): DataDatabricksAppAppComputeStatusOutputReference;
    get createTime(): string;
    get creator(): string;
    get defaultSourceCodePath(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveBudgetPolicyId(): string;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    private _gitRepository;
    get gitRepository(): DataDatabricksAppAppGitRepositoryOutputReference;
    putGitRepository(value: DataDatabricksAppAppGitRepository): void;
    resetGitRepository(): void;
    get gitRepositoryInput(): cdktn.IResolvable | DataDatabricksAppAppGitRepository | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get oauth2AppClientId(): string;
    get oauth2AppIntegrationId(): string;
    private _pendingDeployment;
    get pendingDeployment(): DataDatabricksAppAppPendingDeploymentOutputReference;
    private _resources;
    get resources(): DataDatabricksAppAppResourcesList;
    putResources(value: DataDatabricksAppAppResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | DataDatabricksAppAppResources[] | undefined;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _space?;
    get space(): string;
    set space(value: string);
    resetSpace(): void;
    get spaceInput(): string | undefined;
    private _telemetryExportDestinations;
    get telemetryExportDestinations(): DataDatabricksAppAppTelemetryExportDestinationsList;
    putTelemetryExportDestinations(value: DataDatabricksAppAppTelemetryExportDestinations[] | cdktn.IResolvable): void;
    resetTelemetryExportDestinations(): void;
    get telemetryExportDestinationsInput(): cdktn.IResolvable | DataDatabricksAppAppTelemetryExportDestinations[] | undefined;
    get thumbnailUrl(): string;
    get updateTime(): string;
    get updater(): string;
    get url(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    private _userApiScopes?;
    get userApiScopes(): string[];
    set userApiScopes(value: string[]);
    resetUserApiScopes(): void;
    get userApiScopesInput(): string[] | undefined;
}
export interface DataDatabricksAppProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#workspace_id DataDatabricksApp#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAppProviderConfigToTerraform(struct?: DataDatabricksAppProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppProviderConfigToHclTerraform(struct?: DataDatabricksAppProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app databricks_app}
*/
export declare class DataDatabricksApp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_app";
    /**
    * Generates CDKTN code for importing a DataDatabricksApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksApp to import
    * @param importFromId The id of the existing DataDatabricksApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/app databricks_app} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAppConfig);
    private _app;
    get app(): DataDatabricksAppAppOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
