/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EntityTagAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment#entity_name EntityTagAssignment#entity_name}
    */
    readonly entityName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment#entity_type EntityTagAssignment#entity_type}
    */
    readonly entityType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment#provider_config EntityTagAssignment#provider_config}
    */
    readonly providerConfig?: EntityTagAssignmentProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment#tag_key EntityTagAssignment#tag_key}
    */
    readonly tagKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment#tag_value EntityTagAssignment#tag_value}
    */
    readonly tagValue?: string;
}
export interface EntityTagAssignmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment#workspace_id EntityTagAssignment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function entityTagAssignmentProviderConfigToTerraform(struct?: EntityTagAssignmentProviderConfig | cdktn.IResolvable): any;
export declare function entityTagAssignmentProviderConfigToHclTerraform(struct?: EntityTagAssignmentProviderConfig | cdktn.IResolvable): any;
export declare class EntityTagAssignmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EntityTagAssignmentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: EntityTagAssignmentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment databricks_entity_tag_assignment}
*/
export declare class EntityTagAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_entity_tag_assignment";
    /**
    * Generates CDKTN code for importing a EntityTagAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EntityTagAssignment to import
    * @param importFromId The id of the existing EntityTagAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EntityTagAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/entity_tag_assignment databricks_entity_tag_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EntityTagAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: EntityTagAssignmentConfig);
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    get entityNameInput(): string | undefined;
    private _entityType?;
    get entityType(): string;
    set entityType(value: string);
    get entityTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): EntityTagAssignmentProviderConfigOutputReference;
    putProviderConfig(value: EntityTagAssignmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | EntityTagAssignmentProviderConfig | undefined;
    get sourceType(): string;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    private _tagValue?;
    get tagValue(): string;
    set tagValue(value: string);
    resetTagValue(): void;
    get tagValueInput(): string | undefined;
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
