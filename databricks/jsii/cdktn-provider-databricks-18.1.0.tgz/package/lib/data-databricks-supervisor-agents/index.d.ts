/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSupervisorAgentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents#page_size DataDatabricksSupervisorAgents#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents#provider_config DataDatabricksSupervisorAgents#provider_config}
    */
    readonly providerConfig?: DataDatabricksSupervisorAgentsProviderConfig;
}
export interface DataDatabricksSupervisorAgentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents#workspace_id DataDatabricksSupervisorAgents#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSupervisorAgentsProviderConfigToTerraform(struct?: DataDatabricksSupervisorAgentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSupervisorAgentsProviderConfigToHclTerraform(struct?: DataDatabricksSupervisorAgentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSupervisorAgentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents#workspace_id DataDatabricksSupervisorAgents#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSupervisorAgentsSupervisorAgentsProviderConfigToTerraform(struct?: DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSupervisorAgentsSupervisorAgentsProviderConfigToHclTerraform(struct?: DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSupervisorAgentsSupervisorAgents {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents#name DataDatabricksSupervisorAgents#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents#provider_config DataDatabricksSupervisorAgents#provider_config}
    */
    readonly providerConfig?: DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig;
}
export declare function dataDatabricksSupervisorAgentsSupervisorAgentsToTerraform(struct?: DataDatabricksSupervisorAgentsSupervisorAgents): any;
export declare function dataDatabricksSupervisorAgentsSupervisorAgentsToHclTerraform(struct?: DataDatabricksSupervisorAgentsSupervisorAgents): any;
export declare class DataDatabricksSupervisorAgentsSupervisorAgentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksSupervisorAgentsSupervisorAgents | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentsSupervisorAgents | undefined);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get displayName(): string;
    get endpointName(): string;
    get experimentId(): string;
    get id(): string;
    get instructions(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSupervisorAgentsSupervisorAgentsProviderConfig | undefined;
    get supervisorAgentId(): string;
}
export declare class DataDatabricksSupervisorAgentsSupervisorAgentsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksSupervisorAgentsSupervisorAgents[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksSupervisorAgentsSupervisorAgentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents databricks_supervisor_agents}
*/
export declare class DataDatabricksSupervisorAgents extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_supervisor_agents";
    /**
    * Generates CDKTN code for importing a DataDatabricksSupervisorAgents resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSupervisorAgents to import
    * @param importFromId The id of the existing DataDatabricksSupervisorAgents that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSupervisorAgents to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/supervisor_agents databricks_supervisor_agents} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSupervisorAgentsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksSupervisorAgentsConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSupervisorAgentsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSupervisorAgentsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSupervisorAgentsProviderConfig | undefined;
    private _supervisorAgents;
    get supervisorAgents(): DataDatabricksSupervisorAgentsSupervisorAgentsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
