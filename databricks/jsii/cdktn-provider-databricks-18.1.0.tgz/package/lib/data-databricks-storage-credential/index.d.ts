/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksStorageCredentialConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#id DataDatabricksStorageCredential#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#name DataDatabricksStorageCredential#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#provider_config DataDatabricksStorageCredential#provider_config}
    */
    readonly providerConfig?: DataDatabricksStorageCredentialProviderConfig;
    /**
    * storage_credential_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#storage_credential_info DataDatabricksStorageCredential#storage_credential_info}
    */
    readonly storageCredentialInfo?: DataDatabricksStorageCredentialStorageCredentialInfo;
}
export interface DataDatabricksStorageCredentialProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#workspace_id DataDatabricksStorageCredential#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksStorageCredentialProviderConfigToTerraform(struct?: DataDatabricksStorageCredentialProviderConfigOutputReference | DataDatabricksStorageCredentialProviderConfig): any;
export declare function dataDatabricksStorageCredentialProviderConfigToHclTerraform(struct?: DataDatabricksStorageCredentialProviderConfigOutputReference | DataDatabricksStorageCredentialProviderConfig): any;
export declare class DataDatabricksStorageCredentialProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialProviderConfig | undefined;
    set internalValue(value: DataDatabricksStorageCredentialProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#external_id DataDatabricksStorageCredential#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#role_arn DataDatabricksStorageCredential#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#unity_catalog_iam_arn DataDatabricksStorageCredential#unity_catalog_iam_arn}
    */
    readonly unityCatalogIamArn?: string;
}
export declare function dataDatabricksStorageCredentialStorageCredentialInfoAwsIamRoleToTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRoleOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole): any;
export declare function dataDatabricksStorageCredentialStorageCredentialInfoAwsIamRoleToHclTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRoleOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole): any;
export declare class DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRoleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole | undefined;
    set internalValue(value: DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole | undefined);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _unityCatalogIamArn?;
    get unityCatalogIamArn(): string;
    set unityCatalogIamArn(value: string);
    resetUnityCatalogIamArn(): void;
    get unityCatalogIamArnInput(): string | undefined;
}
export interface DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#access_connector_id DataDatabricksStorageCredential#access_connector_id}
    */
    readonly accessConnectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#credential_id DataDatabricksStorageCredential#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#managed_identity_id DataDatabricksStorageCredential#managed_identity_id}
    */
    readonly managedIdentityId?: string;
}
export declare function dataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentityToTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentityOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity): any;
export declare function dataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentityToHclTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentityOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity): any;
export declare class DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity | undefined;
    set internalValue(value: DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity | undefined);
    private _accessConnectorId?;
    get accessConnectorId(): string;
    set accessConnectorId(value: string);
    get accessConnectorIdInput(): string | undefined;
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _managedIdentityId?;
    get managedIdentityId(): string;
    set managedIdentityId(value: string);
    resetManagedIdentityId(): void;
    get managedIdentityIdInput(): string | undefined;
}
export interface DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#application_id DataDatabricksStorageCredential#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#client_secret DataDatabricksStorageCredential#client_secret}
    */
    readonly clientSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#directory_id DataDatabricksStorageCredential#directory_id}
    */
    readonly directoryId: string;
}
export declare function dataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipalToTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipalOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal): any;
export declare function dataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipalToHclTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipalOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal): any;
export declare class DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal | undefined;
    set internalValue(value: DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal | undefined);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
}
export interface DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#access_key_id DataDatabricksStorageCredential#access_key_id}
    */
    readonly accessKeyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#account_id DataDatabricksStorageCredential#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#secret_access_key DataDatabricksStorageCredential#secret_access_key}
    */
    readonly secretAccessKey: string;
}
export declare function dataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiTokenToTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiTokenOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken): any;
export declare function dataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiTokenToHclTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiTokenOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken): any;
export declare class DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken | undefined;
    set internalValue(value: DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    get accessKeyIdInput(): string | undefined;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    get secretAccessKeyInput(): string | undefined;
}
export interface DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#credential_id DataDatabricksStorageCredential#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#email DataDatabricksStorageCredential#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccountToTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccountOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount): any;
export declare function dataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccountToHclTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccountOutputReference | DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount): any;
export declare class DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount | undefined;
    set internalValue(value: DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount | undefined);
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksStorageCredentialStorageCredentialInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#comment DataDatabricksStorageCredential#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#created_at DataDatabricksStorageCredential#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#created_by DataDatabricksStorageCredential#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#full_name DataDatabricksStorageCredential#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#id DataDatabricksStorageCredential#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#isolation_mode DataDatabricksStorageCredential#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#metastore_id DataDatabricksStorageCredential#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#name DataDatabricksStorageCredential#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#owner DataDatabricksStorageCredential#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#read_only DataDatabricksStorageCredential#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#updated_at DataDatabricksStorageCredential#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#updated_by DataDatabricksStorageCredential#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#used_for_managed_storage DataDatabricksStorageCredential#used_for_managed_storage}
    */
    readonly usedForManagedStorage?: boolean | cdktn.IResolvable;
    /**
    * aws_iam_role block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#aws_iam_role DataDatabricksStorageCredential#aws_iam_role}
    */
    readonly awsIamRole?: DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole;
    /**
    * azure_managed_identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#azure_managed_identity DataDatabricksStorageCredential#azure_managed_identity}
    */
    readonly azureManagedIdentity?: DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity;
    /**
    * azure_service_principal block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#azure_service_principal DataDatabricksStorageCredential#azure_service_principal}
    */
    readonly azureServicePrincipal?: DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal;
    /**
    * cloudflare_api_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#cloudflare_api_token DataDatabricksStorageCredential#cloudflare_api_token}
    */
    readonly cloudflareApiToken?: DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken;
    /**
    * databricks_gcp_service_account block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#databricks_gcp_service_account DataDatabricksStorageCredential#databricks_gcp_service_account}
    */
    readonly databricksGcpServiceAccount?: DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount;
}
export declare function dataDatabricksStorageCredentialStorageCredentialInfoToTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoOutputReference | DataDatabricksStorageCredentialStorageCredentialInfo): any;
export declare function dataDatabricksStorageCredentialStorageCredentialInfoToHclTerraform(struct?: DataDatabricksStorageCredentialStorageCredentialInfoOutputReference | DataDatabricksStorageCredentialStorageCredentialInfo): any;
export declare class DataDatabricksStorageCredentialStorageCredentialInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialStorageCredentialInfo | undefined;
    set internalValue(value: DataDatabricksStorageCredentialStorageCredentialInfo | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _usedForManagedStorage?;
    get usedForManagedStorage(): boolean | cdktn.IResolvable;
    set usedForManagedStorage(value: boolean | cdktn.IResolvable);
    resetUsedForManagedStorage(): void;
    get usedForManagedStorageInput(): boolean | cdktn.IResolvable | undefined;
    private _awsIamRole;
    get awsIamRole(): DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRoleOutputReference;
    putAwsIamRole(value: DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole): void;
    resetAwsIamRole(): void;
    get awsIamRoleInput(): DataDatabricksStorageCredentialStorageCredentialInfoAwsIamRole | undefined;
    private _azureManagedIdentity;
    get azureManagedIdentity(): DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentityOutputReference;
    putAzureManagedIdentity(value: DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity): void;
    resetAzureManagedIdentity(): void;
    get azureManagedIdentityInput(): DataDatabricksStorageCredentialStorageCredentialInfoAzureManagedIdentity | undefined;
    private _azureServicePrincipal;
    get azureServicePrincipal(): DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipalOutputReference;
    putAzureServicePrincipal(value: DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal): void;
    resetAzureServicePrincipal(): void;
    get azureServicePrincipalInput(): DataDatabricksStorageCredentialStorageCredentialInfoAzureServicePrincipal | undefined;
    private _cloudflareApiToken;
    get cloudflareApiToken(): DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiTokenOutputReference;
    putCloudflareApiToken(value: DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken): void;
    resetCloudflareApiToken(): void;
    get cloudflareApiTokenInput(): DataDatabricksStorageCredentialStorageCredentialInfoCloudflareApiToken | undefined;
    private _databricksGcpServiceAccount;
    get databricksGcpServiceAccount(): DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccountOutputReference;
    putDatabricksGcpServiceAccount(value: DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount): void;
    resetDatabricksGcpServiceAccount(): void;
    get databricksGcpServiceAccountInput(): DataDatabricksStorageCredentialStorageCredentialInfoDatabricksGcpServiceAccount | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential databricks_storage_credential}
*/
export declare class DataDatabricksStorageCredential extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_storage_credential";
    /**
    * Generates CDKTN code for importing a DataDatabricksStorageCredential resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksStorageCredential to import
    * @param importFromId The id of the existing DataDatabricksStorageCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksStorageCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credential databricks_storage_credential} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksStorageCredentialConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksStorageCredentialConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksStorageCredentialProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksStorageCredentialProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksStorageCredentialProviderConfig | undefined;
    private _storageCredentialInfo;
    get storageCredentialInfo(): DataDatabricksStorageCredentialStorageCredentialInfoOutputReference;
    putStorageCredentialInfo(value: DataDatabricksStorageCredentialStorageCredentialInfo): void;
    resetStorageCredentialInfo(): void;
    get storageCredentialInfoInput(): DataDatabricksStorageCredentialStorageCredentialInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
