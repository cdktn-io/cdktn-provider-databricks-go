/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AibiDashboardEmbeddingApprovedDomainsSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#etag AibiDashboardEmbeddingApprovedDomainsSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#id AibiDashboardEmbeddingApprovedDomainsSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#setting_name AibiDashboardEmbeddingApprovedDomainsSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * aibi_dashboard_embedding_approved_domains block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#aibi_dashboard_embedding_approved_domains AibiDashboardEmbeddingApprovedDomainsSetting#aibi_dashboard_embedding_approved_domains}
    */
    readonly aibiDashboardEmbeddingApprovedDomains: AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#provider_config AibiDashboardEmbeddingApprovedDomainsSetting#provider_config}
    */
    readonly providerConfig?: AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig;
}
export interface AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#approved_domains AibiDashboardEmbeddingApprovedDomainsSetting#approved_domains}
    */
    readonly approvedDomains: string[];
}
export declare function aibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomainsOutputReference | AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains): any;
export declare function aibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomainsOutputReference | AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains): any;
export declare class AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    get approvedDomainsInput(): string[] | undefined;
}
export interface AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#workspace_id AibiDashboardEmbeddingApprovedDomainsSetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function aibiDashboardEmbeddingApprovedDomainsSettingProviderConfigToTerraform(struct?: AibiDashboardEmbeddingApprovedDomainsSettingProviderConfigOutputReference | AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig): any;
export declare function aibiDashboardEmbeddingApprovedDomainsSettingProviderConfigToHclTerraform(struct?: AibiDashboardEmbeddingApprovedDomainsSettingProviderConfigOutputReference | AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig): any;
export declare class AibiDashboardEmbeddingApprovedDomainsSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig | undefined;
    set internalValue(value: AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting databricks_aibi_dashboard_embedding_approved_domains_setting}
*/
export declare class AibiDashboardEmbeddingApprovedDomainsSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_aibi_dashboard_embedding_approved_domains_setting";
    /**
    * Generates CDKTN code for importing a AibiDashboardEmbeddingApprovedDomainsSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AibiDashboardEmbeddingApprovedDomainsSetting to import
    * @param importFromId The id of the existing AibiDashboardEmbeddingApprovedDomainsSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AibiDashboardEmbeddingApprovedDomainsSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/aibi_dashboard_embedding_approved_domains_setting databricks_aibi_dashboard_embedding_approved_domains_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AibiDashboardEmbeddingApprovedDomainsSettingConfig
    */
    constructor(scope: Construct, id: string, config: AibiDashboardEmbeddingApprovedDomainsSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomainsOutputReference;
    putAibiDashboardEmbeddingApprovedDomains(value: AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains): void;
    get aibiDashboardEmbeddingApprovedDomainsInput(): AibiDashboardEmbeddingApprovedDomainsSettingAibiDashboardEmbeddingApprovedDomains | undefined;
    private _providerConfig;
    get providerConfig(): AibiDashboardEmbeddingApprovedDomainsSettingProviderConfigOutputReference;
    putProviderConfig(value: AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): AibiDashboardEmbeddingApprovedDomainsSettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
