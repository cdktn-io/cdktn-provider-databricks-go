/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDatabaseInstancesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#page_size DataDatabricksDatabaseInstances#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#provider_config DataDatabricksDatabaseInstances#provider_config}
    */
    readonly providerConfig?: DataDatabricksDatabaseInstancesProviderConfig;
}
export interface DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#branch_time DataDatabricksDatabaseInstances#branch_time}
    */
    readonly branchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#lsn DataDatabricksDatabaseInstances#lsn}
    */
    readonly lsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#name DataDatabricksDatabaseInstances#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefsToTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefs): any;
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefsToHclTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefs): any;
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefs | undefined;
    set internalValue(value: DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefs | undefined);
    private _branchTime?;
    get branchTime(): string;
    set branchTime(value: string);
    resetBranchTime(): void;
    get branchTimeInput(): string | undefined;
    get effectiveLsn(): string;
    private _lsn?;
    get lsn(): string;
    set lsn(value: string);
    resetLsn(): void;
    get lsnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get uid(): string;
}
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefsOutputReference;
}
export interface DataDatabricksDatabaseInstancesDatabaseInstancesCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#key DataDatabricksDatabaseInstances#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#value DataDatabricksDatabaseInstances#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesCustomTagsToTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesCustomTags): any;
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesCustomTagsToHclTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesCustomTags): any;
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseInstancesDatabaseInstancesCustomTags | undefined;
    set internalValue(value: DataDatabricksDatabaseInstancesDatabaseInstancesCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseInstancesDatabaseInstancesCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseInstancesDatabaseInstancesCustomTagsOutputReference;
}
export interface DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#key DataDatabricksDatabaseInstances#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#value DataDatabricksDatabaseInstances#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTagsToTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTags): any;
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTagsToHclTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTags): any;
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTags | undefined;
    set internalValue(value: DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTagsOutputReference;
}
export interface DataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#branch_time DataDatabricksDatabaseInstances#branch_time}
    */
    readonly branchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#lsn DataDatabricksDatabaseInstances#lsn}
    */
    readonly lsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#name DataDatabricksDatabaseInstances#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRefToTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRef): any;
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRefToHclTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRef): any;
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRef | undefined;
    set internalValue(value: DataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRef | undefined);
    private _branchTime?;
    get branchTime(): string;
    set branchTime(value: string);
    resetBranchTime(): void;
    get branchTimeInput(): string | undefined;
    get effectiveLsn(): string;
    private _lsn?;
    get lsn(): string;
    set lsn(value: string);
    resetLsn(): void;
    get lsnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get uid(): string;
}
export interface DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#workspace_id DataDatabricksDatabaseInstances#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesProviderConfigToTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesProviderConfigToHclTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksDatabaseInstancesDatabaseInstances {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#name DataDatabricksDatabaseInstances#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#provider_config DataDatabricksDatabaseInstances#provider_config}
    */
    readonly providerConfig?: DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig;
}
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesToTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstances): any;
export declare function dataDatabricksDatabaseInstancesDatabaseInstancesToHclTerraform(struct?: DataDatabricksDatabaseInstancesDatabaseInstances): any;
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseInstancesDatabaseInstances | undefined;
    set internalValue(value: DataDatabricksDatabaseInstancesDatabaseInstances | undefined);
    get capacity(): string;
    private _childInstanceRefs;
    get childInstanceRefs(): DataDatabricksDatabaseInstancesDatabaseInstancesChildInstanceRefsList;
    get creationTime(): string;
    get creator(): string;
    private _customTags;
    get customTags(): DataDatabricksDatabaseInstancesDatabaseInstancesCustomTagsList;
    get effectiveCapacity(): string;
    private _effectiveCustomTags;
    get effectiveCustomTags(): DataDatabricksDatabaseInstancesDatabaseInstancesEffectiveCustomTagsList;
    get effectiveEnablePgNativeLogin(): cdktn.IResolvable;
    get effectiveEnableReadableSecondaries(): cdktn.IResolvable;
    get effectiveNodeCount(): number;
    get effectiveRetentionWindowInDays(): number;
    get effectiveStopped(): cdktn.IResolvable;
    get effectiveUsagePolicyId(): string;
    get enablePgNativeLogin(): cdktn.IResolvable;
    get enableReadableSecondaries(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeCount(): number;
    private _parentInstanceRef;
    get parentInstanceRef(): DataDatabricksDatabaseInstancesDatabaseInstancesParentInstanceRefOutputReference;
    get pgVersion(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDatabaseInstancesDatabaseInstancesProviderConfig | undefined;
    get readOnlyDns(): string;
    get readWriteDns(): string;
    get retentionWindowInDays(): number;
    get state(): string;
    get stopped(): cdktn.IResolvable;
    get uid(): string;
    get usagePolicyId(): string;
}
export declare class DataDatabricksDatabaseInstancesDatabaseInstancesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseInstancesDatabaseInstances[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseInstancesDatabaseInstancesOutputReference;
}
export interface DataDatabricksDatabaseInstancesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#workspace_id DataDatabricksDatabaseInstances#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDatabaseInstancesProviderConfigToTerraform(struct?: DataDatabricksDatabaseInstancesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseInstancesProviderConfigToHclTerraform(struct?: DataDatabricksDatabaseInstancesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseInstancesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseInstancesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseInstancesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances databricks_database_instances}
*/
export declare class DataDatabricksDatabaseInstances extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_database_instances";
    /**
    * Generates CDKTN code for importing a DataDatabricksDatabaseInstances resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDatabaseInstances to import
    * @param importFromId The id of the existing DataDatabricksDatabaseInstances that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDatabaseInstances to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/database_instances databricks_database_instances} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDatabaseInstancesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksDatabaseInstancesConfig);
    private _databaseInstances;
    get databaseInstances(): DataDatabricksDatabaseInstancesDatabaseInstancesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDatabaseInstancesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDatabaseInstancesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDatabaseInstancesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
