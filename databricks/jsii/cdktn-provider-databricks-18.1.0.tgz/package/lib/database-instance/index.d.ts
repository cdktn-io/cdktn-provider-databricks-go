/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#capacity DatabaseInstance#capacity}
    */
    readonly capacity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#custom_tags DatabaseInstance#custom_tags}
    */
    readonly customTags?: DatabaseInstanceCustomTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#enable_pg_native_login DatabaseInstance#enable_pg_native_login}
    */
    readonly enablePgNativeLogin?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#enable_readable_secondaries DatabaseInstance#enable_readable_secondaries}
    */
    readonly enableReadableSecondaries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#name DatabaseInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#node_count DatabaseInstance#node_count}
    */
    readonly nodeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#parent_instance_ref DatabaseInstance#parent_instance_ref}
    */
    readonly parentInstanceRef?: DatabaseInstanceParentInstanceRef;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#provider_config DatabaseInstance#provider_config}
    */
    readonly providerConfig?: DatabaseInstanceProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#purge_on_delete DatabaseInstance#purge_on_delete}
    */
    readonly purgeOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#retention_window_in_days DatabaseInstance#retention_window_in_days}
    */
    readonly retentionWindowInDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#stopped DatabaseInstance#stopped}
    */
    readonly stopped?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#usage_policy_id DatabaseInstance#usage_policy_id}
    */
    readonly usagePolicyId?: string;
}
export interface DatabaseInstanceChildInstanceRefs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#branch_time DatabaseInstance#branch_time}
    */
    readonly branchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#lsn DatabaseInstance#lsn}
    */
    readonly lsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#name DatabaseInstance#name}
    */
    readonly name?: string;
}
export declare function databaseInstanceChildInstanceRefsToTerraform(struct?: DatabaseInstanceChildInstanceRefs): any;
export declare function databaseInstanceChildInstanceRefsToHclTerraform(struct?: DatabaseInstanceChildInstanceRefs): any;
export declare class DatabaseInstanceChildInstanceRefsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseInstanceChildInstanceRefs | undefined;
    set internalValue(value: DatabaseInstanceChildInstanceRefs | undefined);
    private _branchTime?;
    get branchTime(): string;
    set branchTime(value: string);
    resetBranchTime(): void;
    get branchTimeInput(): string | undefined;
    get effectiveLsn(): string;
    private _lsn?;
    get lsn(): string;
    set lsn(value: string);
    resetLsn(): void;
    get lsnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get uid(): string;
}
export declare class DatabaseInstanceChildInstanceRefsList extends cdktn.ComplexList {
    internalValue?: DatabaseInstanceChildInstanceRefs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseInstanceChildInstanceRefsOutputReference;
}
export interface DatabaseInstanceCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#key DatabaseInstance#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#value DatabaseInstance#value}
    */
    readonly value?: string;
}
export declare function databaseInstanceCustomTagsToTerraform(struct?: DatabaseInstanceCustomTags | cdktn.IResolvable): any;
export declare function databaseInstanceCustomTagsToHclTerraform(struct?: DatabaseInstanceCustomTags | cdktn.IResolvable): any;
export declare class DatabaseInstanceCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseInstanceCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseInstanceCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DatabaseInstanceCustomTagsList extends cdktn.ComplexList {
    internalValue?: DatabaseInstanceCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseInstanceCustomTagsOutputReference;
}
export interface DatabaseInstanceEffectiveCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#key DatabaseInstance#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#value DatabaseInstance#value}
    */
    readonly value?: string;
}
export declare function databaseInstanceEffectiveCustomTagsToTerraform(struct?: DatabaseInstanceEffectiveCustomTags): any;
export declare function databaseInstanceEffectiveCustomTagsToHclTerraform(struct?: DatabaseInstanceEffectiveCustomTags): any;
export declare class DatabaseInstanceEffectiveCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseInstanceEffectiveCustomTags | undefined;
    set internalValue(value: DatabaseInstanceEffectiveCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DatabaseInstanceEffectiveCustomTagsList extends cdktn.ComplexList {
    internalValue?: DatabaseInstanceEffectiveCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseInstanceEffectiveCustomTagsOutputReference;
}
export interface DatabaseInstanceParentInstanceRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#branch_time DatabaseInstance#branch_time}
    */
    readonly branchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#lsn DatabaseInstance#lsn}
    */
    readonly lsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#name DatabaseInstance#name}
    */
    readonly name?: string;
}
export declare function databaseInstanceParentInstanceRefToTerraform(struct?: DatabaseInstanceParentInstanceRef | cdktn.IResolvable): any;
export declare function databaseInstanceParentInstanceRefToHclTerraform(struct?: DatabaseInstanceParentInstanceRef | cdktn.IResolvable): any;
export declare class DatabaseInstanceParentInstanceRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseInstanceParentInstanceRef | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseInstanceParentInstanceRef | cdktn.IResolvable | undefined);
    private _branchTime?;
    get branchTime(): string;
    set branchTime(value: string);
    resetBranchTime(): void;
    get branchTimeInput(): string | undefined;
    get effectiveLsn(): string;
    private _lsn?;
    get lsn(): string;
    set lsn(value: string);
    resetLsn(): void;
    get lsnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get uid(): string;
}
export interface DatabaseInstanceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#workspace_id DatabaseInstance#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function databaseInstanceProviderConfigToTerraform(struct?: DatabaseInstanceProviderConfig | cdktn.IResolvable): any;
export declare function databaseInstanceProviderConfigToHclTerraform(struct?: DatabaseInstanceProviderConfig | cdktn.IResolvable): any;
export declare class DatabaseInstanceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseInstanceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseInstanceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance databricks_database_instance}
*/
export declare class DatabaseInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_database_instance";
    /**
    * Generates CDKTN code for importing a DatabaseInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseInstance to import
    * @param importFromId The id of the existing DatabaseInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/database_instance databricks_database_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseInstanceConfig);
    private _capacity?;
    get capacity(): string;
    set capacity(value: string);
    resetCapacity(): void;
    get capacityInput(): string | undefined;
    private _childInstanceRefs;
    get childInstanceRefs(): DatabaseInstanceChildInstanceRefsList;
    get creationTime(): string;
    get creator(): string;
    private _customTags;
    get customTags(): DatabaseInstanceCustomTagsList;
    putCustomTags(value: DatabaseInstanceCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | DatabaseInstanceCustomTags[] | undefined;
    get effectiveCapacity(): string;
    private _effectiveCustomTags;
    get effectiveCustomTags(): DatabaseInstanceEffectiveCustomTagsList;
    get effectiveEnablePgNativeLogin(): cdktn.IResolvable;
    get effectiveEnableReadableSecondaries(): cdktn.IResolvable;
    get effectiveNodeCount(): number;
    get effectiveRetentionWindowInDays(): number;
    get effectiveStopped(): cdktn.IResolvable;
    get effectiveUsagePolicyId(): string;
    private _enablePgNativeLogin?;
    get enablePgNativeLogin(): boolean | cdktn.IResolvable;
    set enablePgNativeLogin(value: boolean | cdktn.IResolvable);
    resetEnablePgNativeLogin(): void;
    get enablePgNativeLoginInput(): boolean | cdktn.IResolvable | undefined;
    private _enableReadableSecondaries?;
    get enableReadableSecondaries(): boolean | cdktn.IResolvable;
    set enableReadableSecondaries(value: boolean | cdktn.IResolvable);
    resetEnableReadableSecondaries(): void;
    get enableReadableSecondariesInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeCount?;
    get nodeCount(): number;
    set nodeCount(value: number);
    resetNodeCount(): void;
    get nodeCountInput(): number | undefined;
    private _parentInstanceRef;
    get parentInstanceRef(): DatabaseInstanceParentInstanceRefOutputReference;
    putParentInstanceRef(value: DatabaseInstanceParentInstanceRef): void;
    resetParentInstanceRef(): void;
    get parentInstanceRefInput(): cdktn.IResolvable | DatabaseInstanceParentInstanceRef | undefined;
    get pgVersion(): string;
    private _providerConfig;
    get providerConfig(): DatabaseInstanceProviderConfigOutputReference;
    putProviderConfig(value: DatabaseInstanceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DatabaseInstanceProviderConfig | undefined;
    private _purgeOnDelete?;
    get purgeOnDelete(): boolean | cdktn.IResolvable;
    set purgeOnDelete(value: boolean | cdktn.IResolvable);
    resetPurgeOnDelete(): void;
    get purgeOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    get readOnlyDns(): string;
    get readWriteDns(): string;
    private _retentionWindowInDays?;
    get retentionWindowInDays(): number;
    set retentionWindowInDays(value: number);
    resetRetentionWindowInDays(): void;
    get retentionWindowInDaysInput(): number | undefined;
    get state(): string;
    private _stopped?;
    get stopped(): boolean | cdktn.IResolvable;
    set stopped(value: boolean | cdktn.IResolvable);
    resetStopped(): void;
    get stoppedInput(): boolean | cdktn.IResolvable | undefined;
    get uid(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
