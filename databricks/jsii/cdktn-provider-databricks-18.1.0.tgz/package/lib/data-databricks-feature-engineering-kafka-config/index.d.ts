/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksFeatureEngineeringKafkaConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#name DataDatabricksFeatureEngineeringKafkaConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#provider_config DataDatabricksFeatureEngineeringKafkaConfig#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringKafkaConfigProviderConfig;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#key DataDatabricksFeatureEngineeringKafkaConfig#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#scope DataDatabricksFeatureEngineeringKafkaConfig#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#key DataDatabricksFeatureEngineeringKafkaConfig#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#scope DataDatabricksFeatureEngineeringKafkaConfig#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#key DataDatabricksFeatureEngineeringKafkaConfig#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#scope DataDatabricksFeatureEngineeringKafkaConfig#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#disable_hostname_verification DataDatabricksFeatureEngineeringKafkaConfig#disable_hostname_verification}
    */
    readonly disableHostnameVerification?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#key_password_ref DataDatabricksFeatureEngineeringKafkaConfig#key_password_ref}
    */
    readonly keyPasswordRef: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#keystore_location DataDatabricksFeatureEngineeringKafkaConfig#keystore_location}
    */
    readonly keystoreLocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#keystore_password_ref DataDatabricksFeatureEngineeringKafkaConfig#keystore_password_ref}
    */
    readonly keystorePasswordRef: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#truststore_location DataDatabricksFeatureEngineeringKafkaConfig#truststore_location}
    */
    readonly truststoreLocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#truststore_password_ref DataDatabricksFeatureEngineeringKafkaConfig#truststore_password_ref}
    */
    readonly truststorePasswordRef: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable | undefined);
    private _disableHostnameVerification?;
    get disableHostnameVerification(): boolean | cdktn.IResolvable;
    set disableHostnameVerification(value: boolean | cdktn.IResolvable);
    resetDisableHostnameVerification(): void;
    get disableHostnameVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _keyPasswordRef;
    get keyPasswordRef(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefOutputReference;
    putKeyPasswordRef(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef): void;
    get keyPasswordRefInput(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | undefined;
    private _keystoreLocation?;
    get keystoreLocation(): string;
    set keystoreLocation(value: string);
    get keystoreLocationInput(): string | undefined;
    private _keystorePasswordRef;
    get keystorePasswordRef(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefOutputReference;
    putKeystorePasswordRef(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef): void;
    get keystorePasswordRefInput(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | undefined;
    private _truststoreLocation?;
    get truststoreLocation(): string;
    set truststoreLocation(value: string);
    get truststoreLocationInput(): string | undefined;
    private _truststorePasswordRef;
    get truststorePasswordRef(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefOutputReference;
    putTruststorePasswordRef(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef): void;
    get truststorePasswordRefInput(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigAuthConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#mtls_config DataDatabricksFeatureEngineeringKafkaConfig#mtls_config}
    */
    readonly mtlsConfig?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#uc_service_credential_name DataDatabricksFeatureEngineeringKafkaConfig#uc_service_credential_name}
    */
    readonly ucServiceCredentialName?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfig): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigAuthConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigAuthConfig): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfig | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfig | undefined);
    private _mtlsConfig;
    get mtlsConfig(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfigOutputReference;
    putMtlsConfig(value: DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig): void;
    resetMtlsConfig(): void;
    get mtlsConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigAuthConfigMtlsConfig | undefined;
    private _ucServiceCredentialName?;
    get ucServiceCredentialName(): string;
    set ucServiceCredentialName(value: string);
    resetUcServiceCredentialName(): void;
    get ucServiceCredentialNameInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#dataframe_schema DataDatabricksFeatureEngineeringKafkaConfig#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#entity_columns DataDatabricksFeatureEngineeringKafkaConfig#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#filter_condition DataDatabricksFeatureEngineeringKafkaConfig#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#full_name DataDatabricksFeatureEngineeringKafkaConfig#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#timeseries_column DataDatabricksFeatureEngineeringKafkaConfig#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#transformation_sql DataDatabricksFeatureEngineeringKafkaConfig#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigBackfillSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#delta_table_name DataDatabricksFeatureEngineeringKafkaConfig#delta_table_name}
    */
    readonly deltaTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#delta_table_source DataDatabricksFeatureEngineeringKafkaConfig#delta_table_source}
    */
    readonly deltaTableSource?: DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigBackfillSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigBackfillSource): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigBackfillSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigBackfillSource): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigBackfillSource | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigBackfillSource | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
    private _deltaTableSource;
    get deltaTableSource(): DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#dataframe_schema DataDatabricksFeatureEngineeringKafkaConfig#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#entity_columns DataDatabricksFeatureEngineeringKafkaConfig#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#filter_condition DataDatabricksFeatureEngineeringKafkaConfig#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#full_name DataDatabricksFeatureEngineeringKafkaConfig#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#timeseries_column DataDatabricksFeatureEngineeringKafkaConfig#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#transformation_sql DataDatabricksFeatureEngineeringKafkaConfig#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#delta_table_name DataDatabricksFeatureEngineeringKafkaConfig#delta_table_name}
    */
    readonly deltaTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#delta_table_source DataDatabricksFeatureEngineeringKafkaConfig#delta_table_source}
    */
    readonly deltaTableSource?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
    private _deltaTableSource;
    get deltaTableSource(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#delta_table_name DataDatabricksFeatureEngineeringKafkaConfig#delta_table_name}
    */
    readonly deltaTableName?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestinationToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestinationToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigIngestionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#backfill_source DataDatabricksFeatureEngineeringKafkaConfig#backfill_source}
    */
    readonly backfillSource?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#deduplication_columns DataDatabricksFeatureEngineeringKafkaConfig#deduplication_columns}
    */
    readonly deduplicationColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#ingestion_destination DataDatabricksFeatureEngineeringKafkaConfig#ingestion_destination}
    */
    readonly ingestionDestination: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfig): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigIngestionConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfig): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfig | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfig | undefined);
    get backfillJobId(): number;
    private _backfillSource;
    get backfillSource(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSourceOutputReference;
    putBackfillSource(value: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource): void;
    resetBackfillSource(): void;
    get backfillSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigBackfillSource | undefined;
    private _deduplicationColumns?;
    get deduplicationColumns(): string[];
    set deduplicationColumns(value: string[]);
    resetDeduplicationColumns(): void;
    get deduplicationColumnsInput(): string[] | undefined;
    private _ingestionDestination;
    get ingestionDestination(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestinationOutputReference;
    putIngestionDestination(value: DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination): void;
    get ingestionDestinationInput(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | undefined;
    get ingestionJobId(): number;
    get ingestionPipelineId(): string;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#message_name DataDatabricksFeatureEngineeringKafkaConfig#message_name}
    */
    readonly messageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#schema_text DataDatabricksFeatureEngineeringKafkaConfig#schema_text}
    */
    readonly schemaText: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable | undefined);
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    get messageNameInput(): string | undefined;
    private _schemaText?;
    get schemaText(): string;
    set schemaText(value: string);
    get schemaTextInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigKeySchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#avro_schema DataDatabricksFeatureEngineeringKafkaConfig#avro_schema}
    */
    readonly avroSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#json_schema DataDatabricksFeatureEngineeringKafkaConfig#json_schema}
    */
    readonly jsonSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#proto_schema DataDatabricksFeatureEngineeringKafkaConfig#proto_schema}
    */
    readonly protoSchema?: DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigKeySchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigKeySchema): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigKeySchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigKeySchema): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigKeySchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigKeySchema | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigKeySchema | undefined);
    private _avroSchema?;
    get avroSchema(): string;
    set avroSchema(value: string);
    resetAvroSchema(): void;
    get avroSchemaInput(): string | undefined;
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
    private _protoSchema;
    get protoSchema(): DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchemaOutputReference;
    putProtoSchema(value: DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema): void;
    resetProtoSchema(): void;
    get protoSchemaInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigKeySchemaProtoSchema | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#workspace_id DataDatabricksFeatureEngineeringKafkaConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigSubscriptionMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#assign DataDatabricksFeatureEngineeringKafkaConfig#assign}
    */
    readonly assign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#subscribe DataDatabricksFeatureEngineeringKafkaConfig#subscribe}
    */
    readonly subscribe?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#subscribe_pattern DataDatabricksFeatureEngineeringKafkaConfig#subscribe_pattern}
    */
    readonly subscribePattern?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigSubscriptionModeToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigSubscriptionMode): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigSubscriptionModeToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigSubscriptionMode): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigSubscriptionModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigSubscriptionMode | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigSubscriptionMode | undefined);
    private _assign?;
    get assign(): string;
    set assign(value: string);
    resetAssign(): void;
    get assignInput(): string | undefined;
    private _subscribe?;
    get subscribe(): string;
    set subscribe(value: string);
    resetSubscribe(): void;
    get subscribeInput(): string | undefined;
    private _subscribePattern?;
    get subscribePattern(): string;
    set subscribePattern(value: string);
    resetSubscribePattern(): void;
    get subscribePatternInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#message_name DataDatabricksFeatureEngineeringKafkaConfig#message_name}
    */
    readonly messageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#schema_text DataDatabricksFeatureEngineeringKafkaConfig#schema_text}
    */
    readonly schemaText: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable | undefined);
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    get messageNameInput(): string | undefined;
    private _schemaText?;
    get schemaText(): string;
    set schemaText(value: string);
    get schemaTextInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigValueSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#avro_schema DataDatabricksFeatureEngineeringKafkaConfig#avro_schema}
    */
    readonly avroSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#json_schema DataDatabricksFeatureEngineeringKafkaConfig#json_schema}
    */
    readonly jsonSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#proto_schema DataDatabricksFeatureEngineeringKafkaConfig#proto_schema}
    */
    readonly protoSchema?: DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigValueSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigValueSchema): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigValueSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigValueSchema): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigValueSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigValueSchema | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigValueSchema | undefined);
    private _avroSchema?;
    get avroSchema(): string;
    set avroSchema(value: string);
    resetAvroSchema(): void;
    get avroSchemaInput(): string | undefined;
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
    private _protoSchema;
    get protoSchema(): DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchemaOutputReference;
    putProtoSchema(value: DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema): void;
    resetProtoSchema(): void;
    get protoSchemaInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigValueSchemaProtoSchema | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config}
*/
export declare class DataDatabricksFeatureEngineeringKafkaConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_feature_engineering_kafka_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksFeatureEngineeringKafkaConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksFeatureEngineeringKafkaConfig to import
    * @param importFromId The id of the existing DataDatabricksFeatureEngineeringKafkaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksFeatureEngineeringKafkaConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksFeatureEngineeringKafkaConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksFeatureEngineeringKafkaConfigConfig);
    private _authConfig;
    get authConfig(): DataDatabricksFeatureEngineeringKafkaConfigAuthConfigOutputReference;
    private _backfillSource;
    get backfillSource(): DataDatabricksFeatureEngineeringKafkaConfigBackfillSourceOutputReference;
    get bootstrapServers(): string;
    private _extraOptions;
    get extraOptions(): cdktn.StringMap;
    private _ingestionConfig;
    get ingestionConfig(): DataDatabricksFeatureEngineeringKafkaConfigIngestionConfigOutputReference;
    private _keySchema;
    get keySchema(): DataDatabricksFeatureEngineeringKafkaConfigKeySchemaOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringKafkaConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringKafkaConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigProviderConfig | undefined;
    private _subscriptionMode;
    get subscriptionMode(): DataDatabricksFeatureEngineeringKafkaConfigSubscriptionModeOutputReference;
    private _valueSchema;
    get valueSchema(): DataDatabricksFeatureEngineeringKafkaConfigValueSchemaOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
