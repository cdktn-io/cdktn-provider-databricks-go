/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksStorageCredentialsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credentials#id DataDatabricksStorageCredentials#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credentials#names DataDatabricksStorageCredentials#names}
    */
    readonly names?: string[];
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credentials#provider_config DataDatabricksStorageCredentials#provider_config}
    */
    readonly providerConfig?: DataDatabricksStorageCredentialsProviderConfig;
}
export interface DataDatabricksStorageCredentialsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credentials#workspace_id DataDatabricksStorageCredentials#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksStorageCredentialsProviderConfigToTerraform(struct?: DataDatabricksStorageCredentialsProviderConfigOutputReference | DataDatabricksStorageCredentialsProviderConfig): any;
export declare function dataDatabricksStorageCredentialsProviderConfigToHclTerraform(struct?: DataDatabricksStorageCredentialsProviderConfigOutputReference | DataDatabricksStorageCredentialsProviderConfig): any;
export declare class DataDatabricksStorageCredentialsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksStorageCredentialsProviderConfig | undefined;
    set internalValue(value: DataDatabricksStorageCredentialsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credentials databricks_storage_credentials}
*/
export declare class DataDatabricksStorageCredentials extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_storage_credentials";
    /**
    * Generates CDKTN code for importing a DataDatabricksStorageCredentials resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksStorageCredentials to import
    * @param importFromId The id of the existing DataDatabricksStorageCredentials that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credentials#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksStorageCredentials to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/data-sources/storage_credentials databricks_storage_credentials} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksStorageCredentialsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksStorageCredentialsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _names?;
    get names(): string[];
    set names(value: string[]);
    resetNames(): void;
    get namesInput(): string[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksStorageCredentialsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksStorageCredentialsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksStorageCredentialsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
