/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MwsPrivateAccessSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#account_id MwsPrivateAccessSettings#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#allowed_vpc_endpoint_ids MwsPrivateAccessSettings#allowed_vpc_endpoint_ids}
    */
    readonly allowedVpcEndpointIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#id MwsPrivateAccessSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#private_access_level MwsPrivateAccessSettings#private_access_level}
    */
    readonly privateAccessLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#private_access_settings_id MwsPrivateAccessSettings#private_access_settings_id}
    */
    readonly privateAccessSettingsId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#private_access_settings_name MwsPrivateAccessSettings#private_access_settings_name}
    */
    readonly privateAccessSettingsName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#public_access_enabled MwsPrivateAccessSettings#public_access_enabled}
    */
    readonly publicAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#region MwsPrivateAccessSettings#region}
    */
    readonly region: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings databricks_mws_private_access_settings}
*/
export declare class MwsPrivateAccessSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mws_private_access_settings";
    /**
    * Generates CDKTN code for importing a MwsPrivateAccessSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MwsPrivateAccessSettings to import
    * @param importFromId The id of the existing MwsPrivateAccessSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MwsPrivateAccessSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.126.0/docs/resources/mws_private_access_settings databricks_mws_private_access_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MwsPrivateAccessSettingsConfig
    */
    constructor(scope: Construct, id: string, config: MwsPrivateAccessSettingsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _allowedVpcEndpointIds?;
    get allowedVpcEndpointIds(): string[];
    set allowedVpcEndpointIds(value: string[]);
    resetAllowedVpcEndpointIds(): void;
    get allowedVpcEndpointIdsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _privateAccessLevel?;
    get privateAccessLevel(): string;
    set privateAccessLevel(value: string);
    resetPrivateAccessLevel(): void;
    get privateAccessLevelInput(): string | undefined;
    private _privateAccessSettingsId?;
    get privateAccessSettingsId(): string;
    set privateAccessSettingsId(value: string);
    resetPrivateAccessSettingsId(): void;
    get privateAccessSettingsIdInput(): string | undefined;
    private _privateAccessSettingsName?;
    get privateAccessSettingsName(): string;
    set privateAccessSettingsName(value: string);
    get privateAccessSettingsNameInput(): string | undefined;
    private _publicAccessEnabled?;
    get publicAccessEnabled(): boolean | cdktn.IResolvable;
    set publicAccessEnabled(value: boolean | cdktn.IResolvable);
    resetPublicAccessEnabled(): void;
    get publicAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
