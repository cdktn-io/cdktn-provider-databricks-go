/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksKnowledgeAssistantKnowledgeSourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#page_size DataDatabricksKnowledgeAssistantKnowledgeSources#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#parent DataDatabricksKnowledgeAssistantKnowledgeSources#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#provider_config DataDatabricksKnowledgeAssistantKnowledgeSources#provider_config}
    */
    readonly providerConfig?: DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#file_col DataDatabricksKnowledgeAssistantKnowledgeSources#file_col}
    */
    readonly fileCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#table_name DataDatabricksKnowledgeAssistantKnowledgeSources#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTableToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTable): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTableToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTable): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTable | undefined);
    private _fileCol?;
    get fileCol(): string;
    set fileCol(value: string);
    get fileColInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFiles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#path DataDatabricksKnowledgeAssistantKnowledgeSources#path}
    */
    readonly path: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFilesToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFiles): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFilesToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFiles): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFiles | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFiles | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#doc_uri_col DataDatabricksKnowledgeAssistantKnowledgeSources#doc_uri_col}
    */
    readonly docUriCol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#index_name DataDatabricksKnowledgeAssistantKnowledgeSources#index_name}
    */
    readonly indexName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#text_col DataDatabricksKnowledgeAssistantKnowledgeSources#text_col}
    */
    readonly textCol: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndexToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndex): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndexToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndex): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndex | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndex | undefined);
    private _docUriCol?;
    get docUriCol(): string;
    set docUriCol(value: string);
    get docUriColInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _textCol?;
    get textCol(): string;
    set textCol(value: string);
    get textColInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#workspace_id DataDatabricksKnowledgeAssistantKnowledgeSources#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfigToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfigToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#name DataDatabricksKnowledgeAssistantKnowledgeSources#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#provider_config DataDatabricksKnowledgeAssistantKnowledgeSources#provider_config}
    */
    readonly providerConfig?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSources): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSources): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSources | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSources | undefined);
    get createTime(): string;
    get description(): string;
    get displayName(): string;
    private _fileTable;
    get fileTable(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFileTableOutputReference;
    private _files;
    get files(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesFilesOutputReference;
    get id(): string;
    private _index;
    get index(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesIndexOutputReference;
    get knowledgeCutoffTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesProviderConfig | undefined;
    get sourceType(): string;
    get state(): string;
}
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesOutputReference;
}
export interface DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#workspace_id DataDatabricksKnowledgeAssistantKnowledgeSources#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfigToTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfigToHclTerraform(struct?: DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources databricks_knowledge_assistant_knowledge_sources}
*/
export declare class DataDatabricksKnowledgeAssistantKnowledgeSources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_knowledge_assistant_knowledge_sources";
    /**
    * Generates CDKTN code for importing a DataDatabricksKnowledgeAssistantKnowledgeSources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksKnowledgeAssistantKnowledgeSources to import
    * @param importFromId The id of the existing DataDatabricksKnowledgeAssistantKnowledgeSources that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksKnowledgeAssistantKnowledgeSources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/knowledge_assistant_knowledge_sources databricks_knowledge_assistant_knowledge_sources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksKnowledgeAssistantKnowledgeSourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksKnowledgeAssistantKnowledgeSourcesConfig);
    private _knowledgeSources;
    get knowledgeSources(): DataDatabricksKnowledgeAssistantKnowledgeSourcesKnowledgeSourcesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksKnowledgeAssistantKnowledgeSourcesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
