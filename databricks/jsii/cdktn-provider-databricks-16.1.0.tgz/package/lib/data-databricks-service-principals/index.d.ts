/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksServicePrincipalsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#application_ids DataDatabricksServicePrincipals#application_ids}
    */
    readonly applicationIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#display_name_contains DataDatabricksServicePrincipals#display_name_contains}
    */
    readonly displayNameContains?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#id DataDatabricksServicePrincipals#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#provider_config DataDatabricksServicePrincipals#provider_config}
    */
    readonly providerConfig?: DataDatabricksServicePrincipalsProviderConfig;
    /**
    * service_principals block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#service_principals DataDatabricksServicePrincipals#service_principals}
    */
    readonly servicePrincipals?: DataDatabricksServicePrincipalsServicePrincipals[] | cdktn.IResolvable;
}
export interface DataDatabricksServicePrincipalsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#workspace_id DataDatabricksServicePrincipals#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksServicePrincipalsProviderConfigToTerraform(struct?: DataDatabricksServicePrincipalsProviderConfigOutputReference | DataDatabricksServicePrincipalsProviderConfig): any;
export declare function dataDatabricksServicePrincipalsProviderConfigToHclTerraform(struct?: DataDatabricksServicePrincipalsProviderConfigOutputReference | DataDatabricksServicePrincipalsProviderConfig): any;
export declare class DataDatabricksServicePrincipalsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksServicePrincipalsProviderConfig | undefined;
    set internalValue(value: DataDatabricksServicePrincipalsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksServicePrincipalsServicePrincipals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#acl_principal_id DataDatabricksServicePrincipals#acl_principal_id}
    */
    readonly aclPrincipalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#active DataDatabricksServicePrincipals#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#application_id DataDatabricksServicePrincipals#application_id}
    */
    readonly applicationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#display_name DataDatabricksServicePrincipals#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#external_id DataDatabricksServicePrincipals#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#home DataDatabricksServicePrincipals#home}
    */
    readonly home?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#id DataDatabricksServicePrincipals#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#repos DataDatabricksServicePrincipals#repos}
    */
    readonly repos?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#scim_id DataDatabricksServicePrincipals#scim_id}
    */
    readonly scimId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#sp_id DataDatabricksServicePrincipals#sp_id}
    */
    readonly spId?: string;
}
export declare function dataDatabricksServicePrincipalsServicePrincipalsToTerraform(struct?: DataDatabricksServicePrincipalsServicePrincipals | cdktn.IResolvable): any;
export declare function dataDatabricksServicePrincipalsServicePrincipalsToHclTerraform(struct?: DataDatabricksServicePrincipalsServicePrincipals | cdktn.IResolvable): any;
export declare class DataDatabricksServicePrincipalsServicePrincipalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksServicePrincipalsServicePrincipals | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksServicePrincipalsServicePrincipals | cdktn.IResolvable | undefined);
    private _aclPrincipalId?;
    get aclPrincipalId(): string;
    set aclPrincipalId(value: string);
    resetAclPrincipalId(): void;
    get aclPrincipalIdInput(): string | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    resetApplicationId(): void;
    get applicationIdInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _home?;
    get home(): string;
    set home(value: string);
    resetHome(): void;
    get homeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _repos?;
    get repos(): string;
    set repos(value: string);
    resetRepos(): void;
    get reposInput(): string | undefined;
    private _scimId?;
    get scimId(): string;
    set scimId(value: string);
    resetScimId(): void;
    get scimIdInput(): string | undefined;
    private _spId?;
    get spId(): string;
    set spId(value: string);
    resetSpId(): void;
    get spIdInput(): string | undefined;
}
export declare class DataDatabricksServicePrincipalsServicePrincipalsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksServicePrincipalsServicePrincipals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksServicePrincipalsServicePrincipalsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals databricks_service_principals}
*/
export declare class DataDatabricksServicePrincipals extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_service_principals";
    /**
    * Generates CDKTN code for importing a DataDatabricksServicePrincipals resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksServicePrincipals to import
    * @param importFromId The id of the existing DataDatabricksServicePrincipals that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksServicePrincipals to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/service_principals databricks_service_principals} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksServicePrincipalsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksServicePrincipalsConfig);
    private _applicationIds?;
    get applicationIds(): string[];
    set applicationIds(value: string[]);
    resetApplicationIds(): void;
    get applicationIdsInput(): string[] | undefined;
    private _displayNameContains?;
    get displayNameContains(): string;
    set displayNameContains(value: string);
    resetDisplayNameContains(): void;
    get displayNameContainsInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksServicePrincipalsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksServicePrincipalsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksServicePrincipalsProviderConfig | undefined;
    private _servicePrincipals;
    get servicePrincipals(): DataDatabricksServicePrincipalsServicePrincipalsList;
    putServicePrincipals(value: DataDatabricksServicePrincipalsServicePrincipals[] | cdktn.IResolvable): void;
    resetServicePrincipals(): void;
    get servicePrincipalsInput(): cdktn.IResolvable | DataDatabricksServicePrincipalsServicePrincipals[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
