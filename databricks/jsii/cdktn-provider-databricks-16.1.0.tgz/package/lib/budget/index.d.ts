/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BudgetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#account_id Budget#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#budget_configuration_id Budget#budget_configuration_id}
    */
    readonly budgetConfigurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#create_time Budget#create_time}
    */
    readonly createTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#display_name Budget#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#id Budget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#update_time Budget#update_time}
    */
    readonly updateTime?: number;
    /**
    * alert_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#alert_configurations Budget#alert_configurations}
    */
    readonly alertConfigurations?: BudgetAlertConfigurations[] | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#filter Budget#filter}
    */
    readonly filter?: BudgetFilter;
}
export interface BudgetAlertConfigurationsActionConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#action_configuration_id Budget#action_configuration_id}
    */
    readonly actionConfigurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#action_type Budget#action_type}
    */
    readonly actionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#target Budget#target}
    */
    readonly target?: string;
}
export declare function budgetAlertConfigurationsActionConfigurationsToTerraform(struct?: BudgetAlertConfigurationsActionConfigurations | cdktn.IResolvable): any;
export declare function budgetAlertConfigurationsActionConfigurationsToHclTerraform(struct?: BudgetAlertConfigurationsActionConfigurations | cdktn.IResolvable): any;
export declare class BudgetAlertConfigurationsActionConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetAlertConfigurationsActionConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetAlertConfigurationsActionConfigurations | cdktn.IResolvable | undefined);
    private _actionConfigurationId?;
    get actionConfigurationId(): string;
    set actionConfigurationId(value: string);
    resetActionConfigurationId(): void;
    get actionConfigurationIdInput(): string | undefined;
    private _actionType?;
    get actionType(): string;
    set actionType(value: string);
    resetActionType(): void;
    get actionTypeInput(): string | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
}
export declare class BudgetAlertConfigurationsActionConfigurationsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: BudgetAlertConfigurationsActionConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetAlertConfigurationsActionConfigurationsOutputReference;
}
export interface BudgetAlertConfigurations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#alert_configuration_id Budget#alert_configuration_id}
    */
    readonly alertConfigurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#quantity_threshold Budget#quantity_threshold}
    */
    readonly quantityThreshold?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#quantity_type Budget#quantity_type}
    */
    readonly quantityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#time_period Budget#time_period}
    */
    readonly timePeriod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#trigger_type Budget#trigger_type}
    */
    readonly triggerType?: string;
    /**
    * action_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#action_configurations Budget#action_configurations}
    */
    readonly actionConfigurations?: BudgetAlertConfigurationsActionConfigurations[] | cdktn.IResolvable;
}
export declare function budgetAlertConfigurationsToTerraform(struct?: BudgetAlertConfigurations | cdktn.IResolvable): any;
export declare function budgetAlertConfigurationsToHclTerraform(struct?: BudgetAlertConfigurations | cdktn.IResolvable): any;
export declare class BudgetAlertConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetAlertConfigurations | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetAlertConfigurations | cdktn.IResolvable | undefined);
    private _alertConfigurationId?;
    get alertConfigurationId(): string;
    set alertConfigurationId(value: string);
    resetAlertConfigurationId(): void;
    get alertConfigurationIdInput(): string | undefined;
    private _quantityThreshold?;
    get quantityThreshold(): string;
    set quantityThreshold(value: string);
    resetQuantityThreshold(): void;
    get quantityThresholdInput(): string | undefined;
    private _quantityType?;
    get quantityType(): string;
    set quantityType(value: string);
    resetQuantityType(): void;
    get quantityTypeInput(): string | undefined;
    private _timePeriod?;
    get timePeriod(): string;
    set timePeriod(value: string);
    resetTimePeriod(): void;
    get timePeriodInput(): string | undefined;
    private _triggerType?;
    get triggerType(): string;
    set triggerType(value: string);
    resetTriggerType(): void;
    get triggerTypeInput(): string | undefined;
    private _actionConfigurations;
    get actionConfigurations(): BudgetAlertConfigurationsActionConfigurationsList;
    putActionConfigurations(value: BudgetAlertConfigurationsActionConfigurations[] | cdktn.IResolvable): void;
    resetActionConfigurations(): void;
    get actionConfigurationsInput(): cdktn.IResolvable | BudgetAlertConfigurationsActionConfigurations[] | undefined;
}
export declare class BudgetAlertConfigurationsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: BudgetAlertConfigurations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetAlertConfigurationsOutputReference;
}
export interface BudgetFilterTagsValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#operator Budget#operator}
    */
    readonly operator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#values Budget#values}
    */
    readonly values?: string[];
}
export declare function budgetFilterTagsValueToTerraform(struct?: BudgetFilterTagsValueOutputReference | BudgetFilterTagsValue): any;
export declare function budgetFilterTagsValueToHclTerraform(struct?: BudgetFilterTagsValueOutputReference | BudgetFilterTagsValue): any;
export declare class BudgetFilterTagsValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetFilterTagsValue | undefined;
    set internalValue(value: BudgetFilterTagsValue | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export interface BudgetFilterTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#key Budget#key}
    */
    readonly key?: string;
    /**
    * value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#value Budget#value}
    */
    readonly value?: BudgetFilterTagsValue;
}
export declare function budgetFilterTagsToTerraform(struct?: BudgetFilterTags | cdktn.IResolvable): any;
export declare function budgetFilterTagsToHclTerraform(struct?: BudgetFilterTags | cdktn.IResolvable): any;
export declare class BudgetFilterTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetFilterTags | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetFilterTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value;
    get value(): BudgetFilterTagsValueOutputReference;
    putValue(value: BudgetFilterTagsValue): void;
    resetValue(): void;
    get valueInput(): BudgetFilterTagsValue | undefined;
}
export declare class BudgetFilterTagsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: BudgetFilterTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetFilterTagsOutputReference;
}
export interface BudgetFilterWorkspaceId {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#operator Budget#operator}
    */
    readonly operator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#values Budget#values}
    */
    readonly values?: number[];
}
export declare function budgetFilterWorkspaceIdToTerraform(struct?: BudgetFilterWorkspaceIdOutputReference | BudgetFilterWorkspaceId): any;
export declare function budgetFilterWorkspaceIdToHclTerraform(struct?: BudgetFilterWorkspaceIdOutputReference | BudgetFilterWorkspaceId): any;
export declare class BudgetFilterWorkspaceIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetFilterWorkspaceId | undefined;
    set internalValue(value: BudgetFilterWorkspaceId | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): number[];
    set values(value: number[]);
    resetValues(): void;
    get valuesInput(): number[] | undefined;
}
export interface BudgetFilter {
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#tags Budget#tags}
    */
    readonly tags?: BudgetFilterTags[] | cdktn.IResolvable;
    /**
    * workspace_id block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#workspace_id Budget#workspace_id}
    */
    readonly workspaceId?: BudgetFilterWorkspaceId;
}
export declare function budgetFilterToTerraform(struct?: BudgetFilterOutputReference | BudgetFilter): any;
export declare function budgetFilterToHclTerraform(struct?: BudgetFilterOutputReference | BudgetFilter): any;
export declare class BudgetFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BudgetFilter | undefined;
    set internalValue(value: BudgetFilter | undefined);
    private _tags;
    get tags(): BudgetFilterTagsList;
    putTags(value: BudgetFilterTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | BudgetFilterTags[] | undefined;
    private _workspaceId;
    get workspaceId(): BudgetFilterWorkspaceIdOutputReference;
    putWorkspaceId(value: BudgetFilterWorkspaceId): void;
    resetWorkspaceId(): void;
    get workspaceIdInput(): BudgetFilterWorkspaceId | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget databricks_budget}
*/
export declare class Budget extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_budget";
    /**
    * Generates CDKTN code for importing a Budget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Budget to import
    * @param importFromId The id of the existing Budget that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Budget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/budget databricks_budget} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BudgetConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BudgetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _budgetConfigurationId?;
    get budgetConfigurationId(): string;
    set budgetConfigurationId(value: string);
    resetBudgetConfigurationId(): void;
    get budgetConfigurationIdInput(): string | undefined;
    private _createTime?;
    get createTime(): number;
    set createTime(value: number);
    resetCreateTime(): void;
    get createTimeInput(): number | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _updateTime?;
    get updateTime(): number;
    set updateTime(value: number);
    resetUpdateTime(): void;
    get updateTimeInput(): number | undefined;
    private _alertConfigurations;
    get alertConfigurations(): BudgetAlertConfigurationsList;
    putAlertConfigurations(value: BudgetAlertConfigurations[] | cdktn.IResolvable): void;
    resetAlertConfigurations(): void;
    get alertConfigurationsInput(): cdktn.IResolvable | BudgetAlertConfigurations[] | undefined;
    private _filter;
    get filter(): BudgetFilterOutputReference;
    putFilter(value: BudgetFilter): void;
    resetFilter(): void;
    get filterInput(): BudgetFilter | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
