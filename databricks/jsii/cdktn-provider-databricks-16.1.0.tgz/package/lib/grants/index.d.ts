/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GrantsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#catalog Grants#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#credential Grants#credential}
    */
    readonly credential?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#external_location Grants#external_location}
    */
    readonly externalLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#foreign_connection Grants#foreign_connection}
    */
    readonly foreignConnection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#function Grants#function}
    */
    readonly function?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#id Grants#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#metastore Grants#metastore}
    */
    readonly metastore?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#model Grants#model}
    */
    readonly model?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#pipeline Grants#pipeline}
    */
    readonly pipeline?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#recipient Grants#recipient}
    */
    readonly recipient?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#schema Grants#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#share Grants#share}
    */
    readonly share?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#storage_credential Grants#storage_credential}
    */
    readonly storageCredential?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#table Grants#table}
    */
    readonly table?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#volume Grants#volume}
    */
    readonly volume?: string;
    /**
    * grant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#grant Grants#grant}
    */
    readonly grant: GrantsGrant[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#provider_config Grants#provider_config}
    */
    readonly providerConfig?: GrantsProviderConfig;
}
export interface GrantsGrant {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#principal Grants#principal}
    */
    readonly principal: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#privileges Grants#privileges}
    */
    readonly privileges: string[];
}
export declare function grantsGrantToTerraform(struct?: GrantsGrant | cdktn.IResolvable): any;
export declare function grantsGrantToHclTerraform(struct?: GrantsGrant | cdktn.IResolvable): any;
export declare class GrantsGrantOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GrantsGrant | cdktn.IResolvable | undefined;
    set internalValue(value: GrantsGrant | cdktn.IResolvable | undefined);
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _privileges?;
    get privileges(): string[];
    set privileges(value: string[]);
    get privilegesInput(): string[] | undefined;
}
export declare class GrantsGrantList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: GrantsGrant[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GrantsGrantOutputReference;
}
export interface GrantsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#workspace_id Grants#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function grantsProviderConfigToTerraform(struct?: GrantsProviderConfigOutputReference | GrantsProviderConfig): any;
export declare function grantsProviderConfigToHclTerraform(struct?: GrantsProviderConfigOutputReference | GrantsProviderConfig): any;
export declare class GrantsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GrantsProviderConfig | undefined;
    set internalValue(value: GrantsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants databricks_grants}
*/
export declare class Grants extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_grants";
    /**
    * Generates CDKTN code for importing a Grants resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Grants to import
    * @param importFromId The id of the existing Grants that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Grants to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/grants databricks_grants} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GrantsConfig
    */
    constructor(scope: Construct, id: string, config: GrantsConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _credential?;
    get credential(): string;
    set credential(value: string);
    resetCredential(): void;
    get credentialInput(): string | undefined;
    private _externalLocation?;
    get externalLocation(): string;
    set externalLocation(value: string);
    resetExternalLocation(): void;
    get externalLocationInput(): string | undefined;
    private _foreignConnection?;
    get foreignConnection(): string;
    set foreignConnection(value: string);
    resetForeignConnection(): void;
    get foreignConnectionInput(): string | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    resetFunction(): void;
    get functionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastore?;
    get metastore(): string;
    set metastore(value: string);
    resetMetastore(): void;
    get metastoreInput(): string | undefined;
    private _model?;
    get model(): string;
    set model(value: string);
    resetModel(): void;
    get modelInput(): string | undefined;
    private _pipeline?;
    get pipeline(): string;
    set pipeline(value: string);
    resetPipeline(): void;
    get pipelineInput(): string | undefined;
    private _recipient?;
    get recipient(): string;
    set recipient(value: string);
    resetRecipient(): void;
    get recipientInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _share?;
    get share(): string;
    set share(value: string);
    resetShare(): void;
    get shareInput(): string | undefined;
    private _storageCredential?;
    get storageCredential(): string;
    set storageCredential(value: string);
    resetStorageCredential(): void;
    get storageCredentialInput(): string | undefined;
    private _table?;
    get table(): string;
    set table(value: string);
    resetTable(): void;
    get tableInput(): string | undefined;
    private _volume?;
    get volume(): string;
    set volume(value: string);
    resetVolume(): void;
    get volumeInput(): string | undefined;
    private _grant;
    get grant(): GrantsGrantList;
    putGrant(value: GrantsGrant[] | cdktn.IResolvable): void;
    get grantInput(): cdktn.IResolvable | GrantsGrant[] | undefined;
    private _providerConfig;
    get providerConfig(): GrantsProviderConfigOutputReference;
    putProviderConfig(value: GrantsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): GrantsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
