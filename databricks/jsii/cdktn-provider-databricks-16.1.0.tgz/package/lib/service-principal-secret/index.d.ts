/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServicePrincipalSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#create_time ServicePrincipalSecret#create_time}
    */
    readonly createTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#expire_time ServicePrincipalSecret#expire_time}
    */
    readonly expireTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#id ServicePrincipalSecret#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#lifetime ServicePrincipalSecret#lifetime}
    */
    readonly lifetime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#secret ServicePrincipalSecret#secret}
    */
    readonly secret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#secret_hash ServicePrincipalSecret#secret_hash}
    */
    readonly secretHash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#service_principal_id ServicePrincipalSecret#service_principal_id}
    */
    readonly servicePrincipalId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#status ServicePrincipalSecret#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#time_rotating ServicePrincipalSecret#time_rotating}
    */
    readonly timeRotating?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#update_time ServicePrincipalSecret#update_time}
    */
    readonly updateTime?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#provider_config ServicePrincipalSecret#provider_config}
    */
    readonly providerConfig?: ServicePrincipalSecretProviderConfig;
}
export interface ServicePrincipalSecretProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#workspace_id ServicePrincipalSecret#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function servicePrincipalSecretProviderConfigToTerraform(struct?: ServicePrincipalSecretProviderConfigOutputReference | ServicePrincipalSecretProviderConfig): any;
export declare function servicePrincipalSecretProviderConfigToHclTerraform(struct?: ServicePrincipalSecretProviderConfigOutputReference | ServicePrincipalSecretProviderConfig): any;
export declare class ServicePrincipalSecretProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServicePrincipalSecretProviderConfig | undefined;
    set internalValue(value: ServicePrincipalSecretProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret databricks_service_principal_secret}
*/
export declare class ServicePrincipalSecret extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_service_principal_secret";
    /**
    * Generates CDKTN code for importing a ServicePrincipalSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServicePrincipalSecret to import
    * @param importFromId The id of the existing ServicePrincipalSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServicePrincipalSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/service_principal_secret databricks_service_principal_secret} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServicePrincipalSecretConfig
    */
    constructor(scope: Construct, id: string, config: ServicePrincipalSecretConfig);
    private _createTime?;
    get createTime(): string;
    set createTime(value: string);
    resetCreateTime(): void;
    get createTimeInput(): string | undefined;
    private _expireTime?;
    get expireTime(): string;
    set expireTime(value: string);
    resetExpireTime(): void;
    get expireTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lifetime?;
    get lifetime(): string;
    set lifetime(value: string);
    resetLifetime(): void;
    get lifetimeInput(): string | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    resetSecret(): void;
    get secretInput(): string | undefined;
    private _secretHash?;
    get secretHash(): string;
    set secretHash(value: string);
    resetSecretHash(): void;
    get secretHashInput(): string | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _timeRotating?;
    get timeRotating(): string;
    set timeRotating(value: string);
    resetTimeRotating(): void;
    get timeRotatingInput(): string | undefined;
    private _updateTime?;
    get updateTime(): string;
    set updateTime(value: string);
    resetUpdateTime(): void;
    get updateTimeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): ServicePrincipalSecretProviderConfigOutputReference;
    putProviderConfig(value: ServicePrincipalSecretProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ServicePrincipalSecretProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
