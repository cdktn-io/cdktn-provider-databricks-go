/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OnlineStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store#capacity OnlineStore#capacity}
    */
    readonly capacity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store#name OnlineStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store#provider_config OnlineStore#provider_config}
    */
    readonly providerConfig?: OnlineStoreProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store#read_replica_count OnlineStore#read_replica_count}
    */
    readonly readReplicaCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store#usage_policy_id OnlineStore#usage_policy_id}
    */
    readonly usagePolicyId?: string;
}
export interface OnlineStoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store#workspace_id OnlineStore#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function onlineStoreProviderConfigToTerraform(struct?: OnlineStoreProviderConfig | cdktn.IResolvable): any;
export declare function onlineStoreProviderConfigToHclTerraform(struct?: OnlineStoreProviderConfig | cdktn.IResolvable): any;
export declare class OnlineStoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OnlineStoreProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: OnlineStoreProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store databricks_online_store}
*/
export declare class OnlineStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_online_store";
    /**
    * Generates CDKTN code for importing a OnlineStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OnlineStore to import
    * @param importFromId The id of the existing OnlineStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OnlineStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/online_store databricks_online_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OnlineStoreConfig
    */
    constructor(scope: Construct, id: string, config: OnlineStoreConfig);
    private _capacity?;
    get capacity(): string;
    set capacity(value: string);
    get capacityInput(): string | undefined;
    get creationTime(): string;
    get creator(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): OnlineStoreProviderConfigOutputReference;
    putProviderConfig(value: OnlineStoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | OnlineStoreProviderConfig | undefined;
    private _readReplicaCount?;
    get readReplicaCount(): number;
    set readReplicaCount(value: number);
    resetReadReplicaCount(): void;
    get readReplicaCountInput(): number | undefined;
    get state(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
