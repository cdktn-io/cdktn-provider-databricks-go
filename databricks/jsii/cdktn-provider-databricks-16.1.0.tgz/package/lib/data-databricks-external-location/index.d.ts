/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksExternalLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#id DataDatabricksExternalLocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#name DataDatabricksExternalLocation#name}
    */
    readonly name: string;
    /**
    * external_location_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#external_location_info DataDatabricksExternalLocation#external_location_info}
    */
    readonly externalLocationInfo?: DataDatabricksExternalLocationExternalLocationInfo;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#provider_config DataDatabricksExternalLocation#provider_config}
    */
    readonly providerConfig?: DataDatabricksExternalLocationProviderConfig;
}
export interface DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#algorithm DataDatabricksExternalLocation#algorithm}
    */
    readonly algorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#aws_kms_key_arn DataDatabricksExternalLocation#aws_kms_key_arn}
    */
    readonly awsKmsKeyArn?: string;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetailsToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetailsOutputReference | DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetailsToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetailsOutputReference | DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _awsKmsKeyArn?;
    get awsKmsKeyArn(): string;
    set awsKmsKeyArn(value: string);
    resetAwsKmsKeyArn(): void;
    get awsKmsKeyArnInput(): string | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails {
    /**
    * sse_encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#sse_encryption_details DataDatabricksExternalLocation#sse_encryption_details}
    */
    readonly sseEncryptionDetails?: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsOutputReference | DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsOutputReference | DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails | undefined);
    private _sseEncryptionDetails;
    get sseEncryptionDetails(): DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetailsOutputReference;
    putSseEncryptionDetails(value: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails): void;
    resetSseEncryptionDetails(): void;
    get sseEncryptionDetailsInput(): DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsSseEncryptionDetails | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_resource_id DataDatabricksExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#queue_url DataDatabricksExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#resource_group DataDatabricksExternalLocation#resource_group}
    */
    readonly resourceGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#subscription_id DataDatabricksExternalLocation#subscription_id}
    */
    readonly subscriptionId?: string;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqsToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqsToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    resetResourceGroup(): void;
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_resource_id DataDatabricksExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#subscription_name DataDatabricksExternalLocation#subscription_name}
    */
    readonly subscriptionName?: string;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsubToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsubOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsubToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsubOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _subscriptionName?;
    get subscriptionName(): string;
    set subscriptionName(value: string);
    resetSubscriptionName(): void;
    get subscriptionNameInput(): string | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_resource_id DataDatabricksExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#queue_url DataDatabricksExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqsToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqsToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_resource_id DataDatabricksExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#queue_url DataDatabricksExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#resource_group DataDatabricksExternalLocation#resource_group}
    */
    readonly resourceGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#subscription_id DataDatabricksExternalLocation#subscription_id}
    */
    readonly subscriptionId?: string;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqsToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqsToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    resetResourceGroup(): void;
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_resource_id DataDatabricksExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#subscription_name DataDatabricksExternalLocation#subscription_name}
    */
    readonly subscriptionName?: string;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsubToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsubOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsubToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsubOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _subscriptionName?;
    get subscriptionName(): string;
    set subscriptionName(value: string);
    resetSubscriptionName(): void;
    get subscriptionNameInput(): string | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_resource_id DataDatabricksExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#queue_url DataDatabricksExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqsToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqsToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqsOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfoFileEventQueue {
    /**
    * managed_aqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_aqs DataDatabricksExternalLocation#managed_aqs}
    */
    readonly managedAqs?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs;
    /**
    * managed_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_pubsub DataDatabricksExternalLocation#managed_pubsub}
    */
    readonly managedPubsub?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub;
    /**
    * managed_sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#managed_sqs DataDatabricksExternalLocation#managed_sqs}
    */
    readonly managedSqs?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs;
    /**
    * provided_aqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#provided_aqs DataDatabricksExternalLocation#provided_aqs}
    */
    readonly providedAqs?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs;
    /**
    * provided_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#provided_pubsub DataDatabricksExternalLocation#provided_pubsub}
    */
    readonly providedPubsub?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub;
    /**
    * provided_sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#provided_sqs DataDatabricksExternalLocation#provided_sqs}
    */
    readonly providedSqs?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueue): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoFileEventQueueToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueOutputReference | DataDatabricksExternalLocationExternalLocationInfoFileEventQueue): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoFileEventQueueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueue | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueue | undefined);
    private _managedAqs;
    get managedAqs(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqsOutputReference;
    putManagedAqs(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs): void;
    resetManagedAqs(): void;
    get managedAqsInput(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedAqs | undefined;
    private _managedPubsub;
    get managedPubsub(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsubOutputReference;
    putManagedPubsub(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub): void;
    resetManagedPubsub(): void;
    get managedPubsubInput(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedPubsub | undefined;
    private _managedSqs;
    get managedSqs(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqsOutputReference;
    putManagedSqs(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs): void;
    resetManagedSqs(): void;
    get managedSqsInput(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueManagedSqs | undefined;
    private _providedAqs;
    get providedAqs(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqsOutputReference;
    putProvidedAqs(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs): void;
    resetProvidedAqs(): void;
    get providedAqsInput(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedAqs | undefined;
    private _providedPubsub;
    get providedPubsub(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsubOutputReference;
    putProvidedPubsub(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub): void;
    resetProvidedPubsub(): void;
    get providedPubsubInput(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedPubsub | undefined;
    private _providedSqs;
    get providedSqs(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqsOutputReference;
    putProvidedSqs(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs): void;
    resetProvidedSqs(): void;
    get providedSqsInput(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueProvidedSqs | undefined;
}
export interface DataDatabricksExternalLocationExternalLocationInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#browse_only DataDatabricksExternalLocation#browse_only}
    */
    readonly browseOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#comment DataDatabricksExternalLocation#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#created_at DataDatabricksExternalLocation#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#created_by DataDatabricksExternalLocation#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#credential_id DataDatabricksExternalLocation#credential_id}
    */
    readonly credentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#credential_name DataDatabricksExternalLocation#credential_name}
    */
    readonly credentialName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#effective_enable_file_events DataDatabricksExternalLocation#effective_enable_file_events}
    */
    readonly effectiveEnableFileEvents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#enable_file_events DataDatabricksExternalLocation#enable_file_events}
    */
    readonly enableFileEvents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#fallback DataDatabricksExternalLocation#fallback}
    */
    readonly fallback?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#isolation_mode DataDatabricksExternalLocation#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#metastore_id DataDatabricksExternalLocation#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#name DataDatabricksExternalLocation#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#owner DataDatabricksExternalLocation#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#read_only DataDatabricksExternalLocation#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#updated_at DataDatabricksExternalLocation#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#updated_by DataDatabricksExternalLocation#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#url DataDatabricksExternalLocation#url}
    */
    readonly url?: string;
    /**
    * encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#encryption_details DataDatabricksExternalLocation#encryption_details}
    */
    readonly encryptionDetails?: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails;
    /**
    * file_event_queue block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#file_event_queue DataDatabricksExternalLocation#file_event_queue}
    */
    readonly fileEventQueue?: DataDatabricksExternalLocationExternalLocationInfoFileEventQueue;
}
export declare function dataDatabricksExternalLocationExternalLocationInfoToTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoOutputReference | DataDatabricksExternalLocationExternalLocationInfo): any;
export declare function dataDatabricksExternalLocationExternalLocationInfoToHclTerraform(struct?: DataDatabricksExternalLocationExternalLocationInfoOutputReference | DataDatabricksExternalLocationExternalLocationInfo): any;
export declare class DataDatabricksExternalLocationExternalLocationInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationExternalLocationInfo | undefined;
    set internalValue(value: DataDatabricksExternalLocationExternalLocationInfo | undefined);
    private _browseOnly?;
    get browseOnly(): boolean | cdktn.IResolvable;
    set browseOnly(value: boolean | cdktn.IResolvable);
    resetBrowseOnly(): void;
    get browseOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    resetCredentialId(): void;
    get credentialIdInput(): string | undefined;
    private _credentialName?;
    get credentialName(): string;
    set credentialName(value: string);
    resetCredentialName(): void;
    get credentialNameInput(): string | undefined;
    private _effectiveEnableFileEvents?;
    get effectiveEnableFileEvents(): boolean | cdktn.IResolvable;
    set effectiveEnableFileEvents(value: boolean | cdktn.IResolvable);
    resetEffectiveEnableFileEvents(): void;
    get effectiveEnableFileEventsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableFileEvents?;
    get enableFileEvents(): boolean | cdktn.IResolvable;
    set enableFileEvents(value: boolean | cdktn.IResolvable);
    resetEnableFileEvents(): void;
    get enableFileEventsInput(): boolean | cdktn.IResolvable | undefined;
    private _fallback?;
    get fallback(): boolean | cdktn.IResolvable;
    set fallback(value: boolean | cdktn.IResolvable);
    resetFallback(): void;
    get fallbackInput(): boolean | cdktn.IResolvable | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _encryptionDetails;
    get encryptionDetails(): DataDatabricksExternalLocationExternalLocationInfoEncryptionDetailsOutputReference;
    putEncryptionDetails(value: DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails): void;
    resetEncryptionDetails(): void;
    get encryptionDetailsInput(): DataDatabricksExternalLocationExternalLocationInfoEncryptionDetails | undefined;
    private _fileEventQueue;
    get fileEventQueue(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueueOutputReference;
    putFileEventQueue(value: DataDatabricksExternalLocationExternalLocationInfoFileEventQueue): void;
    resetFileEventQueue(): void;
    get fileEventQueueInput(): DataDatabricksExternalLocationExternalLocationInfoFileEventQueue | undefined;
}
export interface DataDatabricksExternalLocationProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#workspace_id DataDatabricksExternalLocation#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksExternalLocationProviderConfigToTerraform(struct?: DataDatabricksExternalLocationProviderConfigOutputReference | DataDatabricksExternalLocationProviderConfig): any;
export declare function dataDatabricksExternalLocationProviderConfigToHclTerraform(struct?: DataDatabricksExternalLocationProviderConfigOutputReference | DataDatabricksExternalLocationProviderConfig): any;
export declare class DataDatabricksExternalLocationProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalLocationProviderConfig | undefined;
    set internalValue(value: DataDatabricksExternalLocationProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location databricks_external_location}
*/
export declare class DataDatabricksExternalLocation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_external_location";
    /**
    * Generates CDKTN code for importing a DataDatabricksExternalLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksExternalLocation to import
    * @param importFromId The id of the existing DataDatabricksExternalLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksExternalLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/external_location databricks_external_location} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksExternalLocationConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksExternalLocationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _externalLocationInfo;
    get externalLocationInfo(): DataDatabricksExternalLocationExternalLocationInfoOutputReference;
    putExternalLocationInfo(value: DataDatabricksExternalLocationExternalLocationInfo): void;
    resetExternalLocationInfo(): void;
    get externalLocationInfoInput(): DataDatabricksExternalLocationExternalLocationInfo | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksExternalLocationProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksExternalLocationProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksExternalLocationProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
