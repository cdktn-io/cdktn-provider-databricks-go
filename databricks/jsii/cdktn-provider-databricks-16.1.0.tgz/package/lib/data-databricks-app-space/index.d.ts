/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAppSpaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#name DataDatabricksAppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#provider_config DataDatabricksAppSpace#provider_config}
    */
    readonly providerConfig?: DataDatabricksAppSpaceProviderConfig;
}
export interface DataDatabricksAppSpaceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#workspace_id DataDatabricksAppSpace#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function dataDatabricksAppSpaceProviderConfigToTerraform(struct?: DataDatabricksAppSpaceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceProviderConfigToHclTerraform(struct?: DataDatabricksAppSpaceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesApp {
}
export declare function dataDatabricksAppSpaceResourcesAppToTerraform(struct?: DataDatabricksAppSpaceResourcesApp | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesAppToHclTerraform(struct?: DataDatabricksAppSpaceResourcesApp | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesApp | cdktn.IResolvable | undefined);
}
export interface DataDatabricksAppSpaceResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#database_name DataDatabricksAppSpace#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#instance_name DataDatabricksAppSpace#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpaceResourcesDatabaseToTerraform(struct?: DataDatabricksAppSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesDatabaseToHclTerraform(struct?: DataDatabricksAppSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#experiment_id DataDatabricksAppSpace#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpaceResourcesExperimentToTerraform(struct?: DataDatabricksAppSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesExperimentToHclTerraform(struct?: DataDatabricksAppSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#name DataDatabricksAppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#space_id DataDatabricksAppSpace#space_id}
    */
    readonly spaceId: string;
}
export declare function dataDatabricksAppSpaceResourcesGenieSpaceToTerraform(struct?: DataDatabricksAppSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesGenieSpaceToHclTerraform(struct?: DataDatabricksAppSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#id DataDatabricksAppSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpaceResourcesJobToTerraform(struct?: DataDatabricksAppSpaceResourcesJob | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesJobToHclTerraform(struct?: DataDatabricksAppSpaceResourcesJob | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesPostgres {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#branch DataDatabricksAppSpace#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#database DataDatabricksAppSpace#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission?: string;
}
export declare function dataDatabricksAppSpaceResourcesPostgresToTerraform(struct?: DataDatabricksAppSpaceResourcesPostgres | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesPostgresToHclTerraform(struct?: DataDatabricksAppSpaceResourcesPostgres | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesPostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesPostgres | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesPostgres | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#key DataDatabricksAppSpace#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#scope DataDatabricksAppSpace#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksAppSpaceResourcesSecretToTerraform(struct?: DataDatabricksAppSpaceResourcesSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesSecretToHclTerraform(struct?: DataDatabricksAppSpaceResourcesSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#name DataDatabricksAppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpaceResourcesServingEndpointToTerraform(struct?: DataDatabricksAppSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesServingEndpointToHclTerraform(struct?: DataDatabricksAppSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#id DataDatabricksAppSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
}
export declare function dataDatabricksAppSpaceResourcesSqlWarehouseToTerraform(struct?: DataDatabricksAppSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesSqlWarehouseToHclTerraform(struct?: DataDatabricksAppSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#permission DataDatabricksAppSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#securable_full_name DataDatabricksAppSpace#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#securable_type DataDatabricksAppSpace#securable_type}
    */
    readonly securableType: string;
}
export declare function dataDatabricksAppSpaceResourcesUcSecurableToTerraform(struct?: DataDatabricksAppSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare function dataDatabricksAppSpaceResourcesUcSecurableToHclTerraform(struct?: DataDatabricksAppSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare class DataDatabricksAppSpaceResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAppSpaceResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface DataDatabricksAppSpaceResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#app DataDatabricksAppSpace#app}
    */
    readonly app?: DataDatabricksAppSpaceResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#database DataDatabricksAppSpace#database}
    */
    readonly database?: DataDatabricksAppSpaceResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#description DataDatabricksAppSpace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#experiment DataDatabricksAppSpace#experiment}
    */
    readonly experiment?: DataDatabricksAppSpaceResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#genie_space DataDatabricksAppSpace#genie_space}
    */
    readonly genieSpace?: DataDatabricksAppSpaceResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#job DataDatabricksAppSpace#job}
    */
    readonly job?: DataDatabricksAppSpaceResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#name DataDatabricksAppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#postgres DataDatabricksAppSpace#postgres}
    */
    readonly postgres?: DataDatabricksAppSpaceResourcesPostgres;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#secret DataDatabricksAppSpace#secret}
    */
    readonly secret?: DataDatabricksAppSpaceResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#serving_endpoint DataDatabricksAppSpace#serving_endpoint}
    */
    readonly servingEndpoint?: DataDatabricksAppSpaceResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#sql_warehouse DataDatabricksAppSpace#sql_warehouse}
    */
    readonly sqlWarehouse?: DataDatabricksAppSpaceResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#uc_securable DataDatabricksAppSpace#uc_securable}
    */
    readonly ucSecurable?: DataDatabricksAppSpaceResourcesUcSecurable;
}
export declare function dataDatabricksAppSpaceResourcesToTerraform(struct?: DataDatabricksAppSpaceResources): any;
export declare function dataDatabricksAppSpaceResourcesToHclTerraform(struct?: DataDatabricksAppSpaceResources): any;
export declare class DataDatabricksAppSpaceResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAppSpaceResources | undefined;
    set internalValue(value: DataDatabricksAppSpaceResources | undefined);
    private _app;
    get app(): DataDatabricksAppSpaceResourcesAppOutputReference;
    putApp(value: DataDatabricksAppSpaceResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesApp | undefined;
    private _database;
    get database(): DataDatabricksAppSpaceResourcesDatabaseOutputReference;
    putDatabase(value: DataDatabricksAppSpaceResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): DataDatabricksAppSpaceResourcesExperimentOutputReference;
    putExperiment(value: DataDatabricksAppSpaceResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): DataDatabricksAppSpaceResourcesGenieSpaceOutputReference;
    putGenieSpace(value: DataDatabricksAppSpaceResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesGenieSpace | undefined;
    private _job;
    get job(): DataDatabricksAppSpaceResourcesJobOutputReference;
    putJob(value: DataDatabricksAppSpaceResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _postgres;
    get postgres(): DataDatabricksAppSpaceResourcesPostgresOutputReference;
    putPostgres(value: DataDatabricksAppSpaceResourcesPostgres): void;
    resetPostgres(): void;
    get postgresInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesPostgres | undefined;
    private _secret;
    get secret(): DataDatabricksAppSpaceResourcesSecretOutputReference;
    putSecret(value: DataDatabricksAppSpaceResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): DataDatabricksAppSpaceResourcesServingEndpointOutputReference;
    putServingEndpoint(value: DataDatabricksAppSpaceResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): DataDatabricksAppSpaceResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: DataDatabricksAppSpaceResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): DataDatabricksAppSpaceResourcesUcSecurableOutputReference;
    putUcSecurable(value: DataDatabricksAppSpaceResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | DataDatabricksAppSpaceResourcesUcSecurable | undefined;
}
export declare class DataDatabricksAppSpaceResourcesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataDatabricksAppSpaceResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAppSpaceResourcesOutputReference;
}
export interface DataDatabricksAppSpaceStatus {
}
export declare function dataDatabricksAppSpaceStatusToTerraform(struct?: DataDatabricksAppSpaceStatus): any;
export declare function dataDatabricksAppSpaceStatusToHclTerraform(struct?: DataDatabricksAppSpaceStatus): any;
export declare class DataDatabricksAppSpaceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAppSpaceStatus | undefined;
    set internalValue(value: DataDatabricksAppSpaceStatus | undefined);
    get message(): string;
    get state(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space databricks_app_space}
*/
export declare class DataDatabricksAppSpace extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_app_space";
    /**
    * Generates CDKTN code for importing a DataDatabricksAppSpace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAppSpace to import
    * @param importFromId The id of the existing DataDatabricksAppSpace that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAppSpace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/data-sources/app_space databricks_app_space} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAppSpaceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAppSpaceConfig);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAppSpaceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAppSpaceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAppSpaceProviderConfig | undefined;
    private _resources;
    get resources(): DataDatabricksAppSpaceResourcesList;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _status;
    get status(): DataDatabricksAppSpaceStatusOutputReference;
    get updateTime(): string;
    get updater(): string;
    get usagePolicyId(): string;
    get userApiScopes(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
