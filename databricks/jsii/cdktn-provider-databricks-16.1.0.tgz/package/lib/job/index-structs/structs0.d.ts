/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface JobContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pause_status Job#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#task_retry_mode Job#task_retry_mode}
    */
    readonly taskRetryMode?: string;
}
export declare function jobContinuousToTerraform(struct?: JobContinuousOutputReference | JobContinuous): any;
export declare function jobContinuousToHclTerraform(struct?: JobContinuousOutputReference | JobContinuous): any;
export declare class JobContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobContinuous | undefined;
    set internalValue(value: JobContinuous | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _taskRetryMode?;
    get taskRetryMode(): string;
    set taskRetryMode(value: string);
    resetTaskRetryMode(): void;
    get taskRetryModeInput(): string | undefined;
}
export interface JobDbtTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#catalog Job#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#commands Job#commands}
    */
    readonly commands: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#profiles_directory Job#profiles_directory}
    */
    readonly profilesDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#project_directory Job#project_directory}
    */
    readonly projectDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#schema Job#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function jobDbtTaskToTerraform(struct?: JobDbtTaskOutputReference | JobDbtTask): any;
export declare function jobDbtTaskToHclTerraform(struct?: JobDbtTaskOutputReference | JobDbtTask): any;
export declare class JobDbtTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobDbtTask | undefined;
    set internalValue(value: JobDbtTask | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    get commandsInput(): string[] | undefined;
    private _profilesDirectory?;
    get profilesDirectory(): string;
    set profilesDirectory(value: string);
    resetProfilesDirectory(): void;
    get profilesDirectoryInput(): string | undefined;
    private _projectDirectory?;
    get projectDirectory(): string;
    set projectDirectory(value: string);
    resetProjectDirectory(): void;
    get projectDirectoryInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface JobDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#kind Job#kind}
    */
    readonly kind: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#metadata_file_path Job#metadata_file_path}
    */
    readonly metadataFilePath?: string;
}
export declare function jobDeploymentToTerraform(struct?: JobDeploymentOutputReference | JobDeployment): any;
export declare function jobDeploymentToHclTerraform(struct?: JobDeploymentOutputReference | JobDeployment): any;
export declare class JobDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobDeployment | undefined;
    set internalValue(value: JobDeployment | undefined);
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _metadataFilePath?;
    get metadataFilePath(): string;
    set metadataFilePath(value: string);
    resetMetadataFilePath(): void;
    get metadataFilePathInput(): string | undefined;
}
export interface JobEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: string[];
}
export declare function jobEmailNotificationsToTerraform(struct?: JobEmailNotificationsOutputReference | JobEmailNotifications): any;
export declare function jobEmailNotificationsToHclTerraform(struct?: JobEmailNotificationsOutputReference | JobEmailNotifications): any;
export declare class JobEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobEmailNotifications | undefined;
    set internalValue(value: JobEmailNotifications | undefined);
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _onDurationWarningThresholdExceeded?;
    get onDurationWarningThresholdExceeded(): string[];
    set onDurationWarningThresholdExceeded(value: string[]);
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): string[] | undefined;
    private _onFailure?;
    get onFailure(): string[];
    set onFailure(value: string[]);
    resetOnFailure(): void;
    get onFailureInput(): string[] | undefined;
    private _onStart?;
    get onStart(): string[];
    set onStart(value: string[]);
    resetOnStart(): void;
    get onStartInput(): string[] | undefined;
    private _onStreamingBacklogExceeded?;
    get onStreamingBacklogExceeded(): string[];
    set onStreamingBacklogExceeded(value: string[]);
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): string[] | undefined;
    private _onSuccess?;
    get onSuccess(): string[];
    set onSuccess(value: string[]);
    resetOnSuccess(): void;
    get onSuccessInput(): string[] | undefined;
}
export interface JobEnvironmentSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#base_environment Job#base_environment}
    */
    readonly baseEnvironment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#client Job#client}
    */
    readonly client?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dependencies Job#dependencies}
    */
    readonly dependencies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#environment_version Job#environment_version}
    */
    readonly environmentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#java_dependencies Job#java_dependencies}
    */
    readonly javaDependencies?: string[];
}
export declare function jobEnvironmentSpecToTerraform(struct?: JobEnvironmentSpecOutputReference | JobEnvironmentSpec): any;
export declare function jobEnvironmentSpecToHclTerraform(struct?: JobEnvironmentSpecOutputReference | JobEnvironmentSpec): any;
export declare class JobEnvironmentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobEnvironmentSpec | undefined;
    set internalValue(value: JobEnvironmentSpec | undefined);
    private _baseEnvironment?;
    get baseEnvironment(): string;
    set baseEnvironment(value: string);
    resetBaseEnvironment(): void;
    get baseEnvironmentInput(): string | undefined;
    private _client?;
    get client(): string;
    set client(value: string);
    resetClient(): void;
    get clientInput(): string | undefined;
    private _dependencies?;
    get dependencies(): string[];
    set dependencies(value: string[]);
    resetDependencies(): void;
    get dependenciesInput(): string[] | undefined;
    private _environmentVersion?;
    get environmentVersion(): string;
    set environmentVersion(value: string);
    resetEnvironmentVersion(): void;
    get environmentVersionInput(): string | undefined;
    private _javaDependencies?;
    get javaDependencies(): string[];
    set javaDependencies(value: string[]);
    resetJavaDependencies(): void;
    get javaDependenciesInput(): string[] | undefined;
}
export interface JobEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#environment_key Job#environment_key}
    */
    readonly environmentKey: string;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spec Job#spec}
    */
    readonly spec?: JobEnvironmentSpec;
}
export declare function jobEnvironmentToTerraform(struct?: JobEnvironment | cdktn.IResolvable): any;
export declare function jobEnvironmentToHclTerraform(struct?: JobEnvironment | cdktn.IResolvable): any;
export declare class JobEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: JobEnvironment | cdktn.IResolvable | undefined);
    private _environmentKey?;
    get environmentKey(): string;
    set environmentKey(value: string);
    get environmentKeyInput(): string | undefined;
    private _spec;
    get spec(): JobEnvironmentSpecOutputReference;
    putSpec(value: JobEnvironmentSpec): void;
    resetSpec(): void;
    get specInput(): JobEnvironmentSpec | undefined;
}
export declare class JobEnvironmentList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobEnvironmentOutputReference;
}
export interface JobGitSourceGitSnapshot {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#used_commit Job#used_commit}
    */
    readonly usedCommit?: string;
}
export declare function jobGitSourceGitSnapshotToTerraform(struct?: JobGitSourceGitSnapshotOutputReference | JobGitSourceGitSnapshot): any;
export declare function jobGitSourceGitSnapshotToHclTerraform(struct?: JobGitSourceGitSnapshotOutputReference | JobGitSourceGitSnapshot): any;
export declare class JobGitSourceGitSnapshotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobGitSourceGitSnapshot | undefined;
    set internalValue(value: JobGitSourceGitSnapshot | undefined);
    private _usedCommit?;
    get usedCommit(): string;
    set usedCommit(value: string);
    resetUsedCommit(): void;
    get usedCommitInput(): string | undefined;
}
export interface JobGitSourceJobSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dirty_state Job#dirty_state}
    */
    readonly dirtyState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#import_from_git_branch Job#import_from_git_branch}
    */
    readonly importFromGitBranch: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#job_config_path Job#job_config_path}
    */
    readonly jobConfigPath: string;
}
export declare function jobGitSourceJobSourceToTerraform(struct?: JobGitSourceJobSourceOutputReference | JobGitSourceJobSource): any;
export declare function jobGitSourceJobSourceToHclTerraform(struct?: JobGitSourceJobSourceOutputReference | JobGitSourceJobSource): any;
export declare class JobGitSourceJobSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobGitSourceJobSource | undefined;
    set internalValue(value: JobGitSourceJobSource | undefined);
    private _dirtyState?;
    get dirtyState(): string;
    set dirtyState(value: string);
    resetDirtyState(): void;
    get dirtyStateInput(): string | undefined;
    private _importFromGitBranch?;
    get importFromGitBranch(): string;
    set importFromGitBranch(value: string);
    get importFromGitBranchInput(): string | undefined;
    private _jobConfigPath?;
    get jobConfigPath(): string;
    set jobConfigPath(value: string);
    get jobConfigPathInput(): string | undefined;
}
export interface JobGitSourceSparseCheckout {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#patterns Job#patterns}
    */
    readonly patterns?: string[];
}
export declare function jobGitSourceSparseCheckoutToTerraform(struct?: JobGitSourceSparseCheckoutOutputReference | JobGitSourceSparseCheckout): any;
export declare function jobGitSourceSparseCheckoutToHclTerraform(struct?: JobGitSourceSparseCheckoutOutputReference | JobGitSourceSparseCheckout): any;
export declare class JobGitSourceSparseCheckoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobGitSourceSparseCheckout | undefined;
    set internalValue(value: JobGitSourceSparseCheckout | undefined);
    private _patterns?;
    get patterns(): string[];
    set patterns(value: string[]);
    resetPatterns(): void;
    get patternsInput(): string[] | undefined;
}
export interface JobGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#branch Job#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#commit Job#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#provider Job#provider}
    */
    readonly provider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#tag Job#tag}
    */
    readonly tag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * git_snapshot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#git_snapshot Job#git_snapshot}
    */
    readonly gitSnapshot?: JobGitSourceGitSnapshot;
    /**
    * job_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#job_source Job#job_source}
    */
    readonly jobSource?: JobGitSourceJobSource;
    /**
    * sparse_checkout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#sparse_checkout Job#sparse_checkout}
    */
    readonly sparseCheckout?: JobGitSourceSparseCheckout;
}
export declare function jobGitSourceToTerraform(struct?: JobGitSourceOutputReference | JobGitSource): any;
export declare function jobGitSourceToHclTerraform(struct?: JobGitSourceOutputReference | JobGitSource): any;
export declare class JobGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobGitSource | undefined;
    set internalValue(value: JobGitSource | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _gitSnapshot;
    get gitSnapshot(): JobGitSourceGitSnapshotOutputReference;
    putGitSnapshot(value: JobGitSourceGitSnapshot): void;
    resetGitSnapshot(): void;
    get gitSnapshotInput(): JobGitSourceGitSnapshot | undefined;
    private _jobSource;
    get jobSource(): JobGitSourceJobSourceOutputReference;
    putJobSource(value: JobGitSourceJobSource): void;
    resetJobSource(): void;
    get jobSourceInput(): JobGitSourceJobSource | undefined;
    private _sparseCheckout;
    get sparseCheckout(): JobGitSourceSparseCheckoutOutputReference;
    putSparseCheckout(value: JobGitSourceSparseCheckout): void;
    resetSparseCheckout(): void;
    get sparseCheckoutInput(): JobGitSourceSparseCheckout | undefined;
}
export interface JobHealthRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#metric Job#metric}
    */
    readonly metric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#op Job#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#value Job#value}
    */
    readonly value: number;
}
export declare function jobHealthRulesToTerraform(struct?: JobHealthRules | cdktn.IResolvable): any;
export declare function jobHealthRulesToHclTerraform(struct?: JobHealthRules | cdktn.IResolvable): any;
export declare class JobHealthRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobHealthRules | cdktn.IResolvable | undefined;
    set internalValue(value: JobHealthRules | cdktn.IResolvable | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class JobHealthRulesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobHealthRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobHealthRulesOutputReference;
}
export interface JobHealth {
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#rules Job#rules}
    */
    readonly rules: JobHealthRules[] | cdktn.IResolvable;
}
export declare function jobHealthToTerraform(struct?: JobHealthOutputReference | JobHealth): any;
export declare function jobHealthToHclTerraform(struct?: JobHealthOutputReference | JobHealth): any;
export declare class JobHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobHealth | undefined;
    set internalValue(value: JobHealth | undefined);
    private _rules;
    get rules(): JobHealthRulesList;
    putRules(value: JobHealthRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | JobHealthRules[] | undefined;
}
export interface JobJobClusterNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#max_workers Job#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#min_workers Job#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function jobJobClusterNewClusterAutoscaleToTerraform(struct?: JobJobClusterNewClusterAutoscaleOutputReference | JobJobClusterNewClusterAutoscale): any;
export declare function jobJobClusterNewClusterAutoscaleToHclTerraform(struct?: JobJobClusterNewClusterAutoscaleOutputReference | JobJobClusterNewClusterAutoscale): any;
export declare class JobJobClusterNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterAutoscale | undefined;
    set internalValue(value: JobJobClusterNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface JobJobClusterNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_count Job#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_iops Job#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_size Job#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_throughput Job#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_type Job#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#instance_profile_arn Job#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spot_bid_price_percent Job#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobJobClusterNewClusterAwsAttributesToTerraform(struct?: JobJobClusterNewClusterAwsAttributesOutputReference | JobJobClusterNewClusterAwsAttributes): any;
export declare function jobJobClusterNewClusterAwsAttributesToHclTerraform(struct?: JobJobClusterNewClusterAwsAttributesOutputReference | JobJobClusterNewClusterAwsAttributes): any;
export declare class JobJobClusterNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterAwsAttributes | undefined;
    set internalValue(value: JobJobClusterNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#log_analytics_primary_key Job#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#log_analytics_workspace_id Job#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function jobJobClusterNewClusterAzureAttributesLogAnalyticsInfoToTerraform(struct?: JobJobClusterNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare function jobJobClusterNewClusterAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: JobJobClusterNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare class JobJobClusterNewClusterAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface JobJobClusterNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spot_bid_max_price Job#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#log_analytics_info Job#log_analytics_info}
    */
    readonly logAnalyticsInfo?: JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo;
}
export declare function jobJobClusterNewClusterAzureAttributesToTerraform(struct?: JobJobClusterNewClusterAzureAttributesOutputReference | JobJobClusterNewClusterAzureAttributes): any;
export declare function jobJobClusterNewClusterAzureAttributesToHclTerraform(struct?: JobJobClusterNewClusterAzureAttributesOutputReference | JobJobClusterNewClusterAzureAttributes): any;
export declare class JobJobClusterNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterAzureAttributes | undefined;
    set internalValue(value: JobJobClusterNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): JobJobClusterNewClusterAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): JobJobClusterNewClusterAzureAttributesLogAnalyticsInfo | undefined;
}
export interface JobJobClusterNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterClusterLogConfDbfsToTerraform(struct?: JobJobClusterNewClusterClusterLogConfDbfsOutputReference | JobJobClusterNewClusterClusterLogConfDbfs): any;
export declare function jobJobClusterNewClusterClusterLogConfDbfsToHclTerraform(struct?: JobJobClusterNewClusterClusterLogConfDbfsOutputReference | JobJobClusterNewClusterClusterLogConfDbfs): any;
export declare class JobJobClusterNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: JobJobClusterNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobJobClusterNewClusterClusterLogConfS3ToTerraform(struct?: JobJobClusterNewClusterClusterLogConfS3OutputReference | JobJobClusterNewClusterClusterLogConfS3): any;
export declare function jobJobClusterNewClusterClusterLogConfS3ToHclTerraform(struct?: JobJobClusterNewClusterClusterLogConfS3OutputReference | JobJobClusterNewClusterClusterLogConfS3): any;
export declare class JobJobClusterNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: JobJobClusterNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobJobClusterNewClusterClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterClusterLogConfVolumesToTerraform(struct?: JobJobClusterNewClusterClusterLogConfVolumesOutputReference | JobJobClusterNewClusterClusterLogConfVolumes): any;
export declare function jobJobClusterNewClusterClusterLogConfVolumesToHclTerraform(struct?: JobJobClusterNewClusterClusterLogConfVolumesOutputReference | JobJobClusterNewClusterClusterLogConfVolumes): any;
export declare class JobJobClusterNewClusterClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterClusterLogConfVolumes | undefined;
    set internalValue(value: JobJobClusterNewClusterClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobJobClusterNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobJobClusterNewClusterClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobJobClusterNewClusterClusterLogConfVolumes;
}
export declare function jobJobClusterNewClusterClusterLogConfToTerraform(struct?: JobJobClusterNewClusterClusterLogConfOutputReference | JobJobClusterNewClusterClusterLogConf): any;
export declare function jobJobClusterNewClusterClusterLogConfToHclTerraform(struct?: JobJobClusterNewClusterClusterLogConfOutputReference | JobJobClusterNewClusterClusterLogConf): any;
export declare class JobJobClusterNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterClusterLogConf | undefined;
    set internalValue(value: JobJobClusterNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): JobJobClusterNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: JobJobClusterNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobJobClusterNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): JobJobClusterNewClusterClusterLogConfS3OutputReference;
    putS3(value: JobJobClusterNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): JobJobClusterNewClusterClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): JobJobClusterNewClusterClusterLogConfVolumesOutputReference;
    putVolumes(value: JobJobClusterNewClusterClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobJobClusterNewClusterClusterLogConfVolumes | undefined;
}
export interface JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#mount_options Job#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#server_address Job#server_address}
    */
    readonly serverAddress: string;
}
export declare function jobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function jobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface JobJobClusterNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#local_mount_dir_path Job#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#remote_mount_dir_path Job#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#network_filesystem_info Job#network_filesystem_info}
    */
    readonly networkFilesystemInfo: JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function jobJobClusterNewClusterClusterMountInfoToTerraform(struct?: JobJobClusterNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function jobJobClusterNewClusterClusterMountInfoToHclTerraform(struct?: JobJobClusterNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class JobJobClusterNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobJobClusterNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: JobJobClusterNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): JobJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class JobJobClusterNewClusterClusterMountInfoList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobJobClusterNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobJobClusterNewClusterClusterMountInfoOutputReference;
}
export interface JobJobClusterNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#password Job#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#username Job#username}
    */
    readonly username: string;
}
export declare function jobJobClusterNewClusterDockerImageBasicAuthToTerraform(struct?: JobJobClusterNewClusterDockerImageBasicAuthOutputReference | JobJobClusterNewClusterDockerImageBasicAuth): any;
export declare function jobJobClusterNewClusterDockerImageBasicAuthToHclTerraform(struct?: JobJobClusterNewClusterDockerImageBasicAuthOutputReference | JobJobClusterNewClusterDockerImageBasicAuth): any;
export declare class JobJobClusterNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: JobJobClusterNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface JobJobClusterNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#basic_auth Job#basic_auth}
    */
    readonly basicAuth?: JobJobClusterNewClusterDockerImageBasicAuth;
}
export declare function jobJobClusterNewClusterDockerImageToTerraform(struct?: JobJobClusterNewClusterDockerImageOutputReference | JobJobClusterNewClusterDockerImage): any;
export declare function jobJobClusterNewClusterDockerImageToHclTerraform(struct?: JobJobClusterNewClusterDockerImageOutputReference | JobJobClusterNewClusterDockerImage): any;
export declare class JobJobClusterNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterDockerImage | undefined;
    set internalValue(value: JobJobClusterNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): JobJobClusterNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: JobJobClusterNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): JobJobClusterNewClusterDockerImageBasicAuth | undefined;
}
export interface JobJobClusterNewClusterDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobJobClusterNewClusterDriverNodeTypeFlexibilityToTerraform(struct?: JobJobClusterNewClusterDriverNodeTypeFlexibilityOutputReference | JobJobClusterNewClusterDriverNodeTypeFlexibility): any;
export declare function jobJobClusterNewClusterDriverNodeTypeFlexibilityToHclTerraform(struct?: JobJobClusterNewClusterDriverNodeTypeFlexibilityOutputReference | JobJobClusterNewClusterDriverNodeTypeFlexibility): any;
export declare class JobJobClusterNewClusterDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterDriverNodeTypeFlexibility | undefined;
    set internalValue(value: JobJobClusterNewClusterDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobJobClusterNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#boot_disk_size Job#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#google_service_account Job#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#local_ssd_count Job#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#use_preemptible_executors Job#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobJobClusterNewClusterGcpAttributesToTerraform(struct?: JobJobClusterNewClusterGcpAttributesOutputReference | JobJobClusterNewClusterGcpAttributes): any;
export declare function jobJobClusterNewClusterGcpAttributesToHclTerraform(struct?: JobJobClusterNewClusterGcpAttributesOutputReference | JobJobClusterNewClusterGcpAttributes): any;
export declare class JobJobClusterNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterGcpAttributes | undefined;
    set internalValue(value: JobJobClusterNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterInitScriptsAbfssToTerraform(struct?: JobJobClusterNewClusterInitScriptsAbfssOutputReference | JobJobClusterNewClusterInitScriptsAbfss): any;
export declare function jobJobClusterNewClusterInitScriptsAbfssToHclTerraform(struct?: JobJobClusterNewClusterInitScriptsAbfssOutputReference | JobJobClusterNewClusterInitScriptsAbfss): any;
export declare class JobJobClusterNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterInitScriptsDbfsToTerraform(struct?: JobJobClusterNewClusterInitScriptsDbfsOutputReference | JobJobClusterNewClusterInitScriptsDbfs): any;
export declare function jobJobClusterNewClusterInitScriptsDbfsToHclTerraform(struct?: JobJobClusterNewClusterInitScriptsDbfsOutputReference | JobJobClusterNewClusterInitScriptsDbfs): any;
export declare class JobJobClusterNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterInitScriptsFileToTerraform(struct?: JobJobClusterNewClusterInitScriptsFileOutputReference | JobJobClusterNewClusterInitScriptsFile): any;
export declare function jobJobClusterNewClusterInitScriptsFileToHclTerraform(struct?: JobJobClusterNewClusterInitScriptsFileOutputReference | JobJobClusterNewClusterInitScriptsFile): any;
export declare class JobJobClusterNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterInitScriptsFile | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterInitScriptsGcsToTerraform(struct?: JobJobClusterNewClusterInitScriptsGcsOutputReference | JobJobClusterNewClusterInitScriptsGcs): any;
export declare function jobJobClusterNewClusterInitScriptsGcsToHclTerraform(struct?: JobJobClusterNewClusterInitScriptsGcsOutputReference | JobJobClusterNewClusterInitScriptsGcs): any;
export declare class JobJobClusterNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterInitScriptsGcs | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobJobClusterNewClusterInitScriptsS3ToTerraform(struct?: JobJobClusterNewClusterInitScriptsS3OutputReference | JobJobClusterNewClusterInitScriptsS3): any;
export declare function jobJobClusterNewClusterInitScriptsS3ToHclTerraform(struct?: JobJobClusterNewClusterInitScriptsS3OutputReference | JobJobClusterNewClusterInitScriptsS3): any;
export declare class JobJobClusterNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterInitScriptsS3 | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterInitScriptsVolumesToTerraform(struct?: JobJobClusterNewClusterInitScriptsVolumesOutputReference | JobJobClusterNewClusterInitScriptsVolumes): any;
export declare function jobJobClusterNewClusterInitScriptsVolumesToHclTerraform(struct?: JobJobClusterNewClusterInitScriptsVolumesOutputReference | JobJobClusterNewClusterInitScriptsVolumes): any;
export declare class JobJobClusterNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobJobClusterNewClusterInitScriptsWorkspaceToTerraform(struct?: JobJobClusterNewClusterInitScriptsWorkspaceOutputReference | JobJobClusterNewClusterInitScriptsWorkspace): any;
export declare function jobJobClusterNewClusterInitScriptsWorkspaceToHclTerraform(struct?: JobJobClusterNewClusterInitScriptsWorkspaceOutputReference | JobJobClusterNewClusterInitScriptsWorkspace): any;
export declare class JobJobClusterNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobJobClusterNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#abfss Job#abfss}
    */
    readonly abfss?: JobJobClusterNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobJobClusterNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobJobClusterNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#gcs Job#gcs}
    */
    readonly gcs?: JobJobClusterNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobJobClusterNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobJobClusterNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace Job#workspace}
    */
    readonly workspace?: JobJobClusterNewClusterInitScriptsWorkspace;
}
export declare function jobJobClusterNewClusterInitScriptsToTerraform(struct?: JobJobClusterNewClusterInitScripts | cdktn.IResolvable): any;
export declare function jobJobClusterNewClusterInitScriptsToHclTerraform(struct?: JobJobClusterNewClusterInitScripts | cdktn.IResolvable): any;
export declare class JobJobClusterNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobJobClusterNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: JobJobClusterNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): JobJobClusterNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: JobJobClusterNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): JobJobClusterNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): JobJobClusterNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: JobJobClusterNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobJobClusterNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): JobJobClusterNewClusterInitScriptsFileOutputReference;
    putFile(value: JobJobClusterNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): JobJobClusterNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): JobJobClusterNewClusterInitScriptsGcsOutputReference;
    putGcs(value: JobJobClusterNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): JobJobClusterNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): JobJobClusterNewClusterInitScriptsS3OutputReference;
    putS3(value: JobJobClusterNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): JobJobClusterNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): JobJobClusterNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: JobJobClusterNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobJobClusterNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): JobJobClusterNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: JobJobClusterNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): JobJobClusterNewClusterInitScriptsWorkspace | undefined;
}
export declare class JobJobClusterNewClusterInitScriptsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobJobClusterNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobJobClusterNewClusterInitScriptsOutputReference;
}
export interface JobJobClusterNewClusterLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobJobClusterNewClusterLibraryCranToTerraform(struct?: JobJobClusterNewClusterLibraryCranOutputReference | JobJobClusterNewClusterLibraryCran): any;
export declare function jobJobClusterNewClusterLibraryCranToHclTerraform(struct?: JobJobClusterNewClusterLibraryCranOutputReference | JobJobClusterNewClusterLibraryCran): any;
export declare class JobJobClusterNewClusterLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterLibraryCran | undefined;
    set internalValue(value: JobJobClusterNewClusterLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobJobClusterNewClusterLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobJobClusterNewClusterLibraryMavenToTerraform(struct?: JobJobClusterNewClusterLibraryMavenOutputReference | JobJobClusterNewClusterLibraryMaven): any;
export declare function jobJobClusterNewClusterLibraryMavenToHclTerraform(struct?: JobJobClusterNewClusterLibraryMavenOutputReference | JobJobClusterNewClusterLibraryMaven): any;
export declare class JobJobClusterNewClusterLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterLibraryMaven | undefined;
    set internalValue(value: JobJobClusterNewClusterLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobJobClusterNewClusterLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobJobClusterNewClusterLibraryProviderConfigToTerraform(struct?: JobJobClusterNewClusterLibraryProviderConfigOutputReference | JobJobClusterNewClusterLibraryProviderConfig): any;
export declare function jobJobClusterNewClusterLibraryProviderConfigToHclTerraform(struct?: JobJobClusterNewClusterLibraryProviderConfigOutputReference | JobJobClusterNewClusterLibraryProviderConfig): any;
export declare class JobJobClusterNewClusterLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterLibraryProviderConfig | undefined;
    set internalValue(value: JobJobClusterNewClusterLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface JobJobClusterNewClusterLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobJobClusterNewClusterLibraryPypiToTerraform(struct?: JobJobClusterNewClusterLibraryPypiOutputReference | JobJobClusterNewClusterLibraryPypi): any;
export declare function jobJobClusterNewClusterLibraryPypiToHclTerraform(struct?: JobJobClusterNewClusterLibraryPypiOutputReference | JobJobClusterNewClusterLibraryPypi): any;
export declare class JobJobClusterNewClusterLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterLibraryPypi | undefined;
    set internalValue(value: JobJobClusterNewClusterLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobJobClusterNewClusterLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobJobClusterNewClusterLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobJobClusterNewClusterLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobJobClusterNewClusterLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobJobClusterNewClusterLibraryPypi;
}
export declare function jobJobClusterNewClusterLibraryToTerraform(struct?: JobJobClusterNewClusterLibrary | cdktn.IResolvable): any;
export declare function jobJobClusterNewClusterLibraryToHclTerraform(struct?: JobJobClusterNewClusterLibrary | cdktn.IResolvable): any;
export declare class JobJobClusterNewClusterLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobJobClusterNewClusterLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobJobClusterNewClusterLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobJobClusterNewClusterLibraryCranOutputReference;
    putCran(value: JobJobClusterNewClusterLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobJobClusterNewClusterLibraryCran | undefined;
    private _maven;
    get maven(): JobJobClusterNewClusterLibraryMavenOutputReference;
    putMaven(value: JobJobClusterNewClusterLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobJobClusterNewClusterLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobJobClusterNewClusterLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobJobClusterNewClusterLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobJobClusterNewClusterLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobJobClusterNewClusterLibraryPypiOutputReference;
    putPypi(value: JobJobClusterNewClusterLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobJobClusterNewClusterLibraryPypi | undefined;
}
export declare class JobJobClusterNewClusterLibraryList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobJobClusterNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobJobClusterNewClusterLibraryOutputReference;
}
export interface JobJobClusterNewClusterProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobJobClusterNewClusterProviderConfigToTerraform(struct?: JobJobClusterNewClusterProviderConfigOutputReference | JobJobClusterNewClusterProviderConfig): any;
export declare function jobJobClusterNewClusterProviderConfigToHclTerraform(struct?: JobJobClusterNewClusterProviderConfigOutputReference | JobJobClusterNewClusterProviderConfig): any;
export declare class JobJobClusterNewClusterProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterProviderConfig | undefined;
    set internalValue(value: JobJobClusterNewClusterProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface JobJobClusterNewClusterWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobJobClusterNewClusterWorkerNodeTypeFlexibilityToTerraform(struct?: JobJobClusterNewClusterWorkerNodeTypeFlexibilityOutputReference | JobJobClusterNewClusterWorkerNodeTypeFlexibility): any;
export declare function jobJobClusterNewClusterWorkerNodeTypeFlexibilityToHclTerraform(struct?: JobJobClusterNewClusterWorkerNodeTypeFlexibilityOutputReference | JobJobClusterNewClusterWorkerNodeTypeFlexibility): any;
export declare class JobJobClusterNewClusterWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: JobJobClusterNewClusterWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobJobClusterNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#jobs Job#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#notebooks Job#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function jobJobClusterNewClusterWorkloadTypeClientsToTerraform(struct?: JobJobClusterNewClusterWorkloadTypeClientsOutputReference | JobJobClusterNewClusterWorkloadTypeClients): any;
export declare function jobJobClusterNewClusterWorkloadTypeClientsToHclTerraform(struct?: JobJobClusterNewClusterWorkloadTypeClientsOutputReference | JobJobClusterNewClusterWorkloadTypeClients): any;
export declare class JobJobClusterNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: JobJobClusterNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobJobClusterNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#clients Job#clients}
    */
    readonly clients: JobJobClusterNewClusterWorkloadTypeClients;
}
export declare function jobJobClusterNewClusterWorkloadTypeToTerraform(struct?: JobJobClusterNewClusterWorkloadTypeOutputReference | JobJobClusterNewClusterWorkloadType): any;
export declare function jobJobClusterNewClusterWorkloadTypeToHclTerraform(struct?: JobJobClusterNewClusterWorkloadTypeOutputReference | JobJobClusterNewClusterWorkloadType): any;
export declare class JobJobClusterNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewClusterWorkloadType | undefined;
    set internalValue(value: JobJobClusterNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): JobJobClusterNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: JobJobClusterNewClusterWorkloadTypeClients): void;
    get clientsInput(): JobJobClusterNewClusterWorkloadTypeClients | undefined;
}
export interface JobJobClusterNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#__apply_policy_default_values_allow_list Job#__apply_policy_default_values_allow_list}
    */
    readonly applyPolicyDefaultValuesAllowList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#apply_policy_default_values Job#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_id Job#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_name Job#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#custom_tags Job#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#data_security_mode Job#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#driver_instance_pool_id Job#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#driver_node_type_id Job#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_elastic_disk Job#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_local_disk_encryption Job#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#idempotency_token Job#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#instance_pool_id Job#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#is_single_node Job#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#kind Job#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#node_type_id Job#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#num_workers Job#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#policy_id Job#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#remote_disk_throughput Job#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#runtime_engine Job#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#single_user_name Job#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spark_conf Job#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spark_env_vars Job#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spark_version Job#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ssh_public_keys Job#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#total_initial_remote_disk_size Job#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#use_ml_runtime Job#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#autoscale Job#autoscale}
    */
    readonly autoscale?: JobJobClusterNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#aws_attributes Job#aws_attributes}
    */
    readonly awsAttributes?: JobJobClusterNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#azure_attributes Job#azure_attributes}
    */
    readonly azureAttributes?: JobJobClusterNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_log_conf Job#cluster_log_conf}
    */
    readonly clusterLogConf?: JobJobClusterNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_mount_info Job#cluster_mount_info}
    */
    readonly clusterMountInfo?: JobJobClusterNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#docker_image Job#docker_image}
    */
    readonly dockerImage?: JobJobClusterNewClusterDockerImage;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#driver_node_type_flexibility Job#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: JobJobClusterNewClusterDriverNodeTypeFlexibility;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#gcp_attributes Job#gcp_attributes}
    */
    readonly gcpAttributes?: JobJobClusterNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#init_scripts Job#init_scripts}
    */
    readonly initScripts?: JobJobClusterNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobJobClusterNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobJobClusterNewClusterProviderConfig;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#worker_node_type_flexibility Job#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: JobJobClusterNewClusterWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workload_type Job#workload_type}
    */
    readonly workloadType?: JobJobClusterNewClusterWorkloadType;
}
export declare function jobJobClusterNewClusterToTerraform(struct?: JobJobClusterNewClusterOutputReference | JobJobClusterNewCluster): any;
export declare function jobJobClusterNewClusterToHclTerraform(struct?: JobJobClusterNewClusterOutputReference | JobJobClusterNewCluster): any;
export declare class JobJobClusterNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobJobClusterNewCluster | undefined;
    set internalValue(value: JobJobClusterNewCluster | undefined);
    private _applyPolicyDefaultValuesAllowList?;
    get applyPolicyDefaultValuesAllowList(): string[];
    set applyPolicyDefaultValuesAllowList(value: string[]);
    resetApplyPolicyDefaultValuesAllowList(): void;
    get applyPolicyDefaultValuesAllowListInput(): string[] | undefined;
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): JobJobClusterNewClusterAutoscaleOutputReference;
    putAutoscale(value: JobJobClusterNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): JobJobClusterNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): JobJobClusterNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: JobJobClusterNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): JobJobClusterNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): JobJobClusterNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: JobJobClusterNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): JobJobClusterNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): JobJobClusterNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: JobJobClusterNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): JobJobClusterNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): JobJobClusterNewClusterClusterMountInfoList;
    putClusterMountInfo(value: JobJobClusterNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | JobJobClusterNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): JobJobClusterNewClusterDockerImageOutputReference;
    putDockerImage(value: JobJobClusterNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): JobJobClusterNewClusterDockerImage | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): JobJobClusterNewClusterDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: JobJobClusterNewClusterDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): JobJobClusterNewClusterDriverNodeTypeFlexibility | undefined;
    private _gcpAttributes;
    get gcpAttributes(): JobJobClusterNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: JobJobClusterNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): JobJobClusterNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): JobJobClusterNewClusterInitScriptsList;
    putInitScripts(value: JobJobClusterNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | JobJobClusterNewClusterInitScripts[] | undefined;
    private _library;
    get library(): JobJobClusterNewClusterLibraryList;
    putLibrary(value: JobJobClusterNewClusterLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobJobClusterNewClusterLibrary[] | undefined;
    private _providerConfig;
    get providerConfig(): JobJobClusterNewClusterProviderConfigOutputReference;
    putProviderConfig(value: JobJobClusterNewClusterProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobJobClusterNewClusterProviderConfig | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): JobJobClusterNewClusterWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: JobJobClusterNewClusterWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): JobJobClusterNewClusterWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): JobJobClusterNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: JobJobClusterNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): JobJobClusterNewClusterWorkloadType | undefined;
}
export interface JobJobCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#job_cluster_key Job#job_cluster_key}
    */
    readonly jobClusterKey: string;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#new_cluster Job#new_cluster}
    */
    readonly newCluster: JobJobClusterNewCluster;
}
export declare function jobJobClusterToTerraform(struct?: JobJobCluster | cdktn.IResolvable): any;
export declare function jobJobClusterToHclTerraform(struct?: JobJobCluster | cdktn.IResolvable): any;
export declare class JobJobClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobJobCluster | cdktn.IResolvable | undefined;
    set internalValue(value: JobJobCluster | cdktn.IResolvable | undefined);
    private _jobClusterKey?;
    get jobClusterKey(): string;
    set jobClusterKey(value: string);
    get jobClusterKeyInput(): string | undefined;
    private _newCluster;
    get newCluster(): JobJobClusterNewClusterOutputReference;
    putNewCluster(value: JobJobClusterNewCluster): void;
    get newClusterInput(): JobJobClusterNewCluster | undefined;
}
export declare class JobJobClusterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobJobCluster[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobJobClusterOutputReference;
}
export interface JobLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobLibraryCranToTerraform(struct?: JobLibraryCranOutputReference | JobLibraryCran): any;
export declare function jobLibraryCranToHclTerraform(struct?: JobLibraryCranOutputReference | JobLibraryCran): any;
export declare class JobLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobLibraryCran | undefined;
    set internalValue(value: JobLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobLibraryMavenToTerraform(struct?: JobLibraryMavenOutputReference | JobLibraryMaven): any;
export declare function jobLibraryMavenToHclTerraform(struct?: JobLibraryMavenOutputReference | JobLibraryMaven): any;
export declare class JobLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobLibraryMaven | undefined;
    set internalValue(value: JobLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobLibraryProviderConfigToTerraform(struct?: JobLibraryProviderConfigOutputReference | JobLibraryProviderConfig): any;
export declare function jobLibraryProviderConfigToHclTerraform(struct?: JobLibraryProviderConfigOutputReference | JobLibraryProviderConfig): any;
export declare class JobLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobLibraryProviderConfig | undefined;
    set internalValue(value: JobLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface JobLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobLibraryPypiToTerraform(struct?: JobLibraryPypiOutputReference | JobLibraryPypi): any;
export declare function jobLibraryPypiToHclTerraform(struct?: JobLibraryPypiOutputReference | JobLibraryPypi): any;
export declare class JobLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobLibraryPypi | undefined;
    set internalValue(value: JobLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobLibraryPypi;
}
export declare function jobLibraryToTerraform(struct?: JobLibrary | cdktn.IResolvable): any;
export declare function jobLibraryToHclTerraform(struct?: JobLibrary | cdktn.IResolvable): any;
export declare class JobLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobLibraryCranOutputReference;
    putCran(value: JobLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobLibraryCran | undefined;
    private _maven;
    get maven(): JobLibraryMavenOutputReference;
    putMaven(value: JobLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobLibraryPypiOutputReference;
    putPypi(value: JobLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobLibraryPypi | undefined;
}
export declare class JobLibraryList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobLibraryOutputReference;
}
export interface JobNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#max_workers Job#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#min_workers Job#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function jobNewClusterAutoscaleToTerraform(struct?: JobNewClusterAutoscaleOutputReference | JobNewClusterAutoscale): any;
export declare function jobNewClusterAutoscaleToHclTerraform(struct?: JobNewClusterAutoscaleOutputReference | JobNewClusterAutoscale): any;
export declare class JobNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterAutoscale | undefined;
    set internalValue(value: JobNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface JobNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_count Job#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_iops Job#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_size Job#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_throughput Job#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ebs_volume_type Job#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#instance_profile_arn Job#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spot_bid_price_percent Job#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobNewClusterAwsAttributesToTerraform(struct?: JobNewClusterAwsAttributesOutputReference | JobNewClusterAwsAttributes): any;
export declare function jobNewClusterAwsAttributesToHclTerraform(struct?: JobNewClusterAwsAttributesOutputReference | JobNewClusterAwsAttributes): any;
export declare class JobNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterAwsAttributes | undefined;
    set internalValue(value: JobNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobNewClusterAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#log_analytics_primary_key Job#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#log_analytics_workspace_id Job#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function jobNewClusterAzureAttributesLogAnalyticsInfoToTerraform(struct?: JobNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare function jobNewClusterAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: JobNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare class JobNewClusterAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: JobNewClusterAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface JobNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spot_bid_max_price Job#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#log_analytics_info Job#log_analytics_info}
    */
    readonly logAnalyticsInfo?: JobNewClusterAzureAttributesLogAnalyticsInfo;
}
export declare function jobNewClusterAzureAttributesToTerraform(struct?: JobNewClusterAzureAttributesOutputReference | JobNewClusterAzureAttributes): any;
export declare function jobNewClusterAzureAttributesToHclTerraform(struct?: JobNewClusterAzureAttributesOutputReference | JobNewClusterAzureAttributes): any;
export declare class JobNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterAzureAttributes | undefined;
    set internalValue(value: JobNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): JobNewClusterAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: JobNewClusterAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): JobNewClusterAzureAttributesLogAnalyticsInfo | undefined;
}
export interface JobNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterClusterLogConfDbfsToTerraform(struct?: JobNewClusterClusterLogConfDbfsOutputReference | JobNewClusterClusterLogConfDbfs): any;
export declare function jobNewClusterClusterLogConfDbfsToHclTerraform(struct?: JobNewClusterClusterLogConfDbfsOutputReference | JobNewClusterClusterLogConfDbfs): any;
export declare class JobNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: JobNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobNewClusterClusterLogConfS3ToTerraform(struct?: JobNewClusterClusterLogConfS3OutputReference | JobNewClusterClusterLogConfS3): any;
export declare function jobNewClusterClusterLogConfS3ToHclTerraform(struct?: JobNewClusterClusterLogConfS3OutputReference | JobNewClusterClusterLogConfS3): any;
export declare class JobNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: JobNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobNewClusterClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterClusterLogConfVolumesToTerraform(struct?: JobNewClusterClusterLogConfVolumesOutputReference | JobNewClusterClusterLogConfVolumes): any;
export declare function jobNewClusterClusterLogConfVolumesToHclTerraform(struct?: JobNewClusterClusterLogConfVolumesOutputReference | JobNewClusterClusterLogConfVolumes): any;
export declare class JobNewClusterClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterClusterLogConfVolumes | undefined;
    set internalValue(value: JobNewClusterClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobNewClusterClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobNewClusterClusterLogConfVolumes;
}
export declare function jobNewClusterClusterLogConfToTerraform(struct?: JobNewClusterClusterLogConfOutputReference | JobNewClusterClusterLogConf): any;
export declare function jobNewClusterClusterLogConfToHclTerraform(struct?: JobNewClusterClusterLogConfOutputReference | JobNewClusterClusterLogConf): any;
export declare class JobNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterClusterLogConf | undefined;
    set internalValue(value: JobNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): JobNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: JobNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): JobNewClusterClusterLogConfS3OutputReference;
    putS3(value: JobNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): JobNewClusterClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): JobNewClusterClusterLogConfVolumesOutputReference;
    putVolumes(value: JobNewClusterClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobNewClusterClusterLogConfVolumes | undefined;
}
export interface JobNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#mount_options Job#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#server_address Job#server_address}
    */
    readonly serverAddress: string;
}
export declare function jobNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: JobNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function jobNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: JobNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class JobNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: JobNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface JobNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#local_mount_dir_path Job#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#remote_mount_dir_path Job#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#network_filesystem_info Job#network_filesystem_info}
    */
    readonly networkFilesystemInfo: JobNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function jobNewClusterClusterMountInfoToTerraform(struct?: JobNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function jobNewClusterClusterMountInfoToHclTerraform(struct?: JobNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class JobNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: JobNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): JobNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: JobNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): JobNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class JobNewClusterClusterMountInfoList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobNewClusterClusterMountInfoOutputReference;
}
export interface JobNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#password Job#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#username Job#username}
    */
    readonly username: string;
}
export declare function jobNewClusterDockerImageBasicAuthToTerraform(struct?: JobNewClusterDockerImageBasicAuthOutputReference | JobNewClusterDockerImageBasicAuth): any;
export declare function jobNewClusterDockerImageBasicAuthToHclTerraform(struct?: JobNewClusterDockerImageBasicAuthOutputReference | JobNewClusterDockerImageBasicAuth): any;
export declare class JobNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: JobNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface JobNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#basic_auth Job#basic_auth}
    */
    readonly basicAuth?: JobNewClusterDockerImageBasicAuth;
}
export declare function jobNewClusterDockerImageToTerraform(struct?: JobNewClusterDockerImageOutputReference | JobNewClusterDockerImage): any;
export declare function jobNewClusterDockerImageToHclTerraform(struct?: JobNewClusterDockerImageOutputReference | JobNewClusterDockerImage): any;
export declare class JobNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterDockerImage | undefined;
    set internalValue(value: JobNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): JobNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: JobNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): JobNewClusterDockerImageBasicAuth | undefined;
}
export interface JobNewClusterDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobNewClusterDriverNodeTypeFlexibilityToTerraform(struct?: JobNewClusterDriverNodeTypeFlexibilityOutputReference | JobNewClusterDriverNodeTypeFlexibility): any;
export declare function jobNewClusterDriverNodeTypeFlexibilityToHclTerraform(struct?: JobNewClusterDriverNodeTypeFlexibilityOutputReference | JobNewClusterDriverNodeTypeFlexibility): any;
export declare class JobNewClusterDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterDriverNodeTypeFlexibility | undefined;
    set internalValue(value: JobNewClusterDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#boot_disk_size Job#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#google_service_account Job#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#local_ssd_count Job#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#use_preemptible_executors Job#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobNewClusterGcpAttributesToTerraform(struct?: JobNewClusterGcpAttributesOutputReference | JobNewClusterGcpAttributes): any;
export declare function jobNewClusterGcpAttributesToHclTerraform(struct?: JobNewClusterGcpAttributesOutputReference | JobNewClusterGcpAttributes): any;
export declare class JobNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterGcpAttributes | undefined;
    set internalValue(value: JobNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterInitScriptsAbfssToTerraform(struct?: JobNewClusterInitScriptsAbfssOutputReference | JobNewClusterInitScriptsAbfss): any;
export declare function jobNewClusterInitScriptsAbfssToHclTerraform(struct?: JobNewClusterInitScriptsAbfssOutputReference | JobNewClusterInitScriptsAbfss): any;
export declare class JobNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: JobNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterInitScriptsDbfsToTerraform(struct?: JobNewClusterInitScriptsDbfsOutputReference | JobNewClusterInitScriptsDbfs): any;
export declare function jobNewClusterInitScriptsDbfsToHclTerraform(struct?: JobNewClusterInitScriptsDbfsOutputReference | JobNewClusterInitScriptsDbfs): any;
export declare class JobNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: JobNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterInitScriptsFileToTerraform(struct?: JobNewClusterInitScriptsFileOutputReference | JobNewClusterInitScriptsFile): any;
export declare function jobNewClusterInitScriptsFileToHclTerraform(struct?: JobNewClusterInitScriptsFileOutputReference | JobNewClusterInitScriptsFile): any;
export declare class JobNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterInitScriptsFile | undefined;
    set internalValue(value: JobNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterInitScriptsGcsToTerraform(struct?: JobNewClusterInitScriptsGcsOutputReference | JobNewClusterInitScriptsGcs): any;
export declare function jobNewClusterInitScriptsGcsToHclTerraform(struct?: JobNewClusterInitScriptsGcsOutputReference | JobNewClusterInitScriptsGcs): any;
export declare class JobNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterInitScriptsGcs | undefined;
    set internalValue(value: JobNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobNewClusterInitScriptsS3ToTerraform(struct?: JobNewClusterInitScriptsS3OutputReference | JobNewClusterInitScriptsS3): any;
export declare function jobNewClusterInitScriptsS3ToHclTerraform(struct?: JobNewClusterInitScriptsS3OutputReference | JobNewClusterInitScriptsS3): any;
export declare class JobNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterInitScriptsS3 | undefined;
    set internalValue(value: JobNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterInitScriptsVolumesToTerraform(struct?: JobNewClusterInitScriptsVolumesOutputReference | JobNewClusterInitScriptsVolumes): any;
export declare function jobNewClusterInitScriptsVolumesToHclTerraform(struct?: JobNewClusterInitScriptsVolumesOutputReference | JobNewClusterInitScriptsVolumes): any;
export declare class JobNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: JobNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobNewClusterInitScriptsWorkspaceToTerraform(struct?: JobNewClusterInitScriptsWorkspaceOutputReference | JobNewClusterInitScriptsWorkspace): any;
export declare function jobNewClusterInitScriptsWorkspaceToHclTerraform(struct?: JobNewClusterInitScriptsWorkspaceOutputReference | JobNewClusterInitScriptsWorkspace): any;
export declare class JobNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: JobNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#abfss Job#abfss}
    */
    readonly abfss?: JobNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#gcs Job#gcs}
    */
    readonly gcs?: JobNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace Job#workspace}
    */
    readonly workspace?: JobNewClusterInitScriptsWorkspace;
}
export declare function jobNewClusterInitScriptsToTerraform(struct?: JobNewClusterInitScripts | cdktn.IResolvable): any;
export declare function jobNewClusterInitScriptsToHclTerraform(struct?: JobNewClusterInitScripts | cdktn.IResolvable): any;
export declare class JobNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: JobNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): JobNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: JobNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): JobNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): JobNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: JobNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): JobNewClusterInitScriptsFileOutputReference;
    putFile(value: JobNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): JobNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): JobNewClusterInitScriptsGcsOutputReference;
    putGcs(value: JobNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): JobNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): JobNewClusterInitScriptsS3OutputReference;
    putS3(value: JobNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): JobNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): JobNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: JobNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): JobNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: JobNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): JobNewClusterInitScriptsWorkspace | undefined;
}
export declare class JobNewClusterInitScriptsList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobNewClusterInitScriptsOutputReference;
}
export interface JobNewClusterLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobNewClusterLibraryCranToTerraform(struct?: JobNewClusterLibraryCranOutputReference | JobNewClusterLibraryCran): any;
export declare function jobNewClusterLibraryCranToHclTerraform(struct?: JobNewClusterLibraryCranOutputReference | JobNewClusterLibraryCran): any;
export declare class JobNewClusterLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterLibraryCran | undefined;
    set internalValue(value: JobNewClusterLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobNewClusterLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobNewClusterLibraryMavenToTerraform(struct?: JobNewClusterLibraryMavenOutputReference | JobNewClusterLibraryMaven): any;
export declare function jobNewClusterLibraryMavenToHclTerraform(struct?: JobNewClusterLibraryMavenOutputReference | JobNewClusterLibraryMaven): any;
export declare class JobNewClusterLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterLibraryMaven | undefined;
    set internalValue(value: JobNewClusterLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobNewClusterLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobNewClusterLibraryProviderConfigToTerraform(struct?: JobNewClusterLibraryProviderConfigOutputReference | JobNewClusterLibraryProviderConfig): any;
export declare function jobNewClusterLibraryProviderConfigToHclTerraform(struct?: JobNewClusterLibraryProviderConfigOutputReference | JobNewClusterLibraryProviderConfig): any;
export declare class JobNewClusterLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterLibraryProviderConfig | undefined;
    set internalValue(value: JobNewClusterLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface JobNewClusterLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobNewClusterLibraryPypiToTerraform(struct?: JobNewClusterLibraryPypiOutputReference | JobNewClusterLibraryPypi): any;
export declare function jobNewClusterLibraryPypiToHclTerraform(struct?: JobNewClusterLibraryPypiOutputReference | JobNewClusterLibraryPypi): any;
export declare class JobNewClusterLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterLibraryPypi | undefined;
    set internalValue(value: JobNewClusterLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobNewClusterLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobNewClusterLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobNewClusterLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobNewClusterLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobNewClusterLibraryPypi;
}
export declare function jobNewClusterLibraryToTerraform(struct?: JobNewClusterLibrary | cdktn.IResolvable): any;
export declare function jobNewClusterLibraryToHclTerraform(struct?: JobNewClusterLibrary | cdktn.IResolvable): any;
export declare class JobNewClusterLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobNewClusterLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobNewClusterLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobNewClusterLibraryCranOutputReference;
    putCran(value: JobNewClusterLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobNewClusterLibraryCran | undefined;
    private _maven;
    get maven(): JobNewClusterLibraryMavenOutputReference;
    putMaven(value: JobNewClusterLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobNewClusterLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobNewClusterLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobNewClusterLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobNewClusterLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobNewClusterLibraryPypiOutputReference;
    putPypi(value: JobNewClusterLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobNewClusterLibraryPypi | undefined;
}
export declare class JobNewClusterLibraryList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobNewClusterLibraryOutputReference;
}
export interface JobNewClusterProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobNewClusterProviderConfigToTerraform(struct?: JobNewClusterProviderConfigOutputReference | JobNewClusterProviderConfig): any;
export declare function jobNewClusterProviderConfigToHclTerraform(struct?: JobNewClusterProviderConfigOutputReference | JobNewClusterProviderConfig): any;
export declare class JobNewClusterProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterProviderConfig | undefined;
    set internalValue(value: JobNewClusterProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface JobNewClusterWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobNewClusterWorkerNodeTypeFlexibilityToTerraform(struct?: JobNewClusterWorkerNodeTypeFlexibilityOutputReference | JobNewClusterWorkerNodeTypeFlexibility): any;
export declare function jobNewClusterWorkerNodeTypeFlexibilityToHclTerraform(struct?: JobNewClusterWorkerNodeTypeFlexibilityOutputReference | JobNewClusterWorkerNodeTypeFlexibility): any;
export declare class JobNewClusterWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: JobNewClusterWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#jobs Job#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#notebooks Job#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function jobNewClusterWorkloadTypeClientsToTerraform(struct?: JobNewClusterWorkloadTypeClientsOutputReference | JobNewClusterWorkloadTypeClients): any;
export declare function jobNewClusterWorkloadTypeClientsToHclTerraform(struct?: JobNewClusterWorkloadTypeClientsOutputReference | JobNewClusterWorkloadTypeClients): any;
export declare class JobNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: JobNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#clients Job#clients}
    */
    readonly clients: JobNewClusterWorkloadTypeClients;
}
export declare function jobNewClusterWorkloadTypeToTerraform(struct?: JobNewClusterWorkloadTypeOutputReference | JobNewClusterWorkloadType): any;
export declare function jobNewClusterWorkloadTypeToHclTerraform(struct?: JobNewClusterWorkloadTypeOutputReference | JobNewClusterWorkloadType): any;
export declare class JobNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewClusterWorkloadType | undefined;
    set internalValue(value: JobNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): JobNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: JobNewClusterWorkloadTypeClients): void;
    get clientsInput(): JobNewClusterWorkloadTypeClients | undefined;
}
export interface JobNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#apply_policy_default_values Job#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_id Job#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_name Job#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#custom_tags Job#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#data_security_mode Job#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#driver_instance_pool_id Job#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#driver_node_type_id Job#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_elastic_disk Job#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enable_local_disk_encryption Job#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#idempotency_token Job#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#instance_pool_id Job#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#is_single_node Job#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#kind Job#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#node_type_id Job#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#num_workers Job#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#policy_id Job#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#remote_disk_throughput Job#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#runtime_engine Job#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#single_user_name Job#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spark_conf Job#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spark_env_vars Job#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#spark_version Job#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#ssh_public_keys Job#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#total_initial_remote_disk_size Job#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#use_ml_runtime Job#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#autoscale Job#autoscale}
    */
    readonly autoscale?: JobNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#aws_attributes Job#aws_attributes}
    */
    readonly awsAttributes?: JobNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#azure_attributes Job#azure_attributes}
    */
    readonly azureAttributes?: JobNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_log_conf Job#cluster_log_conf}
    */
    readonly clusterLogConf?: JobNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cluster_mount_info Job#cluster_mount_info}
    */
    readonly clusterMountInfo?: JobNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#docker_image Job#docker_image}
    */
    readonly dockerImage?: JobNewClusterDockerImage;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#driver_node_type_flexibility Job#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: JobNewClusterDriverNodeTypeFlexibility;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#gcp_attributes Job#gcp_attributes}
    */
    readonly gcpAttributes?: JobNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#init_scripts Job#init_scripts}
    */
    readonly initScripts?: JobNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobNewClusterProviderConfig;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#worker_node_type_flexibility Job#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: JobNewClusterWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workload_type Job#workload_type}
    */
    readonly workloadType?: JobNewClusterWorkloadType;
}
export declare function jobNewClusterToTerraform(struct?: JobNewClusterOutputReference | JobNewCluster): any;
export declare function jobNewClusterToHclTerraform(struct?: JobNewClusterOutputReference | JobNewCluster): any;
export declare class JobNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNewCluster | undefined;
    set internalValue(value: JobNewCluster | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): JobNewClusterAutoscaleOutputReference;
    putAutoscale(value: JobNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): JobNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): JobNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: JobNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): JobNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): JobNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: JobNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): JobNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): JobNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: JobNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): JobNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): JobNewClusterClusterMountInfoList;
    putClusterMountInfo(value: JobNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | JobNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): JobNewClusterDockerImageOutputReference;
    putDockerImage(value: JobNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): JobNewClusterDockerImage | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): JobNewClusterDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: JobNewClusterDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): JobNewClusterDriverNodeTypeFlexibility | undefined;
    private _gcpAttributes;
    get gcpAttributes(): JobNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: JobNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): JobNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): JobNewClusterInitScriptsList;
    putInitScripts(value: JobNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | JobNewClusterInitScripts[] | undefined;
    private _library;
    get library(): JobNewClusterLibraryList;
    putLibrary(value: JobNewClusterLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobNewClusterLibrary[] | undefined;
    private _providerConfig;
    get providerConfig(): JobNewClusterProviderConfigOutputReference;
    putProviderConfig(value: JobNewClusterProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobNewClusterProviderConfig | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): JobNewClusterWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: JobNewClusterWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): JobNewClusterWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): JobNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: JobNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): JobNewClusterWorkloadType | undefined;
}
export interface JobNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#base_parameters Job#base_parameters}
    */
    readonly baseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#notebook_path Job#notebook_path}
    */
    readonly notebookPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function jobNotebookTaskToTerraform(struct?: JobNotebookTaskOutputReference | JobNotebookTask): any;
export declare function jobNotebookTaskToHclTerraform(struct?: JobNotebookTaskOutputReference | JobNotebookTask): any;
export declare class JobNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNotebookTask | undefined;
    set internalValue(value: JobNotebookTask | undefined);
    private _baseParameters?;
    get baseParameters(): {
        [key: string]: string;
    };
    set baseParameters(value: {
        [key: string]: string;
    });
    resetBaseParameters(): void;
    get baseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    get notebookPathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface JobNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#no_alert_for_canceled_runs Job#no_alert_for_canceled_runs}
    */
    readonly noAlertForCanceledRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
}
export declare function jobNotificationSettingsToTerraform(struct?: JobNotificationSettingsOutputReference | JobNotificationSettings): any;
export declare function jobNotificationSettingsToHclTerraform(struct?: JobNotificationSettingsOutputReference | JobNotificationSettings): any;
export declare class JobNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobNotificationSettings | undefined;
    set internalValue(value: JobNotificationSettings | undefined);
    private _noAlertForCanceledRuns?;
    get noAlertForCanceledRuns(): boolean | cdktn.IResolvable;
    set noAlertForCanceledRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForCanceledRuns(): void;
    get noAlertForCanceledRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#default Job#default}
    */
    readonly default: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#name Job#name}
    */
    readonly name: string;
}
export declare function jobParameterToTerraform(struct?: JobParameter | cdktn.IResolvable): any;
export declare function jobParameterToHclTerraform(struct?: JobParameter | cdktn.IResolvable): any;
export declare class JobParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobParameter | cdktn.IResolvable | undefined;
    set internalValue(value: JobParameter | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    get defaultInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class JobParameterList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobParameterOutputReference;
}
export interface JobPipelineTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#full_refresh Job#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pipeline_id Job#pipeline_id}
    */
    readonly pipelineId: string;
}
export declare function jobPipelineTaskToTerraform(struct?: JobPipelineTaskOutputReference | JobPipelineTask): any;
export declare function jobPipelineTaskToHclTerraform(struct?: JobPipelineTaskOutputReference | JobPipelineTask): any;
export declare class JobPipelineTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobPipelineTask | undefined;
    set internalValue(value: JobPipelineTask | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
}
export interface JobProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobProviderConfigToTerraform(struct?: JobProviderConfigOutputReference | JobProviderConfig): any;
export declare function jobProviderConfigToHclTerraform(struct?: JobProviderConfigOutputReference | JobProviderConfig): any;
export declare class JobProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobProviderConfig | undefined;
    set internalValue(value: JobProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface JobPythonWheelTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#entry_point Job#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#named_parameters Job#named_parameters}
    */
    readonly namedParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package_name Job#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobPythonWheelTaskToTerraform(struct?: JobPythonWheelTaskOutputReference | JobPythonWheelTask): any;
export declare function jobPythonWheelTaskToHclTerraform(struct?: JobPythonWheelTaskOutputReference | JobPythonWheelTask): any;
export declare class JobPythonWheelTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobPythonWheelTask | undefined;
    set internalValue(value: JobPythonWheelTask | undefined);
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _namedParameters?;
    get namedParameters(): {
        [key: string]: string;
    };
    set namedParameters(value: {
        [key: string]: string;
    });
    resetNamedParameters(): void;
    get namedParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobQueue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#enabled Job#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function jobQueueToTerraform(struct?: JobQueueOutputReference | JobQueue): any;
export declare function jobQueueToHclTerraform(struct?: JobQueueOutputReference | JobQueue): any;
export declare class JobQueueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobQueue | undefined;
    set internalValue(value: JobQueue | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#group_name Job#group_name}
    */
    readonly groupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#service_principal_name Job#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobRunAsToTerraform(struct?: JobRunAsOutputReference | JobRunAs): any;
export declare function jobRunAsToHclTerraform(struct?: JobRunAsOutputReference | JobRunAs): any;
export declare class JobRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobRunAs | undefined;
    set internalValue(value: JobRunAs | undefined);
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    resetGroupName(): void;
    get groupNameInput(): string | undefined;
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface JobRunJobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#job_id Job#job_id}
    */
    readonly jobId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#job_parameters Job#job_parameters}
    */
    readonly jobParameters?: {
        [key: string]: string;
    };
}
export declare function jobRunJobTaskToTerraform(struct?: JobRunJobTaskOutputReference | JobRunJobTask): any;
export declare function jobRunJobTaskToHclTerraform(struct?: JobRunJobTaskOutputReference | JobRunJobTask): any;
export declare class JobRunJobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobRunJobTask | undefined;
    set internalValue(value: JobRunJobTask | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    private _jobParameters?;
    get jobParameters(): {
        [key: string]: string;
    };
    set jobParameters(value: {
        [key: string]: string;
    });
    resetJobParameters(): void;
    get jobParametersInput(): {
        [key: string]: string;
    } | undefined;
}
export interface JobSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pause_status Job#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#quartz_cron_expression Job#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#timezone_id Job#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function jobScheduleToTerraform(struct?: JobScheduleOutputReference | JobSchedule): any;
export declare function jobScheduleToHclTerraform(struct?: JobScheduleOutputReference | JobSchedule): any;
export declare class JobScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobSchedule | undefined;
    set internalValue(value: JobSchedule | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface JobSparkJarTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#jar_uri Job#jar_uri}
    */
    readonly jarUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#main_class_name Job#main_class_name}
    */
    readonly mainClassName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobSparkJarTaskToTerraform(struct?: JobSparkJarTaskOutputReference | JobSparkJarTask): any;
export declare function jobSparkJarTaskToHclTerraform(struct?: JobSparkJarTaskOutputReference | JobSparkJarTask): any;
export declare class JobSparkJarTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobSparkJarTask | undefined;
    set internalValue(value: JobSparkJarTask | undefined);
    private _jarUri?;
    get jarUri(): string;
    set jarUri(value: string);
    resetJarUri(): void;
    get jarUriInput(): string | undefined;
    private _mainClassName?;
    get mainClassName(): string;
    set mainClassName(value: string);
    resetMainClassName(): void;
    get mainClassNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobSparkPythonTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#python_file Job#python_file}
    */
    readonly pythonFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
}
export declare function jobSparkPythonTaskToTerraform(struct?: JobSparkPythonTaskOutputReference | JobSparkPythonTask): any;
export declare function jobSparkPythonTaskToHclTerraform(struct?: JobSparkPythonTaskOutputReference | JobSparkPythonTask): any;
export declare class JobSparkPythonTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobSparkPythonTask | undefined;
    set internalValue(value: JobSparkPythonTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pythonFile?;
    get pythonFile(): string;
    set pythonFile(value: string);
    get pythonFileInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface JobSparkSubmitTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobSparkSubmitTaskToTerraform(struct?: JobSparkSubmitTaskOutputReference | JobSparkSubmitTask): any;
export declare function jobSparkSubmitTaskToHclTerraform(struct?: JobSparkSubmitTaskOutputReference | JobSparkSubmitTask): any;
export declare class JobSparkSubmitTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobSparkSubmitTask | undefined;
    set internalValue(value: JobSparkSubmitTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobTaskCleanRoomsNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#clean_room_name Job#clean_room_name}
    */
    readonly cleanRoomName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#etag Job#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#notebook_base_parameters Job#notebook_base_parameters}
    */
    readonly notebookBaseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#notebook_name Job#notebook_name}
    */
    readonly notebookName: string;
}
export declare function jobTaskCleanRoomsNotebookTaskToTerraform(struct?: JobTaskCleanRoomsNotebookTaskOutputReference | JobTaskCleanRoomsNotebookTask): any;
export declare function jobTaskCleanRoomsNotebookTaskToHclTerraform(struct?: JobTaskCleanRoomsNotebookTaskOutputReference | JobTaskCleanRoomsNotebookTask): any;
export declare class JobTaskCleanRoomsNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskCleanRoomsNotebookTask | undefined;
    set internalValue(value: JobTaskCleanRoomsNotebookTask | undefined);
    private _cleanRoomName?;
    get cleanRoomName(): string;
    set cleanRoomName(value: string);
    get cleanRoomNameInput(): string | undefined;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _notebookBaseParameters?;
    get notebookBaseParameters(): {
        [key: string]: string;
    };
    set notebookBaseParameters(value: {
        [key: string]: string;
    });
    resetNotebookBaseParameters(): void;
    get notebookBaseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookName?;
    get notebookName(): string;
    set notebookName(value: string);
    get notebookNameInput(): string | undefined;
}
export interface JobTaskCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#hardware_accelerator Job#hardware_accelerator}
    */
    readonly hardwareAccelerator?: string;
}
export declare function jobTaskComputeToTerraform(struct?: JobTaskComputeOutputReference | JobTaskCompute): any;
export declare function jobTaskComputeToHclTerraform(struct?: JobTaskComputeOutputReference | JobTaskCompute): any;
export declare class JobTaskComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskCompute | undefined;
    set internalValue(value: JobTaskCompute | undefined);
    private _hardwareAccelerator?;
    get hardwareAccelerator(): string;
    set hardwareAccelerator(value: string);
    resetHardwareAccelerator(): void;
    get hardwareAcceleratorInput(): string | undefined;
}
export interface JobTaskConditionTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#left Job#left}
    */
    readonly left: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#op Job#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#right Job#right}
    */
    readonly right: string;
}
export declare function jobTaskConditionTaskToTerraform(struct?: JobTaskConditionTaskOutputReference | JobTaskConditionTask): any;
export declare function jobTaskConditionTaskToHclTerraform(struct?: JobTaskConditionTaskOutputReference | JobTaskConditionTask): any;
export declare class JobTaskConditionTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskConditionTask | undefined;
    set internalValue(value: JobTaskConditionTask | undefined);
    private _left?;
    get left(): string;
    set left(value: string);
    get leftInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _right?;
    get right(): string;
    set right(value: string);
    get rightInput(): string | undefined;
}
export interface JobTaskDashboardTaskSubscriptionSubscribers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskDashboardTaskSubscriptionSubscribersToTerraform(struct?: JobTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare function jobTaskDashboardTaskSubscriptionSubscribersToHclTerraform(struct?: JobTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare class JobTaskDashboardTaskSubscriptionSubscribersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskDashboardTaskSubscriptionSubscribersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskDashboardTaskSubscriptionSubscribersOutputReference;
}
export interface JobTaskDashboardTaskSubscription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#custom_subject Job#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#paused Job#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * subscribers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#subscribers Job#subscribers}
    */
    readonly subscribers?: JobTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
}
export declare function jobTaskDashboardTaskSubscriptionToTerraform(struct?: JobTaskDashboardTaskSubscriptionOutputReference | JobTaskDashboardTaskSubscription): any;
export declare function jobTaskDashboardTaskSubscriptionToHclTerraform(struct?: JobTaskDashboardTaskSubscriptionOutputReference | JobTaskDashboardTaskSubscription): any;
export declare class JobTaskDashboardTaskSubscriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskDashboardTaskSubscription | undefined;
    set internalValue(value: JobTaskDashboardTaskSubscription | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _subscribers;
    get subscribers(): JobTaskDashboardTaskSubscriptionSubscribersList;
    putSubscribers(value: JobTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable): void;
    resetSubscribers(): void;
    get subscribersInput(): cdktn.IResolvable | JobTaskDashboardTaskSubscriptionSubscribers[] | undefined;
}
export interface JobTaskDashboardTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dashboard_id Job#dashboard_id}
    */
    readonly dashboardId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#filters Job#filters}
    */
    readonly filters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#subscription Job#subscription}
    */
    readonly subscription?: JobTaskDashboardTaskSubscription;
}
export declare function jobTaskDashboardTaskToTerraform(struct?: JobTaskDashboardTaskOutputReference | JobTaskDashboardTask): any;
export declare function jobTaskDashboardTaskToHclTerraform(struct?: JobTaskDashboardTaskOutputReference | JobTaskDashboardTask): any;
export declare class JobTaskDashboardTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskDashboardTask | undefined;
    set internalValue(value: JobTaskDashboardTask | undefined);
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    resetDashboardId(): void;
    get dashboardIdInput(): string | undefined;
    private _filters?;
    get filters(): {
        [key: string]: string;
    };
    set filters(value: {
        [key: string]: string;
    });
    resetFilters(): void;
    get filtersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _subscription;
    get subscription(): JobTaskDashboardTaskSubscriptionOutputReference;
    putSubscription(value: JobTaskDashboardTaskSubscription): void;
    resetSubscription(): void;
    get subscriptionInput(): JobTaskDashboardTaskSubscription | undefined;
}
export interface JobTaskDbtCloudTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#connection_resource_name Job#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbt_cloud_job_id Job#dbt_cloud_job_id}
    */
    readonly dbtCloudJobId?: number;
}
export declare function jobTaskDbtCloudTaskToTerraform(struct?: JobTaskDbtCloudTaskOutputReference | JobTaskDbtCloudTask): any;
export declare function jobTaskDbtCloudTaskToHclTerraform(struct?: JobTaskDbtCloudTaskOutputReference | JobTaskDbtCloudTask): any;
export declare class JobTaskDbtCloudTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskDbtCloudTask | undefined;
    set internalValue(value: JobTaskDbtCloudTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _dbtCloudJobId?;
    get dbtCloudJobId(): number;
    set dbtCloudJobId(value: number);
    resetDbtCloudJobId(): void;
    get dbtCloudJobIdInput(): number | undefined;
}
export interface JobTaskDbtPlatformTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#connection_resource_name Job#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbt_platform_job_id Job#dbt_platform_job_id}
    */
    readonly dbtPlatformJobId?: string;
}
export declare function jobTaskDbtPlatformTaskToTerraform(struct?: JobTaskDbtPlatformTaskOutputReference | JobTaskDbtPlatformTask): any;
export declare function jobTaskDbtPlatformTaskToHclTerraform(struct?: JobTaskDbtPlatformTaskOutputReference | JobTaskDbtPlatformTask): any;
export declare class JobTaskDbtPlatformTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskDbtPlatformTask | undefined;
    set internalValue(value: JobTaskDbtPlatformTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _dbtPlatformJobId?;
    get dbtPlatformJobId(): string;
    set dbtPlatformJobId(value: string);
    resetDbtPlatformJobId(): void;
    get dbtPlatformJobIdInput(): string | undefined;
}
export interface JobTaskDbtTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#catalog Job#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#commands Job#commands}
    */
    readonly commands: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#profiles_directory Job#profiles_directory}
    */
    readonly profilesDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#project_directory Job#project_directory}
    */
    readonly projectDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#schema Job#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function jobTaskDbtTaskToTerraform(struct?: JobTaskDbtTaskOutputReference | JobTaskDbtTask): any;
export declare function jobTaskDbtTaskToHclTerraform(struct?: JobTaskDbtTaskOutputReference | JobTaskDbtTask): any;
export declare class JobTaskDbtTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskDbtTask | undefined;
    set internalValue(value: JobTaskDbtTask | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    get commandsInput(): string[] | undefined;
    private _profilesDirectory?;
    get profilesDirectory(): string;
    set profilesDirectory(value: string);
    resetProfilesDirectory(): void;
    get profilesDirectoryInput(): string | undefined;
    private _projectDirectory?;
    get projectDirectory(): string;
    set projectDirectory(value: string);
    resetProjectDirectory(): void;
    get projectDirectoryInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface JobTaskDependsOn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#outcome Job#outcome}
    */
    readonly outcome?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#task_key Job#task_key}
    */
    readonly taskKey: string;
}
export declare function jobTaskDependsOnToTerraform(struct?: JobTaskDependsOn | cdktn.IResolvable): any;
export declare function jobTaskDependsOnToHclTerraform(struct?: JobTaskDependsOn | cdktn.IResolvable): any;
export declare class JobTaskDependsOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskDependsOn | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskDependsOn | cdktn.IResolvable | undefined);
    private _outcome?;
    get outcome(): string;
    set outcome(value: string);
    resetOutcome(): void;
    get outcomeInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
}
export declare class JobTaskDependsOnList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobTaskDependsOn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskDependsOnOutputReference;
}
export interface JobTaskEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: string[];
}
export declare function jobTaskEmailNotificationsToTerraform(struct?: JobTaskEmailNotificationsOutputReference | JobTaskEmailNotifications): any;
export declare function jobTaskEmailNotificationsToHclTerraform(struct?: JobTaskEmailNotificationsOutputReference | JobTaskEmailNotifications): any;
export declare class JobTaskEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskEmailNotifications | undefined;
    set internalValue(value: JobTaskEmailNotifications | undefined);
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _onDurationWarningThresholdExceeded?;
    get onDurationWarningThresholdExceeded(): string[];
    set onDurationWarningThresholdExceeded(value: string[]);
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): string[] | undefined;
    private _onFailure?;
    get onFailure(): string[];
    set onFailure(value: string[]);
    resetOnFailure(): void;
    get onFailureInput(): string[] | undefined;
    private _onStart?;
    get onStart(): string[];
    set onStart(value: string[]);
    resetOnStart(): void;
    get onStartInput(): string[] | undefined;
    private _onStreamingBacklogExceeded?;
    get onStreamingBacklogExceeded(): string[];
    set onStreamingBacklogExceeded(value: string[]);
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): string[] | undefined;
    private _onSuccess?;
    get onSuccess(): string[];
    set onSuccess(value: string[]);
    resetOnSuccess(): void;
    get onSuccessInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskCleanRoomsNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#clean_room_name Job#clean_room_name}
    */
    readonly cleanRoomName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#etag Job#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#notebook_base_parameters Job#notebook_base_parameters}
    */
    readonly notebookBaseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#notebook_name Job#notebook_name}
    */
    readonly notebookName: string;
}
export declare function jobTaskForEachTaskTaskCleanRoomsNotebookTaskToTerraform(struct?: JobTaskForEachTaskTaskCleanRoomsNotebookTaskOutputReference | JobTaskForEachTaskTaskCleanRoomsNotebookTask): any;
export declare function jobTaskForEachTaskTaskCleanRoomsNotebookTaskToHclTerraform(struct?: JobTaskForEachTaskTaskCleanRoomsNotebookTaskOutputReference | JobTaskForEachTaskTaskCleanRoomsNotebookTask): any;
export declare class JobTaskForEachTaskTaskCleanRoomsNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskCleanRoomsNotebookTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskCleanRoomsNotebookTask | undefined);
    private _cleanRoomName?;
    get cleanRoomName(): string;
    set cleanRoomName(value: string);
    get cleanRoomNameInput(): string | undefined;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _notebookBaseParameters?;
    get notebookBaseParameters(): {
        [key: string]: string;
    };
    set notebookBaseParameters(value: {
        [key: string]: string;
    });
    resetNotebookBaseParameters(): void;
    get notebookBaseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookName?;
    get notebookName(): string;
    set notebookName(value: string);
    get notebookNameInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#hardware_accelerator Job#hardware_accelerator}
    */
    readonly hardwareAccelerator?: string;
}
export declare function jobTaskForEachTaskTaskComputeToTerraform(struct?: JobTaskForEachTaskTaskComputeOutputReference | JobTaskForEachTaskTaskCompute): any;
export declare function jobTaskForEachTaskTaskComputeToHclTerraform(struct?: JobTaskForEachTaskTaskComputeOutputReference | JobTaskForEachTaskTaskCompute): any;
export declare class JobTaskForEachTaskTaskComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskCompute | undefined;
    set internalValue(value: JobTaskForEachTaskTaskCompute | undefined);
    private _hardwareAccelerator?;
    get hardwareAccelerator(): string;
    set hardwareAccelerator(value: string);
    resetHardwareAccelerator(): void;
    get hardwareAcceleratorInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskConditionTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#left Job#left}
    */
    readonly left: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#op Job#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#right Job#right}
    */
    readonly right: string;
}
export declare function jobTaskForEachTaskTaskConditionTaskToTerraform(struct?: JobTaskForEachTaskTaskConditionTaskOutputReference | JobTaskForEachTaskTaskConditionTask): any;
export declare function jobTaskForEachTaskTaskConditionTaskToHclTerraform(struct?: JobTaskForEachTaskTaskConditionTaskOutputReference | JobTaskForEachTaskTaskConditionTask): any;
export declare class JobTaskForEachTaskTaskConditionTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskConditionTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskConditionTask | undefined);
    private _left?;
    get left(): string;
    set left(value: string);
    get leftInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _right?;
    get right(): string;
    set right(value: string);
    get rightInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersToTerraform(struct?: JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersToHclTerraform(struct?: JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersOutputReference;
}
export interface JobTaskForEachTaskTaskDashboardTaskSubscription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#custom_subject Job#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#paused Job#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * subscribers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#subscribers Job#subscribers}
    */
    readonly subscribers?: JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskDashboardTaskSubscriptionToTerraform(struct?: JobTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference | JobTaskForEachTaskTaskDashboardTaskSubscription): any;
export declare function jobTaskForEachTaskTaskDashboardTaskSubscriptionToHclTerraform(struct?: JobTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference | JobTaskForEachTaskTaskDashboardTaskSubscription): any;
export declare class JobTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskDashboardTaskSubscription | undefined;
    set internalValue(value: JobTaskForEachTaskTaskDashboardTaskSubscription | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _subscribers;
    get subscribers(): JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersList;
    putSubscribers(value: JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable): void;
    resetSubscribers(): void;
    get subscribersInput(): cdktn.IResolvable | JobTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | undefined;
}
export interface JobTaskForEachTaskTaskDashboardTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dashboard_id Job#dashboard_id}
    */
    readonly dashboardId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#filters Job#filters}
    */
    readonly filters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#subscription Job#subscription}
    */
    readonly subscription?: JobTaskForEachTaskTaskDashboardTaskSubscription;
}
export declare function jobTaskForEachTaskTaskDashboardTaskToTerraform(struct?: JobTaskForEachTaskTaskDashboardTaskOutputReference | JobTaskForEachTaskTaskDashboardTask): any;
export declare function jobTaskForEachTaskTaskDashboardTaskToHclTerraform(struct?: JobTaskForEachTaskTaskDashboardTaskOutputReference | JobTaskForEachTaskTaskDashboardTask): any;
export declare class JobTaskForEachTaskTaskDashboardTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskDashboardTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskDashboardTask | undefined);
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    resetDashboardId(): void;
    get dashboardIdInput(): string | undefined;
    private _filters?;
    get filters(): {
        [key: string]: string;
    };
    set filters(value: {
        [key: string]: string;
    });
    resetFilters(): void;
    get filtersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _subscription;
    get subscription(): JobTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference;
    putSubscription(value: JobTaskForEachTaskTaskDashboardTaskSubscription): void;
    resetSubscription(): void;
    get subscriptionInput(): JobTaskForEachTaskTaskDashboardTaskSubscription | undefined;
}
export interface JobTaskForEachTaskTaskDbtCloudTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#connection_resource_name Job#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbt_cloud_job_id Job#dbt_cloud_job_id}
    */
    readonly dbtCloudJobId?: number;
}
export declare function jobTaskForEachTaskTaskDbtCloudTaskToTerraform(struct?: JobTaskForEachTaskTaskDbtCloudTaskOutputReference | JobTaskForEachTaskTaskDbtCloudTask): any;
export declare function jobTaskForEachTaskTaskDbtCloudTaskToHclTerraform(struct?: JobTaskForEachTaskTaskDbtCloudTaskOutputReference | JobTaskForEachTaskTaskDbtCloudTask): any;
export declare class JobTaskForEachTaskTaskDbtCloudTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskDbtCloudTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskDbtCloudTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _dbtCloudJobId?;
    get dbtCloudJobId(): number;
    set dbtCloudJobId(value: number);
    resetDbtCloudJobId(): void;
    get dbtCloudJobIdInput(): number | undefined;
}
export interface JobTaskForEachTaskTaskDbtPlatformTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#connection_resource_name Job#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dbt_platform_job_id Job#dbt_platform_job_id}
    */
    readonly dbtPlatformJobId?: string;
}
export declare function jobTaskForEachTaskTaskDbtPlatformTaskToTerraform(struct?: JobTaskForEachTaskTaskDbtPlatformTaskOutputReference | JobTaskForEachTaskTaskDbtPlatformTask): any;
export declare function jobTaskForEachTaskTaskDbtPlatformTaskToHclTerraform(struct?: JobTaskForEachTaskTaskDbtPlatformTaskOutputReference | JobTaskForEachTaskTaskDbtPlatformTask): any;
export declare class JobTaskForEachTaskTaskDbtPlatformTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskDbtPlatformTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskDbtPlatformTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _dbtPlatformJobId?;
    get dbtPlatformJobId(): string;
    set dbtPlatformJobId(value: string);
    resetDbtPlatformJobId(): void;
    get dbtPlatformJobIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskDbtTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#catalog Job#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#commands Job#commands}
    */
    readonly commands: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#profiles_directory Job#profiles_directory}
    */
    readonly profilesDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#project_directory Job#project_directory}
    */
    readonly projectDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#schema Job#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function jobTaskForEachTaskTaskDbtTaskToTerraform(struct?: JobTaskForEachTaskTaskDbtTaskOutputReference | JobTaskForEachTaskTaskDbtTask): any;
export declare function jobTaskForEachTaskTaskDbtTaskToHclTerraform(struct?: JobTaskForEachTaskTaskDbtTaskOutputReference | JobTaskForEachTaskTaskDbtTask): any;
export declare class JobTaskForEachTaskTaskDbtTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskDbtTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskDbtTask | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    get commandsInput(): string[] | undefined;
    private _profilesDirectory?;
    get profilesDirectory(): string;
    set profilesDirectory(value: string);
    resetProfilesDirectory(): void;
    get profilesDirectoryInput(): string | undefined;
    private _projectDirectory?;
    get projectDirectory(): string;
    set projectDirectory(value: string);
    resetProjectDirectory(): void;
    get projectDirectoryInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskDependsOn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#outcome Job#outcome}
    */
    readonly outcome?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#task_key Job#task_key}
    */
    readonly taskKey: string;
}
export declare function jobTaskForEachTaskTaskDependsOnToTerraform(struct?: JobTaskForEachTaskTaskDependsOn | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskDependsOnToHclTerraform(struct?: JobTaskForEachTaskTaskDependsOn | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskDependsOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskDependsOn | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskDependsOn | cdktn.IResolvable | undefined);
    private _outcome?;
    get outcome(): string;
    set outcome(value: string);
    resetOutcome(): void;
    get outcomeInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskDependsOnList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobTaskForEachTaskTaskDependsOn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskDependsOnOutputReference;
}
export interface JobTaskForEachTaskTaskEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: string[];
}
export declare function jobTaskForEachTaskTaskEmailNotificationsToTerraform(struct?: JobTaskForEachTaskTaskEmailNotificationsOutputReference | JobTaskForEachTaskTaskEmailNotifications): any;
export declare function jobTaskForEachTaskTaskEmailNotificationsToHclTerraform(struct?: JobTaskForEachTaskTaskEmailNotificationsOutputReference | JobTaskForEachTaskTaskEmailNotifications): any;
export declare class JobTaskForEachTaskTaskEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskEmailNotifications | undefined;
    set internalValue(value: JobTaskForEachTaskTaskEmailNotifications | undefined);
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _onDurationWarningThresholdExceeded?;
    get onDurationWarningThresholdExceeded(): string[];
    set onDurationWarningThresholdExceeded(value: string[]);
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): string[] | undefined;
    private _onFailure?;
    get onFailure(): string[];
    set onFailure(value: string[]);
    resetOnFailure(): void;
    get onFailureInput(): string[] | undefined;
    private _onStart?;
    get onStart(): string[];
    set onStart(value: string[]);
    resetOnStart(): void;
    get onStartInput(): string[] | undefined;
    private _onStreamingBacklogExceeded?;
    get onStreamingBacklogExceeded(): string[];
    set onStreamingBacklogExceeded(value: string[]);
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): string[] | undefined;
    private _onSuccess?;
    get onSuccess(): string[];
    set onSuccess(value: string[]);
    resetOnSuccess(): void;
    get onSuccessInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskGenAiComputeTaskCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#gpu_node_pool_id Job#gpu_node_pool_id}
    */
    readonly gpuNodePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#gpu_type Job#gpu_type}
    */
    readonly gpuType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#num_gpus Job#num_gpus}
    */
    readonly numGpus: number;
}
export declare function jobTaskForEachTaskTaskGenAiComputeTaskComputeToTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference | JobTaskForEachTaskTaskGenAiComputeTaskCompute): any;
export declare function jobTaskForEachTaskTaskGenAiComputeTaskComputeToHclTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference | JobTaskForEachTaskTaskGenAiComputeTaskCompute): any;
export declare class JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskGenAiComputeTaskCompute | undefined;
    set internalValue(value: JobTaskForEachTaskTaskGenAiComputeTaskCompute | undefined);
    private _gpuNodePoolId?;
    get gpuNodePoolId(): string;
    set gpuNodePoolId(value: string);
    resetGpuNodePoolId(): void;
    get gpuNodePoolIdInput(): string | undefined;
    private _gpuType?;
    get gpuType(): string;
    set gpuType(value: string);
    resetGpuType(): void;
    get gpuTypeInput(): string | undefined;
    private _numGpus?;
    get numGpus(): number;
    set numGpus(value: number);
    get numGpusInput(): number | undefined;
}
export interface JobTaskForEachTaskTaskGenAiComputeTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#command Job#command}
    */
    readonly command?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#dl_runtime_image Job#dl_runtime_image}
    */
    readonly dlRuntimeImage: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#mlflow_experiment_name Job#mlflow_experiment_name}
    */
    readonly mlflowExperimentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#training_script_path Job#training_script_path}
    */
    readonly trainingScriptPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#yaml_parameters Job#yaml_parameters}
    */
    readonly yamlParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#yaml_parameters_file_path Job#yaml_parameters_file_path}
    */
    readonly yamlParametersFilePath?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#compute Job#compute}
    */
    readonly compute?: JobTaskForEachTaskTaskGenAiComputeTaskCompute;
}
export declare function jobTaskForEachTaskTaskGenAiComputeTaskToTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskOutputReference | JobTaskForEachTaskTaskGenAiComputeTask): any;
export declare function jobTaskForEachTaskTaskGenAiComputeTaskToHclTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskOutputReference | JobTaskForEachTaskTaskGenAiComputeTask): any;
export declare class JobTaskForEachTaskTaskGenAiComputeTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskGenAiComputeTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskGenAiComputeTask | undefined);
    private _command?;
    get command(): string;
    set command(value: string);
    resetCommand(): void;
    get commandInput(): string | undefined;
    private _dlRuntimeImage?;
    get dlRuntimeImage(): string;
    set dlRuntimeImage(value: string);
    get dlRuntimeImageInput(): string | undefined;
    private _mlflowExperimentName?;
    get mlflowExperimentName(): string;
    set mlflowExperimentName(value: string);
    resetMlflowExperimentName(): void;
    get mlflowExperimentNameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _trainingScriptPath?;
    get trainingScriptPath(): string;
    set trainingScriptPath(value: string);
    resetTrainingScriptPath(): void;
    get trainingScriptPathInput(): string | undefined;
    private _yamlParameters?;
    get yamlParameters(): string;
    set yamlParameters(value: string);
    resetYamlParameters(): void;
    get yamlParametersInput(): string | undefined;
    private _yamlParametersFilePath?;
    get yamlParametersFilePath(): string;
    set yamlParametersFilePath(value: string);
    resetYamlParametersFilePath(): void;
    get yamlParametersFilePathInput(): string | undefined;
    private _compute;
    get compute(): JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference;
    putCompute(value: JobTaskForEachTaskTaskGenAiComputeTaskCompute): void;
    resetCompute(): void;
    get computeInput(): JobTaskForEachTaskTaskGenAiComputeTaskCompute | undefined;
}
export interface JobTaskForEachTaskTaskHealthRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#metric Job#metric}
    */
    readonly metric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#op Job#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#value Job#value}
    */
    readonly value: number;
}
export declare function jobTaskForEachTaskTaskHealthRulesToTerraform(struct?: JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskHealthRulesToHclTerraform(struct?: JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskHealthRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class JobTaskForEachTaskTaskHealthRulesList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskHealthRulesOutputReference;
}
export interface JobTaskForEachTaskTaskHealth {
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#rules Job#rules}
    */
    readonly rules: JobTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskHealthToTerraform(struct?: JobTaskForEachTaskTaskHealthOutputReference | JobTaskForEachTaskTaskHealth): any;
export declare function jobTaskForEachTaskTaskHealthToHclTerraform(struct?: JobTaskForEachTaskTaskHealthOutputReference | JobTaskForEachTaskTaskHealth): any;
export declare class JobTaskForEachTaskTaskHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskHealth | undefined;
    set internalValue(value: JobTaskForEachTaskTaskHealth | undefined);
    private _rules;
    get rules(): JobTaskForEachTaskTaskHealthRulesList;
    putRules(value: JobTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | JobTaskForEachTaskTaskHealthRules[] | undefined;
}
export interface JobTaskForEachTaskTaskLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskLibraryCranToTerraform(struct?: JobTaskForEachTaskTaskLibraryCranOutputReference | JobTaskForEachTaskTaskLibraryCran): any;
export declare function jobTaskForEachTaskTaskLibraryCranToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryCranOutputReference | JobTaskForEachTaskTaskLibraryCran): any;
export declare class JobTaskForEachTaskTaskLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryCran | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskLibraryMavenToTerraform(struct?: JobTaskForEachTaskTaskLibraryMavenOutputReference | JobTaskForEachTaskTaskLibraryMaven): any;
export declare function jobTaskForEachTaskTaskLibraryMavenToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryMavenOutputReference | JobTaskForEachTaskTaskLibraryMaven): any;
export declare class JobTaskForEachTaskTaskLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryMaven | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobTaskForEachTaskTaskLibraryProviderConfigToTerraform(struct?: JobTaskForEachTaskTaskLibraryProviderConfigOutputReference | JobTaskForEachTaskTaskLibraryProviderConfig): any;
export declare function jobTaskForEachTaskTaskLibraryProviderConfigToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryProviderConfigOutputReference | JobTaskForEachTaskTaskLibraryProviderConfig): any;
export declare class JobTaskForEachTaskTaskLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryProviderConfig | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskLibraryPypiToTerraform(struct?: JobTaskForEachTaskTaskLibraryPypiOutputReference | JobTaskForEachTaskTaskLibraryPypi): any;
export declare function jobTaskForEachTaskTaskLibraryPypiToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryPypiOutputReference | JobTaskForEachTaskTaskLibraryPypi): any;
export declare class JobTaskForEachTaskTaskLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryPypi | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobTaskForEachTaskTaskLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobTaskForEachTaskTaskLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskForEachTaskTaskLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobTaskForEachTaskTaskLibraryPypi;
}
export declare function jobTaskForEachTaskTaskLibraryToTerraform(struct?: JobTaskForEachTaskTaskLibrary | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskLibraryToHclTerraform(struct?: JobTaskForEachTaskTaskLibrary | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobTaskForEachTaskTaskLibraryCranOutputReference;
    putCran(value: JobTaskForEachTaskTaskLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobTaskForEachTaskTaskLibraryCran | undefined;
    private _maven;
    get maven(): JobTaskForEachTaskTaskLibraryMavenOutputReference;
    putMaven(value: JobTaskForEachTaskTaskLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobTaskForEachTaskTaskLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskForEachTaskTaskLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobTaskForEachTaskTaskLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskForEachTaskTaskLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobTaskForEachTaskTaskLibraryPypiOutputReference;
    putPypi(value: JobTaskForEachTaskTaskLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobTaskForEachTaskTaskLibraryPypi | undefined;
}
export declare class JobTaskForEachTaskTaskLibraryList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobTaskForEachTaskTaskLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskLibraryOutputReference;
}
export interface JobTaskForEachTaskTaskNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#max_workers Job#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#min_workers Job#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function jobTaskForEachTaskTaskNewClusterAutoscaleToTerraform(struct?: JobTaskForEachTaskTaskNewClusterAutoscaleOutputReference | JobTaskForEachTaskTaskNewClusterAutoscale): any;
export declare function jobTaskForEachTaskTaskNewClusterAutoscaleToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterAutoscaleOutputReference | JobTaskForEachTaskTaskNewClusterAutoscale): any;
export declare class JobTaskForEachTaskTaskNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterAutoscale | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
