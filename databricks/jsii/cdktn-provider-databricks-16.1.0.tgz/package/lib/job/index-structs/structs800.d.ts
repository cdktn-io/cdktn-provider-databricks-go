/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface JobTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#create Job#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#update Job#update}
    */
    readonly update?: string;
}
export declare function jobTimeoutsToTerraform(struct?: JobTimeouts | cdktn.IResolvable): any;
export declare function jobTimeoutsToHclTerraform(struct?: JobTimeouts | cdktn.IResolvable): any;
export declare class JobTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: JobTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface JobTriggerFileArrival {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerFileArrivalToTerraform(struct?: JobTriggerFileArrivalOutputReference | JobTriggerFileArrival): any;
export declare function jobTriggerFileArrivalToHclTerraform(struct?: JobTriggerFileArrivalOutputReference | JobTriggerFileArrival): any;
export declare class JobTriggerFileArrivalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerFileArrival | undefined;
    set internalValue(value: JobTriggerFileArrival | undefined);
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggerModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#aliases Job#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#condition Job#condition}
    */
    readonly condition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#securable_name Job#securable_name}
    */
    readonly securableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerModelToTerraform(struct?: JobTriggerModelOutputReference | JobTriggerModel): any;
export declare function jobTriggerModelToHclTerraform(struct?: JobTriggerModelOutputReference | JobTriggerModel): any;
export declare class JobTriggerModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerModel | undefined;
    set internalValue(value: JobTriggerModel | undefined);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _securableName?;
    get securableName(): string;
    set securableName(value: string);
    resetSecurableName(): void;
    get securableNameInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggerPeriodic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#interval Job#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#unit Job#unit}
    */
    readonly unit: string;
}
export declare function jobTriggerPeriodicToTerraform(struct?: JobTriggerPeriodicOutputReference | JobTriggerPeriodic): any;
export declare function jobTriggerPeriodicToHclTerraform(struct?: JobTriggerPeriodicOutputReference | JobTriggerPeriodic): any;
export declare class JobTriggerPeriodicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerPeriodic | undefined;
    set internalValue(value: JobTriggerPeriodic | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface JobTriggerTableUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#condition Job#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#table_names Job#table_names}
    */
    readonly tableNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerTableUpdateToTerraform(struct?: JobTriggerTableUpdateOutputReference | JobTriggerTableUpdate): any;
export declare function jobTriggerTableUpdateToHclTerraform(struct?: JobTriggerTableUpdateOutputReference | JobTriggerTableUpdate): any;
export declare class JobTriggerTableUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerTableUpdate | undefined;
    set internalValue(value: JobTriggerTableUpdate | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _tableNames?;
    get tableNames(): string[];
    set tableNames(value: string[]);
    get tableNamesInput(): string[] | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#pause_status Job#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * file_arrival block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#file_arrival Job#file_arrival}
    */
    readonly fileArrival?: JobTriggerFileArrival;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#model Job#model}
    */
    readonly model?: JobTriggerModel;
    /**
    * periodic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#periodic Job#periodic}
    */
    readonly periodic?: JobTriggerPeriodic;
    /**
    * table_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#table_update Job#table_update}
    */
    readonly tableUpdate?: JobTriggerTableUpdate;
}
export declare function jobTriggerToTerraform(struct?: JobTriggerOutputReference | JobTrigger): any;
export declare function jobTriggerToHclTerraform(struct?: JobTriggerOutputReference | JobTrigger): any;
export declare class JobTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTrigger | undefined;
    set internalValue(value: JobTrigger | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _fileArrival;
    get fileArrival(): JobTriggerFileArrivalOutputReference;
    putFileArrival(value: JobTriggerFileArrival): void;
    resetFileArrival(): void;
    get fileArrivalInput(): JobTriggerFileArrival | undefined;
    private _model;
    get model(): JobTriggerModelOutputReference;
    putModel(value: JobTriggerModel): void;
    resetModel(): void;
    get modelInput(): JobTriggerModel | undefined;
    private _periodic;
    get periodic(): JobTriggerPeriodicOutputReference;
    putPeriodic(value: JobTriggerPeriodic): void;
    resetPeriodic(): void;
    get periodicInput(): JobTriggerPeriodic | undefined;
    private _tableUpdate;
    get tableUpdate(): JobTriggerTableUpdateOutputReference;
    putTableUpdate(value: JobTriggerTableUpdate): void;
    resetTableUpdate(): void;
    get tableUpdateInput(): JobTriggerTableUpdate | undefined;
}
export interface JobWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface JobWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnFailureToTerraform(struct?: JobWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnFailureToHclTerraform(struct?: JobWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnFailureOutputReference;
}
export interface JobWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnStartToTerraform(struct?: JobWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnStartToHclTerraform(struct?: JobWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnStartList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnStartOutputReference;
}
export interface JobWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface JobWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnSuccessToTerraform(struct?: JobWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnSuccessToHclTerraform(struct?: JobWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    protected terraformResource: cdktn.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnSuccessOutputReference;
}
export interface JobWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: JobWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.111.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function jobWebhookNotificationsToTerraform(struct?: JobWebhookNotificationsOutputReference | JobWebhookNotifications): any;
export declare function jobWebhookNotificationsToHclTerraform(struct?: JobWebhookNotificationsOutputReference | JobWebhookNotifications): any;
export declare class JobWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobWebhookNotifications | undefined;
    set internalValue(value: JobWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): JobWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): JobWebhookNotificationsOnFailureList;
    putOnFailure(value: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | JobWebhookNotificationsOnFailure[] | undefined;
    private _onStart;
    get onStart(): JobWebhookNotificationsOnStartList;
    putOnStart(value: JobWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | JobWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): JobWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | JobWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): JobWebhookNotificationsOnSuccessList;
    putOnSuccess(value: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | JobWebhookNotificationsOnSuccess[] | undefined;
}
