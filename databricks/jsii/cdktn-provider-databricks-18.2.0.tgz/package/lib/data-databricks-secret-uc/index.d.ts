/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSecretUcConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/secret_uc#full_name DataDatabricksSecretUc#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/secret_uc#provider_config DataDatabricksSecretUc#provider_config}
    */
    readonly providerConfig?: DataDatabricksSecretUcProviderConfig;
}
export interface DataDatabricksSecretUcProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/secret_uc#workspace_id DataDatabricksSecretUc#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSecretUcProviderConfigToTerraform(struct?: DataDatabricksSecretUcProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSecretUcProviderConfigToHclTerraform(struct?: DataDatabricksSecretUcProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSecretUcProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSecretUcProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSecretUcProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/secret_uc databricks_secret_uc}
*/
export declare class DataDatabricksSecretUc extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_secret_uc";
    /**
    * Generates CDKTN code for importing a DataDatabricksSecretUc resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSecretUc to import
    * @param importFromId The id of the existing DataDatabricksSecretUc that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/secret_uc#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSecretUc to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/secret_uc databricks_secret_uc} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSecretUcConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksSecretUcConfig);
    get catalogName(): string;
    get comment(): string;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get effectiveValue(): string;
    get expireTime(): string;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    get metastoreId(): string;
    get name(): string;
    get owner(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksSecretUcProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSecretUcProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSecretUcProviderConfig | undefined;
    get schemaName(): string;
    get updateTime(): string;
    get updatedBy(): string;
    get value(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
