/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SqlVisualizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#description SqlVisualization#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#id SqlVisualization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#name SqlVisualization#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#options SqlVisualization#options}
    */
    readonly options: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#query_id SqlVisualization#query_id}
    */
    readonly queryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#query_plan SqlVisualization#query_plan}
    */
    readonly queryPlan?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#type SqlVisualization#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#visualization_id SqlVisualization#visualization_id}
    */
    readonly visualizationId?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#provider_config SqlVisualization#provider_config}
    */
    readonly providerConfig?: SqlVisualizationProviderConfig;
}
export interface SqlVisualizationProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#workspace_id SqlVisualization#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function sqlVisualizationProviderConfigToTerraform(struct?: SqlVisualizationProviderConfigOutputReference | SqlVisualizationProviderConfig): any;
export declare function sqlVisualizationProviderConfigToHclTerraform(struct?: SqlVisualizationProviderConfigOutputReference | SqlVisualizationProviderConfig): any;
export declare class SqlVisualizationProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlVisualizationProviderConfig | undefined;
    set internalValue(value: SqlVisualizationProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization databricks_sql_visualization}
*/
export declare class SqlVisualization extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sql_visualization";
    /**
    * Generates CDKTN code for importing a SqlVisualization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlVisualization to import
    * @param importFromId The id of the existing SqlVisualization that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlVisualization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/sql_visualization databricks_sql_visualization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlVisualizationConfig
    */
    constructor(scope: Construct, id: string, config: SqlVisualizationConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options?;
    get options(): string;
    set options(value: string);
    get optionsInput(): string | undefined;
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
    private _queryPlan?;
    get queryPlan(): string;
    set queryPlan(value: string);
    resetQueryPlan(): void;
    get queryPlanInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _visualizationId?;
    get visualizationId(): string;
    set visualizationId(value: string);
    resetVisualizationId(): void;
    get visualizationIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): SqlVisualizationProviderConfigOutputReference;
    putProviderConfig(value: SqlVisualizationProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SqlVisualizationProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
