/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksEnvironmentsWorkspaceBaseEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment#name DataDatabricksEnvironmentsWorkspaceBaseEnvironment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment#provider_config DataDatabricksEnvironmentsWorkspaceBaseEnvironment#provider_config}
    */
    readonly providerConfig?: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig;
}
export interface DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment#workspace_id DataDatabricksEnvironmentsWorkspaceBaseEnvironment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfigToTerraform(struct?: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfigToHclTerraform(struct?: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment#dependencies DataDatabricksEnvironmentsWorkspaceBaseEnvironment#dependencies}
    */
    readonly dependencies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment#environment_version DataDatabricksEnvironmentsWorkspaceBaseEnvironment#environment_version}
    */
    readonly environmentVersion?: string;
}
export declare function dataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpecToTerraform(struct?: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpec): any;
export declare function dataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpecToHclTerraform(struct?: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpec): any;
export declare class DataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpec | undefined;
    set internalValue(value: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpec | undefined);
    private _dependencies?;
    get dependencies(): string[];
    set dependencies(value: string[]);
    resetDependencies(): void;
    get dependenciesInput(): string[] | undefined;
    private _environmentVersion?;
    get environmentVersion(): string;
    set environmentVersion(value: string);
    resetEnvironmentVersion(): void;
    get environmentVersionInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment databricks_environments_workspace_base_environment}
*/
export declare class DataDatabricksEnvironmentsWorkspaceBaseEnvironment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_environments_workspace_base_environment";
    /**
    * Generates CDKTN code for importing a DataDatabricksEnvironmentsWorkspaceBaseEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksEnvironmentsWorkspaceBaseEnvironment to import
    * @param importFromId The id of the existing DataDatabricksEnvironmentsWorkspaceBaseEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksEnvironmentsWorkspaceBaseEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/environments_workspace_base_environment databricks_environments_workspace_base_environment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksEnvironmentsWorkspaceBaseEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentConfig);
    get baseEnvironmentType(): string;
    get createTime(): string;
    get creatorUserId(): string;
    get displayName(): string;
    get effectiveBaseEnvironmentType(): string;
    get filepath(): string;
    get isDefault(): cdktn.IResolvable;
    get lastUpdatedUserId(): string;
    get message(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksEnvironmentsWorkspaceBaseEnvironmentProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksEnvironmentsWorkspaceBaseEnvironmentSpecOutputReference;
    get status(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
