/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDataClassificationCatalogConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#name DataDatabricksDataClassificationCatalogConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#provider_config DataDatabricksDataClassificationCatalogConfig#provider_config}
    */
    readonly providerConfig?: DataDatabricksDataClassificationCatalogConfigProviderConfig;
}
export interface DataDatabricksDataClassificationCatalogConfigAutoTagConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#auto_tagging_mode DataDatabricksDataClassificationCatalogConfig#auto_tagging_mode}
    */
    readonly autoTaggingMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#classification_tag DataDatabricksDataClassificationCatalogConfig#classification_tag}
    */
    readonly classificationTag: string;
}
export declare function dataDatabricksDataClassificationCatalogConfigAutoTagConfigsToTerraform(struct?: DataDatabricksDataClassificationCatalogConfigAutoTagConfigs): any;
export declare function dataDatabricksDataClassificationCatalogConfigAutoTagConfigsToHclTerraform(struct?: DataDatabricksDataClassificationCatalogConfigAutoTagConfigs): any;
export declare class DataDatabricksDataClassificationCatalogConfigAutoTagConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDataClassificationCatalogConfigAutoTagConfigs | undefined;
    set internalValue(value: DataDatabricksDataClassificationCatalogConfigAutoTagConfigs | undefined);
    private _autoTaggingMode?;
    get autoTaggingMode(): string;
    set autoTaggingMode(value: string);
    get autoTaggingModeInput(): string | undefined;
    private _classificationTag?;
    get classificationTag(): string;
    set classificationTag(value: string);
    get classificationTagInput(): string | undefined;
}
export declare class DataDatabricksDataClassificationCatalogConfigAutoTagConfigsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDataClassificationCatalogConfigAutoTagConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDataClassificationCatalogConfigAutoTagConfigsOutputReference;
}
export interface DataDatabricksDataClassificationCatalogConfigExcludedSchemas {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#names DataDatabricksDataClassificationCatalogConfig#names}
    */
    readonly names: string[];
}
export declare function dataDatabricksDataClassificationCatalogConfigExcludedSchemasToTerraform(struct?: DataDatabricksDataClassificationCatalogConfigExcludedSchemas): any;
export declare function dataDatabricksDataClassificationCatalogConfigExcludedSchemasToHclTerraform(struct?: DataDatabricksDataClassificationCatalogConfigExcludedSchemas): any;
export declare class DataDatabricksDataClassificationCatalogConfigExcludedSchemasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataClassificationCatalogConfigExcludedSchemas | undefined;
    set internalValue(value: DataDatabricksDataClassificationCatalogConfigExcludedSchemas | undefined);
    private _names?;
    get names(): string[];
    set names(value: string[]);
    get namesInput(): string[] | undefined;
}
export interface DataDatabricksDataClassificationCatalogConfigIncludedSchemas {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#names DataDatabricksDataClassificationCatalogConfig#names}
    */
    readonly names: string[];
}
export declare function dataDatabricksDataClassificationCatalogConfigIncludedSchemasToTerraform(struct?: DataDatabricksDataClassificationCatalogConfigIncludedSchemas): any;
export declare function dataDatabricksDataClassificationCatalogConfigIncludedSchemasToHclTerraform(struct?: DataDatabricksDataClassificationCatalogConfigIncludedSchemas): any;
export declare class DataDatabricksDataClassificationCatalogConfigIncludedSchemasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataClassificationCatalogConfigIncludedSchemas | undefined;
    set internalValue(value: DataDatabricksDataClassificationCatalogConfigIncludedSchemas | undefined);
    private _names?;
    get names(): string[];
    set names(value: string[]);
    get namesInput(): string[] | undefined;
}
export interface DataDatabricksDataClassificationCatalogConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#workspace_id DataDatabricksDataClassificationCatalogConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDataClassificationCatalogConfigProviderConfigToTerraform(struct?: DataDatabricksDataClassificationCatalogConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDataClassificationCatalogConfigProviderConfigToHclTerraform(struct?: DataDatabricksDataClassificationCatalogConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDataClassificationCatalogConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataClassificationCatalogConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataClassificationCatalogConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config databricks_data_classification_catalog_config}
*/
export declare class DataDatabricksDataClassificationCatalogConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_data_classification_catalog_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksDataClassificationCatalogConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDataClassificationCatalogConfig to import
    * @param importFromId The id of the existing DataDatabricksDataClassificationCatalogConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDataClassificationCatalogConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/data_classification_catalog_config databricks_data_classification_catalog_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDataClassificationCatalogConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDataClassificationCatalogConfigConfig);
    private _autoTagConfigs;
    get autoTagConfigs(): DataDatabricksDataClassificationCatalogConfigAutoTagConfigsList;
    private _excludedSchemas;
    get excludedSchemas(): DataDatabricksDataClassificationCatalogConfigExcludedSchemasOutputReference;
    private _includedSchemas;
    get includedSchemas(): DataDatabricksDataClassificationCatalogConfigIncludedSchemasOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDataClassificationCatalogConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDataClassificationCatalogConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDataClassificationCatalogConfigProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
