/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSparkVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#beta DataDatabricksSparkVersion#beta}
    */
    readonly beta?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#genomics DataDatabricksSparkVersion#genomics}
    */
    readonly genomics?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#gpu DataDatabricksSparkVersion#gpu}
    */
    readonly gpu?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#graviton DataDatabricksSparkVersion#graviton}
    */
    readonly graviton?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#id DataDatabricksSparkVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#latest DataDatabricksSparkVersion#latest}
    */
    readonly latest?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#long_term_support DataDatabricksSparkVersion#long_term_support}
    */
    readonly longTermSupport?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#ml DataDatabricksSparkVersion#ml}
    */
    readonly ml?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#photon DataDatabricksSparkVersion#photon}
    */
    readonly photon?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#scala DataDatabricksSparkVersion#scala}
    */
    readonly scala?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#spark_version DataDatabricksSparkVersion#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#provider_config DataDatabricksSparkVersion#provider_config}
    */
    readonly providerConfig?: DataDatabricksSparkVersionProviderConfig;
}
export interface DataDatabricksSparkVersionProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#workspace_id DataDatabricksSparkVersion#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSparkVersionProviderConfigToTerraform(struct?: DataDatabricksSparkVersionProviderConfigOutputReference | DataDatabricksSparkVersionProviderConfig): any;
export declare function dataDatabricksSparkVersionProviderConfigToHclTerraform(struct?: DataDatabricksSparkVersionProviderConfigOutputReference | DataDatabricksSparkVersionProviderConfig): any;
export declare class DataDatabricksSparkVersionProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSparkVersionProviderConfig | undefined;
    set internalValue(value: DataDatabricksSparkVersionProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version databricks_spark_version}
*/
export declare class DataDatabricksSparkVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_spark_version";
    /**
    * Generates CDKTN code for importing a DataDatabricksSparkVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSparkVersion to import
    * @param importFromId The id of the existing DataDatabricksSparkVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSparkVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/spark_version databricks_spark_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSparkVersionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksSparkVersionConfig);
    private _beta?;
    get beta(): boolean | cdktn.IResolvable;
    set beta(value: boolean | cdktn.IResolvable);
    resetBeta(): void;
    get betaInput(): boolean | cdktn.IResolvable | undefined;
    private _genomics?;
    get genomics(): boolean | cdktn.IResolvable;
    set genomics(value: boolean | cdktn.IResolvable);
    resetGenomics(): void;
    get genomicsInput(): boolean | cdktn.IResolvable | undefined;
    private _gpu?;
    get gpu(): boolean | cdktn.IResolvable;
    set gpu(value: boolean | cdktn.IResolvable);
    resetGpu(): void;
    get gpuInput(): boolean | cdktn.IResolvable | undefined;
    private _graviton?;
    get graviton(): boolean | cdktn.IResolvable;
    set graviton(value: boolean | cdktn.IResolvable);
    resetGraviton(): void;
    get gravitonInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _latest?;
    get latest(): boolean | cdktn.IResolvable;
    set latest(value: boolean | cdktn.IResolvable);
    resetLatest(): void;
    get latestInput(): boolean | cdktn.IResolvable | undefined;
    private _longTermSupport?;
    get longTermSupport(): boolean | cdktn.IResolvable;
    set longTermSupport(value: boolean | cdktn.IResolvable);
    resetLongTermSupport(): void;
    get longTermSupportInput(): boolean | cdktn.IResolvable | undefined;
    private _ml?;
    get ml(): boolean | cdktn.IResolvable;
    set ml(value: boolean | cdktn.IResolvable);
    resetMl(): void;
    get mlInput(): boolean | cdktn.IResolvable | undefined;
    private _photon?;
    get photon(): boolean | cdktn.IResolvable;
    set photon(value: boolean | cdktn.IResolvable);
    resetPhoton(): void;
    get photonInput(): boolean | cdktn.IResolvable | undefined;
    private _scala?;
    get scala(): string;
    set scala(value: string);
    resetScala(): void;
    get scalaInput(): string | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSparkVersionProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSparkVersionProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksSparkVersionProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
