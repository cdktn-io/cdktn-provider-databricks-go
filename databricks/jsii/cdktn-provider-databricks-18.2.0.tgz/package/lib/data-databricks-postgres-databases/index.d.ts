/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresDatabasesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#page_size DataDatabricksPostgresDatabases#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#parent DataDatabricksPostgresDatabases#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#provider_config DataDatabricksPostgresDatabases#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresDatabasesProviderConfig;
}
export interface DataDatabricksPostgresDatabasesDatabasesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#workspace_id DataDatabricksPostgresDatabases#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresDatabasesDatabasesProviderConfigToTerraform(struct?: DataDatabricksPostgresDatabasesDatabasesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresDatabasesDatabasesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresDatabasesDatabasesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresDatabasesDatabasesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDatabasesDatabasesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresDatabasesDatabasesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresDatabasesDatabasesSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#postgres_database DataDatabricksPostgresDatabases#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#role DataDatabricksPostgresDatabases#role}
    */
    readonly role: string;
}
export declare function dataDatabricksPostgresDatabasesDatabasesSpecToTerraform(struct?: DataDatabricksPostgresDatabasesDatabasesSpec): any;
export declare function dataDatabricksPostgresDatabasesDatabasesSpecToHclTerraform(struct?: DataDatabricksPostgresDatabasesDatabasesSpec): any;
export declare class DataDatabricksPostgresDatabasesDatabasesSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDatabasesDatabasesSpec | undefined;
    set internalValue(value: DataDatabricksPostgresDatabasesDatabasesSpec | undefined);
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
}
export interface DataDatabricksPostgresDatabasesDatabasesStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#postgres_database DataDatabricksPostgresDatabases#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#role DataDatabricksPostgresDatabases#role}
    */
    readonly role?: string;
}
export declare function dataDatabricksPostgresDatabasesDatabasesStatusToTerraform(struct?: DataDatabricksPostgresDatabasesDatabasesStatus): any;
export declare function dataDatabricksPostgresDatabasesDatabasesStatusToHclTerraform(struct?: DataDatabricksPostgresDatabasesDatabasesStatus): any;
export declare class DataDatabricksPostgresDatabasesDatabasesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDatabasesDatabasesStatus | undefined;
    set internalValue(value: DataDatabricksPostgresDatabasesDatabasesStatus | undefined);
    get databaseId(): string;
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
}
export interface DataDatabricksPostgresDatabasesDatabases {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#name DataDatabricksPostgresDatabases#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#provider_config DataDatabricksPostgresDatabases#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresDatabasesDatabasesProviderConfig;
}
export declare function dataDatabricksPostgresDatabasesDatabasesToTerraform(struct?: DataDatabricksPostgresDatabasesDatabases): any;
export declare function dataDatabricksPostgresDatabasesDatabasesToHclTerraform(struct?: DataDatabricksPostgresDatabasesDatabases): any;
export declare class DataDatabricksPostgresDatabasesDatabasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresDatabasesDatabases | undefined;
    set internalValue(value: DataDatabricksPostgresDatabasesDatabases | undefined);
    get createTime(): string;
    get databaseId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresDatabasesDatabasesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresDatabasesDatabasesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresDatabasesDatabasesProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresDatabasesDatabasesSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresDatabasesDatabasesStatusOutputReference;
    get updateTime(): string;
}
export declare class DataDatabricksPostgresDatabasesDatabasesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresDatabasesDatabases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresDatabasesDatabasesOutputReference;
}
export interface DataDatabricksPostgresDatabasesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#workspace_id DataDatabricksPostgresDatabases#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresDatabasesProviderConfigToTerraform(struct?: DataDatabricksPostgresDatabasesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresDatabasesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresDatabasesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresDatabasesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresDatabasesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresDatabasesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases databricks_postgres_databases}
*/
export declare class DataDatabricksPostgresDatabases extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_databases";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresDatabases resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresDatabases to import
    * @param importFromId The id of the existing DataDatabricksPostgresDatabases that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresDatabases to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/postgres_databases databricks_postgres_databases} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresDatabasesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresDatabasesConfig);
    private _databases;
    get databases(): DataDatabricksPostgresDatabasesDatabasesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresDatabasesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresDatabasesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresDatabasesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
