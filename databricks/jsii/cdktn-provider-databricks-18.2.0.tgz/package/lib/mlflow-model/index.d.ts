/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MlflowModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#description MlflowModel#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#id MlflowModel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#name MlflowModel#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#provider_config MlflowModel#provider_config}
    */
    readonly providerConfig?: MlflowModelProviderConfig;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#tags MlflowModel#tags}
    */
    readonly tags?: MlflowModelTags[] | cdktn.IResolvable;
}
export interface MlflowModelProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#workspace_id MlflowModel#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function mlflowModelProviderConfigToTerraform(struct?: MlflowModelProviderConfigOutputReference | MlflowModelProviderConfig): any;
export declare function mlflowModelProviderConfigToHclTerraform(struct?: MlflowModelProviderConfigOutputReference | MlflowModelProviderConfig): any;
export declare class MlflowModelProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MlflowModelProviderConfig | undefined;
    set internalValue(value: MlflowModelProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface MlflowModelTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#key MlflowModel#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#value MlflowModel#value}
    */
    readonly value?: string;
}
export declare function mlflowModelTagsToTerraform(struct?: MlflowModelTags | cdktn.IResolvable): any;
export declare function mlflowModelTagsToHclTerraform(struct?: MlflowModelTags | cdktn.IResolvable): any;
export declare class MlflowModelTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): MlflowModelTags | cdktn.IResolvable | undefined;
    set internalValue(value: MlflowModelTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class MlflowModelTagsList extends cdktn.ComplexList {
    internalValue?: MlflowModelTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): MlflowModelTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model databricks_mlflow_model}
*/
export declare class MlflowModel extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mlflow_model";
    /**
    * Generates CDKTN code for importing a MlflowModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MlflowModel to import
    * @param importFromId The id of the existing MlflowModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MlflowModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/mlflow_model databricks_mlflow_model} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MlflowModelConfig
    */
    constructor(scope: Construct, id: string, config: MlflowModelConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get registeredModelId(): string;
    private _providerConfig;
    get providerConfig(): MlflowModelProviderConfigOutputReference;
    putProviderConfig(value: MlflowModelProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): MlflowModelProviderConfig | undefined;
    private _tags;
    get tags(): MlflowModelTagsList;
    putTags(value: MlflowModelTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | MlflowModelTags[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
