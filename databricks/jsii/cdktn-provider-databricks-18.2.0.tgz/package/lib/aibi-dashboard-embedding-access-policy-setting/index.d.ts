/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AibiDashboardEmbeddingAccessPolicySettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#etag AibiDashboardEmbeddingAccessPolicySetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#id AibiDashboardEmbeddingAccessPolicySetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#setting_name AibiDashboardEmbeddingAccessPolicySetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * aibi_dashboard_embedding_access_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#aibi_dashboard_embedding_access_policy AibiDashboardEmbeddingAccessPolicySetting#aibi_dashboard_embedding_access_policy}
    */
    readonly aibiDashboardEmbeddingAccessPolicy: AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#provider_config AibiDashboardEmbeddingAccessPolicySetting#provider_config}
    */
    readonly providerConfig?: AibiDashboardEmbeddingAccessPolicySettingProviderConfig;
}
export interface AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#access_policy_type AibiDashboardEmbeddingAccessPolicySetting#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function aibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicyOutputReference | AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy): any;
export declare function aibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicyOutputReference | AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy): any;
export declare class AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface AibiDashboardEmbeddingAccessPolicySettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#workspace_id AibiDashboardEmbeddingAccessPolicySetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function aibiDashboardEmbeddingAccessPolicySettingProviderConfigToTerraform(struct?: AibiDashboardEmbeddingAccessPolicySettingProviderConfigOutputReference | AibiDashboardEmbeddingAccessPolicySettingProviderConfig): any;
export declare function aibiDashboardEmbeddingAccessPolicySettingProviderConfigToHclTerraform(struct?: AibiDashboardEmbeddingAccessPolicySettingProviderConfigOutputReference | AibiDashboardEmbeddingAccessPolicySettingProviderConfig): any;
export declare class AibiDashboardEmbeddingAccessPolicySettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AibiDashboardEmbeddingAccessPolicySettingProviderConfig | undefined;
    set internalValue(value: AibiDashboardEmbeddingAccessPolicySettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting databricks_aibi_dashboard_embedding_access_policy_setting}
*/
export declare class AibiDashboardEmbeddingAccessPolicySetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_aibi_dashboard_embedding_access_policy_setting";
    /**
    * Generates CDKTN code for importing a AibiDashboardEmbeddingAccessPolicySetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AibiDashboardEmbeddingAccessPolicySetting to import
    * @param importFromId The id of the existing AibiDashboardEmbeddingAccessPolicySetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AibiDashboardEmbeddingAccessPolicySetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/resources/aibi_dashboard_embedding_access_policy_setting databricks_aibi_dashboard_embedding_access_policy_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AibiDashboardEmbeddingAccessPolicySettingConfig
    */
    constructor(scope: Construct, id: string, config: AibiDashboardEmbeddingAccessPolicySettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicyOutputReference;
    putAibiDashboardEmbeddingAccessPolicy(value: AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy): void;
    get aibiDashboardEmbeddingAccessPolicyInput(): AibiDashboardEmbeddingAccessPolicySettingAibiDashboardEmbeddingAccessPolicy | undefined;
    private _providerConfig;
    get providerConfig(): AibiDashboardEmbeddingAccessPolicySettingProviderConfigOutputReference;
    putProviderConfig(value: AibiDashboardEmbeddingAccessPolicySettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): AibiDashboardEmbeddingAccessPolicySettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
