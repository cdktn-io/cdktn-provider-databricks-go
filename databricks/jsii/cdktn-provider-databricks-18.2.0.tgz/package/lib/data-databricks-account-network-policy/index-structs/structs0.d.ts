/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ids DataDatabricksAccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsToTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#internet_destination_type DataDatabricksAccountNetworkPolicy#internet_destination_type}
    */
    readonly internetDestinationType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsToTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _internetDestinationType?;
    get internetDestinationType(): string;
    set internetDestinationType(value: string);
    resetInternetDestinationType(): void;
    get internetDestinationTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#azure_storage_account DataDatabricksAccountNetworkPolicy#azure_storage_account}
    */
    readonly azureStorageAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#azure_storage_service DataDatabricksAccountNetworkPolicy#azure_storage_service}
    */
    readonly azureStorageService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#bucket_name DataDatabricksAccountNetworkPolicy#bucket_name}
    */
    readonly bucketName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#region DataDatabricksAccountNetworkPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#storage_destination_type DataDatabricksAccountNetworkPolicy#storage_destination_type}
    */
    readonly storageDestinationType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsToTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations | cdktn.IResolvable | undefined);
    private _azureStorageAccount?;
    get azureStorageAccount(): string;
    set azureStorageAccount(value: string);
    resetAzureStorageAccount(): void;
    get azureStorageAccountInput(): string | undefined;
    private _azureStorageService?;
    get azureStorageService(): string;
    set azureStorageService(value: string);
    resetAzureStorageService(): void;
    get azureStorageServiceInput(): string | undefined;
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    resetBucketName(): void;
    get bucketNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageDestinationType?;
    get storageDestinationType(): string;
    set storageDestinationType(value: string);
    resetStorageDestinationType(): void;
    get storageDestinationTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#internet_destination_type DataDatabricksAccountNetworkPolicy#internet_destination_type}
    */
    readonly internetDestinationType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsToTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations | cdktn.IResolvable | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    private _internetDestinationType?;
    get internetDestinationType(): string;
    set internetDestinationType(value: string);
    resetInternetDestinationType(): void;
    get internetDestinationTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#dry_run_mode_product_filter DataDatabricksAccountNetworkPolicy#dry_run_mode_product_filter}
    */
    readonly dryRunModeProductFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#enforcement_mode DataDatabricksAccountNetworkPolicy#enforcement_mode}
    */
    readonly enforcementMode?: string;
}
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcementToTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcementToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | cdktn.IResolvable | undefined);
    private _dryRunModeProductFilter?;
    get dryRunModeProductFilter(): string[];
    set dryRunModeProductFilter(value: string[]);
    resetDryRunModeProductFilter(): void;
    get dryRunModeProductFilterInput(): string[] | undefined;
    private _enforcementMode?;
    get enforcementMode(): string;
    set enforcementMode(value: string);
    resetEnforcementMode(): void;
    get enforcementModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyEgressNetworkAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allowed_databricks_destinations DataDatabricksAccountNetworkPolicy#allowed_databricks_destinations}
    */
    readonly allowedDatabricksDestinations?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allowed_internet_destinations DataDatabricksAccountNetworkPolicy#allowed_internet_destinations}
    */
    readonly allowedInternetDestinations?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allowed_storage_destinations DataDatabricksAccountNetworkPolicy#allowed_storage_destinations}
    */
    readonly allowedStorageDestinations?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#blocked_internet_destinations DataDatabricksAccountNetworkPolicy#blocked_internet_destinations}
    */
    readonly blockedInternetDestinations?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#policy_enforcement DataDatabricksAccountNetworkPolicy#policy_enforcement}
    */
    readonly policyEnforcement?: DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#restriction_mode DataDatabricksAccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessToTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyEgressNetworkAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyEgressNetworkAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccess | cdktn.IResolvable | undefined);
    private _allowedDatabricksDestinations;
    get allowedDatabricksDestinations(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinationsList;
    putAllowedDatabricksDestinations(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | cdktn.IResolvable): void;
    resetAllowedDatabricksDestinations(): void;
    get allowedDatabricksDestinationsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedDatabricksDestinations[] | undefined;
    private _allowedInternetDestinations;
    get allowedInternetDestinations(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinationsList;
    putAllowedInternetDestinations(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | cdktn.IResolvable): void;
    resetAllowedInternetDestinations(): void;
    get allowedInternetDestinationsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedInternetDestinations[] | undefined;
    private _allowedStorageDestinations;
    get allowedStorageDestinations(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinationsList;
    putAllowedStorageDestinations(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | cdktn.IResolvable): void;
    resetAllowedStorageDestinations(): void;
    get allowedStorageDestinationsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyEgressNetworkAccessAllowedStorageDestinations[] | undefined;
    private _blockedInternetDestinations;
    get blockedInternetDestinations(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinationsList;
    putBlockedInternetDestinations(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | cdktn.IResolvable): void;
    resetBlockedInternetDestinations(): void;
    get blockedInternetDestinationsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyEgressNetworkAccessBlockedInternetDestinations[] | undefined;
    private _policyEnforcement;
    get policyEnforcement(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcementOutputReference;
    putPolicyEnforcement(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement): void;
    resetPolicyEnforcement(): void;
    get policyEnforcementInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyEgressNetworkAccessPolicyEnforcement | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyEgress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#network_access DataDatabricksAccountNetworkPolicy#network_access}
    */
    readonly networkAccess?: DataDatabricksAccountNetworkPolicyEgressNetworkAccess;
}
export declare function dataDatabricksAccountNetworkPolicyEgressToTerraform(struct?: DataDatabricksAccountNetworkPolicyEgress): any;
export declare function dataDatabricksAccountNetworkPolicyEgressToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyEgress): any;
export declare class DataDatabricksAccountNetworkPolicyEgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyEgress | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyEgress | undefined);
    private _networkAccess;
    get networkAccess(): DataDatabricksAccountNetworkPolicyEgressNetworkAccessOutputReference;
    putNetworkAccess(value: DataDatabricksAccountNetworkPolicyEgressNetworkAccess): void;
    resetNetworkAccess(): void;
    get networkAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyEgressNetworkAccess | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ids DataDatabricksAccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_source_workspaces DataDatabricksAccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#selected_workspaces DataDatabricksAccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ids DataDatabricksAccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_source_workspaces DataDatabricksAccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#selected_workspaces DataDatabricksAccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allow_rules DataDatabricksAccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#deny_rules DataDatabricksAccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#restriction_mode DataDatabricksAccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoint_ids DataDatabricksAccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_private_access DataDatabricksAccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_registered_endpoints DataDatabricksAccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#azure_workspace_private_link DataDatabricksAccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoints DataDatabricksAccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoint_ids DataDatabricksAccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_private_access DataDatabricksAccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_registered_endpoints DataDatabricksAccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#azure_workspace_private_link DataDatabricksAccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoints DataDatabricksAccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPrivateAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allow_rules DataDatabricksAccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#deny_rules DataDatabricksAccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#restriction_mode DataDatabricksAccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPrivateAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPrivateAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_ip_ranges DataDatabricksAccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#excluded_ip_ranges DataDatabricksAccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#included_ip_ranges DataDatabricksAccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_ip_ranges DataDatabricksAccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#excluded_ip_ranges DataDatabricksAccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#included_ip_ranges DataDatabricksAccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allow_rules DataDatabricksAccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#deny_rules DataDatabricksAccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#restriction_mode DataDatabricksAccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressPublicAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#cross_workspace_access DataDatabricksAccountNetworkPolicy#cross_workspace_access}
    */
    readonly crossWorkspaceAccess?: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#private_access DataDatabricksAccountNetworkPolicy#private_access}
    */
    readonly privateAccess?: DataDatabricksAccountNetworkPolicyIngressPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#public_access DataDatabricksAccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: DataDatabricksAccountNetworkPolicyIngressPublicAccess;
}
export declare function dataDatabricksAccountNetworkPolicyIngressToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngress): any;
export declare function dataDatabricksAccountNetworkPolicyIngressToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngress): any;
export declare class DataDatabricksAccountNetworkPolicyIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngress | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngress | undefined);
    private _crossWorkspaceAccess;
    get crossWorkspaceAccess(): DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccessOutputReference;
    putCrossWorkspaceAccess(value: DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess): void;
    resetCrossWorkspaceAccess(): void;
    get crossWorkspaceAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressCrossWorkspaceAccess | undefined;
    private _privateAccess;
    get privateAccess(): DataDatabricksAccountNetworkPolicyIngressPrivateAccessOutputReference;
    putPrivateAccess(value: DataDatabricksAccountNetworkPolicyIngressPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): DataDatabricksAccountNetworkPolicyIngressPublicAccessOutputReference;
    putPublicAccess(value: DataDatabricksAccountNetworkPolicyIngressPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressPublicAccess | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ids DataDatabricksAccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_source_workspaces DataDatabricksAccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#selected_workspaces DataDatabricksAccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginSelectedWorkspaces | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ids DataDatabricksAccountNetworkPolicy#workspace_ids}
    */
    readonly workspaceIds?: number[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | cdktn.IResolvable | undefined);
    private _workspaceIds?;
    get workspaceIds(): number[];
    set workspaceIds(value: number[]);
    resetWorkspaceIds(): void;
    get workspaceIdsInput(): number[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_source_workspaces DataDatabricksAccountNetworkPolicy#all_source_workspaces}
    */
    readonly allSourceWorkspaces?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#selected_workspaces DataDatabricksAccountNetworkPolicy#selected_workspaces}
    */
    readonly selectedWorkspaces?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allSourceWorkspaces?;
    get allSourceWorkspaces(): boolean | cdktn.IResolvable;
    set allSourceWorkspaces(value: boolean | cdktn.IResolvable);
    resetAllSourceWorkspaces(): void;
    get allSourceWorkspacesInput(): boolean | cdktn.IResolvable | undefined;
    private _selectedWorkspaces;
    get selectedWorkspaces(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspacesOutputReference;
    putSelectedWorkspaces(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces): void;
    resetSelectedWorkspaces(): void;
    get selectedWorkspacesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginSelectedWorkspaces | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allow_rules DataDatabricksAccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#deny_rules DataDatabricksAccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#restriction_mode DataDatabricksAccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoint_ids DataDatabricksAccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_private_access DataDatabricksAccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_registered_endpoints DataDatabricksAccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#azure_workspace_private_link DataDatabricksAccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoints DataDatabricksAccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoint_ids DataDatabricksAccountNetworkPolicy#endpoint_ids}
    */
    readonly endpointIds?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | cdktn.IResolvable | undefined);
    private _endpointIds?;
    get endpointIds(): string[];
    set endpointIds(value: string[]);
    resetEndpointIds(): void;
    get endpointIdsInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_private_access DataDatabricksAccountNetworkPolicy#all_private_access}
    */
    readonly allPrivateAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_registered_endpoints DataDatabricksAccountNetworkPolicy#all_registered_endpoints}
    */
    readonly allRegisteredEndpoints?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#azure_workspace_private_link DataDatabricksAccountNetworkPolicy#azure_workspace_private_link}
    */
    readonly azureWorkspacePrivateLink?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#endpoints DataDatabricksAccountNetworkPolicy#endpoints}
    */
    readonly endpoints?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allPrivateAccess?;
    get allPrivateAccess(): boolean | cdktn.IResolvable;
    set allPrivateAccess(value: boolean | cdktn.IResolvable);
    resetAllPrivateAccess(): void;
    get allPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _allRegisteredEndpoints?;
    get allRegisteredEndpoints(): boolean | cdktn.IResolvable;
    set allRegisteredEndpoints(value: boolean | cdktn.IResolvable);
    resetAllRegisteredEndpoints(): void;
    get allRegisteredEndpointsInput(): boolean | cdktn.IResolvable | undefined;
    private _azureWorkspacePrivateLink?;
    get azureWorkspacePrivateLink(): boolean | cdktn.IResolvable;
    set azureWorkspacePrivateLink(value: boolean | cdktn.IResolvable);
    resetAzureWorkspacePrivateLink(): void;
    get azureWorkspacePrivateLinkInput(): boolean | cdktn.IResolvable | undefined;
    private _endpoints;
    get endpoints(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpointsOutputReference;
    putEndpoints(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints): void;
    resetEndpoints(): void;
    get endpointsInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginEndpoints | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#allow_rules DataDatabricksAccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#deny_rules DataDatabricksAccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#restriction_mode DataDatabricksAccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_ip_ranges DataDatabricksAccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#excluded_ip_ranges DataDatabricksAccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#included_ip_ranges DataDatabricksAccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginIncludedIpRanges | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_id DataDatabricksAccountNetworkPolicy#principal_id}
    */
    readonly principalId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#principal_type DataDatabricksAccountNetworkPolicy#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities | cdktn.IResolvable | undefined);
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identities DataDatabricksAccountNetworkPolicy#identities}
    */
    readonly identities?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#identity_type DataDatabricksAccountNetworkPolicy#identity_type}
    */
    readonly identityType?: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | cdktn.IResolvable | undefined);
    private _identities;
    get identities(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentitiesList;
    putIdentities(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | cdktn.IResolvable): void;
    resetIdentities(): void;
    get identitiesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationIdentities[] | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scope_qualifier DataDatabricksAccountNetworkPolicy#scope_qualifier}
    */
    readonly scopeQualifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#scopes DataDatabricksAccountNetworkPolicy#scopes}
    */
    readonly scopes?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | cdktn.IResolvable | undefined);
    private _scopeQualifier?;
    get scopeQualifier(): string;
    set scopeQualifier(value: string);
    resetScopeQualifier(): void;
    get scopeQualifierInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | cdktn.IResolvable | undefined);
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_api DataDatabricksAccountNetworkPolicy#account_api}
    */
    readonly accountApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_databricks_one DataDatabricksAccountNetworkPolicy#account_databricks_one}
    */
    readonly accountDatabricksOne?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#account_ui DataDatabricksAccountNetworkPolicy#account_ui}
    */
    readonly accountUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_destinations DataDatabricksAccountNetworkPolicy#all_destinations}
    */
    readonly allDestinations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#apps_runtime DataDatabricksAccountNetworkPolicy#apps_runtime}
    */
    readonly appsRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#lakebase_runtime DataDatabricksAccountNetworkPolicy#lakebase_runtime}
    */
    readonly lakebaseRuntime?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_api DataDatabricksAccountNetworkPolicy#workspace_api}
    */
    readonly workspaceApi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#workspace_ui DataDatabricksAccountNetworkPolicy#workspace_ui}
    */
    readonly workspaceUi?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | cdktn.IResolvable | undefined);
    private _accountApi;
    get accountApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApiOutputReference;
    putAccountApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi): void;
    resetAccountApi(): void;
    get accountApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountApi | undefined;
    private _accountDatabricksOne;
    get accountDatabricksOne(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOneOutputReference;
    putAccountDatabricksOne(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne): void;
    resetAccountDatabricksOne(): void;
    get accountDatabricksOneInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountDatabricksOne | undefined;
    private _accountUi;
    get accountUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUiOutputReference;
    putAccountUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi): void;
    resetAccountUi(): void;
    get accountUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAccountUi | undefined;
    private _allDestinations?;
    get allDestinations(): boolean | cdktn.IResolvable;
    set allDestinations(value: boolean | cdktn.IResolvable);
    resetAllDestinations(): void;
    get allDestinationsInput(): boolean | cdktn.IResolvable | undefined;
    private _appsRuntime;
    get appsRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntimeOutputReference;
    putAppsRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime): void;
    resetAppsRuntime(): void;
    get appsRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationAppsRuntime | undefined;
    private _lakebaseRuntime;
    get lakebaseRuntime(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntimeOutputReference;
    putLakebaseRuntime(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime): void;
    resetLakebaseRuntime(): void;
    get lakebaseRuntimeInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationLakebaseRuntime | undefined;
    private _workspaceApi;
    get workspaceApi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApiOutputReference;
    putWorkspaceApi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi): void;
    resetWorkspaceApi(): void;
    get workspaceApiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceApi | undefined;
    private _workspaceUi;
    get workspaceUi(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUiOutputReference;
    putWorkspaceUi(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi): void;
    resetWorkspaceUi(): void;
    get workspaceUiInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationWorkspaceUi | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#ip_ranges DataDatabricksAccountNetworkPolicy#ip_ranges}
    */
    readonly ipRanges?: string[];
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | cdktn.IResolvable | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    resetIpRanges(): void;
    get ipRangesInput(): string[] | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#all_ip_ranges DataDatabricksAccountNetworkPolicy#all_ip_ranges}
    */
    readonly allIpRanges?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#excluded_ip_ranges DataDatabricksAccountNetworkPolicy#excluded_ip_ranges}
    */
    readonly excludedIpRanges?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/account_network_policy#included_ip_ranges DataDatabricksAccountNetworkPolicy#included_ip_ranges}
    */
    readonly includedIpRanges?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | cdktn.IResolvable | undefined);
    private _allIpRanges?;
    get allIpRanges(): boolean | cdktn.IResolvable;
    set allIpRanges(value: boolean | cdktn.IResolvable);
    resetAllIpRanges(): void;
    get allIpRangesInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedIpRanges;
    get excludedIpRanges(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRangesOutputReference;
    putExcludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges): void;
    resetExcludedIpRanges(): void;
    get excludedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginExcludedIpRanges | undefined;
    private _includedIpRanges;
    get includedIpRanges(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRangesOutputReference;
    putIncludedIpRanges(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges): void;
    resetIncludedIpRanges(): void;
    get includedIpRangesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginIncludedIpRanges | undefined;
}
