/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksOnlineStoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores#page_size DataDatabricksOnlineStores#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores#provider_config DataDatabricksOnlineStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksOnlineStoresProviderConfig;
}
export interface DataDatabricksOnlineStoresOnlineStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores#workspace_id DataDatabricksOnlineStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksOnlineStoresOnlineStoresProviderConfigToTerraform(struct?: DataDatabricksOnlineStoresOnlineStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksOnlineStoresOnlineStoresProviderConfigToHclTerraform(struct?: DataDatabricksOnlineStoresOnlineStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksOnlineStoresOnlineStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksOnlineStoresOnlineStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksOnlineStoresOnlineStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksOnlineStoresOnlineStores {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores#name DataDatabricksOnlineStores#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores#provider_config DataDatabricksOnlineStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksOnlineStoresOnlineStoresProviderConfig;
}
export declare function dataDatabricksOnlineStoresOnlineStoresToTerraform(struct?: DataDatabricksOnlineStoresOnlineStores): any;
export declare function dataDatabricksOnlineStoresOnlineStoresToHclTerraform(struct?: DataDatabricksOnlineStoresOnlineStores): any;
export declare class DataDatabricksOnlineStoresOnlineStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksOnlineStoresOnlineStores | undefined;
    set internalValue(value: DataDatabricksOnlineStoresOnlineStores | undefined);
    get capacity(): string;
    get creationTime(): string;
    get creator(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksOnlineStoresOnlineStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksOnlineStoresOnlineStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksOnlineStoresOnlineStoresProviderConfig | undefined;
    get readReplicaCount(): number;
    get state(): string;
    get usagePolicyId(): string;
}
export declare class DataDatabricksOnlineStoresOnlineStoresList extends cdktn.ComplexList {
    internalValue?: DataDatabricksOnlineStoresOnlineStores[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksOnlineStoresOnlineStoresOutputReference;
}
export interface DataDatabricksOnlineStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores#workspace_id DataDatabricksOnlineStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksOnlineStoresProviderConfigToTerraform(struct?: DataDatabricksOnlineStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksOnlineStoresProviderConfigToHclTerraform(struct?: DataDatabricksOnlineStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksOnlineStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksOnlineStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksOnlineStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores databricks_online_stores}
*/
export declare class DataDatabricksOnlineStores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_online_stores";
    /**
    * Generates CDKTN code for importing a DataDatabricksOnlineStores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksOnlineStores to import
    * @param importFromId The id of the existing DataDatabricksOnlineStores that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksOnlineStores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/online_stores databricks_online_stores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksOnlineStoresConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksOnlineStoresConfig);
    private _onlineStores;
    get onlineStores(): DataDatabricksOnlineStoresOnlineStoresList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksOnlineStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksOnlineStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksOnlineStoresProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
