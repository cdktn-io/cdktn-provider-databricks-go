/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksServicePrincipalConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#acl_principal_id DataDatabricksServicePrincipal#acl_principal_id}
    */
    readonly aclPrincipalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#active DataDatabricksServicePrincipal#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#api DataDatabricksServicePrincipal#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#application_id DataDatabricksServicePrincipal#application_id}
    */
    readonly applicationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#display_name DataDatabricksServicePrincipal#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#external_id DataDatabricksServicePrincipal#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#home DataDatabricksServicePrincipal#home}
    */
    readonly home?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#id DataDatabricksServicePrincipal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#repos DataDatabricksServicePrincipal#repos}
    */
    readonly repos?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#scim_id DataDatabricksServicePrincipal#scim_id}
    */
    readonly scimId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#sp_id DataDatabricksServicePrincipal#sp_id}
    */
    readonly spId?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#provider_config DataDatabricksServicePrincipal#provider_config}
    */
    readonly providerConfig?: DataDatabricksServicePrincipalProviderConfig;
}
export interface DataDatabricksServicePrincipalProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#workspace_id DataDatabricksServicePrincipal#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksServicePrincipalProviderConfigToTerraform(struct?: DataDatabricksServicePrincipalProviderConfigOutputReference | DataDatabricksServicePrincipalProviderConfig): any;
export declare function dataDatabricksServicePrincipalProviderConfigToHclTerraform(struct?: DataDatabricksServicePrincipalProviderConfigOutputReference | DataDatabricksServicePrincipalProviderConfig): any;
export declare class DataDatabricksServicePrincipalProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksServicePrincipalProviderConfig | undefined;
    set internalValue(value: DataDatabricksServicePrincipalProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal databricks_service_principal}
*/
export declare class DataDatabricksServicePrincipal extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_service_principal";
    /**
    * Generates CDKTN code for importing a DataDatabricksServicePrincipal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksServicePrincipal to import
    * @param importFromId The id of the existing DataDatabricksServicePrincipal that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksServicePrincipal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.127.0/docs/data-sources/service_principal databricks_service_principal} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksServicePrincipalConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksServicePrincipalConfig);
    private _aclPrincipalId?;
    get aclPrincipalId(): string;
    set aclPrincipalId(value: string);
    resetAclPrincipalId(): void;
    get aclPrincipalIdInput(): string | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    resetApplicationId(): void;
    get applicationIdInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _home?;
    get home(): string;
    set home(value: string);
    resetHome(): void;
    get homeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _repos?;
    get repos(): string;
    set repos(value: string);
    resetRepos(): void;
    get reposInput(): string | undefined;
    private _scimId?;
    get scimId(): string;
    set scimId(value: string);
    resetScimId(): void;
    get scimIdInput(): string | undefined;
    private _spId?;
    get spId(): string;
    set spId(value: string);
    resetSpId(): void;
    get spIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksServicePrincipalProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksServicePrincipalProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksServicePrincipalProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
