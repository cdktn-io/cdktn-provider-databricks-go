/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DisableLegacyDbfsSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#etag DisableLegacyDbfsSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#id DisableLegacyDbfsSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#setting_name DisableLegacyDbfsSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * disable_legacy_dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#disable_legacy_dbfs DisableLegacyDbfsSetting#disable_legacy_dbfs}
    */
    readonly disableLegacyDbfs: DisableLegacyDbfsSettingDisableLegacyDbfs;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#provider_config DisableLegacyDbfsSetting#provider_config}
    */
    readonly providerConfig?: DisableLegacyDbfsSettingProviderConfig;
}
export interface DisableLegacyDbfsSettingDisableLegacyDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#value DisableLegacyDbfsSetting#value}
    */
    readonly value: boolean | cdktn.IResolvable;
}
export declare function disableLegacyDbfsSettingDisableLegacyDbfsToTerraform(struct?: DisableLegacyDbfsSettingDisableLegacyDbfsOutputReference | DisableLegacyDbfsSettingDisableLegacyDbfs): any;
export declare function disableLegacyDbfsSettingDisableLegacyDbfsToHclTerraform(struct?: DisableLegacyDbfsSettingDisableLegacyDbfsOutputReference | DisableLegacyDbfsSettingDisableLegacyDbfs): any;
export declare class DisableLegacyDbfsSettingDisableLegacyDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisableLegacyDbfsSettingDisableLegacyDbfs | undefined;
    set internalValue(value: DisableLegacyDbfsSettingDisableLegacyDbfs | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DisableLegacyDbfsSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#workspace_id DisableLegacyDbfsSetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function disableLegacyDbfsSettingProviderConfigToTerraform(struct?: DisableLegacyDbfsSettingProviderConfigOutputReference | DisableLegacyDbfsSettingProviderConfig): any;
export declare function disableLegacyDbfsSettingProviderConfigToHclTerraform(struct?: DisableLegacyDbfsSettingProviderConfigOutputReference | DisableLegacyDbfsSettingProviderConfig): any;
export declare class DisableLegacyDbfsSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisableLegacyDbfsSettingProviderConfig | undefined;
    set internalValue(value: DisableLegacyDbfsSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting databricks_disable_legacy_dbfs_setting}
*/
export declare class DisableLegacyDbfsSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_disable_legacy_dbfs_setting";
    /**
    * Generates CDKTN code for importing a DisableLegacyDbfsSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisableLegacyDbfsSetting to import
    * @param importFromId The id of the existing DisableLegacyDbfsSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisableLegacyDbfsSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disable_legacy_dbfs_setting databricks_disable_legacy_dbfs_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisableLegacyDbfsSettingConfig
    */
    constructor(scope: Construct, id: string, config: DisableLegacyDbfsSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _disableLegacyDbfs;
    get disableLegacyDbfs(): DisableLegacyDbfsSettingDisableLegacyDbfsOutputReference;
    putDisableLegacyDbfs(value: DisableLegacyDbfsSettingDisableLegacyDbfs): void;
    get disableLegacyDbfsInput(): DisableLegacyDbfsSettingDisableLegacyDbfs | undefined;
    private _providerConfig;
    get providerConfig(): DisableLegacyDbfsSettingProviderConfigOutputReference;
    putProviderConfig(value: DisableLegacyDbfsSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DisableLegacyDbfsSettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
