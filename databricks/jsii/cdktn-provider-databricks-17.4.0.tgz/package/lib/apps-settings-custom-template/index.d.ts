/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppsSettingsCustomTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#description AppsSettingsCustomTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#git_provider AppsSettingsCustomTemplate#git_provider}
    */
    readonly gitProvider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#git_repo AppsSettingsCustomTemplate#git_repo}
    */
    readonly gitRepo: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#manifest AppsSettingsCustomTemplate#manifest}
    */
    readonly manifest: AppsSettingsCustomTemplateManifest;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#name AppsSettingsCustomTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#path AppsSettingsCustomTemplate#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#provider_config AppsSettingsCustomTemplate#provider_config}
    */
    readonly providerConfig?: AppsSettingsCustomTemplateProviderConfig;
}
export interface AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#permission AppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function appsSettingsCustomTemplateManifestResourceSpecsExperimentSpecToTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestResourceSpecsExperimentSpecToHclTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSettingsCustomTemplateManifestResourceSpecsJobSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#permission AppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function appsSettingsCustomTemplateManifestResourceSpecsJobSpecToTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestResourceSpecsJobSpecToHclTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestResourceSpecsJobSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifestResourceSpecsJobSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#permission AppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function appsSettingsCustomTemplateManifestResourceSpecsSecretSpecToTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestResourceSpecsSecretSpecToHclTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestResourceSpecsSecretSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#permission AppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function appsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecToTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecToHclTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#permission AppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
}
export declare function appsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecToTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecToHclTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#permission AppsSettingsCustomTemplate#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#securable_type AppsSettingsCustomTemplate#securable_type}
    */
    readonly securableType: string;
}
export declare function appsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecToTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecToHclTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface AppsSettingsCustomTemplateManifestResourceSpecs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#description AppsSettingsCustomTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#experiment_spec AppsSettingsCustomTemplate#experiment_spec}
    */
    readonly experimentSpec?: AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#job_spec AppsSettingsCustomTemplate#job_spec}
    */
    readonly jobSpec?: AppsSettingsCustomTemplateManifestResourceSpecsJobSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#name AppsSettingsCustomTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#secret_spec AppsSettingsCustomTemplate#secret_spec}
    */
    readonly secretSpec?: AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#serving_endpoint_spec AppsSettingsCustomTemplate#serving_endpoint_spec}
    */
    readonly servingEndpointSpec?: AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#sql_warehouse_spec AppsSettingsCustomTemplate#sql_warehouse_spec}
    */
    readonly sqlWarehouseSpec?: AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#uc_securable_spec AppsSettingsCustomTemplate#uc_securable_spec}
    */
    readonly ucSecurableSpec?: AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec;
}
export declare function appsSettingsCustomTemplateManifestResourceSpecsToTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestResourceSpecsToHclTerraform(struct?: AppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestResourceSpecsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifestResourceSpecs | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experimentSpec;
    get experimentSpec(): AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpecOutputReference;
    putExperimentSpec(value: AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec): void;
    resetExperimentSpec(): void;
    get experimentSpecInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifestResourceSpecsExperimentSpec | undefined;
    private _jobSpec;
    get jobSpec(): AppsSettingsCustomTemplateManifestResourceSpecsJobSpecOutputReference;
    putJobSpec(value: AppsSettingsCustomTemplateManifestResourceSpecsJobSpec): void;
    resetJobSpec(): void;
    get jobSpecInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifestResourceSpecsJobSpec | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secretSpec;
    get secretSpec(): AppsSettingsCustomTemplateManifestResourceSpecsSecretSpecOutputReference;
    putSecretSpec(value: AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec): void;
    resetSecretSpec(): void;
    get secretSpecInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifestResourceSpecsSecretSpec | undefined;
    private _servingEndpointSpec;
    get servingEndpointSpec(): AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpecOutputReference;
    putServingEndpointSpec(value: AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec): void;
    resetServingEndpointSpec(): void;
    get servingEndpointSpecInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifestResourceSpecsServingEndpointSpec | undefined;
    private _sqlWarehouseSpec;
    get sqlWarehouseSpec(): AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpecOutputReference;
    putSqlWarehouseSpec(value: AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec): void;
    resetSqlWarehouseSpec(): void;
    get sqlWarehouseSpecInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifestResourceSpecsSqlWarehouseSpec | undefined;
    private _ucSecurableSpec;
    get ucSecurableSpec(): AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpecOutputReference;
    putUcSecurableSpec(value: AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec): void;
    resetUcSecurableSpec(): void;
    get ucSecurableSpecInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifestResourceSpecsUcSecurableSpec | undefined;
}
export declare class AppsSettingsCustomTemplateManifestResourceSpecsList extends cdktn.ComplexList {
    internalValue?: AppsSettingsCustomTemplateManifestResourceSpecs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppsSettingsCustomTemplateManifestResourceSpecsOutputReference;
}
export interface AppsSettingsCustomTemplateManifest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#description AppsSettingsCustomTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#name AppsSettingsCustomTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#resource_specs AppsSettingsCustomTemplate#resource_specs}
    */
    readonly resourceSpecs?: AppsSettingsCustomTemplateManifestResourceSpecs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#version AppsSettingsCustomTemplate#version}
    */
    readonly version: number;
}
export declare function appsSettingsCustomTemplateManifestToTerraform(struct?: AppsSettingsCustomTemplateManifest | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateManifestToHclTerraform(struct?: AppsSettingsCustomTemplateManifest | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateManifestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateManifest | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateManifest | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceSpecs;
    get resourceSpecs(): AppsSettingsCustomTemplateManifestResourceSpecsList;
    putResourceSpecs(value: AppsSettingsCustomTemplateManifestResourceSpecs[] | cdktn.IResolvable): void;
    resetResourceSpecs(): void;
    get resourceSpecsInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifestResourceSpecs[] | undefined;
    private _version?;
    get version(): number;
    set version(value: number);
    get versionInput(): number | undefined;
}
export interface AppsSettingsCustomTemplateProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#workspace_id AppsSettingsCustomTemplate#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function appsSettingsCustomTemplateProviderConfigToTerraform(struct?: AppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable): any;
export declare function appsSettingsCustomTemplateProviderConfigToHclTerraform(struct?: AppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable): any;
export declare class AppsSettingsCustomTemplateProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppsSettingsCustomTemplateProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template databricks_apps_settings_custom_template}
*/
export declare class AppsSettingsCustomTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_apps_settings_custom_template";
    /**
    * Generates CDKTN code for importing a AppsSettingsCustomTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppsSettingsCustomTemplate to import
    * @param importFromId The id of the existing AppsSettingsCustomTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppsSettingsCustomTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/apps_settings_custom_template databricks_apps_settings_custom_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppsSettingsCustomTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AppsSettingsCustomTemplateConfig);
    get creator(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _gitProvider?;
    get gitProvider(): string;
    set gitProvider(value: string);
    get gitProviderInput(): string | undefined;
    private _gitRepo?;
    get gitRepo(): string;
    set gitRepo(value: string);
    get gitRepoInput(): string | undefined;
    private _manifest;
    get manifest(): AppsSettingsCustomTemplateManifestOutputReference;
    putManifest(value: AppsSettingsCustomTemplateManifest): void;
    get manifestInput(): cdktn.IResolvable | AppsSettingsCustomTemplateManifest | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AppsSettingsCustomTemplateProviderConfigOutputReference;
    putProviderConfig(value: AppsSettingsCustomTemplateProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AppsSettingsCustomTemplateProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
