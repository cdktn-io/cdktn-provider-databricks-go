/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DisasterRecoveryStableUrlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_stable_url#initial_workspace_id DisasterRecoveryStableUrl#initial_workspace_id}
    */
    readonly initialWorkspaceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_stable_url#parent DisasterRecoveryStableUrl#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_stable_url#stable_url_id DisasterRecoveryStableUrl#stable_url_id}
    */
    readonly stableUrlId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_stable_url databricks_disaster_recovery_stable_url}
*/
export declare class DisasterRecoveryStableUrl extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_disaster_recovery_stable_url";
    /**
    * Generates CDKTN code for importing a DisasterRecoveryStableUrl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisasterRecoveryStableUrl to import
    * @param importFromId The id of the existing DisasterRecoveryStableUrl that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_stable_url#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisasterRecoveryStableUrl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_stable_url databricks_disaster_recovery_stable_url} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisasterRecoveryStableUrlConfig
    */
    constructor(scope: Construct, id: string, config: DisasterRecoveryStableUrlConfig);
    get failoverGroupName(): string;
    private _initialWorkspaceId?;
    get initialWorkspaceId(): string;
    set initialWorkspaceId(value: string);
    get initialWorkspaceIdInput(): string | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _stableUrlId?;
    get stableUrlId(): string;
    set stableUrlId(value: string);
    get stableUrlIdInput(): string | undefined;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
