/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DefaultNamespaceSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#etag DefaultNamespaceSetting#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#id DefaultNamespaceSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#setting_name DefaultNamespaceSetting#setting_name}
    */
    readonly settingName?: string;
    /**
    * namespace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#namespace DefaultNamespaceSetting#namespace}
    */
    readonly namespace: DefaultNamespaceSettingNamespace;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#provider_config DefaultNamespaceSetting#provider_config}
    */
    readonly providerConfig?: DefaultNamespaceSettingProviderConfig;
}
export interface DefaultNamespaceSettingNamespace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#value DefaultNamespaceSetting#value}
    */
    readonly value?: string;
}
export declare function defaultNamespaceSettingNamespaceToTerraform(struct?: DefaultNamespaceSettingNamespaceOutputReference | DefaultNamespaceSettingNamespace): any;
export declare function defaultNamespaceSettingNamespaceToHclTerraform(struct?: DefaultNamespaceSettingNamespaceOutputReference | DefaultNamespaceSettingNamespace): any;
export declare class DefaultNamespaceSettingNamespaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DefaultNamespaceSettingNamespace | undefined;
    set internalValue(value: DefaultNamespaceSettingNamespace | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DefaultNamespaceSettingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#workspace_id DefaultNamespaceSetting#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function defaultNamespaceSettingProviderConfigToTerraform(struct?: DefaultNamespaceSettingProviderConfigOutputReference | DefaultNamespaceSettingProviderConfig): any;
export declare function defaultNamespaceSettingProviderConfigToHclTerraform(struct?: DefaultNamespaceSettingProviderConfigOutputReference | DefaultNamespaceSettingProviderConfig): any;
export declare class DefaultNamespaceSettingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DefaultNamespaceSettingProviderConfig | undefined;
    set internalValue(value: DefaultNamespaceSettingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting databricks_default_namespace_setting}
*/
export declare class DefaultNamespaceSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_default_namespace_setting";
    /**
    * Generates CDKTN code for importing a DefaultNamespaceSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DefaultNamespaceSetting to import
    * @param importFromId The id of the existing DefaultNamespaceSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DefaultNamespaceSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/default_namespace_setting databricks_default_namespace_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DefaultNamespaceSettingConfig
    */
    constructor(scope: Construct, id: string, config: DefaultNamespaceSettingConfig);
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _settingName?;
    get settingName(): string;
    set settingName(value: string);
    resetSettingName(): void;
    get settingNameInput(): string | undefined;
    private _namespace;
    get namespace(): DefaultNamespaceSettingNamespaceOutputReference;
    putNamespace(value: DefaultNamespaceSettingNamespace): void;
    get namespaceInput(): DefaultNamespaceSettingNamespace | undefined;
    private _providerConfig;
    get providerConfig(): DefaultNamespaceSettingProviderConfigOutputReference;
    putProviderConfig(value: DefaultNamespaceSettingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DefaultNamespaceSettingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
