/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksOnlineStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/online_store#name DataDatabricksOnlineStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/online_store#provider_config DataDatabricksOnlineStore#provider_config}
    */
    readonly providerConfig?: DataDatabricksOnlineStoreProviderConfig;
}
export interface DataDatabricksOnlineStoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/online_store#workspace_id DataDatabricksOnlineStore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksOnlineStoreProviderConfigToTerraform(struct?: DataDatabricksOnlineStoreProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksOnlineStoreProviderConfigToHclTerraform(struct?: DataDatabricksOnlineStoreProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksOnlineStoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksOnlineStoreProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksOnlineStoreProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/online_store databricks_online_store}
*/
export declare class DataDatabricksOnlineStore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_online_store";
    /**
    * Generates CDKTN code for importing a DataDatabricksOnlineStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksOnlineStore to import
    * @param importFromId The id of the existing DataDatabricksOnlineStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/online_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksOnlineStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/online_store databricks_online_store} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksOnlineStoreConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksOnlineStoreConfig);
    get capacity(): string;
    get creationTime(): string;
    get creator(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksOnlineStoreProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksOnlineStoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksOnlineStoreProviderConfig | undefined;
    get readReplicaCount(): number;
    get state(): string;
    get usagePolicyId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
