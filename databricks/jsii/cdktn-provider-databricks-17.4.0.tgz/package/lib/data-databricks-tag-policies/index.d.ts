/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksTagPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#page_size DataDatabricksTagPolicies#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#provider_config DataDatabricksTagPolicies#provider_config}
    */
    readonly providerConfig?: DataDatabricksTagPoliciesProviderConfig;
}
export interface DataDatabricksTagPoliciesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#workspace_id DataDatabricksTagPolicies#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksTagPoliciesProviderConfigToTerraform(struct?: DataDatabricksTagPoliciesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksTagPoliciesProviderConfigToHclTerraform(struct?: DataDatabricksTagPoliciesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksTagPoliciesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTagPoliciesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTagPoliciesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksTagPoliciesTagPoliciesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#workspace_id DataDatabricksTagPolicies#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksTagPoliciesTagPoliciesProviderConfigToTerraform(struct?: DataDatabricksTagPoliciesTagPoliciesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksTagPoliciesTagPoliciesProviderConfigToHclTerraform(struct?: DataDatabricksTagPoliciesTagPoliciesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksTagPoliciesTagPoliciesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTagPoliciesTagPoliciesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTagPoliciesTagPoliciesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksTagPoliciesTagPoliciesValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#name DataDatabricksTagPolicies#name}
    */
    readonly name: string;
}
export declare function dataDatabricksTagPoliciesTagPoliciesValuesToTerraform(struct?: DataDatabricksTagPoliciesTagPoliciesValues): any;
export declare function dataDatabricksTagPoliciesTagPoliciesValuesToHclTerraform(struct?: DataDatabricksTagPoliciesTagPoliciesValues): any;
export declare class DataDatabricksTagPoliciesTagPoliciesValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTagPoliciesTagPoliciesValues | undefined;
    set internalValue(value: DataDatabricksTagPoliciesTagPoliciesValues | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksTagPoliciesTagPoliciesValuesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTagPoliciesTagPoliciesValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTagPoliciesTagPoliciesValuesOutputReference;
}
export interface DataDatabricksTagPoliciesTagPolicies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#provider_config DataDatabricksTagPolicies#provider_config}
    */
    readonly providerConfig?: DataDatabricksTagPoliciesTagPoliciesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#tag_key DataDatabricksTagPolicies#tag_key}
    */
    readonly tagKey: string;
}
export declare function dataDatabricksTagPoliciesTagPoliciesToTerraform(struct?: DataDatabricksTagPoliciesTagPolicies): any;
export declare function dataDatabricksTagPoliciesTagPoliciesToHclTerraform(struct?: DataDatabricksTagPoliciesTagPolicies): any;
export declare class DataDatabricksTagPoliciesTagPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTagPoliciesTagPolicies | undefined;
    set internalValue(value: DataDatabricksTagPoliciesTagPolicies | undefined);
    get createTime(): string;
    get description(): string;
    get id(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksTagPoliciesTagPoliciesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksTagPoliciesTagPoliciesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksTagPoliciesTagPoliciesProviderConfig | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    get updateTime(): string;
    private _values;
    get values(): DataDatabricksTagPoliciesTagPoliciesValuesList;
}
export declare class DataDatabricksTagPoliciesTagPoliciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTagPoliciesTagPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTagPoliciesTagPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies databricks_tag_policies}
*/
export declare class DataDatabricksTagPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_tag_policies";
    /**
    * Generates CDKTN code for importing a DataDatabricksTagPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksTagPolicies to import
    * @param importFromId The id of the existing DataDatabricksTagPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksTagPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/tag_policies databricks_tag_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksTagPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksTagPoliciesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksTagPoliciesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksTagPoliciesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksTagPoliciesProviderConfig | undefined;
    private _tagPolicies;
    get tagPolicies(): DataDatabricksTagPoliciesTagPoliciesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
