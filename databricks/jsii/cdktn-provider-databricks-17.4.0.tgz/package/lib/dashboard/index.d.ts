/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#create_time Dashboard#create_time}
    */
    readonly createTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#dashboard_change_detected Dashboard#dashboard_change_detected}
    */
    readonly dashboardChangeDetected?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#dashboard_id Dashboard#dashboard_id}
    */
    readonly dashboardId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#dataset_catalog Dashboard#dataset_catalog}
    */
    readonly datasetCatalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#dataset_schema Dashboard#dataset_schema}
    */
    readonly datasetSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#display_name Dashboard#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#embed_credentials Dashboard#embed_credentials}
    */
    readonly embedCredentials?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#etag Dashboard#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#file_path Dashboard#file_path}
    */
    readonly filePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#id Dashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#lifecycle_state Dashboard#lifecycle_state}
    */
    readonly lifecycleState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#md5 Dashboard#md5}
    */
    readonly md5?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#parent_path Dashboard#parent_path}
    */
    readonly parentPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#path Dashboard#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#serialized_dashboard Dashboard#serialized_dashboard}
    */
    readonly serializedDashboard?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#update_time Dashboard#update_time}
    */
    readonly updateTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#warehouse_id Dashboard#warehouse_id}
    */
    readonly warehouseId: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#provider_config Dashboard#provider_config}
    */
    readonly providerConfig?: DashboardProviderConfig;
}
export interface DashboardProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#workspace_id Dashboard#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dashboardProviderConfigToTerraform(struct?: DashboardProviderConfigOutputReference | DashboardProviderConfig): any;
export declare function dashboardProviderConfigToHclTerraform(struct?: DashboardProviderConfigOutputReference | DashboardProviderConfig): any;
export declare class DashboardProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DashboardProviderConfig | undefined;
    set internalValue(value: DashboardProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard databricks_dashboard}
*/
export declare class Dashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_dashboard";
    /**
    * Generates CDKTN code for importing a Dashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Dashboard to import
    * @param importFromId The id of the existing Dashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Dashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/dashboard databricks_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DashboardConfig
    */
    constructor(scope: Construct, id: string, config: DashboardConfig);
    private _createTime?;
    get createTime(): string;
    set createTime(value: string);
    resetCreateTime(): void;
    get createTimeInput(): string | undefined;
    private _dashboardChangeDetected?;
    get dashboardChangeDetected(): boolean | cdktn.IResolvable;
    set dashboardChangeDetected(value: boolean | cdktn.IResolvable);
    resetDashboardChangeDetected(): void;
    get dashboardChangeDetectedInput(): boolean | cdktn.IResolvable | undefined;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    resetDashboardId(): void;
    get dashboardIdInput(): string | undefined;
    private _datasetCatalog?;
    get datasetCatalog(): string;
    set datasetCatalog(value: string);
    resetDatasetCatalog(): void;
    get datasetCatalogInput(): string | undefined;
    private _datasetSchema?;
    get datasetSchema(): string;
    set datasetSchema(value: string);
    resetDatasetSchema(): void;
    get datasetSchemaInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _embedCredentials?;
    get embedCredentials(): boolean | cdktn.IResolvable;
    set embedCredentials(value: boolean | cdktn.IResolvable);
    resetEmbedCredentials(): void;
    get embedCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _filePath?;
    get filePath(): string;
    set filePath(value: string);
    resetFilePath(): void;
    get filePathInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lifecycleState?;
    get lifecycleState(): string;
    set lifecycleState(value: string);
    resetLifecycleState(): void;
    get lifecycleStateInput(): string | undefined;
    private _md5?;
    get md5(): string;
    set md5(value: string);
    resetMd5(): void;
    get md5Input(): string | undefined;
    private _parentPath?;
    get parentPath(): string;
    set parentPath(value: string);
    get parentPathInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _serializedDashboard?;
    get serializedDashboard(): string;
    set serializedDashboard(value: string);
    resetSerializedDashboard(): void;
    get serializedDashboardInput(): string | undefined;
    private _updateTime?;
    get updateTime(): string;
    set updateTime(value: string);
    resetUpdateTime(): void;
    get updateTimeInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DashboardProviderConfigOutputReference;
    putProviderConfig(value: DashboardProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DashboardProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
