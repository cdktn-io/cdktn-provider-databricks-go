/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#id DataDatabricksTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#name DataDatabricksTable#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#provider_config DataDatabricksTable#provider_config}
    */
    readonly providerConfig?: DataDatabricksTableProviderConfig;
    /**
    * table_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#table_info DataDatabricksTable#table_info}
    */
    readonly tableInfo?: DataDatabricksTableTableInfo;
}
export interface DataDatabricksTableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#workspace_id DataDatabricksTable#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksTableProviderConfigToTerraform(struct?: DataDatabricksTableProviderConfigOutputReference | DataDatabricksTableProviderConfig): any;
export declare function dataDatabricksTableProviderConfigToHclTerraform(struct?: DataDatabricksTableProviderConfigOutputReference | DataDatabricksTableProviderConfig): any;
export declare class DataDatabricksTableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableProviderConfig | undefined;
    set internalValue(value: DataDatabricksTableProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoColumnsMaskUsingArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#column DataDatabricksTable#column}
    */
    readonly column?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#constant DataDatabricksTable#constant}
    */
    readonly constant?: string;
}
export declare function dataDatabricksTableTableInfoColumnsMaskUsingArgumentsToTerraform(struct?: DataDatabricksTableTableInfoColumnsMaskUsingArguments | cdktn.IResolvable): any;
export declare function dataDatabricksTableTableInfoColumnsMaskUsingArgumentsToHclTerraform(struct?: DataDatabricksTableTableInfoColumnsMaskUsingArguments | cdktn.IResolvable): any;
export declare class DataDatabricksTableTableInfoColumnsMaskUsingArgumentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTableTableInfoColumnsMaskUsingArguments | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTableTableInfoColumnsMaskUsingArguments | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    resetColumn(): void;
    get columnInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
}
export declare class DataDatabricksTableTableInfoColumnsMaskUsingArgumentsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTableTableInfoColumnsMaskUsingArguments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTableTableInfoColumnsMaskUsingArgumentsOutputReference;
}
export interface DataDatabricksTableTableInfoColumnsMask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#function_name DataDatabricksTable#function_name}
    */
    readonly functionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#using_column_names DataDatabricksTable#using_column_names}
    */
    readonly usingColumnNames?: string[];
    /**
    * using_arguments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#using_arguments DataDatabricksTable#using_arguments}
    */
    readonly usingArguments?: DataDatabricksTableTableInfoColumnsMaskUsingArguments[] | cdktn.IResolvable;
}
export declare function dataDatabricksTableTableInfoColumnsMaskToTerraform(struct?: DataDatabricksTableTableInfoColumnsMaskOutputReference | DataDatabricksTableTableInfoColumnsMask): any;
export declare function dataDatabricksTableTableInfoColumnsMaskToHclTerraform(struct?: DataDatabricksTableTableInfoColumnsMaskOutputReference | DataDatabricksTableTableInfoColumnsMask): any;
export declare class DataDatabricksTableTableInfoColumnsMaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoColumnsMask | undefined;
    set internalValue(value: DataDatabricksTableTableInfoColumnsMask | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    resetFunctionName(): void;
    get functionNameInput(): string | undefined;
    private _usingColumnNames?;
    get usingColumnNames(): string[];
    set usingColumnNames(value: string[]);
    resetUsingColumnNames(): void;
    get usingColumnNamesInput(): string[] | undefined;
    private _usingArguments;
    get usingArguments(): DataDatabricksTableTableInfoColumnsMaskUsingArgumentsList;
    putUsingArguments(value: DataDatabricksTableTableInfoColumnsMaskUsingArguments[] | cdktn.IResolvable): void;
    resetUsingArguments(): void;
    get usingArgumentsInput(): cdktn.IResolvable | DataDatabricksTableTableInfoColumnsMaskUsingArguments[] | undefined;
}
export interface DataDatabricksTableTableInfoColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#comment DataDatabricksTable#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#name DataDatabricksTable#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#nullable DataDatabricksTable#nullable}
    */
    readonly nullable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#partition_index DataDatabricksTable#partition_index}
    */
    readonly partitionIndex?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#position DataDatabricksTable#position}
    */
    readonly position?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#type_interval_type DataDatabricksTable#type_interval_type}
    */
    readonly typeIntervalType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#type_json DataDatabricksTable#type_json}
    */
    readonly typeJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#type_name DataDatabricksTable#type_name}
    */
    readonly typeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#type_precision DataDatabricksTable#type_precision}
    */
    readonly typePrecision?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#type_scale DataDatabricksTable#type_scale}
    */
    readonly typeScale?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#type_text DataDatabricksTable#type_text}
    */
    readonly typeText?: string;
    /**
    * mask block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#mask DataDatabricksTable#mask}
    */
    readonly mask?: DataDatabricksTableTableInfoColumnsMask;
}
export declare function dataDatabricksTableTableInfoColumnsToTerraform(struct?: DataDatabricksTableTableInfoColumns | cdktn.IResolvable): any;
export declare function dataDatabricksTableTableInfoColumnsToHclTerraform(struct?: DataDatabricksTableTableInfoColumns | cdktn.IResolvable): any;
export declare class DataDatabricksTableTableInfoColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTableTableInfoColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTableTableInfoColumns | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nullable?;
    get nullable(): boolean | cdktn.IResolvable;
    set nullable(value: boolean | cdktn.IResolvable);
    resetNullable(): void;
    get nullableInput(): boolean | cdktn.IResolvable | undefined;
    private _partitionIndex?;
    get partitionIndex(): number;
    set partitionIndex(value: number);
    resetPartitionIndex(): void;
    get partitionIndexInput(): number | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
    private _typeIntervalType?;
    get typeIntervalType(): string;
    set typeIntervalType(value: string);
    resetTypeIntervalType(): void;
    get typeIntervalTypeInput(): string | undefined;
    private _typeJson?;
    get typeJson(): string;
    set typeJson(value: string);
    resetTypeJson(): void;
    get typeJsonInput(): string | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    resetTypeName(): void;
    get typeNameInput(): string | undefined;
    private _typePrecision?;
    get typePrecision(): number;
    set typePrecision(value: number);
    resetTypePrecision(): void;
    get typePrecisionInput(): number | undefined;
    private _typeScale?;
    get typeScale(): number;
    set typeScale(value: number);
    resetTypeScale(): void;
    get typeScaleInput(): number | undefined;
    private _typeText?;
    get typeText(): string;
    set typeText(value: string);
    resetTypeText(): void;
    get typeTextInput(): string | undefined;
    private _mask;
    get mask(): DataDatabricksTableTableInfoColumnsMaskOutputReference;
    putMask(value: DataDatabricksTableTableInfoColumnsMask): void;
    resetMask(): void;
    get maskInput(): DataDatabricksTableTableInfoColumnsMask | undefined;
}
export declare class DataDatabricksTableTableInfoColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTableTableInfoColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTableTableInfoColumnsOutputReference;
}
export interface DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#delta_runtime_properties DataDatabricksTable#delta_runtime_properties}
    */
    readonly deltaRuntimeProperties: {
        [key: string]: string;
    };
}
export declare function dataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairsToTerraform(struct?: DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairsOutputReference | DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs): any;
export declare function dataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairsToHclTerraform(struct?: DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairsOutputReference | DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs): any;
export declare class DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs | undefined;
    set internalValue(value: DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs | undefined);
    private _deltaRuntimeProperties?;
    get deltaRuntimeProperties(): {
        [key: string]: string;
    };
    set deltaRuntimeProperties(value: {
        [key: string]: string;
    });
    get deltaRuntimePropertiesInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#inherited_from_name DataDatabricksTable#inherited_from_name}
    */
    readonly inheritedFromName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#inherited_from_type DataDatabricksTable#inherited_from_type}
    */
    readonly inheritedFromType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#value DataDatabricksTable#value}
    */
    readonly value: string;
}
export declare function dataDatabricksTableTableInfoEffectivePredictiveOptimizationFlagToTerraform(struct?: DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlagOutputReference | DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag): any;
export declare function dataDatabricksTableTableInfoEffectivePredictiveOptimizationFlagToHclTerraform(struct?: DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlagOutputReference | DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag): any;
export declare class DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag | undefined;
    set internalValue(value: DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag | undefined);
    private _inheritedFromName?;
    get inheritedFromName(): string;
    set inheritedFromName(value: string);
    resetInheritedFromName(): void;
    get inheritedFromNameInput(): string | undefined;
    private _inheritedFromType?;
    get inheritedFromType(): string;
    set inheritedFromType(value: string);
    resetInheritedFromType(): void;
    get inheritedFromTypeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#algorithm DataDatabricksTable#algorithm}
    */
    readonly algorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#aws_kms_key_arn DataDatabricksTable#aws_kms_key_arn}
    */
    readonly awsKmsKeyArn?: string;
}
export declare function dataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetailsToTerraform(struct?: DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetailsOutputReference | DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails): any;
export declare function dataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetailsToHclTerraform(struct?: DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetailsOutputReference | DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails): any;
export declare class DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails | undefined;
    set internalValue(value: DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _awsKmsKeyArn?;
    get awsKmsKeyArn(): string;
    set awsKmsKeyArn(value: string);
    resetAwsKmsKeyArn(): void;
    get awsKmsKeyArnInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoEncryptionDetails {
    /**
    * sse_encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#sse_encryption_details DataDatabricksTable#sse_encryption_details}
    */
    readonly sseEncryptionDetails?: DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails;
}
export declare function dataDatabricksTableTableInfoEncryptionDetailsToTerraform(struct?: DataDatabricksTableTableInfoEncryptionDetailsOutputReference | DataDatabricksTableTableInfoEncryptionDetails): any;
export declare function dataDatabricksTableTableInfoEncryptionDetailsToHclTerraform(struct?: DataDatabricksTableTableInfoEncryptionDetailsOutputReference | DataDatabricksTableTableInfoEncryptionDetails): any;
export declare class DataDatabricksTableTableInfoEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoEncryptionDetails | undefined;
    set internalValue(value: DataDatabricksTableTableInfoEncryptionDetails | undefined);
    private _sseEncryptionDetails;
    get sseEncryptionDetails(): DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetailsOutputReference;
    putSseEncryptionDetails(value: DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails): void;
    resetSseEncryptionDetails(): void;
    get sseEncryptionDetailsInput(): DataDatabricksTableTableInfoEncryptionDetailsSseEncryptionDetails | undefined;
}
export interface DataDatabricksTableTableInfoRowFilterInputArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#column DataDatabricksTable#column}
    */
    readonly column?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#constant DataDatabricksTable#constant}
    */
    readonly constant?: string;
}
export declare function dataDatabricksTableTableInfoRowFilterInputArgumentsToTerraform(struct?: DataDatabricksTableTableInfoRowFilterInputArguments | cdktn.IResolvable): any;
export declare function dataDatabricksTableTableInfoRowFilterInputArgumentsToHclTerraform(struct?: DataDatabricksTableTableInfoRowFilterInputArguments | cdktn.IResolvable): any;
export declare class DataDatabricksTableTableInfoRowFilterInputArgumentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTableTableInfoRowFilterInputArguments | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTableTableInfoRowFilterInputArguments | cdktn.IResolvable | undefined);
    private _column?;
    get column(): string;
    set column(value: string);
    resetColumn(): void;
    get columnInput(): string | undefined;
    private _constant?;
    get constant(): string;
    set constant(value: string);
    resetConstant(): void;
    get constantInput(): string | undefined;
}
export declare class DataDatabricksTableTableInfoRowFilterInputArgumentsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTableTableInfoRowFilterInputArguments[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTableTableInfoRowFilterInputArgumentsOutputReference;
}
export interface DataDatabricksTableTableInfoRowFilter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#function_name DataDatabricksTable#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#input_column_names DataDatabricksTable#input_column_names}
    */
    readonly inputColumnNames: string[];
    /**
    * input_arguments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#input_arguments DataDatabricksTable#input_arguments}
    */
    readonly inputArguments?: DataDatabricksTableTableInfoRowFilterInputArguments[] | cdktn.IResolvable;
}
export declare function dataDatabricksTableTableInfoRowFilterToTerraform(struct?: DataDatabricksTableTableInfoRowFilterOutputReference | DataDatabricksTableTableInfoRowFilter): any;
export declare function dataDatabricksTableTableInfoRowFilterToHclTerraform(struct?: DataDatabricksTableTableInfoRowFilterOutputReference | DataDatabricksTableTableInfoRowFilter): any;
export declare class DataDatabricksTableTableInfoRowFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoRowFilter | undefined;
    set internalValue(value: DataDatabricksTableTableInfoRowFilter | undefined);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _inputColumnNames?;
    get inputColumnNames(): string[];
    set inputColumnNames(value: string[]);
    get inputColumnNamesInput(): string[] | undefined;
    private _inputArguments;
    get inputArguments(): DataDatabricksTableTableInfoRowFilterInputArgumentsList;
    putInputArguments(value: DataDatabricksTableTableInfoRowFilterInputArguments[] | cdktn.IResolvable): void;
    resetInputArguments(): void;
    get inputArgumentsInput(): cdktn.IResolvable | DataDatabricksTableTableInfoRowFilterInputArguments[] | undefined;
}
export interface DataDatabricksTableTableInfoSecurableKindManifestOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#allowed_values DataDatabricksTable#allowed_values}
    */
    readonly allowedValues?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#default_value DataDatabricksTable#default_value}
    */
    readonly defaultValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#description DataDatabricksTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#hint DataDatabricksTable#hint}
    */
    readonly hint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#is_copiable DataDatabricksTable#is_copiable}
    */
    readonly isCopiable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#is_creatable DataDatabricksTable#is_creatable}
    */
    readonly isCreatable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#is_hidden DataDatabricksTable#is_hidden}
    */
    readonly isHidden?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#is_loggable DataDatabricksTable#is_loggable}
    */
    readonly isLoggable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#is_required DataDatabricksTable#is_required}
    */
    readonly isRequired?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#is_secret DataDatabricksTable#is_secret}
    */
    readonly isSecret?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#is_updatable DataDatabricksTable#is_updatable}
    */
    readonly isUpdatable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#name DataDatabricksTable#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#oauth_stage DataDatabricksTable#oauth_stage}
    */
    readonly oauthStage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#type DataDatabricksTable#type}
    */
    readonly type?: string;
}
export declare function dataDatabricksTableTableInfoSecurableKindManifestOptionsToTerraform(struct?: DataDatabricksTableTableInfoSecurableKindManifestOptions | cdktn.IResolvable): any;
export declare function dataDatabricksTableTableInfoSecurableKindManifestOptionsToHclTerraform(struct?: DataDatabricksTableTableInfoSecurableKindManifestOptions | cdktn.IResolvable): any;
export declare class DataDatabricksTableTableInfoSecurableKindManifestOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTableTableInfoSecurableKindManifestOptions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTableTableInfoSecurableKindManifestOptions | cdktn.IResolvable | undefined);
    private _allowedValues?;
    get allowedValues(): string[];
    set allowedValues(value: string[]);
    resetAllowedValues(): void;
    get allowedValuesInput(): string[] | undefined;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _hint?;
    get hint(): string;
    set hint(value: string);
    resetHint(): void;
    get hintInput(): string | undefined;
    private _isCopiable?;
    get isCopiable(): boolean | cdktn.IResolvable;
    set isCopiable(value: boolean | cdktn.IResolvable);
    resetIsCopiable(): void;
    get isCopiableInput(): boolean | cdktn.IResolvable | undefined;
    private _isCreatable?;
    get isCreatable(): boolean | cdktn.IResolvable;
    set isCreatable(value: boolean | cdktn.IResolvable);
    resetIsCreatable(): void;
    get isCreatableInput(): boolean | cdktn.IResolvable | undefined;
    private _isHidden?;
    get isHidden(): boolean | cdktn.IResolvable;
    set isHidden(value: boolean | cdktn.IResolvable);
    resetIsHidden(): void;
    get isHiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _isLoggable?;
    get isLoggable(): boolean | cdktn.IResolvable;
    set isLoggable(value: boolean | cdktn.IResolvable);
    resetIsLoggable(): void;
    get isLoggableInput(): boolean | cdktn.IResolvable | undefined;
    private _isRequired?;
    get isRequired(): boolean | cdktn.IResolvable;
    set isRequired(value: boolean | cdktn.IResolvable);
    resetIsRequired(): void;
    get isRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _isSecret?;
    get isSecret(): boolean | cdktn.IResolvable;
    set isSecret(value: boolean | cdktn.IResolvable);
    resetIsSecret(): void;
    get isSecretInput(): boolean | cdktn.IResolvable | undefined;
    private _isUpdatable?;
    get isUpdatable(): boolean | cdktn.IResolvable;
    set isUpdatable(value: boolean | cdktn.IResolvable);
    resetIsUpdatable(): void;
    get isUpdatableInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _oauthStage?;
    get oauthStage(): string;
    set oauthStage(value: string);
    resetOauthStage(): void;
    get oauthStageInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class DataDatabricksTableTableInfoSecurableKindManifestOptionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTableTableInfoSecurableKindManifestOptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTableTableInfoSecurableKindManifestOptionsOutputReference;
}
export interface DataDatabricksTableTableInfoSecurableKindManifest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#assignable_privileges DataDatabricksTable#assignable_privileges}
    */
    readonly assignablePrivileges?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#capabilities DataDatabricksTable#capabilities}
    */
    readonly capabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#securable_kind DataDatabricksTable#securable_kind}
    */
    readonly securableKind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#securable_type DataDatabricksTable#securable_type}
    */
    readonly securableType?: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#options DataDatabricksTable#options}
    */
    readonly options?: DataDatabricksTableTableInfoSecurableKindManifestOptions[] | cdktn.IResolvable;
}
export declare function dataDatabricksTableTableInfoSecurableKindManifestToTerraform(struct?: DataDatabricksTableTableInfoSecurableKindManifestOutputReference | DataDatabricksTableTableInfoSecurableKindManifest): any;
export declare function dataDatabricksTableTableInfoSecurableKindManifestToHclTerraform(struct?: DataDatabricksTableTableInfoSecurableKindManifestOutputReference | DataDatabricksTableTableInfoSecurableKindManifest): any;
export declare class DataDatabricksTableTableInfoSecurableKindManifestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoSecurableKindManifest | undefined;
    set internalValue(value: DataDatabricksTableTableInfoSecurableKindManifest | undefined);
    private _assignablePrivileges?;
    get assignablePrivileges(): string[];
    set assignablePrivileges(value: string[]);
    resetAssignablePrivileges(): void;
    get assignablePrivilegesInput(): string[] | undefined;
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    resetCapabilities(): void;
    get capabilitiesInput(): string[] | undefined;
    private _securableKind?;
    get securableKind(): string;
    set securableKind(value: string);
    resetSecurableKind(): void;
    get securableKindInput(): string | undefined;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    resetSecurableType(): void;
    get securableTypeInput(): string | undefined;
    private _options;
    get options(): DataDatabricksTableTableInfoSecurableKindManifestOptionsList;
    putOptions(value: DataDatabricksTableTableInfoSecurableKindManifestOptions[] | cdktn.IResolvable): void;
    resetOptions(): void;
    get optionsInput(): cdktn.IResolvable | DataDatabricksTableTableInfoSecurableKindManifestOptions[] | undefined;
}
export interface DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#child_columns DataDatabricksTable#child_columns}
    */
    readonly childColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#name DataDatabricksTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#parent_columns DataDatabricksTable#parent_columns}
    */
    readonly parentColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#parent_table DataDatabricksTable#parent_table}
    */
    readonly parentTable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#rely DataDatabricksTable#rely}
    */
    readonly rely?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksTableTableInfoTableConstraintsForeignKeyConstraintToTerraform(struct?: DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraintOutputReference | DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint): any;
export declare function dataDatabricksTableTableInfoTableConstraintsForeignKeyConstraintToHclTerraform(struct?: DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraintOutputReference | DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint): any;
export declare class DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint | undefined;
    set internalValue(value: DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint | undefined);
    private _childColumns?;
    get childColumns(): string[];
    set childColumns(value: string[]);
    get childColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentColumns?;
    get parentColumns(): string[];
    set parentColumns(value: string[]);
    get parentColumnsInput(): string[] | undefined;
    private _parentTable?;
    get parentTable(): string;
    set parentTable(value: string);
    get parentTableInput(): string | undefined;
    private _rely?;
    get rely(): boolean | cdktn.IResolvable;
    set rely(value: boolean | cdktn.IResolvable);
    resetRely(): void;
    get relyInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#name DataDatabricksTable#name}
    */
    readonly name: string;
}
export declare function dataDatabricksTableTableInfoTableConstraintsNamedTableConstraintToTerraform(struct?: DataDatabricksTableTableInfoTableConstraintsNamedTableConstraintOutputReference | DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint): any;
export declare function dataDatabricksTableTableInfoTableConstraintsNamedTableConstraintToHclTerraform(struct?: DataDatabricksTableTableInfoTableConstraintsNamedTableConstraintOutputReference | DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint): any;
export declare class DataDatabricksTableTableInfoTableConstraintsNamedTableConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint | undefined;
    set internalValue(value: DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#child_columns DataDatabricksTable#child_columns}
    */
    readonly childColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#name DataDatabricksTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#rely DataDatabricksTable#rely}
    */
    readonly rely?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#timeseries_columns DataDatabricksTable#timeseries_columns}
    */
    readonly timeseriesColumns?: string[];
}
export declare function dataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraintToTerraform(struct?: DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraintOutputReference | DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint): any;
export declare function dataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraintToHclTerraform(struct?: DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraintOutputReference | DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint): any;
export declare class DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraintOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint | undefined;
    set internalValue(value: DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint | undefined);
    private _childColumns?;
    get childColumns(): string[];
    set childColumns(value: string[]);
    get childColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rely?;
    get rely(): boolean | cdktn.IResolvable;
    set rely(value: boolean | cdktn.IResolvable);
    resetRely(): void;
    get relyInput(): boolean | cdktn.IResolvable | undefined;
    private _timeseriesColumns?;
    get timeseriesColumns(): string[];
    set timeseriesColumns(value: string[]);
    resetTimeseriesColumns(): void;
    get timeseriesColumnsInput(): string[] | undefined;
}
export interface DataDatabricksTableTableInfoTableConstraints {
    /**
    * foreign_key_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#foreign_key_constraint DataDatabricksTable#foreign_key_constraint}
    */
    readonly foreignKeyConstraint?: DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint;
    /**
    * named_table_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#named_table_constraint DataDatabricksTable#named_table_constraint}
    */
    readonly namedTableConstraint?: DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint;
    /**
    * primary_key_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#primary_key_constraint DataDatabricksTable#primary_key_constraint}
    */
    readonly primaryKeyConstraint?: DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint;
}
export declare function dataDatabricksTableTableInfoTableConstraintsToTerraform(struct?: DataDatabricksTableTableInfoTableConstraints | cdktn.IResolvable): any;
export declare function dataDatabricksTableTableInfoTableConstraintsToHclTerraform(struct?: DataDatabricksTableTableInfoTableConstraints | cdktn.IResolvable): any;
export declare class DataDatabricksTableTableInfoTableConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTableTableInfoTableConstraints | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTableTableInfoTableConstraints | cdktn.IResolvable | undefined);
    private _foreignKeyConstraint;
    get foreignKeyConstraint(): DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraintOutputReference;
    putForeignKeyConstraint(value: DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint): void;
    resetForeignKeyConstraint(): void;
    get foreignKeyConstraintInput(): DataDatabricksTableTableInfoTableConstraintsForeignKeyConstraint | undefined;
    private _namedTableConstraint;
    get namedTableConstraint(): DataDatabricksTableTableInfoTableConstraintsNamedTableConstraintOutputReference;
    putNamedTableConstraint(value: DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint): void;
    resetNamedTableConstraint(): void;
    get namedTableConstraintInput(): DataDatabricksTableTableInfoTableConstraintsNamedTableConstraint | undefined;
    private _primaryKeyConstraint;
    get primaryKeyConstraint(): DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraintOutputReference;
    putPrimaryKeyConstraint(value: DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint): void;
    resetPrimaryKeyConstraint(): void;
    get primaryKeyConstraintInput(): DataDatabricksTableTableInfoTableConstraintsPrimaryKeyConstraint | undefined;
}
export declare class DataDatabricksTableTableInfoTableConstraintsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTableTableInfoTableConstraints[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTableTableInfoTableConstraintsOutputReference;
}
export interface DataDatabricksTableTableInfoViewDependenciesDependenciesConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#connection_name DataDatabricksTable#connection_name}
    */
    readonly connectionName?: string;
}
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesConnectionToTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesConnectionOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesConnection): any;
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesConnectionToHclTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesConnectionOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesConnection): any;
export declare class DataDatabricksTableTableInfoViewDependenciesDependenciesConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoViewDependenciesDependenciesConnection | undefined;
    set internalValue(value: DataDatabricksTableTableInfoViewDependenciesDependenciesConnection | undefined);
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    resetConnectionName(): void;
    get connectionNameInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoViewDependenciesDependenciesCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#credential_name DataDatabricksTable#credential_name}
    */
    readonly credentialName?: string;
}
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesCredentialToTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesCredentialOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesCredential): any;
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesCredentialToHclTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesCredentialOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesCredential): any;
export declare class DataDatabricksTableTableInfoViewDependenciesDependenciesCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoViewDependenciesDependenciesCredential | undefined;
    set internalValue(value: DataDatabricksTableTableInfoViewDependenciesDependenciesCredential | undefined);
    private _credentialName?;
    get credentialName(): string;
    set credentialName(value: string);
    resetCredentialName(): void;
    get credentialNameInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoViewDependenciesDependenciesFunction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#function_full_name DataDatabricksTable#function_full_name}
    */
    readonly functionFullName: string;
}
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesFunctionToTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesFunctionOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesFunction): any;
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesFunctionToHclTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesFunctionOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesFunction): any;
export declare class DataDatabricksTableTableInfoViewDependenciesDependenciesFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoViewDependenciesDependenciesFunction | undefined;
    set internalValue(value: DataDatabricksTableTableInfoViewDependenciesDependenciesFunction | undefined);
    private _functionFullName?;
    get functionFullName(): string;
    set functionFullName(value: string);
    get functionFullNameInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoViewDependenciesDependenciesTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#table_full_name DataDatabricksTable#table_full_name}
    */
    readonly tableFullName: string;
}
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesTableToTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesTableOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesTable): any;
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesTableToHclTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependenciesTableOutputReference | DataDatabricksTableTableInfoViewDependenciesDependenciesTable): any;
export declare class DataDatabricksTableTableInfoViewDependenciesDependenciesTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoViewDependenciesDependenciesTable | undefined;
    set internalValue(value: DataDatabricksTableTableInfoViewDependenciesDependenciesTable | undefined);
    private _tableFullName?;
    get tableFullName(): string;
    set tableFullName(value: string);
    get tableFullNameInput(): string | undefined;
}
export interface DataDatabricksTableTableInfoViewDependenciesDependencies {
    /**
    * connection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#connection DataDatabricksTable#connection}
    */
    readonly connection?: DataDatabricksTableTableInfoViewDependenciesDependenciesConnection;
    /**
    * credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#credential DataDatabricksTable#credential}
    */
    readonly credential?: DataDatabricksTableTableInfoViewDependenciesDependenciesCredential;
    /**
    * function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#function DataDatabricksTable#function}
    */
    readonly function?: DataDatabricksTableTableInfoViewDependenciesDependenciesFunction;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#table DataDatabricksTable#table}
    */
    readonly table?: DataDatabricksTableTableInfoViewDependenciesDependenciesTable;
}
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesToTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependencies | cdktn.IResolvable): any;
export declare function dataDatabricksTableTableInfoViewDependenciesDependenciesToHclTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesDependencies | cdktn.IResolvable): any;
export declare class DataDatabricksTableTableInfoViewDependenciesDependenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksTableTableInfoViewDependenciesDependencies | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksTableTableInfoViewDependenciesDependencies | cdktn.IResolvable | undefined);
    private _connection;
    get connection(): DataDatabricksTableTableInfoViewDependenciesDependenciesConnectionOutputReference;
    putConnection(value: DataDatabricksTableTableInfoViewDependenciesDependenciesConnection): void;
    resetConnection(): void;
    get connectionInput(): DataDatabricksTableTableInfoViewDependenciesDependenciesConnection | undefined;
    private _credential;
    get credential(): DataDatabricksTableTableInfoViewDependenciesDependenciesCredentialOutputReference;
    putCredential(value: DataDatabricksTableTableInfoViewDependenciesDependenciesCredential): void;
    resetCredential(): void;
    get credentialInput(): DataDatabricksTableTableInfoViewDependenciesDependenciesCredential | undefined;
    private _function;
    get function(): DataDatabricksTableTableInfoViewDependenciesDependenciesFunctionOutputReference;
    putFunction(value: DataDatabricksTableTableInfoViewDependenciesDependenciesFunction): void;
    resetFunction(): void;
    get functionInput(): DataDatabricksTableTableInfoViewDependenciesDependenciesFunction | undefined;
    private _table;
    get table(): DataDatabricksTableTableInfoViewDependenciesDependenciesTableOutputReference;
    putTable(value: DataDatabricksTableTableInfoViewDependenciesDependenciesTable): void;
    resetTable(): void;
    get tableInput(): DataDatabricksTableTableInfoViewDependenciesDependenciesTable | undefined;
}
export declare class DataDatabricksTableTableInfoViewDependenciesDependenciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksTableTableInfoViewDependenciesDependencies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksTableTableInfoViewDependenciesDependenciesOutputReference;
}
export interface DataDatabricksTableTableInfoViewDependencies {
    /**
    * dependencies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#dependencies DataDatabricksTable#dependencies}
    */
    readonly dependencies?: DataDatabricksTableTableInfoViewDependenciesDependencies[] | cdktn.IResolvable;
}
export declare function dataDatabricksTableTableInfoViewDependenciesToTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesOutputReference | DataDatabricksTableTableInfoViewDependencies): any;
export declare function dataDatabricksTableTableInfoViewDependenciesToHclTerraform(struct?: DataDatabricksTableTableInfoViewDependenciesOutputReference | DataDatabricksTableTableInfoViewDependencies): any;
export declare class DataDatabricksTableTableInfoViewDependenciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfoViewDependencies | undefined;
    set internalValue(value: DataDatabricksTableTableInfoViewDependencies | undefined);
    private _dependencies;
    get dependencies(): DataDatabricksTableTableInfoViewDependenciesDependenciesList;
    putDependencies(value: DataDatabricksTableTableInfoViewDependenciesDependencies[] | cdktn.IResolvable): void;
    resetDependencies(): void;
    get dependenciesInput(): cdktn.IResolvable | DataDatabricksTableTableInfoViewDependenciesDependencies[] | undefined;
}
export interface DataDatabricksTableTableInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#access_point DataDatabricksTable#access_point}
    */
    readonly accessPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#browse_only DataDatabricksTable#browse_only}
    */
    readonly browseOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#catalog_name DataDatabricksTable#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#comment DataDatabricksTable#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#created_at DataDatabricksTable#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#created_by DataDatabricksTable#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#data_access_configuration_id DataDatabricksTable#data_access_configuration_id}
    */
    readonly dataAccessConfigurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#data_source_format DataDatabricksTable#data_source_format}
    */
    readonly dataSourceFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#deleted_at DataDatabricksTable#deleted_at}
    */
    readonly deletedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#enable_predictive_optimization DataDatabricksTable#enable_predictive_optimization}
    */
    readonly enablePredictiveOptimization?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#full_name DataDatabricksTable#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#metastore_id DataDatabricksTable#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#name DataDatabricksTable#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#owner DataDatabricksTable#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#pipeline_id DataDatabricksTable#pipeline_id}
    */
    readonly pipelineId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#properties DataDatabricksTable#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#schema_name DataDatabricksTable#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#sql_path DataDatabricksTable#sql_path}
    */
    readonly sqlPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#storage_credential_name DataDatabricksTable#storage_credential_name}
    */
    readonly storageCredentialName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#storage_location DataDatabricksTable#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#table_id DataDatabricksTable#table_id}
    */
    readonly tableId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#table_type DataDatabricksTable#table_type}
    */
    readonly tableType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#updated_at DataDatabricksTable#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#updated_by DataDatabricksTable#updated_by}
    */
    readonly updatedBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#view_definition DataDatabricksTable#view_definition}
    */
    readonly viewDefinition?: string;
    /**
    * columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#columns DataDatabricksTable#columns}
    */
    readonly columns?: DataDatabricksTableTableInfoColumns[] | cdktn.IResolvable;
    /**
    * delta_runtime_properties_kvpairs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#delta_runtime_properties_kvpairs DataDatabricksTable#delta_runtime_properties_kvpairs}
    */
    readonly deltaRuntimePropertiesKvpairs?: DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs;
    /**
    * effective_predictive_optimization_flag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#effective_predictive_optimization_flag DataDatabricksTable#effective_predictive_optimization_flag}
    */
    readonly effectivePredictiveOptimizationFlag?: DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag;
    /**
    * encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#encryption_details DataDatabricksTable#encryption_details}
    */
    readonly encryptionDetails?: DataDatabricksTableTableInfoEncryptionDetails;
    /**
    * row_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#row_filter DataDatabricksTable#row_filter}
    */
    readonly rowFilter?: DataDatabricksTableTableInfoRowFilter;
    /**
    * securable_kind_manifest block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#securable_kind_manifest DataDatabricksTable#securable_kind_manifest}
    */
    readonly securableKindManifest?: DataDatabricksTableTableInfoSecurableKindManifest;
    /**
    * table_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#table_constraints DataDatabricksTable#table_constraints}
    */
    readonly tableConstraints?: DataDatabricksTableTableInfoTableConstraints[] | cdktn.IResolvable;
    /**
    * view_dependencies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#view_dependencies DataDatabricksTable#view_dependencies}
    */
    readonly viewDependencies?: DataDatabricksTableTableInfoViewDependencies;
}
export declare function dataDatabricksTableTableInfoToTerraform(struct?: DataDatabricksTableTableInfoOutputReference | DataDatabricksTableTableInfo): any;
export declare function dataDatabricksTableTableInfoToHclTerraform(struct?: DataDatabricksTableTableInfoOutputReference | DataDatabricksTableTableInfo): any;
export declare class DataDatabricksTableTableInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksTableTableInfo | undefined;
    set internalValue(value: DataDatabricksTableTableInfo | undefined);
    private _accessPoint?;
    get accessPoint(): string;
    set accessPoint(value: string);
    resetAccessPoint(): void;
    get accessPointInput(): string | undefined;
    private _browseOnly?;
    get browseOnly(): boolean | cdktn.IResolvable;
    set browseOnly(value: boolean | cdktn.IResolvable);
    resetBrowseOnly(): void;
    get browseOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _dataAccessConfigurationId?;
    get dataAccessConfigurationId(): string;
    set dataAccessConfigurationId(value: string);
    resetDataAccessConfigurationId(): void;
    get dataAccessConfigurationIdInput(): string | undefined;
    private _dataSourceFormat?;
    get dataSourceFormat(): string;
    set dataSourceFormat(value: string);
    resetDataSourceFormat(): void;
    get dataSourceFormatInput(): string | undefined;
    private _deletedAt?;
    get deletedAt(): number;
    set deletedAt(value: number);
    resetDeletedAt(): void;
    get deletedAtInput(): number | undefined;
    private _enablePredictiveOptimization?;
    get enablePredictiveOptimization(): string;
    set enablePredictiveOptimization(value: string);
    resetEnablePredictiveOptimization(): void;
    get enablePredictiveOptimizationInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    resetPipelineId(): void;
    get pipelineIdInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _sqlPath?;
    get sqlPath(): string;
    set sqlPath(value: string);
    resetSqlPath(): void;
    get sqlPathInput(): string | undefined;
    private _storageCredentialName?;
    get storageCredentialName(): string;
    set storageCredentialName(value: string);
    resetStorageCredentialName(): void;
    get storageCredentialNameInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    resetTableId(): void;
    get tableIdInput(): string | undefined;
    private _tableType?;
    get tableType(): string;
    set tableType(value: string);
    resetTableType(): void;
    get tableTypeInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
    private _viewDefinition?;
    get viewDefinition(): string;
    set viewDefinition(value: string);
    resetViewDefinition(): void;
    get viewDefinitionInput(): string | undefined;
    private _columns;
    get columns(): DataDatabricksTableTableInfoColumnsList;
    putColumns(value: DataDatabricksTableTableInfoColumns[] | cdktn.IResolvable): void;
    resetColumns(): void;
    get columnsInput(): cdktn.IResolvable | DataDatabricksTableTableInfoColumns[] | undefined;
    private _deltaRuntimePropertiesKvpairs;
    get deltaRuntimePropertiesKvpairs(): DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairsOutputReference;
    putDeltaRuntimePropertiesKvpairs(value: DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs): void;
    resetDeltaRuntimePropertiesKvpairs(): void;
    get deltaRuntimePropertiesKvpairsInput(): DataDatabricksTableTableInfoDeltaRuntimePropertiesKvpairs | undefined;
    private _effectivePredictiveOptimizationFlag;
    get effectivePredictiveOptimizationFlag(): DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlagOutputReference;
    putEffectivePredictiveOptimizationFlag(value: DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag): void;
    resetEffectivePredictiveOptimizationFlag(): void;
    get effectivePredictiveOptimizationFlagInput(): DataDatabricksTableTableInfoEffectivePredictiveOptimizationFlag | undefined;
    private _encryptionDetails;
    get encryptionDetails(): DataDatabricksTableTableInfoEncryptionDetailsOutputReference;
    putEncryptionDetails(value: DataDatabricksTableTableInfoEncryptionDetails): void;
    resetEncryptionDetails(): void;
    get encryptionDetailsInput(): DataDatabricksTableTableInfoEncryptionDetails | undefined;
    private _rowFilter;
    get rowFilter(): DataDatabricksTableTableInfoRowFilterOutputReference;
    putRowFilter(value: DataDatabricksTableTableInfoRowFilter): void;
    resetRowFilter(): void;
    get rowFilterInput(): DataDatabricksTableTableInfoRowFilter | undefined;
    private _securableKindManifest;
    get securableKindManifest(): DataDatabricksTableTableInfoSecurableKindManifestOutputReference;
    putSecurableKindManifest(value: DataDatabricksTableTableInfoSecurableKindManifest): void;
    resetSecurableKindManifest(): void;
    get securableKindManifestInput(): DataDatabricksTableTableInfoSecurableKindManifest | undefined;
    private _tableConstraints;
    get tableConstraints(): DataDatabricksTableTableInfoTableConstraintsList;
    putTableConstraints(value: DataDatabricksTableTableInfoTableConstraints[] | cdktn.IResolvable): void;
    resetTableConstraints(): void;
    get tableConstraintsInput(): cdktn.IResolvable | DataDatabricksTableTableInfoTableConstraints[] | undefined;
    private _viewDependencies;
    get viewDependencies(): DataDatabricksTableTableInfoViewDependenciesOutputReference;
    putViewDependencies(value: DataDatabricksTableTableInfoViewDependencies): void;
    resetViewDependencies(): void;
    get viewDependenciesInput(): DataDatabricksTableTableInfoViewDependencies | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table databricks_table}
*/
export declare class DataDatabricksTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_table";
    /**
    * Generates CDKTN code for importing a DataDatabricksTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksTable to import
    * @param importFromId The id of the existing DataDatabricksTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/table databricks_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksTableConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksTableConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksTableProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksTableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksTableProviderConfig | undefined;
    private _tableInfo;
    get tableInfo(): DataDatabricksTableTableInfoOutputReference;
    putTableInfo(value: DataDatabricksTableTableInfo): void;
    resetTableInfo(): void;
    get tableInfoInput(): DataDatabricksTableTableInfo | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
