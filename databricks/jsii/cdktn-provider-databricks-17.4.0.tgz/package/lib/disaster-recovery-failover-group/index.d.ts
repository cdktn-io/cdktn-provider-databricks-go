/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DisasterRecoveryFailoverGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#etag DisasterRecoveryFailoverGroup#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#failover_group_id DisasterRecoveryFailoverGroup#failover_group_id}
    */
    readonly failoverGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#initial_primary_region DisasterRecoveryFailoverGroup#initial_primary_region}
    */
    readonly initialPrimaryRegion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#parent DisasterRecoveryFailoverGroup#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#regions DisasterRecoveryFailoverGroup#regions}
    */
    readonly regions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#unity_catalog_assets DisasterRecoveryFailoverGroup#unity_catalog_assets}
    */
    readonly unityCatalogAssets?: DisasterRecoveryFailoverGroupUnityCatalogAssets;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#workspace_sets DisasterRecoveryFailoverGroup#workspace_sets}
    */
    readonly workspaceSets: DisasterRecoveryFailoverGroupWorkspaceSets[] | cdktn.IResolvable;
}
export interface DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#name DisasterRecoveryFailoverGroup#name}
    */
    readonly name: string;
}
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsToTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs | cdktn.IResolvable): any;
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsToHclTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs | cdktn.IResolvable): any;
export declare class DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs | cdktn.IResolvable | undefined;
    set internalValue(value: DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsList extends cdktn.ComplexList {
    internalValue?: DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsOutputReference;
}
export interface DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#region DisasterRecoveryFailoverGroup#region}
    */
    readonly region: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#uri DisasterRecoveryFailoverGroup#uri}
    */
    readonly uri: string;
}
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionToTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion | cdktn.IResolvable): any;
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionToHclTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion | cdktn.IResolvable): any;
export declare class DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion | cdktn.IResolvable | undefined;
    set internalValue(value: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion | cdktn.IResolvable | undefined);
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    private _uri?;
    get uri(): string;
    set uri(value: string);
    get uriInput(): string | undefined;
}
export declare class DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionList extends cdktn.ComplexList {
    internalValue?: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionOutputReference;
}
export interface DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#name DisasterRecoveryFailoverGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#uri_by_region DisasterRecoveryFailoverGroup#uri_by_region}
    */
    readonly uriByRegion: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | cdktn.IResolvable;
}
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsToTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable): any;
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsToHclTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable): any;
export declare class DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable | undefined;
    set internalValue(value: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _uriByRegion;
    get uriByRegion(): DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegionList;
    putUriByRegion(value: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | cdktn.IResolvable): void;
    get uriByRegionInput(): cdktn.IResolvable | DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsUriByRegion[] | undefined;
}
export declare class DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsList extends cdktn.ComplexList {
    internalValue?: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsOutputReference;
}
export interface DisasterRecoveryFailoverGroupUnityCatalogAssets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#catalogs DisasterRecoveryFailoverGroup#catalogs}
    */
    readonly catalogs: DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#data_replication_workspace_set DisasterRecoveryFailoverGroup#data_replication_workspace_set}
    */
    readonly dataReplicationWorkspaceSet: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#location_mappings DisasterRecoveryFailoverGroup#location_mappings}
    */
    readonly locationMappings?: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | cdktn.IResolvable;
}
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsToTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssets | cdktn.IResolvable): any;
export declare function disasterRecoveryFailoverGroupUnityCatalogAssetsToHclTerraform(struct?: DisasterRecoveryFailoverGroupUnityCatalogAssets | cdktn.IResolvable): any;
export declare class DisasterRecoveryFailoverGroupUnityCatalogAssetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DisasterRecoveryFailoverGroupUnityCatalogAssets | cdktn.IResolvable | undefined;
    set internalValue(value: DisasterRecoveryFailoverGroupUnityCatalogAssets | cdktn.IResolvable | undefined);
    private _catalogs;
    get catalogs(): DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogsList;
    putCatalogs(value: DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | cdktn.IResolvable): void;
    get catalogsInput(): cdktn.IResolvable | DisasterRecoveryFailoverGroupUnityCatalogAssetsCatalogs[] | undefined;
    private _dataReplicationWorkspaceSet?;
    get dataReplicationWorkspaceSet(): string;
    set dataReplicationWorkspaceSet(value: string);
    get dataReplicationWorkspaceSetInput(): string | undefined;
    private _locationMappings;
    get locationMappings(): DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappingsList;
    putLocationMappings(value: DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | cdktn.IResolvable): void;
    resetLocationMappings(): void;
    get locationMappingsInput(): cdktn.IResolvable | DisasterRecoveryFailoverGroupUnityCatalogAssetsLocationMappings[] | undefined;
}
export interface DisasterRecoveryFailoverGroupWorkspaceSets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#name DisasterRecoveryFailoverGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#replicate_workspace_assets DisasterRecoveryFailoverGroup#replicate_workspace_assets}
    */
    readonly replicateWorkspaceAssets: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#stable_url_names DisasterRecoveryFailoverGroup#stable_url_names}
    */
    readonly stableUrlNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#workspace_ids DisasterRecoveryFailoverGroup#workspace_ids}
    */
    readonly workspaceIds: string[];
}
export declare function disasterRecoveryFailoverGroupWorkspaceSetsToTerraform(struct?: DisasterRecoveryFailoverGroupWorkspaceSets | cdktn.IResolvable): any;
export declare function disasterRecoveryFailoverGroupWorkspaceSetsToHclTerraform(struct?: DisasterRecoveryFailoverGroupWorkspaceSets | cdktn.IResolvable): any;
export declare class DisasterRecoveryFailoverGroupWorkspaceSetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DisasterRecoveryFailoverGroupWorkspaceSets | cdktn.IResolvable | undefined;
    set internalValue(value: DisasterRecoveryFailoverGroupWorkspaceSets | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _replicateWorkspaceAssets?;
    get replicateWorkspaceAssets(): boolean | cdktn.IResolvable;
    set replicateWorkspaceAssets(value: boolean | cdktn.IResolvable);
    get replicateWorkspaceAssetsInput(): boolean | cdktn.IResolvable | undefined;
    private _stableUrlNames?;
    get stableUrlNames(): string[];
    set stableUrlNames(value: string[]);
    resetStableUrlNames(): void;
    get stableUrlNamesInput(): string[] | undefined;
    private _workspaceIds?;
    get workspaceIds(): string[];
    set workspaceIds(value: string[]);
    get workspaceIdsInput(): string[] | undefined;
}
export declare class DisasterRecoveryFailoverGroupWorkspaceSetsList extends cdktn.ComplexList {
    internalValue?: DisasterRecoveryFailoverGroupWorkspaceSets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DisasterRecoveryFailoverGroupWorkspaceSetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group databricks_disaster_recovery_failover_group}
*/
export declare class DisasterRecoveryFailoverGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_disaster_recovery_failover_group";
    /**
    * Generates CDKTN code for importing a DisasterRecoveryFailoverGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DisasterRecoveryFailoverGroup to import
    * @param importFromId The id of the existing DisasterRecoveryFailoverGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DisasterRecoveryFailoverGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/disaster_recovery_failover_group databricks_disaster_recovery_failover_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DisasterRecoveryFailoverGroupConfig
    */
    constructor(scope: Construct, id: string, config: DisasterRecoveryFailoverGroupConfig);
    get createTime(): string;
    get effectivePrimaryRegion(): string;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _failoverGroupId?;
    get failoverGroupId(): string;
    set failoverGroupId(value: string);
    get failoverGroupIdInput(): string | undefined;
    private _initialPrimaryRegion?;
    get initialPrimaryRegion(): string;
    set initialPrimaryRegion(value: string);
    get initialPrimaryRegionInput(): string | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
    get replicationPoint(): string;
    get state(): string;
    private _unityCatalogAssets;
    get unityCatalogAssets(): DisasterRecoveryFailoverGroupUnityCatalogAssetsOutputReference;
    putUnityCatalogAssets(value: DisasterRecoveryFailoverGroupUnityCatalogAssets): void;
    resetUnityCatalogAssets(): void;
    get unityCatalogAssetsInput(): cdktn.IResolvable | DisasterRecoveryFailoverGroupUnityCatalogAssets | undefined;
    get updateTime(): string;
    private _workspaceSets;
    get workspaceSets(): DisasterRecoveryFailoverGroupWorkspaceSetsList;
    putWorkspaceSets(value: DisasterRecoveryFailoverGroupWorkspaceSets[] | cdktn.IResolvable): void;
    get workspaceSetsInput(): cdktn.IResolvable | DisasterRecoveryFailoverGroupWorkspaceSets[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
