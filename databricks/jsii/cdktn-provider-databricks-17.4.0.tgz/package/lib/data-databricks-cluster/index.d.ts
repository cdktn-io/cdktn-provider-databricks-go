/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_id DataDatabricksCluster#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_name DataDatabricksCluster#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#id DataDatabricksCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * cluster_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_info DataDatabricksCluster#cluster_info}
    */
    readonly clusterInfo?: DataDatabricksClusterClusterInfo;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#provider_config DataDatabricksCluster#provider_config}
    */
    readonly providerConfig?: DataDatabricksClusterProviderConfig;
}
export interface DataDatabricksClusterClusterInfoAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#max_workers DataDatabricksCluster#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#min_workers DataDatabricksCluster#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksClusterClusterInfoAutoscaleToTerraform(struct?: DataDatabricksClusterClusterInfoAutoscaleOutputReference | DataDatabricksClusterClusterInfoAutoscale): any;
export declare function dataDatabricksClusterClusterInfoAutoscaleToHclTerraform(struct?: DataDatabricksClusterClusterInfoAutoscaleOutputReference | DataDatabricksClusterClusterInfoAutoscale): any;
export declare class DataDatabricksClusterClusterInfoAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoAutoscale | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface DataDatabricksClusterClusterInfoAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#availability DataDatabricksCluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_count DataDatabricksCluster#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_iops DataDatabricksCluster#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_size DataDatabricksCluster#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_throughput DataDatabricksCluster#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_type DataDatabricksCluster#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#first_on_demand DataDatabricksCluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#instance_profile_arn DataDatabricksCluster#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spot_bid_price_percent DataDatabricksCluster#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#zone_id DataDatabricksCluster#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterClusterInfoAwsAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoAwsAttributesOutputReference | DataDatabricksClusterClusterInfoAwsAttributes): any;
export declare function dataDatabricksClusterClusterInfoAwsAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoAwsAttributesOutputReference | DataDatabricksClusterClusterInfoAwsAttributes): any;
export declare class DataDatabricksClusterClusterInfoAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoAwsAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#log_analytics_primary_key DataDatabricksCluster#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#log_analytics_workspace_id DataDatabricksCluster#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function dataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfoToTerraform(struct?: DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfoOutputReference | DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo): any;
export declare function dataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfoOutputReference | DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo): any;
export declare class DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#availability DataDatabricksCluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#first_on_demand DataDatabricksCluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spot_bid_max_price DataDatabricksCluster#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#log_analytics_info DataDatabricksCluster#log_analytics_info}
    */
    readonly logAnalyticsInfo?: DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo;
}
export declare function dataDatabricksClusterClusterInfoAzureAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoAzureAttributesOutputReference | DataDatabricksClusterClusterInfoAzureAttributes): any;
export declare function dataDatabricksClusterClusterInfoAzureAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoAzureAttributesOutputReference | DataDatabricksClusterClusterInfoAzureAttributes): any;
export declare class DataDatabricksClusterClusterInfoAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoAzureAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): DataDatabricksClusterClusterInfoAzureAttributesLogAnalyticsInfo | undefined;
}
export interface DataDatabricksClusterClusterInfoClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoClusterLogConfDbfsToTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfDbfsOutputReference | DataDatabricksClusterClusterInfoClusterLogConfDbfs): any;
export declare function dataDatabricksClusterClusterInfoClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfDbfsOutputReference | DataDatabricksClusterClusterInfoClusterLogConfDbfs): any;
export declare class DataDatabricksClusterClusterInfoClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoClusterLogConfDbfs | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#canned_acl DataDatabricksCluster#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_encryption DataDatabricksCluster#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#encryption_type DataDatabricksCluster#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#endpoint DataDatabricksCluster#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#kms_key DataDatabricksCluster#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#region DataDatabricksCluster#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterClusterInfoClusterLogConfS3ToTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfS3OutputReference | DataDatabricksClusterClusterInfoClusterLogConfS3): any;
export declare function dataDatabricksClusterClusterInfoClusterLogConfS3ToHclTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfS3OutputReference | DataDatabricksClusterClusterInfoClusterLogConfS3): any;
export declare class DataDatabricksClusterClusterInfoClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoClusterLogConfS3 | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoClusterLogConfVolumesToTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfVolumesOutputReference | DataDatabricksClusterClusterInfoClusterLogConfVolumes): any;
export declare function dataDatabricksClusterClusterInfoClusterLogConfVolumesToHclTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfVolumesOutputReference | DataDatabricksClusterClusterInfoClusterLogConfVolumes): any;
export declare class DataDatabricksClusterClusterInfoClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoClusterLogConfVolumes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#dbfs DataDatabricksCluster#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterClusterInfoClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#s3 DataDatabricksCluster#s3}
    */
    readonly s3?: DataDatabricksClusterClusterInfoClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#volumes DataDatabricksCluster#volumes}
    */
    readonly volumes?: DataDatabricksClusterClusterInfoClusterLogConfVolumes;
}
export declare function dataDatabricksClusterClusterInfoClusterLogConfToTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfOutputReference | DataDatabricksClusterClusterInfoClusterLogConf): any;
export declare function dataDatabricksClusterClusterInfoClusterLogConfToHclTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogConfOutputReference | DataDatabricksClusterClusterInfoClusterLogConf): any;
export declare class DataDatabricksClusterClusterInfoClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoClusterLogConf | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksClusterClusterInfoClusterLogConfDbfsOutputReference;
    putDbfs(value: DataDatabricksClusterClusterInfoClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksClusterClusterInfoClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): DataDatabricksClusterClusterInfoClusterLogConfS3OutputReference;
    putS3(value: DataDatabricksClusterClusterInfoClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksClusterClusterInfoClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterClusterInfoClusterLogConfVolumesOutputReference;
    putVolumes(value: DataDatabricksClusterClusterInfoClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksClusterClusterInfoClusterLogConfVolumes | undefined;
}
export interface DataDatabricksClusterClusterInfoClusterLogStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#last_attempted DataDatabricksCluster#last_attempted}
    */
    readonly lastAttempted?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#last_exception DataDatabricksCluster#last_exception}
    */
    readonly lastException?: string;
}
export declare function dataDatabricksClusterClusterInfoClusterLogStatusToTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogStatusOutputReference | DataDatabricksClusterClusterInfoClusterLogStatus): any;
export declare function dataDatabricksClusterClusterInfoClusterLogStatusToHclTerraform(struct?: DataDatabricksClusterClusterInfoClusterLogStatusOutputReference | DataDatabricksClusterClusterInfoClusterLogStatus): any;
export declare class DataDatabricksClusterClusterInfoClusterLogStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoClusterLogStatus | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoClusterLogStatus | undefined);
    private _lastAttempted?;
    get lastAttempted(): number;
    set lastAttempted(value: number);
    resetLastAttempted(): void;
    get lastAttemptedInput(): number | undefined;
    private _lastException?;
    get lastException(): string;
    set lastException(value: string);
    resetLastException(): void;
    get lastExceptionInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#password DataDatabricksCluster#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#username DataDatabricksCluster#username}
    */
    readonly username?: string;
}
export declare function dataDatabricksClusterClusterInfoDockerImageBasicAuthToTerraform(struct?: DataDatabricksClusterClusterInfoDockerImageBasicAuthOutputReference | DataDatabricksClusterClusterInfoDockerImageBasicAuth): any;
export declare function dataDatabricksClusterClusterInfoDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksClusterClusterInfoDockerImageBasicAuthOutputReference | DataDatabricksClusterClusterInfoDockerImageBasicAuth): any;
export declare class DataDatabricksClusterClusterInfoDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoDockerImageBasicAuth | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#url DataDatabricksCluster#url}
    */
    readonly url?: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#basic_auth DataDatabricksCluster#basic_auth}
    */
    readonly basicAuth?: DataDatabricksClusterClusterInfoDockerImageBasicAuth;
}
export declare function dataDatabricksClusterClusterInfoDockerImageToTerraform(struct?: DataDatabricksClusterClusterInfoDockerImageOutputReference | DataDatabricksClusterClusterInfoDockerImage): any;
export declare function dataDatabricksClusterClusterInfoDockerImageToHclTerraform(struct?: DataDatabricksClusterClusterInfoDockerImageOutputReference | DataDatabricksClusterClusterInfoDockerImage): any;
export declare class DataDatabricksClusterClusterInfoDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoDockerImage | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): DataDatabricksClusterClusterInfoDockerImageBasicAuthOutputReference;
    putBasicAuth(value: DataDatabricksClusterClusterInfoDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): DataDatabricksClusterClusterInfoDockerImageBasicAuth | undefined;
}
export interface DataDatabricksClusterClusterInfoDriverNodeAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#is_spot DataDatabricksCluster#is_spot}
    */
    readonly isSpot?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterClusterInfoDriverNodeAwsAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoDriverNodeAwsAttributesOutputReference | DataDatabricksClusterClusterInfoDriverNodeAwsAttributes): any;
export declare function dataDatabricksClusterClusterInfoDriverNodeAwsAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoDriverNodeAwsAttributesOutputReference | DataDatabricksClusterClusterInfoDriverNodeAwsAttributes): any;
export declare class DataDatabricksClusterClusterInfoDriverNodeAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoDriverNodeAwsAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoDriverNodeAwsAttributes | undefined);
    private _isSpot?;
    get isSpot(): boolean | cdktn.IResolvable;
    set isSpot(value: boolean | cdktn.IResolvable);
    resetIsSpot(): void;
    get isSpotInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksClusterClusterInfoDriver {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#host_private_ip DataDatabricksCluster#host_private_ip}
    */
    readonly hostPrivateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#instance_id DataDatabricksCluster#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#node_id DataDatabricksCluster#node_id}
    */
    readonly nodeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#private_ip DataDatabricksCluster#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#public_dns DataDatabricksCluster#public_dns}
    */
    readonly publicDns?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#start_timestamp DataDatabricksCluster#start_timestamp}
    */
    readonly startTimestamp?: number;
    /**
    * node_aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#node_aws_attributes DataDatabricksCluster#node_aws_attributes}
    */
    readonly nodeAwsAttributes?: DataDatabricksClusterClusterInfoDriverNodeAwsAttributes;
}
export declare function dataDatabricksClusterClusterInfoDriverToTerraform(struct?: DataDatabricksClusterClusterInfoDriverOutputReference | DataDatabricksClusterClusterInfoDriver): any;
export declare function dataDatabricksClusterClusterInfoDriverToHclTerraform(struct?: DataDatabricksClusterClusterInfoDriverOutputReference | DataDatabricksClusterClusterInfoDriver): any;
export declare class DataDatabricksClusterClusterInfoDriverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoDriver | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoDriver | undefined);
    private _hostPrivateIp?;
    get hostPrivateIp(): string;
    set hostPrivateIp(value: string);
    resetHostPrivateIp(): void;
    get hostPrivateIpInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _nodeId?;
    get nodeId(): string;
    set nodeId(value: string);
    resetNodeId(): void;
    get nodeIdInput(): string | undefined;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    private _publicDns?;
    get publicDns(): string;
    set publicDns(value: string);
    resetPublicDns(): void;
    get publicDnsInput(): string | undefined;
    private _startTimestamp?;
    get startTimestamp(): number;
    set startTimestamp(value: number);
    resetStartTimestamp(): void;
    get startTimestampInput(): number | undefined;
    private _nodeAwsAttributes;
    get nodeAwsAttributes(): DataDatabricksClusterClusterInfoDriverNodeAwsAttributesOutputReference;
    putNodeAwsAttributes(value: DataDatabricksClusterClusterInfoDriverNodeAwsAttributes): void;
    resetNodeAwsAttributes(): void;
    get nodeAwsAttributesInput(): DataDatabricksClusterClusterInfoDriverNodeAwsAttributes | undefined;
}
export interface DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#alternate_node_type_ids DataDatabricksCluster#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterClusterInfoDriverNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterClusterInfoDriverNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility): any;
export declare function dataDatabricksClusterClusterInfoDriverNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterClusterInfoDriverNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility): any;
export declare class DataDatabricksClusterClusterInfoDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#is_spot DataDatabricksCluster#is_spot}
    */
    readonly isSpot?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterClusterInfoExecutorsNodeAwsAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributesOutputReference | DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes): any;
export declare function dataDatabricksClusterClusterInfoExecutorsNodeAwsAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributesOutputReference | DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes): any;
export declare class DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes | undefined);
    private _isSpot?;
    get isSpot(): boolean | cdktn.IResolvable;
    set isSpot(value: boolean | cdktn.IResolvable);
    resetIsSpot(): void;
    get isSpotInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksClusterClusterInfoExecutors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#host_private_ip DataDatabricksCluster#host_private_ip}
    */
    readonly hostPrivateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#instance_id DataDatabricksCluster#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#node_id DataDatabricksCluster#node_id}
    */
    readonly nodeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#private_ip DataDatabricksCluster#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#public_dns DataDatabricksCluster#public_dns}
    */
    readonly publicDns?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#start_timestamp DataDatabricksCluster#start_timestamp}
    */
    readonly startTimestamp?: number;
    /**
    * node_aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#node_aws_attributes DataDatabricksCluster#node_aws_attributes}
    */
    readonly nodeAwsAttributes?: DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes;
}
export declare function dataDatabricksClusterClusterInfoExecutorsToTerraform(struct?: DataDatabricksClusterClusterInfoExecutors | cdktn.IResolvable): any;
export declare function dataDatabricksClusterClusterInfoExecutorsToHclTerraform(struct?: DataDatabricksClusterClusterInfoExecutors | cdktn.IResolvable): any;
export declare class DataDatabricksClusterClusterInfoExecutorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterClusterInfoExecutors | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoExecutors | cdktn.IResolvable | undefined);
    private _hostPrivateIp?;
    get hostPrivateIp(): string;
    set hostPrivateIp(value: string);
    resetHostPrivateIp(): void;
    get hostPrivateIpInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _nodeId?;
    get nodeId(): string;
    set nodeId(value: string);
    resetNodeId(): void;
    get nodeIdInput(): string | undefined;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    private _publicDns?;
    get publicDns(): string;
    set publicDns(value: string);
    resetPublicDns(): void;
    get publicDnsInput(): string | undefined;
    private _startTimestamp?;
    get startTimestamp(): number;
    set startTimestamp(value: number);
    resetStartTimestamp(): void;
    get startTimestampInput(): number | undefined;
    private _nodeAwsAttributes;
    get nodeAwsAttributes(): DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributesOutputReference;
    putNodeAwsAttributes(value: DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes): void;
    resetNodeAwsAttributes(): void;
    get nodeAwsAttributesInput(): DataDatabricksClusterClusterInfoExecutorsNodeAwsAttributes | undefined;
}
export declare class DataDatabricksClusterClusterInfoExecutorsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterClusterInfoExecutors[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterClusterInfoExecutorsOutputReference;
}
export interface DataDatabricksClusterClusterInfoGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#availability DataDatabricksCluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#boot_disk_size DataDatabricksCluster#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#confidential_compute_type DataDatabricksCluster#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#first_on_demand DataDatabricksCluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#google_service_account DataDatabricksCluster#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#local_ssd_count DataDatabricksCluster#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#use_preemptible_executors DataDatabricksCluster#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#zone_id DataDatabricksCluster#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterClusterInfoGcpAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoGcpAttributesOutputReference | DataDatabricksClusterClusterInfoGcpAttributes): any;
export declare function dataDatabricksClusterClusterInfoGcpAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoGcpAttributesOutputReference | DataDatabricksClusterClusterInfoGcpAttributes): any;
export declare class DataDatabricksClusterClusterInfoGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoGcpAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsAbfssToTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsAbfssOutputReference | DataDatabricksClusterClusterInfoInitScriptsAbfss): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsAbfssToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsAbfssOutputReference | DataDatabricksClusterClusterInfoInitScriptsAbfss): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoInitScriptsAbfss | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsDbfsToTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsDbfsOutputReference | DataDatabricksClusterClusterInfoInitScriptsDbfs): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsDbfsToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsDbfsOutputReference | DataDatabricksClusterClusterInfoInitScriptsDbfs): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoInitScriptsDbfs | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsFileToTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsFileOutputReference | DataDatabricksClusterClusterInfoInitScriptsFile): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsFileToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsFileOutputReference | DataDatabricksClusterClusterInfoInitScriptsFile): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoInitScriptsFile | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsGcsToTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsGcsOutputReference | DataDatabricksClusterClusterInfoInitScriptsGcs): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsGcsToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsGcsOutputReference | DataDatabricksClusterClusterInfoInitScriptsGcs): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoInitScriptsGcs | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#canned_acl DataDatabricksCluster#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_encryption DataDatabricksCluster#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#encryption_type DataDatabricksCluster#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#endpoint DataDatabricksCluster#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#kms_key DataDatabricksCluster#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#region DataDatabricksCluster#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsS3ToTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsS3OutputReference | DataDatabricksClusterClusterInfoInitScriptsS3): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsS3ToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsS3OutputReference | DataDatabricksClusterClusterInfoInitScriptsS3): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoInitScriptsS3 | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsVolumesToTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsVolumesOutputReference | DataDatabricksClusterClusterInfoInitScriptsVolumes): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsVolumesToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsVolumesOutputReference | DataDatabricksClusterClusterInfoInitScriptsVolumes): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoInitScriptsVolumes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsWorkspaceToTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsWorkspaceOutputReference | DataDatabricksClusterClusterInfoInitScriptsWorkspace): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScriptsWorkspaceOutputReference | DataDatabricksClusterClusterInfoInitScriptsWorkspace): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoInitScriptsWorkspace | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#abfss DataDatabricksCluster#abfss}
    */
    readonly abfss?: DataDatabricksClusterClusterInfoInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#dbfs DataDatabricksCluster#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterClusterInfoInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#file DataDatabricksCluster#file}
    */
    readonly file?: DataDatabricksClusterClusterInfoInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#gcs DataDatabricksCluster#gcs}
    */
    readonly gcs?: DataDatabricksClusterClusterInfoInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#s3 DataDatabricksCluster#s3}
    */
    readonly s3?: DataDatabricksClusterClusterInfoInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#volumes DataDatabricksCluster#volumes}
    */
    readonly volumes?: DataDatabricksClusterClusterInfoInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#workspace DataDatabricksCluster#workspace}
    */
    readonly workspace?: DataDatabricksClusterClusterInfoInitScriptsWorkspace;
}
export declare function dataDatabricksClusterClusterInfoInitScriptsToTerraform(struct?: DataDatabricksClusterClusterInfoInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksClusterClusterInfoInitScriptsToHclTerraform(struct?: DataDatabricksClusterClusterInfoInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksClusterClusterInfoInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterClusterInfoInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksClusterClusterInfoInitScriptsAbfssOutputReference;
    putAbfss(value: DataDatabricksClusterClusterInfoInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): DataDatabricksClusterClusterInfoInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksClusterClusterInfoInitScriptsDbfsOutputReference;
    putDbfs(value: DataDatabricksClusterClusterInfoInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksClusterClusterInfoInitScriptsDbfs | undefined;
    private _file;
    get file(): DataDatabricksClusterClusterInfoInitScriptsFileOutputReference;
    putFile(value: DataDatabricksClusterClusterInfoInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksClusterClusterInfoInitScriptsFile | undefined;
    private _gcs;
    get gcs(): DataDatabricksClusterClusterInfoInitScriptsGcsOutputReference;
    putGcs(value: DataDatabricksClusterClusterInfoInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): DataDatabricksClusterClusterInfoInitScriptsGcs | undefined;
    private _s3;
    get s3(): DataDatabricksClusterClusterInfoInitScriptsS3OutputReference;
    putS3(value: DataDatabricksClusterClusterInfoInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksClusterClusterInfoInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterClusterInfoInitScriptsVolumesOutputReference;
    putVolumes(value: DataDatabricksClusterClusterInfoInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksClusterClusterInfoInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): DataDatabricksClusterClusterInfoInitScriptsWorkspaceOutputReference;
    putWorkspace(value: DataDatabricksClusterClusterInfoInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): DataDatabricksClusterClusterInfoInitScriptsWorkspace | undefined;
}
export declare class DataDatabricksClusterClusterInfoInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterClusterInfoInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterClusterInfoInitScriptsOutputReference;
}
export interface DataDatabricksClusterClusterInfoSpecAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#max_workers DataDatabricksCluster#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#min_workers DataDatabricksCluster#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksClusterClusterInfoSpecAutoscaleToTerraform(struct?: DataDatabricksClusterClusterInfoSpecAutoscaleOutputReference | DataDatabricksClusterClusterInfoSpecAutoscale): any;
export declare function dataDatabricksClusterClusterInfoSpecAutoscaleToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecAutoscaleOutputReference | DataDatabricksClusterClusterInfoSpecAutoscale): any;
export declare class DataDatabricksClusterClusterInfoSpecAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecAutoscale | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#availability DataDatabricksCluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_count DataDatabricksCluster#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_iops DataDatabricksCluster#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_size DataDatabricksCluster#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_throughput DataDatabricksCluster#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ebs_volume_type DataDatabricksCluster#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#first_on_demand DataDatabricksCluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#instance_profile_arn DataDatabricksCluster#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spot_bid_price_percent DataDatabricksCluster#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#zone_id DataDatabricksCluster#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecAwsAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoSpecAwsAttributesOutputReference | DataDatabricksClusterClusterInfoSpecAwsAttributes): any;
export declare function dataDatabricksClusterClusterInfoSpecAwsAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecAwsAttributesOutputReference | DataDatabricksClusterClusterInfoSpecAwsAttributes): any;
export declare class DataDatabricksClusterClusterInfoSpecAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecAwsAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#log_analytics_primary_key DataDatabricksCluster#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#log_analytics_workspace_id DataDatabricksCluster#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfoToTerraform(struct?: DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfoOutputReference | DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo): any;
export declare function dataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfoOutputReference | DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo): any;
export declare class DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#availability DataDatabricksCluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#first_on_demand DataDatabricksCluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spot_bid_max_price DataDatabricksCluster#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#log_analytics_info DataDatabricksCluster#log_analytics_info}
    */
    readonly logAnalyticsInfo?: DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo;
}
export declare function dataDatabricksClusterClusterInfoSpecAzureAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoSpecAzureAttributesOutputReference | DataDatabricksClusterClusterInfoSpecAzureAttributes): any;
export declare function dataDatabricksClusterClusterInfoSpecAzureAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecAzureAttributesOutputReference | DataDatabricksClusterClusterInfoSpecAzureAttributes): any;
export declare class DataDatabricksClusterClusterInfoSpecAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecAzureAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): DataDatabricksClusterClusterInfoSpecAzureAttributesLogAnalyticsInfo | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfDbfsToTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfDbfsOutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs): any;
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfDbfsOutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs): any;
export declare class DataDatabricksClusterClusterInfoSpecClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#canned_acl DataDatabricksCluster#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_encryption DataDatabricksCluster#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#encryption_type DataDatabricksCluster#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#endpoint DataDatabricksCluster#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#kms_key DataDatabricksCluster#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#region DataDatabricksCluster#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfS3ToTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfS3OutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConfS3): any;
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfS3ToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfS3OutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConfS3): any;
export declare class DataDatabricksClusterClusterInfoSpecClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecClusterLogConfS3 | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfVolumesToTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfVolumesOutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes): any;
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfVolumesToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfVolumesOutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes): any;
export declare class DataDatabricksClusterClusterInfoSpecClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#dbfs DataDatabricksCluster#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#s3 DataDatabricksCluster#s3}
    */
    readonly s3?: DataDatabricksClusterClusterInfoSpecClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#volumes DataDatabricksCluster#volumes}
    */
    readonly volumes?: DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes;
}
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfToTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfOutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConf): any;
export declare function dataDatabricksClusterClusterInfoSpecClusterLogConfToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterLogConfOutputReference | DataDatabricksClusterClusterInfoSpecClusterLogConf): any;
export declare class DataDatabricksClusterClusterInfoSpecClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecClusterLogConf | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksClusterClusterInfoSpecClusterLogConfDbfsOutputReference;
    putDbfs(value: DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksClusterClusterInfoSpecClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): DataDatabricksClusterClusterInfoSpecClusterLogConfS3OutputReference;
    putS3(value: DataDatabricksClusterClusterInfoSpecClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksClusterClusterInfoSpecClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterClusterInfoSpecClusterLogConfVolumesOutputReference;
    putVolumes(value: DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksClusterClusterInfoSpecClusterLogConfVolumes | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#mount_options DataDatabricksCluster#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#server_address DataDatabricksCluster#server_address}
    */
    readonly serverAddress: string;
}
export declare function dataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo): any;
export declare function dataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo): any;
export declare class DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#local_mount_dir_path DataDatabricksCluster#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#remote_mount_dir_path DataDatabricksCluster#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#network_filesystem_info DataDatabricksCluster#network_filesystem_info}
    */
    readonly networkFilesystemInfo: DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo;
}
export declare function dataDatabricksClusterClusterInfoSpecClusterMountInfoToTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterMountInfo | cdktn.IResolvable): any;
export declare function dataDatabricksClusterClusterInfoSpecClusterMountInfoToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecClusterMountInfo | cdktn.IResolvable): any;
export declare class DataDatabricksClusterClusterInfoSpecClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterClusterInfoSpecClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): DataDatabricksClusterClusterInfoSpecClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class DataDatabricksClusterClusterInfoSpecClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterClusterInfoSpecClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterClusterInfoSpecClusterMountInfoOutputReference;
}
export interface DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#password DataDatabricksCluster#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#username DataDatabricksCluster#username}
    */
    readonly username: string;
}
export declare function dataDatabricksClusterClusterInfoSpecDockerImageBasicAuthToTerraform(struct?: DataDatabricksClusterClusterInfoSpecDockerImageBasicAuthOutputReference | DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth): any;
export declare function dataDatabricksClusterClusterInfoSpecDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecDockerImageBasicAuthOutputReference | DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth): any;
export declare class DataDatabricksClusterClusterInfoSpecDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#url DataDatabricksCluster#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#basic_auth DataDatabricksCluster#basic_auth}
    */
    readonly basicAuth?: DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth;
}
export declare function dataDatabricksClusterClusterInfoSpecDockerImageToTerraform(struct?: DataDatabricksClusterClusterInfoSpecDockerImageOutputReference | DataDatabricksClusterClusterInfoSpecDockerImage): any;
export declare function dataDatabricksClusterClusterInfoSpecDockerImageToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecDockerImageOutputReference | DataDatabricksClusterClusterInfoSpecDockerImage): any;
export declare class DataDatabricksClusterClusterInfoSpecDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecDockerImage | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): DataDatabricksClusterClusterInfoSpecDockerImageBasicAuthOutputReference;
    putBasicAuth(value: DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): DataDatabricksClusterClusterInfoSpecDockerImageBasicAuth | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#alternate_node_type_ids DataDatabricksCluster#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility): any;
export declare function dataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility): any;
export declare class DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#availability DataDatabricksCluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#boot_disk_size DataDatabricksCluster#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#confidential_compute_type DataDatabricksCluster#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#first_on_demand DataDatabricksCluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#google_service_account DataDatabricksCluster#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#local_ssd_count DataDatabricksCluster#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#use_preemptible_executors DataDatabricksCluster#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#zone_id DataDatabricksCluster#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecGcpAttributesToTerraform(struct?: DataDatabricksClusterClusterInfoSpecGcpAttributesOutputReference | DataDatabricksClusterClusterInfoSpecGcpAttributes): any;
export declare function dataDatabricksClusterClusterInfoSpecGcpAttributesToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecGcpAttributesOutputReference | DataDatabricksClusterClusterInfoSpecGcpAttributes): any;
export declare class DataDatabricksClusterClusterInfoSpecGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecGcpAttributes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsAbfssToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsAbfssOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsAbfss): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsAbfssToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsAbfssOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsAbfss): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScriptsAbfss | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsDbfsToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsDbfsOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsDbfs): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsDbfsToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsDbfsOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsDbfs): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScriptsDbfs | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsFileToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsFileOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsFile): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsFileToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsFileOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsFile): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScriptsFile | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsGcsToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsGcsOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsGcs): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsGcsToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsGcsOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsGcs): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScriptsGcs | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#canned_acl DataDatabricksCluster#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_encryption DataDatabricksCluster#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#encryption_type DataDatabricksCluster#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#endpoint DataDatabricksCluster#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#kms_key DataDatabricksCluster#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#region DataDatabricksCluster#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsS3ToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsS3OutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsS3): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsS3ToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsS3OutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsS3): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScriptsS3 | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsVolumesToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsVolumesOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsVolumes): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsVolumesToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsVolumesOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsVolumes): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScriptsVolumes | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#destination DataDatabricksCluster#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsWorkspaceToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsWorkspaceOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScriptsWorkspaceOutputReference | DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#abfss DataDatabricksCluster#abfss}
    */
    readonly abfss?: DataDatabricksClusterClusterInfoSpecInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#dbfs DataDatabricksCluster#dbfs}
    */
    readonly dbfs?: DataDatabricksClusterClusterInfoSpecInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#file DataDatabricksCluster#file}
    */
    readonly file?: DataDatabricksClusterClusterInfoSpecInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#gcs DataDatabricksCluster#gcs}
    */
    readonly gcs?: DataDatabricksClusterClusterInfoSpecInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#s3 DataDatabricksCluster#s3}
    */
    readonly s3?: DataDatabricksClusterClusterInfoSpecInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#volumes DataDatabricksCluster#volumes}
    */
    readonly volumes?: DataDatabricksClusterClusterInfoSpecInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#workspace DataDatabricksCluster#workspace}
    */
    readonly workspace?: DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace;
}
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsToTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksClusterClusterInfoSpecInitScriptsToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterClusterInfoSpecInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksClusterClusterInfoSpecInitScriptsAbfssOutputReference;
    putAbfss(value: DataDatabricksClusterClusterInfoSpecInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): DataDatabricksClusterClusterInfoSpecInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksClusterClusterInfoSpecInitScriptsDbfsOutputReference;
    putDbfs(value: DataDatabricksClusterClusterInfoSpecInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksClusterClusterInfoSpecInitScriptsDbfs | undefined;
    private _file;
    get file(): DataDatabricksClusterClusterInfoSpecInitScriptsFileOutputReference;
    putFile(value: DataDatabricksClusterClusterInfoSpecInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksClusterClusterInfoSpecInitScriptsFile | undefined;
    private _gcs;
    get gcs(): DataDatabricksClusterClusterInfoSpecInitScriptsGcsOutputReference;
    putGcs(value: DataDatabricksClusterClusterInfoSpecInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): DataDatabricksClusterClusterInfoSpecInitScriptsGcs | undefined;
    private _s3;
    get s3(): DataDatabricksClusterClusterInfoSpecInitScriptsS3OutputReference;
    putS3(value: DataDatabricksClusterClusterInfoSpecInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksClusterClusterInfoSpecInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksClusterClusterInfoSpecInitScriptsVolumesOutputReference;
    putVolumes(value: DataDatabricksClusterClusterInfoSpecInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksClusterClusterInfoSpecInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): DataDatabricksClusterClusterInfoSpecInitScriptsWorkspaceOutputReference;
    putWorkspace(value: DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): DataDatabricksClusterClusterInfoSpecInitScriptsWorkspace | undefined;
}
export declare class DataDatabricksClusterClusterInfoSpecInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterClusterInfoSpecInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterClusterInfoSpecInitScriptsOutputReference;
}
export interface DataDatabricksClusterClusterInfoSpecLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#package DataDatabricksCluster#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#repo DataDatabricksCluster#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecLibraryCranToTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryCranOutputReference | DataDatabricksClusterClusterInfoSpecLibraryCran): any;
export declare function dataDatabricksClusterClusterInfoSpecLibraryCranToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryCranOutputReference | DataDatabricksClusterClusterInfoSpecLibraryCran): any;
export declare class DataDatabricksClusterClusterInfoSpecLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecLibraryCran | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#coordinates DataDatabricksCluster#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#exclusions DataDatabricksCluster#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#repo DataDatabricksCluster#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecLibraryMavenToTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryMavenOutputReference | DataDatabricksClusterClusterInfoSpecLibraryMaven): any;
export declare function dataDatabricksClusterClusterInfoSpecLibraryMavenToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryMavenOutputReference | DataDatabricksClusterClusterInfoSpecLibraryMaven): any;
export declare class DataDatabricksClusterClusterInfoSpecLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecLibraryMaven | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#workspace_id DataDatabricksCluster#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecLibraryProviderConfigToTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryProviderConfigOutputReference | DataDatabricksClusterClusterInfoSpecLibraryProviderConfig): any;
export declare function dataDatabricksClusterClusterInfoSpecLibraryProviderConfigToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryProviderConfigOutputReference | DataDatabricksClusterClusterInfoSpecLibraryProviderConfig): any;
export declare class DataDatabricksClusterClusterInfoSpecLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecLibraryProviderConfig | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#package DataDatabricksCluster#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#repo DataDatabricksCluster#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecLibraryPypiToTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryPypiOutputReference | DataDatabricksClusterClusterInfoSpecLibraryPypi): any;
export declare function dataDatabricksClusterClusterInfoSpecLibraryPypiToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibraryPypiOutputReference | DataDatabricksClusterClusterInfoSpecLibraryPypi): any;
export declare class DataDatabricksClusterClusterInfoSpecLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecLibraryPypi | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#egg DataDatabricksCluster#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#jar DataDatabricksCluster#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#requirements DataDatabricksCluster#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#whl DataDatabricksCluster#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cran DataDatabricksCluster#cran}
    */
    readonly cran?: DataDatabricksClusterClusterInfoSpecLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#maven DataDatabricksCluster#maven}
    */
    readonly maven?: DataDatabricksClusterClusterInfoSpecLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#provider_config DataDatabricksCluster#provider_config}
    */
    readonly providerConfig?: DataDatabricksClusterClusterInfoSpecLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#pypi DataDatabricksCluster#pypi}
    */
    readonly pypi?: DataDatabricksClusterClusterInfoSpecLibraryPypi;
}
export declare function dataDatabricksClusterClusterInfoSpecLibraryToTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibrary | cdktn.IResolvable): any;
export declare function dataDatabricksClusterClusterInfoSpecLibraryToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecLibrary | cdktn.IResolvable): any;
export declare class DataDatabricksClusterClusterInfoSpecLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksClusterClusterInfoSpecLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): DataDatabricksClusterClusterInfoSpecLibraryCranOutputReference;
    putCran(value: DataDatabricksClusterClusterInfoSpecLibraryCran): void;
    resetCran(): void;
    get cranInput(): DataDatabricksClusterClusterInfoSpecLibraryCran | undefined;
    private _maven;
    get maven(): DataDatabricksClusterClusterInfoSpecLibraryMavenOutputReference;
    putMaven(value: DataDatabricksClusterClusterInfoSpecLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): DataDatabricksClusterClusterInfoSpecLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksClusterClusterInfoSpecLibraryProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksClusterClusterInfoSpecLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksClusterClusterInfoSpecLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): DataDatabricksClusterClusterInfoSpecLibraryPypiOutputReference;
    putPypi(value: DataDatabricksClusterClusterInfoSpecLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): DataDatabricksClusterClusterInfoSpecLibraryPypi | undefined;
}
export declare class DataDatabricksClusterClusterInfoSpecLibraryList extends cdktn.ComplexList {
    internalValue?: DataDatabricksClusterClusterInfoSpecLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksClusterClusterInfoSpecLibraryOutputReference;
}
export interface DataDatabricksClusterClusterInfoSpecProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#workspace_id DataDatabricksCluster#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksClusterClusterInfoSpecProviderConfigToTerraform(struct?: DataDatabricksClusterClusterInfoSpecProviderConfigOutputReference | DataDatabricksClusterClusterInfoSpecProviderConfig): any;
export declare function dataDatabricksClusterClusterInfoSpecProviderConfigToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecProviderConfigOutputReference | DataDatabricksClusterClusterInfoSpecProviderConfig): any;
export declare class DataDatabricksClusterClusterInfoSpecProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecProviderConfig | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#alternate_node_type_ids DataDatabricksCluster#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility): any;
export declare function dataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility): any;
export declare class DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#jobs DataDatabricksCluster#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#notebooks DataDatabricksCluster#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterClusterInfoSpecWorkloadTypeClientsToTerraform(struct?: DataDatabricksClusterClusterInfoSpecWorkloadTypeClientsOutputReference | DataDatabricksClusterClusterInfoSpecWorkloadTypeClients): any;
export declare function dataDatabricksClusterClusterInfoSpecWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecWorkloadTypeClientsOutputReference | DataDatabricksClusterClusterInfoSpecWorkloadTypeClients): any;
export declare class DataDatabricksClusterClusterInfoSpecWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksClusterClusterInfoSpecWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#clients DataDatabricksCluster#clients}
    */
    readonly clients: DataDatabricksClusterClusterInfoSpecWorkloadTypeClients;
}
export declare function dataDatabricksClusterClusterInfoSpecWorkloadTypeToTerraform(struct?: DataDatabricksClusterClusterInfoSpecWorkloadTypeOutputReference | DataDatabricksClusterClusterInfoSpecWorkloadType): any;
export declare function dataDatabricksClusterClusterInfoSpecWorkloadTypeToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecWorkloadTypeOutputReference | DataDatabricksClusterClusterInfoSpecWorkloadType): any;
export declare class DataDatabricksClusterClusterInfoSpecWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpecWorkloadType | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpecWorkloadType | undefined);
    private _clients;
    get clients(): DataDatabricksClusterClusterInfoSpecWorkloadTypeClientsOutputReference;
    putClients(value: DataDatabricksClusterClusterInfoSpecWorkloadTypeClients): void;
    get clientsInput(): DataDatabricksClusterClusterInfoSpecWorkloadTypeClients | undefined;
}
export interface DataDatabricksClusterClusterInfoSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#apply_policy_default_values DataDatabricksCluster#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_name DataDatabricksCluster#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#custom_tags DataDatabricksCluster#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#data_security_mode DataDatabricksCluster#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#driver_instance_pool_id DataDatabricksCluster#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#driver_node_type_id DataDatabricksCluster#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_elastic_disk DataDatabricksCluster#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_local_disk_encryption DataDatabricksCluster#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#idempotency_token DataDatabricksCluster#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#instance_pool_id DataDatabricksCluster#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#is_single_node DataDatabricksCluster#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#kind DataDatabricksCluster#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#node_type_id DataDatabricksCluster#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#num_workers DataDatabricksCluster#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#policy_id DataDatabricksCluster#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#remote_disk_throughput DataDatabricksCluster#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#runtime_engine DataDatabricksCluster#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#single_user_name DataDatabricksCluster#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spark_conf DataDatabricksCluster#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spark_env_vars DataDatabricksCluster#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spark_version DataDatabricksCluster#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ssh_public_keys DataDatabricksCluster#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#total_initial_remote_disk_size DataDatabricksCluster#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#use_ml_runtime DataDatabricksCluster#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#autoscale DataDatabricksCluster#autoscale}
    */
    readonly autoscale?: DataDatabricksClusterClusterInfoSpecAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#aws_attributes DataDatabricksCluster#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksClusterClusterInfoSpecAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#azure_attributes DataDatabricksCluster#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksClusterClusterInfoSpecAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_log_conf DataDatabricksCluster#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksClusterClusterInfoSpecClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_mount_info DataDatabricksCluster#cluster_mount_info}
    */
    readonly clusterMountInfo?: DataDatabricksClusterClusterInfoSpecClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#docker_image DataDatabricksCluster#docker_image}
    */
    readonly dockerImage?: DataDatabricksClusterClusterInfoSpecDockerImage;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#driver_node_type_flexibility DataDatabricksCluster#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#gcp_attributes DataDatabricksCluster#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksClusterClusterInfoSpecGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#init_scripts DataDatabricksCluster#init_scripts}
    */
    readonly initScripts?: DataDatabricksClusterClusterInfoSpecInitScripts[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#library DataDatabricksCluster#library}
    */
    readonly library?: DataDatabricksClusterClusterInfoSpecLibrary[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#provider_config DataDatabricksCluster#provider_config}
    */
    readonly providerConfig?: DataDatabricksClusterClusterInfoSpecProviderConfig;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#worker_node_type_flexibility DataDatabricksCluster#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#workload_type DataDatabricksCluster#workload_type}
    */
    readonly workloadType?: DataDatabricksClusterClusterInfoSpecWorkloadType;
}
export declare function dataDatabricksClusterClusterInfoSpecToTerraform(struct?: DataDatabricksClusterClusterInfoSpecOutputReference | DataDatabricksClusterClusterInfoSpec): any;
export declare function dataDatabricksClusterClusterInfoSpecToHclTerraform(struct?: DataDatabricksClusterClusterInfoSpecOutputReference | DataDatabricksClusterClusterInfoSpec): any;
export declare class DataDatabricksClusterClusterInfoSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoSpec | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoSpec | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    get clusterId(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): DataDatabricksClusterClusterInfoSpecAutoscaleOutputReference;
    putAutoscale(value: DataDatabricksClusterClusterInfoSpecAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): DataDatabricksClusterClusterInfoSpecAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksClusterClusterInfoSpecAwsAttributesOutputReference;
    putAwsAttributes(value: DataDatabricksClusterClusterInfoSpecAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): DataDatabricksClusterClusterInfoSpecAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksClusterClusterInfoSpecAzureAttributesOutputReference;
    putAzureAttributes(value: DataDatabricksClusterClusterInfoSpecAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): DataDatabricksClusterClusterInfoSpecAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksClusterClusterInfoSpecClusterLogConfOutputReference;
    putClusterLogConf(value: DataDatabricksClusterClusterInfoSpecClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): DataDatabricksClusterClusterInfoSpecClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): DataDatabricksClusterClusterInfoSpecClusterMountInfoList;
    putClusterMountInfo(value: DataDatabricksClusterClusterInfoSpecClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | DataDatabricksClusterClusterInfoSpecClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksClusterClusterInfoSpecDockerImageOutputReference;
    putDockerImage(value: DataDatabricksClusterClusterInfoSpecDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): DataDatabricksClusterClusterInfoSpecDockerImage | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): DataDatabricksClusterClusterInfoSpecDriverNodeTypeFlexibility | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksClusterClusterInfoSpecGcpAttributesOutputReference;
    putGcpAttributes(value: DataDatabricksClusterClusterInfoSpecGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): DataDatabricksClusterClusterInfoSpecGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksClusterClusterInfoSpecInitScriptsList;
    putInitScripts(value: DataDatabricksClusterClusterInfoSpecInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksClusterClusterInfoSpecInitScripts[] | undefined;
    private _library;
    get library(): DataDatabricksClusterClusterInfoSpecLibraryList;
    putLibrary(value: DataDatabricksClusterClusterInfoSpecLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | DataDatabricksClusterClusterInfoSpecLibrary[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksClusterClusterInfoSpecProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksClusterClusterInfoSpecProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksClusterClusterInfoSpecProviderConfig | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): DataDatabricksClusterClusterInfoSpecWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksClusterClusterInfoSpecWorkloadTypeOutputReference;
    putWorkloadType(value: DataDatabricksClusterClusterInfoSpecWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): DataDatabricksClusterClusterInfoSpecWorkloadType | undefined;
}
export interface DataDatabricksClusterClusterInfoTerminationReason {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#code DataDatabricksCluster#code}
    */
    readonly code?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#parameters DataDatabricksCluster#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#type DataDatabricksCluster#type}
    */
    readonly type?: string;
}
export declare function dataDatabricksClusterClusterInfoTerminationReasonToTerraform(struct?: DataDatabricksClusterClusterInfoTerminationReasonOutputReference | DataDatabricksClusterClusterInfoTerminationReason): any;
export declare function dataDatabricksClusterClusterInfoTerminationReasonToHclTerraform(struct?: DataDatabricksClusterClusterInfoTerminationReasonOutputReference | DataDatabricksClusterClusterInfoTerminationReason): any;
export declare class DataDatabricksClusterClusterInfoTerminationReasonOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoTerminationReason | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoTerminationReason | undefined);
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#alternate_node_type_ids DataDatabricksCluster#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function dataDatabricksClusterClusterInfoWorkerNodeTypeFlexibilityToTerraform(struct?: DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility): any;
export declare function dataDatabricksClusterClusterInfoWorkerNodeTypeFlexibilityToHclTerraform(struct?: DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibilityOutputReference | DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility): any;
export declare class DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface DataDatabricksClusterClusterInfoWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#jobs DataDatabricksCluster#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#notebooks DataDatabricksCluster#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksClusterClusterInfoWorkloadTypeClientsToTerraform(struct?: DataDatabricksClusterClusterInfoWorkloadTypeClientsOutputReference | DataDatabricksClusterClusterInfoWorkloadTypeClients): any;
export declare function dataDatabricksClusterClusterInfoWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksClusterClusterInfoWorkloadTypeClientsOutputReference | DataDatabricksClusterClusterInfoWorkloadTypeClients): any;
export declare class DataDatabricksClusterClusterInfoWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksClusterClusterInfoWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#clients DataDatabricksCluster#clients}
    */
    readonly clients: DataDatabricksClusterClusterInfoWorkloadTypeClients;
}
export declare function dataDatabricksClusterClusterInfoWorkloadTypeToTerraform(struct?: DataDatabricksClusterClusterInfoWorkloadTypeOutputReference | DataDatabricksClusterClusterInfoWorkloadType): any;
export declare function dataDatabricksClusterClusterInfoWorkloadTypeToHclTerraform(struct?: DataDatabricksClusterClusterInfoWorkloadTypeOutputReference | DataDatabricksClusterClusterInfoWorkloadType): any;
export declare class DataDatabricksClusterClusterInfoWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfoWorkloadType | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfoWorkloadType | undefined);
    private _clients;
    get clients(): DataDatabricksClusterClusterInfoWorkloadTypeClientsOutputReference;
    putClients(value: DataDatabricksClusterClusterInfoWorkloadTypeClients): void;
    get clientsInput(): DataDatabricksClusterClusterInfoWorkloadTypeClients | undefined;
}
export interface DataDatabricksClusterClusterInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#autotermination_minutes DataDatabricksCluster#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_cores DataDatabricksCluster#cluster_cores}
    */
    readonly clusterCores?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_id DataDatabricksCluster#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_memory_mb DataDatabricksCluster#cluster_memory_mb}
    */
    readonly clusterMemoryMb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_name DataDatabricksCluster#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_source DataDatabricksCluster#cluster_source}
    */
    readonly clusterSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#creator_user_name DataDatabricksCluster#creator_user_name}
    */
    readonly creatorUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#custom_tags DataDatabricksCluster#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#data_security_mode DataDatabricksCluster#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#default_tags DataDatabricksCluster#default_tags}
    */
    readonly defaultTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#driver_instance_pool_id DataDatabricksCluster#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#driver_node_type_id DataDatabricksCluster#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_elastic_disk DataDatabricksCluster#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#enable_local_disk_encryption DataDatabricksCluster#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#instance_pool_id DataDatabricksCluster#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#is_single_node DataDatabricksCluster#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#jdbc_port DataDatabricksCluster#jdbc_port}
    */
    readonly jdbcPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#kind DataDatabricksCluster#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#last_restarted_time DataDatabricksCluster#last_restarted_time}
    */
    readonly lastRestartedTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#last_state_loss_time DataDatabricksCluster#last_state_loss_time}
    */
    readonly lastStateLossTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#node_type_id DataDatabricksCluster#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#num_workers DataDatabricksCluster#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#policy_id DataDatabricksCluster#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#remote_disk_throughput DataDatabricksCluster#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#runtime_engine DataDatabricksCluster#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#single_user_name DataDatabricksCluster#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spark_conf DataDatabricksCluster#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spark_context_id DataDatabricksCluster#spark_context_id}
    */
    readonly sparkContextId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spark_env_vars DataDatabricksCluster#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spark_version DataDatabricksCluster#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#ssh_public_keys DataDatabricksCluster#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#start_time DataDatabricksCluster#start_time}
    */
    readonly startTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#state DataDatabricksCluster#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#state_message DataDatabricksCluster#state_message}
    */
    readonly stateMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#terminated_time DataDatabricksCluster#terminated_time}
    */
    readonly terminatedTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#total_initial_remote_disk_size DataDatabricksCluster#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#use_ml_runtime DataDatabricksCluster#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#autoscale DataDatabricksCluster#autoscale}
    */
    readonly autoscale?: DataDatabricksClusterClusterInfoAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#aws_attributes DataDatabricksCluster#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksClusterClusterInfoAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#azure_attributes DataDatabricksCluster#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksClusterClusterInfoAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_log_conf DataDatabricksCluster#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksClusterClusterInfoClusterLogConf;
    /**
    * cluster_log_status block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#cluster_log_status DataDatabricksCluster#cluster_log_status}
    */
    readonly clusterLogStatus?: DataDatabricksClusterClusterInfoClusterLogStatus;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#docker_image DataDatabricksCluster#docker_image}
    */
    readonly dockerImage?: DataDatabricksClusterClusterInfoDockerImage;
    /**
    * driver block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#driver DataDatabricksCluster#driver}
    */
    readonly driver?: DataDatabricksClusterClusterInfoDriver;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#driver_node_type_flexibility DataDatabricksCluster#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility;
    /**
    * executors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#executors DataDatabricksCluster#executors}
    */
    readonly executors?: DataDatabricksClusterClusterInfoExecutors[] | cdktn.IResolvable;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#gcp_attributes DataDatabricksCluster#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksClusterClusterInfoGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#init_scripts DataDatabricksCluster#init_scripts}
    */
    readonly initScripts?: DataDatabricksClusterClusterInfoInitScripts[] | cdktn.IResolvable;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#spec DataDatabricksCluster#spec}
    */
    readonly spec?: DataDatabricksClusterClusterInfoSpec;
    /**
    * termination_reason block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#termination_reason DataDatabricksCluster#termination_reason}
    */
    readonly terminationReason?: DataDatabricksClusterClusterInfoTerminationReason;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#worker_node_type_flexibility DataDatabricksCluster#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#workload_type DataDatabricksCluster#workload_type}
    */
    readonly workloadType?: DataDatabricksClusterClusterInfoWorkloadType;
}
export declare function dataDatabricksClusterClusterInfoToTerraform(struct?: DataDatabricksClusterClusterInfoOutputReference | DataDatabricksClusterClusterInfo): any;
export declare function dataDatabricksClusterClusterInfoToHclTerraform(struct?: DataDatabricksClusterClusterInfoOutputReference | DataDatabricksClusterClusterInfo): any;
export declare class DataDatabricksClusterClusterInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterClusterInfo | undefined;
    set internalValue(value: DataDatabricksClusterClusterInfo | undefined);
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _clusterCores?;
    get clusterCores(): number;
    set clusterCores(value: number);
    resetClusterCores(): void;
    get clusterCoresInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterMemoryMb?;
    get clusterMemoryMb(): number;
    set clusterMemoryMb(value: number);
    resetClusterMemoryMb(): void;
    get clusterMemoryMbInput(): number | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _clusterSource?;
    get clusterSource(): string;
    set clusterSource(value: string);
    resetClusterSource(): void;
    get clusterSourceInput(): string | undefined;
    private _creatorUserName?;
    get creatorUserName(): string;
    set creatorUserName(value: string);
    resetCreatorUserName(): void;
    get creatorUserNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _defaultTags?;
    get defaultTags(): {
        [key: string]: string;
    };
    set defaultTags(value: {
        [key: string]: string;
    });
    resetDefaultTags(): void;
    get defaultTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _jdbcPort?;
    get jdbcPort(): number;
    set jdbcPort(value: number);
    resetJdbcPort(): void;
    get jdbcPortInput(): number | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _lastRestartedTime?;
    get lastRestartedTime(): number;
    set lastRestartedTime(value: number);
    resetLastRestartedTime(): void;
    get lastRestartedTimeInput(): number | undefined;
    private _lastStateLossTime?;
    get lastStateLossTime(): number;
    set lastStateLossTime(value: number);
    resetLastStateLossTime(): void;
    get lastStateLossTimeInput(): number | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkContextId?;
    get sparkContextId(): number;
    set sparkContextId(value: number);
    resetSparkContextId(): void;
    get sparkContextIdInput(): number | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _startTime?;
    get startTime(): number;
    set startTime(value: number);
    resetStartTime(): void;
    get startTimeInput(): number | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _stateMessage?;
    get stateMessage(): string;
    set stateMessage(value: string);
    resetStateMessage(): void;
    get stateMessageInput(): string | undefined;
    private _terminatedTime?;
    get terminatedTime(): number;
    set terminatedTime(value: number);
    resetTerminatedTime(): void;
    get terminatedTimeInput(): number | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): DataDatabricksClusterClusterInfoAutoscaleOutputReference;
    putAutoscale(value: DataDatabricksClusterClusterInfoAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): DataDatabricksClusterClusterInfoAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksClusterClusterInfoAwsAttributesOutputReference;
    putAwsAttributes(value: DataDatabricksClusterClusterInfoAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): DataDatabricksClusterClusterInfoAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksClusterClusterInfoAzureAttributesOutputReference;
    putAzureAttributes(value: DataDatabricksClusterClusterInfoAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): DataDatabricksClusterClusterInfoAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksClusterClusterInfoClusterLogConfOutputReference;
    putClusterLogConf(value: DataDatabricksClusterClusterInfoClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): DataDatabricksClusterClusterInfoClusterLogConf | undefined;
    private _clusterLogStatus;
    get clusterLogStatus(): DataDatabricksClusterClusterInfoClusterLogStatusOutputReference;
    putClusterLogStatus(value: DataDatabricksClusterClusterInfoClusterLogStatus): void;
    resetClusterLogStatus(): void;
    get clusterLogStatusInput(): DataDatabricksClusterClusterInfoClusterLogStatus | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksClusterClusterInfoDockerImageOutputReference;
    putDockerImage(value: DataDatabricksClusterClusterInfoDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): DataDatabricksClusterClusterInfoDockerImage | undefined;
    private _driver;
    get driver(): DataDatabricksClusterClusterInfoDriverOutputReference;
    putDriver(value: DataDatabricksClusterClusterInfoDriver): void;
    resetDriver(): void;
    get driverInput(): DataDatabricksClusterClusterInfoDriver | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): DataDatabricksClusterClusterInfoDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): DataDatabricksClusterClusterInfoDriverNodeTypeFlexibility | undefined;
    private _executors;
    get executors(): DataDatabricksClusterClusterInfoExecutorsList;
    putExecutors(value: DataDatabricksClusterClusterInfoExecutors[] | cdktn.IResolvable): void;
    resetExecutors(): void;
    get executorsInput(): cdktn.IResolvable | DataDatabricksClusterClusterInfoExecutors[] | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksClusterClusterInfoGcpAttributesOutputReference;
    putGcpAttributes(value: DataDatabricksClusterClusterInfoGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): DataDatabricksClusterClusterInfoGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksClusterClusterInfoInitScriptsList;
    putInitScripts(value: DataDatabricksClusterClusterInfoInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksClusterClusterInfoInitScripts[] | undefined;
    private _spec;
    get spec(): DataDatabricksClusterClusterInfoSpecOutputReference;
    putSpec(value: DataDatabricksClusterClusterInfoSpec): void;
    resetSpec(): void;
    get specInput(): DataDatabricksClusterClusterInfoSpec | undefined;
    private _terminationReason;
    get terminationReason(): DataDatabricksClusterClusterInfoTerminationReasonOutputReference;
    putTerminationReason(value: DataDatabricksClusterClusterInfoTerminationReason): void;
    resetTerminationReason(): void;
    get terminationReasonInput(): DataDatabricksClusterClusterInfoTerminationReason | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): DataDatabricksClusterClusterInfoWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksClusterClusterInfoWorkloadTypeOutputReference;
    putWorkloadType(value: DataDatabricksClusterClusterInfoWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): DataDatabricksClusterClusterInfoWorkloadType | undefined;
}
export interface DataDatabricksClusterProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#workspace_id DataDatabricksCluster#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksClusterProviderConfigToTerraform(struct?: DataDatabricksClusterProviderConfigOutputReference | DataDatabricksClusterProviderConfig): any;
export declare function dataDatabricksClusterProviderConfigToHclTerraform(struct?: DataDatabricksClusterProviderConfigOutputReference | DataDatabricksClusterProviderConfig): any;
export declare class DataDatabricksClusterProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterProviderConfig | undefined;
    set internalValue(value: DataDatabricksClusterProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster databricks_cluster}
*/
export declare class DataDatabricksCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_cluster";
    /**
    * Generates CDKTN code for importing a DataDatabricksCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksCluster to import
    * @param importFromId The id of the existing DataDatabricksCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/cluster databricks_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksClusterConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksClusterConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _clusterInfo;
    get clusterInfo(): DataDatabricksClusterClusterInfoOutputReference;
    putClusterInfo(value: DataDatabricksClusterClusterInfo): void;
    resetClusterInfo(): void;
    get clusterInfoInput(): DataDatabricksClusterClusterInfo | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksClusterProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksClusterProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksClusterProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
