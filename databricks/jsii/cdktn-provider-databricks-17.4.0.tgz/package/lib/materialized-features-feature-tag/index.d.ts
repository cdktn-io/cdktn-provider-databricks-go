/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MaterializedFeaturesFeatureTagConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/materialized_features_feature_tag#key MaterializedFeaturesFeatureTag#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/materialized_features_feature_tag#provider_config MaterializedFeaturesFeatureTag#provider_config}
    */
    readonly providerConfig?: MaterializedFeaturesFeatureTagProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/materialized_features_feature_tag#value MaterializedFeaturesFeatureTag#value}
    */
    readonly value?: string;
}
export interface MaterializedFeaturesFeatureTagProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/materialized_features_feature_tag#workspace_id MaterializedFeaturesFeatureTag#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function materializedFeaturesFeatureTagProviderConfigToTerraform(struct?: MaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable): any;
export declare function materializedFeaturesFeatureTagProviderConfigToHclTerraform(struct?: MaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable): any;
export declare class MaterializedFeaturesFeatureTagProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: MaterializedFeaturesFeatureTagProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/materialized_features_feature_tag databricks_materialized_features_feature_tag}
*/
export declare class MaterializedFeaturesFeatureTag extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_materialized_features_feature_tag";
    /**
    * Generates CDKTN code for importing a MaterializedFeaturesFeatureTag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MaterializedFeaturesFeatureTag to import
    * @param importFromId The id of the existing MaterializedFeaturesFeatureTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/materialized_features_feature_tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MaterializedFeaturesFeatureTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/materialized_features_feature_tag databricks_materialized_features_feature_tag} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MaterializedFeaturesFeatureTagConfig
    */
    constructor(scope: Construct, id: string, config: MaterializedFeaturesFeatureTagConfig);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): MaterializedFeaturesFeatureTagProviderConfigOutputReference;
    putProviderConfig(value: MaterializedFeaturesFeatureTagProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | MaterializedFeaturesFeatureTagProviderConfig | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
