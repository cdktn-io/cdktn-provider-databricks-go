/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EnvironmentsDefaultWorkspaceBaseEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/environments_default_workspace_base_environment#cpu_workspace_base_environment EnvironmentsDefaultWorkspaceBaseEnvironment#cpu_workspace_base_environment}
    */
    readonly cpuWorkspaceBaseEnvironment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/environments_default_workspace_base_environment#gpu_workspace_base_environment EnvironmentsDefaultWorkspaceBaseEnvironment#gpu_workspace_base_environment}
    */
    readonly gpuWorkspaceBaseEnvironment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/environments_default_workspace_base_environment#provider_config EnvironmentsDefaultWorkspaceBaseEnvironment#provider_config}
    */
    readonly providerConfig?: EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig;
}
export interface EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/environments_default_workspace_base_environment#workspace_id EnvironmentsDefaultWorkspaceBaseEnvironment#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function environmentsDefaultWorkspaceBaseEnvironmentProviderConfigToTerraform(struct?: EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare function environmentsDefaultWorkspaceBaseEnvironmentProviderConfigToHclTerraform(struct?: EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable): any;
export declare class EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/environments_default_workspace_base_environment databricks_environments_default_workspace_base_environment}
*/
export declare class EnvironmentsDefaultWorkspaceBaseEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_environments_default_workspace_base_environment";
    /**
    * Generates CDKTN code for importing a EnvironmentsDefaultWorkspaceBaseEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EnvironmentsDefaultWorkspaceBaseEnvironment to import
    * @param importFromId The id of the existing EnvironmentsDefaultWorkspaceBaseEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/environments_default_workspace_base_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EnvironmentsDefaultWorkspaceBaseEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/environments_default_workspace_base_environment databricks_environments_default_workspace_base_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EnvironmentsDefaultWorkspaceBaseEnvironmentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: EnvironmentsDefaultWorkspaceBaseEnvironmentConfig);
    private _cpuWorkspaceBaseEnvironment?;
    get cpuWorkspaceBaseEnvironment(): string;
    set cpuWorkspaceBaseEnvironment(value: string);
    resetCpuWorkspaceBaseEnvironment(): void;
    get cpuWorkspaceBaseEnvironmentInput(): string | undefined;
    private _gpuWorkspaceBaseEnvironment?;
    get gpuWorkspaceBaseEnvironment(): string;
    set gpuWorkspaceBaseEnvironment(value: string);
    resetGpuWorkspaceBaseEnvironment(): void;
    get gpuWorkspaceBaseEnvironmentInput(): string | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfigOutputReference;
    putProviderConfig(value: EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | EnvironmentsDefaultWorkspaceBaseEnvironmentProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
