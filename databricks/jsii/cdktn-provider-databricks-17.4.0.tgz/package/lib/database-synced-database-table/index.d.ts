/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DatabaseSyncedDatabaseTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#database_instance_name DatabaseSyncedDatabaseTable#database_instance_name}
    */
    readonly databaseInstanceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#logical_database_name DatabaseSyncedDatabaseTable#logical_database_name}
    */
    readonly logicalDatabaseName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#name DatabaseSyncedDatabaseTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#provider_config DatabaseSyncedDatabaseTable#provider_config}
    */
    readonly providerConfig?: DatabaseSyncedDatabaseTableProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#spec DatabaseSyncedDatabaseTable#spec}
    */
    readonly spec?: DatabaseSyncedDatabaseTableSpec;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get provisioningPhase(): string;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | cdktn.IResolvable | undefined);
    private _initialPipelineSyncProgress;
    get initialPipelineSyncProgress(): DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusInitialPipelineSyncProgressOutputReference;
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | cdktn.IResolvable | undefined);
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfo | undefined);
    get deltaCommitTimestamp(): string;
    get deltaCommitVersion(): number;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusLastSyncToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusLastSyncToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSync | undefined);
    private _deltaTableSyncInfo;
    get deltaTableSyncInfo(): DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncDeltaTableSyncInfoOutputReference;
    get syncEndTimestamp(): string;
    get syncStartTimestamp(): string;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get provisioningPhase(): string;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | cdktn.IResolvable | undefined);
    private _initialPipelineSyncProgress;
    get initialPipelineSyncProgress(): DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusInitialPipelineSyncProgressOutputReference;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get provisioningPhase(): string;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus {
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | cdktn.IResolvable | undefined);
    get lastProcessedCommitVersion(): number;
    get timestamp(): string;
    private _triggeredUpdateProgress;
    get triggeredUpdateProgress(): DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusTriggeredUpdateProgressOutputReference;
}
export interface DatabaseSyncedDatabaseTableDataSynchronizationStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#continuous_update_status DatabaseSyncedDatabaseTable#continuous_update_status}
    */
    readonly continuousUpdateStatus?: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#failed_status DatabaseSyncedDatabaseTable#failed_status}
    */
    readonly failedStatus?: DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#provisioning_status DatabaseSyncedDatabaseTable#provisioning_status}
    */
    readonly provisioningStatus?: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#triggered_update_status DatabaseSyncedDatabaseTable#triggered_update_status}
    */
    readonly triggeredUpdateStatus?: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus;
}
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusToTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatus): any;
export declare function databaseSyncedDatabaseTableDataSynchronizationStatusToHclTerraform(struct?: DatabaseSyncedDatabaseTableDataSynchronizationStatus): any;
export declare class DatabaseSyncedDatabaseTableDataSynchronizationStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableDataSynchronizationStatus | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableDataSynchronizationStatus | undefined);
    private _continuousUpdateStatus;
    get continuousUpdateStatus(): DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatusOutputReference;
    putContinuousUpdateStatus(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus): void;
    resetContinuousUpdateStatus(): void;
    get continuousUpdateStatusInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableDataSynchronizationStatusContinuousUpdateStatus | undefined;
    get detailedState(): string;
    private _failedStatus;
    get failedStatus(): DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatusOutputReference;
    putFailedStatus(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus): void;
    resetFailedStatus(): void;
    get failedStatusInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableDataSynchronizationStatusFailedStatus | undefined;
    private _lastSync;
    get lastSync(): DatabaseSyncedDatabaseTableDataSynchronizationStatusLastSyncOutputReference;
    get message(): string;
    get pipelineId(): string;
    private _provisioningStatus;
    get provisioningStatus(): DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatusOutputReference;
    putProvisioningStatus(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus): void;
    resetProvisioningStatus(): void;
    get provisioningStatusInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableDataSynchronizationStatusProvisioningStatus | undefined;
    private _triggeredUpdateStatus;
    get triggeredUpdateStatus(): DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatusOutputReference;
    putTriggeredUpdateStatus(value: DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus): void;
    resetTriggeredUpdateStatus(): void;
    get triggeredUpdateStatusInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableDataSynchronizationStatusTriggeredUpdateStatus | undefined;
}
export interface DatabaseSyncedDatabaseTableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#workspace_id DatabaseSyncedDatabaseTable#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function databaseSyncedDatabaseTableProviderConfigToTerraform(struct?: DatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableProviderConfigToHclTerraform(struct?: DatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DatabaseSyncedDatabaseTableSpecNewPipelineSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#budget_policy_id DatabaseSyncedDatabaseTable#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#storage_catalog DatabaseSyncedDatabaseTable#storage_catalog}
    */
    readonly storageCatalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#storage_schema DatabaseSyncedDatabaseTable#storage_schema}
    */
    readonly storageSchema?: string;
}
export declare function databaseSyncedDatabaseTableSpecNewPipelineSpecToTerraform(struct?: DatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableSpecNewPipelineSpecToHclTerraform(struct?: DatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableSpecNewPipelineSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableSpecNewPipelineSpec | cdktn.IResolvable | undefined);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _storageCatalog?;
    get storageCatalog(): string;
    set storageCatalog(value: string);
    resetStorageCatalog(): void;
    get storageCatalogInput(): string | undefined;
    private _storageSchema?;
    get storageSchema(): string;
    set storageSchema(value: string);
    resetStorageSchema(): void;
    get storageSchemaInput(): string | undefined;
}
export interface DatabaseSyncedDatabaseTableSpecTypeOverrides {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#column_name DatabaseSyncedDatabaseTable#column_name}
    */
    readonly columnName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#pg_type DatabaseSyncedDatabaseTable#pg_type}
    */
    readonly pgType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#size DatabaseSyncedDatabaseTable#size}
    */
    readonly size?: number;
}
export declare function databaseSyncedDatabaseTableSpecTypeOverridesToTerraform(struct?: DatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableSpecTypeOverridesToHclTerraform(struct?: DatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableSpecTypeOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableSpecTypeOverrides | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    get columnNameInput(): string | undefined;
    private _pgType?;
    get pgType(): string;
    set pgType(value: string);
    get pgTypeInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class DatabaseSyncedDatabaseTableSpecTypeOverridesList extends cdktn.ComplexList {
    internalValue?: DatabaseSyncedDatabaseTableSpecTypeOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DatabaseSyncedDatabaseTableSpecTypeOverridesOutputReference;
}
export interface DatabaseSyncedDatabaseTableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#accelerated_sync DatabaseSyncedDatabaseTable#accelerated_sync}
    */
    readonly acceleratedSync?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#create_database_objects_if_missing DatabaseSyncedDatabaseTable#create_database_objects_if_missing}
    */
    readonly createDatabaseObjectsIfMissing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#existing_pipeline_id DatabaseSyncedDatabaseTable#existing_pipeline_id}
    */
    readonly existingPipelineId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#new_pipeline_spec DatabaseSyncedDatabaseTable#new_pipeline_spec}
    */
    readonly newPipelineSpec?: DatabaseSyncedDatabaseTableSpecNewPipelineSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#primary_key_columns DatabaseSyncedDatabaseTable#primary_key_columns}
    */
    readonly primaryKeyColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#scheduling_policy DatabaseSyncedDatabaseTable#scheduling_policy}
    */
    readonly schedulingPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#source_table_full_name DatabaseSyncedDatabaseTable#source_table_full_name}
    */
    readonly sourceTableFullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#timeseries_key DatabaseSyncedDatabaseTable#timeseries_key}
    */
    readonly timeseriesKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#type_overrides DatabaseSyncedDatabaseTable#type_overrides}
    */
    readonly typeOverrides?: DatabaseSyncedDatabaseTableSpecTypeOverrides[] | cdktn.IResolvable;
}
export declare function databaseSyncedDatabaseTableSpecToTerraform(struct?: DatabaseSyncedDatabaseTableSpec | cdktn.IResolvable): any;
export declare function databaseSyncedDatabaseTableSpecToHclTerraform(struct?: DatabaseSyncedDatabaseTableSpec | cdktn.IResolvable): any;
export declare class DatabaseSyncedDatabaseTableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DatabaseSyncedDatabaseTableSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DatabaseSyncedDatabaseTableSpec | cdktn.IResolvable | undefined);
    private _acceleratedSync?;
    get acceleratedSync(): boolean | cdktn.IResolvable;
    set acceleratedSync(value: boolean | cdktn.IResolvable);
    resetAcceleratedSync(): void;
    get acceleratedSyncInput(): boolean | cdktn.IResolvable | undefined;
    private _createDatabaseObjectsIfMissing?;
    get createDatabaseObjectsIfMissing(): boolean | cdktn.IResolvable;
    set createDatabaseObjectsIfMissing(value: boolean | cdktn.IResolvable);
    resetCreateDatabaseObjectsIfMissing(): void;
    get createDatabaseObjectsIfMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _existingPipelineId?;
    get existingPipelineId(): string;
    set existingPipelineId(value: string);
    resetExistingPipelineId(): void;
    get existingPipelineIdInput(): string | undefined;
    private _newPipelineSpec;
    get newPipelineSpec(): DatabaseSyncedDatabaseTableSpecNewPipelineSpecOutputReference;
    putNewPipelineSpec(value: DatabaseSyncedDatabaseTableSpecNewPipelineSpec): void;
    resetNewPipelineSpec(): void;
    get newPipelineSpecInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableSpecNewPipelineSpec | undefined;
    private _primaryKeyColumns?;
    get primaryKeyColumns(): string[];
    set primaryKeyColumns(value: string[]);
    resetPrimaryKeyColumns(): void;
    get primaryKeyColumnsInput(): string[] | undefined;
    private _schedulingPolicy?;
    get schedulingPolicy(): string;
    set schedulingPolicy(value: string);
    resetSchedulingPolicy(): void;
    get schedulingPolicyInput(): string | undefined;
    private _sourceTableFullName?;
    get sourceTableFullName(): string;
    set sourceTableFullName(value: string);
    resetSourceTableFullName(): void;
    get sourceTableFullNameInput(): string | undefined;
    private _timeseriesKey?;
    get timeseriesKey(): string;
    set timeseriesKey(value: string);
    resetTimeseriesKey(): void;
    get timeseriesKeyInput(): string | undefined;
    private _typeOverrides;
    get typeOverrides(): DatabaseSyncedDatabaseTableSpecTypeOverridesList;
    putTypeOverrides(value: DatabaseSyncedDatabaseTableSpecTypeOverrides[] | cdktn.IResolvable): void;
    resetTypeOverrides(): void;
    get typeOverridesInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableSpecTypeOverrides[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table databricks_database_synced_database_table}
*/
export declare class DatabaseSyncedDatabaseTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_database_synced_database_table";
    /**
    * Generates CDKTN code for importing a DatabaseSyncedDatabaseTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DatabaseSyncedDatabaseTable to import
    * @param importFromId The id of the existing DatabaseSyncedDatabaseTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DatabaseSyncedDatabaseTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/resources/database_synced_database_table databricks_database_synced_database_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DatabaseSyncedDatabaseTableConfig
    */
    constructor(scope: Construct, id: string, config: DatabaseSyncedDatabaseTableConfig);
    private _dataSynchronizationStatus;
    get dataSynchronizationStatus(): DatabaseSyncedDatabaseTableDataSynchronizationStatusOutputReference;
    private _databaseInstanceName?;
    get databaseInstanceName(): string;
    set databaseInstanceName(value: string);
    resetDatabaseInstanceName(): void;
    get databaseInstanceNameInput(): string | undefined;
    get effectiveDatabaseInstanceName(): string;
    get effectiveLogicalDatabaseName(): string;
    private _logicalDatabaseName?;
    get logicalDatabaseName(): string;
    set logicalDatabaseName(value: string);
    resetLogicalDatabaseName(): void;
    get logicalDatabaseNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DatabaseSyncedDatabaseTableProviderConfigOutputReference;
    putProviderConfig(value: DatabaseSyncedDatabaseTableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableProviderConfig | undefined;
    private _spec;
    get spec(): DatabaseSyncedDatabaseTableSpecOutputReference;
    putSpec(value: DatabaseSyncedDatabaseTableSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | DatabaseSyncedDatabaseTableSpec | undefined;
    get unityCatalogProvisioningState(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
