/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDataQualityRefreshesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#object_id DataDatabricksDataQualityRefreshes#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#object_type DataDatabricksDataQualityRefreshes#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#page_size DataDatabricksDataQualityRefreshes#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#provider_config DataDatabricksDataQualityRefreshes#provider_config}
    */
    readonly providerConfig?: DataDatabricksDataQualityRefreshesProviderConfig;
}
export interface DataDatabricksDataQualityRefreshesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#workspace_id DataDatabricksDataQualityRefreshes#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDataQualityRefreshesProviderConfigToTerraform(struct?: DataDatabricksDataQualityRefreshesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityRefreshesProviderConfigToHclTerraform(struct?: DataDatabricksDataQualityRefreshesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityRefreshesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityRefreshesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityRefreshesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksDataQualityRefreshesRefreshesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#workspace_id DataDatabricksDataQualityRefreshes#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDataQualityRefreshesRefreshesProviderConfigToTerraform(struct?: DataDatabricksDataQualityRefreshesRefreshesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityRefreshesRefreshesProviderConfigToHclTerraform(struct?: DataDatabricksDataQualityRefreshesRefreshesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityRefreshesRefreshesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityRefreshesRefreshesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityRefreshesRefreshesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksDataQualityRefreshesRefreshes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#object_id DataDatabricksDataQualityRefreshes#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#object_type DataDatabricksDataQualityRefreshes#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#provider_config DataDatabricksDataQualityRefreshes#provider_config}
    */
    readonly providerConfig?: DataDatabricksDataQualityRefreshesRefreshesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#refresh_id DataDatabricksDataQualityRefreshes#refresh_id}
    */
    readonly refreshId: number;
}
export declare function dataDatabricksDataQualityRefreshesRefreshesToTerraform(struct?: DataDatabricksDataQualityRefreshesRefreshes): any;
export declare function dataDatabricksDataQualityRefreshesRefreshesToHclTerraform(struct?: DataDatabricksDataQualityRefreshesRefreshes): any;
export declare class DataDatabricksDataQualityRefreshesRefreshesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDataQualityRefreshesRefreshes | undefined;
    set internalValue(value: DataDatabricksDataQualityRefreshesRefreshes | undefined);
    get endTimeMs(): number;
    get message(): string;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDataQualityRefreshesRefreshesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDataQualityRefreshesRefreshesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDataQualityRefreshesRefreshesProviderConfig | undefined;
    private _refreshId?;
    get refreshId(): number;
    set refreshId(value: number);
    get refreshIdInput(): number | undefined;
    get startTimeMs(): number;
    get state(): string;
    get trigger(): string;
}
export declare class DataDatabricksDataQualityRefreshesRefreshesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDataQualityRefreshesRefreshes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDataQualityRefreshesRefreshesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes databricks_data_quality_refreshes}
*/
export declare class DataDatabricksDataQualityRefreshes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_data_quality_refreshes";
    /**
    * Generates CDKTN code for importing a DataDatabricksDataQualityRefreshes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDataQualityRefreshes to import
    * @param importFromId The id of the existing DataDatabricksDataQualityRefreshes that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDataQualityRefreshes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.118.0/docs/data-sources/data_quality_refreshes databricks_data_quality_refreshes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDataQualityRefreshesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDataQualityRefreshesConfig);
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDataQualityRefreshesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDataQualityRefreshesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDataQualityRefreshesProviderConfig | undefined;
    private _refreshes;
    get refreshes(): DataDatabricksDataQualityRefreshesRefreshesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
