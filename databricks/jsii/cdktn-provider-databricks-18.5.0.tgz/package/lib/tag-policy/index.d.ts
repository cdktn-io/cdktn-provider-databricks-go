/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TagPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy#description TagPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy#provider_config TagPolicy#provider_config}
    */
    readonly providerConfig?: TagPolicyProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy#tag_key TagPolicy#tag_key}
    */
    readonly tagKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy#values TagPolicy#values}
    */
    readonly values?: TagPolicyValues[] | cdktn.IResolvable;
}
export interface TagPolicyProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy#workspace_id TagPolicy#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function tagPolicyProviderConfigToTerraform(struct?: TagPolicyProviderConfig | cdktn.IResolvable): any;
export declare function tagPolicyProviderConfigToHclTerraform(struct?: TagPolicyProviderConfig | cdktn.IResolvable): any;
export declare class TagPolicyProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TagPolicyProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: TagPolicyProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface TagPolicyValues {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy#name TagPolicy#name}
    */
    readonly name: string;
}
export declare function tagPolicyValuesToTerraform(struct?: TagPolicyValues | cdktn.IResolvable): any;
export declare function tagPolicyValuesToHclTerraform(struct?: TagPolicyValues | cdktn.IResolvable): any;
export declare class TagPolicyValuesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TagPolicyValues | cdktn.IResolvable | undefined;
    set internalValue(value: TagPolicyValues | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class TagPolicyValuesList extends cdktn.ComplexList {
    internalValue?: TagPolicyValues[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TagPolicyValuesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy databricks_tag_policy}
*/
export declare class TagPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_tag_policy";
    /**
    * Generates CDKTN code for importing a TagPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TagPolicy to import
    * @param importFromId The id of the existing TagPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TagPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/tag_policy databricks_tag_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TagPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TagPolicyConfig);
    get createTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _providerConfig;
    get providerConfig(): TagPolicyProviderConfigOutputReference;
    putProviderConfig(value: TagPolicyProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | TagPolicyProviderConfig | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    get tagKeyInput(): string | undefined;
    get updateTime(): string;
    private _values;
    get values(): TagPolicyValuesList;
    putValues(value: TagPolicyValues[] | cdktn.IResolvable): void;
    resetValues(): void;
    get valuesInput(): cdktn.IResolvable | TagPolicyValues[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
