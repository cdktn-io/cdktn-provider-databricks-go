/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountIamWorkspaceAssignmentV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_workspace_assignment_v2#entitlements AccountIamWorkspaceAssignmentV2#entitlements}
    */
    readonly entitlements?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_workspace_assignment_v2#principal_id AccountIamWorkspaceAssignmentV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_workspace_assignment_v2#workspace_id AccountIamWorkspaceAssignmentV2#workspace_id}
    */
    readonly workspaceId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_workspace_assignment_v2 databricks_account_iam_workspace_assignment_v2}
*/
export declare class AccountIamWorkspaceAssignmentV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_iam_workspace_assignment_v2";
    /**
    * Generates CDKTN code for importing a AccountIamWorkspaceAssignmentV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountIamWorkspaceAssignmentV2 to import
    * @param importFromId The id of the existing AccountIamWorkspaceAssignmentV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_workspace_assignment_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountIamWorkspaceAssignmentV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_workspace_assignment_v2 databricks_account_iam_workspace_assignment_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountIamWorkspaceAssignmentV2Config
    */
    constructor(scope: Construct, id: string, config: AccountIamWorkspaceAssignmentV2Config);
    get accountId(): string;
    get effectiveEntitlements(): string[];
    private _entitlements?;
    get entitlements(): string[];
    set entitlements(value: string[]);
    resetEntitlements(): void;
    get entitlementsInput(): string[] | undefined;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    resetWorkspaceId(): void;
    get workspaceIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
