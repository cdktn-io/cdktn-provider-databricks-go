/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksUsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#api DataDatabricksUsers#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#extra_attributes DataDatabricksUsers#extra_attributes}
    */
    readonly extraAttributes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#filter DataDatabricksUsers#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#provider_config DataDatabricksUsers#provider_config}
    */
    readonly providerConfig?: DataDatabricksUsersProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#users DataDatabricksUsers#users}
    */
    readonly users?: DataDatabricksUsersUsers[] | cdktn.IResolvable;
}
export interface DataDatabricksUsersProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#workspace_id DataDatabricksUsers#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksUsersProviderConfigToTerraform(struct?: DataDatabricksUsersProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksUsersProviderConfigToHclTerraform(struct?: DataDatabricksUsersProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksUsersProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksUsersProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksUsersProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksUsersUsersEmails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#display DataDatabricksUsers#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#primary DataDatabricksUsers#primary}
    */
    readonly primary?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#ref DataDatabricksUsers#ref}
    */
    readonly ref?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#type DataDatabricksUsers#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#value DataDatabricksUsers#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksUsersUsersEmailsToTerraform(struct?: DataDatabricksUsersUsersEmails | cdktn.IResolvable): any;
export declare function dataDatabricksUsersUsersEmailsToHclTerraform(struct?: DataDatabricksUsersUsersEmails | cdktn.IResolvable): any;
export declare class DataDatabricksUsersUsersEmailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksUsersUsersEmails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksUsersUsersEmails | cdktn.IResolvable | undefined);
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _primary?;
    get primary(): boolean | cdktn.IResolvable;
    set primary(value: boolean | cdktn.IResolvable);
    resetPrimary(): void;
    get primaryInput(): boolean | cdktn.IResolvable | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksUsersUsersEmailsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksUsersUsersEmails[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksUsersUsersEmailsOutputReference;
}
export interface DataDatabricksUsersUsersEntitlements {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#display DataDatabricksUsers#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#primary DataDatabricksUsers#primary}
    */
    readonly primary?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#ref DataDatabricksUsers#ref}
    */
    readonly ref?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#type DataDatabricksUsers#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#value DataDatabricksUsers#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksUsersUsersEntitlementsToTerraform(struct?: DataDatabricksUsersUsersEntitlements | cdktn.IResolvable): any;
export declare function dataDatabricksUsersUsersEntitlementsToHclTerraform(struct?: DataDatabricksUsersUsersEntitlements | cdktn.IResolvable): any;
export declare class DataDatabricksUsersUsersEntitlementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksUsersUsersEntitlements | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksUsersUsersEntitlements | cdktn.IResolvable | undefined);
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _primary?;
    get primary(): boolean | cdktn.IResolvable;
    set primary(value: boolean | cdktn.IResolvable);
    resetPrimary(): void;
    get primaryInput(): boolean | cdktn.IResolvable | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksUsersUsersEntitlementsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksUsersUsersEntitlements[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksUsersUsersEntitlementsOutputReference;
}
export interface DataDatabricksUsersUsersGroups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#display DataDatabricksUsers#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#primary DataDatabricksUsers#primary}
    */
    readonly primary?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#ref DataDatabricksUsers#ref}
    */
    readonly ref?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#type DataDatabricksUsers#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#value DataDatabricksUsers#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksUsersUsersGroupsToTerraform(struct?: DataDatabricksUsersUsersGroups | cdktn.IResolvable): any;
export declare function dataDatabricksUsersUsersGroupsToHclTerraform(struct?: DataDatabricksUsersUsersGroups | cdktn.IResolvable): any;
export declare class DataDatabricksUsersUsersGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksUsersUsersGroups | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksUsersUsersGroups | cdktn.IResolvable | undefined);
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _primary?;
    get primary(): boolean | cdktn.IResolvable;
    set primary(value: boolean | cdktn.IResolvable);
    resetPrimary(): void;
    get primaryInput(): boolean | cdktn.IResolvable | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksUsersUsersGroupsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksUsersUsersGroups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksUsersUsersGroupsOutputReference;
}
export interface DataDatabricksUsersUsersName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#family_name DataDatabricksUsers#family_name}
    */
    readonly familyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#given_name DataDatabricksUsers#given_name}
    */
    readonly givenName?: string;
}
export declare function dataDatabricksUsersUsersNameToTerraform(struct?: DataDatabricksUsersUsersName | cdktn.IResolvable): any;
export declare function dataDatabricksUsersUsersNameToHclTerraform(struct?: DataDatabricksUsersUsersName | cdktn.IResolvable): any;
export declare class DataDatabricksUsersUsersNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksUsersUsersName | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksUsersUsersName | cdktn.IResolvable | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    resetFamilyName(): void;
    get familyNameInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
}
export interface DataDatabricksUsersUsersRoles {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#display DataDatabricksUsers#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#primary DataDatabricksUsers#primary}
    */
    readonly primary?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#ref DataDatabricksUsers#ref}
    */
    readonly ref?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#type DataDatabricksUsers#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#value DataDatabricksUsers#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksUsersUsersRolesToTerraform(struct?: DataDatabricksUsersUsersRoles | cdktn.IResolvable): any;
export declare function dataDatabricksUsersUsersRolesToHclTerraform(struct?: DataDatabricksUsersUsersRoles | cdktn.IResolvable): any;
export declare class DataDatabricksUsersUsersRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksUsersUsersRoles | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksUsersUsersRoles | cdktn.IResolvable | undefined);
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _primary?;
    get primary(): boolean | cdktn.IResolvable;
    set primary(value: boolean | cdktn.IResolvable);
    resetPrimary(): void;
    get primaryInput(): boolean | cdktn.IResolvable | undefined;
    private _ref?;
    get ref(): string;
    set ref(value: string);
    resetRef(): void;
    get refInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksUsersUsersRolesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksUsersUsersRoles[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksUsersUsersRolesOutputReference;
}
export interface DataDatabricksUsersUsers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#active DataDatabricksUsers#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#display_name DataDatabricksUsers#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#emails DataDatabricksUsers#emails}
    */
    readonly emails?: DataDatabricksUsersUsersEmails[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#entitlements DataDatabricksUsers#entitlements}
    */
    readonly entitlements?: DataDatabricksUsersUsersEntitlements[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#external_id DataDatabricksUsers#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#groups DataDatabricksUsers#groups}
    */
    readonly groups?: DataDatabricksUsersUsersGroups[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#id DataDatabricksUsers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#name DataDatabricksUsers#name}
    */
    readonly name?: DataDatabricksUsersUsersName;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#roles DataDatabricksUsers#roles}
    */
    readonly roles?: DataDatabricksUsersUsersRoles[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#schemas DataDatabricksUsers#schemas}
    */
    readonly schemas?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#user_name DataDatabricksUsers#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksUsersUsersToTerraform(struct?: DataDatabricksUsersUsers | cdktn.IResolvable): any;
export declare function dataDatabricksUsersUsersToHclTerraform(struct?: DataDatabricksUsersUsers | cdktn.IResolvable): any;
export declare class DataDatabricksUsersUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksUsersUsers | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksUsersUsers | cdktn.IResolvable | undefined);
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _emails;
    get emails(): DataDatabricksUsersUsersEmailsList;
    putEmails(value: DataDatabricksUsersUsersEmails[] | cdktn.IResolvable): void;
    resetEmails(): void;
    get emailsInput(): cdktn.IResolvable | DataDatabricksUsersUsersEmails[] | undefined;
    private _entitlements;
    get entitlements(): DataDatabricksUsersUsersEntitlementsList;
    putEntitlements(value: DataDatabricksUsersUsersEntitlements[] | cdktn.IResolvable): void;
    resetEntitlements(): void;
    get entitlementsInput(): cdktn.IResolvable | DataDatabricksUsersUsersEntitlements[] | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _groups;
    get groups(): DataDatabricksUsersUsersGroupsList;
    putGroups(value: DataDatabricksUsersUsersGroups[] | cdktn.IResolvable): void;
    resetGroups(): void;
    get groupsInput(): cdktn.IResolvable | DataDatabricksUsersUsersGroups[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name;
    get name(): DataDatabricksUsersUsersNameOutputReference;
    putName(value: DataDatabricksUsersUsersName): void;
    resetName(): void;
    get nameInput(): cdktn.IResolvable | DataDatabricksUsersUsersName | undefined;
    private _roles;
    get roles(): DataDatabricksUsersUsersRolesList;
    putRoles(value: DataDatabricksUsersUsersRoles[] | cdktn.IResolvable): void;
    resetRoles(): void;
    get rolesInput(): cdktn.IResolvable | DataDatabricksUsersUsersRoles[] | undefined;
    private _schemas?;
    get schemas(): string[];
    set schemas(value: string[]);
    resetSchemas(): void;
    get schemasInput(): string[] | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class DataDatabricksUsersUsersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksUsersUsers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksUsersUsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users databricks_users}
*/
export declare class DataDatabricksUsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_users";
    /**
    * Generates CDKTN code for importing a DataDatabricksUsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksUsers to import
    * @param importFromId The id of the existing DataDatabricksUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/users databricks_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksUsersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksUsersConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _extraAttributes?;
    get extraAttributes(): string;
    set extraAttributes(value: string);
    resetExtraAttributes(): void;
    get extraAttributesInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksUsersProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksUsersProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksUsersProviderConfig | undefined;
    private _users;
    get users(): DataDatabricksUsersUsersList;
    putUsers(value: DataDatabricksUsersUsers[] | cdktn.IResolvable): void;
    resetUsers(): void;
    get usersInput(): cdktn.IResolvable | DataDatabricksUsersUsers[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
