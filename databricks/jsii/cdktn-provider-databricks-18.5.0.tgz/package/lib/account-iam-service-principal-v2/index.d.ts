/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountIamServicePrincipalV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_service_principal_v2#account_sp_status AccountIamServicePrincipalV2#account_sp_status}
    */
    readonly accountSpStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_service_principal_v2#application_id AccountIamServicePrincipalV2#application_id}
    */
    readonly applicationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_service_principal_v2#display_name AccountIamServicePrincipalV2#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_service_principal_v2#external_id AccountIamServicePrincipalV2#external_id}
    */
    readonly externalId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_service_principal_v2 databricks_account_iam_service_principal_v2}
*/
export declare class AccountIamServicePrincipalV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_iam_service_principal_v2";
    /**
    * Generates CDKTN code for importing a AccountIamServicePrincipalV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountIamServicePrincipalV2 to import
    * @param importFromId The id of the existing AccountIamServicePrincipalV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_service_principal_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountIamServicePrincipalV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_service_principal_v2 databricks_account_iam_service_principal_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountIamServicePrincipalV2Config
    */
    constructor(scope: Construct, id: string, config: AccountIamServicePrincipalV2Config);
    get accountId(): string;
    private _accountSpStatus?;
    get accountSpStatus(): string;
    set accountSpStatus(value: string);
    get accountSpStatusInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    resetApplicationId(): void;
    get applicationIdInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    get servicePrincipalId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
