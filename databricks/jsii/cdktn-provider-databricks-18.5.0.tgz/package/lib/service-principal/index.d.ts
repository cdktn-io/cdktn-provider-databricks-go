/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServicePrincipalConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#acl_principal_id ServicePrincipal#acl_principal_id}
    */
    readonly aclPrincipalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#active ServicePrincipal#active}
    */
    readonly active?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#allow_cluster_create ServicePrincipal#allow_cluster_create}
    */
    readonly allowClusterCreate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#allow_instance_pool_create ServicePrincipal#allow_instance_pool_create}
    */
    readonly allowInstancePoolCreate?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#api ServicePrincipal#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#application_id ServicePrincipal#application_id}
    */
    readonly applicationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#databricks_sql_access ServicePrincipal#databricks_sql_access}
    */
    readonly databricksSqlAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#disable_as_user_deletion ServicePrincipal#disable_as_user_deletion}
    */
    readonly disableAsUserDeletion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#display_name ServicePrincipal#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#external_id ServicePrincipal#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#force ServicePrincipal#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#force_delete_home_dir ServicePrincipal#force_delete_home_dir}
    */
    readonly forceDeleteHomeDir?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#force_delete_repos ServicePrincipal#force_delete_repos}
    */
    readonly forceDeleteRepos?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#home ServicePrincipal#home}
    */
    readonly home?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#id ServicePrincipal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#repos ServicePrincipal#repos}
    */
    readonly repos?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#workspace_access ServicePrincipal#workspace_access}
    */
    readonly workspaceAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#workspace_consume ServicePrincipal#workspace_consume}
    */
    readonly workspaceConsume?: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#provider_config ServicePrincipal#provider_config}
    */
    readonly providerConfig?: ServicePrincipalProviderConfig;
}
export interface ServicePrincipalProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#workspace_id ServicePrincipal#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function servicePrincipalProviderConfigToTerraform(struct?: ServicePrincipalProviderConfigOutputReference | ServicePrincipalProviderConfig): any;
export declare function servicePrincipalProviderConfigToHclTerraform(struct?: ServicePrincipalProviderConfigOutputReference | ServicePrincipalProviderConfig): any;
export declare class ServicePrincipalProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServicePrincipalProviderConfig | undefined;
    set internalValue(value: ServicePrincipalProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal databricks_service_principal}
*/
export declare class ServicePrincipal extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_service_principal";
    /**
    * Generates CDKTN code for importing a ServicePrincipal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServicePrincipal to import
    * @param importFromId The id of the existing ServicePrincipal that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServicePrincipal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/service_principal databricks_service_principal} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServicePrincipalConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ServicePrincipalConfig);
    private _aclPrincipalId?;
    get aclPrincipalId(): string;
    set aclPrincipalId(value: string);
    resetAclPrincipalId(): void;
    get aclPrincipalIdInput(): string | undefined;
    private _active?;
    get active(): boolean | cdktn.IResolvable;
    set active(value: boolean | cdktn.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktn.IResolvable | undefined;
    private _allowClusterCreate?;
    get allowClusterCreate(): boolean | cdktn.IResolvable;
    set allowClusterCreate(value: boolean | cdktn.IResolvable);
    resetAllowClusterCreate(): void;
    get allowClusterCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _allowInstancePoolCreate?;
    get allowInstancePoolCreate(): boolean | cdktn.IResolvable;
    set allowInstancePoolCreate(value: boolean | cdktn.IResolvable);
    resetAllowInstancePoolCreate(): void;
    get allowInstancePoolCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    resetApplicationId(): void;
    get applicationIdInput(): string | undefined;
    private _databricksSqlAccess?;
    get databricksSqlAccess(): boolean | cdktn.IResolvable;
    set databricksSqlAccess(value: boolean | cdktn.IResolvable);
    resetDatabricksSqlAccess(): void;
    get databricksSqlAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _disableAsUserDeletion?;
    get disableAsUserDeletion(): boolean | cdktn.IResolvable;
    set disableAsUserDeletion(value: boolean | cdktn.IResolvable);
    resetDisableAsUserDeletion(): void;
    get disableAsUserDeletionInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDeleteHomeDir?;
    get forceDeleteHomeDir(): boolean | cdktn.IResolvable;
    set forceDeleteHomeDir(value: boolean | cdktn.IResolvable);
    resetForceDeleteHomeDir(): void;
    get forceDeleteHomeDirInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDeleteRepos?;
    get forceDeleteRepos(): boolean | cdktn.IResolvable;
    set forceDeleteRepos(value: boolean | cdktn.IResolvable);
    resetForceDeleteRepos(): void;
    get forceDeleteReposInput(): boolean | cdktn.IResolvable | undefined;
    private _home?;
    get home(): string;
    set home(value: string);
    resetHome(): void;
    get homeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _repos?;
    get repos(): string;
    set repos(value: string);
    resetRepos(): void;
    get reposInput(): string | undefined;
    private _workspaceAccess?;
    get workspaceAccess(): boolean | cdktn.IResolvable;
    set workspaceAccess(value: boolean | cdktn.IResolvable);
    resetWorkspaceAccess(): void;
    get workspaceAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _workspaceConsume?;
    get workspaceConsume(): boolean | cdktn.IResolvable;
    set workspaceConsume(value: boolean | cdktn.IResolvable);
    resetWorkspaceConsume(): void;
    get workspaceConsumeInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): ServicePrincipalProviderConfigOutputReference;
    putProviderConfig(value: ServicePrincipalProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ServicePrincipalProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
