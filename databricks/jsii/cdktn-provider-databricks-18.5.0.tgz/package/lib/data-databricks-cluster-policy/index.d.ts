/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksClusterPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#definition DataDatabricksClusterPolicy#definition}
    */
    readonly definition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#description DataDatabricksClusterPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#id DataDatabricksClusterPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#is_default DataDatabricksClusterPolicy#is_default}
    */
    readonly isDefault?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#max_clusters_per_user DataDatabricksClusterPolicy#max_clusters_per_user}
    */
    readonly maxClustersPerUser?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#name DataDatabricksClusterPolicy#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#policy_family_definition_overrides DataDatabricksClusterPolicy#policy_family_definition_overrides}
    */
    readonly policyFamilyDefinitionOverrides?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#policy_family_id DataDatabricksClusterPolicy#policy_family_id}
    */
    readonly policyFamilyId?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#provider_config DataDatabricksClusterPolicy#provider_config}
    */
    readonly providerConfig?: DataDatabricksClusterPolicyProviderConfig;
}
export interface DataDatabricksClusterPolicyProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#workspace_id DataDatabricksClusterPolicy#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksClusterPolicyProviderConfigToTerraform(struct?: DataDatabricksClusterPolicyProviderConfigOutputReference | DataDatabricksClusterPolicyProviderConfig): any;
export declare function dataDatabricksClusterPolicyProviderConfigToHclTerraform(struct?: DataDatabricksClusterPolicyProviderConfigOutputReference | DataDatabricksClusterPolicyProviderConfig): any;
export declare class DataDatabricksClusterPolicyProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksClusterPolicyProviderConfig | undefined;
    set internalValue(value: DataDatabricksClusterPolicyProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy databricks_cluster_policy}
*/
export declare class DataDatabricksClusterPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_cluster_policy";
    /**
    * Generates CDKTN code for importing a DataDatabricksClusterPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksClusterPolicy to import
    * @param importFromId The id of the existing DataDatabricksClusterPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksClusterPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/cluster_policy databricks_cluster_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksClusterPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksClusterPolicyConfig);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    resetDefinition(): void;
    get definitionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isDefault?;
    get isDefault(): boolean | cdktn.IResolvable;
    set isDefault(value: boolean | cdktn.IResolvable);
    resetIsDefault(): void;
    get isDefaultInput(): boolean | cdktn.IResolvable | undefined;
    private _maxClustersPerUser?;
    get maxClustersPerUser(): number;
    set maxClustersPerUser(value: number);
    resetMaxClustersPerUser(): void;
    get maxClustersPerUserInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _policyFamilyDefinitionOverrides?;
    get policyFamilyDefinitionOverrides(): string;
    set policyFamilyDefinitionOverrides(value: string);
    resetPolicyFamilyDefinitionOverrides(): void;
    get policyFamilyDefinitionOverridesInput(): string | undefined;
    private _policyFamilyId?;
    get policyFamilyId(): string;
    set policyFamilyId(value: string);
    resetPolicyFamilyId(): void;
    get policyFamilyIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksClusterPolicyProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksClusterPolicyProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksClusterPolicyProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
