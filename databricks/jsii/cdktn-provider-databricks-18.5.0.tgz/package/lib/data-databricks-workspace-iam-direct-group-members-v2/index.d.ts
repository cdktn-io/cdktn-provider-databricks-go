/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamDirectGroupMembersV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#group_id DataDatabricksWorkspaceIamDirectGroupMembersV2#group_id}
    */
    readonly groupId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#page_size DataDatabricksWorkspaceIamDirectGroupMembersV2#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#provider_config DataDatabricksWorkspaceIamDirectGroupMembersV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#workspace_id DataDatabricksWorkspaceIamDirectGroupMembersV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#group_id DataDatabricksWorkspaceIamDirectGroupMembersV2#group_id}
    */
    readonly groupId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#principal_id DataDatabricksWorkspaceIamDirectGroupMembersV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#provider_config DataDatabricksWorkspaceIamDirectGroupMembersV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig;
}
export declare function dataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersToTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembers): any;
export declare function dataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersToHclTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembers): any;
export declare class DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembers | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembers | undefined);
    get displayName(): string;
    get externalId(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    get groupIdInput(): number | undefined;
    get membershipSource(): string;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersProviderConfig | undefined;
}
export declare class DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersOutputReference;
}
export interface DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#workspace_id DataDatabricksWorkspaceIamDirectGroupMembersV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2 databricks_workspace_iam_direct_group_members_v2}
*/
export declare class DataDatabricksWorkspaceIamDirectGroupMembersV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_direct_group_members_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamDirectGroupMembersV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamDirectGroupMembersV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamDirectGroupMembersV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamDirectGroupMembersV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_direct_group_members_v2 databricks_workspace_iam_direct_group_members_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamDirectGroupMembersV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamDirectGroupMembersV2Config);
    private _directGroupMembers;
    get directGroupMembers(): DataDatabricksWorkspaceIamDirectGroupMembersV2DirectGroupMembersList;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    get groupIdInput(): number | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamDirectGroupMembersV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
