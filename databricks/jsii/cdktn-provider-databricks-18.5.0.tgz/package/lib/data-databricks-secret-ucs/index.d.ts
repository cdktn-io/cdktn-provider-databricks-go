/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSecretUcsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#catalog_name DataDatabricksSecretUcs#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#page_size DataDatabricksSecretUcs#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#provider_config DataDatabricksSecretUcs#provider_config}
    */
    readonly providerConfig?: DataDatabricksSecretUcsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#schema_name DataDatabricksSecretUcs#schema_name}
    */
    readonly schemaName?: string;
}
export interface DataDatabricksSecretUcsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#workspace_id DataDatabricksSecretUcs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSecretUcsProviderConfigToTerraform(struct?: DataDatabricksSecretUcsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSecretUcsProviderConfigToHclTerraform(struct?: DataDatabricksSecretUcsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSecretUcsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSecretUcsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSecretUcsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSecretUcsSecretsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#workspace_id DataDatabricksSecretUcs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSecretUcsSecretsProviderConfigToTerraform(struct?: DataDatabricksSecretUcsSecretsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSecretUcsSecretsProviderConfigToHclTerraform(struct?: DataDatabricksSecretUcsSecretsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSecretUcsSecretsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSecretUcsSecretsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSecretUcsSecretsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSecretUcsSecrets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#full_name DataDatabricksSecretUcs#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#provider_config DataDatabricksSecretUcs#provider_config}
    */
    readonly providerConfig?: DataDatabricksSecretUcsSecretsProviderConfig;
}
export declare function dataDatabricksSecretUcsSecretsToTerraform(struct?: DataDatabricksSecretUcsSecrets): any;
export declare function dataDatabricksSecretUcsSecretsToHclTerraform(struct?: DataDatabricksSecretUcsSecrets): any;
export declare class DataDatabricksSecretUcsSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksSecretUcsSecrets | undefined;
    set internalValue(value: DataDatabricksSecretUcsSecrets | undefined);
    get catalogName(): string;
    get comment(): string;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get effectiveValue(): string;
    get expireTime(): string;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    get metastoreId(): string;
    get name(): string;
    get owner(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksSecretUcsSecretsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSecretUcsSecretsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSecretUcsSecretsProviderConfig | undefined;
    get schemaName(): string;
    get updateTime(): string;
    get updatedBy(): string;
    get value(): string;
}
export declare class DataDatabricksSecretUcsSecretsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksSecretUcsSecrets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksSecretUcsSecretsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs databricks_secret_ucs}
*/
export declare class DataDatabricksSecretUcs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_secret_ucs";
    /**
    * Generates CDKTN code for importing a DataDatabricksSecretUcs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSecretUcs to import
    * @param importFromId The id of the existing DataDatabricksSecretUcs that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSecretUcs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/secret_ucs databricks_secret_ucs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSecretUcsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksSecretUcsConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSecretUcsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSecretUcsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSecretUcsProviderConfig | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _secrets;
    get secrets(): DataDatabricksSecretUcsSecretsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
