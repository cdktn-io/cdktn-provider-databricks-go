/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BudgetPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy#binding_workspace_ids BudgetPolicy#binding_workspace_ids}
    */
    readonly bindingWorkspaceIds?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy#custom_tags BudgetPolicy#custom_tags}
    */
    readonly customTags?: BudgetPolicyCustomTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy#policy_id BudgetPolicy#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy#policy_name BudgetPolicy#policy_name}
    */
    readonly policyName?: string;
}
export interface BudgetPolicyCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy#key BudgetPolicy#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy#value BudgetPolicy#value}
    */
    readonly value?: string;
}
export declare function budgetPolicyCustomTagsToTerraform(struct?: BudgetPolicyCustomTags | cdktn.IResolvable): any;
export declare function budgetPolicyCustomTagsToHclTerraform(struct?: BudgetPolicyCustomTags | cdktn.IResolvable): any;
export declare class BudgetPolicyCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BudgetPolicyCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: BudgetPolicyCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class BudgetPolicyCustomTagsList extends cdktn.ComplexList {
    internalValue?: BudgetPolicyCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BudgetPolicyCustomTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy databricks_budget_policy}
*/
export declare class BudgetPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_budget_policy";
    /**
    * Generates CDKTN code for importing a BudgetPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BudgetPolicy to import
    * @param importFromId The id of the existing BudgetPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BudgetPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/budget_policy databricks_budget_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BudgetPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: BudgetPolicyConfig);
    private _bindingWorkspaceIds?;
    get bindingWorkspaceIds(): number[];
    set bindingWorkspaceIds(value: number[]);
    resetBindingWorkspaceIds(): void;
    get bindingWorkspaceIdsInput(): number[] | undefined;
    private _customTags;
    get customTags(): BudgetPolicyCustomTagsList;
    putCustomTags(value: BudgetPolicyCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | BudgetPolicyCustomTags[] | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    resetPolicyName(): void;
    get policyNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
