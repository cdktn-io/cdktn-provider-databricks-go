/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksRecipientsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/recipients#provider_config DataDatabricksRecipients#provider_config}
    */
    readonly providerConfig?: DataDatabricksRecipientsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/recipients#recipients DataDatabricksRecipients#recipients}
    */
    readonly recipients?: string[];
}
export interface DataDatabricksRecipientsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/recipients#workspace_id DataDatabricksRecipients#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksRecipientsProviderConfigToTerraform(struct?: DataDatabricksRecipientsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksRecipientsProviderConfigToHclTerraform(struct?: DataDatabricksRecipientsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksRecipientsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksRecipientsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRecipientsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/recipients databricks_recipients}
*/
export declare class DataDatabricksRecipients extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_recipients";
    /**
    * Generates CDKTN code for importing a DataDatabricksRecipients resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksRecipients to import
    * @param importFromId The id of the existing DataDatabricksRecipients that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/recipients#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksRecipients to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/recipients databricks_recipients} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksRecipientsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksRecipientsConfig);
    private _providerConfig;
    get providerConfig(): DataDatabricksRecipientsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksRecipientsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksRecipientsProviderConfig | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
