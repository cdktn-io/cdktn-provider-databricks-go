/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamUsersV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#filter DataDatabricksWorkspaceIamUsersV2#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#page_size DataDatabricksWorkspaceIamUsersV2#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#provider_config DataDatabricksWorkspaceIamUsersV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamUsersV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamUsersV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#workspace_id DataDatabricksWorkspaceIamUsersV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamUsersV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamUsersV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamUsersV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamUsersV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamUsersV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamUsersV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamUsersV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamUsersV2UsersFullName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#family_name DataDatabricksWorkspaceIamUsersV2#family_name}
    */
    readonly familyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#given_name DataDatabricksWorkspaceIamUsersV2#given_name}
    */
    readonly givenName?: string;
}
export declare function dataDatabricksWorkspaceIamUsersV2UsersFullNameToTerraform(struct?: DataDatabricksWorkspaceIamUsersV2UsersFullName): any;
export declare function dataDatabricksWorkspaceIamUsersV2UsersFullNameToHclTerraform(struct?: DataDatabricksWorkspaceIamUsersV2UsersFullName): any;
export declare class DataDatabricksWorkspaceIamUsersV2UsersFullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamUsersV2UsersFullName | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamUsersV2UsersFullName | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    resetFamilyName(): void;
    get familyNameInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamUsersV2UsersProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#workspace_id DataDatabricksWorkspaceIamUsersV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamUsersV2UsersProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamUsersV2UsersProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamUsersV2UsersProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamUsersV2UsersProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamUsersV2UsersProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamUsersV2UsersProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamUsersV2UsersProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamUsersV2Users {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#provider_config DataDatabricksWorkspaceIamUsersV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamUsersV2UsersProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#user_id DataDatabricksWorkspaceIamUsersV2#user_id}
    */
    readonly userId: string;
}
export declare function dataDatabricksWorkspaceIamUsersV2UsersToTerraform(struct?: DataDatabricksWorkspaceIamUsersV2Users): any;
export declare function dataDatabricksWorkspaceIamUsersV2UsersToHclTerraform(struct?: DataDatabricksWorkspaceIamUsersV2Users): any;
export declare class DataDatabricksWorkspaceIamUsersV2UsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksWorkspaceIamUsersV2Users | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamUsersV2Users | undefined);
    get accountId(): string;
    get accountUserStatus(): string;
    get externalId(): string;
    private _fullName;
    get fullName(): DataDatabricksWorkspaceIamUsersV2UsersFullNameOutputReference;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamUsersV2UsersProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamUsersV2UsersProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamUsersV2UsersProviderConfig | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    get username(): string;
}
export declare class DataDatabricksWorkspaceIamUsersV2UsersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksWorkspaceIamUsersV2Users[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksWorkspaceIamUsersV2UsersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2 databricks_workspace_iam_users_v2}
*/
export declare class DataDatabricksWorkspaceIamUsersV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_users_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamUsersV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamUsersV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamUsersV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamUsersV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_users_v2 databricks_workspace_iam_users_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamUsersV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksWorkspaceIamUsersV2Config);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamUsersV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamUsersV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamUsersV2ProviderConfig | undefined;
    private _users;
    get users(): DataDatabricksWorkspaceIamUsersV2UsersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
