/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#aibi_dashboard_embedding_access_policy AccountSettingV2#aibi_dashboard_embedding_access_policy}
    */
    readonly aibiDashboardEmbeddingAccessPolicy?: AccountSettingV2AibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#aibi_dashboard_embedding_approved_domains AccountSettingV2#aibi_dashboard_embedding_approved_domains}
    */
    readonly aibiDashboardEmbeddingApprovedDomains?: AccountSettingV2AibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#allowed_apps_user_api_scopes AccountSettingV2#allowed_apps_user_api_scopes}
    */
    readonly allowedAppsUserApiScopes?: AccountSettingV2AllowedAppsUserApiScopes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#automatic_cluster_update_workspace AccountSettingV2#automatic_cluster_update_workspace}
    */
    readonly automaticClusterUpdateWorkspace?: AccountSettingV2AutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#boolean_val AccountSettingV2#boolean_val}
    */
    readonly booleanVal?: AccountSettingV2BooleanVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#collaboration_platform_connectivity AccountSettingV2#collaboration_platform_connectivity}
    */
    readonly collaborationPlatformConnectivity?: AccountSettingV2CollaborationPlatformConnectivity;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#effective_aibi_dashboard_embedding_access_policy AccountSettingV2#effective_aibi_dashboard_embedding_access_policy}
    */
    readonly effectiveAibiDashboardEmbeddingAccessPolicy?: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#effective_aibi_dashboard_embedding_approved_domains AccountSettingV2#effective_aibi_dashboard_embedding_approved_domains}
    */
    readonly effectiveAibiDashboardEmbeddingApprovedDomains?: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#effective_automatic_cluster_update_workspace AccountSettingV2#effective_automatic_cluster_update_workspace}
    */
    readonly effectiveAutomaticClusterUpdateWorkspace?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#effective_personal_compute AccountSettingV2#effective_personal_compute}
    */
    readonly effectivePersonalCompute?: AccountSettingV2EffectivePersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#effective_restrict_workspace_admins AccountSettingV2#effective_restrict_workspace_admins}
    */
    readonly effectiveRestrictWorkspaceAdmins?: AccountSettingV2EffectiveRestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#integer_val AccountSettingV2#integer_val}
    */
    readonly integerVal?: AccountSettingV2IntegerVal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#name AccountSettingV2#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#operational_email_custom_recipient AccountSettingV2#operational_email_custom_recipient}
    */
    readonly operationalEmailCustomRecipient?: AccountSettingV2OperationalEmailCustomRecipient;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#personal_compute AccountSettingV2#personal_compute}
    */
    readonly personalCompute?: AccountSettingV2PersonalCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#restrict_workspace_admins AccountSettingV2#restrict_workspace_admins}
    */
    readonly restrictWorkspaceAdmins?: AccountSettingV2RestrictWorkspaceAdmins;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#string_val AccountSettingV2#string_val}
    */
    readonly stringVal?: AccountSettingV2StringVal;
}
export interface AccountSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#access_policy_type AccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function accountSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function accountSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class AccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface AccountSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#approved_domains AccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function accountSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function accountSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class AccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface AccountSettingV2AllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#allowed_scopes AccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function accountSettingV2AllowedAppsUserApiScopesToTerraform(struct?: AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable): any;
export declare function accountSettingV2AllowedAppsUserApiScopesToHclTerraform(struct?: AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable): any;
export declare class AccountSettingV2AllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AllowedAppsUserApiScopes | cdktn.IResolvable | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#forced_for_compliance_mode AccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#unavailable_for_disabled_entitlement AccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#unavailable_for_non_enterprise_tier AccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#hours AccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#minutes AccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#day_of_week AccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#frequency AccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#window_start_time AccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#week_day_based_schedule AccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface AccountSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#can_toggle AccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#enabled AccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#enablement_details AccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#maintenance_window AccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#restart_even_if_no_updates_available AccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function accountSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class AccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2AutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2BooleanValToTerraform(struct?: AccountSettingV2BooleanVal | cdktn.IResolvable): any;
export declare function accountSettingV2BooleanValToHclTerraform(struct?: AccountSettingV2BooleanVal | cdktn.IResolvable): any;
export declare class AccountSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2BooleanVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2BooleanVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2CollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#connectivity AccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function accountSettingV2CollaborationPlatformConnectivityToTerraform(struct?: AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable): any;
export declare function accountSettingV2CollaborationPlatformConnectivityToHclTerraform(struct?: AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable): any;
export declare class AccountSettingV2CollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2CollaborationPlatformConnectivity | cdktn.IResolvable | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#access_policy_type AccountSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | cdktn.IResolvable | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#approved_domains AccountSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | cdktn.IResolvable | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface AccountSettingV2EffectiveAllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#allowed_scopes AccountSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function accountSettingV2EffectiveAllowedAppsUserApiScopesToTerraform(struct?: AccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare function accountSettingV2EffectiveAllowedAppsUserApiScopesToHclTerraform(struct?: AccountSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare class AccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined;
    set internalValue(value: AccountSettingV2EffectiveAllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#forced_for_compliance_mode AccountSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#unavailable_for_disabled_entitlement AccountSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#unavailable_for_non_enterprise_tier AccountSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#hours AccountSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#minutes AccountSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#day_of_week AccountSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#frequency AccountSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#window_start_time AccountSettingV2#window_start_time}
    */
    readonly windowStartTime?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#week_day_based_schedule AccountSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#can_toggle AccountSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#enabled AccountSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#enablement_details AccountSettingV2#enablement_details}
    */
    readonly enablementDetails?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#maintenance_window AccountSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#restart_even_if_no_updates_available AccountSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | cdktn.IResolvable | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function accountSettingV2EffectiveBooleanValToTerraform(struct?: AccountSettingV2EffectiveBooleanVal): any;
export declare function accountSettingV2EffectiveBooleanValToHclTerraform(struct?: AccountSettingV2EffectiveBooleanVal): any;
export declare class AccountSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: AccountSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface AccountSettingV2EffectiveCollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#connectivity AccountSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function accountSettingV2EffectiveCollaborationPlatformConnectivityToTerraform(struct?: AccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare function accountSettingV2EffectiveCollaborationPlatformConnectivityToHclTerraform(struct?: AccountSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare class AccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined;
    set internalValue(value: AccountSettingV2EffectiveCollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface AccountSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function accountSettingV2EffectiveIntegerValToTerraform(struct?: AccountSettingV2EffectiveIntegerVal): any;
export declare function accountSettingV2EffectiveIntegerValToHclTerraform(struct?: AccountSettingV2EffectiveIntegerVal): any;
export declare class AccountSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: AccountSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface AccountSettingV2EffectiveOperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#email AccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function accountSettingV2EffectiveOperationalEmailCustomRecipientToTerraform(struct?: AccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare function accountSettingV2EffectiveOperationalEmailCustomRecipientToHclTerraform(struct?: AccountSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare class AccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined;
    set internalValue(value: AccountSettingV2EffectiveOperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface AccountSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2EffectivePersonalComputeToTerraform(struct?: AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare function accountSettingV2EffectivePersonalComputeToHclTerraform(struct?: AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectivePersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#disable_gov_tag_creation AccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#status AccountSettingV2#status}
    */
    readonly status: string;
}
export declare function accountSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function accountSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class AccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2EffectiveRestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface AccountSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2EffectiveStringValToTerraform(struct?: AccountSettingV2EffectiveStringVal): any;
export declare function accountSettingV2EffectiveStringValToHclTerraform(struct?: AccountSettingV2EffectiveStringVal): any;
export declare class AccountSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2EffectiveStringVal | undefined;
    set internalValue(value: AccountSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: number;
}
export declare function accountSettingV2IntegerValToTerraform(struct?: AccountSettingV2IntegerVal | cdktn.IResolvable): any;
export declare function accountSettingV2IntegerValToHclTerraform(struct?: AccountSettingV2IntegerVal | cdktn.IResolvable): any;
export declare class AccountSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2IntegerVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2IntegerVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface AccountSettingV2OperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#email AccountSettingV2#email}
    */
    readonly email?: string;
}
export declare function accountSettingV2OperationalEmailCustomRecipientToTerraform(struct?: AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable): any;
export declare function accountSettingV2OperationalEmailCustomRecipientToHclTerraform(struct?: AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable): any;
export declare class AccountSettingV2OperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2OperationalEmailCustomRecipient | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface AccountSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2PersonalComputeToTerraform(struct?: AccountSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare function accountSettingV2PersonalComputeToHclTerraform(struct?: AccountSettingV2PersonalCompute | cdktn.IResolvable): any;
export declare class AccountSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2PersonalCompute | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2PersonalCompute | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AccountSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#disable_gov_tag_creation AccountSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#status AccountSettingV2#status}
    */
    readonly status: string;
}
export declare function accountSettingV2RestrictWorkspaceAdminsToTerraform(struct?: AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare function accountSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable): any;
export declare class AccountSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2RestrictWorkspaceAdmins | cdktn.IResolvable | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface AccountSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#value AccountSettingV2#value}
    */
    readonly value?: string;
}
export declare function accountSettingV2StringValToTerraform(struct?: AccountSettingV2StringVal | cdktn.IResolvable): any;
export declare function accountSettingV2StringValToHclTerraform(struct?: AccountSettingV2StringVal | cdktn.IResolvable): any;
export declare class AccountSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountSettingV2StringVal | cdktn.IResolvable | undefined;
    set internalValue(value: AccountSettingV2StringVal | cdktn.IResolvable | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2 databricks_account_setting_v2}
*/
export declare class AccountSettingV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_setting_v2";
    /**
    * Generates CDKTN code for importing a AccountSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountSettingV2 to import
    * @param importFromId The id of the existing AccountSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_setting_v2 databricks_account_setting_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountSettingV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: AccountSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): AccountSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    putAibiDashboardEmbeddingAccessPolicy(value: AccountSettingV2AibiDashboardEmbeddingAccessPolicy): void;
    resetAibiDashboardEmbeddingAccessPolicy(): void;
    get aibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | AccountSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): AccountSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    putAibiDashboardEmbeddingApprovedDomains(value: AccountSettingV2AibiDashboardEmbeddingApprovedDomains): void;
    resetAibiDashboardEmbeddingApprovedDomains(): void;
    get aibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | AccountSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    private _allowedAppsUserApiScopes;
    get allowedAppsUserApiScopes(): AccountSettingV2AllowedAppsUserApiScopesOutputReference;
    putAllowedAppsUserApiScopes(value: AccountSettingV2AllowedAppsUserApiScopes): void;
    resetAllowedAppsUserApiScopes(): void;
    get allowedAppsUserApiScopesInput(): cdktn.IResolvable | AccountSettingV2AllowedAppsUserApiScopes | undefined;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): AccountSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    putAutomaticClusterUpdateWorkspace(value: AccountSettingV2AutomaticClusterUpdateWorkspace): void;
    resetAutomaticClusterUpdateWorkspace(): void;
    get automaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | AccountSettingV2AutomaticClusterUpdateWorkspace | undefined;
    private _booleanVal;
    get booleanVal(): AccountSettingV2BooleanValOutputReference;
    putBooleanVal(value: AccountSettingV2BooleanVal): void;
    resetBooleanVal(): void;
    get booleanValInput(): cdktn.IResolvable | AccountSettingV2BooleanVal | undefined;
    private _collaborationPlatformConnectivity;
    get collaborationPlatformConnectivity(): AccountSettingV2CollaborationPlatformConnectivityOutputReference;
    putCollaborationPlatformConnectivity(value: AccountSettingV2CollaborationPlatformConnectivity): void;
    resetCollaborationPlatformConnectivity(): void;
    get collaborationPlatformConnectivityInput(): cdktn.IResolvable | AccountSettingV2CollaborationPlatformConnectivity | undefined;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    putEffectiveAibiDashboardEmbeddingAccessPolicy(value: AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): void;
    resetEffectiveAibiDashboardEmbeddingAccessPolicy(): void;
    get effectiveAibiDashboardEmbeddingAccessPolicyInput(): cdktn.IResolvable | AccountSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    putEffectiveAibiDashboardEmbeddingApprovedDomains(value: AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): void;
    resetEffectiveAibiDashboardEmbeddingApprovedDomains(): void;
    get effectiveAibiDashboardEmbeddingApprovedDomainsInput(): cdktn.IResolvable | AccountSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    private _effectiveAllowedAppsUserApiScopes;
    get effectiveAllowedAppsUserApiScopes(): AccountSettingV2EffectiveAllowedAppsUserApiScopesOutputReference;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): AccountSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    putEffectiveAutomaticClusterUpdateWorkspace(value: AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace): void;
    resetEffectiveAutomaticClusterUpdateWorkspace(): void;
    get effectiveAutomaticClusterUpdateWorkspaceInput(): cdktn.IResolvable | AccountSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): AccountSettingV2EffectiveBooleanValOutputReference;
    private _effectiveCollaborationPlatformConnectivity;
    get effectiveCollaborationPlatformConnectivity(): AccountSettingV2EffectiveCollaborationPlatformConnectivityOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): AccountSettingV2EffectiveIntegerValOutputReference;
    private _effectiveOperationalEmailCustomRecipient;
    get effectiveOperationalEmailCustomRecipient(): AccountSettingV2EffectiveOperationalEmailCustomRecipientOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): AccountSettingV2EffectivePersonalComputeOutputReference;
    putEffectivePersonalCompute(value: AccountSettingV2EffectivePersonalCompute): void;
    resetEffectivePersonalCompute(): void;
    get effectivePersonalComputeInput(): cdktn.IResolvable | AccountSettingV2EffectivePersonalCompute | undefined;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): AccountSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    putEffectiveRestrictWorkspaceAdmins(value: AccountSettingV2EffectiveRestrictWorkspaceAdmins): void;
    resetEffectiveRestrictWorkspaceAdmins(): void;
    get effectiveRestrictWorkspaceAdminsInput(): cdktn.IResolvable | AccountSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    private _effectiveStringVal;
    get effectiveStringVal(): AccountSettingV2EffectiveStringValOutputReference;
    private _integerVal;
    get integerVal(): AccountSettingV2IntegerValOutputReference;
    putIntegerVal(value: AccountSettingV2IntegerVal): void;
    resetIntegerVal(): void;
    get integerValInput(): cdktn.IResolvable | AccountSettingV2IntegerVal | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operationalEmailCustomRecipient;
    get operationalEmailCustomRecipient(): AccountSettingV2OperationalEmailCustomRecipientOutputReference;
    putOperationalEmailCustomRecipient(value: AccountSettingV2OperationalEmailCustomRecipient): void;
    resetOperationalEmailCustomRecipient(): void;
    get operationalEmailCustomRecipientInput(): cdktn.IResolvable | AccountSettingV2OperationalEmailCustomRecipient | undefined;
    private _personalCompute;
    get personalCompute(): AccountSettingV2PersonalComputeOutputReference;
    putPersonalCompute(value: AccountSettingV2PersonalCompute): void;
    resetPersonalCompute(): void;
    get personalComputeInput(): cdktn.IResolvable | AccountSettingV2PersonalCompute | undefined;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): AccountSettingV2RestrictWorkspaceAdminsOutputReference;
    putRestrictWorkspaceAdmins(value: AccountSettingV2RestrictWorkspaceAdmins): void;
    resetRestrictWorkspaceAdmins(): void;
    get restrictWorkspaceAdminsInput(): cdktn.IResolvable | AccountSettingV2RestrictWorkspaceAdmins | undefined;
    private _stringVal;
    get stringVal(): AccountSettingV2StringValOutputReference;
    putStringVal(value: AccountSettingV2StringVal): void;
    resetStringVal(): void;
    get stringValInput(): cdktn.IResolvable | AccountSettingV2StringVal | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
