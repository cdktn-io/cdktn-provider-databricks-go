/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountIamUserV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2#account_user_status AccountIamUserV2#account_user_status}
    */
    readonly accountUserStatus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2#external_id AccountIamUserV2#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2#full_name AccountIamUserV2#full_name}
    */
    readonly fullName: AccountIamUserV2FullName;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2#username AccountIamUserV2#username}
    */
    readonly username: string;
}
export interface AccountIamUserV2FullName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2#family_name AccountIamUserV2#family_name}
    */
    readonly familyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2#given_name AccountIamUserV2#given_name}
    */
    readonly givenName?: string;
}
export declare function accountIamUserV2FullNameToTerraform(struct?: AccountIamUserV2FullName | cdktn.IResolvable): any;
export declare function accountIamUserV2FullNameToHclTerraform(struct?: AccountIamUserV2FullName | cdktn.IResolvable): any;
export declare class AccountIamUserV2FullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccountIamUserV2FullName | cdktn.IResolvable | undefined;
    set internalValue(value: AccountIamUserV2FullName | cdktn.IResolvable | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    resetFamilyName(): void;
    get familyNameInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2 databricks_account_iam_user_v2}
*/
export declare class AccountIamUserV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_iam_user_v2";
    /**
    * Generates CDKTN code for importing a AccountIamUserV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountIamUserV2 to import
    * @param importFromId The id of the existing AccountIamUserV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountIamUserV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/account_iam_user_v2 databricks_account_iam_user_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountIamUserV2Config
    */
    constructor(scope: Construct, id: string, config: AccountIamUserV2Config);
    get accountId(): string;
    private _accountUserStatus?;
    get accountUserStatus(): string;
    set accountUserStatus(value: string);
    get accountUserStatusInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _fullName;
    get fullName(): AccountIamUserV2FullNameOutputReference;
    putFullName(value: AccountIamUserV2FullName): void;
    get fullNameInput(): cdktn.IResolvable | AccountIamUserV2FullName | undefined;
    get userId(): string;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
