/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MwsNccPrivateEndpointRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#domain_names MwsNccPrivateEndpointRule#domain_names}
    */
    readonly domainNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#enabled MwsNccPrivateEndpointRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#endpoint_service MwsNccPrivateEndpointRule#endpoint_service}
    */
    readonly endpointService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#group_id MwsNccPrivateEndpointRule#group_id}
    */
    readonly groupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#id MwsNccPrivateEndpointRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#network_connectivity_config_id MwsNccPrivateEndpointRule#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#resource_id MwsNccPrivateEndpointRule#resource_id}
    */
    readonly resourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#resource_names MwsNccPrivateEndpointRule#resource_names}
    */
    readonly resourceNames?: string[];
    /**
    * gcp_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#gcp_endpoint MwsNccPrivateEndpointRule#gcp_endpoint}
    */
    readonly gcpEndpoint?: MwsNccPrivateEndpointRuleGcpEndpoint;
}
export interface MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#endpoints MwsNccPrivateEndpointRule#endpoints}
    */
    readonly endpoints?: string[];
}
export declare function mwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpointsToTerraform(struct?: MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpointsOutputReference | MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints): any;
export declare function mwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpointsToHclTerraform(struct?: MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpointsOutputReference | MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints): any;
export declare class MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints | undefined;
    set internalValue(value: MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints | undefined);
    private _endpoints?;
    get endpoints(): string[];
    set endpoints(value: string[]);
    resetEndpoints(): void;
    get endpointsInput(): string[] | undefined;
}
export interface MwsNccPrivateEndpointRuleGcpEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#all_vpc_sc_services MwsNccPrivateEndpointRule#all_vpc_sc_services}
    */
    readonly allVpcScServices?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#service_attachment MwsNccPrivateEndpointRule#service_attachment}
    */
    readonly serviceAttachment?: string;
    /**
    * google_api_endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#google_api_endpoints MwsNccPrivateEndpointRule#google_api_endpoints}
    */
    readonly googleApiEndpoints?: MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints;
}
export declare function mwsNccPrivateEndpointRuleGcpEndpointToTerraform(struct?: MwsNccPrivateEndpointRuleGcpEndpointOutputReference | MwsNccPrivateEndpointRuleGcpEndpoint): any;
export declare function mwsNccPrivateEndpointRuleGcpEndpointToHclTerraform(struct?: MwsNccPrivateEndpointRuleGcpEndpointOutputReference | MwsNccPrivateEndpointRuleGcpEndpoint): any;
export declare class MwsNccPrivateEndpointRuleGcpEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsNccPrivateEndpointRuleGcpEndpoint | undefined;
    set internalValue(value: MwsNccPrivateEndpointRuleGcpEndpoint | undefined);
    private _allVpcScServices?;
    get allVpcScServices(): boolean | cdktn.IResolvable;
    set allVpcScServices(value: boolean | cdktn.IResolvable);
    resetAllVpcScServices(): void;
    get allVpcScServicesInput(): boolean | cdktn.IResolvable | undefined;
    get pscEndpointUri(): string;
    private _serviceAttachment?;
    get serviceAttachment(): string;
    set serviceAttachment(value: string);
    resetServiceAttachment(): void;
    get serviceAttachmentInput(): string | undefined;
    private _googleApiEndpoints;
    get googleApiEndpoints(): MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpointsOutputReference;
    putGoogleApiEndpoints(value: MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints): void;
    resetGoogleApiEndpoints(): void;
    get googleApiEndpointsInput(): MwsNccPrivateEndpointRuleGcpEndpointGoogleApiEndpoints | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule databricks_mws_ncc_private_endpoint_rule}
*/
export declare class MwsNccPrivateEndpointRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mws_ncc_private_endpoint_rule";
    /**
    * Generates CDKTN code for importing a MwsNccPrivateEndpointRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MwsNccPrivateEndpointRule to import
    * @param importFromId The id of the existing MwsNccPrivateEndpointRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MwsNccPrivateEndpointRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/mws_ncc_private_endpoint_rule databricks_mws_ncc_private_endpoint_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MwsNccPrivateEndpointRuleConfig
    */
    constructor(scope: Construct, id: string, config: MwsNccPrivateEndpointRuleConfig);
    get accountId(): string;
    get connectionState(): string;
    get creationTime(): number;
    get deactivated(): cdktn.IResolvable;
    get deactivatedAt(): number;
    private _domainNames?;
    get domainNames(): string[];
    set domainNames(value: string[]);
    resetDomainNames(): void;
    get domainNamesInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get endpointName(): string;
    private _endpointService?;
    get endpointService(): string;
    set endpointService(value: string);
    resetEndpointService(): void;
    get endpointServiceInput(): string | undefined;
    get errorMessage(): string;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    resetGroupId(): void;
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    get networkConnectivityConfigIdInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    resetResourceId(): void;
    get resourceIdInput(): string | undefined;
    private _resourceNames?;
    get resourceNames(): string[];
    set resourceNames(value: string[]);
    resetResourceNames(): void;
    get resourceNamesInput(): string[] | undefined;
    get ruleId(): string;
    get updatedTime(): number;
    get vpcEndpointId(): string;
    private _gcpEndpoint;
    get gcpEndpoint(): MwsNccPrivateEndpointRuleGcpEndpointOutputReference;
    putGcpEndpoint(value: MwsNccPrivateEndpointRuleGcpEndpoint): void;
    resetGcpEndpoint(): void;
    get gcpEndpointInput(): MwsNccPrivateEndpointRuleGcpEndpoint | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
