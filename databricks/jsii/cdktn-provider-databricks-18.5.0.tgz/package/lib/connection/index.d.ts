/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#comment Connection#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#connection_type Connection#connection_type}
    */
    readonly connectionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#id Connection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#name Connection#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#options Connection#options}
    */
    readonly options?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#owner Connection#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#properties Connection#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#read_only Connection#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * environment_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#environment_settings Connection#environment_settings}
    */
    readonly environmentSettings?: ConnectionEnvironmentSettings;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#provider_config Connection#provider_config}
    */
    readonly providerConfig?: ConnectionProviderConfig;
}
export interface ConnectionProvisioningInfo {
}
export declare function connectionProvisioningInfoToTerraform(struct?: ConnectionProvisioningInfo): any;
export declare function connectionProvisioningInfoToHclTerraform(struct?: ConnectionProvisioningInfo): any;
export declare class ConnectionProvisioningInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConnectionProvisioningInfo | undefined;
    set internalValue(value: ConnectionProvisioningInfo | undefined);
    get state(): string;
}
export declare class ConnectionProvisioningInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConnectionProvisioningInfoOutputReference;
}
export interface ConnectionEnvironmentSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#environment_version Connection#environment_version}
    */
    readonly environmentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#java_dependencies Connection#java_dependencies}
    */
    readonly javaDependencies?: string[];
}
export declare function connectionEnvironmentSettingsToTerraform(struct?: ConnectionEnvironmentSettingsOutputReference | ConnectionEnvironmentSettings): any;
export declare function connectionEnvironmentSettingsToHclTerraform(struct?: ConnectionEnvironmentSettingsOutputReference | ConnectionEnvironmentSettings): any;
export declare class ConnectionEnvironmentSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectionEnvironmentSettings | undefined;
    set internalValue(value: ConnectionEnvironmentSettings | undefined);
    private _environmentVersion?;
    get environmentVersion(): string;
    set environmentVersion(value: string);
    resetEnvironmentVersion(): void;
    get environmentVersionInput(): string | undefined;
    private _javaDependencies?;
    get javaDependencies(): string[];
    set javaDependencies(value: string[]);
    resetJavaDependencies(): void;
    get javaDependenciesInput(): string[] | undefined;
}
export interface ConnectionProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#workspace_id Connection#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function connectionProviderConfigToTerraform(struct?: ConnectionProviderConfigOutputReference | ConnectionProviderConfig): any;
export declare function connectionProviderConfigToHclTerraform(struct?: ConnectionProviderConfigOutputReference | ConnectionProviderConfig): any;
export declare class ConnectionProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConnectionProviderConfig | undefined;
    set internalValue(value: ConnectionProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection databricks_connection}
*/
export declare class Connection extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_connection";
    /**
    * Generates CDKTN code for importing a Connection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Connection to import
    * @param importFromId The id of the existing Connection that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Connection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/connection databricks_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConnectionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ConnectionConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get connectionId(): string;
    private _connectionType?;
    get connectionType(): string;
    set connectionType(value: string);
    resetConnectionType(): void;
    get connectionTypeInput(): string | undefined;
    get createdAt(): number;
    get createdBy(): string;
    get credentialType(): string;
    get fullName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _provisioningInfo;
    get provisioningInfo(): ConnectionProvisioningInfoList;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    get securableType(): string;
    get updatedAt(): number;
    get updatedBy(): string;
    get url(): string;
    private _environmentSettings;
    get environmentSettings(): ConnectionEnvironmentSettingsOutputReference;
    putEnvironmentSettings(value: ConnectionEnvironmentSettings): void;
    resetEnvironmentSettings(): void;
    get environmentSettingsInput(): ConnectionEnvironmentSettings | undefined;
    private _providerConfig;
    get providerConfig(): ConnectionProviderConfigOutputReference;
    putProviderConfig(value: ConnectionProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ConnectionProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
