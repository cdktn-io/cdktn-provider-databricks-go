/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamGroupsV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#filter DataDatabricksWorkspaceIamGroupsV2#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#page_size DataDatabricksWorkspaceIamGroupsV2#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#provider_config DataDatabricksWorkspaceIamGroupsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamGroupsV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#workspace_id DataDatabricksWorkspaceIamGroupsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamGroupsV2GroupsProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamGroupsV2GroupsProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamGroupsV2Groups {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#group_id DataDatabricksWorkspaceIamGroupsV2#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#provider_config DataDatabricksWorkspaceIamGroupsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig;
}
export declare function dataDatabricksWorkspaceIamGroupsV2GroupsToTerraform(struct?: DataDatabricksWorkspaceIamGroupsV2Groups): any;
export declare function dataDatabricksWorkspaceIamGroupsV2GroupsToHclTerraform(struct?: DataDatabricksWorkspaceIamGroupsV2Groups): any;
export declare class DataDatabricksWorkspaceIamGroupsV2GroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksWorkspaceIamGroupsV2Groups | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamGroupsV2Groups | undefined);
    get accountId(): string;
    get externalId(): string;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    get groupName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamGroupsV2GroupsProviderConfig | undefined;
}
export declare class DataDatabricksWorkspaceIamGroupsV2GroupsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksWorkspaceIamGroupsV2Groups[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksWorkspaceIamGroupsV2GroupsOutputReference;
}
export interface DataDatabricksWorkspaceIamGroupsV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#workspace_id DataDatabricksWorkspaceIamGroupsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamGroupsV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamGroupsV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamGroupsV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamGroupsV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamGroupsV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamGroupsV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamGroupsV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2 databricks_workspace_iam_groups_v2}
*/
export declare class DataDatabricksWorkspaceIamGroupsV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_groups_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamGroupsV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamGroupsV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamGroupsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamGroupsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/workspace_iam_groups_v2 databricks_workspace_iam_groups_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamGroupsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksWorkspaceIamGroupsV2Config);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _groups;
    get groups(): DataDatabricksWorkspaceIamGroupsV2GroupsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamGroupsV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamGroupsV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamGroupsV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
