/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiGatewayModelProviderServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#name DataDatabricksAiGatewayModelProviderService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#provider_config DataDatabricksAiGatewayModelProviderService#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayModelProviderServiceProviderConfig;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#access_key_id DataDatabricksAiGatewayModelProviderService#access_key_id}
    */
    readonly accessKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#secret_access_key DataDatabricksAiGatewayModelProviderService#secret_access_key}
    */
    readonly secretAccessKey?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    resetAccessKeyId(): void;
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey;
    get secretAccessKey(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyOutputReference;
    putSecretAccessKey(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey): void;
    resetSecretAccessKey(): void;
    get secretAccessKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#name DataDatabricksAiGatewayModelProviderService#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#aws_access_key DataDatabricksAiGatewayModelProviderService#aws_access_key}
    */
    readonly awsAccessKey?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#region DataDatabricksAiGatewayModelProviderService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#service_credential DataDatabricksAiGatewayModelProviderService#service_credential}
    */
    readonly serviceCredential?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable | undefined);
    private _awsAccessKey;
    get awsAccessKey(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyOutputReference;
    putAwsAccessKey(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey): void;
    resetAwsAccessKey(): void;
    get awsAccessKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceCredential;
    get serviceCredential(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialOutputReference;
    putServiceCredential(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#direct DataDatabricksAiGatewayModelProviderService#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#api_key DataDatabricksAiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectApiKey | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plan_type DataDatabricksAiGatewayModelProviderService#plan_type}
    */
    readonly planType?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayedToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayedToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable | undefined);
    private _planType?;
    get planType(): string;
    set planType(value: string);
    resetPlanType(): void;
    get planTypeInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAnthropic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#direct DataDatabricksAiGatewayModelProviderService#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#relayed DataDatabricksAiGatewayModelProviderService#relayed}
    */
    readonly relayed?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAnthropicToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAnthropicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAnthropicDirect | undefined;
    private _relayed;
    get relayed(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayedOutputReference;
    putRelayed(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed): void;
    resetRelayed(): void;
    get relayedInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAnthropicRelayed | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#client_id DataDatabricksAiGatewayModelProviderService#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#client_secret DataDatabricksAiGatewayModelProviderService#client_secret}
    */
    readonly clientSecret?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#tenant_id DataDatabricksAiGatewayModelProviderService#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret;
    get clientSecret(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretOutputReference;
    putClientSecret(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret): void;
    resetClientSecret(): void;
    get clientSecretInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#name DataDatabricksAiGatewayModelProviderService#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#api_key DataDatabricksAiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#base_url DataDatabricksAiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#entra_service_principal DataDatabricksAiGatewayModelProviderService#entra_service_principal}
    */
    readonly entraServicePrincipal?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#service_credential DataDatabricksAiGatewayModelProviderService#service_credential}
    */
    readonly serviceCredential?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _entraServicePrincipal;
    get entraServicePrincipal(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalOutputReference;
    putEntraServicePrincipal(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal): void;
    resetEntraServicePrincipal(): void;
    get entraServicePrincipalInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | undefined;
    private _serviceCredential;
    get serviceCredential(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialOutputReference;
    putServiceCredential(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#direct DataDatabricksAiGatewayModelProviderService#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#api_key DataDatabricksAiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#base_url DataDatabricksAiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigCustomDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigCustomDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigCustom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#direct DataDatabricksAiGatewayModelProviderService#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigCustomToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigCustomToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServiceConfigCustomDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigCustomDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#api_key DataDatabricksAiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#project_id DataDatabricksAiGatewayModelProviderService#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#region DataDatabricksAiGatewayModelProviderService#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#direct DataDatabricksAiGatewayModelProviderService#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#disabled DataDatabricksAiGatewayModelProviderService#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#parent DataDatabricksAiGatewayModelProviderService#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#table_name_prefix DataDatabricksAiGatewayModelProviderService#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigInferenceTableToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigInferenceTableToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigInferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get table(): string;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#client_id DataDatabricksAiGatewayModelProviderService#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#client_secret DataDatabricksAiGatewayModelProviderService#client_secret}
    */
    readonly clientSecret?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#tenant_id DataDatabricksAiGatewayModelProviderService#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret;
    get clientSecret(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretOutputReference;
    putClientSecret(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret): void;
    resetClientSecret(): void;
    get clientSecretInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#name DataDatabricksAiGatewayModelProviderService#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#api_key DataDatabricksAiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#base_url DataDatabricksAiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#entra_service_principal DataDatabricksAiGatewayModelProviderService#entra_service_principal}
    */
    readonly entraServicePrincipal?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#service_credential DataDatabricksAiGatewayModelProviderService#service_credential}
    */
    readonly serviceCredential?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _entraServicePrincipal;
    get entraServicePrincipal(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalOutputReference;
    putEntraServicePrincipal(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal): void;
    resetEntraServicePrincipal(): void;
    get entraServicePrincipalInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | undefined;
    private _serviceCredential;
    get serviceCredential(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialOutputReference;
    putServiceCredential(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#direct DataDatabricksAiGatewayModelProviderService#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#plaintext DataDatabricksAiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#api_key DataDatabricksAiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#base_url DataDatabricksAiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#organization DataDatabricksAiGatewayModelProviderService#organization}
    */
    readonly organization?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigOpenai {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#direct DataDatabricksAiGatewayModelProviderService#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigOpenaiToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigOpenaiToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigOpenaiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigOpenaiDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#key DataDatabricksAiGatewayModelProviderService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#principal DataDatabricksAiGatewayModelProviderService#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#renewal_period DataDatabricksAiGatewayModelProviderService#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#request_tag_key DataDatabricksAiGatewayModelProviderService#request_tag_key}
    */
    readonly requestTagKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#request_tag_value DataDatabricksAiGatewayModelProviderService#request_tag_value}
    */
    readonly requestTagValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#requests DataDatabricksAiGatewayModelProviderService#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#tokens DataDatabricksAiGatewayModelProviderService#tokens}
    */
    readonly tokens?: number;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigRateLimitsToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigRateLimitsToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requestTagKey?;
    get requestTagKey(): string;
    set requestTagKey(value: string);
    resetRequestTagKey(): void;
    get requestTagKeyInput(): string | undefined;
    private _requestTagValue?;
    get requestTagValue(): string;
    set requestTagValue(value: string);
    resetRequestTagValue(): void;
    get requestTagValueInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelProviderServiceConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelProviderServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelProviderServiceConfigRateLimitsOutputReference;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#model DataDatabricksAiGatewayModelProviderService#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#native_api_types DataDatabricksAiGatewayModelProviderService#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigTargetsToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigTargetsToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export declare class DataDatabricksAiGatewayModelProviderServiceConfigTargetsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelProviderServiceConfigTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelProviderServiceConfigTargetsOutputReference;
}
export interface DataDatabricksAiGatewayModelProviderServiceConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#allow_all_targets DataDatabricksAiGatewayModelProviderService#allow_all_targets}
    */
    readonly allowAllTargets?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#amazon_bedrock DataDatabricksAiGatewayModelProviderService#amazon_bedrock}
    */
    readonly amazonBedrock?: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#anthropic DataDatabricksAiGatewayModelProviderService#anthropic}
    */
    readonly anthropic?: DataDatabricksAiGatewayModelProviderServiceConfigAnthropic;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#azure_openai DataDatabricksAiGatewayModelProviderService#azure_openai}
    */
    readonly azureOpenai?: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#custom DataDatabricksAiGatewayModelProviderService#custom}
    */
    readonly custom?: DataDatabricksAiGatewayModelProviderServiceConfigCustom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#forward_headers DataDatabricksAiGatewayModelProviderService#forward_headers}
    */
    readonly forwardHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#forward_query_parameters DataDatabricksAiGatewayModelProviderService#forward_query_parameters}
    */
    readonly forwardQueryParameters?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#forward_unmanaged_paths DataDatabricksAiGatewayModelProviderService#forward_unmanaged_paths}
    */
    readonly forwardUnmanagedPaths?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#gemini_enterprise DataDatabricksAiGatewayModelProviderService#gemini_enterprise}
    */
    readonly geminiEnterprise?: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#inference_table DataDatabricksAiGatewayModelProviderService#inference_table}
    */
    readonly inferenceTable?: DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#microsoft_foundry DataDatabricksAiGatewayModelProviderService#microsoft_foundry}
    */
    readonly microsoftFoundry?: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#openai DataDatabricksAiGatewayModelProviderService#openai}
    */
    readonly openai?: DataDatabricksAiGatewayModelProviderServiceConfigOpenai;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#provider_type DataDatabricksAiGatewayModelProviderService#provider_type}
    */
    readonly providerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#rate_limits DataDatabricksAiGatewayModelProviderService#rate_limits}
    */
    readonly rateLimits?: DataDatabricksAiGatewayModelProviderServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#targets DataDatabricksAiGatewayModelProviderService#targets}
    */
    readonly targets?: DataDatabricksAiGatewayModelProviderServiceConfigTargets[] | cdktn.IResolvable;
}
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigA): any;
export declare function dataDatabricksAiGatewayModelProviderServiceConfigAToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceConfigA): any;
export declare class DataDatabricksAiGatewayModelProviderServiceConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceConfigA | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceConfigA | undefined);
    private _allowAllTargets?;
    get allowAllTargets(): boolean | cdktn.IResolvable;
    set allowAllTargets(value: boolean | cdktn.IResolvable);
    resetAllowAllTargets(): void;
    get allowAllTargetsInput(): boolean | cdktn.IResolvable | undefined;
    private _amazonBedrock;
    get amazonBedrock(): DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrockOutputReference;
    putAmazonBedrock(value: DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock): void;
    resetAmazonBedrock(): void;
    get amazonBedrockInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAmazonBedrock | undefined;
    private _anthropic;
    get anthropic(): DataDatabricksAiGatewayModelProviderServiceConfigAnthropicOutputReference;
    putAnthropic(value: DataDatabricksAiGatewayModelProviderServiceConfigAnthropic): void;
    resetAnthropic(): void;
    get anthropicInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAnthropic | undefined;
    private _azureOpenai;
    get azureOpenai(): DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenaiOutputReference;
    putAzureOpenai(value: DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai): void;
    resetAzureOpenai(): void;
    get azureOpenaiInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigAzureOpenai | undefined;
    private _custom;
    get custom(): DataDatabricksAiGatewayModelProviderServiceConfigCustomOutputReference;
    putCustom(value: DataDatabricksAiGatewayModelProviderServiceConfigCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigCustom | undefined;
    private _forwardHeaders?;
    get forwardHeaders(): boolean | cdktn.IResolvable;
    set forwardHeaders(value: boolean | cdktn.IResolvable);
    resetForwardHeaders(): void;
    get forwardHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardQueryParameters?;
    get forwardQueryParameters(): boolean | cdktn.IResolvable;
    set forwardQueryParameters(value: boolean | cdktn.IResolvable);
    resetForwardQueryParameters(): void;
    get forwardQueryParametersInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardUnmanagedPaths?;
    get forwardUnmanagedPaths(): boolean | cdktn.IResolvable;
    set forwardUnmanagedPaths(value: boolean | cdktn.IResolvable);
    resetForwardUnmanagedPaths(): void;
    get forwardUnmanagedPathsInput(): boolean | cdktn.IResolvable | undefined;
    private _geminiEnterprise;
    get geminiEnterprise(): DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterpriseOutputReference;
    putGeminiEnterprise(value: DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise): void;
    resetGeminiEnterprise(): void;
    get geminiEnterpriseInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigGeminiEnterprise | undefined;
    private _inferenceTable;
    get inferenceTable(): DataDatabricksAiGatewayModelProviderServiceConfigInferenceTableOutputReference;
    putInferenceTable(value: DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable): void;
    resetInferenceTable(): void;
    get inferenceTableInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigInferenceTable | undefined;
    private _microsoftFoundry;
    get microsoftFoundry(): DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundryOutputReference;
    putMicrosoftFoundry(value: DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry): void;
    resetMicrosoftFoundry(): void;
    get microsoftFoundryInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigMicrosoftFoundry | undefined;
    private _openai;
    get openai(): DataDatabricksAiGatewayModelProviderServiceConfigOpenaiOutputReference;
    putOpenai(value: DataDatabricksAiGatewayModelProviderServiceConfigOpenai): void;
    resetOpenai(): void;
    get openaiInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigOpenai | undefined;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    resetProviderType(): void;
    get providerTypeInput(): string | undefined;
    private _rateLimits;
    get rateLimits(): DataDatabricksAiGatewayModelProviderServiceConfigRateLimitsList;
    putRateLimits(value: DataDatabricksAiGatewayModelProviderServiceConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigRateLimits[] | undefined;
    private _targets;
    get targets(): DataDatabricksAiGatewayModelProviderServiceConfigTargetsList;
    putTargets(value: DataDatabricksAiGatewayModelProviderServiceConfigTargets[] | cdktn.IResolvable): void;
    resetTargets(): void;
    get targetsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceConfigTargets[] | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServiceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#workspace_id DataDatabricksAiGatewayModelProviderService#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServiceProviderConfigToTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServiceProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServiceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service databricks_ai_gateway_model_provider_service}
*/
export declare class DataDatabricksAiGatewayModelProviderService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_gateway_model_provider_service";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiGatewayModelProviderService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiGatewayModelProviderService to import
    * @param importFromId The id of the existing DataDatabricksAiGatewayModelProviderService that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiGatewayModelProviderService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/data-sources/ai_gateway_model_provider_service databricks_ai_gateway_model_provider_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiGatewayModelProviderServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAiGatewayModelProviderServiceConfig);
    get comment(): string;
    private _config;
    get config(): DataDatabricksAiGatewayModelProviderServiceConfigAOutputReference;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get owner(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayModelProviderServiceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayModelProviderServiceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServiceProviderConfig | undefined;
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
