/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresDataApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#parent PostgresDataApi#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#provider_config PostgresDataApi#provider_config}
    */
    readonly providerConfig?: PostgresDataApiProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#spec PostgresDataApi#spec}
    */
    readonly spec?: PostgresDataApiSpec;
}
export interface PostgresDataApiProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#workspace_id PostgresDataApi#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresDataApiProviderConfigToTerraform(struct?: PostgresDataApiProviderConfig | cdktn.IResolvable): any;
export declare function postgresDataApiProviderConfigToHclTerraform(struct?: PostgresDataApiProviderConfig | cdktn.IResolvable): any;
export declare class PostgresDataApiProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresDataApiProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresDataApiProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface PostgresDataApiSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#db_aggregates_enabled PostgresDataApi#db_aggregates_enabled}
    */
    readonly dbAggregatesEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#db_extra_search_path PostgresDataApi#db_extra_search_path}
    */
    readonly dbExtraSearchPath?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#db_max_rows PostgresDataApi#db_max_rows}
    */
    readonly dbMaxRows?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#db_schemas PostgresDataApi#db_schemas}
    */
    readonly dbSchemas?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#jwt_cache_max_lifetime PostgresDataApi#jwt_cache_max_lifetime}
    */
    readonly jwtCacheMaxLifetime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#jwt_role_claim_key PostgresDataApi#jwt_role_claim_key}
    */
    readonly jwtRoleClaimKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#openapi_mode PostgresDataApi#openapi_mode}
    */
    readonly openapiMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#server_cors_allowed_origins PostgresDataApi#server_cors_allowed_origins}
    */
    readonly serverCorsAllowedOrigins?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#server_timing_enabled PostgresDataApi#server_timing_enabled}
    */
    readonly serverTimingEnabled?: boolean | cdktn.IResolvable;
}
export declare function postgresDataApiSpecToTerraform(struct?: PostgresDataApiSpec | cdktn.IResolvable): any;
export declare function postgresDataApiSpecToHclTerraform(struct?: PostgresDataApiSpec | cdktn.IResolvable): any;
export declare class PostgresDataApiSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresDataApiSpec | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresDataApiSpec | cdktn.IResolvable | undefined);
    private _dbAggregatesEnabled?;
    get dbAggregatesEnabled(): boolean | cdktn.IResolvable;
    set dbAggregatesEnabled(value: boolean | cdktn.IResolvable);
    resetDbAggregatesEnabled(): void;
    get dbAggregatesEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _dbExtraSearchPath?;
    get dbExtraSearchPath(): string[];
    set dbExtraSearchPath(value: string[]);
    resetDbExtraSearchPath(): void;
    get dbExtraSearchPathInput(): string[] | undefined;
    private _dbMaxRows?;
    get dbMaxRows(): number;
    set dbMaxRows(value: number);
    resetDbMaxRows(): void;
    get dbMaxRowsInput(): number | undefined;
    private _dbSchemas?;
    get dbSchemas(): string[];
    set dbSchemas(value: string[]);
    resetDbSchemas(): void;
    get dbSchemasInput(): string[] | undefined;
    private _jwtCacheMaxLifetime?;
    get jwtCacheMaxLifetime(): string;
    set jwtCacheMaxLifetime(value: string);
    resetJwtCacheMaxLifetime(): void;
    get jwtCacheMaxLifetimeInput(): string | undefined;
    private _jwtRoleClaimKey?;
    get jwtRoleClaimKey(): string;
    set jwtRoleClaimKey(value: string);
    resetJwtRoleClaimKey(): void;
    get jwtRoleClaimKeyInput(): string | undefined;
    private _openapiMode?;
    get openapiMode(): string;
    set openapiMode(value: string);
    resetOpenapiMode(): void;
    get openapiModeInput(): string | undefined;
    private _serverCorsAllowedOrigins?;
    get serverCorsAllowedOrigins(): string[];
    set serverCorsAllowedOrigins(value: string[]);
    resetServerCorsAllowedOrigins(): void;
    get serverCorsAllowedOriginsInput(): string[] | undefined;
    private _serverTimingEnabled?;
    get serverTimingEnabled(): boolean | cdktn.IResolvable;
    set serverTimingEnabled(value: boolean | cdktn.IResolvable);
    resetServerTimingEnabled(): void;
    get serverTimingEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface PostgresDataApiStatus {
}
export declare function postgresDataApiStatusToTerraform(struct?: PostgresDataApiStatus): any;
export declare function postgresDataApiStatusToHclTerraform(struct?: PostgresDataApiStatus): any;
export declare class PostgresDataApiStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresDataApiStatus | undefined;
    set internalValue(value: PostgresDataApiStatus | undefined);
    get availableSchemas(): string[];
    get dbAggregatesEnabled(): cdktn.IResolvable;
    get dbExtraSearchPath(): string[];
    get dbMaxRows(): number;
    get dbSchemas(): string[];
    get jwtCacheMaxLifetime(): string;
    get jwtRoleClaimKey(): string;
    get openapiMode(): string;
    get serverCorsAllowedOrigins(): string[];
    get serverTimingEnabled(): cdktn.IResolvable;
    get url(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api databricks_postgres_data_api}
*/
export declare class PostgresDataApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_data_api";
    /**
    * Generates CDKTN code for importing a PostgresDataApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresDataApi to import
    * @param importFromId The id of the existing PostgresDataApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresDataApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.130.0/docs/resources/postgres_data_api databricks_postgres_data_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresDataApiConfig
    */
    constructor(scope: Construct, id: string, config: PostgresDataApiConfig);
    get createTime(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresDataApiProviderConfigOutputReference;
    putProviderConfig(value: PostgresDataApiProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresDataApiProviderConfig | undefined;
    private _spec;
    get spec(): PostgresDataApiSpecOutputReference;
    putSpec(value: PostgresDataApiSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | PostgresDataApiSpec | undefined;
    private _status;
    get status(): PostgresDataApiStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
