/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchBuiltinParserVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version#name DataDatabricksLakewatchBuiltinParserVersion#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version#provider_config DataDatabricksLakewatchBuiltinParserVersion#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchBuiltinParserVersionProviderConfig;
}
export interface DataDatabricksLakewatchBuiltinParserVersionProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version#workspace_id DataDatabricksLakewatchBuiltinParserVersion#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchBuiltinParserVersionProviderConfigToTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchBuiltinParserVersionProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchBuiltinParserVersionProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchBuiltinParserVersionProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserVersionProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchBuiltinParserVersionTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version#key DataDatabricksLakewatchBuiltinParserVersion#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version#value DataDatabricksLakewatchBuiltinParserVersion#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksLakewatchBuiltinParserVersionTagsToTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionTags): any;
export declare function dataDatabricksLakewatchBuiltinParserVersionTagsToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionTags): any;
export declare class DataDatabricksLakewatchBuiltinParserVersionTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchBuiltinParserVersionTags | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserVersionTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksLakewatchBuiltinParserVersionTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchBuiltinParserVersionTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchBuiltinParserVersionTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version databricks_lakewatch_builtin_parser_version}
*/
export declare class DataDatabricksLakewatchBuiltinParserVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_builtin_parser_version";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchBuiltinParserVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchBuiltinParserVersion to import
    * @param importFromId The id of the existing DataDatabricksLakewatchBuiltinParserVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchBuiltinParserVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_version databricks_lakewatch_builtin_parser_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchBuiltinParserVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchBuiltinParserVersionConfig);
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parserName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchBuiltinParserVersionProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchBuiltinParserVersionProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchBuiltinParserVersionProviderConfig | undefined;
    get spec(): string;
    private _tags;
    get tags(): DataDatabricksLakewatchBuiltinParserVersionTagsList;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
