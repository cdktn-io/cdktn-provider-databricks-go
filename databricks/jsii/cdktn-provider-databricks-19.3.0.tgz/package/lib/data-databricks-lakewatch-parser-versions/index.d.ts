/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchParserVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#page_size DataDatabricksLakewatchParserVersions#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#parent DataDatabricksLakewatchParserVersions#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#provider_config DataDatabricksLakewatchParserVersions#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchParserVersionsProviderConfig;
}
export interface DataDatabricksLakewatchParserVersionsParserVersionsCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#display_name DataDatabricksLakewatchParserVersions#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#email DataDatabricksLakewatchParserVersions#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#id DataDatabricksLakewatchParserVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#principal_type DataDatabricksLakewatchParserVersions#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchParserVersionsParserVersionsCreatedByToTerraform(struct?: DataDatabricksLakewatchParserVersionsParserVersionsCreatedBy): any;
export declare function dataDatabricksLakewatchParserVersionsParserVersionsCreatedByToHclTerraform(struct?: DataDatabricksLakewatchParserVersionsParserVersionsCreatedBy): any;
export declare class DataDatabricksLakewatchParserVersionsParserVersionsCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserVersionsParserVersionsCreatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchParserVersionsParserVersionsCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#workspace_id DataDatabricksLakewatchParserVersions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchParserVersionsParserVersionsProviderConfigToTerraform(struct?: DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchParserVersionsParserVersionsProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchParserVersionsParserVersionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchParserVersionsParserVersions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#name DataDatabricksLakewatchParserVersions#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#provider_config DataDatabricksLakewatchParserVersions#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig;
}
export declare function dataDatabricksLakewatchParserVersionsParserVersionsToTerraform(struct?: DataDatabricksLakewatchParserVersionsParserVersions): any;
export declare function dataDatabricksLakewatchParserVersionsParserVersionsToHclTerraform(struct?: DataDatabricksLakewatchParserVersionsParserVersions): any;
export declare class DataDatabricksLakewatchParserVersionsParserVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchParserVersionsParserVersions | undefined;
    set internalValue(value: DataDatabricksLakewatchParserVersionsParserVersions | undefined);
    get createTime(): string;
    private _createdBy;
    get createdBy(): DataDatabricksLakewatchParserVersionsParserVersionsCreatedByOutputReference;
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parserName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchParserVersionsParserVersionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchParserVersionsParserVersionsProviderConfig | undefined;
    get spec(): string;
    get version(): number;
}
export declare class DataDatabricksLakewatchParserVersionsParserVersionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchParserVersionsParserVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchParserVersionsParserVersionsOutputReference;
}
export interface DataDatabricksLakewatchParserVersionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#workspace_id DataDatabricksLakewatchParserVersions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchParserVersionsProviderConfigToTerraform(struct?: DataDatabricksLakewatchParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchParserVersionsProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchParserVersionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserVersionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchParserVersionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions databricks_lakewatch_parser_versions}
*/
export declare class DataDatabricksLakewatchParserVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_parser_versions";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchParserVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchParserVersions to import
    * @param importFromId The id of the existing DataDatabricksLakewatchParserVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchParserVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_versions databricks_lakewatch_parser_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchParserVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchParserVersionsConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _parserVersions;
    get parserVersions(): DataDatabricksLakewatchParserVersionsParserVersionsList;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchParserVersionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchParserVersionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchParserVersionsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
