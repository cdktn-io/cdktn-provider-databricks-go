/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchParserVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#name DataDatabricksLakewatchParserVersion#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#provider_config DataDatabricksLakewatchParserVersion#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchParserVersionProviderConfig;
}
export interface DataDatabricksLakewatchParserVersionCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#display_name DataDatabricksLakewatchParserVersion#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#email DataDatabricksLakewatchParserVersion#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#id DataDatabricksLakewatchParserVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#principal_type DataDatabricksLakewatchParserVersion#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchParserVersionCreatedByToTerraform(struct?: DataDatabricksLakewatchParserVersionCreatedBy): any;
export declare function dataDatabricksLakewatchParserVersionCreatedByToHclTerraform(struct?: DataDatabricksLakewatchParserVersionCreatedBy): any;
export declare class DataDatabricksLakewatchParserVersionCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserVersionCreatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchParserVersionCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchParserVersionProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#workspace_id DataDatabricksLakewatchParserVersion#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchParserVersionProviderConfigToTerraform(struct?: DataDatabricksLakewatchParserVersionProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchParserVersionProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchParserVersionProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchParserVersionProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserVersionProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchParserVersionProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version databricks_lakewatch_parser_version}
*/
export declare class DataDatabricksLakewatchParserVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_parser_version";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchParserVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchParserVersion to import
    * @param importFromId The id of the existing DataDatabricksLakewatchParserVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchParserVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser_version databricks_lakewatch_parser_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchParserVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchParserVersionConfig);
    get createTime(): string;
    private _createdBy;
    get createdBy(): DataDatabricksLakewatchParserVersionCreatedByOutputReference;
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parserName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchParserVersionProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchParserVersionProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchParserVersionProviderConfig | undefined;
    get spec(): string;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
