/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSandboxConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#name DataDatabricksSandbox#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#provider_config DataDatabricksSandbox#provider_config}
    */
    readonly providerConfig?: DataDatabricksSandboxProviderConfig;
}
export interface DataDatabricksSandboxMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#custom_tags DataDatabricksSandbox#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksSandboxMetadataToTerraform(struct?: DataDatabricksSandboxMetadata): any;
export declare function dataDatabricksSandboxMetadataToHclTerraform(struct?: DataDatabricksSandboxMetadata): any;
export declare class DataDatabricksSandboxMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxMetadata | undefined;
    set internalValue(value: DataDatabricksSandboxMetadata | undefined);
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksSandboxProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#workspace_id DataDatabricksSandbox#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSandboxProviderConfigToTerraform(struct?: DataDatabricksSandboxProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSandboxProviderConfigToHclTerraform(struct?: DataDatabricksSandboxProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSandboxProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSandboxProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSandboxSpecCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#inactivity_timeout DataDatabricksSandbox#inactivity_timeout}
    */
    readonly inactivityTimeout?: string;
}
export declare function dataDatabricksSandboxSpecComputeToTerraform(struct?: DataDatabricksSandboxSpecCompute | cdktn.IResolvable): any;
export declare function dataDatabricksSandboxSpecComputeToHclTerraform(struct?: DataDatabricksSandboxSpecCompute | cdktn.IResolvable): any;
export declare class DataDatabricksSandboxSpecComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxSpecCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSandboxSpecCompute | cdktn.IResolvable | undefined);
    private _inactivityTimeout?;
    get inactivityTimeout(): string;
    set inactivityTimeout(value: string);
    resetInactivityTimeout(): void;
    get inactivityTimeoutInput(): string | undefined;
}
export interface DataDatabricksSandboxSpecEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#image_uri DataDatabricksSandbox#image_uri}
    */
    readonly imageUri?: string;
}
export declare function dataDatabricksSandboxSpecEnvironmentToTerraform(struct?: DataDatabricksSandboxSpecEnvironment | cdktn.IResolvable): any;
export declare function dataDatabricksSandboxSpecEnvironmentToHclTerraform(struct?: DataDatabricksSandboxSpecEnvironment | cdktn.IResolvable): any;
export declare class DataDatabricksSandboxSpecEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxSpecEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSandboxSpecEnvironment | cdktn.IResolvable | undefined);
    private _imageUri?;
    get imageUri(): string;
    set imageUri(value: string);
    resetImageUri(): void;
    get imageUriInput(): string | undefined;
}
export interface DataDatabricksSandboxSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#compute DataDatabricksSandbox#compute}
    */
    readonly compute?: DataDatabricksSandboxSpecCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#environment DataDatabricksSandbox#environment}
    */
    readonly environment?: DataDatabricksSandboxSpecEnvironment;
}
export declare function dataDatabricksSandboxSpecToTerraform(struct?: DataDatabricksSandboxSpec): any;
export declare function dataDatabricksSandboxSpecToHclTerraform(struct?: DataDatabricksSandboxSpec): any;
export declare class DataDatabricksSandboxSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxSpec | undefined;
    set internalValue(value: DataDatabricksSandboxSpec | undefined);
    private _compute;
    get compute(): DataDatabricksSandboxSpecComputeOutputReference;
    putCompute(value: DataDatabricksSandboxSpecCompute): void;
    resetCompute(): void;
    get computeInput(): cdktn.IResolvable | DataDatabricksSandboxSpecCompute | undefined;
    private _environment;
    get environment(): DataDatabricksSandboxSpecEnvironmentOutputReference;
    putEnvironment(value: DataDatabricksSandboxSpecEnvironment): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | DataDatabricksSandboxSpecEnvironment | undefined;
}
export interface DataDatabricksSandboxStatus {
}
export declare function dataDatabricksSandboxStatusToTerraform(struct?: DataDatabricksSandboxStatus): any;
export declare function dataDatabricksSandboxStatusToHclTerraform(struct?: DataDatabricksSandboxStatus): any;
export declare class DataDatabricksSandboxStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxStatus | undefined;
    set internalValue(value: DataDatabricksSandboxStatus | undefined);
    get state(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox databricks_sandbox}
*/
export declare class DataDatabricksSandbox extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_sandbox";
    /**
    * Generates CDKTN code for importing a DataDatabricksSandbox resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSandbox to import
    * @param importFromId The id of the existing DataDatabricksSandbox that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSandbox to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/sandbox databricks_sandbox} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSandboxConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksSandboxConfig);
    get createTime(): string;
    get displayName(): string;
    private _metadata;
    get metadata(): DataDatabricksSandboxMetadataOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSandboxProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSandboxProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSandboxProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksSandboxSpecOutputReference;
    private _status;
    get status(): DataDatabricksSandboxStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
