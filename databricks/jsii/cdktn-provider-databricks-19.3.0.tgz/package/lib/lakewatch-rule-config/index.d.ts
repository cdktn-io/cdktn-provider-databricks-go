/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LakewatchRuleConfigAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#default_folder LakewatchRuleConfigA#default_folder}
    */
    readonly defaultFolder?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#default_schedule LakewatchRuleConfigA#default_schedule}
    */
    readonly defaultSchedule?: LakewatchRuleConfigDefaultSchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#default_signal_collation_window LakewatchRuleConfigA#default_signal_collation_window}
    */
    readonly defaultSignalCollationWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#detection_categories LakewatchRuleConfigA#detection_categories}
    */
    readonly detectionCategories?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#parent LakewatchRuleConfigA#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#provider_config LakewatchRuleConfigA#provider_config}
    */
    readonly providerConfig?: LakewatchRuleConfigProviderConfig;
}
export interface LakewatchRuleConfigDefaultSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#at_least_every LakewatchRuleConfigA#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#cron_expression LakewatchRuleConfigA#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#enabled LakewatchRuleConfigA#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function lakewatchRuleConfigDefaultScheduleToTerraform(struct?: LakewatchRuleConfigDefaultSchedule | cdktn.IResolvable): any;
export declare function lakewatchRuleConfigDefaultScheduleToHclTerraform(struct?: LakewatchRuleConfigDefaultSchedule | cdktn.IResolvable): any;
export declare class LakewatchRuleConfigDefaultScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleConfigDefaultSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleConfigDefaultSchedule | cdktn.IResolvable | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface LakewatchRuleConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#workspace_id LakewatchRuleConfigA#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakewatchRuleConfigProviderConfigToTerraform(struct?: LakewatchRuleConfigProviderConfig | cdktn.IResolvable): any;
export declare function lakewatchRuleConfigProviderConfigToHclTerraform(struct?: LakewatchRuleConfigProviderConfig | cdktn.IResolvable): any;
export declare class LakewatchRuleConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchRuleConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakewatchRuleConfigUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#display_name LakewatchRuleConfigA#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#email LakewatchRuleConfigA#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#id LakewatchRuleConfigA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#principal_type LakewatchRuleConfigA#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchRuleConfigUpdatedByToTerraform(struct?: LakewatchRuleConfigUpdatedBy): any;
export declare function lakewatchRuleConfigUpdatedByToHclTerraform(struct?: LakewatchRuleConfigUpdatedBy): any;
export declare class LakewatchRuleConfigUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchRuleConfigUpdatedBy | undefined;
    set internalValue(value: LakewatchRuleConfigUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config databricks_lakewatch_rule_config}
*/
export declare class LakewatchRuleConfigA extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_lakewatch_rule_config";
    /**
    * Generates CDKTN code for importing a LakewatchRuleConfigA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LakewatchRuleConfigA to import
    * @param importFromId The id of the existing LakewatchRuleConfigA that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LakewatchRuleConfigA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_rule_config databricks_lakewatch_rule_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LakewatchRuleConfigAConfig
    */
    constructor(scope: Construct, id: string, config: LakewatchRuleConfigAConfig);
    private _defaultFolder?;
    get defaultFolder(): string;
    set defaultFolder(value: string);
    resetDefaultFolder(): void;
    get defaultFolderInput(): string | undefined;
    private _defaultSchedule;
    get defaultSchedule(): LakewatchRuleConfigDefaultScheduleOutputReference;
    putDefaultSchedule(value: LakewatchRuleConfigDefaultSchedule): void;
    resetDefaultSchedule(): void;
    get defaultScheduleInput(): cdktn.IResolvable | LakewatchRuleConfigDefaultSchedule | undefined;
    private _defaultSignalCollationWindow?;
    get defaultSignalCollationWindow(): string;
    set defaultSignalCollationWindow(value: string);
    resetDefaultSignalCollationWindow(): void;
    get defaultSignalCollationWindowInput(): string | undefined;
    private _detectionCategories?;
    get detectionCategories(): string[];
    set detectionCategories(value: string[]);
    resetDetectionCategories(): void;
    get detectionCategoriesInput(): string[] | undefined;
    get effectiveDefaultFolder(): string;
    get effectiveDetectionCategories(): string[];
    get etag(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): LakewatchRuleConfigProviderConfigOutputReference;
    putProviderConfig(value: LakewatchRuleConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | LakewatchRuleConfigProviderConfig | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): LakewatchRuleConfigUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
