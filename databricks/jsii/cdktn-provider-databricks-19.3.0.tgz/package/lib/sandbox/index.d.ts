/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SandboxConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#display_name Sandbox#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#metadata Sandbox#metadata}
    */
    readonly metadata?: SandboxMetadata;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#provider_config Sandbox#provider_config}
    */
    readonly providerConfig?: SandboxProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#sandbox_id Sandbox#sandbox_id}
    */
    readonly sandboxId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#spec Sandbox#spec}
    */
    readonly spec?: SandboxSpec;
}
export interface SandboxMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#custom_tags Sandbox#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
}
export declare function sandboxMetadataToTerraform(struct?: SandboxMetadata | cdktn.IResolvable): any;
export declare function sandboxMetadataToHclTerraform(struct?: SandboxMetadata | cdktn.IResolvable): any;
export declare class SandboxMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SandboxMetadata | cdktn.IResolvable | undefined;
    set internalValue(value: SandboxMetadata | cdktn.IResolvable | undefined);
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface SandboxProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#workspace_id Sandbox#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function sandboxProviderConfigToTerraform(struct?: SandboxProviderConfig | cdktn.IResolvable): any;
export declare function sandboxProviderConfigToHclTerraform(struct?: SandboxProviderConfig | cdktn.IResolvable): any;
export declare class SandboxProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SandboxProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: SandboxProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface SandboxSpecCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#inactivity_timeout Sandbox#inactivity_timeout}
    */
    readonly inactivityTimeout?: string;
}
export declare function sandboxSpecComputeToTerraform(struct?: SandboxSpecCompute | cdktn.IResolvable): any;
export declare function sandboxSpecComputeToHclTerraform(struct?: SandboxSpecCompute | cdktn.IResolvable): any;
export declare class SandboxSpecComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SandboxSpecCompute | cdktn.IResolvable | undefined;
    set internalValue(value: SandboxSpecCompute | cdktn.IResolvable | undefined);
    private _inactivityTimeout?;
    get inactivityTimeout(): string;
    set inactivityTimeout(value: string);
    resetInactivityTimeout(): void;
    get inactivityTimeoutInput(): string | undefined;
}
export interface SandboxSpecEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#image_uri Sandbox#image_uri}
    */
    readonly imageUri?: string;
}
export declare function sandboxSpecEnvironmentToTerraform(struct?: SandboxSpecEnvironment | cdktn.IResolvable): any;
export declare function sandboxSpecEnvironmentToHclTerraform(struct?: SandboxSpecEnvironment | cdktn.IResolvable): any;
export declare class SandboxSpecEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SandboxSpecEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: SandboxSpecEnvironment | cdktn.IResolvable | undefined);
    private _imageUri?;
    get imageUri(): string;
    set imageUri(value: string);
    resetImageUri(): void;
    get imageUriInput(): string | undefined;
}
export interface SandboxSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#compute Sandbox#compute}
    */
    readonly compute?: SandboxSpecCompute;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#environment Sandbox#environment}
    */
    readonly environment?: SandboxSpecEnvironment;
}
export declare function sandboxSpecToTerraform(struct?: SandboxSpec | cdktn.IResolvable): any;
export declare function sandboxSpecToHclTerraform(struct?: SandboxSpec | cdktn.IResolvable): any;
export declare class SandboxSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SandboxSpec | cdktn.IResolvable | undefined;
    set internalValue(value: SandboxSpec | cdktn.IResolvable | undefined);
    private _compute;
    get compute(): SandboxSpecComputeOutputReference;
    putCompute(value: SandboxSpecCompute): void;
    resetCompute(): void;
    get computeInput(): cdktn.IResolvable | SandboxSpecCompute | undefined;
    private _environment;
    get environment(): SandboxSpecEnvironmentOutputReference;
    putEnvironment(value: SandboxSpecEnvironment): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | SandboxSpecEnvironment | undefined;
}
export interface SandboxStatus {
}
export declare function sandboxStatusToTerraform(struct?: SandboxStatus): any;
export declare function sandboxStatusToHclTerraform(struct?: SandboxStatus): any;
export declare class SandboxStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SandboxStatus | undefined;
    set internalValue(value: SandboxStatus | undefined);
    get state(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox databricks_sandbox}
*/
export declare class Sandbox extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sandbox";
    /**
    * Generates CDKTN code for importing a Sandbox resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Sandbox to import
    * @param importFromId The id of the existing Sandbox that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Sandbox to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/sandbox databricks_sandbox} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SandboxConfig
    */
    constructor(scope: Construct, id: string, config: SandboxConfig);
    get createTime(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _metadata;
    get metadata(): SandboxMetadataOutputReference;
    putMetadata(value: SandboxMetadata): void;
    resetMetadata(): void;
    get metadataInput(): cdktn.IResolvable | SandboxMetadata | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): SandboxProviderConfigOutputReference;
    putProviderConfig(value: SandboxProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | SandboxProviderConfig | undefined;
    private _sandboxId?;
    get sandboxId(): string;
    set sandboxId(value: string);
    get sandboxIdInput(): string | undefined;
    private _spec;
    get spec(): SandboxSpecOutputReference;
    putSpec(value: SandboxSpec): void;
    resetSpec(): void;
    get specInput(): cdktn.IResolvable | SandboxSpec | undefined;
    private _status;
    get status(): SandboxStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
