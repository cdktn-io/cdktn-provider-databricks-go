/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LakewatchDatasourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#annotations LakewatchDatasource#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#autoloader LakewatchDatasource#autoloader}
    */
    readonly autoloader?: LakewatchDatasourceAutoloader;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#catalog_name LakewatchDatasource#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#compute_mode LakewatchDatasource#compute_mode}
    */
    readonly computeMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#datasource_name LakewatchDatasource#datasource_name}
    */
    readonly datasourceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#description LakewatchDatasource#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#existing_table LakewatchDatasource#existing_table}
    */
    readonly existingTable?: LakewatchDatasourceExistingTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#parsers LakewatchDatasource#parsers}
    */
    readonly parsers?: LakewatchDatasourceParsers[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#provider_config LakewatchDatasource#provider_config}
    */
    readonly providerConfig?: LakewatchDatasourceProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#run_as_principal LakewatchDatasource#run_as_principal}
    */
    readonly runAsPrincipal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#schedule LakewatchDatasource#schedule}
    */
    readonly schedule: LakewatchDatasourceSchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#schema_name LakewatchDatasource#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#unity_catalog_connection LakewatchDatasource#unity_catalog_connection}
    */
    readonly unityCatalogConnection?: LakewatchDatasourceUnityCatalogConnection;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#warehouse_id LakewatchDatasource#warehouse_id}
    */
    readonly warehouseId?: string;
}
export interface LakewatchDatasourceAutoloaderEffectiveRawTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#catalog_name LakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#schema_name LakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#table_name LakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function lakewatchDatasourceAutoloaderEffectiveRawTableToTerraform(struct?: LakewatchDatasourceAutoloaderEffectiveRawTable): any;
export declare function lakewatchDatasourceAutoloaderEffectiveRawTableToHclTerraform(struct?: LakewatchDatasourceAutoloaderEffectiveRawTable): any;
export declare class LakewatchDatasourceAutoloaderEffectiveRawTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceAutoloaderEffectiveRawTable | undefined;
    set internalValue(value: LakewatchDatasourceAutoloaderEffectiveRawTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#header_retention LakewatchDatasource#header_retention}
    */
    readonly headerRetention?: boolean | cdktn.IResolvable;
}
export declare function lakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsToTerraform(struct?: LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable): any;
export declare function lakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsToHclTerraform(struct?: LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable): any;
export declare class LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable | undefined);
    private _headerRetention?;
    get headerRetention(): boolean | cdktn.IResolvable;
    set headerRetention(value: boolean | cdktn.IResolvable);
    resetHeaderRetention(): void;
    get headerRetentionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface LakewatchDatasourceAutoloaderEnvelopeJsonArray {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#path LakewatchDatasource#path}
    */
    readonly path: string;
}
export declare function lakewatchDatasourceAutoloaderEnvelopeJsonArrayToTerraform(struct?: LakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable): any;
export declare function lakewatchDatasourceAutoloaderEnvelopeJsonArrayToHclTerraform(struct?: LakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable): any;
export declare class LakewatchDatasourceAutoloaderEnvelopeJsonArrayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceAutoloaderEnvelopeJsonArray | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface LakewatchDatasourceAutoloaderEnvelope {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#cloud_watch_logs LakewatchDatasource#cloud_watch_logs}
    */
    readonly cloudWatchLogs?: LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#json_array LakewatchDatasource#json_array}
    */
    readonly jsonArray?: LakewatchDatasourceAutoloaderEnvelopeJsonArray;
}
export declare function lakewatchDatasourceAutoloaderEnvelopeToTerraform(struct?: LakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable): any;
export declare function lakewatchDatasourceAutoloaderEnvelopeToHclTerraform(struct?: LakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable): any;
export declare class LakewatchDatasourceAutoloaderEnvelopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceAutoloaderEnvelope | cdktn.IResolvable | undefined);
    private _cloudWatchLogs;
    get cloudWatchLogs(): LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogsOutputReference;
    putCloudWatchLogs(value: LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs): void;
    resetCloudWatchLogs(): void;
    get cloudWatchLogsInput(): cdktn.IResolvable | LakewatchDatasourceAutoloaderEnvelopeCloudWatchLogs | undefined;
    private _jsonArray;
    get jsonArray(): LakewatchDatasourceAutoloaderEnvelopeJsonArrayOutputReference;
    putJsonArray(value: LakewatchDatasourceAutoloaderEnvelopeJsonArray): void;
    resetJsonArray(): void;
    get jsonArrayInput(): cdktn.IResolvable | LakewatchDatasourceAutoloaderEnvelopeJsonArray | undefined;
}
export interface LakewatchDatasourceAutoloaderRawTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#catalog_name LakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#schema_name LakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#table_name LakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function lakewatchDatasourceAutoloaderRawTableToTerraform(struct?: LakewatchDatasourceAutoloaderRawTable | cdktn.IResolvable): any;
export declare function lakewatchDatasourceAutoloaderRawTableToHclTerraform(struct?: LakewatchDatasourceAutoloaderRawTable | cdktn.IResolvable): any;
export declare class LakewatchDatasourceAutoloaderRawTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceAutoloaderRawTable | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceAutoloaderRawTable | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface LakewatchDatasourceAutoloader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#aws_secret_scope LakewatchDatasource#aws_secret_scope}
    */
    readonly awsSecretScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#envelope LakewatchDatasource#envelope}
    */
    readonly envelope?: LakewatchDatasourceAutoloaderEnvelope;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#format LakewatchDatasource#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#format_options LakewatchDatasource#format_options}
    */
    readonly formatOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#include_existing_files LakewatchDatasource#include_existing_files}
    */
    readonly includeExistingFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#location LakewatchDatasource#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#override_partition_columns LakewatchDatasource#override_partition_columns}
    */
    readonly overridePartitionColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#queue_url LakewatchDatasource#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#raw_table LakewatchDatasource#raw_table}
    */
    readonly rawTable: LakewatchDatasourceAutoloaderRawTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#service_credentials LakewatchDatasource#service_credentials}
    */
    readonly serviceCredentials?: string;
}
export declare function lakewatchDatasourceAutoloaderToTerraform(struct?: LakewatchDatasourceAutoloader | cdktn.IResolvable): any;
export declare function lakewatchDatasourceAutoloaderToHclTerraform(struct?: LakewatchDatasourceAutoloader | cdktn.IResolvable): any;
export declare class LakewatchDatasourceAutoloaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceAutoloader | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceAutoloader | cdktn.IResolvable | undefined);
    private _awsSecretScope?;
    get awsSecretScope(): string;
    set awsSecretScope(value: string);
    resetAwsSecretScope(): void;
    get awsSecretScopeInput(): string | undefined;
    get effectiveIncludeExistingFiles(): cdktn.IResolvable;
    private _effectiveRawTable;
    get effectiveRawTable(): LakewatchDatasourceAutoloaderEffectiveRawTableOutputReference;
    private _envelope;
    get envelope(): LakewatchDatasourceAutoloaderEnvelopeOutputReference;
    putEnvelope(value: LakewatchDatasourceAutoloaderEnvelope): void;
    resetEnvelope(): void;
    get envelopeInput(): cdktn.IResolvable | LakewatchDatasourceAutoloaderEnvelope | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _formatOptions?;
    get formatOptions(): {
        [key: string]: string;
    };
    set formatOptions(value: {
        [key: string]: string;
    });
    resetFormatOptions(): void;
    get formatOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _includeExistingFiles?;
    get includeExistingFiles(): boolean | cdktn.IResolvable;
    set includeExistingFiles(value: boolean | cdktn.IResolvable);
    resetIncludeExistingFiles(): void;
    get includeExistingFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _overridePartitionColumns?;
    get overridePartitionColumns(): string[];
    set overridePartitionColumns(value: string[]);
    resetOverridePartitionColumns(): void;
    get overridePartitionColumnsInput(): string[] | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _rawTable;
    get rawTable(): LakewatchDatasourceAutoloaderRawTableOutputReference;
    putRawTable(value: LakewatchDatasourceAutoloaderRawTable): void;
    get rawTableInput(): cdktn.IResolvable | LakewatchDatasourceAutoloaderRawTable | undefined;
    private _serviceCredentials?;
    get serviceCredentials(): string;
    set serviceCredentials(value: string);
    resetServiceCredentials(): void;
    get serviceCredentialsInput(): string | undefined;
}
export interface LakewatchDatasourceCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#display_name LakewatchDatasource#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#email LakewatchDatasource#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#id LakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#principal_type LakewatchDatasource#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchDatasourceCreatedByToTerraform(struct?: LakewatchDatasourceCreatedBy): any;
export declare function lakewatchDatasourceCreatedByToHclTerraform(struct?: LakewatchDatasourceCreatedBy): any;
export declare class LakewatchDatasourceCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceCreatedBy | undefined;
    set internalValue(value: LakewatchDatasourceCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface LakewatchDatasourceExistingTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#catalog LakewatchDatasource#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#include_existing_rows LakewatchDatasource#include_existing_rows}
    */
    readonly includeExistingRows?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#name LakewatchDatasource#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#schema LakewatchDatasource#schema}
    */
    readonly schema?: string;
}
export declare function lakewatchDatasourceExistingTableToTerraform(struct?: LakewatchDatasourceExistingTable | cdktn.IResolvable): any;
export declare function lakewatchDatasourceExistingTableToHclTerraform(struct?: LakewatchDatasourceExistingTable | cdktn.IResolvable): any;
export declare class LakewatchDatasourceExistingTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceExistingTable | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceExistingTable | cdktn.IResolvable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    get effectiveCatalog(): string;
    get effectiveName(): string;
    get effectiveSchema(): string;
    private _includeExistingRows?;
    get includeExistingRows(): boolean | cdktn.IResolvable;
    set includeExistingRows(value: boolean | cdktn.IResolvable);
    resetIncludeExistingRows(): void;
    get includeExistingRowsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface LakewatchDatasourceOwner {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#display_name LakewatchDatasource#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#email LakewatchDatasource#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#id LakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#principal_type LakewatchDatasource#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchDatasourceOwnerToTerraform(struct?: LakewatchDatasourceOwner): any;
export declare function lakewatchDatasourceOwnerToHclTerraform(struct?: LakewatchDatasourceOwner): any;
export declare class LakewatchDatasourceOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceOwner | undefined;
    set internalValue(value: LakewatchDatasourceOwner | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface LakewatchDatasourceParsersEffectiveTargetTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#catalog_name LakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#schema_name LakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#table_name LakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function lakewatchDatasourceParsersEffectiveTargetTableToTerraform(struct?: LakewatchDatasourceParsersEffectiveTargetTable): any;
export declare function lakewatchDatasourceParsersEffectiveTargetTableToHclTerraform(struct?: LakewatchDatasourceParsersEffectiveTargetTable): any;
export declare class LakewatchDatasourceParsersEffectiveTargetTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceParsersEffectiveTargetTable | undefined;
    set internalValue(value: LakewatchDatasourceParsersEffectiveTargetTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface LakewatchDatasourceParsersTargetTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#catalog_name LakewatchDatasource#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#schema_name LakewatchDatasource#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#table_name LakewatchDatasource#table_name}
    */
    readonly tableName: string;
}
export declare function lakewatchDatasourceParsersTargetTableToTerraform(struct?: LakewatchDatasourceParsersTargetTable | cdktn.IResolvable): any;
export declare function lakewatchDatasourceParsersTargetTableToHclTerraform(struct?: LakewatchDatasourceParsersTargetTable | cdktn.IResolvable): any;
export declare class LakewatchDatasourceParsersTargetTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceParsersTargetTable | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceParsersTargetTable | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface LakewatchDatasourceParsers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#id LakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#target_table LakewatchDatasource#target_table}
    */
    readonly targetTable?: LakewatchDatasourceParsersTargetTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#version LakewatchDatasource#version}
    */
    readonly version: string;
}
export declare function lakewatchDatasourceParsersToTerraform(struct?: LakewatchDatasourceParsers | cdktn.IResolvable): any;
export declare function lakewatchDatasourceParsersToHclTerraform(struct?: LakewatchDatasourceParsers | cdktn.IResolvable): any;
export declare class LakewatchDatasourceParsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LakewatchDatasourceParsers | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceParsers | cdktn.IResolvable | undefined);
    private _effectiveTargetTable;
    get effectiveTargetTable(): LakewatchDatasourceParsersEffectiveTargetTableOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _targetTable;
    get targetTable(): LakewatchDatasourceParsersTargetTableOutputReference;
    putTargetTable(value: LakewatchDatasourceParsersTargetTable): void;
    resetTargetTable(): void;
    get targetTableInput(): cdktn.IResolvable | LakewatchDatasourceParsersTargetTable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export declare class LakewatchDatasourceParsersList extends cdktn.ComplexList {
    internalValue?: LakewatchDatasourceParsers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LakewatchDatasourceParsersOutputReference;
}
export interface LakewatchDatasourceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#workspace_id LakewatchDatasource#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakewatchDatasourceProviderConfigToTerraform(struct?: LakewatchDatasourceProviderConfig | cdktn.IResolvable): any;
export declare function lakewatchDatasourceProviderConfigToHclTerraform(struct?: LakewatchDatasourceProviderConfig | cdktn.IResolvable): any;
export declare class LakewatchDatasourceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakewatchDatasourceSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#at_least_every LakewatchDatasource#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#compute_group LakewatchDatasource#compute_group}
    */
    readonly computeGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#continuous LakewatchDatasource#continuous}
    */
    readonly continuous?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#cron_expression LakewatchDatasource#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#enabled LakewatchDatasource#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function lakewatchDatasourceScheduleToTerraform(struct?: LakewatchDatasourceSchedule | cdktn.IResolvable): any;
export declare function lakewatchDatasourceScheduleToHclTerraform(struct?: LakewatchDatasourceSchedule | cdktn.IResolvable): any;
export declare class LakewatchDatasourceScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceSchedule | cdktn.IResolvable | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _computeGroup?;
    get computeGroup(): string;
    set computeGroup(value: string);
    resetComputeGroup(): void;
    get computeGroupInput(): string | undefined;
    private _continuous?;
    get continuous(): boolean | cdktn.IResolvable;
    set continuous(value: boolean | cdktn.IResolvable);
    resetContinuous(): void;
    get continuousInput(): boolean | cdktn.IResolvable | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface LakewatchDatasourceStatusIngestionJob {
}
export declare function lakewatchDatasourceStatusIngestionJobToTerraform(struct?: LakewatchDatasourceStatusIngestionJob): any;
export declare function lakewatchDatasourceStatusIngestionJobToHclTerraform(struct?: LakewatchDatasourceStatusIngestionJob): any;
export declare class LakewatchDatasourceStatusIngestionJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceStatusIngestionJob | undefined;
    set internalValue(value: LakewatchDatasourceStatusIngestionJob | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface LakewatchDatasourceStatusIngestionPipeline {
}
export declare function lakewatchDatasourceStatusIngestionPipelineToTerraform(struct?: LakewatchDatasourceStatusIngestionPipeline): any;
export declare function lakewatchDatasourceStatusIngestionPipelineToHclTerraform(struct?: LakewatchDatasourceStatusIngestionPipeline): any;
export declare class LakewatchDatasourceStatusIngestionPipelineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceStatusIngestionPipeline | undefined;
    set internalValue(value: LakewatchDatasourceStatusIngestionPipeline | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface LakewatchDatasourceStatus {
}
export declare function lakewatchDatasourceStatusToTerraform(struct?: LakewatchDatasourceStatus): any;
export declare function lakewatchDatasourceStatusToHclTerraform(struct?: LakewatchDatasourceStatus): any;
export declare class LakewatchDatasourceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceStatus | undefined;
    set internalValue(value: LakewatchDatasourceStatus | undefined);
    private _ingestionJob;
    get ingestionJob(): LakewatchDatasourceStatusIngestionJobOutputReference;
    private _ingestionPipeline;
    get ingestionPipeline(): LakewatchDatasourceStatusIngestionPipelineOutputReference;
}
export interface LakewatchDatasourceUnityCatalogConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#configuration LakewatchDatasource#configuration}
    */
    readonly configuration?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#connection_name LakewatchDatasource#connection_name}
    */
    readonly connectionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#start_time LakewatchDatasource#start_time}
    */
    readonly startTime?: string;
}
export declare function lakewatchDatasourceUnityCatalogConnectionToTerraform(struct?: LakewatchDatasourceUnityCatalogConnection | cdktn.IResolvable): any;
export declare function lakewatchDatasourceUnityCatalogConnectionToHclTerraform(struct?: LakewatchDatasourceUnityCatalogConnection | cdktn.IResolvable): any;
export declare class LakewatchDatasourceUnityCatalogConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceUnityCatalogConnection | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchDatasourceUnityCatalogConnection | cdktn.IResolvable | undefined);
    private _configuration?;
    get configuration(): {
        [key: string]: string;
    };
    set configuration(value: {
        [key: string]: string;
    });
    resetConfiguration(): void;
    get configurationInput(): {
        [key: string]: string;
    } | undefined;
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    get connectionNameInput(): string | undefined;
    get connector(): string;
    get effectiveStartTime(): string;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export interface LakewatchDatasourceUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#display_name LakewatchDatasource#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#email LakewatchDatasource#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#id LakewatchDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#principal_type LakewatchDatasource#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchDatasourceUpdatedByToTerraform(struct?: LakewatchDatasourceUpdatedBy): any;
export declare function lakewatchDatasourceUpdatedByToHclTerraform(struct?: LakewatchDatasourceUpdatedBy): any;
export declare class LakewatchDatasourceUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchDatasourceUpdatedBy | undefined;
    set internalValue(value: LakewatchDatasourceUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource databricks_lakewatch_datasource}
*/
export declare class LakewatchDatasource extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_lakewatch_datasource";
    /**
    * Generates CDKTN code for importing a LakewatchDatasource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LakewatchDatasource to import
    * @param importFromId The id of the existing LakewatchDatasource that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LakewatchDatasource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_datasource databricks_lakewatch_datasource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LakewatchDatasourceConfig
    */
    constructor(scope: Construct, id: string, config: LakewatchDatasourceConfig);
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _autoloader;
    get autoloader(): LakewatchDatasourceAutoloaderOutputReference;
    putAutoloader(value: LakewatchDatasourceAutoloader): void;
    resetAutoloader(): void;
    get autoloaderInput(): cdktn.IResolvable | LakewatchDatasourceAutoloader | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _computeMode?;
    get computeMode(): string;
    set computeMode(value: string);
    resetComputeMode(): void;
    get computeModeInput(): string | undefined;
    get computeWorkspaceId(): string;
    get createTime(): string;
    private _createdBy;
    get createdBy(): LakewatchDatasourceCreatedByOutputReference;
    get datasourceId(): string;
    private _datasourceName?;
    get datasourceName(): string;
    set datasourceName(value: string);
    get datasourceNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveCatalogName(): string;
    get effectiveDatasourceName(): string;
    get effectiveRunAsPrincipal(): string;
    get effectiveSchemaName(): string;
    get etag(): string;
    private _existingTable;
    get existingTable(): LakewatchDatasourceExistingTableOutputReference;
    putExistingTable(value: LakewatchDatasourceExistingTable): void;
    resetExistingTable(): void;
    get existingTableInput(): cdktn.IResolvable | LakewatchDatasourceExistingTable | undefined;
    get name(): string;
    private _owner;
    get owner(): LakewatchDatasourceOwnerOutputReference;
    private _parsers;
    get parsers(): LakewatchDatasourceParsersList;
    putParsers(value: LakewatchDatasourceParsers[] | cdktn.IResolvable): void;
    resetParsers(): void;
    get parsersInput(): cdktn.IResolvable | LakewatchDatasourceParsers[] | undefined;
    private _providerConfig;
    get providerConfig(): LakewatchDatasourceProviderConfigOutputReference;
    putProviderConfig(value: LakewatchDatasourceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | LakewatchDatasourceProviderConfig | undefined;
    private _runAsPrincipal?;
    get runAsPrincipal(): string;
    set runAsPrincipal(value: string);
    resetRunAsPrincipal(): void;
    get runAsPrincipalInput(): string | undefined;
    private _schedule;
    get schedule(): LakewatchDatasourceScheduleOutputReference;
    putSchedule(value: LakewatchDatasourceSchedule): void;
    get scheduleInput(): cdktn.IResolvable | LakewatchDatasourceSchedule | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _status;
    get status(): LakewatchDatasourceStatusOutputReference;
    private _unityCatalogConnection;
    get unityCatalogConnection(): LakewatchDatasourceUnityCatalogConnectionOutputReference;
    putUnityCatalogConnection(value: LakewatchDatasourceUnityCatalogConnection): void;
    resetUnityCatalogConnection(): void;
    get unityCatalogConnectionInput(): cdktn.IResolvable | LakewatchDatasourceUnityCatalogConnection | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): LakewatchDatasourceUpdatedByOutputReference;
    get version(): number;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
