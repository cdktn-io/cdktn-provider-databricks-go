/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LakewatchAlertConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#default_security_alert_collation_window LakewatchAlertConfig#default_security_alert_collation_window}
    */
    readonly defaultSecurityAlertCollationWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#default_system_alert_collation_window LakewatchAlertConfig#default_system_alert_collation_window}
    */
    readonly defaultSystemAlertCollationWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#parent LakewatchAlertConfig#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#provider_config LakewatchAlertConfig#provider_config}
    */
    readonly providerConfig?: LakewatchAlertConfigProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#security_alert_export_config LakewatchAlertConfig#security_alert_export_config}
    */
    readonly securityAlertExportConfig?: LakewatchAlertConfigSecurityAlertExportConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#system_alert_export_config LakewatchAlertConfig#system_alert_export_config}
    */
    readonly systemAlertExportConfig?: LakewatchAlertConfigSystemAlertExportConfig;
}
export interface LakewatchAlertConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#workspace_id LakewatchAlertConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakewatchAlertConfigProviderConfigToTerraform(struct?: LakewatchAlertConfigProviderConfig | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigProviderConfigToHclTerraform(struct?: LakewatchAlertConfigProviderConfig | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakewatchAlertConfigSecurityAlertExportConfigJira {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#api_token_uc_secret LakewatchAlertConfig#api_token_uc_secret}
    */
    readonly apiTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#default_issue_type LakewatchAlertConfig#default_issue_type}
    */
    readonly defaultIssueType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#instance_url LakewatchAlertConfig#instance_url}
    */
    readonly instanceUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#project_key LakewatchAlertConfig#project_key}
    */
    readonly projectKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#user_email LakewatchAlertConfig#user_email}
    */
    readonly userEmail: string;
}
export declare function lakewatchAlertConfigSecurityAlertExportConfigJiraToTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSecurityAlertExportConfigJiraToHclTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSecurityAlertExportConfigJiraOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable | undefined);
    private _apiTokenUcSecret?;
    get apiTokenUcSecret(): string;
    set apiTokenUcSecret(value: string);
    get apiTokenUcSecretInput(): string | undefined;
    private _defaultIssueType?;
    get defaultIssueType(): string;
    set defaultIssueType(value: string);
    get defaultIssueTypeInput(): string | undefined;
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    get instanceUrlInput(): string | undefined;
    private _projectKey?;
    get projectKey(): string;
    set projectKey(value: string);
    get projectKeyInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string;
    set userEmail(value: string);
    get userEmailInput(): string | undefined;
}
export interface LakewatchAlertConfigSecurityAlertExportConfigServiceNow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#client_id LakewatchAlertConfig#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#client_secret_uc_secret LakewatchAlertConfig#client_secret_uc_secret}
    */
    readonly clientSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#instance_id LakewatchAlertConfig#instance_id}
    */
    readonly instanceId: string;
}
export declare function lakewatchAlertConfigSecurityAlertExportConfigServiceNowToTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSecurityAlertExportConfigServiceNowToHclTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSecurityAlertExportConfigServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretUcSecret?;
    get clientSecretUcSecret(): string;
    set clientSecretUcSecret(value: string);
    get clientSecretUcSecretInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
}
export interface LakewatchAlertConfigSecurityAlertExportConfigSlack {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#bot_token_uc_secret LakewatchAlertConfig#bot_token_uc_secret}
    */
    readonly botTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#channel LakewatchAlertConfig#channel}
    */
    readonly channel: string;
}
export declare function lakewatchAlertConfigSecurityAlertExportConfigSlackToTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSecurityAlertExportConfigSlackToHclTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSecurityAlertExportConfigSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable | undefined);
    private _botTokenUcSecret?;
    get botTokenUcSecret(): string;
    set botTokenUcSecret(value: string);
    get botTokenUcSecretInput(): string | undefined;
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
}
export interface LakewatchAlertConfigSecurityAlertExportConfigTines {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#export_updates LakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#webhook_secret_uc_secret LakewatchAlertConfig#webhook_secret_uc_secret}
    */
    readonly webhookSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#webhook_uri LakewatchAlertConfig#webhook_uri}
    */
    readonly webhookUri: string;
}
export declare function lakewatchAlertConfigSecurityAlertExportConfigTinesToTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSecurityAlertExportConfigTinesToHclTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSecurityAlertExportConfigTinesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _webhookSecretUcSecret?;
    get webhookSecretUcSecret(): string;
    set webhookSecretUcSecret(value: string);
    get webhookSecretUcSecretInput(): string | undefined;
    private _webhookUri?;
    get webhookUri(): string;
    set webhookUri(value: string);
    get webhookUriInput(): string | undefined;
}
export interface LakewatchAlertConfigSecurityAlertExportConfigWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#export_updates LakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#url LakewatchAlertConfig#url}
    */
    readonly url?: string;
}
export declare function lakewatchAlertConfigSecurityAlertExportConfigWebhookToTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSecurityAlertExportConfigWebhookToHclTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSecurityAlertExportConfigWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface LakewatchAlertConfigSecurityAlertExportConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#enabled LakewatchAlertConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#jira LakewatchAlertConfig#jira}
    */
    readonly jira?: LakewatchAlertConfigSecurityAlertExportConfigJira;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#service_now LakewatchAlertConfig#service_now}
    */
    readonly serviceNow?: LakewatchAlertConfigSecurityAlertExportConfigServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#slack LakewatchAlertConfig#slack}
    */
    readonly slack?: LakewatchAlertConfigSecurityAlertExportConfigSlack;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#tines LakewatchAlertConfig#tines}
    */
    readonly tines?: LakewatchAlertConfigSecurityAlertExportConfigTines;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#webhook LakewatchAlertConfig#webhook}
    */
    readonly webhook?: LakewatchAlertConfigSecurityAlertExportConfigWebhook;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#workspace_id LakewatchAlertConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakewatchAlertConfigSecurityAlertExportConfigToTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfig | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSecurityAlertExportConfigToHclTerraform(struct?: LakewatchAlertConfigSecurityAlertExportConfig | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSecurityAlertExportConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSecurityAlertExportConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSecurityAlertExportConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _jira;
    get jira(): LakewatchAlertConfigSecurityAlertExportConfigJiraOutputReference;
    putJira(value: LakewatchAlertConfigSecurityAlertExportConfigJira): void;
    resetJira(): void;
    get jiraInput(): cdktn.IResolvable | LakewatchAlertConfigSecurityAlertExportConfigJira | undefined;
    private _serviceNow;
    get serviceNow(): LakewatchAlertConfigSecurityAlertExportConfigServiceNowOutputReference;
    putServiceNow(value: LakewatchAlertConfigSecurityAlertExportConfigServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | LakewatchAlertConfigSecurityAlertExportConfigServiceNow | undefined;
    private _slack;
    get slack(): LakewatchAlertConfigSecurityAlertExportConfigSlackOutputReference;
    putSlack(value: LakewatchAlertConfigSecurityAlertExportConfigSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | LakewatchAlertConfigSecurityAlertExportConfigSlack | undefined;
    private _tines;
    get tines(): LakewatchAlertConfigSecurityAlertExportConfigTinesOutputReference;
    putTines(value: LakewatchAlertConfigSecurityAlertExportConfigTines): void;
    resetTines(): void;
    get tinesInput(): cdktn.IResolvable | LakewatchAlertConfigSecurityAlertExportConfigTines | undefined;
    private _webhook;
    get webhook(): LakewatchAlertConfigSecurityAlertExportConfigWebhookOutputReference;
    putWebhook(value: LakewatchAlertConfigSecurityAlertExportConfigWebhook): void;
    resetWebhook(): void;
    get webhookInput(): cdktn.IResolvable | LakewatchAlertConfigSecurityAlertExportConfigWebhook | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakewatchAlertConfigSystemAlertExportConfigJira {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#api_token_uc_secret LakewatchAlertConfig#api_token_uc_secret}
    */
    readonly apiTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#default_issue_type LakewatchAlertConfig#default_issue_type}
    */
    readonly defaultIssueType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#instance_url LakewatchAlertConfig#instance_url}
    */
    readonly instanceUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#project_key LakewatchAlertConfig#project_key}
    */
    readonly projectKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#user_email LakewatchAlertConfig#user_email}
    */
    readonly userEmail: string;
}
export declare function lakewatchAlertConfigSystemAlertExportConfigJiraToTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSystemAlertExportConfigJiraToHclTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSystemAlertExportConfigJiraOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable | undefined);
    private _apiTokenUcSecret?;
    get apiTokenUcSecret(): string;
    set apiTokenUcSecret(value: string);
    get apiTokenUcSecretInput(): string | undefined;
    private _defaultIssueType?;
    get defaultIssueType(): string;
    set defaultIssueType(value: string);
    get defaultIssueTypeInput(): string | undefined;
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    get instanceUrlInput(): string | undefined;
    private _projectKey?;
    get projectKey(): string;
    set projectKey(value: string);
    get projectKeyInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string;
    set userEmail(value: string);
    get userEmailInput(): string | undefined;
}
export interface LakewatchAlertConfigSystemAlertExportConfigServiceNow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#client_id LakewatchAlertConfig#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#client_secret_uc_secret LakewatchAlertConfig#client_secret_uc_secret}
    */
    readonly clientSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#instance_id LakewatchAlertConfig#instance_id}
    */
    readonly instanceId: string;
}
export declare function lakewatchAlertConfigSystemAlertExportConfigServiceNowToTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSystemAlertExportConfigServiceNowToHclTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSystemAlertExportConfigServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretUcSecret?;
    get clientSecretUcSecret(): string;
    set clientSecretUcSecret(value: string);
    get clientSecretUcSecretInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
}
export interface LakewatchAlertConfigSystemAlertExportConfigSlack {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#bot_token_uc_secret LakewatchAlertConfig#bot_token_uc_secret}
    */
    readonly botTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#channel LakewatchAlertConfig#channel}
    */
    readonly channel: string;
}
export declare function lakewatchAlertConfigSystemAlertExportConfigSlackToTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSystemAlertExportConfigSlackToHclTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSystemAlertExportConfigSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable | undefined);
    private _botTokenUcSecret?;
    get botTokenUcSecret(): string;
    set botTokenUcSecret(value: string);
    get botTokenUcSecretInput(): string | undefined;
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
}
export interface LakewatchAlertConfigSystemAlertExportConfigTines {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#export_updates LakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#webhook_secret_uc_secret LakewatchAlertConfig#webhook_secret_uc_secret}
    */
    readonly webhookSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#webhook_uri LakewatchAlertConfig#webhook_uri}
    */
    readonly webhookUri: string;
}
export declare function lakewatchAlertConfigSystemAlertExportConfigTinesToTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSystemAlertExportConfigTinesToHclTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSystemAlertExportConfigTinesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _webhookSecretUcSecret?;
    get webhookSecretUcSecret(): string;
    set webhookSecretUcSecret(value: string);
    get webhookSecretUcSecretInput(): string | undefined;
    private _webhookUri?;
    get webhookUri(): string;
    set webhookUri(value: string);
    get webhookUriInput(): string | undefined;
}
export interface LakewatchAlertConfigSystemAlertExportConfigWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#export_updates LakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#url LakewatchAlertConfig#url}
    */
    readonly url?: string;
}
export declare function lakewatchAlertConfigSystemAlertExportConfigWebhookToTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSystemAlertExportConfigWebhookToHclTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSystemAlertExportConfigWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface LakewatchAlertConfigSystemAlertExportConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#enabled LakewatchAlertConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#jira LakewatchAlertConfig#jira}
    */
    readonly jira?: LakewatchAlertConfigSystemAlertExportConfigJira;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#service_now LakewatchAlertConfig#service_now}
    */
    readonly serviceNow?: LakewatchAlertConfigSystemAlertExportConfigServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#slack LakewatchAlertConfig#slack}
    */
    readonly slack?: LakewatchAlertConfigSystemAlertExportConfigSlack;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#tines LakewatchAlertConfig#tines}
    */
    readonly tines?: LakewatchAlertConfigSystemAlertExportConfigTines;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#webhook LakewatchAlertConfig#webhook}
    */
    readonly webhook?: LakewatchAlertConfigSystemAlertExportConfigWebhook;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#workspace_id LakewatchAlertConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function lakewatchAlertConfigSystemAlertExportConfigToTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfig | cdktn.IResolvable): any;
export declare function lakewatchAlertConfigSystemAlertExportConfigToHclTerraform(struct?: LakewatchAlertConfigSystemAlertExportConfig | cdktn.IResolvable): any;
export declare class LakewatchAlertConfigSystemAlertExportConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigSystemAlertExportConfig | cdktn.IResolvable | undefined;
    set internalValue(value: LakewatchAlertConfigSystemAlertExportConfig | cdktn.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _jira;
    get jira(): LakewatchAlertConfigSystemAlertExportConfigJiraOutputReference;
    putJira(value: LakewatchAlertConfigSystemAlertExportConfigJira): void;
    resetJira(): void;
    get jiraInput(): cdktn.IResolvable | LakewatchAlertConfigSystemAlertExportConfigJira | undefined;
    private _serviceNow;
    get serviceNow(): LakewatchAlertConfigSystemAlertExportConfigServiceNowOutputReference;
    putServiceNow(value: LakewatchAlertConfigSystemAlertExportConfigServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | LakewatchAlertConfigSystemAlertExportConfigServiceNow | undefined;
    private _slack;
    get slack(): LakewatchAlertConfigSystemAlertExportConfigSlackOutputReference;
    putSlack(value: LakewatchAlertConfigSystemAlertExportConfigSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | LakewatchAlertConfigSystemAlertExportConfigSlack | undefined;
    private _tines;
    get tines(): LakewatchAlertConfigSystemAlertExportConfigTinesOutputReference;
    putTines(value: LakewatchAlertConfigSystemAlertExportConfigTines): void;
    resetTines(): void;
    get tinesInput(): cdktn.IResolvable | LakewatchAlertConfigSystemAlertExportConfigTines | undefined;
    private _webhook;
    get webhook(): LakewatchAlertConfigSystemAlertExportConfigWebhookOutputReference;
    putWebhook(value: LakewatchAlertConfigSystemAlertExportConfigWebhook): void;
    resetWebhook(): void;
    get webhookInput(): cdktn.IResolvable | LakewatchAlertConfigSystemAlertExportConfigWebhook | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface LakewatchAlertConfigUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#display_name LakewatchAlertConfig#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#email LakewatchAlertConfig#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#id LakewatchAlertConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#principal_type LakewatchAlertConfig#principal_type}
    */
    readonly principalType?: string;
}
export declare function lakewatchAlertConfigUpdatedByToTerraform(struct?: LakewatchAlertConfigUpdatedBy): any;
export declare function lakewatchAlertConfigUpdatedByToHclTerraform(struct?: LakewatchAlertConfigUpdatedBy): any;
export declare class LakewatchAlertConfigUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LakewatchAlertConfigUpdatedBy | undefined;
    set internalValue(value: LakewatchAlertConfigUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config databricks_lakewatch_alert_config}
*/
export declare class LakewatchAlertConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_lakewatch_alert_config";
    /**
    * Generates CDKTN code for importing a LakewatchAlertConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LakewatchAlertConfig to import
    * @param importFromId The id of the existing LakewatchAlertConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LakewatchAlertConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/lakewatch_alert_config databricks_lakewatch_alert_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LakewatchAlertConfigConfig
    */
    constructor(scope: Construct, id: string, config: LakewatchAlertConfigConfig);
    private _defaultSecurityAlertCollationWindow?;
    get defaultSecurityAlertCollationWindow(): string;
    set defaultSecurityAlertCollationWindow(value: string);
    resetDefaultSecurityAlertCollationWindow(): void;
    get defaultSecurityAlertCollationWindowInput(): string | undefined;
    private _defaultSystemAlertCollationWindow?;
    get defaultSystemAlertCollationWindow(): string;
    set defaultSystemAlertCollationWindow(value: string);
    resetDefaultSystemAlertCollationWindow(): void;
    get defaultSystemAlertCollationWindowInput(): string | undefined;
    get effectiveDefaultSecurityAlertCollationWindow(): string;
    get effectiveDefaultSystemAlertCollationWindow(): string;
    get etag(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): LakewatchAlertConfigProviderConfigOutputReference;
    putProviderConfig(value: LakewatchAlertConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | LakewatchAlertConfigProviderConfig | undefined;
    private _securityAlertExportConfig;
    get securityAlertExportConfig(): LakewatchAlertConfigSecurityAlertExportConfigOutputReference;
    putSecurityAlertExportConfig(value: LakewatchAlertConfigSecurityAlertExportConfig): void;
    resetSecurityAlertExportConfig(): void;
    get securityAlertExportConfigInput(): cdktn.IResolvable | LakewatchAlertConfigSecurityAlertExportConfig | undefined;
    private _systemAlertExportConfig;
    get systemAlertExportConfig(): LakewatchAlertConfigSystemAlertExportConfigOutputReference;
    putSystemAlertExportConfig(value: LakewatchAlertConfigSystemAlertExportConfig): void;
    resetSystemAlertExportConfig(): void;
    get systemAlertExportConfigInput(): cdktn.IResolvable | LakewatchAlertConfigSystemAlertExportConfig | undefined;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): LakewatchAlertConfigUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
