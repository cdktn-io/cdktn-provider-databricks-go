/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchAlertConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#name DataDatabricksLakewatchAlertConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#provider_config DataDatabricksLakewatchAlertConfig#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchAlertConfigProviderConfig;
}
export interface DataDatabricksLakewatchAlertConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#workspace_id DataDatabricksLakewatchAlertConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchAlertConfigProviderConfigToTerraform(struct?: DataDatabricksLakewatchAlertConfigProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#api_token_uc_secret DataDatabricksLakewatchAlertConfig#api_token_uc_secret}
    */
    readonly apiTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#default_issue_type DataDatabricksLakewatchAlertConfig#default_issue_type}
    */
    readonly defaultIssueType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#instance_url DataDatabricksLakewatchAlertConfig#instance_url}
    */
    readonly instanceUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#project_key DataDatabricksLakewatchAlertConfig#project_key}
    */
    readonly projectKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#user_email DataDatabricksLakewatchAlertConfig#user_email}
    */
    readonly userEmail: string;
}
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJiraToTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJiraToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJiraOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira | cdktn.IResolvable | undefined);
    private _apiTokenUcSecret?;
    get apiTokenUcSecret(): string;
    set apiTokenUcSecret(value: string);
    get apiTokenUcSecretInput(): string | undefined;
    private _defaultIssueType?;
    get defaultIssueType(): string;
    set defaultIssueType(value: string);
    get defaultIssueTypeInput(): string | undefined;
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    get instanceUrlInput(): string | undefined;
    private _projectKey?;
    get projectKey(): string;
    set projectKey(value: string);
    get projectKeyInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string;
    set userEmail(value: string);
    get userEmailInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#client_id DataDatabricksLakewatchAlertConfig#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#client_secret_uc_secret DataDatabricksLakewatchAlertConfig#client_secret_uc_secret}
    */
    readonly clientSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#instance_id DataDatabricksLakewatchAlertConfig#instance_id}
    */
    readonly instanceId: string;
}
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNowToTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNowToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretUcSecret?;
    get clientSecretUcSecret(): string;
    set clientSecretUcSecret(value: string);
    get clientSecretUcSecretInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#bot_token_uc_secret DataDatabricksLakewatchAlertConfig#bot_token_uc_secret}
    */
    readonly botTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#channel DataDatabricksLakewatchAlertConfig#channel}
    */
    readonly channel: string;
}
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlackToTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlackToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack | cdktn.IResolvable | undefined);
    private _botTokenUcSecret?;
    get botTokenUcSecret(): string;
    set botTokenUcSecret(value: string);
    get botTokenUcSecretInput(): string | undefined;
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#export_updates DataDatabricksLakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#webhook_secret_uc_secret DataDatabricksLakewatchAlertConfig#webhook_secret_uc_secret}
    */
    readonly webhookSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#webhook_uri DataDatabricksLakewatchAlertConfig#webhook_uri}
    */
    readonly webhookUri: string;
}
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTinesToTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTinesToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTinesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _webhookSecretUcSecret?;
    get webhookSecretUcSecret(): string;
    set webhookSecretUcSecret(value: string);
    get webhookSecretUcSecretInput(): string | undefined;
    private _webhookUri?;
    get webhookUri(): string;
    set webhookUri(value: string);
    get webhookUriInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#export_updates DataDatabricksLakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#url DataDatabricksLakewatchAlertConfig#url}
    */
    readonly url?: string;
}
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhookToTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhookToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSecurityAlertExportConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#enabled DataDatabricksLakewatchAlertConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#jira DataDatabricksLakewatchAlertConfig#jira}
    */
    readonly jira?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#service_now DataDatabricksLakewatchAlertConfig#service_now}
    */
    readonly serviceNow?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#slack DataDatabricksLakewatchAlertConfig#slack}
    */
    readonly slack?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#tines DataDatabricksLakewatchAlertConfig#tines}
    */
    readonly tines?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#webhook DataDatabricksLakewatchAlertConfig#webhook}
    */
    readonly webhook?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#workspace_id DataDatabricksLakewatchAlertConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigToTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfig): any;
export declare function dataDatabricksLakewatchAlertConfigSecurityAlertExportConfigToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfig): any;
export declare class DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfig | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _jira;
    get jira(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJiraOutputReference;
    putJira(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira): void;
    resetJira(): void;
    get jiraInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigJira | undefined;
    private _serviceNow;
    get serviceNow(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNowOutputReference;
    putServiceNow(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigServiceNow | undefined;
    private _slack;
    get slack(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlackOutputReference;
    putSlack(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigSlack | undefined;
    private _tines;
    get tines(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTinesOutputReference;
    putTines(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines): void;
    resetTines(): void;
    get tinesInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigTines | undefined;
    private _webhook;
    get webhook(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhookOutputReference;
    putWebhook(value: DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook): void;
    resetWebhook(): void;
    get webhookInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigWebhook | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#api_token_uc_secret DataDatabricksLakewatchAlertConfig#api_token_uc_secret}
    */
    readonly apiTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#default_issue_type DataDatabricksLakewatchAlertConfig#default_issue_type}
    */
    readonly defaultIssueType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#instance_url DataDatabricksLakewatchAlertConfig#instance_url}
    */
    readonly instanceUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#project_key DataDatabricksLakewatchAlertConfig#project_key}
    */
    readonly projectKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#user_email DataDatabricksLakewatchAlertConfig#user_email}
    */
    readonly userEmail: string;
}
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigJiraToTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigJiraToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJiraOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira | cdktn.IResolvable | undefined);
    private _apiTokenUcSecret?;
    get apiTokenUcSecret(): string;
    set apiTokenUcSecret(value: string);
    get apiTokenUcSecretInput(): string | undefined;
    private _defaultIssueType?;
    get defaultIssueType(): string;
    set defaultIssueType(value: string);
    get defaultIssueTypeInput(): string | undefined;
    private _instanceUrl?;
    get instanceUrl(): string;
    set instanceUrl(value: string);
    get instanceUrlInput(): string | undefined;
    private _projectKey?;
    get projectKey(): string;
    set projectKey(value: string);
    get projectKeyInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string;
    set userEmail(value: string);
    get userEmailInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#client_id DataDatabricksLakewatchAlertConfig#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#client_secret_uc_secret DataDatabricksLakewatchAlertConfig#client_secret_uc_secret}
    */
    readonly clientSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#instance_id DataDatabricksLakewatchAlertConfig#instance_id}
    */
    readonly instanceId: string;
}
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNowToTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNowToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientSecretUcSecret?;
    get clientSecretUcSecret(): string;
    set clientSecretUcSecret(value: string);
    get clientSecretUcSecretInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#bot_token_uc_secret DataDatabricksLakewatchAlertConfig#bot_token_uc_secret}
    */
    readonly botTokenUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#channel DataDatabricksLakewatchAlertConfig#channel}
    */
    readonly channel: string;
}
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlackToTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlackToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack | cdktn.IResolvable | undefined);
    private _botTokenUcSecret?;
    get botTokenUcSecret(): string;
    set botTokenUcSecret(value: string);
    get botTokenUcSecretInput(): string | undefined;
    private _channel?;
    get channel(): string;
    set channel(value: string);
    get channelInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#export_updates DataDatabricksLakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#webhook_secret_uc_secret DataDatabricksLakewatchAlertConfig#webhook_secret_uc_secret}
    */
    readonly webhookSecretUcSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#webhook_uri DataDatabricksLakewatchAlertConfig#webhook_uri}
    */
    readonly webhookUri: string;
}
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigTinesToTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigTinesToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTinesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _webhookSecretUcSecret?;
    get webhookSecretUcSecret(): string;
    set webhookSecretUcSecret(value: string);
    get webhookSecretUcSecretInput(): string | undefined;
    private _webhookUri?;
    get webhookUri(): string;
    set webhookUri(value: string);
    get webhookUriInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#export_updates DataDatabricksLakewatchAlertConfig#export_updates}
    */
    readonly exportUpdates?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#url DataDatabricksLakewatchAlertConfig#url}
    */
    readonly url?: string;
}
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhookToTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhookToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhookOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook | cdktn.IResolvable | undefined);
    private _exportUpdates?;
    get exportUpdates(): boolean | cdktn.IResolvable;
    set exportUpdates(value: boolean | cdktn.IResolvable);
    resetExportUpdates(): void;
    get exportUpdatesInput(): boolean | cdktn.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigSystemAlertExportConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#enabled DataDatabricksLakewatchAlertConfig#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#jira DataDatabricksLakewatchAlertConfig#jira}
    */
    readonly jira?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#service_now DataDatabricksLakewatchAlertConfig#service_now}
    */
    readonly serviceNow?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#slack DataDatabricksLakewatchAlertConfig#slack}
    */
    readonly slack?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#tines DataDatabricksLakewatchAlertConfig#tines}
    */
    readonly tines?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#webhook DataDatabricksLakewatchAlertConfig#webhook}
    */
    readonly webhook?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#workspace_id DataDatabricksLakewatchAlertConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigToTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfig): any;
export declare function dataDatabricksLakewatchAlertConfigSystemAlertExportConfigToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigSystemAlertExportConfig): any;
export declare class DataDatabricksLakewatchAlertConfigSystemAlertExportConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfig | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _jira;
    get jira(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJiraOutputReference;
    putJira(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira): void;
    resetJira(): void;
    get jiraInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSystemAlertExportConfigJira | undefined;
    private _serviceNow;
    get serviceNow(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNowOutputReference;
    putServiceNow(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow): void;
    resetServiceNow(): void;
    get serviceNowInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSystemAlertExportConfigServiceNow | undefined;
    private _slack;
    get slack(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlackOutputReference;
    putSlack(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack): void;
    resetSlack(): void;
    get slackInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSystemAlertExportConfigSlack | undefined;
    private _tines;
    get tines(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTinesOutputReference;
    putTines(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines): void;
    resetTines(): void;
    get tinesInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSystemAlertExportConfigTines | undefined;
    private _webhook;
    get webhook(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhookOutputReference;
    putWebhook(value: DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook): void;
    resetWebhook(): void;
    get webhookInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigSystemAlertExportConfigWebhook | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchAlertConfigUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#display_name DataDatabricksLakewatchAlertConfig#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#email DataDatabricksLakewatchAlertConfig#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#id DataDatabricksLakewatchAlertConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#principal_type DataDatabricksLakewatchAlertConfig#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchAlertConfigUpdatedByToTerraform(struct?: DataDatabricksLakewatchAlertConfigUpdatedBy): any;
export declare function dataDatabricksLakewatchAlertConfigUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchAlertConfigUpdatedBy): any;
export declare class DataDatabricksLakewatchAlertConfigUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchAlertConfigUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchAlertConfigUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config databricks_lakewatch_alert_config}
*/
export declare class DataDatabricksLakewatchAlertConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_alert_config";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchAlertConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchAlertConfig to import
    * @param importFromId The id of the existing DataDatabricksLakewatchAlertConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchAlertConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_alert_config databricks_lakewatch_alert_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchAlertConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchAlertConfigConfig);
    get defaultSecurityAlertCollationWindow(): string;
    get defaultSystemAlertCollationWindow(): string;
    get effectiveDefaultSecurityAlertCollationWindow(): string;
    get effectiveDefaultSystemAlertCollationWindow(): string;
    get etag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchAlertConfigProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchAlertConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchAlertConfigProviderConfig | undefined;
    private _securityAlertExportConfig;
    get securityAlertExportConfig(): DataDatabricksLakewatchAlertConfigSecurityAlertExportConfigOutputReference;
    private _systemAlertExportConfig;
    get systemAlertExportConfig(): DataDatabricksLakewatchAlertConfigSystemAlertExportConfigOutputReference;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchAlertConfigUpdatedByOutputReference;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
