/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AssumeGroupRestrictedSharingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/assume_group_restricted_sharing_group#provider_config AssumeGroupRestrictedSharingGroup#provider_config}
    */
    readonly providerConfig?: AssumeGroupRestrictedSharingGroupProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/assume_group_restricted_sharing_group#restricted_sharing_group_id AssumeGroupRestrictedSharingGroup#restricted_sharing_group_id}
    */
    readonly restrictedSharingGroupId: string;
}
export interface AssumeGroupRestrictedSharingGroupProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/assume_group_restricted_sharing_group#workspace_id AssumeGroupRestrictedSharingGroup#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function assumeGroupRestrictedSharingGroupProviderConfigToTerraform(struct?: AssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable): any;
export declare function assumeGroupRestrictedSharingGroupProviderConfigToHclTerraform(struct?: AssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable): any;
export declare class AssumeGroupRestrictedSharingGroupProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AssumeGroupRestrictedSharingGroupProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/assume_group_restricted_sharing_group databricks_assume_group_restricted_sharing_group}
*/
export declare class AssumeGroupRestrictedSharingGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_assume_group_restricted_sharing_group";
    /**
    * Generates CDKTN code for importing a AssumeGroupRestrictedSharingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AssumeGroupRestrictedSharingGroup to import
    * @param importFromId The id of the existing AssumeGroupRestrictedSharingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/assume_group_restricted_sharing_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AssumeGroupRestrictedSharingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/assume_group_restricted_sharing_group databricks_assume_group_restricted_sharing_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AssumeGroupRestrictedSharingGroupConfig
    */
    constructor(scope: Construct, id: string, config: AssumeGroupRestrictedSharingGroupConfig);
    get groupDisplayName(): string;
    get name(): string;
    private _providerConfig;
    get providerConfig(): AssumeGroupRestrictedSharingGroupProviderConfigOutputReference;
    putProviderConfig(value: AssumeGroupRestrictedSharingGroupProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AssumeGroupRestrictedSharingGroupProviderConfig | undefined;
    private _restrictedSharingGroupId?;
    get restrictedSharingGroupId(): string;
    set restrictedSharingGroupId(value: string);
    get restrictedSharingGroupIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
