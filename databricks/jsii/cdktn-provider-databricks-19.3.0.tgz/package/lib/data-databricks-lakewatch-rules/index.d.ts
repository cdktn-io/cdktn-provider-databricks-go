/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#catalog_name DataDatabricksLakewatchRules#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#filter DataDatabricksLakewatchRules#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#page_size DataDatabricksLakewatchRules#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#provider_config DataDatabricksLakewatchRules#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchRulesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#schema_name DataDatabricksLakewatchRules#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#view DataDatabricksLakewatchRules#view}
    */
    readonly view?: string;
}
export interface DataDatabricksLakewatchRulesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#workspace_id DataDatabricksLakewatchRules#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchRulesProviderConfigToTerraform(struct?: DataDatabricksLakewatchRulesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRulesProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchRulesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRulesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesBatchCustom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#notebook DataDatabricksLakewatchRules#notebook}
    */
    readonly notebook: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#options DataDatabricksLakewatchRules#options}
    */
    readonly options?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksLakewatchRulesRulesBatchCustomToTerraform(struct?: DataDatabricksLakewatchRulesRulesBatchCustom | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRulesRulesBatchCustomToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesBatchCustom | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRulesRulesBatchCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesBatchCustom | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesBatchCustom | cdktn.IResolvable | undefined);
    private _notebook?;
    get notebook(): string;
    set notebook(value: string);
    get notebookInput(): string | undefined;
    private _options?;
    get options(): {
        [key: string]: string;
    };
    set options(value: {
        [key: string]: string;
    });
    resetOptions(): void;
    get optionsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksLakewatchRulesRulesBatchSql {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#default_catalog_name DataDatabricksLakewatchRules#default_catalog_name}
    */
    readonly defaultCatalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#default_schema_name DataDatabricksLakewatchRules#default_schema_name}
    */
    readonly defaultSchemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#query DataDatabricksLakewatchRules#query}
    */
    readonly query: string;
}
export declare function dataDatabricksLakewatchRulesRulesBatchSqlToTerraform(struct?: DataDatabricksLakewatchRulesRulesBatchSql | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRulesRulesBatchSqlToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesBatchSql | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRulesRulesBatchSqlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesBatchSql | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesBatchSql | cdktn.IResolvable | undefined);
    private _defaultCatalogName?;
    get defaultCatalogName(): string;
    set defaultCatalogName(value: string);
    resetDefaultCatalogName(): void;
    get defaultCatalogNameInput(): string | undefined;
    private _defaultSchemaName?;
    get defaultSchemaName(): string;
    set defaultSchemaName(value: string);
    resetDefaultSchemaName(): void;
    get defaultSchemaNameInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    get queryInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesBatch {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#custom DataDatabricksLakewatchRules#custom}
    */
    readonly custom?: DataDatabricksLakewatchRulesRulesBatchCustom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#sql DataDatabricksLakewatchRules#sql}
    */
    readonly sql?: DataDatabricksLakewatchRulesRulesBatchSql;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#warehouse_id DataDatabricksLakewatchRules#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksLakewatchRulesRulesBatchToTerraform(struct?: DataDatabricksLakewatchRulesRulesBatch): any;
export declare function dataDatabricksLakewatchRulesRulesBatchToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesBatch): any;
export declare class DataDatabricksLakewatchRulesRulesBatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesBatch | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesBatch | undefined);
    private _custom;
    get custom(): DataDatabricksLakewatchRulesRulesBatchCustomOutputReference;
    putCustom(value: DataDatabricksLakewatchRulesRulesBatchCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | DataDatabricksLakewatchRulesRulesBatchCustom | undefined;
    private _sql;
    get sql(): DataDatabricksLakewatchRulesRulesBatchSqlOutputReference;
    putSql(value: DataDatabricksLakewatchRulesRulesBatchSql): void;
    resetSql(): void;
    get sqlInput(): cdktn.IResolvable | DataDatabricksLakewatchRulesRulesBatchSql | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#display_name DataDatabricksLakewatchRules#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#email DataDatabricksLakewatchRules#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#id DataDatabricksLakewatchRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#principal_type DataDatabricksLakewatchRules#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchRulesRulesCreatedByToTerraform(struct?: DataDatabricksLakewatchRulesRulesCreatedBy): any;
export declare function dataDatabricksLakewatchRulesRulesCreatedByToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesCreatedBy): any;
export declare class DataDatabricksLakewatchRulesRulesCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesCreatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesMitre {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#sub_technique DataDatabricksLakewatchRules#sub_technique}
    */
    readonly subTechnique?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#sub_technique_id DataDatabricksLakewatchRules#sub_technique_id}
    */
    readonly subTechniqueId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#tactic DataDatabricksLakewatchRules#tactic}
    */
    readonly tactic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#taxonomy DataDatabricksLakewatchRules#taxonomy}
    */
    readonly taxonomy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#technique DataDatabricksLakewatchRules#technique}
    */
    readonly technique?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#technique_id DataDatabricksLakewatchRules#technique_id}
    */
    readonly techniqueId?: string;
}
export declare function dataDatabricksLakewatchRulesRulesMitreToTerraform(struct?: DataDatabricksLakewatchRulesRulesMitre): any;
export declare function dataDatabricksLakewatchRulesRulesMitreToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesMitre): any;
export declare class DataDatabricksLakewatchRulesRulesMitreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchRulesRulesMitre | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesMitre | undefined);
    private _subTechnique?;
    get subTechnique(): string;
    set subTechnique(value: string);
    resetSubTechnique(): void;
    get subTechniqueInput(): string | undefined;
    private _subTechniqueId?;
    get subTechniqueId(): string;
    set subTechniqueId(value: string);
    resetSubTechniqueId(): void;
    get subTechniqueIdInput(): string | undefined;
    private _tactic?;
    get tactic(): string;
    set tactic(value: string);
    resetTactic(): void;
    get tacticInput(): string | undefined;
    private _taxonomy?;
    get taxonomy(): string;
    set taxonomy(value: string);
    resetTaxonomy(): void;
    get taxonomyInput(): string | undefined;
    private _technique?;
    get technique(): string;
    set technique(value: string);
    resetTechnique(): void;
    get techniqueInput(): string | undefined;
    private _techniqueId?;
    get techniqueId(): string;
    set techniqueId(value: string);
    resetTechniqueId(): void;
    get techniqueIdInput(): string | undefined;
}
export declare class DataDatabricksLakewatchRulesRulesMitreList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchRulesRulesMitre[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchRulesRulesMitreOutputReference;
}
export interface DataDatabricksLakewatchRulesRulesOriginalContentPack {
}
export declare function dataDatabricksLakewatchRulesRulesOriginalContentPackToTerraform(struct?: DataDatabricksLakewatchRulesRulesOriginalContentPack): any;
export declare function dataDatabricksLakewatchRulesRulesOriginalContentPackToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesOriginalContentPack): any;
export declare class DataDatabricksLakewatchRulesRulesOriginalContentPackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesOriginalContentPack | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesOriginalContentPack | undefined);
    get uuid(): string;
    get version(): string;
}
export interface DataDatabricksLakewatchRulesRulesOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#context DataDatabricksLakewatchRules#context}
    */
    readonly context?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#default_context DataDatabricksLakewatchRules#default_context}
    */
    readonly defaultContext?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#event_time_column DataDatabricksLakewatchRules#event_time_column}
    */
    readonly eventTimeColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#summary DataDatabricksLakewatchRules#summary}
    */
    readonly summary?: string;
}
export declare function dataDatabricksLakewatchRulesRulesOutputToTerraform(struct?: DataDatabricksLakewatchRulesRulesOutput): any;
export declare function dataDatabricksLakewatchRulesRulesOutputToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesOutput): any;
export declare class DataDatabricksLakewatchRulesRulesOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesOutput | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesOutput | undefined);
    private _context?;
    get context(): {
        [key: string]: string;
    };
    set context(value: {
        [key: string]: string;
    });
    resetContext(): void;
    get contextInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultContext?;
    get defaultContext(): boolean | cdktn.IResolvable;
    set defaultContext(value: boolean | cdktn.IResolvable);
    resetDefaultContext(): void;
    get defaultContextInput(): boolean | cdktn.IResolvable | undefined;
    private _eventTimeColumn?;
    get eventTimeColumn(): string;
    set eventTimeColumn(value: string);
    resetEventTimeColumn(): void;
    get eventTimeColumnInput(): string | undefined;
    private _summary?;
    get summary(): string;
    set summary(value: string);
    resetSummary(): void;
    get summaryInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesOwner {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#display_name DataDatabricksLakewatchRules#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#email DataDatabricksLakewatchRules#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#id DataDatabricksLakewatchRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#principal_type DataDatabricksLakewatchRules#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchRulesRulesOwnerToTerraform(struct?: DataDatabricksLakewatchRulesRulesOwner): any;
export declare function dataDatabricksLakewatchRulesRulesOwnerToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesOwner): any;
export declare class DataDatabricksLakewatchRulesRulesOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesOwner | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesOwner | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#workspace_id DataDatabricksLakewatchRules#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchRulesRulesProviderConfigToTerraform(struct?: DataDatabricksLakewatchRulesRulesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchRulesRulesProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchRulesRulesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#at_least_every DataDatabricksLakewatchRules#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#cron_expression DataDatabricksLakewatchRules#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#enabled DataDatabricksLakewatchRules#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksLakewatchRulesRulesScheduleToTerraform(struct?: DataDatabricksLakewatchRulesRulesSchedule): any;
export declare function dataDatabricksLakewatchRulesRulesScheduleToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesSchedule): any;
export declare class DataDatabricksLakewatchRulesRulesScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesSchedule | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesSchedule | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksLakewatchRulesRulesStatus {
}
export declare function dataDatabricksLakewatchRulesRulesStatusToTerraform(struct?: DataDatabricksLakewatchRulesRulesStatus): any;
export declare function dataDatabricksLakewatchRulesRulesStatusToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesStatus): any;
export declare class DataDatabricksLakewatchRulesRulesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesStatus | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesStatus | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface DataDatabricksLakewatchRulesRulesTimerange {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#extend_lookback DataDatabricksLakewatchRules#extend_lookback}
    */
    readonly extendLookback?: string;
}
export declare function dataDatabricksLakewatchRulesRulesTimerangeToTerraform(struct?: DataDatabricksLakewatchRulesRulesTimerange): any;
export declare function dataDatabricksLakewatchRulesRulesTimerangeToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesTimerange): any;
export declare class DataDatabricksLakewatchRulesRulesTimerangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesTimerange | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesTimerange | undefined);
    private _extendLookback?;
    get extendLookback(): string;
    set extendLookback(value: string);
    resetExtendLookback(): void;
    get extendLookbackInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRulesUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#display_name DataDatabricksLakewatchRules#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#email DataDatabricksLakewatchRules#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#id DataDatabricksLakewatchRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#principal_type DataDatabricksLakewatchRules#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchRulesRulesUpdatedByToTerraform(struct?: DataDatabricksLakewatchRulesRulesUpdatedBy): any;
export declare function dataDatabricksLakewatchRulesRulesUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchRulesRulesUpdatedBy): any;
export declare class DataDatabricksLakewatchRulesRulesUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchRulesRulesUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRulesUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchRulesRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#name DataDatabricksLakewatchRules#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#provider_config DataDatabricksLakewatchRules#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchRulesRulesProviderConfig;
}
export declare function dataDatabricksLakewatchRulesRulesToTerraform(struct?: DataDatabricksLakewatchRulesRules): any;
export declare function dataDatabricksLakewatchRulesRulesToHclTerraform(struct?: DataDatabricksLakewatchRulesRules): any;
export declare class DataDatabricksLakewatchRulesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchRulesRules | undefined;
    set internalValue(value: DataDatabricksLakewatchRulesRules | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _batch;
    get batch(): DataDatabricksLakewatchRulesRulesBatchOutputReference;
    get catalogName(): string;
    get category(): string;
    get computeWorkspaceId(): string;
    get contentResourceId(): string;
    get createTime(): string;
    private _createdBy;
    get createdBy(): DataDatabricksLakewatchRulesRulesCreatedByOutputReference;
    get deduplication(): string;
    get deduplicationTimeWindow(): string;
    get description(): string;
    get effectiveCatalogName(): string;
    get effectiveRuleName(): string;
    get effectiveRunAsPrincipal(): string;
    get effectiveSchemaName(): string;
    get etag(): string;
    get fidelity(): string;
    private _mitre;
    get mitre(): DataDatabricksLakewatchRulesRulesMitreList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get objective(): string;
    private _originalContentPack;
    get originalContentPack(): DataDatabricksLakewatchRulesRulesOriginalContentPackOutputReference;
    private _output;
    get output(): DataDatabricksLakewatchRulesRulesOutputOutputReference;
    private _owner;
    get owner(): DataDatabricksLakewatchRulesRulesOwnerOutputReference;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchRulesRulesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchRulesRulesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchRulesRulesProviderConfig | undefined;
    get references(): string[];
    get ruleId(): string;
    get ruleName(): string;
    get runAsPrincipal(): string;
    get runbook(): string;
    private _schedule;
    get schedule(): DataDatabricksLakewatchRulesRulesScheduleOutputReference;
    get schemaName(): string;
    get severity(): string;
    private _status;
    get status(): DataDatabricksLakewatchRulesRulesStatusOutputReference;
    get suppressUntilTime(): string;
    private _timerange;
    get timerange(): DataDatabricksLakewatchRulesRulesTimerangeOutputReference;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchRulesRulesUpdatedByOutputReference;
    get version(): number;
}
export declare class DataDatabricksLakewatchRulesRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchRulesRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchRulesRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules databricks_lakewatch_rules}
*/
export declare class DataDatabricksLakewatchRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_rules";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchRules to import
    * @param importFromId The id of the existing DataDatabricksLakewatchRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_rules databricks_lakewatch_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchRulesConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchRulesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchRulesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchRulesProviderConfig | undefined;
    private _rules;
    get rules(): DataDatabricksLakewatchRulesRulesList;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
