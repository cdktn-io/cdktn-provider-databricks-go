/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchBuiltinParserVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#page_size DataDatabricksLakewatchBuiltinParserVersions#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#parent DataDatabricksLakewatchBuiltinParserVersions#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#provider_config DataDatabricksLakewatchBuiltinParserVersions#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchBuiltinParserVersionsProviderConfig;
}
export interface DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#workspace_id DataDatabricksLakewatchBuiltinParserVersions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfigToTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#key DataDatabricksLakewatchBuiltinParserVersions#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#value DataDatabricksLakewatchBuiltinParserVersions#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTagsToTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTags): any;
export declare function dataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTagsToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTags): any;
export declare class DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTags | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTagsOutputReference;
}
export interface DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#name DataDatabricksLakewatchBuiltinParserVersions#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#provider_config DataDatabricksLakewatchBuiltinParserVersions#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig;
}
export declare function dataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsToTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersions): any;
export declare function dataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersions): any;
export declare class DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersions | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersions | undefined);
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parserName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsProviderConfig | undefined;
    get spec(): string;
    private _tags;
    get tags(): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsTagsList;
    get version(): number;
}
export declare class DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsOutputReference;
}
export interface DataDatabricksLakewatchBuiltinParserVersionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#workspace_id DataDatabricksLakewatchBuiltinParserVersions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchBuiltinParserVersionsProviderConfigToTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchBuiltinParserVersionsProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserVersionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchBuiltinParserVersionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchBuiltinParserVersionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserVersionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions databricks_lakewatch_builtin_parser_versions}
*/
export declare class DataDatabricksLakewatchBuiltinParserVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_builtin_parser_versions";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchBuiltinParserVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchBuiltinParserVersions to import
    * @param importFromId The id of the existing DataDatabricksLakewatchBuiltinParserVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchBuiltinParserVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser_versions databricks_lakewatch_builtin_parser_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchBuiltinParserVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchBuiltinParserVersionsConfig);
    private _builtinParserVersions;
    get builtinParserVersions(): DataDatabricksLakewatchBuiltinParserVersionsBuiltinParserVersionsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchBuiltinParserVersionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchBuiltinParserVersionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchBuiltinParserVersionsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
