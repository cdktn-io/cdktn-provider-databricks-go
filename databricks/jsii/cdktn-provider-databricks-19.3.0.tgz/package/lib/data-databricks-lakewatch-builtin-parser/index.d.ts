/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchBuiltinParserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser#name DataDatabricksLakewatchBuiltinParser#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser#provider_config DataDatabricksLakewatchBuiltinParser#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchBuiltinParserProviderConfig;
}
export interface DataDatabricksLakewatchBuiltinParserProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser#workspace_id DataDatabricksLakewatchBuiltinParser#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchBuiltinParserProviderConfigToTerraform(struct?: DataDatabricksLakewatchBuiltinParserProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchBuiltinParserProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchBuiltinParserProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchBuiltinParserProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchBuiltinParserTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser#key DataDatabricksLakewatchBuiltinParser#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser#value DataDatabricksLakewatchBuiltinParser#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksLakewatchBuiltinParserTagsToTerraform(struct?: DataDatabricksLakewatchBuiltinParserTags): any;
export declare function dataDatabricksLakewatchBuiltinParserTagsToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParserTags): any;
export declare class DataDatabricksLakewatchBuiltinParserTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchBuiltinParserTags | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParserTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksLakewatchBuiltinParserTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchBuiltinParserTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchBuiltinParserTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser databricks_lakewatch_builtin_parser}
*/
export declare class DataDatabricksLakewatchBuiltinParser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_builtin_parser";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchBuiltinParser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchBuiltinParser to import
    * @param importFromId The id of the existing DataDatabricksLakewatchBuiltinParser that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchBuiltinParser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parser databricks_lakewatch_builtin_parser} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchBuiltinParserConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchBuiltinParserConfig);
    get latestVersion(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parserId(): string;
    get parserName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchBuiltinParserProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchBuiltinParserProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchBuiltinParserProviderConfig | undefined;
    private _tags;
    get tags(): DataDatabricksLakewatchBuiltinParserTagsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
