/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchParserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#name DataDatabricksLakewatchParser#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#provider_config DataDatabricksLakewatchParser#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchParserProviderConfig;
}
export interface DataDatabricksLakewatchParserCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#display_name DataDatabricksLakewatchParser#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#email DataDatabricksLakewatchParser#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#id DataDatabricksLakewatchParser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#principal_type DataDatabricksLakewatchParser#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchParserCreatedByToTerraform(struct?: DataDatabricksLakewatchParserCreatedBy): any;
export declare function dataDatabricksLakewatchParserCreatedByToHclTerraform(struct?: DataDatabricksLakewatchParserCreatedBy): any;
export declare class DataDatabricksLakewatchParserCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserCreatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchParserCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchParserOwner {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#display_name DataDatabricksLakewatchParser#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#email DataDatabricksLakewatchParser#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#id DataDatabricksLakewatchParser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#principal_type DataDatabricksLakewatchParser#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchParserOwnerToTerraform(struct?: DataDatabricksLakewatchParserOwner): any;
export declare function dataDatabricksLakewatchParserOwnerToHclTerraform(struct?: DataDatabricksLakewatchParserOwner): any;
export declare class DataDatabricksLakewatchParserOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserOwner | undefined;
    set internalValue(value: DataDatabricksLakewatchParserOwner | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchParserProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#workspace_id DataDatabricksLakewatchParser#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchParserProviderConfigToTerraform(struct?: DataDatabricksLakewatchParserProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchParserProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchParserProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchParserProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchParserProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchParserProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser databricks_lakewatch_parser}
*/
export declare class DataDatabricksLakewatchParser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_parser";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchParser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchParser to import
    * @param importFromId The id of the existing DataDatabricksLakewatchParser that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchParser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_parser databricks_lakewatch_parser} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchParserConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchParserConfig);
    get catalogName(): string;
    get createTime(): string;
    private _createdBy;
    get createdBy(): DataDatabricksLakewatchParserCreatedByOutputReference;
    get description(): string;
    get effectiveCatalogName(): string;
    get effectiveSchemaName(): string;
    get latestVersion(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner;
    get owner(): DataDatabricksLakewatchParserOwnerOutputReference;
    get parserId(): string;
    get parserName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchParserProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchParserProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchParserProviderConfig | undefined;
    get schemaName(): string;
    get spec(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
