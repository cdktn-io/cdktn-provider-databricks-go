/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { JobTaskNewClusterAutoscale, JobTaskNewClusterAutoscaleOutputReference, JobTaskNewClusterAwsAttributes, JobTaskNewClusterAwsAttributesOutputReference, JobTaskNewClusterAzureAttributes, JobTaskNewClusterAzureAttributesOutputReference, JobTaskNewClusterClusterLogConf, JobTaskNewClusterClusterLogConfOutputReference, JobTaskNewClusterClusterMountInfo, JobTaskNewClusterClusterMountInfoList, JobTaskNewClusterDockerImage, JobTaskNewClusterDockerImageOutputReference, JobTaskDependsOn, JobTaskDependsOnList, JobTaskEmailNotifications, JobTaskEmailNotificationsOutputReference, JobTaskForEachTask, JobTaskForEachTaskOutputReference, JobTaskGenAiComputeTask, JobTaskGenAiComputeTaskOutputReference, JobTaskHealth, JobTaskHealthOutputReference, JobTaskLibrary, JobTaskLibraryList } from './structs400';
import { JobTaskAiFunctionTask, JobTaskAiFunctionTaskOutputReference, JobTaskAiRuntimeTask, JobTaskAiRuntimeTaskOutputReference, JobTaskAlertTask, JobTaskAlertTaskOutputReference, JobTaskCleanRoomsNotebookTask, JobTaskCleanRoomsNotebookTaskOutputReference, JobTaskCompute, JobTaskComputeOutputReference, JobTaskConditionTask, JobTaskConditionTaskOutputReference, JobTaskDashboardTask, JobTaskDashboardTaskOutputReference, JobTaskDbtCloudTask, JobTaskDbtCloudTaskOutputReference, JobTaskDbtPlatformTask, JobTaskDbtPlatformTaskOutputReference, JobTaskDbtTask, JobTaskDbtTaskOutputReference } from './structs0';
export interface JobTaskNewClusterDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#aws_context_id Job#aws_context_id}
    */
    readonly awsContextId?: string;
}
export declare function jobTaskNewClusterDriverNodeTypeFlexibilityToTerraform(struct?: JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference | JobTaskNewClusterDriverNodeTypeFlexibility): any;
export declare function jobTaskNewClusterDriverNodeTypeFlexibilityToHclTerraform(struct?: JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference | JobTaskNewClusterDriverNodeTypeFlexibility): any;
export declare class JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterDriverNodeTypeFlexibility | undefined;
    set internalValue(value: JobTaskNewClusterDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
    private _awsContextId?;
    get awsContextId(): string;
    set awsContextId(value: string);
    resetAwsContextId(): void;
    get awsContextIdInput(): string | undefined;
}
export interface JobTaskNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#boot_disk_size Job#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#confidential_compute_type Job#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#google_service_account Job#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#local_ssd_count Job#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#use_preemptible_executors Job#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobTaskNewClusterGcpAttributesToTerraform(struct?: JobTaskNewClusterGcpAttributesOutputReference | JobTaskNewClusterGcpAttributes): any;
export declare function jobTaskNewClusterGcpAttributesToHclTerraform(struct?: JobTaskNewClusterGcpAttributesOutputReference | JobTaskNewClusterGcpAttributes): any;
export declare class JobTaskNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterGcpAttributes | undefined;
    set internalValue(value: JobTaskNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsAbfssToTerraform(struct?: JobTaskNewClusterInitScriptsAbfssOutputReference | JobTaskNewClusterInitScriptsAbfss): any;
export declare function jobTaskNewClusterInitScriptsAbfssToHclTerraform(struct?: JobTaskNewClusterInitScriptsAbfssOutputReference | JobTaskNewClusterInitScriptsAbfss): any;
export declare class JobTaskNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsDbfsToTerraform(struct?: JobTaskNewClusterInitScriptsDbfsOutputReference | JobTaskNewClusterInitScriptsDbfs): any;
export declare function jobTaskNewClusterInitScriptsDbfsToHclTerraform(struct?: JobTaskNewClusterInitScriptsDbfsOutputReference | JobTaskNewClusterInitScriptsDbfs): any;
export declare class JobTaskNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsFileToTerraform(struct?: JobTaskNewClusterInitScriptsFileOutputReference | JobTaskNewClusterInitScriptsFile): any;
export declare function jobTaskNewClusterInitScriptsFileToHclTerraform(struct?: JobTaskNewClusterInitScriptsFileOutputReference | JobTaskNewClusterInitScriptsFile): any;
export declare class JobTaskNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsFile | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsGcsToTerraform(struct?: JobTaskNewClusterInitScriptsGcsOutputReference | JobTaskNewClusterInitScriptsGcs): any;
export declare function jobTaskNewClusterInitScriptsGcsToHclTerraform(struct?: JobTaskNewClusterInitScriptsGcsOutputReference | JobTaskNewClusterInitScriptsGcs): any;
export declare class JobTaskNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsGcs | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobTaskNewClusterInitScriptsS3ToTerraform(struct?: JobTaskNewClusterInitScriptsS3OutputReference | JobTaskNewClusterInitScriptsS3): any;
export declare function jobTaskNewClusterInitScriptsS3ToHclTerraform(struct?: JobTaskNewClusterInitScriptsS3OutputReference | JobTaskNewClusterInitScriptsS3): any;
export declare class JobTaskNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsS3 | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsVolumesToTerraform(struct?: JobTaskNewClusterInitScriptsVolumesOutputReference | JobTaskNewClusterInitScriptsVolumes): any;
export declare function jobTaskNewClusterInitScriptsVolumesToHclTerraform(struct?: JobTaskNewClusterInitScriptsVolumesOutputReference | JobTaskNewClusterInitScriptsVolumes): any;
export declare class JobTaskNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsWorkspaceToTerraform(struct?: JobTaskNewClusterInitScriptsWorkspaceOutputReference | JobTaskNewClusterInitScriptsWorkspace): any;
export declare function jobTaskNewClusterInitScriptsWorkspaceToHclTerraform(struct?: JobTaskNewClusterInitScriptsWorkspaceOutputReference | JobTaskNewClusterInitScriptsWorkspace): any;
export declare class JobTaskNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#abfss Job#abfss}
    */
    readonly abfss?: JobTaskNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobTaskNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobTaskNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#gcs Job#gcs}
    */
    readonly gcs?: JobTaskNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobTaskNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobTaskNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#workspace Job#workspace}
    */
    readonly workspace?: JobTaskNewClusterInitScriptsWorkspace;
}
export declare function jobTaskNewClusterInitScriptsToTerraform(struct?: JobTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare function jobTaskNewClusterInitScriptsToHclTerraform(struct?: JobTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare class JobTaskNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): JobTaskNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: JobTaskNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): JobTaskNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): JobTaskNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: JobTaskNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobTaskNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): JobTaskNewClusterInitScriptsFileOutputReference;
    putFile(value: JobTaskNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): JobTaskNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): JobTaskNewClusterInitScriptsGcsOutputReference;
    putGcs(value: JobTaskNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): JobTaskNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): JobTaskNewClusterInitScriptsS3OutputReference;
    putS3(value: JobTaskNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): JobTaskNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): JobTaskNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: JobTaskNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobTaskNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): JobTaskNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: JobTaskNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): JobTaskNewClusterInitScriptsWorkspace | undefined;
}
export declare class JobTaskNewClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: JobTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskNewClusterInitScriptsOutputReference;
}
export interface JobTaskNewClusterLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskNewClusterLibraryCranToTerraform(struct?: JobTaskNewClusterLibraryCranOutputReference | JobTaskNewClusterLibraryCran): any;
export declare function jobTaskNewClusterLibraryCranToHclTerraform(struct?: JobTaskNewClusterLibraryCranOutputReference | JobTaskNewClusterLibraryCran): any;
export declare class JobTaskNewClusterLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryCran | undefined;
    set internalValue(value: JobTaskNewClusterLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskNewClusterLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskNewClusterLibraryMavenToTerraform(struct?: JobTaskNewClusterLibraryMavenOutputReference | JobTaskNewClusterLibraryMaven): any;
export declare function jobTaskNewClusterLibraryMavenToHclTerraform(struct?: JobTaskNewClusterLibraryMavenOutputReference | JobTaskNewClusterLibraryMaven): any;
export declare class JobTaskNewClusterLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryMaven | undefined;
    set internalValue(value: JobTaskNewClusterLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskNewClusterLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskNewClusterLibraryProviderConfigToTerraform(struct?: JobTaskNewClusterLibraryProviderConfigOutputReference | JobTaskNewClusterLibraryProviderConfig): any;
export declare function jobTaskNewClusterLibraryProviderConfigToHclTerraform(struct?: JobTaskNewClusterLibraryProviderConfigOutputReference | JobTaskNewClusterLibraryProviderConfig): any;
export declare class JobTaskNewClusterLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryProviderConfig | undefined;
    set internalValue(value: JobTaskNewClusterLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskNewClusterLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskNewClusterLibraryPypiToTerraform(struct?: JobTaskNewClusterLibraryPypiOutputReference | JobTaskNewClusterLibraryPypi): any;
export declare function jobTaskNewClusterLibraryPypiToHclTerraform(struct?: JobTaskNewClusterLibraryPypiOutputReference | JobTaskNewClusterLibraryPypi): any;
export declare class JobTaskNewClusterLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryPypi | undefined;
    set internalValue(value: JobTaskNewClusterLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskNewClusterLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobTaskNewClusterLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobTaskNewClusterLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskNewClusterLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobTaskNewClusterLibraryPypi;
}
export declare function jobTaskNewClusterLibraryToTerraform(struct?: JobTaskNewClusterLibrary | cdktn.IResolvable): any;
export declare function jobTaskNewClusterLibraryToHclTerraform(struct?: JobTaskNewClusterLibrary | cdktn.IResolvable): any;
export declare class JobTaskNewClusterLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskNewClusterLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskNewClusterLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobTaskNewClusterLibraryCranOutputReference;
    putCran(value: JobTaskNewClusterLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobTaskNewClusterLibraryCran | undefined;
    private _maven;
    get maven(): JobTaskNewClusterLibraryMavenOutputReference;
    putMaven(value: JobTaskNewClusterLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobTaskNewClusterLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskNewClusterLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobTaskNewClusterLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskNewClusterLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobTaskNewClusterLibraryPypiOutputReference;
    putPypi(value: JobTaskNewClusterLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobTaskNewClusterLibraryPypi | undefined;
}
export declare class JobTaskNewClusterLibraryList extends cdktn.ComplexList {
    internalValue?: JobTaskNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskNewClusterLibraryOutputReference;
}
export interface JobTaskNewClusterProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskNewClusterProviderConfigToTerraform(struct?: JobTaskNewClusterProviderConfigOutputReference | JobTaskNewClusterProviderConfig): any;
export declare function jobTaskNewClusterProviderConfigToHclTerraform(struct?: JobTaskNewClusterProviderConfigOutputReference | JobTaskNewClusterProviderConfig): any;
export declare class JobTaskNewClusterProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterProviderConfig | undefined;
    set internalValue(value: JobTaskNewClusterProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskNewClusterWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#aws_context_id Job#aws_context_id}
    */
    readonly awsContextId?: string;
}
export declare function jobTaskNewClusterWorkerNodeTypeFlexibilityToTerraform(struct?: JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference | JobTaskNewClusterWorkerNodeTypeFlexibility): any;
export declare function jobTaskNewClusterWorkerNodeTypeFlexibilityToHclTerraform(struct?: JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference | JobTaskNewClusterWorkerNodeTypeFlexibility): any;
export declare class JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: JobTaskNewClusterWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
    private _awsContextId?;
    get awsContextId(): string;
    set awsContextId(value: string);
    resetAwsContextId(): void;
    get awsContextIdInput(): string | undefined;
}
export interface JobTaskNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#jobs Job#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#notebooks Job#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function jobTaskNewClusterWorkloadTypeClientsToTerraform(struct?: JobTaskNewClusterWorkloadTypeClientsOutputReference | JobTaskNewClusterWorkloadTypeClients): any;
export declare function jobTaskNewClusterWorkloadTypeClientsToHclTerraform(struct?: JobTaskNewClusterWorkloadTypeClientsOutputReference | JobTaskNewClusterWorkloadTypeClients): any;
export declare class JobTaskNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: JobTaskNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#clients Job#clients}
    */
    readonly clients: JobTaskNewClusterWorkloadTypeClients;
}
export declare function jobTaskNewClusterWorkloadTypeToTerraform(struct?: JobTaskNewClusterWorkloadTypeOutputReference | JobTaskNewClusterWorkloadType): any;
export declare function jobTaskNewClusterWorkloadTypeToHclTerraform(struct?: JobTaskNewClusterWorkloadTypeOutputReference | JobTaskNewClusterWorkloadType): any;
export declare class JobTaskNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterWorkloadType | undefined;
    set internalValue(value: JobTaskNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): JobTaskNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: JobTaskNewClusterWorkloadTypeClients): void;
    get clientsInput(): JobTaskNewClusterWorkloadTypeClients | undefined;
}
export interface JobTaskNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#__apply_policy_default_values_allow_list Job#__apply_policy_default_values_allow_list}
    */
    readonly applyPolicyDefaultValuesAllowList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#apply_policy_default_values Job#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#cluster_id Job#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#cluster_name Job#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#custom_tags Job#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#data_security_mode Job#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dependency_mode Job#dependency_mode}
    */
    readonly dependencyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#driver_instance_pool_id Job#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#driver_node_type_id Job#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#enable_elastic_disk Job#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#enable_local_disk_encryption Job#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#idempotency_token Job#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#instance_pool_id Job#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#is_single_node Job#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#kind Job#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#node_type_id Job#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#num_workers Job#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#policy_id Job#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#remote_disk_throughput Job#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#runtime_engine Job#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#single_user_name Job#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#spark_conf Job#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#spark_env_vars Job#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#spark_version Job#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#ssh_public_keys Job#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#total_initial_remote_disk_size Job#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#use_ml_runtime Job#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#autoscale Job#autoscale}
    */
    readonly autoscale?: JobTaskNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#aws_attributes Job#aws_attributes}
    */
    readonly awsAttributes?: JobTaskNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#azure_attributes Job#azure_attributes}
    */
    readonly azureAttributes?: JobTaskNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#cluster_log_conf Job#cluster_log_conf}
    */
    readonly clusterLogConf?: JobTaskNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#cluster_mount_info Job#cluster_mount_info}
    */
    readonly clusterMountInfo?: JobTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#docker_image Job#docker_image}
    */
    readonly dockerImage?: JobTaskNewClusterDockerImage;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#driver_node_type_flexibility Job#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: JobTaskNewClusterDriverNodeTypeFlexibility;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#gcp_attributes Job#gcp_attributes}
    */
    readonly gcpAttributes?: JobTaskNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#init_scripts Job#init_scripts}
    */
    readonly initScripts?: JobTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobTaskNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskNewClusterProviderConfig;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#worker_node_type_flexibility Job#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: JobTaskNewClusterWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#workload_type Job#workload_type}
    */
    readonly workloadType?: JobTaskNewClusterWorkloadType;
}
export declare function jobTaskNewClusterToTerraform(struct?: JobTaskNewClusterOutputReference | JobTaskNewCluster): any;
export declare function jobTaskNewClusterToHclTerraform(struct?: JobTaskNewClusterOutputReference | JobTaskNewCluster): any;
export declare class JobTaskNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewCluster | undefined;
    set internalValue(value: JobTaskNewCluster | undefined);
    private _applyPolicyDefaultValuesAllowList?;
    get applyPolicyDefaultValuesAllowList(): string[];
    set applyPolicyDefaultValuesAllowList(value: string[]);
    resetApplyPolicyDefaultValuesAllowList(): void;
    get applyPolicyDefaultValuesAllowListInput(): string[] | undefined;
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _dependencyMode?;
    get dependencyMode(): string;
    set dependencyMode(value: string);
    resetDependencyMode(): void;
    get dependencyModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): JobTaskNewClusterAutoscaleOutputReference;
    putAutoscale(value: JobTaskNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): JobTaskNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): JobTaskNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: JobTaskNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): JobTaskNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): JobTaskNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: JobTaskNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): JobTaskNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): JobTaskNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: JobTaskNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): JobTaskNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): JobTaskNewClusterClusterMountInfoList;
    putClusterMountInfo(value: JobTaskNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | JobTaskNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): JobTaskNewClusterDockerImageOutputReference;
    putDockerImage(value: JobTaskNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): JobTaskNewClusterDockerImage | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: JobTaskNewClusterDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): JobTaskNewClusterDriverNodeTypeFlexibility | undefined;
    private _gcpAttributes;
    get gcpAttributes(): JobTaskNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: JobTaskNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): JobTaskNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): JobTaskNewClusterInitScriptsList;
    putInitScripts(value: JobTaskNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | JobTaskNewClusterInitScripts[] | undefined;
    private _library;
    get library(): JobTaskNewClusterLibraryList;
    putLibrary(value: JobTaskNewClusterLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobTaskNewClusterLibrary[] | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskNewClusterProviderConfigOutputReference;
    putProviderConfig(value: JobTaskNewClusterProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskNewClusterProviderConfig | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: JobTaskNewClusterWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): JobTaskNewClusterWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): JobTaskNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: JobTaskNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): JobTaskNewClusterWorkloadType | undefined;
}
export interface JobTaskNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#base_parameters Job#base_parameters}
    */
    readonly baseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#notebook_path Job#notebook_path}
    */
    readonly notebookPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function jobTaskNotebookTaskToTerraform(struct?: JobTaskNotebookTaskOutputReference | JobTaskNotebookTask): any;
export declare function jobTaskNotebookTaskToHclTerraform(struct?: JobTaskNotebookTaskOutputReference | JobTaskNotebookTask): any;
export declare class JobTaskNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNotebookTask | undefined;
    set internalValue(value: JobTaskNotebookTask | undefined);
    private _baseParameters?;
    get baseParameters(): {
        [key: string]: string;
    };
    set baseParameters(value: {
        [key: string]: string;
    });
    resetBaseParameters(): void;
    get baseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    get notebookPathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface JobTaskNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#alert_on_last_attempt Job#alert_on_last_attempt}
    */
    readonly alertOnLastAttempt?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#no_alert_for_canceled_runs Job#no_alert_for_canceled_runs}
    */
    readonly noAlertForCanceledRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
}
export declare function jobTaskNotificationSettingsToTerraform(struct?: JobTaskNotificationSettingsOutputReference | JobTaskNotificationSettings): any;
export declare function jobTaskNotificationSettingsToHclTerraform(struct?: JobTaskNotificationSettingsOutputReference | JobTaskNotificationSettings): any;
export declare class JobTaskNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNotificationSettings | undefined;
    set internalValue(value: JobTaskNotificationSettings | undefined);
    private _alertOnLastAttempt?;
    get alertOnLastAttempt(): boolean | cdktn.IResolvable;
    set alertOnLastAttempt(value: boolean | cdktn.IResolvable);
    resetAlertOnLastAttempt(): void;
    get alertOnLastAttemptInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForCanceledRuns?;
    get noAlertForCanceledRuns(): boolean | cdktn.IResolvable;
    set noAlertForCanceledRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForCanceledRuns(): void;
    get noAlertForCanceledRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskPipelineTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#full_refresh Job#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#full_refresh_selection Job#full_refresh_selection}
    */
    readonly fullRefreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pipeline_id Job#pipeline_id}
    */
    readonly pipelineId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#refresh_flow_selection Job#refresh_flow_selection}
    */
    readonly refreshFlowSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#refresh_selection Job#refresh_selection}
    */
    readonly refreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#reset_checkpoint_selection Job#reset_checkpoint_selection}
    */
    readonly resetCheckpointSelection?: string[];
}
export declare function jobTaskPipelineTaskToTerraform(struct?: JobTaskPipelineTaskOutputReference | JobTaskPipelineTask): any;
export declare function jobTaskPipelineTaskToHclTerraform(struct?: JobTaskPipelineTaskOutputReference | JobTaskPipelineTask): any;
export declare class JobTaskPipelineTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPipelineTask | undefined;
    set internalValue(value: JobTaskPipelineTask | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _fullRefreshSelection?;
    get fullRefreshSelection(): string[];
    set fullRefreshSelection(value: string[]);
    resetFullRefreshSelection(): void;
    get fullRefreshSelectionInput(): string[] | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
    private _refreshFlowSelection?;
    get refreshFlowSelection(): string[];
    set refreshFlowSelection(value: string[]);
    resetRefreshFlowSelection(): void;
    get refreshFlowSelectionInput(): string[] | undefined;
    private _refreshSelection?;
    get refreshSelection(): string[];
    set refreshSelection(value: string[]);
    resetRefreshSelection(): void;
    get refreshSelectionInput(): string[] | undefined;
    private _resetCheckpointSelection?;
    get resetCheckpointSelection(): string[];
    set resetCheckpointSelection(value: string[]);
    resetResetCheckpointSelection(): void;
    get resetCheckpointSelectionInput(): string[] | undefined;
}
export interface JobTaskPowerBiTaskPowerBiModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#authentication_method Job#authentication_method}
    */
    readonly authenticationMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#model_name Job#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#overwrite_existing Job#overwrite_existing}
    */
    readonly overwriteExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#storage_mode Job#storage_mode}
    */
    readonly storageMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#workspace_name Job#workspace_name}
    */
    readonly workspaceName?: string;
}
export declare function jobTaskPowerBiTaskPowerBiModelToTerraform(struct?: JobTaskPowerBiTaskPowerBiModelOutputReference | JobTaskPowerBiTaskPowerBiModel): any;
export declare function jobTaskPowerBiTaskPowerBiModelToHclTerraform(struct?: JobTaskPowerBiTaskPowerBiModelOutputReference | JobTaskPowerBiTaskPowerBiModel): any;
export declare class JobTaskPowerBiTaskPowerBiModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPowerBiTaskPowerBiModel | undefined;
    set internalValue(value: JobTaskPowerBiTaskPowerBiModel | undefined);
    private _authenticationMethod?;
    get authenticationMethod(): string;
    set authenticationMethod(value: string);
    resetAuthenticationMethod(): void;
    get authenticationMethodInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _overwriteExisting?;
    get overwriteExisting(): boolean | cdktn.IResolvable;
    set overwriteExisting(value: boolean | cdktn.IResolvable);
    resetOverwriteExisting(): void;
    get overwriteExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
    private _workspaceName?;
    get workspaceName(): string;
    set workspaceName(value: string);
    resetWorkspaceName(): void;
    get workspaceNameInput(): string | undefined;
}
export interface JobTaskPowerBiTaskTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#catalog Job#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#name Job#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#schema Job#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#storage_mode Job#storage_mode}
    */
    readonly storageMode?: string;
}
export declare function jobTaskPowerBiTaskTablesToTerraform(struct?: JobTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare function jobTaskPowerBiTaskTablesToHclTerraform(struct?: JobTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare class JobTaskPowerBiTaskTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskPowerBiTaskTables | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskPowerBiTaskTables | cdktn.IResolvable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
}
export declare class JobTaskPowerBiTaskTablesList extends cdktn.ComplexList {
    internalValue?: JobTaskPowerBiTaskTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskPowerBiTaskTablesOutputReference;
}
export interface JobTaskPowerBiTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#connection_resource_name Job#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#refresh_after_update Job#refresh_after_update}
    */
    readonly refreshAfterUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * power_bi_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#power_bi_model Job#power_bi_model}
    */
    readonly powerBiModel?: JobTaskPowerBiTaskPowerBiModel;
    /**
    * tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#tables Job#tables}
    */
    readonly tables?: JobTaskPowerBiTaskTables[] | cdktn.IResolvable;
}
export declare function jobTaskPowerBiTaskToTerraform(struct?: JobTaskPowerBiTaskOutputReference | JobTaskPowerBiTask): any;
export declare function jobTaskPowerBiTaskToHclTerraform(struct?: JobTaskPowerBiTaskOutputReference | JobTaskPowerBiTask): any;
export declare class JobTaskPowerBiTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPowerBiTask | undefined;
    set internalValue(value: JobTaskPowerBiTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _refreshAfterUpdate?;
    get refreshAfterUpdate(): boolean | cdktn.IResolvable;
    set refreshAfterUpdate(value: boolean | cdktn.IResolvable);
    resetRefreshAfterUpdate(): void;
    get refreshAfterUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _powerBiModel;
    get powerBiModel(): JobTaskPowerBiTaskPowerBiModelOutputReference;
    putPowerBiModel(value: JobTaskPowerBiTaskPowerBiModel): void;
    resetPowerBiModel(): void;
    get powerBiModelInput(): JobTaskPowerBiTaskPowerBiModel | undefined;
    private _tables;
    get tables(): JobTaskPowerBiTaskTablesList;
    putTables(value: JobTaskPowerBiTaskTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | JobTaskPowerBiTaskTables[] | undefined;
}
export interface JobTaskPythonOperatorTaskParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#name Job#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#value Job#value}
    */
    readonly value?: string;
}
export declare function jobTaskPythonOperatorTaskParametersToTerraform(struct?: JobTaskPythonOperatorTaskParameters | cdktn.IResolvable): any;
export declare function jobTaskPythonOperatorTaskParametersToHclTerraform(struct?: JobTaskPythonOperatorTaskParameters | cdktn.IResolvable): any;
export declare class JobTaskPythonOperatorTaskParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskPythonOperatorTaskParameters | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskPythonOperatorTaskParameters | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class JobTaskPythonOperatorTaskParametersList extends cdktn.ComplexList {
    internalValue?: JobTaskPythonOperatorTaskParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskPythonOperatorTaskParametersOutputReference;
}
export interface JobTaskPythonOperatorTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#main Job#main}
    */
    readonly main?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: JobTaskPythonOperatorTaskParameters[] | cdktn.IResolvable;
}
export declare function jobTaskPythonOperatorTaskToTerraform(struct?: JobTaskPythonOperatorTaskOutputReference | JobTaskPythonOperatorTask): any;
export declare function jobTaskPythonOperatorTaskToHclTerraform(struct?: JobTaskPythonOperatorTaskOutputReference | JobTaskPythonOperatorTask): any;
export declare class JobTaskPythonOperatorTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPythonOperatorTask | undefined;
    set internalValue(value: JobTaskPythonOperatorTask | undefined);
    private _main?;
    get main(): string;
    set main(value: string);
    resetMain(): void;
    get mainInput(): string | undefined;
    private _parameters;
    get parameters(): JobTaskPythonOperatorTaskParametersList;
    putParameters(value: JobTaskPythonOperatorTaskParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | JobTaskPythonOperatorTaskParameters[] | undefined;
}
export interface JobTaskPythonWheelTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#entry_point Job#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#named_parameters Job#named_parameters}
    */
    readonly namedParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#package_name Job#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobTaskPythonWheelTaskToTerraform(struct?: JobTaskPythonWheelTaskOutputReference | JobTaskPythonWheelTask): any;
export declare function jobTaskPythonWheelTaskToHclTerraform(struct?: JobTaskPythonWheelTaskOutputReference | JobTaskPythonWheelTask): any;
export declare class JobTaskPythonWheelTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPythonWheelTask | undefined;
    set internalValue(value: JobTaskPythonWheelTask | undefined);
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _namedParameters?;
    get namedParameters(): {
        [key: string]: string;
    };
    set namedParameters(value: {
        [key: string]: string;
    });
    resetNamedParameters(): void;
    get namedParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobTaskRunJobTaskPipelineParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#full_refresh Job#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#full_refresh_selection Job#full_refresh_selection}
    */
    readonly fullRefreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#refresh_flow_selection Job#refresh_flow_selection}
    */
    readonly refreshFlowSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#refresh_selection Job#refresh_selection}
    */
    readonly refreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#reset_checkpoint_selection Job#reset_checkpoint_selection}
    */
    readonly resetCheckpointSelection?: string[];
}
export declare function jobTaskRunJobTaskPipelineParamsToTerraform(struct?: JobTaskRunJobTaskPipelineParamsOutputReference | JobTaskRunJobTaskPipelineParams): any;
export declare function jobTaskRunJobTaskPipelineParamsToHclTerraform(struct?: JobTaskRunJobTaskPipelineParamsOutputReference | JobTaskRunJobTaskPipelineParams): any;
export declare class JobTaskRunJobTaskPipelineParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskRunJobTaskPipelineParams | undefined;
    set internalValue(value: JobTaskRunJobTaskPipelineParams | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _fullRefreshSelection?;
    get fullRefreshSelection(): string[];
    set fullRefreshSelection(value: string[]);
    resetFullRefreshSelection(): void;
    get fullRefreshSelectionInput(): string[] | undefined;
    private _refreshFlowSelection?;
    get refreshFlowSelection(): string[];
    set refreshFlowSelection(value: string[]);
    resetRefreshFlowSelection(): void;
    get refreshFlowSelectionInput(): string[] | undefined;
    private _refreshSelection?;
    get refreshSelection(): string[];
    set refreshSelection(value: string[]);
    resetRefreshSelection(): void;
    get refreshSelectionInput(): string[] | undefined;
    private _resetCheckpointSelection?;
    get resetCheckpointSelection(): string[];
    set resetCheckpointSelection(value: string[]);
    resetResetCheckpointSelection(): void;
    get resetCheckpointSelectionInput(): string[] | undefined;
}
export interface JobTaskRunJobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dbt_commands Job#dbt_commands}
    */
    readonly dbtCommands?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#jar_params Job#jar_params}
    */
    readonly jarParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#job_id Job#job_id}
    */
    readonly jobId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#job_parameters Job#job_parameters}
    */
    readonly jobParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#notebook_params Job#notebook_params}
    */
    readonly notebookParams?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#python_named_params Job#python_named_params}
    */
    readonly pythonNamedParams?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#python_params Job#python_params}
    */
    readonly pythonParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#spark_submit_params Job#spark_submit_params}
    */
    readonly sparkSubmitParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#sql_params Job#sql_params}
    */
    readonly sqlParams?: {
        [key: string]: string;
    };
    /**
    * pipeline_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pipeline_params Job#pipeline_params}
    */
    readonly pipelineParams?: JobTaskRunJobTaskPipelineParams;
}
export declare function jobTaskRunJobTaskToTerraform(struct?: JobTaskRunJobTaskOutputReference | JobTaskRunJobTask): any;
export declare function jobTaskRunJobTaskToHclTerraform(struct?: JobTaskRunJobTaskOutputReference | JobTaskRunJobTask): any;
export declare class JobTaskRunJobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskRunJobTask | undefined;
    set internalValue(value: JobTaskRunJobTask | undefined);
    private _dbtCommands?;
    get dbtCommands(): string[];
    set dbtCommands(value: string[]);
    resetDbtCommands(): void;
    get dbtCommandsInput(): string[] | undefined;
    private _jarParams?;
    get jarParams(): string[];
    set jarParams(value: string[]);
    resetJarParams(): void;
    get jarParamsInput(): string[] | undefined;
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    private _jobParameters?;
    get jobParameters(): {
        [key: string]: string;
    };
    set jobParameters(value: {
        [key: string]: string;
    });
    resetJobParameters(): void;
    get jobParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookParams?;
    get notebookParams(): {
        [key: string]: string;
    };
    set notebookParams(value: {
        [key: string]: string;
    });
    resetNotebookParams(): void;
    get notebookParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pythonNamedParams?;
    get pythonNamedParams(): {
        [key: string]: string;
    };
    set pythonNamedParams(value: {
        [key: string]: string;
    });
    resetPythonNamedParams(): void;
    get pythonNamedParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pythonParams?;
    get pythonParams(): string[];
    set pythonParams(value: string[]);
    resetPythonParams(): void;
    get pythonParamsInput(): string[] | undefined;
    private _sparkSubmitParams?;
    get sparkSubmitParams(): string[];
    set sparkSubmitParams(value: string[]);
    resetSparkSubmitParams(): void;
    get sparkSubmitParamsInput(): string[] | undefined;
    private _sqlParams?;
    get sqlParams(): {
        [key: string]: string;
    };
    set sqlParams(value: {
        [key: string]: string;
    });
    resetSqlParams(): void;
    get sqlParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pipelineParams;
    get pipelineParams(): JobTaskRunJobTaskPipelineParamsOutputReference;
    putPipelineParams(value: JobTaskRunJobTaskPipelineParams): void;
    resetPipelineParams(): void;
    get pipelineParamsInput(): JobTaskRunJobTaskPipelineParams | undefined;
}
export interface JobTaskSparkJarTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#jar_uri Job#jar_uri}
    */
    readonly jarUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#main_class_name Job#main_class_name}
    */
    readonly mainClassName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#run_as_repl Job#run_as_repl}
    */
    readonly runAsRepl?: boolean | cdktn.IResolvable;
}
export declare function jobTaskSparkJarTaskToTerraform(struct?: JobTaskSparkJarTaskOutputReference | JobTaskSparkJarTask): any;
export declare function jobTaskSparkJarTaskToHclTerraform(struct?: JobTaskSparkJarTaskOutputReference | JobTaskSparkJarTask): any;
export declare class JobTaskSparkJarTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSparkJarTask | undefined;
    set internalValue(value: JobTaskSparkJarTask | undefined);
    private _jarUri?;
    get jarUri(): string;
    set jarUri(value: string);
    resetJarUri(): void;
    get jarUriInput(): string | undefined;
    private _mainClassName?;
    get mainClassName(): string;
    set mainClassName(value: string);
    resetMainClassName(): void;
    get mainClassNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _runAsRepl?;
    get runAsRepl(): boolean | cdktn.IResolvable;
    set runAsRepl(value: boolean | cdktn.IResolvable);
    resetRunAsRepl(): void;
    get runAsReplInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskSparkPythonTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#python_file Job#python_file}
    */
    readonly pythonFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
}
export declare function jobTaskSparkPythonTaskToTerraform(struct?: JobTaskSparkPythonTaskOutputReference | JobTaskSparkPythonTask): any;
export declare function jobTaskSparkPythonTaskToHclTerraform(struct?: JobTaskSparkPythonTaskOutputReference | JobTaskSparkPythonTask): any;
export declare class JobTaskSparkPythonTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSparkPythonTask | undefined;
    set internalValue(value: JobTaskSparkPythonTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pythonFile?;
    get pythonFile(): string;
    set pythonFile(value: string);
    get pythonFileInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface JobTaskSparkSubmitTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobTaskSparkSubmitTaskToTerraform(struct?: JobTaskSparkSubmitTaskOutputReference | JobTaskSparkSubmitTask): any;
export declare function jobTaskSparkSubmitTaskToHclTerraform(struct?: JobTaskSparkSubmitTaskOutputReference | JobTaskSparkSubmitTask): any;
export declare class JobTaskSparkSubmitTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSparkSubmitTask | undefined;
    set internalValue(value: JobTaskSparkSubmitTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobTaskSqlTaskAlertSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskSqlTaskAlertSubscriptionsToTerraform(struct?: JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare function jobTaskSqlTaskAlertSubscriptionsToHclTerraform(struct?: JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare class JobTaskSqlTaskAlertSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskSqlTaskAlertSubscriptionsList extends cdktn.ComplexList {
    internalValue?: JobTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskSqlTaskAlertSubscriptionsOutputReference;
}
export interface JobTaskSqlTaskAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#alert_id Job#alert_id}
    */
    readonly alertId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pause_subscriptions Job#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#subscriptions Job#subscriptions}
    */
    readonly subscriptions?: JobTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
}
export declare function jobTaskSqlTaskAlertToTerraform(struct?: JobTaskSqlTaskAlertOutputReference | JobTaskSqlTaskAlert): any;
export declare function jobTaskSqlTaskAlertToHclTerraform(struct?: JobTaskSqlTaskAlertOutputReference | JobTaskSqlTaskAlert): any;
export declare class JobTaskSqlTaskAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskAlert | undefined;
    set internalValue(value: JobTaskSqlTaskAlert | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): JobTaskSqlTaskAlertSubscriptionsList;
    putSubscriptions(value: JobTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | JobTaskSqlTaskAlertSubscriptions[] | undefined;
}
export interface JobTaskSqlTaskDashboardSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskSqlTaskDashboardSubscriptionsToTerraform(struct?: JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare function jobTaskSqlTaskDashboardSubscriptionsToHclTerraform(struct?: JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare class JobTaskSqlTaskDashboardSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskSqlTaskDashboardSubscriptionsList extends cdktn.ComplexList {
    internalValue?: JobTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskSqlTaskDashboardSubscriptionsOutputReference;
}
export interface JobTaskSqlTaskDashboard {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#custom_subject Job#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dashboard_id Job#dashboard_id}
    */
    readonly dashboardId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pause_subscriptions Job#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#subscriptions Job#subscriptions}
    */
    readonly subscriptions?: JobTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
}
export declare function jobTaskSqlTaskDashboardToTerraform(struct?: JobTaskSqlTaskDashboardOutputReference | JobTaskSqlTaskDashboard): any;
export declare function jobTaskSqlTaskDashboardToHclTerraform(struct?: JobTaskSqlTaskDashboardOutputReference | JobTaskSqlTaskDashboard): any;
export declare class JobTaskSqlTaskDashboardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskDashboard | undefined;
    set internalValue(value: JobTaskSqlTaskDashboard | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    get dashboardIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): JobTaskSqlTaskDashboardSubscriptionsList;
    putSubscriptions(value: JobTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | JobTaskSqlTaskDashboardSubscriptions[] | undefined;
}
export interface JobTaskSqlTaskFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#path Job#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
}
export declare function jobTaskSqlTaskFileToTerraform(struct?: JobTaskSqlTaskFileOutputReference | JobTaskSqlTaskFile): any;
export declare function jobTaskSqlTaskFileToHclTerraform(struct?: JobTaskSqlTaskFileOutputReference | JobTaskSqlTaskFile): any;
export declare class JobTaskSqlTaskFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskFile | undefined;
    set internalValue(value: JobTaskSqlTaskFile | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface JobTaskSqlTaskQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#query_id Job#query_id}
    */
    readonly queryId: string;
}
export declare function jobTaskSqlTaskQueryToTerraform(struct?: JobTaskSqlTaskQueryOutputReference | JobTaskSqlTaskQuery): any;
export declare function jobTaskSqlTaskQueryToHclTerraform(struct?: JobTaskSqlTaskQueryOutputReference | JobTaskSqlTaskQuery): any;
export declare class JobTaskSqlTaskQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTaskQuery | undefined;
    set internalValue(value: JobTaskSqlTaskQuery | undefined);
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
}
export interface JobTaskSqlTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#alert Job#alert}
    */
    readonly alert?: JobTaskSqlTaskAlert;
    /**
    * dashboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dashboard Job#dashboard}
    */
    readonly dashboard?: JobTaskSqlTaskDashboard;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobTaskSqlTaskFile;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#query Job#query}
    */
    readonly query?: JobTaskSqlTaskQuery;
}
export declare function jobTaskSqlTaskToTerraform(struct?: JobTaskSqlTaskOutputReference | JobTaskSqlTask): any;
export declare function jobTaskSqlTaskToHclTerraform(struct?: JobTaskSqlTaskOutputReference | JobTaskSqlTask): any;
export declare class JobTaskSqlTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSqlTask | undefined;
    set internalValue(value: JobTaskSqlTask | undefined);
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    private _alert;
    get alert(): JobTaskSqlTaskAlertOutputReference;
    putAlert(value: JobTaskSqlTaskAlert): void;
    resetAlert(): void;
    get alertInput(): JobTaskSqlTaskAlert | undefined;
    private _dashboard;
    get dashboard(): JobTaskSqlTaskDashboardOutputReference;
    putDashboard(value: JobTaskSqlTaskDashboard): void;
    resetDashboard(): void;
    get dashboardInput(): JobTaskSqlTaskDashboard | undefined;
    private _file;
    get file(): JobTaskSqlTaskFileOutputReference;
    putFile(value: JobTaskSqlTaskFile): void;
    resetFile(): void;
    get fileInput(): JobTaskSqlTaskFile | undefined;
    private _query;
    get query(): JobTaskSqlTaskQueryOutputReference;
    putQuery(value: JobTaskSqlTaskQuery): void;
    resetQuery(): void;
    get queryInput(): JobTaskSqlTaskQuery | undefined;
}
export interface JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface JobTaskWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnFailureToTerraform(struct?: JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnFailureToHclTerraform(struct?: JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnFailureOutputReference;
}
export interface JobTaskWebhookNotificationsOnMaintenanceComplete {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnMaintenanceCompleteToTerraform(struct?: JobTaskWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnMaintenanceCompleteToHclTerraform(struct?: JobTaskWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnMaintenanceCompleteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnMaintenanceCompleteList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnMaintenanceComplete[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnMaintenanceCompleteOutputReference;
}
export interface JobTaskWebhookNotificationsOnMaintenanceStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnMaintenanceStartToTerraform(struct?: JobTaskWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnMaintenanceStartToHclTerraform(struct?: JobTaskWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnMaintenanceStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnMaintenanceStartList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnMaintenanceStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnMaintenanceStartOutputReference;
}
export interface JobTaskWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnStartToTerraform(struct?: JobTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnStartToHclTerraform(struct?: JobTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnStartOutputReference;
}
export interface JobTaskWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface JobTaskWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskWebhookNotificationsOnSuccessToTerraform(struct?: JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function jobTaskWebhookNotificationsOnSuccessToHclTerraform(struct?: JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class JobTaskWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: JobTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskWebhookNotificationsOnSuccessOutputReference;
}
export interface JobTaskWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: JobTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_maintenance_complete block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_maintenance_complete Job#on_maintenance_complete}
    */
    readonly onMaintenanceComplete?: JobTaskWebhookNotificationsOnMaintenanceComplete[] | cdktn.IResolvable;
    /**
    * on_maintenance_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_maintenance_start Job#on_maintenance_start}
    */
    readonly onMaintenanceStart?: JobTaskWebhookNotificationsOnMaintenanceStart[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: JobTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: JobTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function jobTaskWebhookNotificationsToTerraform(struct?: JobTaskWebhookNotificationsOutputReference | JobTaskWebhookNotifications): any;
export declare function jobTaskWebhookNotificationsToHclTerraform(struct?: JobTaskWebhookNotificationsOutputReference | JobTaskWebhookNotifications): any;
export declare class JobTaskWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskWebhookNotifications | undefined;
    set internalValue(value: JobTaskWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): JobTaskWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): JobTaskWebhookNotificationsOnFailureList;
    putOnFailure(value: JobTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnFailure[] | undefined;
    private _onMaintenanceComplete;
    get onMaintenanceComplete(): JobTaskWebhookNotificationsOnMaintenanceCompleteList;
    putOnMaintenanceComplete(value: JobTaskWebhookNotificationsOnMaintenanceComplete[] | cdktn.IResolvable): void;
    resetOnMaintenanceComplete(): void;
    get onMaintenanceCompleteInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnMaintenanceComplete[] | undefined;
    private _onMaintenanceStart;
    get onMaintenanceStart(): JobTaskWebhookNotificationsOnMaintenanceStartList;
    putOnMaintenanceStart(value: JobTaskWebhookNotificationsOnMaintenanceStart[] | cdktn.IResolvable): void;
    resetOnMaintenanceStart(): void;
    get onMaintenanceStartInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnMaintenanceStart[] | undefined;
    private _onStart;
    get onStart(): JobTaskWebhookNotificationsOnStartList;
    putOnStart(value: JobTaskWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): JobTaskWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): JobTaskWebhookNotificationsOnSuccessList;
    putOnSuccess(value: JobTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | JobTaskWebhookNotificationsOnSuccess[] | undefined;
}
export interface JobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#description Job#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#disable_auto_optimization Job#disable_auto_optimization}
    */
    readonly disableAutoOptimization?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#disabled Job#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#environment_key Job#environment_key}
    */
    readonly environmentKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#environment_variables_key Job#environment_variables_key}
    */
    readonly environmentVariablesKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#existing_cluster_id Job#existing_cluster_id}
    */
    readonly existingClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#job_cluster_key Job#job_cluster_key}
    */
    readonly jobClusterKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#max_retries Job#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#min_retry_interval_millis Job#min_retry_interval_millis}
    */
    readonly minRetryIntervalMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#retry_on_timeout Job#retry_on_timeout}
    */
    readonly retryOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#run_if Job#run_if}
    */
    readonly runIf?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#task_key Job#task_key}
    */
    readonly taskKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#timeout_seconds Job#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * ai_function_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#ai_function_task Job#ai_function_task}
    */
    readonly aiFunctionTask?: JobTaskAiFunctionTask;
    /**
    * ai_runtime_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#ai_runtime_task Job#ai_runtime_task}
    */
    readonly aiRuntimeTask?: JobTaskAiRuntimeTask;
    /**
    * alert_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#alert_task Job#alert_task}
    */
    readonly alertTask?: JobTaskAlertTask;
    /**
    * clean_rooms_notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#clean_rooms_notebook_task Job#clean_rooms_notebook_task}
    */
    readonly cleanRoomsNotebookTask?: JobTaskCleanRoomsNotebookTask;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#compute Job#compute}
    */
    readonly compute?: JobTaskCompute;
    /**
    * condition_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#condition_task Job#condition_task}
    */
    readonly conditionTask?: JobTaskConditionTask;
    /**
    * dashboard_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dashboard_task Job#dashboard_task}
    */
    readonly dashboardTask?: JobTaskDashboardTask;
    /**
    * dbt_cloud_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dbt_cloud_task Job#dbt_cloud_task}
    */
    readonly dbtCloudTask?: JobTaskDbtCloudTask;
    /**
    * dbt_platform_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dbt_platform_task Job#dbt_platform_task}
    */
    readonly dbtPlatformTask?: JobTaskDbtPlatformTask;
    /**
    * dbt_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#dbt_task Job#dbt_task}
    */
    readonly dbtTask?: JobTaskDbtTask;
    /**
    * depends_on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#depends_on Job#depends_on}
    */
    readonly dependsOn?: JobTaskDependsOn[] | cdktn.IResolvable;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#email_notifications Job#email_notifications}
    */
    readonly emailNotifications?: JobTaskEmailNotifications;
    /**
    * for_each_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#for_each_task Job#for_each_task}
    */
    readonly forEachTask?: JobTaskForEachTask;
    /**
    * gen_ai_compute_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#gen_ai_compute_task Job#gen_ai_compute_task}
    */
    readonly genAiComputeTask?: JobTaskGenAiComputeTask;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#health Job#health}
    */
    readonly health?: JobTaskHealth;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobTaskLibrary[] | cdktn.IResolvable;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#new_cluster Job#new_cluster}
    */
    readonly newCluster?: JobTaskNewCluster;
    /**
    * notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#notebook_task Job#notebook_task}
    */
    readonly notebookTask?: JobTaskNotebookTask;
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#notification_settings Job#notification_settings}
    */
    readonly notificationSettings?: JobTaskNotificationSettings;
    /**
    * pipeline_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pipeline_task Job#pipeline_task}
    */
    readonly pipelineTask?: JobTaskPipelineTask;
    /**
    * power_bi_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#power_bi_task Job#power_bi_task}
    */
    readonly powerBiTask?: JobTaskPowerBiTask;
    /**
    * python_operator_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#python_operator_task Job#python_operator_task}
    */
    readonly pythonOperatorTask?: JobTaskPythonOperatorTask;
    /**
    * python_wheel_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#python_wheel_task Job#python_wheel_task}
    */
    readonly pythonWheelTask?: JobTaskPythonWheelTask;
    /**
    * run_job_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#run_job_task Job#run_job_task}
    */
    readonly runJobTask?: JobTaskRunJobTask;
    /**
    * spark_jar_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#spark_jar_task Job#spark_jar_task}
    */
    readonly sparkJarTask?: JobTaskSparkJarTask;
    /**
    * spark_python_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#spark_python_task Job#spark_python_task}
    */
    readonly sparkPythonTask?: JobTaskSparkPythonTask;
    /**
    * spark_submit_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#spark_submit_task Job#spark_submit_task}
    */
    readonly sparkSubmitTask?: JobTaskSparkSubmitTask;
    /**
    * sql_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#sql_task Job#sql_task}
    */
    readonly sqlTask?: JobTaskSqlTask;
    /**
    * webhook_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#webhook_notifications Job#webhook_notifications}
    */
    readonly webhookNotifications?: JobTaskWebhookNotifications;
}
export declare function jobTaskToTerraform(struct?: JobTask | cdktn.IResolvable): any;
export declare function jobTaskToHclTerraform(struct?: JobTask | cdktn.IResolvable): any;
export declare class JobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTask | cdktn.IResolvable | undefined;
    set internalValue(value: JobTask | cdktn.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableAutoOptimization?;
    get disableAutoOptimization(): boolean | cdktn.IResolvable;
    set disableAutoOptimization(value: boolean | cdktn.IResolvable);
    resetDisableAutoOptimization(): void;
    get disableAutoOptimizationInput(): boolean | cdktn.IResolvable | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentKey?;
    get environmentKey(): string;
    set environmentKey(value: string);
    resetEnvironmentKey(): void;
    get environmentKeyInput(): string | undefined;
    private _environmentVariablesKey?;
    get environmentVariablesKey(): string;
    set environmentVariablesKey(value: string);
    resetEnvironmentVariablesKey(): void;
    get environmentVariablesKeyInput(): string | undefined;
    private _existingClusterId?;
    get existingClusterId(): string;
    set existingClusterId(value: string);
    resetExistingClusterId(): void;
    get existingClusterIdInput(): string | undefined;
    private _jobClusterKey?;
    get jobClusterKey(): string;
    set jobClusterKey(value: string);
    resetJobClusterKey(): void;
    get jobClusterKeyInput(): string | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minRetryIntervalMillis?;
    get minRetryIntervalMillis(): number;
    set minRetryIntervalMillis(value: number);
    resetMinRetryIntervalMillis(): void;
    get minRetryIntervalMillisInput(): number | undefined;
    private _retryOnTimeout?;
    get retryOnTimeout(): boolean | cdktn.IResolvable;
    set retryOnTimeout(value: boolean | cdktn.IResolvable);
    resetRetryOnTimeout(): void;
    get retryOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _runIf?;
    get runIf(): string;
    set runIf(value: string);
    resetRunIf(): void;
    get runIfInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _aiFunctionTask;
    get aiFunctionTask(): JobTaskAiFunctionTaskOutputReference;
    putAiFunctionTask(value: JobTaskAiFunctionTask): void;
    resetAiFunctionTask(): void;
    get aiFunctionTaskInput(): JobTaskAiFunctionTask | undefined;
    private _aiRuntimeTask;
    get aiRuntimeTask(): JobTaskAiRuntimeTaskOutputReference;
    putAiRuntimeTask(value: JobTaskAiRuntimeTask): void;
    resetAiRuntimeTask(): void;
    get aiRuntimeTaskInput(): JobTaskAiRuntimeTask | undefined;
    private _alertTask;
    get alertTask(): JobTaskAlertTaskOutputReference;
    putAlertTask(value: JobTaskAlertTask): void;
    resetAlertTask(): void;
    get alertTaskInput(): JobTaskAlertTask | undefined;
    private _cleanRoomsNotebookTask;
    get cleanRoomsNotebookTask(): JobTaskCleanRoomsNotebookTaskOutputReference;
    putCleanRoomsNotebookTask(value: JobTaskCleanRoomsNotebookTask): void;
    resetCleanRoomsNotebookTask(): void;
    get cleanRoomsNotebookTaskInput(): JobTaskCleanRoomsNotebookTask | undefined;
    private _compute;
    get compute(): JobTaskComputeOutputReference;
    putCompute(value: JobTaskCompute): void;
    resetCompute(): void;
    get computeInput(): JobTaskCompute | undefined;
    private _conditionTask;
    get conditionTask(): JobTaskConditionTaskOutputReference;
    putConditionTask(value: JobTaskConditionTask): void;
    resetConditionTask(): void;
    get conditionTaskInput(): JobTaskConditionTask | undefined;
    private _dashboardTask;
    get dashboardTask(): JobTaskDashboardTaskOutputReference;
    putDashboardTask(value: JobTaskDashboardTask): void;
    resetDashboardTask(): void;
    get dashboardTaskInput(): JobTaskDashboardTask | undefined;
    private _dbtCloudTask;
    get dbtCloudTask(): JobTaskDbtCloudTaskOutputReference;
    putDbtCloudTask(value: JobTaskDbtCloudTask): void;
    resetDbtCloudTask(): void;
    get dbtCloudTaskInput(): JobTaskDbtCloudTask | undefined;
    private _dbtPlatformTask;
    get dbtPlatformTask(): JobTaskDbtPlatformTaskOutputReference;
    putDbtPlatformTask(value: JobTaskDbtPlatformTask): void;
    resetDbtPlatformTask(): void;
    get dbtPlatformTaskInput(): JobTaskDbtPlatformTask | undefined;
    private _dbtTask;
    get dbtTask(): JobTaskDbtTaskOutputReference;
    putDbtTask(value: JobTaskDbtTask): void;
    resetDbtTask(): void;
    get dbtTaskInput(): JobTaskDbtTask | undefined;
    private _dependsOn;
    get dependsOn(): JobTaskDependsOnList;
    putDependsOn(value: JobTaskDependsOn[] | cdktn.IResolvable): void;
    resetDependsOn(): void;
    get dependsOnInput(): cdktn.IResolvable | JobTaskDependsOn[] | undefined;
    private _emailNotifications;
    get emailNotifications(): JobTaskEmailNotificationsOutputReference;
    putEmailNotifications(value: JobTaskEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): JobTaskEmailNotifications | undefined;
    private _forEachTask;
    get forEachTask(): JobTaskForEachTaskOutputReference;
    putForEachTask(value: JobTaskForEachTask): void;
    resetForEachTask(): void;
    get forEachTaskInput(): JobTaskForEachTask | undefined;
    private _genAiComputeTask;
    get genAiComputeTask(): JobTaskGenAiComputeTaskOutputReference;
    putGenAiComputeTask(value: JobTaskGenAiComputeTask): void;
    resetGenAiComputeTask(): void;
    get genAiComputeTaskInput(): JobTaskGenAiComputeTask | undefined;
    private _health;
    get health(): JobTaskHealthOutputReference;
    putHealth(value: JobTaskHealth): void;
    resetHealth(): void;
    get healthInput(): JobTaskHealth | undefined;
    private _library;
    get library(): JobTaskLibraryList;
    putLibrary(value: JobTaskLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobTaskLibrary[] | undefined;
    private _newCluster;
    get newCluster(): JobTaskNewClusterOutputReference;
    putNewCluster(value: JobTaskNewCluster): void;
    resetNewCluster(): void;
    get newClusterInput(): JobTaskNewCluster | undefined;
    private _notebookTask;
    get notebookTask(): JobTaskNotebookTaskOutputReference;
    putNotebookTask(value: JobTaskNotebookTask): void;
    resetNotebookTask(): void;
    get notebookTaskInput(): JobTaskNotebookTask | undefined;
    private _notificationSettings;
    get notificationSettings(): JobTaskNotificationSettingsOutputReference;
    putNotificationSettings(value: JobTaskNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): JobTaskNotificationSettings | undefined;
    private _pipelineTask;
    get pipelineTask(): JobTaskPipelineTaskOutputReference;
    putPipelineTask(value: JobTaskPipelineTask): void;
    resetPipelineTask(): void;
    get pipelineTaskInput(): JobTaskPipelineTask | undefined;
    private _powerBiTask;
    get powerBiTask(): JobTaskPowerBiTaskOutputReference;
    putPowerBiTask(value: JobTaskPowerBiTask): void;
    resetPowerBiTask(): void;
    get powerBiTaskInput(): JobTaskPowerBiTask | undefined;
    private _pythonOperatorTask;
    get pythonOperatorTask(): JobTaskPythonOperatorTaskOutputReference;
    putPythonOperatorTask(value: JobTaskPythonOperatorTask): void;
    resetPythonOperatorTask(): void;
    get pythonOperatorTaskInput(): JobTaskPythonOperatorTask | undefined;
    private _pythonWheelTask;
    get pythonWheelTask(): JobTaskPythonWheelTaskOutputReference;
    putPythonWheelTask(value: JobTaskPythonWheelTask): void;
    resetPythonWheelTask(): void;
    get pythonWheelTaskInput(): JobTaskPythonWheelTask | undefined;
    private _runJobTask;
    get runJobTask(): JobTaskRunJobTaskOutputReference;
    putRunJobTask(value: JobTaskRunJobTask): void;
    resetRunJobTask(): void;
    get runJobTaskInput(): JobTaskRunJobTask | undefined;
    private _sparkJarTask;
    get sparkJarTask(): JobTaskSparkJarTaskOutputReference;
    putSparkJarTask(value: JobTaskSparkJarTask): void;
    resetSparkJarTask(): void;
    get sparkJarTaskInput(): JobTaskSparkJarTask | undefined;
    private _sparkPythonTask;
    get sparkPythonTask(): JobTaskSparkPythonTaskOutputReference;
    putSparkPythonTask(value: JobTaskSparkPythonTask): void;
    resetSparkPythonTask(): void;
    get sparkPythonTaskInput(): JobTaskSparkPythonTask | undefined;
    private _sparkSubmitTask;
    get sparkSubmitTask(): JobTaskSparkSubmitTaskOutputReference;
    putSparkSubmitTask(value: JobTaskSparkSubmitTask): void;
    resetSparkSubmitTask(): void;
    get sparkSubmitTaskInput(): JobTaskSparkSubmitTask | undefined;
    private _sqlTask;
    get sqlTask(): JobTaskSqlTaskOutputReference;
    putSqlTask(value: JobTaskSqlTask): void;
    resetSqlTask(): void;
    get sqlTaskInput(): JobTaskSqlTask | undefined;
    private _webhookNotifications;
    get webhookNotifications(): JobTaskWebhookNotificationsOutputReference;
    putWebhookNotifications(value: JobTaskWebhookNotifications): void;
    resetWebhookNotifications(): void;
    get webhookNotificationsInput(): JobTaskWebhookNotifications | undefined;
}
export declare class JobTaskList extends cdktn.ComplexList {
    internalValue?: JobTask[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskOutputReference;
}
export interface JobTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#create Job#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#update Job#update}
    */
    readonly update?: string;
}
export declare function jobTimeoutsToTerraform(struct?: JobTimeouts | cdktn.IResolvable): any;
export declare function jobTimeoutsToHclTerraform(struct?: JobTimeouts | cdktn.IResolvable): any;
export declare class JobTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: JobTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface JobTriggerFileArrival {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerFileArrivalToTerraform(struct?: JobTriggerFileArrivalOutputReference | JobTriggerFileArrival): any;
export declare function jobTriggerFileArrivalToHclTerraform(struct?: JobTriggerFileArrivalOutputReference | JobTriggerFileArrival): any;
export declare class JobTriggerFileArrivalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerFileArrival | undefined;
    set internalValue(value: JobTriggerFileArrival | undefined);
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggerJobCompletionJobs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#job_id Job#job_id}
    */
    readonly jobId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobTriggerJobCompletionJobsToTerraform(struct?: JobTriggerJobCompletionJobs | cdktn.IResolvable): any;
export declare function jobTriggerJobCompletionJobsToHclTerraform(struct?: JobTriggerJobCompletionJobs | cdktn.IResolvable): any;
export declare class JobTriggerJobCompletionJobsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTriggerJobCompletionJobs | cdktn.IResolvable | undefined;
    set internalValue(value: JobTriggerJobCompletionJobs | cdktn.IResolvable | undefined);
    private _jobId?;
    get jobId(): string;
    set jobId(value: string);
    get jobIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class JobTriggerJobCompletionJobsList extends cdktn.ComplexList {
    internalValue?: JobTriggerJobCompletionJobs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTriggerJobCompletionJobsOutputReference;
}
export interface JobTriggerJobCompletion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#if_status Job#if_status}
    */
    readonly ifStatus?: string;
    /**
    * jobs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#jobs Job#jobs}
    */
    readonly jobs: JobTriggerJobCompletionJobs[] | cdktn.IResolvable;
}
export declare function jobTriggerJobCompletionToTerraform(struct?: JobTriggerJobCompletionOutputReference | JobTriggerJobCompletion): any;
export declare function jobTriggerJobCompletionToHclTerraform(struct?: JobTriggerJobCompletionOutputReference | JobTriggerJobCompletion): any;
export declare class JobTriggerJobCompletionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerJobCompletion | undefined;
    set internalValue(value: JobTriggerJobCompletion | undefined);
    private _ifStatus?;
    get ifStatus(): string;
    set ifStatus(value: string);
    resetIfStatus(): void;
    get ifStatusInput(): string | undefined;
    private _jobs;
    get jobs(): JobTriggerJobCompletionJobsList;
    putJobs(value: JobTriggerJobCompletionJobs[] | cdktn.IResolvable): void;
    get jobsInput(): cdktn.IResolvable | JobTriggerJobCompletionJobs[] | undefined;
}
export interface JobTriggerModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#aliases Job#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#condition Job#condition}
    */
    readonly condition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#securable_name Job#securable_name}
    */
    readonly securableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerModelToTerraform(struct?: JobTriggerModelOutputReference | JobTriggerModel): any;
export declare function jobTriggerModelToHclTerraform(struct?: JobTriggerModelOutputReference | JobTriggerModel): any;
export declare class JobTriggerModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerModel | undefined;
    set internalValue(value: JobTriggerModel | undefined);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _securableName?;
    get securableName(): string;
    set securableName(value: string);
    resetSecurableName(): void;
    get securableNameInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggerPeriodic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#interval Job#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#unit Job#unit}
    */
    readonly unit: string;
}
export declare function jobTriggerPeriodicToTerraform(struct?: JobTriggerPeriodicOutputReference | JobTriggerPeriodic): any;
export declare function jobTriggerPeriodicToHclTerraform(struct?: JobTriggerPeriodicOutputReference | JobTriggerPeriodic): any;
export declare class JobTriggerPeriodicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerPeriodic | undefined;
    set internalValue(value: JobTriggerPeriodic | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface JobTriggerSqlCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#sql_query_id Job#sql_query_id}
    */
    readonly sqlQueryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#trigger_mode Job#trigger_mode}
    */
    readonly triggerMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId: string;
}
export declare function jobTriggerSqlConditionToTerraform(struct?: JobTriggerSqlConditionOutputReference | JobTriggerSqlCondition): any;
export declare function jobTriggerSqlConditionToHclTerraform(struct?: JobTriggerSqlConditionOutputReference | JobTriggerSqlCondition): any;
export declare class JobTriggerSqlConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerSqlCondition | undefined;
    set internalValue(value: JobTriggerSqlCondition | undefined);
    private _sqlQueryId?;
    get sqlQueryId(): string;
    set sqlQueryId(value: string);
    resetSqlQueryId(): void;
    get sqlQueryIdInput(): string | undefined;
    private _triggerMode?;
    get triggerMode(): string;
    set triggerMode(value: string);
    resetTriggerMode(): void;
    get triggerModeInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
}
export interface JobTriggerTableUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#condition Job#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#table_names Job#table_names}
    */
    readonly tableNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggerTableUpdateToTerraform(struct?: JobTriggerTableUpdateOutputReference | JobTriggerTableUpdate): any;
export declare function jobTriggerTableUpdateToHclTerraform(struct?: JobTriggerTableUpdateOutputReference | JobTriggerTableUpdate): any;
export declare class JobTriggerTableUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggerTableUpdate | undefined;
    set internalValue(value: JobTriggerTableUpdate | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _tableNames?;
    get tableNames(): string[];
    set tableNames(value: string[]);
    get tableNamesInput(): string[] | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pause_status Job#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * file_arrival block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#file_arrival Job#file_arrival}
    */
    readonly fileArrival?: JobTriggerFileArrival;
    /**
    * job_completion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#job_completion Job#job_completion}
    */
    readonly jobCompletion?: JobTriggerJobCompletion;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#model Job#model}
    */
    readonly model?: JobTriggerModel;
    /**
    * periodic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#periodic Job#periodic}
    */
    readonly periodic?: JobTriggerPeriodic;
    /**
    * sql_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#sql_condition Job#sql_condition}
    */
    readonly sqlCondition?: JobTriggerSqlCondition;
    /**
    * table_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#table_update Job#table_update}
    */
    readonly tableUpdate?: JobTriggerTableUpdate;
}
export declare function jobTriggerToTerraform(struct?: JobTriggerOutputReference | JobTrigger): any;
export declare function jobTriggerToHclTerraform(struct?: JobTriggerOutputReference | JobTrigger): any;
export declare class JobTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTrigger | undefined;
    set internalValue(value: JobTrigger | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _fileArrival;
    get fileArrival(): JobTriggerFileArrivalOutputReference;
    putFileArrival(value: JobTriggerFileArrival): void;
    resetFileArrival(): void;
    get fileArrivalInput(): JobTriggerFileArrival | undefined;
    private _jobCompletion;
    get jobCompletion(): JobTriggerJobCompletionOutputReference;
    putJobCompletion(value: JobTriggerJobCompletion): void;
    resetJobCompletion(): void;
    get jobCompletionInput(): JobTriggerJobCompletion | undefined;
    private _model;
    get model(): JobTriggerModelOutputReference;
    putModel(value: JobTriggerModel): void;
    resetModel(): void;
    get modelInput(): JobTriggerModel | undefined;
    private _periodic;
    get periodic(): JobTriggerPeriodicOutputReference;
    putPeriodic(value: JobTriggerPeriodic): void;
    resetPeriodic(): void;
    get periodicInput(): JobTriggerPeriodic | undefined;
    private _sqlCondition;
    get sqlCondition(): JobTriggerSqlConditionOutputReference;
    putSqlCondition(value: JobTriggerSqlCondition): void;
    resetSqlCondition(): void;
    get sqlConditionInput(): JobTriggerSqlCondition | undefined;
    private _tableUpdate;
    get tableUpdate(): JobTriggerTableUpdateOutputReference;
    putTableUpdate(value: JobTriggerTableUpdate): void;
    resetTableUpdate(): void;
    get tableUpdateInput(): JobTriggerTableUpdate | undefined;
}
export interface JobTriggersContinuousMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#day_of_week Job#day_of_week}
    */
    readonly dayOfWeek: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#start_hour Job#start_hour}
    */
    readonly startHour: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#timezone_id Job#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function jobTriggersContinuousMaintenanceWindowToTerraform(struct?: JobTriggersContinuousMaintenanceWindowOutputReference | JobTriggersContinuousMaintenanceWindow): any;
export declare function jobTriggersContinuousMaintenanceWindowToHclTerraform(struct?: JobTriggersContinuousMaintenanceWindowOutputReference | JobTriggersContinuousMaintenanceWindow): any;
export declare class JobTriggersContinuousMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersContinuousMaintenanceWindow | undefined;
    set internalValue(value: JobTriggersContinuousMaintenanceWindow | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    get dayOfWeekInput(): string | undefined;
    private _startHour?;
    get startHour(): number;
    set startHour(value: number);
    get startHourInput(): number | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface JobTriggersContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#task_retry_mode Job#task_retry_mode}
    */
    readonly taskRetryMode?: string;
    /**
    * maintenance_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#maintenance_window Job#maintenance_window}
    */
    readonly maintenanceWindow?: JobTriggersContinuousMaintenanceWindow;
}
export declare function jobTriggersContinuousToTerraform(struct?: JobTriggersContinuousOutputReference | JobTriggersContinuous): any;
export declare function jobTriggersContinuousToHclTerraform(struct?: JobTriggersContinuousOutputReference | JobTriggersContinuous): any;
export declare class JobTriggersContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersContinuous | undefined;
    set internalValue(value: JobTriggersContinuous | undefined);
    private _taskRetryMode?;
    get taskRetryMode(): string;
    set taskRetryMode(value: string);
    resetTaskRetryMode(): void;
    get taskRetryModeInput(): string | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): JobTriggersContinuousMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: JobTriggersContinuousMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): JobTriggersContinuousMaintenanceWindow | undefined;
}
export interface JobTriggersFileArrival {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggersFileArrivalToTerraform(struct?: JobTriggersFileArrivalOutputReference | JobTriggersFileArrival): any;
export declare function jobTriggersFileArrivalToHclTerraform(struct?: JobTriggersFileArrivalOutputReference | JobTriggersFileArrival): any;
export declare class JobTriggersFileArrivalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersFileArrival | undefined;
    set internalValue(value: JobTriggersFileArrival | undefined);
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggersJobCompletionJobs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#job_id Job#job_id}
    */
    readonly jobId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId: string;
}
export declare function jobTriggersJobCompletionJobsToTerraform(struct?: JobTriggersJobCompletionJobs | cdktn.IResolvable): any;
export declare function jobTriggersJobCompletionJobsToHclTerraform(struct?: JobTriggersJobCompletionJobs | cdktn.IResolvable): any;
export declare class JobTriggersJobCompletionJobsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTriggersJobCompletionJobs | cdktn.IResolvable | undefined;
    set internalValue(value: JobTriggersJobCompletionJobs | cdktn.IResolvable | undefined);
    private _jobId?;
    get jobId(): string;
    set jobId(value: string);
    get jobIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
}
export declare class JobTriggersJobCompletionJobsList extends cdktn.ComplexList {
    internalValue?: JobTriggersJobCompletionJobs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTriggersJobCompletionJobsOutputReference;
}
export interface JobTriggersJobCompletion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#if_status Job#if_status}
    */
    readonly ifStatus?: string;
    /**
    * jobs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#jobs Job#jobs}
    */
    readonly jobs: JobTriggersJobCompletionJobs[] | cdktn.IResolvable;
}
export declare function jobTriggersJobCompletionToTerraform(struct?: JobTriggersJobCompletionOutputReference | JobTriggersJobCompletion): any;
export declare function jobTriggersJobCompletionToHclTerraform(struct?: JobTriggersJobCompletionOutputReference | JobTriggersJobCompletion): any;
export declare class JobTriggersJobCompletionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersJobCompletion | undefined;
    set internalValue(value: JobTriggersJobCompletion | undefined);
    private _ifStatus?;
    get ifStatus(): string;
    set ifStatus(value: string);
    resetIfStatus(): void;
    get ifStatusInput(): string | undefined;
    private _jobs;
    get jobs(): JobTriggersJobCompletionJobsList;
    putJobs(value: JobTriggersJobCompletionJobs[] | cdktn.IResolvable): void;
    get jobsInput(): cdktn.IResolvable | JobTriggersJobCompletionJobs[] | undefined;
}
export interface JobTriggersModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#aliases Job#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#condition Job#condition}
    */
    readonly condition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#securable_name Job#securable_name}
    */
    readonly securableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggersModelToTerraform(struct?: JobTriggersModelOutputReference | JobTriggersModel): any;
export declare function jobTriggersModelToHclTerraform(struct?: JobTriggersModelOutputReference | JobTriggersModel): any;
export declare class JobTriggersModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersModel | undefined;
    set internalValue(value: JobTriggersModel | undefined);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _condition?;
    get condition(): string;
    set condition(value: string);
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _securableName?;
    get securableName(): string;
    set securableName(value: string);
    resetSecurableName(): void;
    get securableNameInput(): string | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggersPeriodic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#interval Job#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#unit Job#unit}
    */
    readonly unit: string;
}
export declare function jobTriggersPeriodicToTerraform(struct?: JobTriggersPeriodicOutputReference | JobTriggersPeriodic): any;
export declare function jobTriggersPeriodicToHclTerraform(struct?: JobTriggersPeriodicOutputReference | JobTriggersPeriodic): any;
export declare class JobTriggersPeriodicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersPeriodic | undefined;
    set internalValue(value: JobTriggersPeriodic | undefined);
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    get unitInput(): string | undefined;
}
export interface JobTriggersSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#quartz_cron_expression Job#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#timezone_id Job#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function jobTriggersScheduleToTerraform(struct?: JobTriggersScheduleOutputReference | JobTriggersSchedule): any;
export declare function jobTriggersScheduleToHclTerraform(struct?: JobTriggersScheduleOutputReference | JobTriggersSchedule): any;
export declare class JobTriggersScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersSchedule | undefined;
    set internalValue(value: JobTriggersSchedule | undefined);
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface JobTriggersSqlCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#sql_query_id Job#sql_query_id}
    */
    readonly sqlQueryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#trigger_mode Job#trigger_mode}
    */
    readonly triggerMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId: string;
}
export declare function jobTriggersSqlConditionToTerraform(struct?: JobTriggersSqlConditionOutputReference | JobTriggersSqlCondition): any;
export declare function jobTriggersSqlConditionToHclTerraform(struct?: JobTriggersSqlConditionOutputReference | JobTriggersSqlCondition): any;
export declare class JobTriggersSqlConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersSqlCondition | undefined;
    set internalValue(value: JobTriggersSqlCondition | undefined);
    private _sqlQueryId?;
    get sqlQueryId(): string;
    set sqlQueryId(value: string);
    resetSqlQueryId(): void;
    get sqlQueryIdInput(): string | undefined;
    private _triggerMode?;
    get triggerMode(): string;
    set triggerMode(value: string);
    resetTriggerMode(): void;
    get triggerModeInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
}
export interface JobTriggersTableUpdate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#condition Job#condition}
    */
    readonly condition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#min_time_between_triggers_seconds Job#min_time_between_triggers_seconds}
    */
    readonly minTimeBetweenTriggersSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#table_names Job#table_names}
    */
    readonly tableNames: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#wait_after_last_change_seconds Job#wait_after_last_change_seconds}
    */
    readonly waitAfterLastChangeSeconds?: number;
}
export declare function jobTriggersTableUpdateToTerraform(struct?: JobTriggersTableUpdateOutputReference | JobTriggersTableUpdate): any;
export declare function jobTriggersTableUpdateToHclTerraform(struct?: JobTriggersTableUpdateOutputReference | JobTriggersTableUpdate): any;
export declare class JobTriggersTableUpdateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTriggersTableUpdate | undefined;
    set internalValue(value: JobTriggersTableUpdate | undefined);
    private _condition?;
    get condition(): string;
    set condition(value: string);
    resetCondition(): void;
    get conditionInput(): string | undefined;
    private _minTimeBetweenTriggersSeconds?;
    get minTimeBetweenTriggersSeconds(): number;
    set minTimeBetweenTriggersSeconds(value: number);
    resetMinTimeBetweenTriggersSeconds(): void;
    get minTimeBetweenTriggersSecondsInput(): number | undefined;
    private _tableNames?;
    get tableNames(): string[];
    set tableNames(value: string[]);
    get tableNamesInput(): string[] | undefined;
    private _waitAfterLastChangeSeconds?;
    get waitAfterLastChangeSeconds(): number;
    set waitAfterLastChangeSeconds(value: number);
    resetWaitAfterLastChangeSeconds(): void;
    get waitAfterLastChangeSecondsInput(): number | undefined;
}
export interface JobTriggers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#pause_status Job#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * continuous block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#continuous Job#continuous}
    */
    readonly continuous?: JobTriggersContinuous;
    /**
    * file_arrival block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#file_arrival Job#file_arrival}
    */
    readonly fileArrival?: JobTriggersFileArrival;
    /**
    * job_completion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#job_completion Job#job_completion}
    */
    readonly jobCompletion?: JobTriggersJobCompletion;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#model Job#model}
    */
    readonly model?: JobTriggersModel;
    /**
    * periodic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#periodic Job#periodic}
    */
    readonly periodic?: JobTriggersPeriodic;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#schedule Job#schedule}
    */
    readonly schedule?: JobTriggersSchedule;
    /**
    * sql_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#sql_condition Job#sql_condition}
    */
    readonly sqlCondition?: JobTriggersSqlCondition;
    /**
    * table_update block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#table_update Job#table_update}
    */
    readonly tableUpdate?: JobTriggersTableUpdate;
}
export declare function jobTriggersToTerraform(struct?: JobTriggers | cdktn.IResolvable): any;
export declare function jobTriggersToHclTerraform(struct?: JobTriggers | cdktn.IResolvable): any;
export declare class JobTriggersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTriggers | cdktn.IResolvable | undefined;
    set internalValue(value: JobTriggers | cdktn.IResolvable | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _continuous;
    get continuous(): JobTriggersContinuousOutputReference;
    putContinuous(value: JobTriggersContinuous): void;
    resetContinuous(): void;
    get continuousInput(): JobTriggersContinuous | undefined;
    private _fileArrival;
    get fileArrival(): JobTriggersFileArrivalOutputReference;
    putFileArrival(value: JobTriggersFileArrival): void;
    resetFileArrival(): void;
    get fileArrivalInput(): JobTriggersFileArrival | undefined;
    private _jobCompletion;
    get jobCompletion(): JobTriggersJobCompletionOutputReference;
    putJobCompletion(value: JobTriggersJobCompletion): void;
    resetJobCompletion(): void;
    get jobCompletionInput(): JobTriggersJobCompletion | undefined;
    private _model;
    get model(): JobTriggersModelOutputReference;
    putModel(value: JobTriggersModel): void;
    resetModel(): void;
    get modelInput(): JobTriggersModel | undefined;
    private _periodic;
    get periodic(): JobTriggersPeriodicOutputReference;
    putPeriodic(value: JobTriggersPeriodic): void;
    resetPeriodic(): void;
    get periodicInput(): JobTriggersPeriodic | undefined;
    private _schedule;
    get schedule(): JobTriggersScheduleOutputReference;
    putSchedule(value: JobTriggersSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): JobTriggersSchedule | undefined;
    private _sqlCondition;
    get sqlCondition(): JobTriggersSqlConditionOutputReference;
    putSqlCondition(value: JobTriggersSqlCondition): void;
    resetSqlCondition(): void;
    get sqlConditionInput(): JobTriggersSqlCondition | undefined;
    private _tableUpdate;
    get tableUpdate(): JobTriggersTableUpdateOutputReference;
    putTableUpdate(value: JobTriggersTableUpdate): void;
    resetTableUpdate(): void;
    get tableUpdateInput(): JobTriggersTableUpdate | undefined;
}
export declare class JobTriggersList extends cdktn.ComplexList {
    internalValue?: JobTriggers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTriggersOutputReference;
}
export interface JobWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface JobWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnFailureToTerraform(struct?: JobWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnFailureToHclTerraform(struct?: JobWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnFailureOutputReference;
}
export interface JobWebhookNotificationsOnMaintenanceComplete {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnMaintenanceCompleteToTerraform(struct?: JobWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnMaintenanceCompleteToHclTerraform(struct?: JobWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnMaintenanceCompleteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnMaintenanceComplete | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnMaintenanceCompleteList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnMaintenanceComplete[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnMaintenanceCompleteOutputReference;
}
export interface JobWebhookNotificationsOnMaintenanceStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnMaintenanceStartToTerraform(struct?: JobWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnMaintenanceStartToHclTerraform(struct?: JobWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnMaintenanceStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnMaintenanceStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnMaintenanceStartList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnMaintenanceStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnMaintenanceStartOutputReference;
}
export interface JobWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnStartToTerraform(struct?: JobWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnStartToHclTerraform(struct?: JobWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnStartOutputReference;
}
export interface JobWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface JobWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobWebhookNotificationsOnSuccessToTerraform(struct?: JobWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function jobWebhookNotificationsOnSuccessToHclTerraform(struct?: JobWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class JobWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: JobWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobWebhookNotificationsOnSuccessOutputReference;
}
export interface JobWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_maintenance_complete block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_maintenance_complete Job#on_maintenance_complete}
    */
    readonly onMaintenanceComplete?: JobWebhookNotificationsOnMaintenanceComplete[] | cdktn.IResolvable;
    /**
    * on_maintenance_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_maintenance_start Job#on_maintenance_start}
    */
    readonly onMaintenanceStart?: JobWebhookNotificationsOnMaintenanceStart[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: JobWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function jobWebhookNotificationsToTerraform(struct?: JobWebhookNotificationsOutputReference | JobWebhookNotifications): any;
export declare function jobWebhookNotificationsToHclTerraform(struct?: JobWebhookNotificationsOutputReference | JobWebhookNotifications): any;
export declare class JobWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobWebhookNotifications | undefined;
    set internalValue(value: JobWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): JobWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | JobWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): JobWebhookNotificationsOnFailureList;
    putOnFailure(value: JobWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | JobWebhookNotificationsOnFailure[] | undefined;
    private _onMaintenanceComplete;
    get onMaintenanceComplete(): JobWebhookNotificationsOnMaintenanceCompleteList;
    putOnMaintenanceComplete(value: JobWebhookNotificationsOnMaintenanceComplete[] | cdktn.IResolvable): void;
    resetOnMaintenanceComplete(): void;
    get onMaintenanceCompleteInput(): cdktn.IResolvable | JobWebhookNotificationsOnMaintenanceComplete[] | undefined;
    private _onMaintenanceStart;
    get onMaintenanceStart(): JobWebhookNotificationsOnMaintenanceStartList;
    putOnMaintenanceStart(value: JobWebhookNotificationsOnMaintenanceStart[] | cdktn.IResolvable): void;
    resetOnMaintenanceStart(): void;
    get onMaintenanceStartInput(): cdktn.IResolvable | JobWebhookNotificationsOnMaintenanceStart[] | undefined;
    private _onStart;
    get onStart(): JobWebhookNotificationsOnStartList;
    putOnStart(value: JobWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | JobWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): JobWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: JobWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | JobWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): JobWebhookNotificationsOnSuccessList;
    putOnSuccess(value: JobWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | JobWebhookNotificationsOnSuccess[] | undefined;
}
