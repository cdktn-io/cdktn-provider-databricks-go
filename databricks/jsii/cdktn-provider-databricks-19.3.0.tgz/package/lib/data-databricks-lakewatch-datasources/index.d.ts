/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchDatasourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#catalog_name DataDatabricksLakewatchDatasources#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#filter DataDatabricksLakewatchDatasources#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#page_size DataDatabricksLakewatchDatasources#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#provider_config DataDatabricksLakewatchDatasources#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchDatasourcesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#schema_name DataDatabricksLakewatchDatasources#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#view DataDatabricksLakewatchDatasources#view}
    */
    readonly view?: string;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#catalog_name DataDatabricksLakewatchDatasources#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#schema_name DataDatabricksLakewatchDatasources#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#table_name DataDatabricksLakewatchDatasources#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTableToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#header_retention DataDatabricksLakewatchDatasources#header_retention}
    */
    readonly headerRetention?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogsToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogsToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs | cdktn.IResolvable | undefined);
    private _headerRetention?;
    get headerRetention(): boolean | cdktn.IResolvable;
    set headerRetention(value: boolean | cdktn.IResolvable);
    resetHeaderRetention(): void;
    get headerRetentionInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#path DataDatabricksLakewatchDatasources#path}
    */
    readonly path: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArrayToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArrayToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArrayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#cloud_watch_logs DataDatabricksLakewatchDatasources#cloud_watch_logs}
    */
    readonly cloudWatchLogs?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#json_array DataDatabricksLakewatchDatasources#json_array}
    */
    readonly jsonArray?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope | cdktn.IResolvable | undefined);
    private _cloudWatchLogs;
    get cloudWatchLogs(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogsOutputReference;
    putCloudWatchLogs(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs): void;
    resetCloudWatchLogs(): void;
    get cloudWatchLogsInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeCloudWatchLogs | undefined;
    private _jsonArray;
    get jsonArray(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArrayOutputReference;
    putJsonArray(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray): void;
    resetJsonArray(): void;
    get jsonArrayInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeJsonArray | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#catalog_name DataDatabricksLakewatchDatasources#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#schema_name DataDatabricksLakewatchDatasources#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#table_name DataDatabricksLakewatchDatasources#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTableToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesAutoloader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#aws_secret_scope DataDatabricksLakewatchDatasources#aws_secret_scope}
    */
    readonly awsSecretScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#envelope DataDatabricksLakewatchDatasources#envelope}
    */
    readonly envelope?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#format DataDatabricksLakewatchDatasources#format}
    */
    readonly format: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#format_options DataDatabricksLakewatchDatasources#format_options}
    */
    readonly formatOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#include_existing_files DataDatabricksLakewatchDatasources#include_existing_files}
    */
    readonly includeExistingFiles?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#location DataDatabricksLakewatchDatasources#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#override_partition_columns DataDatabricksLakewatchDatasources#override_partition_columns}
    */
    readonly overridePartitionColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#queue_url DataDatabricksLakewatchDatasources#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#raw_table DataDatabricksLakewatchDatasources#raw_table}
    */
    readonly rawTable: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#service_credentials DataDatabricksLakewatchDatasources#service_credentials}
    */
    readonly serviceCredentials?: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloader): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesAutoloaderToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesAutoloader): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloader | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloader | undefined);
    private _awsSecretScope?;
    get awsSecretScope(): string;
    set awsSecretScope(value: string);
    resetAwsSecretScope(): void;
    get awsSecretScopeInput(): string | undefined;
    get effectiveIncludeExistingFiles(): cdktn.IResolvable;
    private _effectiveRawTable;
    get effectiveRawTable(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEffectiveRawTableOutputReference;
    private _envelope;
    get envelope(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelopeOutputReference;
    putEnvelope(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope): void;
    resetEnvelope(): void;
    get envelopeInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderEnvelope | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    get formatInput(): string | undefined;
    private _formatOptions?;
    get formatOptions(): {
        [key: string]: string;
    };
    set formatOptions(value: {
        [key: string]: string;
    });
    resetFormatOptions(): void;
    get formatOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _includeExistingFiles?;
    get includeExistingFiles(): boolean | cdktn.IResolvable;
    set includeExistingFiles(value: boolean | cdktn.IResolvable);
    resetIncludeExistingFiles(): void;
    get includeExistingFilesInput(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _overridePartitionColumns?;
    get overridePartitionColumns(): string[];
    set overridePartitionColumns(value: string[]);
    resetOverridePartitionColumns(): void;
    get overridePartitionColumnsInput(): string[] | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _rawTable;
    get rawTable(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTableOutputReference;
    putRawTable(value: DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable): void;
    get rawTableInput(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderRawTable | undefined;
    private _serviceCredentials?;
    get serviceCredentials(): string;
    set serviceCredentials(value: string);
    resetServiceCredentials(): void;
    get serviceCredentialsInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesCreatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#display_name DataDatabricksLakewatchDatasources#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#email DataDatabricksLakewatchDatasources#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#id DataDatabricksLakewatchDatasources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#principal_type DataDatabricksLakewatchDatasources#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesCreatedByToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesCreatedBy): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesCreatedByToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesCreatedBy): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesCreatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesCreatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesCreatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesExistingTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#catalog DataDatabricksLakewatchDatasources#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#include_existing_rows DataDatabricksLakewatchDatasources#include_existing_rows}
    */
    readonly includeExistingRows?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#name DataDatabricksLakewatchDatasources#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#schema DataDatabricksLakewatchDatasources#schema}
    */
    readonly schema?: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesExistingTableToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesExistingTable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesExistingTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesExistingTable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesExistingTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesExistingTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesExistingTable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    get effectiveCatalog(): string;
    get effectiveName(): string;
    get effectiveSchema(): string;
    private _includeExistingRows?;
    get includeExistingRows(): boolean | cdktn.IResolvable;
    set includeExistingRows(value: boolean | cdktn.IResolvable);
    resetIncludeExistingRows(): void;
    get includeExistingRowsInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesOwner {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#display_name DataDatabricksLakewatchDatasources#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#email DataDatabricksLakewatchDatasources#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#id DataDatabricksLakewatchDatasources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#principal_type DataDatabricksLakewatchDatasources#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesOwnerToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesOwner): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesOwnerToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesOwner): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesOwnerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesOwner | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesOwner | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#catalog_name DataDatabricksLakewatchDatasources#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#schema_name DataDatabricksLakewatchDatasources#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#table_name DataDatabricksLakewatchDatasources#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTableToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#catalog_name DataDatabricksLakewatchDatasources#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#schema_name DataDatabricksLakewatchDatasources#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#table_name DataDatabricksLakewatchDatasources#table_name}
    */
    readonly tableName: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTableToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTableToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable | cdktn.IResolvable | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesParsers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#id DataDatabricksLakewatchDatasources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#target_table DataDatabricksLakewatchDatasources#target_table}
    */
    readonly targetTable?: DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#version DataDatabricksLakewatchDatasources#version}
    */
    readonly version: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesParsersToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesParsers): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesParsersToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesParsers): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesParsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesParsers | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesParsers | undefined);
    private _effectiveTargetTable;
    get effectiveTargetTable(): DataDatabricksLakewatchDatasourcesDatasourcesParsersEffectiveTargetTableOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _targetTable;
    get targetTable(): DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTableOutputReference;
    putTargetTable(value: DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable): void;
    resetTargetTable(): void;
    get targetTableInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourcesDatasourcesParsersTargetTable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
}
export declare class DataDatabricksLakewatchDatasourcesDatasourcesParsersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchDatasourcesDatasourcesParsers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchDatasourcesDatasourcesParsersOutputReference;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#workspace_id DataDatabricksLakewatchDatasources#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesProviderConfigToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#at_least_every DataDatabricksLakewatchDatasources#at_least_every}
    */
    readonly atLeastEvery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#compute_group DataDatabricksLakewatchDatasources#compute_group}
    */
    readonly computeGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#continuous DataDatabricksLakewatchDatasources#continuous}
    */
    readonly continuous?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#cron_expression DataDatabricksLakewatchDatasources#cron_expression}
    */
    readonly cronExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#enabled DataDatabricksLakewatchDatasources#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesScheduleToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesSchedule): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesScheduleToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesSchedule): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesSchedule | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesSchedule | undefined);
    private _atLeastEvery?;
    get atLeastEvery(): string;
    set atLeastEvery(value: string);
    resetAtLeastEvery(): void;
    get atLeastEveryInput(): string | undefined;
    private _computeGroup?;
    get computeGroup(): string;
    set computeGroup(value: string);
    resetComputeGroup(): void;
    get computeGroupInput(): string | undefined;
    private _continuous?;
    get continuous(): boolean | cdktn.IResolvable;
    set continuous(value: boolean | cdktn.IResolvable);
    resetContinuous(): void;
    get continuousInput(): boolean | cdktn.IResolvable | undefined;
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJob {
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJobToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJob): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJobToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJob): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJob | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJob | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipeline {
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipelineToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipeline): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipelineToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipeline): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipelineOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipeline | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipeline | undefined);
    get createTime(): string;
    get jobId(): string;
    get lastCompleteTime(): string;
    get lastErrorMessage(): string;
    get lastStartTime(): string;
    get lastStatusChangeTime(): string;
    get lifecycleState(): string;
    get pipelineId(): string;
    get runState(): string;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesStatus {
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesStatusToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesStatus): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesStatusToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesStatus): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesStatus | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesStatus | undefined);
    private _ingestionJob;
    get ingestionJob(): DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionJobOutputReference;
    private _ingestionPipeline;
    get ingestionPipeline(): DataDatabricksLakewatchDatasourcesDatasourcesStatusIngestionPipelineOutputReference;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#configuration DataDatabricksLakewatchDatasources#configuration}
    */
    readonly configuration?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#connection_name DataDatabricksLakewatchDatasources#connection_name}
    */
    readonly connectionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#start_time DataDatabricksLakewatchDatasources#start_time}
    */
    readonly startTime?: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnectionToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnection): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnectionToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnection): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnection | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnection | undefined);
    private _configuration?;
    get configuration(): {
        [key: string]: string;
    };
    set configuration(value: {
        [key: string]: string;
    });
    resetConfiguration(): void;
    get configurationInput(): {
        [key: string]: string;
    } | undefined;
    private _connectionName?;
    get connectionName(): string;
    set connectionName(value: string);
    get connectionNameInput(): string | undefined;
    get connector(): string;
    get effectiveStartTime(): string;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasourcesUpdatedBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#display_name DataDatabricksLakewatchDatasources#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#email DataDatabricksLakewatchDatasources#email}
    */
    readonly email?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#id DataDatabricksLakewatchDatasources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#principal_type DataDatabricksLakewatchDatasources#principal_type}
    */
    readonly principalType?: string;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesUpdatedByToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesUpdatedBy): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesUpdatedByToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasourcesUpdatedBy): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesUpdatedByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasourcesUpdatedBy | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasourcesUpdatedBy | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    resetPrincipalType(): void;
    get principalTypeInput(): string | undefined;
}
export interface DataDatabricksLakewatchDatasourcesDatasources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#name DataDatabricksLakewatchDatasources#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#provider_config DataDatabricksLakewatchDatasources#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig;
}
export declare function dataDatabricksLakewatchDatasourcesDatasourcesToTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasources): any;
export declare function dataDatabricksLakewatchDatasourcesDatasourcesToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesDatasources): any;
export declare class DataDatabricksLakewatchDatasourcesDatasourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchDatasourcesDatasources | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesDatasources | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _autoloader;
    get autoloader(): DataDatabricksLakewatchDatasourcesDatasourcesAutoloaderOutputReference;
    get catalogName(): string;
    get computeMode(): string;
    get computeWorkspaceId(): string;
    get createTime(): string;
    private _createdBy;
    get createdBy(): DataDatabricksLakewatchDatasourcesDatasourcesCreatedByOutputReference;
    get datasourceId(): string;
    get datasourceName(): string;
    get description(): string;
    get effectiveCatalogName(): string;
    get effectiveDatasourceName(): string;
    get effectiveRunAsPrincipal(): string;
    get effectiveSchemaName(): string;
    get etag(): string;
    private _existingTable;
    get existingTable(): DataDatabricksLakewatchDatasourcesDatasourcesExistingTableOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner;
    get owner(): DataDatabricksLakewatchDatasourcesDatasourcesOwnerOutputReference;
    private _parsers;
    get parsers(): DataDatabricksLakewatchDatasourcesDatasourcesParsersList;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchDatasourcesDatasourcesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourcesDatasourcesProviderConfig | undefined;
    get runAsPrincipal(): string;
    private _schedule;
    get schedule(): DataDatabricksLakewatchDatasourcesDatasourcesScheduleOutputReference;
    get schemaName(): string;
    private _status;
    get status(): DataDatabricksLakewatchDatasourcesDatasourcesStatusOutputReference;
    private _unityCatalogConnection;
    get unityCatalogConnection(): DataDatabricksLakewatchDatasourcesDatasourcesUnityCatalogConnectionOutputReference;
    get updateTime(): string;
    private _updatedBy;
    get updatedBy(): DataDatabricksLakewatchDatasourcesDatasourcesUpdatedByOutputReference;
    get version(): number;
    get warehouseId(): string;
}
export declare class DataDatabricksLakewatchDatasourcesDatasourcesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchDatasourcesDatasources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchDatasourcesDatasourcesOutputReference;
}
export interface DataDatabricksLakewatchDatasourcesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#workspace_id DataDatabricksLakewatchDatasources#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchDatasourcesProviderConfigToTerraform(struct?: DataDatabricksLakewatchDatasourcesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchDatasourcesProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchDatasourcesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchDatasourcesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchDatasourcesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchDatasourcesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources databricks_lakewatch_datasources}
*/
export declare class DataDatabricksLakewatchDatasources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_datasources";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchDatasources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchDatasources to import
    * @param importFromId The id of the existing DataDatabricksLakewatchDatasources that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchDatasources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_datasources databricks_lakewatch_datasources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchDatasourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksLakewatchDatasourcesConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _datasources;
    get datasources(): DataDatabricksLakewatchDatasourcesDatasourcesList;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchDatasourcesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchDatasourcesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchDatasourcesProviderConfig | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
