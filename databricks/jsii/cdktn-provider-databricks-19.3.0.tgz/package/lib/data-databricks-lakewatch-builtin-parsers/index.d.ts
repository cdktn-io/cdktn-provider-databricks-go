/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksLakewatchBuiltinParsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#filter DataDatabricksLakewatchBuiltinParsers#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#page_size DataDatabricksLakewatchBuiltinParsers#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#provider_config DataDatabricksLakewatchBuiltinParsers#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchBuiltinParsersProviderConfig;
}
export interface DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#workspace_id DataDatabricksLakewatchBuiltinParsers#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfigToTerraform(struct?: DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksLakewatchBuiltinParsersBuiltinParsersTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#key DataDatabricksLakewatchBuiltinParsers#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#value DataDatabricksLakewatchBuiltinParsers#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksLakewatchBuiltinParsersBuiltinParsersTagsToTerraform(struct?: DataDatabricksLakewatchBuiltinParsersBuiltinParsersTags): any;
export declare function dataDatabricksLakewatchBuiltinParsersBuiltinParsersTagsToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParsersBuiltinParsersTags): any;
export declare class DataDatabricksLakewatchBuiltinParsersBuiltinParsersTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchBuiltinParsersBuiltinParsersTags | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParsersBuiltinParsersTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksLakewatchBuiltinParsersBuiltinParsersTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchBuiltinParsersBuiltinParsersTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchBuiltinParsersBuiltinParsersTagsOutputReference;
}
export interface DataDatabricksLakewatchBuiltinParsersBuiltinParsers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#name DataDatabricksLakewatchBuiltinParsers#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#provider_config DataDatabricksLakewatchBuiltinParsers#provider_config}
    */
    readonly providerConfig?: DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig;
}
export declare function dataDatabricksLakewatchBuiltinParsersBuiltinParsersToTerraform(struct?: DataDatabricksLakewatchBuiltinParsersBuiltinParsers): any;
export declare function dataDatabricksLakewatchBuiltinParsersBuiltinParsersToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParsersBuiltinParsers): any;
export declare class DataDatabricksLakewatchBuiltinParsersBuiltinParsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksLakewatchBuiltinParsersBuiltinParsers | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParsersBuiltinParsers | undefined);
    get latestVersion(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parserId(): string;
    get parserName(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchBuiltinParsersBuiltinParsersProviderConfig | undefined;
    private _tags;
    get tags(): DataDatabricksLakewatchBuiltinParsersBuiltinParsersTagsList;
}
export declare class DataDatabricksLakewatchBuiltinParsersBuiltinParsersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksLakewatchBuiltinParsersBuiltinParsers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksLakewatchBuiltinParsersBuiltinParsersOutputReference;
}
export interface DataDatabricksLakewatchBuiltinParsersProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#workspace_id DataDatabricksLakewatchBuiltinParsers#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksLakewatchBuiltinParsersProviderConfigToTerraform(struct?: DataDatabricksLakewatchBuiltinParsersProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksLakewatchBuiltinParsersProviderConfigToHclTerraform(struct?: DataDatabricksLakewatchBuiltinParsersProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksLakewatchBuiltinParsersProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksLakewatchBuiltinParsersProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksLakewatchBuiltinParsersProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers databricks_lakewatch_builtin_parsers}
*/
export declare class DataDatabricksLakewatchBuiltinParsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_lakewatch_builtin_parsers";
    /**
    * Generates CDKTN code for importing a DataDatabricksLakewatchBuiltinParsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksLakewatchBuiltinParsers to import
    * @param importFromId The id of the existing DataDatabricksLakewatchBuiltinParsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksLakewatchBuiltinParsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.145.0/docs/data-sources/lakewatch_builtin_parsers databricks_lakewatch_builtin_parsers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksLakewatchBuiltinParsersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksLakewatchBuiltinParsersConfig);
    private _builtinParsers;
    get builtinParsers(): DataDatabricksLakewatchBuiltinParsersBuiltinParsersList;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksLakewatchBuiltinParsersProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksLakewatchBuiltinParsersProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksLakewatchBuiltinParsersProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
