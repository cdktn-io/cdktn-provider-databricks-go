/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksNotificationDestinationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#display_name_contains DataDatabricksNotificationDestinations#display_name_contains}
    */
    readonly displayNameContains?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#provider_config DataDatabricksNotificationDestinations#provider_config}
    */
    readonly providerConfig?: DataDatabricksNotificationDestinationsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#type DataDatabricksNotificationDestinations#type}
    */
    readonly type?: string;
}
export interface DataDatabricksNotificationDestinationsNotificationDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#destination_type DataDatabricksNotificationDestinations#destination_type}
    */
    readonly destinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#display_name DataDatabricksNotificationDestinations#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#id DataDatabricksNotificationDestinations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function dataDatabricksNotificationDestinationsNotificationDestinationsToTerraform(struct?: DataDatabricksNotificationDestinationsNotificationDestinations): any;
export declare function dataDatabricksNotificationDestinationsNotificationDestinationsToHclTerraform(struct?: DataDatabricksNotificationDestinationsNotificationDestinations): any;
export declare class DataDatabricksNotificationDestinationsNotificationDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksNotificationDestinationsNotificationDestinations | undefined;
    set internalValue(value: DataDatabricksNotificationDestinationsNotificationDestinations | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    resetDestinationType(): void;
    get destinationTypeInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export declare class DataDatabricksNotificationDestinationsNotificationDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksNotificationDestinationsNotificationDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksNotificationDestinationsNotificationDestinationsOutputReference;
}
export interface DataDatabricksNotificationDestinationsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#workspace_id DataDatabricksNotificationDestinations#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksNotificationDestinationsProviderConfigToTerraform(struct?: DataDatabricksNotificationDestinationsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksNotificationDestinationsProviderConfigToHclTerraform(struct?: DataDatabricksNotificationDestinationsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksNotificationDestinationsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksNotificationDestinationsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksNotificationDestinationsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations databricks_notification_destinations}
*/
export declare class DataDatabricksNotificationDestinations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_notification_destinations";
    /**
    * Generates CDKTN code for importing a DataDatabricksNotificationDestinations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksNotificationDestinations to import
    * @param importFromId The id of the existing DataDatabricksNotificationDestinations that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksNotificationDestinations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/notification_destinations databricks_notification_destinations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksNotificationDestinationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksNotificationDestinationsConfig);
    private _displayNameContains?;
    get displayNameContains(): string;
    set displayNameContains(value: string);
    resetDisplayNameContains(): void;
    get displayNameContainsInput(): string | undefined;
    private _notificationDestinations;
    get notificationDestinations(): DataDatabricksNotificationDestinationsNotificationDestinationsList;
    private _providerConfig;
    get providerConfig(): DataDatabricksNotificationDestinationsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksNotificationDestinationsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksNotificationDestinationsProviderConfig | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
