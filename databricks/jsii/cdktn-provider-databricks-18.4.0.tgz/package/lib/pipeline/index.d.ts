/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { PipelineCluster, PipelineClusterList, PipelineDeployment, PipelineDeploymentOutputReference, PipelineEnvironment, PipelineEnvironmentOutputReference, PipelineEventLog, PipelineEventLogOutputReference, PipelineFilters, PipelineFiltersOutputReference, PipelineGatewayDefinition, PipelineGatewayDefinitionOutputReference, PipelineIngestionDefinition, PipelineIngestionDefinitionOutputReference, PipelineLatestUpdates, PipelineLatestUpdatesList, PipelineLibrary, PipelineLibraryList, PipelineNotification, PipelineNotificationList, PipelineProviderConfig, PipelineProviderConfigOutputReference, PipelineRestartWindow, PipelineRestartWindowOutputReference, PipelineRunAs, PipelineRunAsOutputReference, PipelineTimeouts, PipelineTimeoutsOutputReference, PipelineTrigger, PipelineTriggerOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#allow_duplicate_names Pipeline#allow_duplicate_names}
    */
    readonly allowDuplicateNames?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#budget_policy_id Pipeline#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#catalog Pipeline#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#cause Pipeline#cause}
    */
    readonly cause?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#channel Pipeline#channel}
    */
    readonly channel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#cluster_id Pipeline#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#configuration Pipeline#configuration}
    */
    readonly configuration?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#continuous Pipeline#continuous}
    */
    readonly continuous?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#creator_user_name Pipeline#creator_user_name}
    */
    readonly creatorUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#development Pipeline#development}
    */
    readonly development?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#edition Pipeline#edition}
    */
    readonly edition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#expected_last_modified Pipeline#expected_last_modified}
    */
    readonly expectedLastModified?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#health Pipeline#health}
    */
    readonly health?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#id Pipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#last_modified Pipeline#last_modified}
    */
    readonly lastModified?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#name Pipeline#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#photon Pipeline#photon}
    */
    readonly photon?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#root_path Pipeline#root_path}
    */
    readonly rootPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#run_as_user_name Pipeline#run_as_user_name}
    */
    readonly runAsUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#schema Pipeline#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#serverless Pipeline#serverless}
    */
    readonly serverless?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#serverless_compute_id Pipeline#serverless_compute_id}
    */
    readonly serverlessComputeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#state Pipeline#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#storage Pipeline#storage}
    */
    readonly storage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#tags Pipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#target Pipeline#target}
    */
    readonly target?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#url Pipeline#url}
    */
    readonly url?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#usage_policy_id Pipeline#usage_policy_id}
    */
    readonly usagePolicyId?: string;
    /**
    * cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#cluster Pipeline#cluster}
    */
    readonly cluster?: PipelineCluster[] | cdktn.IResolvable;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#deployment Pipeline#deployment}
    */
    readonly deployment?: PipelineDeployment;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#environment Pipeline#environment}
    */
    readonly environment?: PipelineEnvironment;
    /**
    * event_log block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#event_log Pipeline#event_log}
    */
    readonly eventLog?: PipelineEventLog;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#filters Pipeline#filters}
    */
    readonly filters?: PipelineFilters;
    /**
    * gateway_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#gateway_definition Pipeline#gateway_definition}
    */
    readonly gatewayDefinition?: PipelineGatewayDefinition;
    /**
    * ingestion_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#ingestion_definition Pipeline#ingestion_definition}
    */
    readonly ingestionDefinition?: PipelineIngestionDefinition;
    /**
    * latest_updates block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#latest_updates Pipeline#latest_updates}
    */
    readonly latestUpdates?: PipelineLatestUpdates[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#library Pipeline#library}
    */
    readonly library?: PipelineLibrary[] | cdktn.IResolvable;
    /**
    * notification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#notification Pipeline#notification}
    */
    readonly notification?: PipelineNotification[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#provider_config Pipeline#provider_config}
    */
    readonly providerConfig?: PipelineProviderConfig;
    /**
    * restart_window block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#restart_window Pipeline#restart_window}
    */
    readonly restartWindow?: PipelineRestartWindow;
    /**
    * run_as block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#run_as Pipeline#run_as}
    */
    readonly runAs?: PipelineRunAs;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#timeouts Pipeline#timeouts}
    */
    readonly timeouts?: PipelineTimeouts;
    /**
    * trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#trigger Pipeline#trigger}
    */
    readonly trigger?: PipelineTrigger;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline databricks_pipeline}
*/
export declare class Pipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_pipeline";
    /**
    * Generates CDKTN code for importing a Pipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Pipeline to import
    * @param importFromId The id of the existing Pipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Pipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline databricks_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PipelineConfig = {}
    */
    constructor(scope: Construct, id: string, config?: PipelineConfig);
    private _allowDuplicateNames?;
    get allowDuplicateNames(): boolean | cdktn.IResolvable;
    set allowDuplicateNames(value: boolean | cdktn.IResolvable);
    resetAllowDuplicateNames(): void;
    get allowDuplicateNamesInput(): boolean | cdktn.IResolvable | undefined;
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _cause?;
    get cause(): string;
    set cause(value: string);
    resetCause(): void;
    get causeInput(): string | undefined;
    private _channel?;
    get channel(): string;
    set channel(value: string);
    resetChannel(): void;
    get channelInput(): string | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _configuration?;
    get configuration(): {
        [key: string]: string;
    };
    set configuration(value: {
        [key: string]: string;
    });
    resetConfiguration(): void;
    get configurationInput(): {
        [key: string]: string;
    } | undefined;
    private _continuous?;
    get continuous(): boolean | cdktn.IResolvable;
    set continuous(value: boolean | cdktn.IResolvable);
    resetContinuous(): void;
    get continuousInput(): boolean | cdktn.IResolvable | undefined;
    private _creatorUserName?;
    get creatorUserName(): string;
    set creatorUserName(value: string);
    resetCreatorUserName(): void;
    get creatorUserNameInput(): string | undefined;
    private _development?;
    get development(): boolean | cdktn.IResolvable;
    set development(value: boolean | cdktn.IResolvable);
    resetDevelopment(): void;
    get developmentInput(): boolean | cdktn.IResolvable | undefined;
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    private _expectedLastModified?;
    get expectedLastModified(): number;
    set expectedLastModified(value: number);
    resetExpectedLastModified(): void;
    get expectedLastModifiedInput(): number | undefined;
    private _health?;
    get health(): string;
    set health(value: string);
    resetHealth(): void;
    get healthInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastModified?;
    get lastModified(): number;
    set lastModified(value: number);
    resetLastModified(): void;
    get lastModifiedInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _photon?;
    get photon(): boolean | cdktn.IResolvable;
    set photon(value: boolean | cdktn.IResolvable);
    resetPhoton(): void;
    get photonInput(): boolean | cdktn.IResolvable | undefined;
    private _rootPath?;
    get rootPath(): string;
    set rootPath(value: string);
    resetRootPath(): void;
    get rootPathInput(): string | undefined;
    private _runAsUserName?;
    get runAsUserName(): string;
    set runAsUserName(value: string);
    resetRunAsUserName(): void;
    get runAsUserNameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _serverless?;
    get serverless(): boolean | cdktn.IResolvable;
    set serverless(value: boolean | cdktn.IResolvable);
    resetServerless(): void;
    get serverlessInput(): boolean | cdktn.IResolvable | undefined;
    private _serverlessComputeId?;
    get serverlessComputeId(): string;
    set serverlessComputeId(value: string);
    resetServerlessComputeId(): void;
    get serverlessComputeIdInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _storage?;
    get storage(): string;
    set storage(value: string);
    resetStorage(): void;
    get storageInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    private _cluster;
    get cluster(): PipelineClusterList;
    putCluster(value: PipelineCluster[] | cdktn.IResolvable): void;
    resetCluster(): void;
    get clusterInput(): cdktn.IResolvable | PipelineCluster[] | undefined;
    private _deployment;
    get deployment(): PipelineDeploymentOutputReference;
    putDeployment(value: PipelineDeployment): void;
    resetDeployment(): void;
    get deploymentInput(): PipelineDeployment | undefined;
    private _environment;
    get environment(): PipelineEnvironmentOutputReference;
    putEnvironment(value: PipelineEnvironment): void;
    resetEnvironment(): void;
    get environmentInput(): PipelineEnvironment | undefined;
    private _eventLog;
    get eventLog(): PipelineEventLogOutputReference;
    putEventLog(value: PipelineEventLog): void;
    resetEventLog(): void;
    get eventLogInput(): PipelineEventLog | undefined;
    private _filters;
    get filters(): PipelineFiltersOutputReference;
    putFilters(value: PipelineFilters): void;
    resetFilters(): void;
    get filtersInput(): PipelineFilters | undefined;
    private _gatewayDefinition;
    get gatewayDefinition(): PipelineGatewayDefinitionOutputReference;
    putGatewayDefinition(value: PipelineGatewayDefinition): void;
    resetGatewayDefinition(): void;
    get gatewayDefinitionInput(): PipelineGatewayDefinition | undefined;
    private _ingestionDefinition;
    get ingestionDefinition(): PipelineIngestionDefinitionOutputReference;
    putIngestionDefinition(value: PipelineIngestionDefinition): void;
    resetIngestionDefinition(): void;
    get ingestionDefinitionInput(): PipelineIngestionDefinition | undefined;
    private _latestUpdates;
    get latestUpdates(): PipelineLatestUpdatesList;
    putLatestUpdates(value: PipelineLatestUpdates[] | cdktn.IResolvable): void;
    resetLatestUpdates(): void;
    get latestUpdatesInput(): cdktn.IResolvable | PipelineLatestUpdates[] | undefined;
    private _library;
    get library(): PipelineLibraryList;
    putLibrary(value: PipelineLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | PipelineLibrary[] | undefined;
    private _notification;
    get notification(): PipelineNotificationList;
    putNotification(value: PipelineNotification[] | cdktn.IResolvable): void;
    resetNotification(): void;
    get notificationInput(): cdktn.IResolvable | PipelineNotification[] | undefined;
    private _providerConfig;
    get providerConfig(): PipelineProviderConfigOutputReference;
    putProviderConfig(value: PipelineProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): PipelineProviderConfig | undefined;
    private _restartWindow;
    get restartWindow(): PipelineRestartWindowOutputReference;
    putRestartWindow(value: PipelineRestartWindow): void;
    resetRestartWindow(): void;
    get restartWindowInput(): PipelineRestartWindow | undefined;
    private _runAs;
    get runAs(): PipelineRunAsOutputReference;
    putRunAs(value: PipelineRunAs): void;
    resetRunAs(): void;
    get runAsInput(): PipelineRunAs | undefined;
    private _timeouts;
    get timeouts(): PipelineTimeoutsOutputReference;
    putTimeouts(value: PipelineTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PipelineTimeouts | undefined;
    private _trigger;
    get trigger(): PipelineTriggerOutputReference;
    putTrigger(value: PipelineTrigger): void;
    resetTrigger(): void;
    get triggerInput(): PipelineTrigger | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
