/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface PipelineTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#default Pipeline#default}
    */
    readonly default?: string;
}
export declare function pipelineTimeoutsToTerraform(struct?: PipelineTimeouts | cdktn.IResolvable): any;
export declare function pipelineTimeoutsToHclTerraform(struct?: PipelineTimeouts | cdktn.IResolvable): any;
export declare class PipelineTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
export interface PipelineTriggerCron {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#quartz_cron_schedule Pipeline#quartz_cron_schedule}
    */
    readonly quartzCronSchedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#timezone_id Pipeline#timezone_id}
    */
    readonly timezoneId?: string;
}
export declare function pipelineTriggerCronToTerraform(struct?: PipelineTriggerCronOutputReference | PipelineTriggerCron): any;
export declare function pipelineTriggerCronToHclTerraform(struct?: PipelineTriggerCronOutputReference | PipelineTriggerCron): any;
export declare class PipelineTriggerCronOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTriggerCron | undefined;
    set internalValue(value: PipelineTriggerCron | undefined);
    private _quartzCronSchedule?;
    get quartzCronSchedule(): string;
    set quartzCronSchedule(value: string);
    resetQuartzCronSchedule(): void;
    get quartzCronScheduleInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    resetTimezoneId(): void;
    get timezoneIdInput(): string | undefined;
}
export interface PipelineTriggerManual {
}
export declare function pipelineTriggerManualToTerraform(struct?: PipelineTriggerManualOutputReference | PipelineTriggerManual): any;
export declare function pipelineTriggerManualToHclTerraform(struct?: PipelineTriggerManualOutputReference | PipelineTriggerManual): any;
export declare class PipelineTriggerManualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTriggerManual | undefined;
    set internalValue(value: PipelineTriggerManual | undefined);
}
export interface PipelineTrigger {
    /**
    * cron block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#cron Pipeline#cron}
    */
    readonly cron?: PipelineTriggerCron;
    /**
    * manual block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/pipeline#manual Pipeline#manual}
    */
    readonly manual?: PipelineTriggerManual;
}
export declare function pipelineTriggerToTerraform(struct?: PipelineTriggerOutputReference | PipelineTrigger): any;
export declare function pipelineTriggerToHclTerraform(struct?: PipelineTriggerOutputReference | PipelineTrigger): any;
export declare class PipelineTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTrigger | undefined;
    set internalValue(value: PipelineTrigger | undefined);
    private _cron;
    get cron(): PipelineTriggerCronOutputReference;
    putCron(value: PipelineTriggerCron): void;
    resetCron(): void;
    get cronInput(): PipelineTriggerCron | undefined;
    private _manual;
    get manual(): PipelineTriggerManualOutputReference;
    putManual(value: PipelineTriggerManual): void;
    resetManual(): void;
    get manualInput(): PipelineTriggerManual | undefined;
}
