/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMwsWorkspacesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/mws_workspaces#id DataDatabricksMwsWorkspaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/mws_workspaces#provider_config DataDatabricksMwsWorkspaces#provider_config}
    */
    readonly providerConfig?: DataDatabricksMwsWorkspacesProviderConfig;
}
export interface DataDatabricksMwsWorkspacesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/mws_workspaces#workspace_id DataDatabricksMwsWorkspaces#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMwsWorkspacesProviderConfigToTerraform(struct?: DataDatabricksMwsWorkspacesProviderConfigOutputReference | DataDatabricksMwsWorkspacesProviderConfig): any;
export declare function dataDatabricksMwsWorkspacesProviderConfigToHclTerraform(struct?: DataDatabricksMwsWorkspacesProviderConfigOutputReference | DataDatabricksMwsWorkspacesProviderConfig): any;
export declare class DataDatabricksMwsWorkspacesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMwsWorkspacesProviderConfig | undefined;
    set internalValue(value: DataDatabricksMwsWorkspacesProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/mws_workspaces databricks_mws_workspaces}
*/
export declare class DataDatabricksMwsWorkspaces extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mws_workspaces";
    /**
    * Generates CDKTN code for importing a DataDatabricksMwsWorkspaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMwsWorkspaces to import
    * @param importFromId The id of the existing DataDatabricksMwsWorkspaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/mws_workspaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMwsWorkspaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/mws_workspaces databricks_mws_workspaces} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMwsWorkspacesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksMwsWorkspacesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids;
    get ids(): cdktn.NumberMap;
    private _providerConfig;
    get providerConfig(): DataDatabricksMwsWorkspacesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMwsWorkspacesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksMwsWorkspacesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
