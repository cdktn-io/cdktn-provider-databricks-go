/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_identity_detail_v2#principal_id DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_identity_detail_v2#provider_config DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_identity_detail_v2#workspace_id DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_identity_detail_v2 databricks_workspace_iam_workspace_identity_detail_v2}
*/
export declare class DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_workspace_identity_detail_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_identity_detail_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_identity_detail_v2 databricks_workspace_iam_workspace_identity_detail_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2Config);
    get assignmentType(): string;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | undefined;
    get workspaceIdentityStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
