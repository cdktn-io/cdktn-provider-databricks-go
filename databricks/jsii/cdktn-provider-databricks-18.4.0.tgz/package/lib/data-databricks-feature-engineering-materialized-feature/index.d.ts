/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksFeatureEngineeringMaterializedFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#materialized_feature_id DataDatabricksFeatureEngineeringMaterializedFeature#materialized_feature_id}
    */
    readonly materializedFeatureId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#provider_config DataDatabricksFeatureEngineeringMaterializedFeature#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig;
}
export interface DataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTrigger {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#cron_expression DataDatabricksFeatureEngineeringMaterializedFeature#cron_expression}
    */
    readonly cronExpression?: string;
}
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTriggerToTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTrigger): any;
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTriggerToHclTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTrigger): any;
export declare class DataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTrigger | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTrigger | undefined);
    private _cronExpression?;
    get cronExpression(): string;
    set cronExpression(value: string);
    resetCronExpression(): void;
    get cronExpressionInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#catalog_name DataDatabricksFeatureEngineeringMaterializedFeature#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#schema_name DataDatabricksFeatureEngineeringMaterializedFeature#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#table_name_prefix DataDatabricksFeatureEngineeringMaterializedFeature#table_name_prefix}
    */
    readonly tableNamePrefix: string;
}
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfigToTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfig): any;
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfig): any;
export declare class DataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfig | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfig | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    get tableNamePrefixInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#catalog_name DataDatabricksFeatureEngineeringMaterializedFeature#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#online_store_name DataDatabricksFeatureEngineeringMaterializedFeature#online_store_name}
    */
    readonly onlineStoreName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#schema_name DataDatabricksFeatureEngineeringMaterializedFeature#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#table_name_prefix DataDatabricksFeatureEngineeringMaterializedFeature#table_name_prefix}
    */
    readonly tableNamePrefix: string;
}
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfigToTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfig): any;
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfig): any;
export declare class DataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfig | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfig | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _onlineStoreName?;
    get onlineStoreName(): string;
    set onlineStoreName(value: string);
    get onlineStoreNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    get tableNamePrefixInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#workspace_id DataDatabricksFeatureEngineeringMaterializedFeature#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringMaterializedFeatureStreamingMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#freshness_target DataDatabricksFeatureEngineeringMaterializedFeature#freshness_target}
    */
    readonly freshnessTarget?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#mode DataDatabricksFeatureEngineeringMaterializedFeature#mode}
    */
    readonly mode?: string;
}
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureStreamingModeToTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureStreamingMode): any;
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureStreamingModeToHclTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureStreamingMode): any;
export declare class DataDatabricksFeatureEngineeringMaterializedFeatureStreamingModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringMaterializedFeatureStreamingMode | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringMaterializedFeatureStreamingMode | undefined);
    private _freshnessTarget?;
    get freshnessTarget(): string;
    set freshnessTarget(value: string);
    resetFreshnessTarget(): void;
    get freshnessTargetInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringMaterializedFeatureTableTrigger {
}
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureTableTriggerToTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureTableTrigger): any;
export declare function dataDatabricksFeatureEngineeringMaterializedFeatureTableTriggerToHclTerraform(struct?: DataDatabricksFeatureEngineeringMaterializedFeatureTableTrigger): any;
export declare class DataDatabricksFeatureEngineeringMaterializedFeatureTableTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringMaterializedFeatureTableTrigger | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringMaterializedFeatureTableTrigger | undefined);
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature databricks_feature_engineering_materialized_feature}
*/
export declare class DataDatabricksFeatureEngineeringMaterializedFeature extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_feature_engineering_materialized_feature";
    /**
    * Generates CDKTN code for importing a DataDatabricksFeatureEngineeringMaterializedFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksFeatureEngineeringMaterializedFeature to import
    * @param importFromId The id of the existing DataDatabricksFeatureEngineeringMaterializedFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksFeatureEngineeringMaterializedFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/feature_engineering_materialized_feature databricks_feature_engineering_materialized_feature} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksFeatureEngineeringMaterializedFeatureConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksFeatureEngineeringMaterializedFeatureConfig);
    get cronSchedule(): string;
    private _cronScheduleTrigger;
    get cronScheduleTrigger(): DataDatabricksFeatureEngineeringMaterializedFeatureCronScheduleTriggerOutputReference;
    get featureName(): string;
    get isOnline(): cdktn.IResolvable;
    get lastMaterializationTime(): string;
    private _materializedFeatureId?;
    get materializedFeatureId(): string;
    set materializedFeatureId(value: string);
    get materializedFeatureIdInput(): string | undefined;
    private _offlineStoreConfig;
    get offlineStoreConfig(): DataDatabricksFeatureEngineeringMaterializedFeatureOfflineStoreConfigOutputReference;
    private _onlineStoreConfig;
    get onlineStoreConfig(): DataDatabricksFeatureEngineeringMaterializedFeatureOnlineStoreConfigOutputReference;
    get pipelineScheduleState(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringMaterializedFeatureProviderConfig | undefined;
    private _streamingMode;
    get streamingMode(): DataDatabricksFeatureEngineeringMaterializedFeatureStreamingModeOutputReference;
    get tableName(): string;
    private _tableTrigger;
    get tableTrigger(): DataDatabricksFeatureEngineeringMaterializedFeatureTableTriggerOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
