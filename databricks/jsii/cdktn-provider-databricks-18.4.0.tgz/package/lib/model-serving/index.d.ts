/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ModelServingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#budget_policy_id ModelServing#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#description ModelServing#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#id ModelServing#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#name ModelServing#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#route_optimized ModelServing#route_optimized}
    */
    readonly routeOptimized?: boolean | cdktn.IResolvable;
    /**
    * ai_gateway block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#ai_gateway ModelServing#ai_gateway}
    */
    readonly aiGateway?: ModelServingAiGateway;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#config ModelServing#config}
    */
    readonly config?: ModelServingConfigA;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#email_notifications ModelServing#email_notifications}
    */
    readonly emailNotifications?: ModelServingEmailNotifications;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#provider_config ModelServing#provider_config}
    */
    readonly providerConfig?: ModelServingProviderConfig;
    /**
    * rate_limits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#rate_limits ModelServing#rate_limits}
    */
    readonly rateLimits?: ModelServingRateLimits[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#tags ModelServing#tags}
    */
    readonly tags?: ModelServingTags[] | cdktn.IResolvable;
    /**
    * telemetry_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#telemetry_config ModelServing#telemetry_config}
    */
    readonly telemetryConfig?: ModelServingTelemetryConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#timeouts ModelServing#timeouts}
    */
    readonly timeouts?: ModelServingTimeouts;
}
export interface ModelServingAiGatewayFallbackConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#enabled ModelServing#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function modelServingAiGatewayFallbackConfigToTerraform(struct?: ModelServingAiGatewayFallbackConfigOutputReference | ModelServingAiGatewayFallbackConfig): any;
export declare function modelServingAiGatewayFallbackConfigToHclTerraform(struct?: ModelServingAiGatewayFallbackConfigOutputReference | ModelServingAiGatewayFallbackConfig): any;
export declare class ModelServingAiGatewayFallbackConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayFallbackConfig | undefined;
    set internalValue(value: ModelServingAiGatewayFallbackConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ModelServingAiGatewayGuardrailsInputPii {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#behavior ModelServing#behavior}
    */
    readonly behavior?: string;
}
export declare function modelServingAiGatewayGuardrailsInputPiiToTerraform(struct?: ModelServingAiGatewayGuardrailsInputPiiOutputReference | ModelServingAiGatewayGuardrailsInputPii): any;
export declare function modelServingAiGatewayGuardrailsInputPiiToHclTerraform(struct?: ModelServingAiGatewayGuardrailsInputPiiOutputReference | ModelServingAiGatewayGuardrailsInputPii): any;
export declare class ModelServingAiGatewayGuardrailsInputPiiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayGuardrailsInputPii | undefined;
    set internalValue(value: ModelServingAiGatewayGuardrailsInputPii | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
}
export interface ModelServingAiGatewayGuardrailsInput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#invalid_keywords ModelServing#invalid_keywords}
    */
    readonly invalidKeywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#safety ModelServing#safety}
    */
    readonly safety?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#valid_topics ModelServing#valid_topics}
    */
    readonly validTopics?: string[];
    /**
    * pii block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#pii ModelServing#pii}
    */
    readonly pii?: ModelServingAiGatewayGuardrailsInputPii;
}
export declare function modelServingAiGatewayGuardrailsInputToTerraform(struct?: ModelServingAiGatewayGuardrailsInputOutputReference | ModelServingAiGatewayGuardrailsInput): any;
export declare function modelServingAiGatewayGuardrailsInputToHclTerraform(struct?: ModelServingAiGatewayGuardrailsInputOutputReference | ModelServingAiGatewayGuardrailsInput): any;
export declare class ModelServingAiGatewayGuardrailsInputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayGuardrailsInput | undefined;
    set internalValue(value: ModelServingAiGatewayGuardrailsInput | undefined);
    private _invalidKeywords?;
    get invalidKeywords(): string[];
    set invalidKeywords(value: string[]);
    resetInvalidKeywords(): void;
    get invalidKeywordsInput(): string[] | undefined;
    private _safety?;
    get safety(): boolean | cdktn.IResolvable;
    set safety(value: boolean | cdktn.IResolvable);
    resetSafety(): void;
    get safetyInput(): boolean | cdktn.IResolvable | undefined;
    private _validTopics?;
    get validTopics(): string[];
    set validTopics(value: string[]);
    resetValidTopics(): void;
    get validTopicsInput(): string[] | undefined;
    private _pii;
    get pii(): ModelServingAiGatewayGuardrailsInputPiiOutputReference;
    putPii(value: ModelServingAiGatewayGuardrailsInputPii): void;
    resetPii(): void;
    get piiInput(): ModelServingAiGatewayGuardrailsInputPii | undefined;
}
export interface ModelServingAiGatewayGuardrailsOutputPii {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#behavior ModelServing#behavior}
    */
    readonly behavior?: string;
}
export declare function modelServingAiGatewayGuardrailsOutputPiiToTerraform(struct?: ModelServingAiGatewayGuardrailsOutputPiiOutputReference | ModelServingAiGatewayGuardrailsOutputPii): any;
export declare function modelServingAiGatewayGuardrailsOutputPiiToHclTerraform(struct?: ModelServingAiGatewayGuardrailsOutputPiiOutputReference | ModelServingAiGatewayGuardrailsOutputPii): any;
export declare class ModelServingAiGatewayGuardrailsOutputPiiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayGuardrailsOutputPii | undefined;
    set internalValue(value: ModelServingAiGatewayGuardrailsOutputPii | undefined);
    private _behavior?;
    get behavior(): string;
    set behavior(value: string);
    resetBehavior(): void;
    get behaviorInput(): string | undefined;
}
export interface ModelServingAiGatewayGuardrailsOutput {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#invalid_keywords ModelServing#invalid_keywords}
    */
    readonly invalidKeywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#safety ModelServing#safety}
    */
    readonly safety?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#valid_topics ModelServing#valid_topics}
    */
    readonly validTopics?: string[];
    /**
    * pii block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#pii ModelServing#pii}
    */
    readonly pii?: ModelServingAiGatewayGuardrailsOutputPii;
}
export declare function modelServingAiGatewayGuardrailsOutputToTerraform(struct?: ModelServingAiGatewayGuardrailsOutputOutputReference | ModelServingAiGatewayGuardrailsOutput): any;
export declare function modelServingAiGatewayGuardrailsOutputToHclTerraform(struct?: ModelServingAiGatewayGuardrailsOutputOutputReference | ModelServingAiGatewayGuardrailsOutput): any;
export declare class ModelServingAiGatewayGuardrailsOutputOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayGuardrailsOutput | undefined;
    set internalValue(value: ModelServingAiGatewayGuardrailsOutput | undefined);
    private _invalidKeywords?;
    get invalidKeywords(): string[];
    set invalidKeywords(value: string[]);
    resetInvalidKeywords(): void;
    get invalidKeywordsInput(): string[] | undefined;
    private _safety?;
    get safety(): boolean | cdktn.IResolvable;
    set safety(value: boolean | cdktn.IResolvable);
    resetSafety(): void;
    get safetyInput(): boolean | cdktn.IResolvable | undefined;
    private _validTopics?;
    get validTopics(): string[];
    set validTopics(value: string[]);
    resetValidTopics(): void;
    get validTopicsInput(): string[] | undefined;
    private _pii;
    get pii(): ModelServingAiGatewayGuardrailsOutputPiiOutputReference;
    putPii(value: ModelServingAiGatewayGuardrailsOutputPii): void;
    resetPii(): void;
    get piiInput(): ModelServingAiGatewayGuardrailsOutputPii | undefined;
}
export interface ModelServingAiGatewayGuardrails {
    /**
    * input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#input ModelServing#input}
    */
    readonly input?: ModelServingAiGatewayGuardrailsInput;
    /**
    * output block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#output ModelServing#output}
    */
    readonly output?: ModelServingAiGatewayGuardrailsOutput;
}
export declare function modelServingAiGatewayGuardrailsToTerraform(struct?: ModelServingAiGatewayGuardrailsOutputReference | ModelServingAiGatewayGuardrails): any;
export declare function modelServingAiGatewayGuardrailsToHclTerraform(struct?: ModelServingAiGatewayGuardrailsOutputReference | ModelServingAiGatewayGuardrails): any;
export declare class ModelServingAiGatewayGuardrailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayGuardrails | undefined;
    set internalValue(value: ModelServingAiGatewayGuardrails | undefined);
    private _input;
    get input(): ModelServingAiGatewayGuardrailsInputOutputReference;
    putInput(value: ModelServingAiGatewayGuardrailsInput): void;
    resetInput(): void;
    get inputInput(): ModelServingAiGatewayGuardrailsInput | undefined;
    private _output;
    get output(): ModelServingAiGatewayGuardrailsOutputOutputReference;
    putOutput(value: ModelServingAiGatewayGuardrailsOutput): void;
    resetOutput(): void;
    get outputInput(): ModelServingAiGatewayGuardrailsOutput | undefined;
}
export interface ModelServingAiGatewayInferenceTableConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#catalog_name ModelServing#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#enabled ModelServing#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#schema_name ModelServing#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#table_name_prefix ModelServing#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function modelServingAiGatewayInferenceTableConfigToTerraform(struct?: ModelServingAiGatewayInferenceTableConfigOutputReference | ModelServingAiGatewayInferenceTableConfig): any;
export declare function modelServingAiGatewayInferenceTableConfigToHclTerraform(struct?: ModelServingAiGatewayInferenceTableConfigOutputReference | ModelServingAiGatewayInferenceTableConfig): any;
export declare class ModelServingAiGatewayInferenceTableConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayInferenceTableConfig | undefined;
    set internalValue(value: ModelServingAiGatewayInferenceTableConfig | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface ModelServingAiGatewayRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#calls ModelServing#calls}
    */
    readonly calls?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#key ModelServing#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#principal ModelServing#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#renewal_period ModelServing#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#tokens ModelServing#tokens}
    */
    readonly tokens?: number;
}
export declare function modelServingAiGatewayRateLimitsToTerraform(struct?: ModelServingAiGatewayRateLimits | cdktn.IResolvable): any;
export declare function modelServingAiGatewayRateLimitsToHclTerraform(struct?: ModelServingAiGatewayRateLimits | cdktn.IResolvable): any;
export declare class ModelServingAiGatewayRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingAiGatewayRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingAiGatewayRateLimits | cdktn.IResolvable | undefined);
    private _calls?;
    get calls(): number;
    set calls(value: number);
    resetCalls(): void;
    get callsInput(): number | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class ModelServingAiGatewayRateLimitsList extends cdktn.ComplexList {
    internalValue?: ModelServingAiGatewayRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingAiGatewayRateLimitsOutputReference;
}
export interface ModelServingAiGatewayUsageTrackingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#enabled ModelServing#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
}
export declare function modelServingAiGatewayUsageTrackingConfigToTerraform(struct?: ModelServingAiGatewayUsageTrackingConfigOutputReference | ModelServingAiGatewayUsageTrackingConfig): any;
export declare function modelServingAiGatewayUsageTrackingConfigToHclTerraform(struct?: ModelServingAiGatewayUsageTrackingConfigOutputReference | ModelServingAiGatewayUsageTrackingConfig): any;
export declare class ModelServingAiGatewayUsageTrackingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGatewayUsageTrackingConfig | undefined;
    set internalValue(value: ModelServingAiGatewayUsageTrackingConfig | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ModelServingAiGateway {
    /**
    * fallback_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#fallback_config ModelServing#fallback_config}
    */
    readonly fallbackConfig?: ModelServingAiGatewayFallbackConfig;
    /**
    * guardrails block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#guardrails ModelServing#guardrails}
    */
    readonly guardrails?: ModelServingAiGatewayGuardrails;
    /**
    * inference_table_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#inference_table_config ModelServing#inference_table_config}
    */
    readonly inferenceTableConfig?: ModelServingAiGatewayInferenceTableConfig;
    /**
    * rate_limits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#rate_limits ModelServing#rate_limits}
    */
    readonly rateLimits?: ModelServingAiGatewayRateLimits[] | cdktn.IResolvable;
    /**
    * usage_tracking_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#usage_tracking_config ModelServing#usage_tracking_config}
    */
    readonly usageTrackingConfig?: ModelServingAiGatewayUsageTrackingConfig;
}
export declare function modelServingAiGatewayToTerraform(struct?: ModelServingAiGatewayOutputReference | ModelServingAiGateway): any;
export declare function modelServingAiGatewayToHclTerraform(struct?: ModelServingAiGatewayOutputReference | ModelServingAiGateway): any;
export declare class ModelServingAiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingAiGateway | undefined;
    set internalValue(value: ModelServingAiGateway | undefined);
    private _fallbackConfig;
    get fallbackConfig(): ModelServingAiGatewayFallbackConfigOutputReference;
    putFallbackConfig(value: ModelServingAiGatewayFallbackConfig): void;
    resetFallbackConfig(): void;
    get fallbackConfigInput(): ModelServingAiGatewayFallbackConfig | undefined;
    private _guardrails;
    get guardrails(): ModelServingAiGatewayGuardrailsOutputReference;
    putGuardrails(value: ModelServingAiGatewayGuardrails): void;
    resetGuardrails(): void;
    get guardrailsInput(): ModelServingAiGatewayGuardrails | undefined;
    private _inferenceTableConfig;
    get inferenceTableConfig(): ModelServingAiGatewayInferenceTableConfigOutputReference;
    putInferenceTableConfig(value: ModelServingAiGatewayInferenceTableConfig): void;
    resetInferenceTableConfig(): void;
    get inferenceTableConfigInput(): ModelServingAiGatewayInferenceTableConfig | undefined;
    private _rateLimits;
    get rateLimits(): ModelServingAiGatewayRateLimitsList;
    putRateLimits(value: ModelServingAiGatewayRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | ModelServingAiGatewayRateLimits[] | undefined;
    private _usageTrackingConfig;
    get usageTrackingConfig(): ModelServingAiGatewayUsageTrackingConfigOutputReference;
    putUsageTrackingConfig(value: ModelServingAiGatewayUsageTrackingConfig): void;
    resetUsageTrackingConfig(): void;
    get usageTrackingConfigInput(): ModelServingAiGatewayUsageTrackingConfig | undefined;
}
export interface ModelServingConfigAutoCaptureConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#catalog_name ModelServing#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#enabled ModelServing#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#schema_name ModelServing#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#table_name_prefix ModelServing#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function modelServingConfigAutoCaptureConfigToTerraform(struct?: ModelServingConfigAutoCaptureConfigOutputReference | ModelServingConfigAutoCaptureConfig): any;
export declare function modelServingConfigAutoCaptureConfigToHclTerraform(struct?: ModelServingConfigAutoCaptureConfigOutputReference | ModelServingConfigAutoCaptureConfig): any;
export declare class ModelServingConfigAutoCaptureConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigAutoCaptureConfig | undefined;
    set internalValue(value: ModelServingConfigAutoCaptureConfig | undefined);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelAi21LabsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#ai21labs_api_key ModelServing#ai21labs_api_key}
    */
    readonly ai21LabsApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#ai21labs_api_key_plaintext ModelServing#ai21labs_api_key_plaintext}
    */
    readonly ai21LabsApiKeyPlaintext?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelAi21LabsConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelAi21LabsConfigOutputReference | ModelServingConfigServedEntitiesExternalModelAi21LabsConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelAi21LabsConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelAi21LabsConfigOutputReference | ModelServingConfigServedEntitiesExternalModelAi21LabsConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelAi21LabsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelAi21LabsConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelAi21LabsConfig | undefined);
    private _ai21LabsApiKey?;
    get ai21LabsApiKey(): string;
    set ai21LabsApiKey(value: string);
    resetAi21LabsApiKey(): void;
    get ai21LabsApiKeyInput(): string | undefined;
    private _ai21LabsApiKeyPlaintext?;
    get ai21LabsApiKeyPlaintext(): string;
    set ai21LabsApiKeyPlaintext(value: string);
    resetAi21LabsApiKeyPlaintext(): void;
    get ai21LabsApiKeyPlaintextInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#aws_access_key_id ModelServing#aws_access_key_id}
    */
    readonly awsAccessKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#aws_access_key_id_plaintext ModelServing#aws_access_key_id_plaintext}
    */
    readonly awsAccessKeyIdPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#aws_region ModelServing#aws_region}
    */
    readonly awsRegion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#aws_secret_access_key ModelServing#aws_secret_access_key}
    */
    readonly awsSecretAccessKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#aws_secret_access_key_plaintext ModelServing#aws_secret_access_key_plaintext}
    */
    readonly awsSecretAccessKeyPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#bedrock_provider ModelServing#bedrock_provider}
    */
    readonly bedrockProvider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#instance_profile_arn ModelServing#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelAmazonBedrockConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfigOutputReference | ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelAmazonBedrockConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfigOutputReference | ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig | undefined);
    private _awsAccessKeyId?;
    get awsAccessKeyId(): string;
    set awsAccessKeyId(value: string);
    resetAwsAccessKeyId(): void;
    get awsAccessKeyIdInput(): string | undefined;
    private _awsAccessKeyIdPlaintext?;
    get awsAccessKeyIdPlaintext(): string;
    set awsAccessKeyIdPlaintext(value: string);
    resetAwsAccessKeyIdPlaintext(): void;
    get awsAccessKeyIdPlaintextInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    get awsRegionInput(): string | undefined;
    private _awsSecretAccessKey?;
    get awsSecretAccessKey(): string;
    set awsSecretAccessKey(value: string);
    resetAwsSecretAccessKey(): void;
    get awsSecretAccessKeyInput(): string | undefined;
    private _awsSecretAccessKeyPlaintext?;
    get awsSecretAccessKeyPlaintext(): string;
    set awsSecretAccessKeyPlaintext(value: string);
    resetAwsSecretAccessKeyPlaintext(): void;
    get awsSecretAccessKeyPlaintextInput(): string | undefined;
    private _bedrockProvider?;
    get bedrockProvider(): string;
    set bedrockProvider(value: string);
    get bedrockProviderInput(): string | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelAnthropicConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#anthropic_api_key ModelServing#anthropic_api_key}
    */
    readonly anthropicApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#anthropic_api_key_plaintext ModelServing#anthropic_api_key_plaintext}
    */
    readonly anthropicApiKeyPlaintext?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelAnthropicConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelAnthropicConfigOutputReference | ModelServingConfigServedEntitiesExternalModelAnthropicConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelAnthropicConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelAnthropicConfigOutputReference | ModelServingConfigServedEntitiesExternalModelAnthropicConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelAnthropicConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelAnthropicConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelAnthropicConfig | undefined);
    private _anthropicApiKey?;
    get anthropicApiKey(): string;
    set anthropicApiKey(value: string);
    resetAnthropicApiKey(): void;
    get anthropicApiKeyInput(): string | undefined;
    private _anthropicApiKeyPlaintext?;
    get anthropicApiKeyPlaintext(): string;
    set anthropicApiKeyPlaintext(value: string);
    resetAnthropicApiKeyPlaintext(): void;
    get anthropicApiKeyPlaintextInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelCohereConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#cohere_api_base ModelServing#cohere_api_base}
    */
    readonly cohereApiBase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#cohere_api_key ModelServing#cohere_api_key}
    */
    readonly cohereApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#cohere_api_key_plaintext ModelServing#cohere_api_key_plaintext}
    */
    readonly cohereApiKeyPlaintext?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelCohereConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCohereConfigOutputReference | ModelServingConfigServedEntitiesExternalModelCohereConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelCohereConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCohereConfigOutputReference | ModelServingConfigServedEntitiesExternalModelCohereConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelCohereConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelCohereConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelCohereConfig | undefined);
    private _cohereApiBase?;
    get cohereApiBase(): string;
    set cohereApiBase(value: string);
    resetCohereApiBase(): void;
    get cohereApiBaseInput(): string | undefined;
    private _cohereApiKey?;
    get cohereApiKey(): string;
    set cohereApiKey(value: string);
    resetCohereApiKey(): void;
    get cohereApiKeyInput(): string | undefined;
    private _cohereApiKeyPlaintext?;
    get cohereApiKeyPlaintext(): string;
    set cohereApiKeyPlaintext(value: string);
    resetCohereApiKeyPlaintext(): void;
    get cohereApiKeyPlaintextInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#key ModelServing#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#value ModelServing#value}
    */
    readonly value?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#value_plaintext ModelServing#value_plaintext}
    */
    readonly valuePlaintext?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthOutputReference | ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth): any;
export declare function modelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthOutputReference | ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth): any;
export declare class ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _valuePlaintext?;
    get valuePlaintext(): string;
    set valuePlaintext(value: string);
    resetValuePlaintext(): void;
    get valuePlaintextInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#token ModelServing#token}
    */
    readonly token?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#token_plaintext ModelServing#token_plaintext}
    */
    readonly tokenPlaintext?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthOutputReference | ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth): any;
export declare function modelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthOutputReference | ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth): any;
export declare class ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth | undefined);
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _tokenPlaintext?;
    get tokenPlaintext(): string;
    set tokenPlaintext(value: string);
    resetTokenPlaintext(): void;
    get tokenPlaintextInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelCustomProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#custom_provider_url ModelServing#custom_provider_url}
    */
    readonly customProviderUrl: string;
    /**
    * api_key_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#api_key_auth ModelServing#api_key_auth}
    */
    readonly apiKeyAuth?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth;
    /**
    * bearer_token_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#bearer_token_auth ModelServing#bearer_token_auth}
    */
    readonly bearerTokenAuth?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth;
}
export declare function modelServingConfigServedEntitiesExternalModelCustomProviderConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigOutputReference | ModelServingConfigServedEntitiesExternalModelCustomProviderConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelCustomProviderConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigOutputReference | ModelServingConfigServedEntitiesExternalModelCustomProviderConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelCustomProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelCustomProviderConfig | undefined);
    private _customProviderUrl?;
    get customProviderUrl(): string;
    set customProviderUrl(value: string);
    get customProviderUrlInput(): string | undefined;
    private _apiKeyAuth;
    get apiKeyAuth(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuthOutputReference;
    putApiKeyAuth(value: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth): void;
    resetApiKeyAuth(): void;
    get apiKeyAuthInput(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfigApiKeyAuth | undefined;
    private _bearerTokenAuth;
    get bearerTokenAuth(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuthOutputReference;
    putBearerTokenAuth(value: ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth): void;
    resetBearerTokenAuth(): void;
    get bearerTokenAuthInput(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfigBearerTokenAuth | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#databricks_api_token ModelServing#databricks_api_token}
    */
    readonly databricksApiToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#databricks_api_token_plaintext ModelServing#databricks_api_token_plaintext}
    */
    readonly databricksApiTokenPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#databricks_workspace_url ModelServing#databricks_workspace_url}
    */
    readonly databricksWorkspaceUrl: string;
}
export declare function modelServingConfigServedEntitiesExternalModelDatabricksModelServingConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfigOutputReference | ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelDatabricksModelServingConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfigOutputReference | ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig | undefined);
    private _databricksApiToken?;
    get databricksApiToken(): string;
    set databricksApiToken(value: string);
    resetDatabricksApiToken(): void;
    get databricksApiTokenInput(): string | undefined;
    private _databricksApiTokenPlaintext?;
    get databricksApiTokenPlaintext(): string;
    set databricksApiTokenPlaintext(value: string);
    resetDatabricksApiTokenPlaintext(): void;
    get databricksApiTokenPlaintextInput(): string | undefined;
    private _databricksWorkspaceUrl?;
    get databricksWorkspaceUrl(): string;
    set databricksWorkspaceUrl(value: string);
    get databricksWorkspaceUrlInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#private_key ModelServing#private_key}
    */
    readonly privateKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#private_key_plaintext ModelServing#private_key_plaintext}
    */
    readonly privateKeyPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#project_id ModelServing#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#region ModelServing#region}
    */
    readonly region: string;
}
export declare function modelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigOutputReference | ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigOutputReference | ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig | undefined);
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _privateKeyPlaintext?;
    get privateKeyPlaintext(): string;
    set privateKeyPlaintext(value: string);
    resetPrivateKeyPlaintext(): void;
    get privateKeyPlaintextInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelOpenaiConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#microsoft_entra_client_id ModelServing#microsoft_entra_client_id}
    */
    readonly microsoftEntraClientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#microsoft_entra_client_secret ModelServing#microsoft_entra_client_secret}
    */
    readonly microsoftEntraClientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#microsoft_entra_client_secret_plaintext ModelServing#microsoft_entra_client_secret_plaintext}
    */
    readonly microsoftEntraClientSecretPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#microsoft_entra_tenant_id ModelServing#microsoft_entra_tenant_id}
    */
    readonly microsoftEntraTenantId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_api_base ModelServing#openai_api_base}
    */
    readonly openaiApiBase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_api_key ModelServing#openai_api_key}
    */
    readonly openaiApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_api_key_plaintext ModelServing#openai_api_key_plaintext}
    */
    readonly openaiApiKeyPlaintext?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_api_type ModelServing#openai_api_type}
    */
    readonly openaiApiType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_api_version ModelServing#openai_api_version}
    */
    readonly openaiApiVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_deployment_name ModelServing#openai_deployment_name}
    */
    readonly openaiDeploymentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_organization ModelServing#openai_organization}
    */
    readonly openaiOrganization?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelOpenaiConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelOpenaiConfigOutputReference | ModelServingConfigServedEntitiesExternalModelOpenaiConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelOpenaiConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelOpenaiConfigOutputReference | ModelServingConfigServedEntitiesExternalModelOpenaiConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelOpenaiConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelOpenaiConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelOpenaiConfig | undefined);
    private _microsoftEntraClientId?;
    get microsoftEntraClientId(): string;
    set microsoftEntraClientId(value: string);
    resetMicrosoftEntraClientId(): void;
    get microsoftEntraClientIdInput(): string | undefined;
    private _microsoftEntraClientSecret?;
    get microsoftEntraClientSecret(): string;
    set microsoftEntraClientSecret(value: string);
    resetMicrosoftEntraClientSecret(): void;
    get microsoftEntraClientSecretInput(): string | undefined;
    private _microsoftEntraClientSecretPlaintext?;
    get microsoftEntraClientSecretPlaintext(): string;
    set microsoftEntraClientSecretPlaintext(value: string);
    resetMicrosoftEntraClientSecretPlaintext(): void;
    get microsoftEntraClientSecretPlaintextInput(): string | undefined;
    private _microsoftEntraTenantId?;
    get microsoftEntraTenantId(): string;
    set microsoftEntraTenantId(value: string);
    resetMicrosoftEntraTenantId(): void;
    get microsoftEntraTenantIdInput(): string | undefined;
    private _openaiApiBase?;
    get openaiApiBase(): string;
    set openaiApiBase(value: string);
    resetOpenaiApiBase(): void;
    get openaiApiBaseInput(): string | undefined;
    private _openaiApiKey?;
    get openaiApiKey(): string;
    set openaiApiKey(value: string);
    resetOpenaiApiKey(): void;
    get openaiApiKeyInput(): string | undefined;
    private _openaiApiKeyPlaintext?;
    get openaiApiKeyPlaintext(): string;
    set openaiApiKeyPlaintext(value: string);
    resetOpenaiApiKeyPlaintext(): void;
    get openaiApiKeyPlaintextInput(): string | undefined;
    private _openaiApiType?;
    get openaiApiType(): string;
    set openaiApiType(value: string);
    resetOpenaiApiType(): void;
    get openaiApiTypeInput(): string | undefined;
    private _openaiApiVersion?;
    get openaiApiVersion(): string;
    set openaiApiVersion(value: string);
    resetOpenaiApiVersion(): void;
    get openaiApiVersionInput(): string | undefined;
    private _openaiDeploymentName?;
    get openaiDeploymentName(): string;
    set openaiDeploymentName(value: string);
    resetOpenaiDeploymentName(): void;
    get openaiDeploymentNameInput(): string | undefined;
    private _openaiOrganization?;
    get openaiOrganization(): string;
    set openaiOrganization(value: string);
    resetOpenaiOrganization(): void;
    get openaiOrganizationInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModelPalmConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#palm_api_key ModelServing#palm_api_key}
    */
    readonly palmApiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#palm_api_key_plaintext ModelServing#palm_api_key_plaintext}
    */
    readonly palmApiKeyPlaintext?: string;
}
export declare function modelServingConfigServedEntitiesExternalModelPalmConfigToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelPalmConfigOutputReference | ModelServingConfigServedEntitiesExternalModelPalmConfig): any;
export declare function modelServingConfigServedEntitiesExternalModelPalmConfigToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelPalmConfigOutputReference | ModelServingConfigServedEntitiesExternalModelPalmConfig): any;
export declare class ModelServingConfigServedEntitiesExternalModelPalmConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModelPalmConfig | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModelPalmConfig | undefined);
    private _palmApiKey?;
    get palmApiKey(): string;
    set palmApiKey(value: string);
    resetPalmApiKey(): void;
    get palmApiKeyInput(): string | undefined;
    private _palmApiKeyPlaintext?;
    get palmApiKeyPlaintext(): string;
    set palmApiKeyPlaintext(value: string);
    resetPalmApiKeyPlaintext(): void;
    get palmApiKeyPlaintextInput(): string | undefined;
}
export interface ModelServingConfigServedEntitiesExternalModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#name ModelServing#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#provider ModelServing#provider}
    */
    readonly provider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#task ModelServing#task}
    */
    readonly task: string;
    /**
    * ai21labs_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#ai21labs_config ModelServing#ai21labs_config}
    */
    readonly ai21LabsConfig?: ModelServingConfigServedEntitiesExternalModelAi21LabsConfig;
    /**
    * amazon_bedrock_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#amazon_bedrock_config ModelServing#amazon_bedrock_config}
    */
    readonly amazonBedrockConfig?: ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig;
    /**
    * anthropic_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#anthropic_config ModelServing#anthropic_config}
    */
    readonly anthropicConfig?: ModelServingConfigServedEntitiesExternalModelAnthropicConfig;
    /**
    * cohere_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#cohere_config ModelServing#cohere_config}
    */
    readonly cohereConfig?: ModelServingConfigServedEntitiesExternalModelCohereConfig;
    /**
    * custom_provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#custom_provider_config ModelServing#custom_provider_config}
    */
    readonly customProviderConfig?: ModelServingConfigServedEntitiesExternalModelCustomProviderConfig;
    /**
    * databricks_model_serving_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#databricks_model_serving_config ModelServing#databricks_model_serving_config}
    */
    readonly databricksModelServingConfig?: ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig;
    /**
    * google_cloud_vertex_ai_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#google_cloud_vertex_ai_config ModelServing#google_cloud_vertex_ai_config}
    */
    readonly googleCloudVertexAiConfig?: ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig;
    /**
    * openai_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#openai_config ModelServing#openai_config}
    */
    readonly openaiConfig?: ModelServingConfigServedEntitiesExternalModelOpenaiConfig;
    /**
    * palm_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#palm_config ModelServing#palm_config}
    */
    readonly palmConfig?: ModelServingConfigServedEntitiesExternalModelPalmConfig;
}
export declare function modelServingConfigServedEntitiesExternalModelToTerraform(struct?: ModelServingConfigServedEntitiesExternalModelOutputReference | ModelServingConfigServedEntitiesExternalModel): any;
export declare function modelServingConfigServedEntitiesExternalModelToHclTerraform(struct?: ModelServingConfigServedEntitiesExternalModelOutputReference | ModelServingConfigServedEntitiesExternalModel): any;
export declare class ModelServingConfigServedEntitiesExternalModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigServedEntitiesExternalModel | undefined;
    set internalValue(value: ModelServingConfigServedEntitiesExternalModel | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    get providerInput(): string | undefined;
    private _task?;
    get task(): string;
    set task(value: string);
    get taskInput(): string | undefined;
    private _ai21LabsConfig;
    get ai21LabsConfig(): ModelServingConfigServedEntitiesExternalModelAi21LabsConfigOutputReference;
    putAi21LabsConfig(value: ModelServingConfigServedEntitiesExternalModelAi21LabsConfig): void;
    resetAi21LabsConfig(): void;
    get ai21LabsConfigInput(): ModelServingConfigServedEntitiesExternalModelAi21LabsConfig | undefined;
    private _amazonBedrockConfig;
    get amazonBedrockConfig(): ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfigOutputReference;
    putAmazonBedrockConfig(value: ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig): void;
    resetAmazonBedrockConfig(): void;
    get amazonBedrockConfigInput(): ModelServingConfigServedEntitiesExternalModelAmazonBedrockConfig | undefined;
    private _anthropicConfig;
    get anthropicConfig(): ModelServingConfigServedEntitiesExternalModelAnthropicConfigOutputReference;
    putAnthropicConfig(value: ModelServingConfigServedEntitiesExternalModelAnthropicConfig): void;
    resetAnthropicConfig(): void;
    get anthropicConfigInput(): ModelServingConfigServedEntitiesExternalModelAnthropicConfig | undefined;
    private _cohereConfig;
    get cohereConfig(): ModelServingConfigServedEntitiesExternalModelCohereConfigOutputReference;
    putCohereConfig(value: ModelServingConfigServedEntitiesExternalModelCohereConfig): void;
    resetCohereConfig(): void;
    get cohereConfigInput(): ModelServingConfigServedEntitiesExternalModelCohereConfig | undefined;
    private _customProviderConfig;
    get customProviderConfig(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfigOutputReference;
    putCustomProviderConfig(value: ModelServingConfigServedEntitiesExternalModelCustomProviderConfig): void;
    resetCustomProviderConfig(): void;
    get customProviderConfigInput(): ModelServingConfigServedEntitiesExternalModelCustomProviderConfig | undefined;
    private _databricksModelServingConfig;
    get databricksModelServingConfig(): ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfigOutputReference;
    putDatabricksModelServingConfig(value: ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig): void;
    resetDatabricksModelServingConfig(): void;
    get databricksModelServingConfigInput(): ModelServingConfigServedEntitiesExternalModelDatabricksModelServingConfig | undefined;
    private _googleCloudVertexAiConfig;
    get googleCloudVertexAiConfig(): ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfigOutputReference;
    putGoogleCloudVertexAiConfig(value: ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig): void;
    resetGoogleCloudVertexAiConfig(): void;
    get googleCloudVertexAiConfigInput(): ModelServingConfigServedEntitiesExternalModelGoogleCloudVertexAiConfig | undefined;
    private _openaiConfig;
    get openaiConfig(): ModelServingConfigServedEntitiesExternalModelOpenaiConfigOutputReference;
    putOpenaiConfig(value: ModelServingConfigServedEntitiesExternalModelOpenaiConfig): void;
    resetOpenaiConfig(): void;
    get openaiConfigInput(): ModelServingConfigServedEntitiesExternalModelOpenaiConfig | undefined;
    private _palmConfig;
    get palmConfig(): ModelServingConfigServedEntitiesExternalModelPalmConfigOutputReference;
    putPalmConfig(value: ModelServingConfigServedEntitiesExternalModelPalmConfig): void;
    resetPalmConfig(): void;
    get palmConfigInput(): ModelServingConfigServedEntitiesExternalModelPalmConfig | undefined;
}
export interface ModelServingConfigServedEntities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#burst_scaling_enabled ModelServing#burst_scaling_enabled}
    */
    readonly burstScalingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#entity_name ModelServing#entity_name}
    */
    readonly entityName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#entity_version ModelServing#entity_version}
    */
    readonly entityVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#environment_vars ModelServing#environment_vars}
    */
    readonly environmentVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#instance_profile_arn ModelServing#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#max_provisioned_concurrency ModelServing#max_provisioned_concurrency}
    */
    readonly maxProvisionedConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#max_provisioned_throughput ModelServing#max_provisioned_throughput}
    */
    readonly maxProvisionedThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#min_provisioned_concurrency ModelServing#min_provisioned_concurrency}
    */
    readonly minProvisionedConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#min_provisioned_throughput ModelServing#min_provisioned_throughput}
    */
    readonly minProvisionedThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#name ModelServing#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#provisioned_model_units ModelServing#provisioned_model_units}
    */
    readonly provisionedModelUnits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#scale_to_zero_enabled ModelServing#scale_to_zero_enabled}
    */
    readonly scaleToZeroEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#workload_size ModelServing#workload_size}
    */
    readonly workloadSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#workload_type ModelServing#workload_type}
    */
    readonly workloadType?: string;
    /**
    * external_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#external_model ModelServing#external_model}
    */
    readonly externalModel?: ModelServingConfigServedEntitiesExternalModel;
}
export declare function modelServingConfigServedEntitiesToTerraform(struct?: ModelServingConfigServedEntities | cdktn.IResolvable): any;
export declare function modelServingConfigServedEntitiesToHclTerraform(struct?: ModelServingConfigServedEntities | cdktn.IResolvable): any;
export declare class ModelServingConfigServedEntitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingConfigServedEntities | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingConfigServedEntities | cdktn.IResolvable | undefined);
    private _burstScalingEnabled?;
    get burstScalingEnabled(): boolean | cdktn.IResolvable;
    set burstScalingEnabled(value: boolean | cdktn.IResolvable);
    resetBurstScalingEnabled(): void;
    get burstScalingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _entityName?;
    get entityName(): string;
    set entityName(value: string);
    resetEntityName(): void;
    get entityNameInput(): string | undefined;
    private _entityVersion?;
    get entityVersion(): string;
    set entityVersion(value: string);
    resetEntityVersion(): void;
    get entityVersionInput(): string | undefined;
    private _environmentVars?;
    get environmentVars(): {
        [key: string]: string;
    };
    set environmentVars(value: {
        [key: string]: string;
    });
    resetEnvironmentVars(): void;
    get environmentVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _maxProvisionedConcurrency?;
    get maxProvisionedConcurrency(): number;
    set maxProvisionedConcurrency(value: number);
    resetMaxProvisionedConcurrency(): void;
    get maxProvisionedConcurrencyInput(): number | undefined;
    private _maxProvisionedThroughput?;
    get maxProvisionedThroughput(): number;
    set maxProvisionedThroughput(value: number);
    resetMaxProvisionedThroughput(): void;
    get maxProvisionedThroughputInput(): number | undefined;
    private _minProvisionedConcurrency?;
    get minProvisionedConcurrency(): number;
    set minProvisionedConcurrency(value: number);
    resetMinProvisionedConcurrency(): void;
    get minProvisionedConcurrencyInput(): number | undefined;
    private _minProvisionedThroughput?;
    get minProvisionedThroughput(): number;
    set minProvisionedThroughput(value: number);
    resetMinProvisionedThroughput(): void;
    get minProvisionedThroughputInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _provisionedModelUnits?;
    get provisionedModelUnits(): number;
    set provisionedModelUnits(value: number);
    resetProvisionedModelUnits(): void;
    get provisionedModelUnitsInput(): number | undefined;
    private _scaleToZeroEnabled?;
    get scaleToZeroEnabled(): boolean | cdktn.IResolvable;
    set scaleToZeroEnabled(value: boolean | cdktn.IResolvable);
    resetScaleToZeroEnabled(): void;
    get scaleToZeroEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _workloadSize?;
    get workloadSize(): string;
    set workloadSize(value: string);
    resetWorkloadSize(): void;
    get workloadSizeInput(): string | undefined;
    private _workloadType?;
    get workloadType(): string;
    set workloadType(value: string);
    resetWorkloadType(): void;
    get workloadTypeInput(): string | undefined;
    private _externalModel;
    get externalModel(): ModelServingConfigServedEntitiesExternalModelOutputReference;
    putExternalModel(value: ModelServingConfigServedEntitiesExternalModel): void;
    resetExternalModel(): void;
    get externalModelInput(): ModelServingConfigServedEntitiesExternalModel | undefined;
}
export declare class ModelServingConfigServedEntitiesList extends cdktn.ComplexList {
    internalValue?: ModelServingConfigServedEntities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingConfigServedEntitiesOutputReference;
}
export interface ModelServingConfigServedModels {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#burst_scaling_enabled ModelServing#burst_scaling_enabled}
    */
    readonly burstScalingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#environment_vars ModelServing#environment_vars}
    */
    readonly environmentVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#instance_profile_arn ModelServing#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#max_provisioned_concurrency ModelServing#max_provisioned_concurrency}
    */
    readonly maxProvisionedConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#max_provisioned_throughput ModelServing#max_provisioned_throughput}
    */
    readonly maxProvisionedThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#min_provisioned_concurrency ModelServing#min_provisioned_concurrency}
    */
    readonly minProvisionedConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#min_provisioned_throughput ModelServing#min_provisioned_throughput}
    */
    readonly minProvisionedThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#model_name ModelServing#model_name}
    */
    readonly modelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#model_version ModelServing#model_version}
    */
    readonly modelVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#name ModelServing#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#provisioned_model_units ModelServing#provisioned_model_units}
    */
    readonly provisionedModelUnits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#scale_to_zero_enabled ModelServing#scale_to_zero_enabled}
    */
    readonly scaleToZeroEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#workload_size ModelServing#workload_size}
    */
    readonly workloadSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#workload_type ModelServing#workload_type}
    */
    readonly workloadType?: string;
}
export declare function modelServingConfigServedModelsToTerraform(struct?: ModelServingConfigServedModels | cdktn.IResolvable): any;
export declare function modelServingConfigServedModelsToHclTerraform(struct?: ModelServingConfigServedModels | cdktn.IResolvable): any;
export declare class ModelServingConfigServedModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingConfigServedModels | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingConfigServedModels | cdktn.IResolvable | undefined);
    private _burstScalingEnabled?;
    get burstScalingEnabled(): boolean | cdktn.IResolvable;
    set burstScalingEnabled(value: boolean | cdktn.IResolvable);
    resetBurstScalingEnabled(): void;
    get burstScalingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentVars?;
    get environmentVars(): {
        [key: string]: string;
    };
    set environmentVars(value: {
        [key: string]: string;
    });
    resetEnvironmentVars(): void;
    get environmentVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _maxProvisionedConcurrency?;
    get maxProvisionedConcurrency(): number;
    set maxProvisionedConcurrency(value: number);
    resetMaxProvisionedConcurrency(): void;
    get maxProvisionedConcurrencyInput(): number | undefined;
    private _maxProvisionedThroughput?;
    get maxProvisionedThroughput(): number;
    set maxProvisionedThroughput(value: number);
    resetMaxProvisionedThroughput(): void;
    get maxProvisionedThroughputInput(): number | undefined;
    private _minProvisionedConcurrency?;
    get minProvisionedConcurrency(): number;
    set minProvisionedConcurrency(value: number);
    resetMinProvisionedConcurrency(): void;
    get minProvisionedConcurrencyInput(): number | undefined;
    private _minProvisionedThroughput?;
    get minProvisionedThroughput(): number;
    set minProvisionedThroughput(value: number);
    resetMinProvisionedThroughput(): void;
    get minProvisionedThroughputInput(): number | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    get modelNameInput(): string | undefined;
    private _modelVersion?;
    get modelVersion(): string;
    set modelVersion(value: string);
    get modelVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _provisionedModelUnits?;
    get provisionedModelUnits(): number;
    set provisionedModelUnits(value: number);
    resetProvisionedModelUnits(): void;
    get provisionedModelUnitsInput(): number | undefined;
    private _scaleToZeroEnabled?;
    get scaleToZeroEnabled(): boolean | cdktn.IResolvable;
    set scaleToZeroEnabled(value: boolean | cdktn.IResolvable);
    resetScaleToZeroEnabled(): void;
    get scaleToZeroEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _workloadSize?;
    get workloadSize(): string;
    set workloadSize(value: string);
    resetWorkloadSize(): void;
    get workloadSizeInput(): string | undefined;
    private _workloadType?;
    get workloadType(): string;
    set workloadType(value: string);
    resetWorkloadType(): void;
    get workloadTypeInput(): string | undefined;
}
export declare class ModelServingConfigServedModelsList extends cdktn.ComplexList {
    internalValue?: ModelServingConfigServedModels[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingConfigServedModelsOutputReference;
}
export interface ModelServingConfigTrafficConfigRoutes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#served_entity_name ModelServing#served_entity_name}
    */
    readonly servedEntityName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#served_model_name ModelServing#served_model_name}
    */
    readonly servedModelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#traffic_percentage ModelServing#traffic_percentage}
    */
    readonly trafficPercentage: number;
}
export declare function modelServingConfigTrafficConfigRoutesToTerraform(struct?: ModelServingConfigTrafficConfigRoutes | cdktn.IResolvable): any;
export declare function modelServingConfigTrafficConfigRoutesToHclTerraform(struct?: ModelServingConfigTrafficConfigRoutes | cdktn.IResolvable): any;
export declare class ModelServingConfigTrafficConfigRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingConfigTrafficConfigRoutes | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingConfigTrafficConfigRoutes | cdktn.IResolvable | undefined);
    private _servedEntityName?;
    get servedEntityName(): string;
    set servedEntityName(value: string);
    resetServedEntityName(): void;
    get servedEntityNameInput(): string | undefined;
    private _servedModelName?;
    get servedModelName(): string;
    set servedModelName(value: string);
    resetServedModelName(): void;
    get servedModelNameInput(): string | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    get trafficPercentageInput(): number | undefined;
}
export declare class ModelServingConfigTrafficConfigRoutesList extends cdktn.ComplexList {
    internalValue?: ModelServingConfigTrafficConfigRoutes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingConfigTrafficConfigRoutesOutputReference;
}
export interface ModelServingConfigTrafficConfig {
    /**
    * routes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#routes ModelServing#routes}
    */
    readonly routes?: ModelServingConfigTrafficConfigRoutes[] | cdktn.IResolvable;
}
export declare function modelServingConfigTrafficConfigToTerraform(struct?: ModelServingConfigTrafficConfigOutputReference | ModelServingConfigTrafficConfig): any;
export declare function modelServingConfigTrafficConfigToHclTerraform(struct?: ModelServingConfigTrafficConfigOutputReference | ModelServingConfigTrafficConfig): any;
export declare class ModelServingConfigTrafficConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigTrafficConfig | undefined;
    set internalValue(value: ModelServingConfigTrafficConfig | undefined);
    private _routes;
    get routes(): ModelServingConfigTrafficConfigRoutesList;
    putRoutes(value: ModelServingConfigTrafficConfigRoutes[] | cdktn.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktn.IResolvable | ModelServingConfigTrafficConfigRoutes[] | undefined;
}
export interface ModelServingConfigA {
    /**
    * auto_capture_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#auto_capture_config ModelServing#auto_capture_config}
    */
    readonly autoCaptureConfig?: ModelServingConfigAutoCaptureConfig;
    /**
    * served_entities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#served_entities ModelServing#served_entities}
    */
    readonly servedEntities?: ModelServingConfigServedEntities[] | cdktn.IResolvable;
    /**
    * served_models block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#served_models ModelServing#served_models}
    */
    readonly servedModels?: ModelServingConfigServedModels[] | cdktn.IResolvable;
    /**
    * traffic_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#traffic_config ModelServing#traffic_config}
    */
    readonly trafficConfig?: ModelServingConfigTrafficConfig;
}
export declare function modelServingConfigAToTerraform(struct?: ModelServingConfigAOutputReference | ModelServingConfigA): any;
export declare function modelServingConfigAToHclTerraform(struct?: ModelServingConfigAOutputReference | ModelServingConfigA): any;
export declare class ModelServingConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingConfigA | undefined;
    set internalValue(value: ModelServingConfigA | undefined);
    private _autoCaptureConfig;
    get autoCaptureConfig(): ModelServingConfigAutoCaptureConfigOutputReference;
    putAutoCaptureConfig(value: ModelServingConfigAutoCaptureConfig): void;
    resetAutoCaptureConfig(): void;
    get autoCaptureConfigInput(): ModelServingConfigAutoCaptureConfig | undefined;
    private _servedEntities;
    get servedEntities(): ModelServingConfigServedEntitiesList;
    putServedEntities(value: ModelServingConfigServedEntities[] | cdktn.IResolvable): void;
    resetServedEntities(): void;
    get servedEntitiesInput(): cdktn.IResolvable | ModelServingConfigServedEntities[] | undefined;
    private _servedModels;
    get servedModels(): ModelServingConfigServedModelsList;
    putServedModels(value: ModelServingConfigServedModels[] | cdktn.IResolvable): void;
    resetServedModels(): void;
    get servedModelsInput(): cdktn.IResolvable | ModelServingConfigServedModels[] | undefined;
    private _trafficConfig;
    get trafficConfig(): ModelServingConfigTrafficConfigOutputReference;
    putTrafficConfig(value: ModelServingConfigTrafficConfig): void;
    resetTrafficConfig(): void;
    get trafficConfigInput(): ModelServingConfigTrafficConfig | undefined;
}
export interface ModelServingEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#on_update_failure ModelServing#on_update_failure}
    */
    readonly onUpdateFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#on_update_success ModelServing#on_update_success}
    */
    readonly onUpdateSuccess?: string[];
}
export declare function modelServingEmailNotificationsToTerraform(struct?: ModelServingEmailNotificationsOutputReference | ModelServingEmailNotifications): any;
export declare function modelServingEmailNotificationsToHclTerraform(struct?: ModelServingEmailNotificationsOutputReference | ModelServingEmailNotifications): any;
export declare class ModelServingEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingEmailNotifications | undefined;
    set internalValue(value: ModelServingEmailNotifications | undefined);
    private _onUpdateFailure?;
    get onUpdateFailure(): string[];
    set onUpdateFailure(value: string[]);
    resetOnUpdateFailure(): void;
    get onUpdateFailureInput(): string[] | undefined;
    private _onUpdateSuccess?;
    get onUpdateSuccess(): string[];
    set onUpdateSuccess(value: string[]);
    resetOnUpdateSuccess(): void;
    get onUpdateSuccessInput(): string[] | undefined;
}
export interface ModelServingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#workspace_id ModelServing#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function modelServingProviderConfigToTerraform(struct?: ModelServingProviderConfigOutputReference | ModelServingProviderConfig): any;
export declare function modelServingProviderConfigToHclTerraform(struct?: ModelServingProviderConfigOutputReference | ModelServingProviderConfig): any;
export declare class ModelServingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingProviderConfig | undefined;
    set internalValue(value: ModelServingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface ModelServingRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#calls ModelServing#calls}
    */
    readonly calls: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#key ModelServing#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#renewal_period ModelServing#renewal_period}
    */
    readonly renewalPeriod: string;
}
export declare function modelServingRateLimitsToTerraform(struct?: ModelServingRateLimits | cdktn.IResolvable): any;
export declare function modelServingRateLimitsToHclTerraform(struct?: ModelServingRateLimits | cdktn.IResolvable): any;
export declare class ModelServingRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingRateLimits | cdktn.IResolvable | undefined);
    private _calls?;
    get calls(): number;
    set calls(value: number);
    get callsInput(): number | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
}
export declare class ModelServingRateLimitsList extends cdktn.ComplexList {
    internalValue?: ModelServingRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingRateLimitsOutputReference;
}
export interface ModelServingTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#key ModelServing#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#value ModelServing#value}
    */
    readonly value?: string;
}
export declare function modelServingTagsToTerraform(struct?: ModelServingTags | cdktn.IResolvable): any;
export declare function modelServingTagsToHclTerraform(struct?: ModelServingTags | cdktn.IResolvable): any;
export declare class ModelServingTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ModelServingTags | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ModelServingTagsList extends cdktn.ComplexList {
    internalValue?: ModelServingTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ModelServingTagsOutputReference;
}
export interface ModelServingTelemetryConfigInferenceTableConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#name ModelServing#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#sampling_fraction ModelServing#sampling_fraction}
    */
    readonly samplingFraction?: number;
}
export declare function modelServingTelemetryConfigInferenceTableConfigToTerraform(struct?: ModelServingTelemetryConfigInferenceTableConfigOutputReference | ModelServingTelemetryConfigInferenceTableConfig): any;
export declare function modelServingTelemetryConfigInferenceTableConfigToHclTerraform(struct?: ModelServingTelemetryConfigInferenceTableConfigOutputReference | ModelServingTelemetryConfigInferenceTableConfig): any;
export declare class ModelServingTelemetryConfigInferenceTableConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingTelemetryConfigInferenceTableConfig | undefined;
    set internalValue(value: ModelServingTelemetryConfigInferenceTableConfig | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _samplingFraction?;
    get samplingFraction(): number;
    set samplingFraction(value: number);
    resetSamplingFraction(): void;
    get samplingFractionInput(): number | undefined;
}
export interface ModelServingTelemetryConfigTableNames {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#annotations_table ModelServing#annotations_table}
    */
    readonly annotationsTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#logs_table ModelServing#logs_table}
    */
    readonly logsTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#metrics_table ModelServing#metrics_table}
    */
    readonly metricsTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#traces_table ModelServing#traces_table}
    */
    readonly tracesTable?: string;
}
export declare function modelServingTelemetryConfigTableNamesToTerraform(struct?: ModelServingTelemetryConfigTableNamesOutputReference | ModelServingTelemetryConfigTableNames): any;
export declare function modelServingTelemetryConfigTableNamesToHclTerraform(struct?: ModelServingTelemetryConfigTableNamesOutputReference | ModelServingTelemetryConfigTableNames): any;
export declare class ModelServingTelemetryConfigTableNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingTelemetryConfigTableNames | undefined;
    set internalValue(value: ModelServingTelemetryConfigTableNames | undefined);
    private _annotationsTable?;
    get annotationsTable(): string;
    set annotationsTable(value: string);
    resetAnnotationsTable(): void;
    get annotationsTableInput(): string | undefined;
    private _logsTable?;
    get logsTable(): string;
    set logsTable(value: string);
    resetLogsTable(): void;
    get logsTableInput(): string | undefined;
    private _metricsTable?;
    get metricsTable(): string;
    set metricsTable(value: string);
    resetMetricsTable(): void;
    get metricsTableInput(): string | undefined;
    private _tracesTable?;
    get tracesTable(): string;
    set tracesTable(value: string);
    resetTracesTable(): void;
    get tracesTableInput(): string | undefined;
}
export interface ModelServingTelemetryConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#enabled_telemetry_features ModelServing#enabled_telemetry_features}
    */
    readonly enabledTelemetryFeatures?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#telemetry_profile_id ModelServing#telemetry_profile_id}
    */
    readonly telemetryProfileId?: string;
    /**
    * inference_table_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#inference_table_config ModelServing#inference_table_config}
    */
    readonly inferenceTableConfig?: ModelServingTelemetryConfigInferenceTableConfig;
    /**
    * table_names block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#table_names ModelServing#table_names}
    */
    readonly tableNames?: ModelServingTelemetryConfigTableNames;
}
export declare function modelServingTelemetryConfigToTerraform(struct?: ModelServingTelemetryConfigOutputReference | ModelServingTelemetryConfig): any;
export declare function modelServingTelemetryConfigToHclTerraform(struct?: ModelServingTelemetryConfigOutputReference | ModelServingTelemetryConfig): any;
export declare class ModelServingTelemetryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingTelemetryConfig | undefined;
    set internalValue(value: ModelServingTelemetryConfig | undefined);
    private _enabledTelemetryFeatures?;
    get enabledTelemetryFeatures(): string[];
    set enabledTelemetryFeatures(value: string[]);
    resetEnabledTelemetryFeatures(): void;
    get enabledTelemetryFeaturesInput(): string[] | undefined;
    private _telemetryProfileId?;
    get telemetryProfileId(): string;
    set telemetryProfileId(value: string);
    resetTelemetryProfileId(): void;
    get telemetryProfileIdInput(): string | undefined;
    private _inferenceTableConfig;
    get inferenceTableConfig(): ModelServingTelemetryConfigInferenceTableConfigOutputReference;
    putInferenceTableConfig(value: ModelServingTelemetryConfigInferenceTableConfig): void;
    resetInferenceTableConfig(): void;
    get inferenceTableConfigInput(): ModelServingTelemetryConfigInferenceTableConfig | undefined;
    private _tableNames;
    get tableNames(): ModelServingTelemetryConfigTableNamesOutputReference;
    putTableNames(value: ModelServingTelemetryConfigTableNames): void;
    resetTableNames(): void;
    get tableNamesInput(): ModelServingTelemetryConfigTableNames | undefined;
}
export interface ModelServingTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#create ModelServing#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#update ModelServing#update}
    */
    readonly update?: string;
}
export declare function modelServingTimeoutsToTerraform(struct?: ModelServingTimeouts | cdktn.IResolvable): any;
export declare function modelServingTimeoutsToHclTerraform(struct?: ModelServingTimeouts | cdktn.IResolvable): any;
export declare class ModelServingTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ModelServingTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ModelServingTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving databricks_model_serving}
*/
export declare class ModelServing extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_model_serving";
    /**
    * Generates CDKTN code for importing a ModelServing resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ModelServing to import
    * @param importFromId The id of the existing ModelServing that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ModelServing to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/model_serving databricks_model_serving} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ModelServingConfig
    */
    constructor(scope: Construct, id: string, config: ModelServingConfig);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get endpointUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _routeOptimized?;
    get routeOptimized(): boolean | cdktn.IResolvable;
    set routeOptimized(value: boolean | cdktn.IResolvable);
    resetRouteOptimized(): void;
    get routeOptimizedInput(): boolean | cdktn.IResolvable | undefined;
    get servingEndpointId(): string;
    private _aiGateway;
    get aiGateway(): ModelServingAiGatewayOutputReference;
    putAiGateway(value: ModelServingAiGateway): void;
    resetAiGateway(): void;
    get aiGatewayInput(): ModelServingAiGateway | undefined;
    private _config;
    get config(): ModelServingConfigAOutputReference;
    putConfig(value: ModelServingConfigA): void;
    resetConfig(): void;
    get configInput(): ModelServingConfigA | undefined;
    private _emailNotifications;
    get emailNotifications(): ModelServingEmailNotificationsOutputReference;
    putEmailNotifications(value: ModelServingEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): ModelServingEmailNotifications | undefined;
    private _providerConfig;
    get providerConfig(): ModelServingProviderConfigOutputReference;
    putProviderConfig(value: ModelServingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ModelServingProviderConfig | undefined;
    private _rateLimits;
    get rateLimits(): ModelServingRateLimitsList;
    putRateLimits(value: ModelServingRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | ModelServingRateLimits[] | undefined;
    private _tags;
    get tags(): ModelServingTagsList;
    putTags(value: ModelServingTags[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | ModelServingTags[] | undefined;
    private _telemetryConfig;
    get telemetryConfig(): ModelServingTelemetryConfigOutputReference;
    putTelemetryConfig(value: ModelServingTelemetryConfig): void;
    resetTelemetryConfig(): void;
    get telemetryConfigInput(): ModelServingTelemetryConfig | undefined;
    private _timeouts;
    get timeouts(): ModelServingTimeoutsOutputReference;
    putTimeouts(value: ModelServingTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ModelServingTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
