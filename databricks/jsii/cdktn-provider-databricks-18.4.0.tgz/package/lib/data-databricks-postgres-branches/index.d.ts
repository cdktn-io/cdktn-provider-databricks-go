/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresBranchesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#page_size DataDatabricksPostgresBranches#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#parent DataDatabricksPostgresBranches#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#provider_config DataDatabricksPostgresBranches#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresBranchesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#show_deleted DataDatabricksPostgresBranches#show_deleted}
    */
    readonly showDeleted?: boolean | cdktn.IResolvable;
}
export interface DataDatabricksPostgresBranchesBranchesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#workspace_id DataDatabricksPostgresBranches#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresBranchesBranchesProviderConfigToTerraform(struct?: DataDatabricksPostgresBranchesBranchesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresBranchesBranchesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresBranchesBranchesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresBranchesBranchesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresBranchesBranchesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresBranchesBranchesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresBranchesBranchesSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#expire_time DataDatabricksPostgresBranches#expire_time}
    */
    readonly expireTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#is_protected DataDatabricksPostgresBranches#is_protected}
    */
    readonly isProtected?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#no_expiry DataDatabricksPostgresBranches#no_expiry}
    */
    readonly noExpiry?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#source_branch DataDatabricksPostgresBranches#source_branch}
    */
    readonly sourceBranch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#source_branch_lsn DataDatabricksPostgresBranches#source_branch_lsn}
    */
    readonly sourceBranchLsn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#source_branch_time DataDatabricksPostgresBranches#source_branch_time}
    */
    readonly sourceBranchTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#ttl DataDatabricksPostgresBranches#ttl}
    */
    readonly ttl?: string;
}
export declare function dataDatabricksPostgresBranchesBranchesSpecToTerraform(struct?: DataDatabricksPostgresBranchesBranchesSpec): any;
export declare function dataDatabricksPostgresBranchesBranchesSpecToHclTerraform(struct?: DataDatabricksPostgresBranchesBranchesSpec): any;
export declare class DataDatabricksPostgresBranchesBranchesSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresBranchesBranchesSpec | undefined;
    set internalValue(value: DataDatabricksPostgresBranchesBranchesSpec | undefined);
    private _expireTime?;
    get expireTime(): string;
    set expireTime(value: string);
    resetExpireTime(): void;
    get expireTimeInput(): string | undefined;
    private _isProtected?;
    get isProtected(): boolean | cdktn.IResolvable;
    set isProtected(value: boolean | cdktn.IResolvable);
    resetIsProtected(): void;
    get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
    private _noExpiry?;
    get noExpiry(): boolean | cdktn.IResolvable;
    set noExpiry(value: boolean | cdktn.IResolvable);
    resetNoExpiry(): void;
    get noExpiryInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceBranch?;
    get sourceBranch(): string;
    set sourceBranch(value: string);
    resetSourceBranch(): void;
    get sourceBranchInput(): string | undefined;
    private _sourceBranchLsn?;
    get sourceBranchLsn(): string;
    set sourceBranchLsn(value: string);
    resetSourceBranchLsn(): void;
    get sourceBranchLsnInput(): string | undefined;
    private _sourceBranchTime?;
    get sourceBranchTime(): string;
    set sourceBranchTime(value: string);
    resetSourceBranchTime(): void;
    get sourceBranchTimeInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    resetTtl(): void;
    get ttlInput(): string | undefined;
}
export interface DataDatabricksPostgresBranchesBranchesStatus {
}
export declare function dataDatabricksPostgresBranchesBranchesStatusToTerraform(struct?: DataDatabricksPostgresBranchesBranchesStatus): any;
export declare function dataDatabricksPostgresBranchesBranchesStatusToHclTerraform(struct?: DataDatabricksPostgresBranchesBranchesStatus): any;
export declare class DataDatabricksPostgresBranchesBranchesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresBranchesBranchesStatus | undefined;
    set internalValue(value: DataDatabricksPostgresBranchesBranchesStatus | undefined);
    get branchId(): string;
    get currentState(): string;
    get default(): cdktn.IResolvable;
    get deleteTime(): string;
    get expireTime(): string;
    get isProtected(): cdktn.IResolvable;
    get logicalSizeBytes(): number;
    get pendingState(): string;
    get purgeTime(): string;
    get sourceBranch(): string;
    get sourceBranchLsn(): string;
    get sourceBranchTime(): string;
    get stateChangeTime(): string;
}
export interface DataDatabricksPostgresBranchesBranches {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#name DataDatabricksPostgresBranches#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#provider_config DataDatabricksPostgresBranches#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresBranchesBranchesProviderConfig;
}
export declare function dataDatabricksPostgresBranchesBranchesToTerraform(struct?: DataDatabricksPostgresBranchesBranches): any;
export declare function dataDatabricksPostgresBranchesBranchesToHclTerraform(struct?: DataDatabricksPostgresBranchesBranches): any;
export declare class DataDatabricksPostgresBranchesBranchesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresBranchesBranches | undefined;
    set internalValue(value: DataDatabricksPostgresBranchesBranches | undefined);
    get branchId(): string;
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresBranchesBranchesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresBranchesBranchesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresBranchesBranchesProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresBranchesBranchesSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresBranchesBranchesStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
}
export declare class DataDatabricksPostgresBranchesBranchesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresBranchesBranches[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresBranchesBranchesOutputReference;
}
export interface DataDatabricksPostgresBranchesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#workspace_id DataDatabricksPostgresBranches#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresBranchesProviderConfigToTerraform(struct?: DataDatabricksPostgresBranchesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresBranchesProviderConfigToHclTerraform(struct?: DataDatabricksPostgresBranchesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresBranchesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresBranchesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresBranchesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches databricks_postgres_branches}
*/
export declare class DataDatabricksPostgresBranches extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_branches";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresBranches resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresBranches to import
    * @param importFromId The id of the existing DataDatabricksPostgresBranches that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresBranches to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_branches databricks_postgres_branches} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresBranchesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresBranchesConfig);
    private _branches;
    get branches(): DataDatabricksPostgresBranchesBranchesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresBranchesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresBranchesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresBranchesProviderConfig | undefined;
    private _showDeleted?;
    get showDeleted(): boolean | cdktn.IResolvable;
    set showDeleted(value: boolean | cdktn.IResolvable);
    resetShowDeleted(): void;
    get showDeletedInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
