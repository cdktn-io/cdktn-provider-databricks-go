/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WorkspaceIamWorkspaceIdentityDetailV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/workspace_iam_workspace_identity_detail_v2#provider_config WorkspaceIamWorkspaceIdentityDetailV2#provider_config}
    */
    readonly providerConfig?: WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/workspace_iam_workspace_identity_detail_v2#workspace_identity_status WorkspaceIamWorkspaceIdentityDetailV2#workspace_identity_status}
    */
    readonly workspaceIdentityStatus?: string;
}
export interface WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/workspace_iam_workspace_identity_detail_v2#workspace_id WorkspaceIamWorkspaceIdentityDetailV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function workspaceIamWorkspaceIdentityDetailV2ProviderConfigToTerraform(struct?: WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable): any;
export declare function workspaceIamWorkspaceIdentityDetailV2ProviderConfigToHclTerraform(struct?: WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable): any;
export declare class WorkspaceIamWorkspaceIdentityDetailV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/workspace_iam_workspace_identity_detail_v2 databricks_workspace_iam_workspace_identity_detail_v2}
*/
export declare class WorkspaceIamWorkspaceIdentityDetailV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_workspace_iam_workspace_identity_detail_v2";
    /**
    * Generates CDKTN code for importing a WorkspaceIamWorkspaceIdentityDetailV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the WorkspaceIamWorkspaceIdentityDetailV2 to import
    * @param importFromId The id of the existing WorkspaceIamWorkspaceIdentityDetailV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/workspace_iam_workspace_identity_detail_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the WorkspaceIamWorkspaceIdentityDetailV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/workspace_iam_workspace_identity_detail_v2 databricks_workspace_iam_workspace_identity_detail_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WorkspaceIamWorkspaceIdentityDetailV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: WorkspaceIamWorkspaceIdentityDetailV2Config);
    get assignmentType(): string;
    get principalId(): number;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): WorkspaceIamWorkspaceIdentityDetailV2ProviderConfigOutputReference;
    putProviderConfig(value: WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | WorkspaceIamWorkspaceIdentityDetailV2ProviderConfig | undefined;
    private _workspaceIdentityStatus?;
    get workspaceIdentityStatus(): string;
    set workspaceIdentityStatus(value: string);
    resetWorkspaceIdentityStatus(): void;
    get workspaceIdentityStatusInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
