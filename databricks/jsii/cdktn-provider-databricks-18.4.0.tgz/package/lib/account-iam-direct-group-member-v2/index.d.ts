/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccountIamDirectGroupMemberV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/account_iam_direct_group_member_v2#group_id AccountIamDirectGroupMemberV2#group_id}
    */
    readonly groupId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/account_iam_direct_group_member_v2#principal_id AccountIamDirectGroupMemberV2#principal_id}
    */
    readonly principalId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/account_iam_direct_group_member_v2 databricks_account_iam_direct_group_member_v2}
*/
export declare class AccountIamDirectGroupMemberV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_account_iam_direct_group_member_v2";
    /**
    * Generates CDKTN code for importing a AccountIamDirectGroupMemberV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccountIamDirectGroupMemberV2 to import
    * @param importFromId The id of the existing AccountIamDirectGroupMemberV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/account_iam_direct_group_member_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccountIamDirectGroupMemberV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/account_iam_direct_group_member_v2 databricks_account_iam_direct_group_member_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccountIamDirectGroupMemberV2Config
    */
    constructor(scope: Construct, id: string, config: AccountIamDirectGroupMemberV2Config);
    get displayName(): string;
    get externalId(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    resetGroupId(): void;
    get groupIdInput(): number | undefined;
    get membershipSource(): string;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
