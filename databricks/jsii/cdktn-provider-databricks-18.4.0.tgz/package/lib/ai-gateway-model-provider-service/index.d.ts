/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiGatewayModelProviderServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#comment AiGatewayModelProviderService#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#config AiGatewayModelProviderService#config}
    */
    readonly config?: AiGatewayModelProviderServiceConfigA;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#model_provider_service_id AiGatewayModelProviderService#model_provider_service_id}
    */
    readonly modelProviderServiceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#owner AiGatewayModelProviderService#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#parent AiGatewayModelProviderService#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#provider_config AiGatewayModelProviderService#provider_config}
    */
    readonly providerConfig?: AiGatewayModelProviderServiceProviderConfig;
}
export interface AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#access_key_id AiGatewayModelProviderService#access_key_id}
    */
    readonly accessKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#secret_access_key AiGatewayModelProviderService#secret_access_key}
    */
    readonly secretAccessKey?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey;
}
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    resetAccessKeyId(): void;
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey;
    get secretAccessKey(): AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyOutputReference;
    putSecretAccessKey(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey): void;
    resetSecretAccessKey(): void;
    get secretAccessKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | undefined;
}
export interface AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#name AiGatewayModelProviderService#name}
    */
    readonly name: string;
}
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialToTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAmazonBedrockDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#aws_access_key AiGatewayModelProviderService#aws_access_key}
    */
    readonly awsAccessKey?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#region AiGatewayModelProviderService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#service_credential AiGatewayModelProviderService#service_credential}
    */
    readonly serviceCredential?: AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential;
}
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectToTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockDirectToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAmazonBedrockDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirect | cdktn.IResolvable | undefined);
    private _awsAccessKey;
    get awsAccessKey(): AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKeyOutputReference;
    putAwsAccessKey(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey): void;
    resetAwsAccessKey(): void;
    get awsAccessKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAmazonBedrockDirectAwsAccessKey | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceCredential;
    get serviceCredential(): AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredentialOutputReference;
    putServiceCredential(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAmazonBedrockDirectServiceCredential | undefined;
}
export interface AiGatewayModelProviderServiceConfigAmazonBedrock {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#direct AiGatewayModelProviderService#direct}
    */
    readonly direct?: AiGatewayModelProviderServiceConfigAmazonBedrockDirect;
}
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockToTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAmazonBedrockToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAmazonBedrockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAmazonBedrock | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): AiGatewayModelProviderServiceConfigAmazonBedrockDirectOutputReference;
    putDirect(value: AiGatewayModelProviderServiceConfigAmazonBedrockDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAmazonBedrockDirect | undefined;
}
export interface AiGatewayModelProviderServiceConfigAnthropicDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigAnthropicDirectApiKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAnthropicDirectApiKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAnthropicDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAnthropicDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAnthropicDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#api_key AiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: AiGatewayModelProviderServiceConfigAnthropicDirectApiKey;
}
export declare function aiGatewayModelProviderServiceConfigAnthropicDirectToTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAnthropicDirectToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAnthropicDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAnthropicDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): AiGatewayModelProviderServiceConfigAnthropicDirectApiKeyOutputReference;
    putApiKey(value: AiGatewayModelProviderServiceConfigAnthropicDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAnthropicDirectApiKey | undefined;
}
export interface AiGatewayModelProviderServiceConfigAnthropicRelayed {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plan_type AiGatewayModelProviderService#plan_type}
    */
    readonly planType?: string;
}
export declare function aiGatewayModelProviderServiceConfigAnthropicRelayedToTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAnthropicRelayedToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAnthropicRelayedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAnthropicRelayed | cdktn.IResolvable | undefined);
    private _planType?;
    get planType(): string;
    set planType(value: string);
    resetPlanType(): void;
    get planTypeInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAnthropic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#direct AiGatewayModelProviderService#direct}
    */
    readonly direct?: AiGatewayModelProviderServiceConfigAnthropicDirect;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#relayed AiGatewayModelProviderService#relayed}
    */
    readonly relayed?: AiGatewayModelProviderServiceConfigAnthropicRelayed;
}
export declare function aiGatewayModelProviderServiceConfigAnthropicToTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAnthropicToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAnthropicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAnthropic | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): AiGatewayModelProviderServiceConfigAnthropicDirectOutputReference;
    putDirect(value: AiGatewayModelProviderServiceConfigAnthropicDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAnthropicDirect | undefined;
    private _relayed;
    get relayed(): AiGatewayModelProviderServiceConfigAnthropicRelayedOutputReference;
    putRelayed(value: AiGatewayModelProviderServiceConfigAnthropicRelayed): void;
    resetRelayed(): void;
    get relayedInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAnthropicRelayed | undefined;
}
export interface AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretToTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#client_id AiGatewayModelProviderService#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#client_secret AiGatewayModelProviderService#client_secret}
    */
    readonly clientSecret?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#tenant_id AiGatewayModelProviderService#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalToTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret;
    get clientSecret(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecretOutputReference;
    putClientSecret(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret): void;
    resetClientSecret(): void;
    get clientSecretInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#name AiGatewayModelProviderService#name}
    */
    readonly name: string;
}
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialToTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigAzureOpenaiDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#api_key AiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#base_url AiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#entra_service_principal AiGatewayModelProviderService#entra_service_principal}
    */
    readonly entraServicePrincipal?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#service_credential AiGatewayModelProviderService#service_credential}
    */
    readonly serviceCredential?: AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential;
}
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectToTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiDirectToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAzureOpenaiDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKeyOutputReference;
    putApiKey(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAzureOpenaiDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _entraServicePrincipal;
    get entraServicePrincipal(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipalOutputReference;
    putEntraServicePrincipal(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal): void;
    resetEntraServicePrincipal(): void;
    get entraServicePrincipalInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAzureOpenaiDirectEntraServicePrincipal | undefined;
    private _serviceCredential;
    get serviceCredential(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredentialOutputReference;
    putServiceCredential(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAzureOpenaiDirectServiceCredential | undefined;
}
export interface AiGatewayModelProviderServiceConfigAzureOpenai {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#direct AiGatewayModelProviderService#direct}
    */
    readonly direct?: AiGatewayModelProviderServiceConfigAzureOpenaiDirect;
}
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiToTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAzureOpenaiToHclTerraform(struct?: AiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAzureOpenaiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigAzureOpenai | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): AiGatewayModelProviderServiceConfigAzureOpenaiDirectOutputReference;
    putDirect(value: AiGatewayModelProviderServiceConfigAzureOpenaiDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAzureOpenaiDirect | undefined;
}
export interface AiGatewayModelProviderServiceConfigCustomDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigCustomDirectApiKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigCustomDirectApiKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigCustomDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigCustomDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigCustomDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#api_key AiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: AiGatewayModelProviderServiceConfigCustomDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#base_url AiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
}
export declare function aiGatewayModelProviderServiceConfigCustomDirectToTerraform(struct?: AiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigCustomDirectToHclTerraform(struct?: AiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigCustomDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigCustomDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): AiGatewayModelProviderServiceConfigCustomDirectApiKeyOutputReference;
    putApiKey(value: AiGatewayModelProviderServiceConfigCustomDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigCustomDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigCustom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#direct AiGatewayModelProviderService#direct}
    */
    readonly direct?: AiGatewayModelProviderServiceConfigCustomDirect;
}
export declare function aiGatewayModelProviderServiceConfigCustomToTerraform(struct?: AiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigCustomToHclTerraform(struct?: AiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigCustom | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): AiGatewayModelProviderServiceConfigCustomDirectOutputReference;
    putDirect(value: AiGatewayModelProviderServiceConfigCustomDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigCustomDirect | undefined;
}
export interface AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#api_key AiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#project_id AiGatewayModelProviderService#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#region AiGatewayModelProviderService#region}
    */
    readonly region?: string;
}
export declare function aiGatewayModelProviderServiceConfigGeminiEnterpriseDirectToTerraform(struct?: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigGeminiEnterpriseDirectToHclTerraform(struct?: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKeyOutputReference;
    putApiKey(value: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectApiKey | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigGeminiEnterprise {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#direct AiGatewayModelProviderService#direct}
    */
    readonly direct?: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect;
}
export declare function aiGatewayModelProviderServiceConfigGeminiEnterpriseToTerraform(struct?: AiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigGeminiEnterpriseToHclTerraform(struct?: AiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigGeminiEnterpriseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigGeminiEnterprise | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): AiGatewayModelProviderServiceConfigGeminiEnterpriseDirectOutputReference;
    putDirect(value: AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigGeminiEnterpriseDirect | undefined;
}
export interface AiGatewayModelProviderServiceConfigInferenceTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#disabled AiGatewayModelProviderService#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#parent AiGatewayModelProviderService#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#table_name_prefix AiGatewayModelProviderService#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function aiGatewayModelProviderServiceConfigInferenceTableToTerraform(struct?: AiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigInferenceTableToHclTerraform(struct?: AiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigInferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigInferenceTable | cdktn.IResolvable | undefined);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get table(): string;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretToTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretToHclTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#client_id AiGatewayModelProviderService#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#client_secret AiGatewayModelProviderService#client_secret}
    */
    readonly clientSecret?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#tenant_id AiGatewayModelProviderService#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalToTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalToHclTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret;
    get clientSecret(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretOutputReference;
    putClientSecret(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret): void;
    resetClientSecret(): void;
    get clientSecretInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#name AiGatewayModelProviderService#name}
    */
    readonly name: string;
}
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialToTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialToHclTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#api_key AiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#base_url AiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#entra_service_principal AiGatewayModelProviderService#entra_service_principal}
    */
    readonly entraServicePrincipal?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#service_credential AiGatewayModelProviderService#service_credential}
    */
    readonly serviceCredential?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential;
}
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectToTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryDirectToHclTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKeyOutputReference;
    putApiKey(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _entraServicePrincipal;
    get entraServicePrincipal(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipalOutputReference;
    putEntraServicePrincipal(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal): void;
    resetEntraServicePrincipal(): void;
    get entraServicePrincipalInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectEntraServicePrincipal | undefined;
    private _serviceCredential;
    get serviceCredential(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredentialOutputReference;
    putServiceCredential(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectServiceCredential | undefined;
}
export interface AiGatewayModelProviderServiceConfigMicrosoftFoundry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#direct AiGatewayModelProviderService#direct}
    */
    readonly direct?: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect;
}
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryToTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigMicrosoftFoundryToHclTerraform(struct?: AiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigMicrosoftFoundryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigMicrosoftFoundry | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): AiGatewayModelProviderServiceConfigMicrosoftFoundryDirectOutputReference;
    putDirect(value: AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigMicrosoftFoundryDirect | undefined;
}
export interface AiGatewayModelProviderServiceConfigOpenaiDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#plaintext AiGatewayModelProviderService#plaintext}
    */
    readonly plaintext?: string;
}
export declare function aiGatewayModelProviderServiceConfigOpenaiDirectApiKeyToTerraform(struct?: AiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigOpenaiDirectApiKeyToHclTerraform(struct?: AiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigOpenaiDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigOpenaiDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigOpenaiDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#api_key AiGatewayModelProviderService#api_key}
    */
    readonly apiKey?: AiGatewayModelProviderServiceConfigOpenaiDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#base_url AiGatewayModelProviderService#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#organization AiGatewayModelProviderService#organization}
    */
    readonly organization?: string;
}
export declare function aiGatewayModelProviderServiceConfigOpenaiDirectToTerraform(struct?: AiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigOpenaiDirectToHclTerraform(struct?: AiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigOpenaiDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigOpenaiDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): AiGatewayModelProviderServiceConfigOpenaiDirectApiKeyOutputReference;
    putApiKey(value: AiGatewayModelProviderServiceConfigOpenaiDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigOpenaiDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
}
export interface AiGatewayModelProviderServiceConfigOpenai {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#direct AiGatewayModelProviderService#direct}
    */
    readonly direct?: AiGatewayModelProviderServiceConfigOpenaiDirect;
}
export declare function aiGatewayModelProviderServiceConfigOpenaiToTerraform(struct?: AiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigOpenaiToHclTerraform(struct?: AiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigOpenaiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigOpenai | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): AiGatewayModelProviderServiceConfigOpenaiDirectOutputReference;
    putDirect(value: AiGatewayModelProviderServiceConfigOpenaiDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigOpenaiDirect | undefined;
}
export interface AiGatewayModelProviderServiceConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#key AiGatewayModelProviderService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#principal AiGatewayModelProviderService#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#renewal_period AiGatewayModelProviderService#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#request_tag_key AiGatewayModelProviderService#request_tag_key}
    */
    readonly requestTagKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#request_tag_value AiGatewayModelProviderService#request_tag_value}
    */
    readonly requestTagValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#requests AiGatewayModelProviderService#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#tokens AiGatewayModelProviderService#tokens}
    */
    readonly tokens?: number;
}
export declare function aiGatewayModelProviderServiceConfigRateLimitsToTerraform(struct?: AiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigRateLimitsToHclTerraform(struct?: AiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requestTagKey?;
    get requestTagKey(): string;
    set requestTagKey(value: string);
    resetRequestTagKey(): void;
    get requestTagKeyInput(): string | undefined;
    private _requestTagValue?;
    get requestTagValue(): string;
    set requestTagValue(value: string);
    resetRequestTagValue(): void;
    get requestTagValueInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class AiGatewayModelProviderServiceConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: AiGatewayModelProviderServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayModelProviderServiceConfigRateLimitsOutputReference;
}
export interface AiGatewayModelProviderServiceConfigTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#model AiGatewayModelProviderService#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#native_api_types AiGatewayModelProviderService#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function aiGatewayModelProviderServiceConfigTargetsToTerraform(struct?: AiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigTargetsToHclTerraform(struct?: AiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigTargets | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export declare class AiGatewayModelProviderServiceConfigTargetsList extends cdktn.ComplexList {
    internalValue?: AiGatewayModelProviderServiceConfigTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayModelProviderServiceConfigTargetsOutputReference;
}
export interface AiGatewayModelProviderServiceConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#allow_all_targets AiGatewayModelProviderService#allow_all_targets}
    */
    readonly allowAllTargets?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#amazon_bedrock AiGatewayModelProviderService#amazon_bedrock}
    */
    readonly amazonBedrock?: AiGatewayModelProviderServiceConfigAmazonBedrock;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#anthropic AiGatewayModelProviderService#anthropic}
    */
    readonly anthropic?: AiGatewayModelProviderServiceConfigAnthropic;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#azure_openai AiGatewayModelProviderService#azure_openai}
    */
    readonly azureOpenai?: AiGatewayModelProviderServiceConfigAzureOpenai;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#custom AiGatewayModelProviderService#custom}
    */
    readonly custom?: AiGatewayModelProviderServiceConfigCustom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#forward_headers AiGatewayModelProviderService#forward_headers}
    */
    readonly forwardHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#forward_query_parameters AiGatewayModelProviderService#forward_query_parameters}
    */
    readonly forwardQueryParameters?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#forward_unmanaged_paths AiGatewayModelProviderService#forward_unmanaged_paths}
    */
    readonly forwardUnmanagedPaths?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#gemini_enterprise AiGatewayModelProviderService#gemini_enterprise}
    */
    readonly geminiEnterprise?: AiGatewayModelProviderServiceConfigGeminiEnterprise;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#inference_table AiGatewayModelProviderService#inference_table}
    */
    readonly inferenceTable?: AiGatewayModelProviderServiceConfigInferenceTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#microsoft_foundry AiGatewayModelProviderService#microsoft_foundry}
    */
    readonly microsoftFoundry?: AiGatewayModelProviderServiceConfigMicrosoftFoundry;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#openai AiGatewayModelProviderService#openai}
    */
    readonly openai?: AiGatewayModelProviderServiceConfigOpenai;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#provider_type AiGatewayModelProviderService#provider_type}
    */
    readonly providerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#rate_limits AiGatewayModelProviderService#rate_limits}
    */
    readonly rateLimits?: AiGatewayModelProviderServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#targets AiGatewayModelProviderService#targets}
    */
    readonly targets?: AiGatewayModelProviderServiceConfigTargets[] | cdktn.IResolvable;
}
export declare function aiGatewayModelProviderServiceConfigAToTerraform(struct?: AiGatewayModelProviderServiceConfigA | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceConfigAToHclTerraform(struct?: AiGatewayModelProviderServiceConfigA | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceConfigA | cdktn.IResolvable | undefined);
    private _allowAllTargets?;
    get allowAllTargets(): boolean | cdktn.IResolvable;
    set allowAllTargets(value: boolean | cdktn.IResolvable);
    resetAllowAllTargets(): void;
    get allowAllTargetsInput(): boolean | cdktn.IResolvable | undefined;
    private _amazonBedrock;
    get amazonBedrock(): AiGatewayModelProviderServiceConfigAmazonBedrockOutputReference;
    putAmazonBedrock(value: AiGatewayModelProviderServiceConfigAmazonBedrock): void;
    resetAmazonBedrock(): void;
    get amazonBedrockInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAmazonBedrock | undefined;
    private _anthropic;
    get anthropic(): AiGatewayModelProviderServiceConfigAnthropicOutputReference;
    putAnthropic(value: AiGatewayModelProviderServiceConfigAnthropic): void;
    resetAnthropic(): void;
    get anthropicInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAnthropic | undefined;
    private _azureOpenai;
    get azureOpenai(): AiGatewayModelProviderServiceConfigAzureOpenaiOutputReference;
    putAzureOpenai(value: AiGatewayModelProviderServiceConfigAzureOpenai): void;
    resetAzureOpenai(): void;
    get azureOpenaiInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigAzureOpenai | undefined;
    private _custom;
    get custom(): AiGatewayModelProviderServiceConfigCustomOutputReference;
    putCustom(value: AiGatewayModelProviderServiceConfigCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigCustom | undefined;
    private _forwardHeaders?;
    get forwardHeaders(): boolean | cdktn.IResolvable;
    set forwardHeaders(value: boolean | cdktn.IResolvable);
    resetForwardHeaders(): void;
    get forwardHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardQueryParameters?;
    get forwardQueryParameters(): boolean | cdktn.IResolvable;
    set forwardQueryParameters(value: boolean | cdktn.IResolvable);
    resetForwardQueryParameters(): void;
    get forwardQueryParametersInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardUnmanagedPaths?;
    get forwardUnmanagedPaths(): boolean | cdktn.IResolvable;
    set forwardUnmanagedPaths(value: boolean | cdktn.IResolvable);
    resetForwardUnmanagedPaths(): void;
    get forwardUnmanagedPathsInput(): boolean | cdktn.IResolvable | undefined;
    private _geminiEnterprise;
    get geminiEnterprise(): AiGatewayModelProviderServiceConfigGeminiEnterpriseOutputReference;
    putGeminiEnterprise(value: AiGatewayModelProviderServiceConfigGeminiEnterprise): void;
    resetGeminiEnterprise(): void;
    get geminiEnterpriseInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigGeminiEnterprise | undefined;
    private _inferenceTable;
    get inferenceTable(): AiGatewayModelProviderServiceConfigInferenceTableOutputReference;
    putInferenceTable(value: AiGatewayModelProviderServiceConfigInferenceTable): void;
    resetInferenceTable(): void;
    get inferenceTableInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigInferenceTable | undefined;
    private _microsoftFoundry;
    get microsoftFoundry(): AiGatewayModelProviderServiceConfigMicrosoftFoundryOutputReference;
    putMicrosoftFoundry(value: AiGatewayModelProviderServiceConfigMicrosoftFoundry): void;
    resetMicrosoftFoundry(): void;
    get microsoftFoundryInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigMicrosoftFoundry | undefined;
    private _openai;
    get openai(): AiGatewayModelProviderServiceConfigOpenaiOutputReference;
    putOpenai(value: AiGatewayModelProviderServiceConfigOpenai): void;
    resetOpenai(): void;
    get openaiInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigOpenai | undefined;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    resetProviderType(): void;
    get providerTypeInput(): string | undefined;
    private _rateLimits;
    get rateLimits(): AiGatewayModelProviderServiceConfigRateLimitsList;
    putRateLimits(value: AiGatewayModelProviderServiceConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigRateLimits[] | undefined;
    private _targets;
    get targets(): AiGatewayModelProviderServiceConfigTargetsList;
    putTargets(value: AiGatewayModelProviderServiceConfigTargets[] | cdktn.IResolvable): void;
    resetTargets(): void;
    get targetsInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigTargets[] | undefined;
}
export interface AiGatewayModelProviderServiceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#workspace_id AiGatewayModelProviderService#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function aiGatewayModelProviderServiceProviderConfigToTerraform(struct?: AiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable): any;
export declare function aiGatewayModelProviderServiceProviderConfigToHclTerraform(struct?: AiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable): any;
export declare class AiGatewayModelProviderServiceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayModelProviderServiceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service databricks_ai_gateway_model_provider_service}
*/
export declare class AiGatewayModelProviderService extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_ai_gateway_model_provider_service";
    /**
    * Generates CDKTN code for importing a AiGatewayModelProviderService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiGatewayModelProviderService to import
    * @param importFromId The id of the existing AiGatewayModelProviderService that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiGatewayModelProviderService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_model_provider_service databricks_ai_gateway_model_provider_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiGatewayModelProviderServiceConfig
    */
    constructor(scope: Construct, id: string, config: AiGatewayModelProviderServiceConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _config;
    get config(): AiGatewayModelProviderServiceConfigAOutputReference;
    putConfig(value: AiGatewayModelProviderServiceConfigA): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | AiGatewayModelProviderServiceConfigA | undefined;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _modelProviderServiceId?;
    get modelProviderServiceId(): string;
    set modelProviderServiceId(value: string);
    get modelProviderServiceIdInput(): string | undefined;
    get name(): string;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AiGatewayModelProviderServiceProviderConfigOutputReference;
    putProviderConfig(value: AiGatewayModelProviderServiceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AiGatewayModelProviderServiceProviderConfig | undefined;
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
