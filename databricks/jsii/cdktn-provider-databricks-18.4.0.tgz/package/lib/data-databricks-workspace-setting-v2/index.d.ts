/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceSettingV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#name DataDatabricksWorkspaceSettingV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#provider_config DataDatabricksWorkspaceSettingV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceSettingV2ProviderConfig;
}
export interface DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#access_policy_type DataDatabricksWorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#approved_domains DataDatabricksWorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#allowed_scopes DataDatabricksWorkspaceSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes): any;
export declare function dataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes): any;
export declare class DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#forced_for_compliance_mode DataDatabricksWorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#unavailable_for_disabled_entitlement DataDatabricksWorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksWorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#hours DataDatabricksWorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#minutes DataDatabricksWorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#day_of_week DataDatabricksWorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#frequency DataDatabricksWorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#window_start_time DataDatabricksWorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#week_day_based_schedule DataDatabricksWorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#can_toggle DataDatabricksWorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#enabled DataDatabricksWorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#enablement_details DataDatabricksWorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#maintenance_window DataDatabricksWorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#restart_even_if_no_updates_available DataDatabricksWorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2BooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2BooleanValToTerraform(struct?: DataDatabricksWorkspaceSettingV2BooleanVal): any;
export declare function dataDatabricksWorkspaceSettingV2BooleanValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2BooleanVal): any;
export declare class DataDatabricksWorkspaceSettingV2BooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2BooleanVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2BooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#connectivity DataDatabricksWorkspaceSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity): any;
export declare function dataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity): any;
export declare class DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#access_policy_type DataDatabricksWorkspaceSettingV2#access_policy_type}
    */
    readonly accessPolicyType: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicy | undefined);
    private _accessPolicyType?;
    get accessPolicyType(): string;
    set accessPolicyType(value: string);
    get accessPolicyTypeInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#approved_domains DataDatabricksWorkspaceSettingV2#approved_domains}
    */
    readonly approvedDomains?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomains | undefined);
    private _approvedDomains?;
    get approvedDomains(): string[];
    set approvedDomains(value: string[]);
    resetApprovedDomains(): void;
    get approvedDomainsInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#allowed_scopes DataDatabricksWorkspaceSettingV2#allowed_scopes}
    */
    readonly allowedScopes?: string[];
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopes | undefined);
    private _allowedScopes?;
    get allowedScopes(): string[];
    set allowedScopes(value: string[]);
    resetAllowedScopes(): void;
    get allowedScopesInput(): string[] | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#forced_for_compliance_mode DataDatabricksWorkspaceSettingV2#forced_for_compliance_mode}
    */
    readonly forcedForComplianceMode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#unavailable_for_disabled_entitlement DataDatabricksWorkspaceSettingV2#unavailable_for_disabled_entitlement}
    */
    readonly unavailableForDisabledEntitlement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#unavailable_for_non_enterprise_tier DataDatabricksWorkspaceSettingV2#unavailable_for_non_enterprise_tier}
    */
    readonly unavailableForNonEnterpriseTier?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | cdktn.IResolvable | undefined);
    private _forcedForComplianceMode?;
    get forcedForComplianceMode(): boolean | cdktn.IResolvable;
    set forcedForComplianceMode(value: boolean | cdktn.IResolvable);
    resetForcedForComplianceMode(): void;
    get forcedForComplianceModeInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForDisabledEntitlement?;
    get unavailableForDisabledEntitlement(): boolean | cdktn.IResolvable;
    set unavailableForDisabledEntitlement(value: boolean | cdktn.IResolvable);
    resetUnavailableForDisabledEntitlement(): void;
    get unavailableForDisabledEntitlementInput(): boolean | cdktn.IResolvable | undefined;
    private _unavailableForNonEnterpriseTier?;
    get unavailableForNonEnterpriseTier(): boolean | cdktn.IResolvable;
    set unavailableForNonEnterpriseTier(value: boolean | cdktn.IResolvable);
    resetUnavailableForNonEnterpriseTier(): void;
    get unavailableForNonEnterpriseTierInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#hours DataDatabricksWorkspaceSettingV2#hours}
    */
    readonly hours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#minutes DataDatabricksWorkspaceSettingV2#minutes}
    */
    readonly minutes?: number;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | cdktn.IResolvable | undefined);
    private _hours?;
    get hours(): number;
    set hours(value: number);
    resetHours(): void;
    get hoursInput(): number | undefined;
    private _minutes?;
    get minutes(): number;
    set minutes(value: number);
    resetMinutes(): void;
    get minutesInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#day_of_week DataDatabricksWorkspaceSettingV2#day_of_week}
    */
    readonly dayOfWeek?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#frequency DataDatabricksWorkspaceSettingV2#frequency}
    */
    readonly frequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#window_start_time DataDatabricksWorkspaceSettingV2#window_start_time}
    */
    readonly windowStartTime?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | cdktn.IResolvable | undefined);
    private _dayOfWeek?;
    get dayOfWeek(): string;
    set dayOfWeek(value: string);
    resetDayOfWeek(): void;
    get dayOfWeekInput(): string | undefined;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    resetFrequency(): void;
    get frequencyInput(): string | undefined;
    private _windowStartTime;
    get windowStartTime(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTimeOutputReference;
    putWindowStartTime(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime): void;
    resetWindowStartTime(): void;
    get windowStartTimeInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleWindowStartTime | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#week_day_based_schedule DataDatabricksWorkspaceSettingV2#week_day_based_schedule}
    */
    readonly weekDayBasedSchedule?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | cdktn.IResolvable | undefined);
    private _weekDayBasedSchedule;
    get weekDayBasedSchedule(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedScheduleOutputReference;
    putWeekDayBasedSchedule(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule): void;
    resetWeekDayBasedSchedule(): void;
    get weekDayBasedScheduleInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowWeekDayBasedSchedule | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#can_toggle DataDatabricksWorkspaceSettingV2#can_toggle}
    */
    readonly canToggle?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#enabled DataDatabricksWorkspaceSettingV2#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#enablement_details DataDatabricksWorkspaceSettingV2#enablement_details}
    */
    readonly enablementDetails?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#maintenance_window DataDatabricksWorkspaceSettingV2#maintenance_window}
    */
    readonly maintenanceWindow?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#restart_even_if_no_updates_available DataDatabricksWorkspaceSettingV2#restart_even_if_no_updates_available}
    */
    readonly restartEvenIfNoUpdatesAvailable?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspace | undefined);
    private _canToggle?;
    get canToggle(): boolean | cdktn.IResolvable;
    set canToggle(value: boolean | cdktn.IResolvable);
    resetCanToggle(): void;
    get canToggleInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _enablementDetails;
    get enablementDetails(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetailsOutputReference;
    putEnablementDetails(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails): void;
    resetEnablementDetails(): void;
    get enablementDetailsInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceEnablementDetails | undefined;
    private _maintenanceWindow;
    get maintenanceWindow(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindowOutputReference;
    putMaintenanceWindow(value: DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow): void;
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceMaintenanceWindow | undefined;
    private _restartEvenIfNoUpdatesAvailable?;
    get restartEvenIfNoUpdatesAvailable(): boolean | cdktn.IResolvable;
    set restartEvenIfNoUpdatesAvailable(value: boolean | cdktn.IResolvable);
    resetRestartEvenIfNoUpdatesAvailable(): void;
    get restartEvenIfNoUpdatesAvailableInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveBooleanVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveBooleanValToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveBooleanVal): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveBooleanValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveBooleanVal): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveBooleanValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveBooleanVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveBooleanVal | undefined);
    private _value?;
    get value(): boolean | cdktn.IResolvable;
    set value(value: boolean | cdktn.IResolvable);
    resetValue(): void;
    get valueInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#connectivity DataDatabricksWorkspaceSettingV2#connectivity}
    */
    readonly connectivity: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivity | undefined);
    private _connectivity?;
    get connectivity(): string;
    set connectivity(value: string);
    get connectivityInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveIntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveIntegerValToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveIntegerVal): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveIntegerValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveIntegerVal): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveIntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveIntegerVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveIntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#email DataDatabricksWorkspaceSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectivePersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectivePersonalComputeToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectivePersonalCompute): any;
export declare function dataDatabricksWorkspaceSettingV2EffectivePersonalComputeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectivePersonalCompute): any;
export declare class DataDatabricksWorkspaceSettingV2EffectivePersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectivePersonalCompute | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectivePersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#disable_gov_tag_creation DataDatabricksWorkspaceSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#status DataDatabricksWorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2EffectiveStringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2EffectiveStringValToTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveStringVal): any;
export declare function dataDatabricksWorkspaceSettingV2EffectiveStringValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2EffectiveStringVal): any;
export declare class DataDatabricksWorkspaceSettingV2EffectiveStringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2EffectiveStringVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2EffectiveStringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2IntegerVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: number;
}
export declare function dataDatabricksWorkspaceSettingV2IntegerValToTerraform(struct?: DataDatabricksWorkspaceSettingV2IntegerVal): any;
export declare function dataDatabricksWorkspaceSettingV2IntegerValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2IntegerVal): any;
export declare class DataDatabricksWorkspaceSettingV2IntegerValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2IntegerVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2IntegerVal | undefined);
    private _value?;
    get value(): number;
    set value(value: number);
    resetValue(): void;
    get valueInput(): number | undefined;
}
export interface DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#email DataDatabricksWorkspaceSettingV2#email}
    */
    readonly email?: string;
}
export declare function dataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientToTerraform(struct?: DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient): any;
export declare function dataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient): any;
export declare class DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipient | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    resetEmail(): void;
    get emailInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2PersonalCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2PersonalComputeToTerraform(struct?: DataDatabricksWorkspaceSettingV2PersonalCompute): any;
export declare function dataDatabricksWorkspaceSettingV2PersonalComputeToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2PersonalCompute): any;
export declare class DataDatabricksWorkspaceSettingV2PersonalComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2PersonalCompute | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2PersonalCompute | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#workspace_id DataDatabricksWorkspaceSettingV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceSettingV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceSettingV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceSettingV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#disable_gov_tag_creation DataDatabricksWorkspaceSettingV2#disable_gov_tag_creation}
    */
    readonly disableGovTagCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#status DataDatabricksWorkspaceSettingV2#status}
    */
    readonly status: string;
}
export declare function dataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsToTerraform(struct?: DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins): any;
export declare function dataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins): any;
export declare class DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdmins | undefined);
    private _disableGovTagCreation?;
    get disableGovTagCreation(): boolean | cdktn.IResolvable;
    set disableGovTagCreation(value: boolean | cdktn.IResolvable);
    resetDisableGovTagCreation(): void;
    get disableGovTagCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
}
export interface DataDatabricksWorkspaceSettingV2StringVal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#value DataDatabricksWorkspaceSettingV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksWorkspaceSettingV2StringValToTerraform(struct?: DataDatabricksWorkspaceSettingV2StringVal): any;
export declare function dataDatabricksWorkspaceSettingV2StringValToHclTerraform(struct?: DataDatabricksWorkspaceSettingV2StringVal): any;
export declare class DataDatabricksWorkspaceSettingV2StringValOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceSettingV2StringVal | undefined;
    set internalValue(value: DataDatabricksWorkspaceSettingV2StringVal | undefined);
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2 databricks_workspace_setting_v2}
*/
export declare class DataDatabricksWorkspaceSettingV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_setting_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceSettingV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceSettingV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceSettingV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceSettingV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_setting_v2 databricks_workspace_setting_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceSettingV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceSettingV2Config);
    private _aibiDashboardEmbeddingAccessPolicy;
    get aibiDashboardEmbeddingAccessPolicy(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingAccessPolicyOutputReference;
    private _aibiDashboardEmbeddingApprovedDomains;
    get aibiDashboardEmbeddingApprovedDomains(): DataDatabricksWorkspaceSettingV2AibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _allowedAppsUserApiScopes;
    get allowedAppsUserApiScopes(): DataDatabricksWorkspaceSettingV2AllowedAppsUserApiScopesOutputReference;
    private _automaticClusterUpdateWorkspace;
    get automaticClusterUpdateWorkspace(): DataDatabricksWorkspaceSettingV2AutomaticClusterUpdateWorkspaceOutputReference;
    private _booleanVal;
    get booleanVal(): DataDatabricksWorkspaceSettingV2BooleanValOutputReference;
    private _collaborationPlatformConnectivity;
    get collaborationPlatformConnectivity(): DataDatabricksWorkspaceSettingV2CollaborationPlatformConnectivityOutputReference;
    private _effectiveAibiDashboardEmbeddingAccessPolicy;
    get effectiveAibiDashboardEmbeddingAccessPolicy(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingAccessPolicyOutputReference;
    private _effectiveAibiDashboardEmbeddingApprovedDomains;
    get effectiveAibiDashboardEmbeddingApprovedDomains(): DataDatabricksWorkspaceSettingV2EffectiveAibiDashboardEmbeddingApprovedDomainsOutputReference;
    private _effectiveAllowedAppsUserApiScopes;
    get effectiveAllowedAppsUserApiScopes(): DataDatabricksWorkspaceSettingV2EffectiveAllowedAppsUserApiScopesOutputReference;
    private _effectiveAutomaticClusterUpdateWorkspace;
    get effectiveAutomaticClusterUpdateWorkspace(): DataDatabricksWorkspaceSettingV2EffectiveAutomaticClusterUpdateWorkspaceOutputReference;
    private _effectiveBooleanVal;
    get effectiveBooleanVal(): DataDatabricksWorkspaceSettingV2EffectiveBooleanValOutputReference;
    private _effectiveCollaborationPlatformConnectivity;
    get effectiveCollaborationPlatformConnectivity(): DataDatabricksWorkspaceSettingV2EffectiveCollaborationPlatformConnectivityOutputReference;
    private _effectiveIntegerVal;
    get effectiveIntegerVal(): DataDatabricksWorkspaceSettingV2EffectiveIntegerValOutputReference;
    private _effectiveOperationalEmailCustomRecipient;
    get effectiveOperationalEmailCustomRecipient(): DataDatabricksWorkspaceSettingV2EffectiveOperationalEmailCustomRecipientOutputReference;
    private _effectivePersonalCompute;
    get effectivePersonalCompute(): DataDatabricksWorkspaceSettingV2EffectivePersonalComputeOutputReference;
    private _effectiveRestrictWorkspaceAdmins;
    get effectiveRestrictWorkspaceAdmins(): DataDatabricksWorkspaceSettingV2EffectiveRestrictWorkspaceAdminsOutputReference;
    private _effectiveStringVal;
    get effectiveStringVal(): DataDatabricksWorkspaceSettingV2EffectiveStringValOutputReference;
    private _integerVal;
    get integerVal(): DataDatabricksWorkspaceSettingV2IntegerValOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operationalEmailCustomRecipient;
    get operationalEmailCustomRecipient(): DataDatabricksWorkspaceSettingV2OperationalEmailCustomRecipientOutputReference;
    private _personalCompute;
    get personalCompute(): DataDatabricksWorkspaceSettingV2PersonalComputeOutputReference;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceSettingV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceSettingV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceSettingV2ProviderConfig | undefined;
    private _restrictWorkspaceAdmins;
    get restrictWorkspaceAdmins(): DataDatabricksWorkspaceSettingV2RestrictWorkspaceAdminsOutputReference;
    private _stringVal;
    get stringVal(): DataDatabricksWorkspaceSettingV2StringValOutputReference;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
