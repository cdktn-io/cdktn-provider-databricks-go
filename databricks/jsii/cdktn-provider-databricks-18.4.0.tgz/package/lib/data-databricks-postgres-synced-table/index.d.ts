/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresSyncedTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#name DataDatabricksPostgresSyncedTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#provider_config DataDatabricksPostgresSyncedTable#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresSyncedTableProviderConfig;
}
export interface DataDatabricksPostgresSyncedTableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#workspace_id DataDatabricksPostgresSyncedTable#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresSyncedTableProviderConfigToTerraform(struct?: DataDatabricksPostgresSyncedTableProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSyncedTableProviderConfigToHclTerraform(struct?: DataDatabricksPostgresSyncedTableProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSyncedTableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSyncedTableProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresSyncedTableSpecExtraColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#column_name DataDatabricksPostgresSyncedTable#column_name}
    */
    readonly columnName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#column_type DataDatabricksPostgresSyncedTable#column_type}
    */
    readonly columnType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#compute DataDatabricksPostgresSyncedTable#compute}
    */
    readonly compute?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#maintenance DataDatabricksPostgresSyncedTable#maintenance}
    */
    readonly maintenance?: string;
}
export declare function dataDatabricksPostgresSyncedTableSpecExtraColumnsToTerraform(struct?: DataDatabricksPostgresSyncedTableSpecExtraColumns | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSyncedTableSpecExtraColumnsToHclTerraform(struct?: DataDatabricksPostgresSyncedTableSpecExtraColumns | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSyncedTableSpecExtraColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresSyncedTableSpecExtraColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableSpecExtraColumns | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    get columnNameInput(): string | undefined;
    private _columnType?;
    get columnType(): string;
    set columnType(value: string);
    get columnTypeInput(): string | undefined;
    private _compute?;
    get compute(): string;
    set compute(value: string);
    resetCompute(): void;
    get computeInput(): string | undefined;
    private _maintenance?;
    get maintenance(): string;
    set maintenance(value: string);
    resetMaintenance(): void;
    get maintenanceInput(): string | undefined;
}
export declare class DataDatabricksPostgresSyncedTableSpecExtraColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresSyncedTableSpecExtraColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresSyncedTableSpecExtraColumnsOutputReference;
}
export interface DataDatabricksPostgresSyncedTableSpecNewPipelineSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#budget_policy_id DataDatabricksPostgresSyncedTable#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#pipeline_channel DataDatabricksPostgresSyncedTable#pipeline_channel}
    */
    readonly pipelineChannel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#storage_catalog DataDatabricksPostgresSyncedTable#storage_catalog}
    */
    readonly storageCatalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#storage_schema DataDatabricksPostgresSyncedTable#storage_schema}
    */
    readonly storageSchema?: string;
}
export declare function dataDatabricksPostgresSyncedTableSpecNewPipelineSpecToTerraform(struct?: DataDatabricksPostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSyncedTableSpecNewPipelineSpecToHclTerraform(struct?: DataDatabricksPostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSyncedTableSpecNewPipelineSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableSpecNewPipelineSpec | cdktn.IResolvable | undefined);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _pipelineChannel?;
    get pipelineChannel(): string;
    set pipelineChannel(value: string);
    resetPipelineChannel(): void;
    get pipelineChannelInput(): string | undefined;
    private _storageCatalog?;
    get storageCatalog(): string;
    set storageCatalog(value: string);
    resetStorageCatalog(): void;
    get storageCatalogInput(): string | undefined;
    private _storageSchema?;
    get storageSchema(): string;
    set storageSchema(value: string);
    resetStorageSchema(): void;
    get storageSchemaInput(): string | undefined;
}
export interface DataDatabricksPostgresSyncedTableSpecTypeOverrides {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#column_name DataDatabricksPostgresSyncedTable#column_name}
    */
    readonly columnName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#pg_type DataDatabricksPostgresSyncedTable#pg_type}
    */
    readonly pgType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#size DataDatabricksPostgresSyncedTable#size}
    */
    readonly size?: number;
}
export declare function dataDatabricksPostgresSyncedTableSpecTypeOverridesToTerraform(struct?: DataDatabricksPostgresSyncedTableSpecTypeOverrides | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresSyncedTableSpecTypeOverridesToHclTerraform(struct?: DataDatabricksPostgresSyncedTableSpecTypeOverrides | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresSyncedTableSpecTypeOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresSyncedTableSpecTypeOverrides | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableSpecTypeOverrides | cdktn.IResolvable | undefined);
    private _columnName?;
    get columnName(): string;
    set columnName(value: string);
    get columnNameInput(): string | undefined;
    private _pgType?;
    get pgType(): string;
    set pgType(value: string);
    get pgTypeInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
export declare class DataDatabricksPostgresSyncedTableSpecTypeOverridesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresSyncedTableSpecTypeOverrides[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresSyncedTableSpecTypeOverridesOutputReference;
}
export interface DataDatabricksPostgresSyncedTableSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#accelerated_sync DataDatabricksPostgresSyncedTable#accelerated_sync}
    */
    readonly acceleratedSync?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#branch DataDatabricksPostgresSyncedTable#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#create_database_objects_if_missing DataDatabricksPostgresSyncedTable#create_database_objects_if_missing}
    */
    readonly createDatabaseObjectsIfMissing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#existing_pipeline_id DataDatabricksPostgresSyncedTable#existing_pipeline_id}
    */
    readonly existingPipelineId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#extra_columns DataDatabricksPostgresSyncedTable#extra_columns}
    */
    readonly extraColumns?: DataDatabricksPostgresSyncedTableSpecExtraColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#new_pipeline_spec DataDatabricksPostgresSyncedTable#new_pipeline_spec}
    */
    readonly newPipelineSpec?: DataDatabricksPostgresSyncedTableSpecNewPipelineSpec;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#postgres_database DataDatabricksPostgresSyncedTable#postgres_database}
    */
    readonly postgresDatabase?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#primary_key_columns DataDatabricksPostgresSyncedTable#primary_key_columns}
    */
    readonly primaryKeyColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#scheduling_policy DataDatabricksPostgresSyncedTable#scheduling_policy}
    */
    readonly schedulingPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#source_table_full_name DataDatabricksPostgresSyncedTable#source_table_full_name}
    */
    readonly sourceTableFullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#timeseries_key DataDatabricksPostgresSyncedTable#timeseries_key}
    */
    readonly timeseriesKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#type_overrides DataDatabricksPostgresSyncedTable#type_overrides}
    */
    readonly typeOverrides?: DataDatabricksPostgresSyncedTableSpecTypeOverrides[] | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresSyncedTableSpecToTerraform(struct?: DataDatabricksPostgresSyncedTableSpec): any;
export declare function dataDatabricksPostgresSyncedTableSpecToHclTerraform(struct?: DataDatabricksPostgresSyncedTableSpec): any;
export declare class DataDatabricksPostgresSyncedTableSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSyncedTableSpec | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableSpec | undefined);
    private _acceleratedSync?;
    get acceleratedSync(): boolean | cdktn.IResolvable;
    set acceleratedSync(value: boolean | cdktn.IResolvable);
    resetAcceleratedSync(): void;
    get acceleratedSyncInput(): boolean | cdktn.IResolvable | undefined;
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _createDatabaseObjectsIfMissing?;
    get createDatabaseObjectsIfMissing(): boolean | cdktn.IResolvable;
    set createDatabaseObjectsIfMissing(value: boolean | cdktn.IResolvable);
    resetCreateDatabaseObjectsIfMissing(): void;
    get createDatabaseObjectsIfMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _existingPipelineId?;
    get existingPipelineId(): string;
    set existingPipelineId(value: string);
    resetExistingPipelineId(): void;
    get existingPipelineIdInput(): string | undefined;
    private _extraColumns;
    get extraColumns(): DataDatabricksPostgresSyncedTableSpecExtraColumnsList;
    putExtraColumns(value: DataDatabricksPostgresSyncedTableSpecExtraColumns[] | cdktn.IResolvable): void;
    resetExtraColumns(): void;
    get extraColumnsInput(): cdktn.IResolvable | DataDatabricksPostgresSyncedTableSpecExtraColumns[] | undefined;
    private _newPipelineSpec;
    get newPipelineSpec(): DataDatabricksPostgresSyncedTableSpecNewPipelineSpecOutputReference;
    putNewPipelineSpec(value: DataDatabricksPostgresSyncedTableSpecNewPipelineSpec): void;
    resetNewPipelineSpec(): void;
    get newPipelineSpecInput(): cdktn.IResolvable | DataDatabricksPostgresSyncedTableSpecNewPipelineSpec | undefined;
    private _postgresDatabase?;
    get postgresDatabase(): string;
    set postgresDatabase(value: string);
    resetPostgresDatabase(): void;
    get postgresDatabaseInput(): string | undefined;
    private _primaryKeyColumns?;
    get primaryKeyColumns(): string[];
    set primaryKeyColumns(value: string[]);
    resetPrimaryKeyColumns(): void;
    get primaryKeyColumnsInput(): string[] | undefined;
    private _schedulingPolicy?;
    get schedulingPolicy(): string;
    set schedulingPolicy(value: string);
    resetSchedulingPolicy(): void;
    get schedulingPolicyInput(): string | undefined;
    private _sourceTableFullName?;
    get sourceTableFullName(): string;
    set sourceTableFullName(value: string);
    resetSourceTableFullName(): void;
    get sourceTableFullNameInput(): string | undefined;
    private _timeseriesKey?;
    get timeseriesKey(): string;
    set timeseriesKey(value: string);
    resetTimeseriesKey(): void;
    get timeseriesKeyInput(): string | undefined;
    private _typeOverrides;
    get typeOverrides(): DataDatabricksPostgresSyncedTableSpecTypeOverridesList;
    putTypeOverrides(value: DataDatabricksPostgresSyncedTableSpecTypeOverrides[] | cdktn.IResolvable): void;
    resetTypeOverrides(): void;
    get typeOverridesInput(): cdktn.IResolvable | DataDatabricksPostgresSyncedTableSpecTypeOverrides[] | undefined;
}
export interface DataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfo {
}
export declare function dataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfoToTerraform(struct?: DataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfo): any;
export declare function dataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfoToHclTerraform(struct?: DataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfo): any;
export declare class DataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfo | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfo | undefined);
    get deltaCommitTime(): string;
    get deltaCommitVersion(): number;
}
export interface DataDatabricksPostgresSyncedTableStatusLastSync {
}
export declare function dataDatabricksPostgresSyncedTableStatusLastSyncToTerraform(struct?: DataDatabricksPostgresSyncedTableStatusLastSync): any;
export declare function dataDatabricksPostgresSyncedTableStatusLastSyncToHclTerraform(struct?: DataDatabricksPostgresSyncedTableStatusLastSync): any;
export declare class DataDatabricksPostgresSyncedTableStatusLastSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSyncedTableStatusLastSync | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableStatusLastSync | undefined);
    private _deltaTableSyncInfo;
    get deltaTableSyncInfo(): DataDatabricksPostgresSyncedTableStatusLastSyncDeltaTableSyncInfoOutputReference;
    get syncEndTime(): string;
    get syncStartTime(): string;
}
export interface DataDatabricksPostgresSyncedTableStatusOngoingSyncProgress {
}
export declare function dataDatabricksPostgresSyncedTableStatusOngoingSyncProgressToTerraform(struct?: DataDatabricksPostgresSyncedTableStatusOngoingSyncProgress): any;
export declare function dataDatabricksPostgresSyncedTableStatusOngoingSyncProgressToHclTerraform(struct?: DataDatabricksPostgresSyncedTableStatusOngoingSyncProgress): any;
export declare class DataDatabricksPostgresSyncedTableStatusOngoingSyncProgressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSyncedTableStatusOngoingSyncProgress | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableStatusOngoingSyncProgress | undefined);
    get estimatedCompletionTimeSeconds(): number;
    get latestVersionCurrentlyProcessing(): number;
    get syncProgressCompletion(): number;
    get syncedRowCount(): number;
    get totalRowCount(): number;
}
export interface DataDatabricksPostgresSyncedTableStatus {
}
export declare function dataDatabricksPostgresSyncedTableStatusToTerraform(struct?: DataDatabricksPostgresSyncedTableStatus): any;
export declare function dataDatabricksPostgresSyncedTableStatusToHclTerraform(struct?: DataDatabricksPostgresSyncedTableStatus): any;
export declare class DataDatabricksPostgresSyncedTableStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresSyncedTableStatus | undefined;
    set internalValue(value: DataDatabricksPostgresSyncedTableStatus | undefined);
    get detailedState(): string;
    get lastProcessedCommitVersion(): number;
    private _lastSync;
    get lastSync(): DataDatabricksPostgresSyncedTableStatusLastSyncOutputReference;
    get lastSyncTime(): string;
    get message(): string;
    private _ongoingSyncProgress;
    get ongoingSyncProgress(): DataDatabricksPostgresSyncedTableStatusOngoingSyncProgressOutputReference;
    get pipelineId(): string;
    get project(): string;
    get provisioningPhase(): string;
    get unityCatalogProvisioningState(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table databricks_postgres_synced_table}
*/
export declare class DataDatabricksPostgresSyncedTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_synced_table";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresSyncedTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresSyncedTable to import
    * @param importFromId The id of the existing DataDatabricksPostgresSyncedTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresSyncedTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/postgres_synced_table databricks_postgres_synced_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresSyncedTableConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresSyncedTableConfig);
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresSyncedTableProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresSyncedTableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresSyncedTableProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksPostgresSyncedTableSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresSyncedTableStatusOutputReference;
    get syncedTableId(): string;
    get uid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
