/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ExternalLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#comment ExternalLocation#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#credential_name ExternalLocation#credential_name}
    */
    readonly credentialName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#enable_file_events ExternalLocation#enable_file_events}
    */
    readonly enableFileEvents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#fallback ExternalLocation#fallback}
    */
    readonly fallback?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#force_destroy ExternalLocation#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#force_update ExternalLocation#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#id ExternalLocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#isolation_mode ExternalLocation#isolation_mode}
    */
    readonly isolationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#metastore_id ExternalLocation#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#name ExternalLocation#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#owner ExternalLocation#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#read_only ExternalLocation#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#skip_validation ExternalLocation#skip_validation}
    */
    readonly skipValidation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#url ExternalLocation#url}
    */
    readonly url: string;
    /**
    * effective_file_event_queue block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#effective_file_event_queue ExternalLocation#effective_file_event_queue}
    */
    readonly effectiveFileEventQueue?: ExternalLocationEffectiveFileEventQueue;
    /**
    * encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#encryption_details ExternalLocation#encryption_details}
    */
    readonly encryptionDetails?: ExternalLocationEncryptionDetails;
    /**
    * file_event_queue block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#file_event_queue ExternalLocation#file_event_queue}
    */
    readonly fileEventQueue?: ExternalLocationFileEventQueue;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#provider_config ExternalLocation#provider_config}
    */
    readonly providerConfig?: ExternalLocationProviderConfig;
}
export interface ExternalLocationEffectiveFileEventQueueManagedAqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_resource_id ExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#resource_group ExternalLocation#resource_group}
    */
    readonly resourceGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_id ExternalLocation#subscription_id}
    */
    readonly subscriptionId?: string;
}
export declare function externalLocationEffectiveFileEventQueueManagedAqsToTerraform(struct?: ExternalLocationEffectiveFileEventQueueManagedAqsOutputReference | ExternalLocationEffectiveFileEventQueueManagedAqs): any;
export declare function externalLocationEffectiveFileEventQueueManagedAqsToHclTerraform(struct?: ExternalLocationEffectiveFileEventQueueManagedAqsOutputReference | ExternalLocationEffectiveFileEventQueueManagedAqs): any;
export declare class ExternalLocationEffectiveFileEventQueueManagedAqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEffectiveFileEventQueueManagedAqs | undefined;
    set internalValue(value: ExternalLocationEffectiveFileEventQueueManagedAqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    resetResourceGroup(): void;
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
}
export interface ExternalLocationEffectiveFileEventQueueManagedPubsub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_resource_id ExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_name ExternalLocation#subscription_name}
    */
    readonly subscriptionName?: string;
}
export declare function externalLocationEffectiveFileEventQueueManagedPubsubToTerraform(struct?: ExternalLocationEffectiveFileEventQueueManagedPubsubOutputReference | ExternalLocationEffectiveFileEventQueueManagedPubsub): any;
export declare function externalLocationEffectiveFileEventQueueManagedPubsubToHclTerraform(struct?: ExternalLocationEffectiveFileEventQueueManagedPubsubOutputReference | ExternalLocationEffectiveFileEventQueueManagedPubsub): any;
export declare class ExternalLocationEffectiveFileEventQueueManagedPubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEffectiveFileEventQueueManagedPubsub | undefined;
    set internalValue(value: ExternalLocationEffectiveFileEventQueueManagedPubsub | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _subscriptionName?;
    get subscriptionName(): string;
    set subscriptionName(value: string);
    resetSubscriptionName(): void;
    get subscriptionNameInput(): string | undefined;
}
export interface ExternalLocationEffectiveFileEventQueueManagedSqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_resource_id ExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
}
export declare function externalLocationEffectiveFileEventQueueManagedSqsToTerraform(struct?: ExternalLocationEffectiveFileEventQueueManagedSqsOutputReference | ExternalLocationEffectiveFileEventQueueManagedSqs): any;
export declare function externalLocationEffectiveFileEventQueueManagedSqsToHclTerraform(struct?: ExternalLocationEffectiveFileEventQueueManagedSqsOutputReference | ExternalLocationEffectiveFileEventQueueManagedSqs): any;
export declare class ExternalLocationEffectiveFileEventQueueManagedSqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEffectiveFileEventQueueManagedSqs | undefined;
    set internalValue(value: ExternalLocationEffectiveFileEventQueueManagedSqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
}
export interface ExternalLocationEffectiveFileEventQueueProvidedAqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_resource_id ExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#resource_group ExternalLocation#resource_group}
    */
    readonly resourceGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_id ExternalLocation#subscription_id}
    */
    readonly subscriptionId?: string;
}
export declare function externalLocationEffectiveFileEventQueueProvidedAqsToTerraform(struct?: ExternalLocationEffectiveFileEventQueueProvidedAqsOutputReference | ExternalLocationEffectiveFileEventQueueProvidedAqs): any;
export declare function externalLocationEffectiveFileEventQueueProvidedAqsToHclTerraform(struct?: ExternalLocationEffectiveFileEventQueueProvidedAqsOutputReference | ExternalLocationEffectiveFileEventQueueProvidedAqs): any;
export declare class ExternalLocationEffectiveFileEventQueueProvidedAqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEffectiveFileEventQueueProvidedAqs | undefined;
    set internalValue(value: ExternalLocationEffectiveFileEventQueueProvidedAqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    resetResourceGroup(): void;
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
}
export interface ExternalLocationEffectiveFileEventQueueProvidedPubsub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_resource_id ExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_name ExternalLocation#subscription_name}
    */
    readonly subscriptionName?: string;
}
export declare function externalLocationEffectiveFileEventQueueProvidedPubsubToTerraform(struct?: ExternalLocationEffectiveFileEventQueueProvidedPubsubOutputReference | ExternalLocationEffectiveFileEventQueueProvidedPubsub): any;
export declare function externalLocationEffectiveFileEventQueueProvidedPubsubToHclTerraform(struct?: ExternalLocationEffectiveFileEventQueueProvidedPubsubOutputReference | ExternalLocationEffectiveFileEventQueueProvidedPubsub): any;
export declare class ExternalLocationEffectiveFileEventQueueProvidedPubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEffectiveFileEventQueueProvidedPubsub | undefined;
    set internalValue(value: ExternalLocationEffectiveFileEventQueueProvidedPubsub | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _subscriptionName?;
    get subscriptionName(): string;
    set subscriptionName(value: string);
    resetSubscriptionName(): void;
    get subscriptionNameInput(): string | undefined;
}
export interface ExternalLocationEffectiveFileEventQueueProvidedSqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_resource_id ExternalLocation#managed_resource_id}
    */
    readonly managedResourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
}
export declare function externalLocationEffectiveFileEventQueueProvidedSqsToTerraform(struct?: ExternalLocationEffectiveFileEventQueueProvidedSqsOutputReference | ExternalLocationEffectiveFileEventQueueProvidedSqs): any;
export declare function externalLocationEffectiveFileEventQueueProvidedSqsToHclTerraform(struct?: ExternalLocationEffectiveFileEventQueueProvidedSqsOutputReference | ExternalLocationEffectiveFileEventQueueProvidedSqs): any;
export declare class ExternalLocationEffectiveFileEventQueueProvidedSqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEffectiveFileEventQueueProvidedSqs | undefined;
    set internalValue(value: ExternalLocationEffectiveFileEventQueueProvidedSqs | undefined);
    private _managedResourceId?;
    get managedResourceId(): string;
    set managedResourceId(value: string);
    resetManagedResourceId(): void;
    get managedResourceIdInput(): string | undefined;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
}
export interface ExternalLocationEffectiveFileEventQueue {
    /**
    * managed_aqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_aqs ExternalLocation#managed_aqs}
    */
    readonly managedAqs?: ExternalLocationEffectiveFileEventQueueManagedAqs;
    /**
    * managed_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_pubsub ExternalLocation#managed_pubsub}
    */
    readonly managedPubsub?: ExternalLocationEffectiveFileEventQueueManagedPubsub;
    /**
    * managed_sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_sqs ExternalLocation#managed_sqs}
    */
    readonly managedSqs?: ExternalLocationEffectiveFileEventQueueManagedSqs;
    /**
    * provided_aqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#provided_aqs ExternalLocation#provided_aqs}
    */
    readonly providedAqs?: ExternalLocationEffectiveFileEventQueueProvidedAqs;
    /**
    * provided_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#provided_pubsub ExternalLocation#provided_pubsub}
    */
    readonly providedPubsub?: ExternalLocationEffectiveFileEventQueueProvidedPubsub;
    /**
    * provided_sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#provided_sqs ExternalLocation#provided_sqs}
    */
    readonly providedSqs?: ExternalLocationEffectiveFileEventQueueProvidedSqs;
}
export declare function externalLocationEffectiveFileEventQueueToTerraform(struct?: ExternalLocationEffectiveFileEventQueueOutputReference | ExternalLocationEffectiveFileEventQueue): any;
export declare function externalLocationEffectiveFileEventQueueToHclTerraform(struct?: ExternalLocationEffectiveFileEventQueueOutputReference | ExternalLocationEffectiveFileEventQueue): any;
export declare class ExternalLocationEffectiveFileEventQueueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEffectiveFileEventQueue | undefined;
    set internalValue(value: ExternalLocationEffectiveFileEventQueue | undefined);
    private _managedAqs;
    get managedAqs(): ExternalLocationEffectiveFileEventQueueManagedAqsOutputReference;
    putManagedAqs(value: ExternalLocationEffectiveFileEventQueueManagedAqs): void;
    resetManagedAqs(): void;
    get managedAqsInput(): ExternalLocationEffectiveFileEventQueueManagedAqs | undefined;
    private _managedPubsub;
    get managedPubsub(): ExternalLocationEffectiveFileEventQueueManagedPubsubOutputReference;
    putManagedPubsub(value: ExternalLocationEffectiveFileEventQueueManagedPubsub): void;
    resetManagedPubsub(): void;
    get managedPubsubInput(): ExternalLocationEffectiveFileEventQueueManagedPubsub | undefined;
    private _managedSqs;
    get managedSqs(): ExternalLocationEffectiveFileEventQueueManagedSqsOutputReference;
    putManagedSqs(value: ExternalLocationEffectiveFileEventQueueManagedSqs): void;
    resetManagedSqs(): void;
    get managedSqsInput(): ExternalLocationEffectiveFileEventQueueManagedSqs | undefined;
    private _providedAqs;
    get providedAqs(): ExternalLocationEffectiveFileEventQueueProvidedAqsOutputReference;
    putProvidedAqs(value: ExternalLocationEffectiveFileEventQueueProvidedAqs): void;
    resetProvidedAqs(): void;
    get providedAqsInput(): ExternalLocationEffectiveFileEventQueueProvidedAqs | undefined;
    private _providedPubsub;
    get providedPubsub(): ExternalLocationEffectiveFileEventQueueProvidedPubsubOutputReference;
    putProvidedPubsub(value: ExternalLocationEffectiveFileEventQueueProvidedPubsub): void;
    resetProvidedPubsub(): void;
    get providedPubsubInput(): ExternalLocationEffectiveFileEventQueueProvidedPubsub | undefined;
    private _providedSqs;
    get providedSqs(): ExternalLocationEffectiveFileEventQueueProvidedSqsOutputReference;
    putProvidedSqs(value: ExternalLocationEffectiveFileEventQueueProvidedSqs): void;
    resetProvidedSqs(): void;
    get providedSqsInput(): ExternalLocationEffectiveFileEventQueueProvidedSqs | undefined;
}
export interface ExternalLocationEncryptionDetailsSseEncryptionDetails {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#algorithm ExternalLocation#algorithm}
    */
    readonly algorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#aws_kms_key_arn ExternalLocation#aws_kms_key_arn}
    */
    readonly awsKmsKeyArn?: string;
}
export declare function externalLocationEncryptionDetailsSseEncryptionDetailsToTerraform(struct?: ExternalLocationEncryptionDetailsSseEncryptionDetailsOutputReference | ExternalLocationEncryptionDetailsSseEncryptionDetails): any;
export declare function externalLocationEncryptionDetailsSseEncryptionDetailsToHclTerraform(struct?: ExternalLocationEncryptionDetailsSseEncryptionDetailsOutputReference | ExternalLocationEncryptionDetailsSseEncryptionDetails): any;
export declare class ExternalLocationEncryptionDetailsSseEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEncryptionDetailsSseEncryptionDetails | undefined;
    set internalValue(value: ExternalLocationEncryptionDetailsSseEncryptionDetails | undefined);
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    resetAlgorithm(): void;
    get algorithmInput(): string | undefined;
    private _awsKmsKeyArn?;
    get awsKmsKeyArn(): string;
    set awsKmsKeyArn(value: string);
    resetAwsKmsKeyArn(): void;
    get awsKmsKeyArnInput(): string | undefined;
}
export interface ExternalLocationEncryptionDetails {
    /**
    * sse_encryption_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#sse_encryption_details ExternalLocation#sse_encryption_details}
    */
    readonly sseEncryptionDetails?: ExternalLocationEncryptionDetailsSseEncryptionDetails;
}
export declare function externalLocationEncryptionDetailsToTerraform(struct?: ExternalLocationEncryptionDetailsOutputReference | ExternalLocationEncryptionDetails): any;
export declare function externalLocationEncryptionDetailsToHclTerraform(struct?: ExternalLocationEncryptionDetailsOutputReference | ExternalLocationEncryptionDetails): any;
export declare class ExternalLocationEncryptionDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationEncryptionDetails | undefined;
    set internalValue(value: ExternalLocationEncryptionDetails | undefined);
    private _sseEncryptionDetails;
    get sseEncryptionDetails(): ExternalLocationEncryptionDetailsSseEncryptionDetailsOutputReference;
    putSseEncryptionDetails(value: ExternalLocationEncryptionDetailsSseEncryptionDetails): void;
    resetSseEncryptionDetails(): void;
    get sseEncryptionDetailsInput(): ExternalLocationEncryptionDetailsSseEncryptionDetails | undefined;
}
export interface ExternalLocationFileEventQueueManagedAqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#resource_group ExternalLocation#resource_group}
    */
    readonly resourceGroup: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_id ExternalLocation#subscription_id}
    */
    readonly subscriptionId: string;
}
export declare function externalLocationFileEventQueueManagedAqsToTerraform(struct?: ExternalLocationFileEventQueueManagedAqsOutputReference | ExternalLocationFileEventQueueManagedAqs): any;
export declare function externalLocationFileEventQueueManagedAqsToHclTerraform(struct?: ExternalLocationFileEventQueueManagedAqsOutputReference | ExternalLocationFileEventQueueManagedAqs): any;
export declare class ExternalLocationFileEventQueueManagedAqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationFileEventQueueManagedAqs | undefined;
    set internalValue(value: ExternalLocationFileEventQueueManagedAqs | undefined);
    get managedResourceId(): string;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
}
export interface ExternalLocationFileEventQueueManagedPubsub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_name ExternalLocation#subscription_name}
    */
    readonly subscriptionName?: string;
}
export declare function externalLocationFileEventQueueManagedPubsubToTerraform(struct?: ExternalLocationFileEventQueueManagedPubsubOutputReference | ExternalLocationFileEventQueueManagedPubsub): any;
export declare function externalLocationFileEventQueueManagedPubsubToHclTerraform(struct?: ExternalLocationFileEventQueueManagedPubsubOutputReference | ExternalLocationFileEventQueueManagedPubsub): any;
export declare class ExternalLocationFileEventQueueManagedPubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationFileEventQueueManagedPubsub | undefined;
    set internalValue(value: ExternalLocationFileEventQueueManagedPubsub | undefined);
    get managedResourceId(): string;
    private _subscriptionName?;
    get subscriptionName(): string;
    set subscriptionName(value: string);
    resetSubscriptionName(): void;
    get subscriptionNameInput(): string | undefined;
}
export interface ExternalLocationFileEventQueueManagedSqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl?: string;
}
export declare function externalLocationFileEventQueueManagedSqsToTerraform(struct?: ExternalLocationFileEventQueueManagedSqsOutputReference | ExternalLocationFileEventQueueManagedSqs): any;
export declare function externalLocationFileEventQueueManagedSqsToHclTerraform(struct?: ExternalLocationFileEventQueueManagedSqsOutputReference | ExternalLocationFileEventQueueManagedSqs): any;
export declare class ExternalLocationFileEventQueueManagedSqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationFileEventQueueManagedSqs | undefined;
    set internalValue(value: ExternalLocationFileEventQueueManagedSqs | undefined);
    get managedResourceId(): string;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    resetQueueUrl(): void;
    get queueUrlInput(): string | undefined;
}
export interface ExternalLocationFileEventQueueProvidedAqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#resource_group ExternalLocation#resource_group}
    */
    readonly resourceGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_id ExternalLocation#subscription_id}
    */
    readonly subscriptionId?: string;
}
export declare function externalLocationFileEventQueueProvidedAqsToTerraform(struct?: ExternalLocationFileEventQueueProvidedAqsOutputReference | ExternalLocationFileEventQueueProvidedAqs): any;
export declare function externalLocationFileEventQueueProvidedAqsToHclTerraform(struct?: ExternalLocationFileEventQueueProvidedAqsOutputReference | ExternalLocationFileEventQueueProvidedAqs): any;
export declare class ExternalLocationFileEventQueueProvidedAqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationFileEventQueueProvidedAqs | undefined;
    set internalValue(value: ExternalLocationFileEventQueueProvidedAqs | undefined);
    get managedResourceId(): string;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    get queueUrlInput(): string | undefined;
    private _resourceGroup?;
    get resourceGroup(): string;
    set resourceGroup(value: string);
    resetResourceGroup(): void;
    get resourceGroupInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    resetSubscriptionId(): void;
    get subscriptionIdInput(): string | undefined;
}
export interface ExternalLocationFileEventQueueProvidedPubsub {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#subscription_name ExternalLocation#subscription_name}
    */
    readonly subscriptionName: string;
}
export declare function externalLocationFileEventQueueProvidedPubsubToTerraform(struct?: ExternalLocationFileEventQueueProvidedPubsubOutputReference | ExternalLocationFileEventQueueProvidedPubsub): any;
export declare function externalLocationFileEventQueueProvidedPubsubToHclTerraform(struct?: ExternalLocationFileEventQueueProvidedPubsubOutputReference | ExternalLocationFileEventQueueProvidedPubsub): any;
export declare class ExternalLocationFileEventQueueProvidedPubsubOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationFileEventQueueProvidedPubsub | undefined;
    set internalValue(value: ExternalLocationFileEventQueueProvidedPubsub | undefined);
    get managedResourceId(): string;
    private _subscriptionName?;
    get subscriptionName(): string;
    set subscriptionName(value: string);
    get subscriptionNameInput(): string | undefined;
}
export interface ExternalLocationFileEventQueueProvidedSqs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#queue_url ExternalLocation#queue_url}
    */
    readonly queueUrl: string;
}
export declare function externalLocationFileEventQueueProvidedSqsToTerraform(struct?: ExternalLocationFileEventQueueProvidedSqsOutputReference | ExternalLocationFileEventQueueProvidedSqs): any;
export declare function externalLocationFileEventQueueProvidedSqsToHclTerraform(struct?: ExternalLocationFileEventQueueProvidedSqsOutputReference | ExternalLocationFileEventQueueProvidedSqs): any;
export declare class ExternalLocationFileEventQueueProvidedSqsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationFileEventQueueProvidedSqs | undefined;
    set internalValue(value: ExternalLocationFileEventQueueProvidedSqs | undefined);
    get managedResourceId(): string;
    private _queueUrl?;
    get queueUrl(): string;
    set queueUrl(value: string);
    get queueUrlInput(): string | undefined;
}
export interface ExternalLocationFileEventQueue {
    /**
    * managed_aqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_aqs ExternalLocation#managed_aqs}
    */
    readonly managedAqs?: ExternalLocationFileEventQueueManagedAqs;
    /**
    * managed_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_pubsub ExternalLocation#managed_pubsub}
    */
    readonly managedPubsub?: ExternalLocationFileEventQueueManagedPubsub;
    /**
    * managed_sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#managed_sqs ExternalLocation#managed_sqs}
    */
    readonly managedSqs?: ExternalLocationFileEventQueueManagedSqs;
    /**
    * provided_aqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#provided_aqs ExternalLocation#provided_aqs}
    */
    readonly providedAqs?: ExternalLocationFileEventQueueProvidedAqs;
    /**
    * provided_pubsub block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#provided_pubsub ExternalLocation#provided_pubsub}
    */
    readonly providedPubsub?: ExternalLocationFileEventQueueProvidedPubsub;
    /**
    * provided_sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#provided_sqs ExternalLocation#provided_sqs}
    */
    readonly providedSqs?: ExternalLocationFileEventQueueProvidedSqs;
}
export declare function externalLocationFileEventQueueToTerraform(struct?: ExternalLocationFileEventQueueOutputReference | ExternalLocationFileEventQueue): any;
export declare function externalLocationFileEventQueueToHclTerraform(struct?: ExternalLocationFileEventQueueOutputReference | ExternalLocationFileEventQueue): any;
export declare class ExternalLocationFileEventQueueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationFileEventQueue | undefined;
    set internalValue(value: ExternalLocationFileEventQueue | undefined);
    private _managedAqs;
    get managedAqs(): ExternalLocationFileEventQueueManagedAqsOutputReference;
    putManagedAqs(value: ExternalLocationFileEventQueueManagedAqs): void;
    resetManagedAqs(): void;
    get managedAqsInput(): ExternalLocationFileEventQueueManagedAqs | undefined;
    private _managedPubsub;
    get managedPubsub(): ExternalLocationFileEventQueueManagedPubsubOutputReference;
    putManagedPubsub(value: ExternalLocationFileEventQueueManagedPubsub): void;
    resetManagedPubsub(): void;
    get managedPubsubInput(): ExternalLocationFileEventQueueManagedPubsub | undefined;
    private _managedSqs;
    get managedSqs(): ExternalLocationFileEventQueueManagedSqsOutputReference;
    putManagedSqs(value: ExternalLocationFileEventQueueManagedSqs): void;
    resetManagedSqs(): void;
    get managedSqsInput(): ExternalLocationFileEventQueueManagedSqs | undefined;
    private _providedAqs;
    get providedAqs(): ExternalLocationFileEventQueueProvidedAqsOutputReference;
    putProvidedAqs(value: ExternalLocationFileEventQueueProvidedAqs): void;
    resetProvidedAqs(): void;
    get providedAqsInput(): ExternalLocationFileEventQueueProvidedAqs | undefined;
    private _providedPubsub;
    get providedPubsub(): ExternalLocationFileEventQueueProvidedPubsubOutputReference;
    putProvidedPubsub(value: ExternalLocationFileEventQueueProvidedPubsub): void;
    resetProvidedPubsub(): void;
    get providedPubsubInput(): ExternalLocationFileEventQueueProvidedPubsub | undefined;
    private _providedSqs;
    get providedSqs(): ExternalLocationFileEventQueueProvidedSqsOutputReference;
    putProvidedSqs(value: ExternalLocationFileEventQueueProvidedSqs): void;
    resetProvidedSqs(): void;
    get providedSqsInput(): ExternalLocationFileEventQueueProvidedSqs | undefined;
}
export interface ExternalLocationProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#workspace_id ExternalLocation#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function externalLocationProviderConfigToTerraform(struct?: ExternalLocationProviderConfigOutputReference | ExternalLocationProviderConfig): any;
export declare function externalLocationProviderConfigToHclTerraform(struct?: ExternalLocationProviderConfigOutputReference | ExternalLocationProviderConfig): any;
export declare class ExternalLocationProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ExternalLocationProviderConfig | undefined;
    set internalValue(value: ExternalLocationProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location databricks_external_location}
*/
export declare class ExternalLocation extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_external_location";
    /**
    * Generates CDKTN code for importing a ExternalLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ExternalLocation to import
    * @param importFromId The id of the existing ExternalLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ExternalLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/external_location databricks_external_location} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ExternalLocationConfig
    */
    constructor(scope: Construct, id: string, config: ExternalLocationConfig);
    get browseOnly(): cdktn.IResolvable;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get createdAt(): number;
    get createdBy(): string;
    get credentialId(): string;
    private _credentialName?;
    get credentialName(): string;
    set credentialName(value: string);
    get credentialNameInput(): string | undefined;
    get effectiveEnableFileEvents(): cdktn.IResolvable;
    private _enableFileEvents?;
    get enableFileEvents(): boolean | cdktn.IResolvable;
    set enableFileEvents(value: boolean | cdktn.IResolvable);
    resetEnableFileEvents(): void;
    get enableFileEventsInput(): boolean | cdktn.IResolvable | undefined;
    private _fallback?;
    get fallback(): boolean | cdktn.IResolvable;
    set fallback(value: boolean | cdktn.IResolvable);
    resetFallback(): void;
    get fallbackInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isolationMode?;
    get isolationMode(): string;
    set isolationMode(value: string);
    resetIsolationMode(): void;
    get isolationModeInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _skipValidation?;
    get skipValidation(): boolean | cdktn.IResolvable;
    set skipValidation(value: boolean | cdktn.IResolvable);
    resetSkipValidation(): void;
    get skipValidationInput(): boolean | cdktn.IResolvable | undefined;
    get updatedAt(): number;
    get updatedBy(): string;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _effectiveFileEventQueue;
    get effectiveFileEventQueue(): ExternalLocationEffectiveFileEventQueueOutputReference;
    putEffectiveFileEventQueue(value: ExternalLocationEffectiveFileEventQueue): void;
    resetEffectiveFileEventQueue(): void;
    get effectiveFileEventQueueInput(): ExternalLocationEffectiveFileEventQueue | undefined;
    private _encryptionDetails;
    get encryptionDetails(): ExternalLocationEncryptionDetailsOutputReference;
    putEncryptionDetails(value: ExternalLocationEncryptionDetails): void;
    resetEncryptionDetails(): void;
    get encryptionDetailsInput(): ExternalLocationEncryptionDetails | undefined;
    private _fileEventQueue;
    get fileEventQueue(): ExternalLocationFileEventQueueOutputReference;
    putFileEventQueue(value: ExternalLocationFileEventQueue): void;
    resetFileEventQueue(): void;
    get fileEventQueueInput(): ExternalLocationFileEventQueue | undefined;
    private _providerConfig;
    get providerConfig(): ExternalLocationProviderConfigOutputReference;
    putProviderConfig(value: ExternalLocationProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ExternalLocationProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
