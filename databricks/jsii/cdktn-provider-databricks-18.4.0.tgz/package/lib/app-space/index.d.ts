/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppSpaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#description AppSpace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#name AppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#provider_config AppSpace#provider_config}
    */
    readonly providerConfig?: AppSpaceProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#resources AppSpace#resources}
    */
    readonly resources?: AppSpaceResources[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#usage_policy_id AppSpace#usage_policy_id}
    */
    readonly usagePolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#user_api_scopes AppSpace#user_api_scopes}
    */
    readonly userApiScopes?: string[];
}
export interface AppSpaceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#workspace_id AppSpace#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function appSpaceProviderConfigToTerraform(struct?: AppSpaceProviderConfig | cdktn.IResolvable): any;
export declare function appSpaceProviderConfigToHclTerraform(struct?: AppSpaceProviderConfig | cdktn.IResolvable): any;
export declare class AppSpaceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface AppSpaceResourcesApp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#name AppSpace#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission?: string;
}
export declare function appSpaceResourcesAppToTerraform(struct?: AppSpaceResourcesApp | cdktn.IResolvable): any;
export declare function appSpaceResourcesAppToHclTerraform(struct?: AppSpaceResourcesApp | cdktn.IResolvable): any;
export declare class AppSpaceResourcesAppOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesApp | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesApp | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface AppSpaceResourcesDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#database_name AppSpace#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#instance_name AppSpace#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
}
export declare function appSpaceResourcesDatabaseToTerraform(struct?: AppSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare function appSpaceResourcesDatabaseToHclTerraform(struct?: AppSpaceResourcesDatabase | cdktn.IResolvable): any;
export declare class AppSpaceResourcesDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesDatabase | cdktn.IResolvable | undefined);
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppSpaceResourcesExperiment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#experiment_id AppSpace#experiment_id}
    */
    readonly experimentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
}
export declare function appSpaceResourcesExperimentToTerraform(struct?: AppSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare function appSpaceResourcesExperimentToHclTerraform(struct?: AppSpaceResourcesExperiment | cdktn.IResolvable): any;
export declare class AppSpaceResourcesExperimentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesExperiment | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesExperiment | cdktn.IResolvable | undefined);
    private _experimentId?;
    get experimentId(): string;
    set experimentId(value: string);
    get experimentIdInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppSpaceResourcesGenieSpace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#name AppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#space_id AppSpace#space_id}
    */
    readonly spaceId: string;
}
export declare function appSpaceResourcesGenieSpaceToTerraform(struct?: AppSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare function appSpaceResourcesGenieSpaceToHclTerraform(struct?: AppSpaceResourcesGenieSpace | cdktn.IResolvable): any;
export declare class AppSpaceResourcesGenieSpaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesGenieSpace | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesGenieSpace | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _spaceId?;
    get spaceId(): string;
    set spaceId(value: string);
    get spaceIdInput(): string | undefined;
}
export interface AppSpaceResourcesJob {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#id AppSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
}
export declare function appSpaceResourcesJobToTerraform(struct?: AppSpaceResourcesJob | cdktn.IResolvable): any;
export declare function appSpaceResourcesJobToHclTerraform(struct?: AppSpaceResourcesJob | cdktn.IResolvable): any;
export declare class AppSpaceResourcesJobOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesJob | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesJob | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppSpaceResourcesPostgres {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#branch AppSpace#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#database AppSpace#database}
    */
    readonly database?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission?: string;
}
export declare function appSpaceResourcesPostgresToTerraform(struct?: AppSpaceResourcesPostgres | cdktn.IResolvable): any;
export declare function appSpaceResourcesPostgresToHclTerraform(struct?: AppSpaceResourcesPostgres | cdktn.IResolvable): any;
export declare class AppSpaceResourcesPostgresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesPostgres | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesPostgres | cdktn.IResolvable | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _database?;
    get database(): string;
    set database(value: string);
    resetDatabase(): void;
    get databaseInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    resetPermission(): void;
    get permissionInput(): string | undefined;
}
export interface AppSpaceResourcesSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#key AppSpace#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#scope AppSpace#scope}
    */
    readonly scope: string;
}
export declare function appSpaceResourcesSecretToTerraform(struct?: AppSpaceResourcesSecret | cdktn.IResolvable): any;
export declare function appSpaceResourcesSecretToHclTerraform(struct?: AppSpaceResourcesSecret | cdktn.IResolvable): any;
export declare class AppSpaceResourcesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesSecret | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesSecret | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface AppSpaceResourcesServingEndpoint {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#name AppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
}
export declare function appSpaceResourcesServingEndpointToTerraform(struct?: AppSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare function appSpaceResourcesServingEndpointToHclTerraform(struct?: AppSpaceResourcesServingEndpoint | cdktn.IResolvable): any;
export declare class AppSpaceResourcesServingEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesServingEndpoint | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppSpaceResourcesSqlWarehouse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#id AppSpace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
}
export declare function appSpaceResourcesSqlWarehouseToTerraform(struct?: AppSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare function appSpaceResourcesSqlWarehouseToHclTerraform(struct?: AppSpaceResourcesSqlWarehouse | cdktn.IResolvable): any;
export declare class AppSpaceResourcesSqlWarehouseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesSqlWarehouse | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
}
export interface AppSpaceResourcesUcSecurable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#permission AppSpace#permission}
    */
    readonly permission: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#securable_full_name AppSpace#securable_full_name}
    */
    readonly securableFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#securable_type AppSpace#securable_type}
    */
    readonly securableType: string;
}
export declare function appSpaceResourcesUcSecurableToTerraform(struct?: AppSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare function appSpaceResourcesUcSecurableToHclTerraform(struct?: AppSpaceResourcesUcSecurable | cdktn.IResolvable): any;
export declare class AppSpaceResourcesUcSecurableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceResourcesUcSecurable | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResourcesUcSecurable | cdktn.IResolvable | undefined);
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _securableFullName?;
    get securableFullName(): string;
    set securableFullName(value: string);
    get securableFullNameInput(): string | undefined;
    get securableKind(): string;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    get securableTypeInput(): string | undefined;
}
export interface AppSpaceResources {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#app AppSpace#app}
    */
    readonly app?: AppSpaceResourcesApp;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#database AppSpace#database}
    */
    readonly database?: AppSpaceResourcesDatabase;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#description AppSpace#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#experiment AppSpace#experiment}
    */
    readonly experiment?: AppSpaceResourcesExperiment;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#genie_space AppSpace#genie_space}
    */
    readonly genieSpace?: AppSpaceResourcesGenieSpace;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#job AppSpace#job}
    */
    readonly job?: AppSpaceResourcesJob;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#name AppSpace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#postgres AppSpace#postgres}
    */
    readonly postgres?: AppSpaceResourcesPostgres;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#secret AppSpace#secret}
    */
    readonly secret?: AppSpaceResourcesSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#serving_endpoint AppSpace#serving_endpoint}
    */
    readonly servingEndpoint?: AppSpaceResourcesServingEndpoint;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#sql_warehouse AppSpace#sql_warehouse}
    */
    readonly sqlWarehouse?: AppSpaceResourcesSqlWarehouse;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#uc_securable AppSpace#uc_securable}
    */
    readonly ucSecurable?: AppSpaceResourcesUcSecurable;
}
export declare function appSpaceResourcesToTerraform(struct?: AppSpaceResources | cdktn.IResolvable): any;
export declare function appSpaceResourcesToHclTerraform(struct?: AppSpaceResources | cdktn.IResolvable): any;
export declare class AppSpaceResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AppSpaceResources | cdktn.IResolvable | undefined;
    set internalValue(value: AppSpaceResources | cdktn.IResolvable | undefined);
    private _app;
    get app(): AppSpaceResourcesAppOutputReference;
    putApp(value: AppSpaceResourcesApp): void;
    resetApp(): void;
    get appInput(): cdktn.IResolvable | AppSpaceResourcesApp | undefined;
    private _database;
    get database(): AppSpaceResourcesDatabaseOutputReference;
    putDatabase(value: AppSpaceResourcesDatabase): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | AppSpaceResourcesDatabase | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experiment;
    get experiment(): AppSpaceResourcesExperimentOutputReference;
    putExperiment(value: AppSpaceResourcesExperiment): void;
    resetExperiment(): void;
    get experimentInput(): cdktn.IResolvable | AppSpaceResourcesExperiment | undefined;
    private _genieSpace;
    get genieSpace(): AppSpaceResourcesGenieSpaceOutputReference;
    putGenieSpace(value: AppSpaceResourcesGenieSpace): void;
    resetGenieSpace(): void;
    get genieSpaceInput(): cdktn.IResolvable | AppSpaceResourcesGenieSpace | undefined;
    private _job;
    get job(): AppSpaceResourcesJobOutputReference;
    putJob(value: AppSpaceResourcesJob): void;
    resetJob(): void;
    get jobInput(): cdktn.IResolvable | AppSpaceResourcesJob | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _postgres;
    get postgres(): AppSpaceResourcesPostgresOutputReference;
    putPostgres(value: AppSpaceResourcesPostgres): void;
    resetPostgres(): void;
    get postgresInput(): cdktn.IResolvable | AppSpaceResourcesPostgres | undefined;
    private _secret;
    get secret(): AppSpaceResourcesSecretOutputReference;
    putSecret(value: AppSpaceResourcesSecret): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | AppSpaceResourcesSecret | undefined;
    private _servingEndpoint;
    get servingEndpoint(): AppSpaceResourcesServingEndpointOutputReference;
    putServingEndpoint(value: AppSpaceResourcesServingEndpoint): void;
    resetServingEndpoint(): void;
    get servingEndpointInput(): cdktn.IResolvable | AppSpaceResourcesServingEndpoint | undefined;
    private _sqlWarehouse;
    get sqlWarehouse(): AppSpaceResourcesSqlWarehouseOutputReference;
    putSqlWarehouse(value: AppSpaceResourcesSqlWarehouse): void;
    resetSqlWarehouse(): void;
    get sqlWarehouseInput(): cdktn.IResolvable | AppSpaceResourcesSqlWarehouse | undefined;
    private _ucSecurable;
    get ucSecurable(): AppSpaceResourcesUcSecurableOutputReference;
    putUcSecurable(value: AppSpaceResourcesUcSecurable): void;
    resetUcSecurable(): void;
    get ucSecurableInput(): cdktn.IResolvable | AppSpaceResourcesUcSecurable | undefined;
}
export declare class AppSpaceResourcesList extends cdktn.ComplexList {
    internalValue?: AppSpaceResources[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AppSpaceResourcesOutputReference;
}
export interface AppSpaceStatus {
}
export declare function appSpaceStatusToTerraform(struct?: AppSpaceStatus): any;
export declare function appSpaceStatusToHclTerraform(struct?: AppSpaceStatus): any;
export declare class AppSpaceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppSpaceStatus | undefined;
    set internalValue(value: AppSpaceStatus | undefined);
    get message(): string;
    get state(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space databricks_app_space}
*/
export declare class AppSpace extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_app_space";
    /**
    * Generates CDKTN code for importing a AppSpace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppSpace to import
    * @param importFromId The id of the existing AppSpace that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppSpace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/app_space databricks_app_space} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppSpaceConfig
    */
    constructor(scope: Construct, id: string, config: AppSpaceConfig);
    get createTime(): string;
    get creator(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get effectiveUsagePolicyId(): string;
    get effectiveUserApiScopes(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AppSpaceProviderConfigOutputReference;
    putProviderConfig(value: AppSpaceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AppSpaceProviderConfig | undefined;
    private _resources;
    get resources(): AppSpaceResourcesList;
    putResources(value: AppSpaceResources[] | cdktn.IResolvable): void;
    resetResources(): void;
    get resourcesInput(): cdktn.IResolvable | AppSpaceResources[] | undefined;
    get servicePrincipalClientId(): string;
    get servicePrincipalId(): number;
    get servicePrincipalName(): string;
    private _status;
    get status(): AppSpaceStatusOutputReference;
    get updateTime(): string;
    get updater(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    private _userApiScopes?;
    get userApiScopes(): string[];
    set userApiScopes(value: string[]);
    resetUserApiScopes(): void;
    get userApiScopesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
