/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface DataDatabricksJobJobSettingsSettingsContinuous {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#pause_status DataDatabricksJob#pause_status}
    */
    readonly pauseStatus?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsContinuousToTerraform(struct?: DataDatabricksJobJobSettingsSettingsContinuousOutputReference | DataDatabricksJobJobSettingsSettingsContinuous): any;
export declare function dataDatabricksJobJobSettingsSettingsContinuousToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsContinuousOutputReference | DataDatabricksJobJobSettingsSettingsContinuous): any;
export declare class DataDatabricksJobJobSettingsSettingsContinuousOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsContinuous | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsContinuous | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsDbtTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#catalog DataDatabricksJob#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#commands DataDatabricksJob#commands}
    */
    readonly commands: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#profiles_directory DataDatabricksJob#profiles_directory}
    */
    readonly profilesDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#project_directory DataDatabricksJob#project_directory}
    */
    readonly projectDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#schema DataDatabricksJob#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsDbtTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsDbtTaskOutputReference | DataDatabricksJobJobSettingsSettingsDbtTask): any;
export declare function dataDatabricksJobJobSettingsSettingsDbtTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsDbtTaskOutputReference | DataDatabricksJobJobSettingsSettingsDbtTask): any;
export declare class DataDatabricksJobJobSettingsSettingsDbtTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsDbtTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsDbtTask | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    get commandsInput(): string[] | undefined;
    private _profilesDirectory?;
    get profilesDirectory(): string;
    set profilesDirectory(value: string);
    resetProfilesDirectory(): void;
    get profilesDirectoryInput(): string | undefined;
    private _projectDirectory?;
    get projectDirectory(): string;
    set projectDirectory(value: string);
    resetProjectDirectory(): void;
    get projectDirectoryInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsDeployment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#deployment_id DataDatabricksJob#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#kind DataDatabricksJob#kind}
    */
    readonly kind: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#metadata_file_path DataDatabricksJob#metadata_file_path}
    */
    readonly metadataFilePath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#version_id DataDatabricksJob#version_id}
    */
    readonly versionId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsDeploymentToTerraform(struct?: DataDatabricksJobJobSettingsSettingsDeploymentOutputReference | DataDatabricksJobJobSettingsSettingsDeployment): any;
export declare function dataDatabricksJobJobSettingsSettingsDeploymentToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsDeploymentOutputReference | DataDatabricksJobJobSettingsSettingsDeployment): any;
export declare class DataDatabricksJobJobSettingsSettingsDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsDeployment | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsDeployment | undefined);
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    get kindInput(): string | undefined;
    private _metadataFilePath?;
    get metadataFilePath(): string;
    set metadataFilePath(value: string);
    resetMetadataFilePath(): void;
    get metadataFilePathInput(): string | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#no_alert_for_skipped_runs DataDatabricksJob#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_duration_warning_threshold_exceeded DataDatabricksJob#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_failure DataDatabricksJob#on_failure}
    */
    readonly onFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_start DataDatabricksJob#on_start}
    */
    readonly onStart?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_streaming_backlog_exceeded DataDatabricksJob#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_success DataDatabricksJob#on_success}
    */
    readonly onSuccess?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsEmailNotificationsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsEmailNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsEmailNotifications): any;
export declare function dataDatabricksJobJobSettingsSettingsEmailNotificationsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsEmailNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsEmailNotifications): any;
export declare class DataDatabricksJobJobSettingsSettingsEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsEmailNotifications | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsEmailNotifications | undefined);
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _onDurationWarningThresholdExceeded?;
    get onDurationWarningThresholdExceeded(): string[];
    set onDurationWarningThresholdExceeded(value: string[]);
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): string[] | undefined;
    private _onFailure?;
    get onFailure(): string[];
    set onFailure(value: string[]);
    resetOnFailure(): void;
    get onFailureInput(): string[] | undefined;
    private _onStart?;
    get onStart(): string[];
    set onStart(value: string[]);
    resetOnStart(): void;
    get onStartInput(): string[] | undefined;
    private _onStreamingBacklogExceeded?;
    get onStreamingBacklogExceeded(): string[];
    set onStreamingBacklogExceeded(value: string[]);
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): string[] | undefined;
    private _onSuccess?;
    get onSuccess(): string[];
    set onSuccess(value: string[]);
    resetOnSuccess(): void;
    get onSuccessInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsEnvironmentSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#base_environment DataDatabricksJob#base_environment}
    */
    readonly baseEnvironment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#client DataDatabricksJob#client}
    */
    readonly client?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dependencies DataDatabricksJob#dependencies}
    */
    readonly dependencies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#environment_version DataDatabricksJob#environment_version}
    */
    readonly environmentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#java_dependencies DataDatabricksJob#java_dependencies}
    */
    readonly javaDependencies?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsEnvironmentSpecToTerraform(struct?: DataDatabricksJobJobSettingsSettingsEnvironmentSpecOutputReference | DataDatabricksJobJobSettingsSettingsEnvironmentSpec): any;
export declare function dataDatabricksJobJobSettingsSettingsEnvironmentSpecToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsEnvironmentSpecOutputReference | DataDatabricksJobJobSettingsSettingsEnvironmentSpec): any;
export declare class DataDatabricksJobJobSettingsSettingsEnvironmentSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsEnvironmentSpec | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsEnvironmentSpec | undefined);
    private _baseEnvironment?;
    get baseEnvironment(): string;
    set baseEnvironment(value: string);
    resetBaseEnvironment(): void;
    get baseEnvironmentInput(): string | undefined;
    private _client?;
    get client(): string;
    set client(value: string);
    resetClient(): void;
    get clientInput(): string | undefined;
    private _dependencies?;
    get dependencies(): string[];
    set dependencies(value: string[]);
    resetDependencies(): void;
    get dependenciesInput(): string[] | undefined;
    private _environmentVersion?;
    get environmentVersion(): string;
    set environmentVersion(value: string);
    resetEnvironmentVersion(): void;
    get environmentVersionInput(): string | undefined;
    private _javaDependencies?;
    get javaDependencies(): string[];
    set javaDependencies(value: string[]);
    resetJavaDependencies(): void;
    get javaDependenciesInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsEnvironment {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#environment_key DataDatabricksJob#environment_key}
    */
    readonly environmentKey: string;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spec DataDatabricksJob#spec}
    */
    readonly spec?: DataDatabricksJobJobSettingsSettingsEnvironmentSpec;
}
export declare function dataDatabricksJobJobSettingsSettingsEnvironmentToTerraform(struct?: DataDatabricksJobJobSettingsSettingsEnvironment | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsEnvironmentToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsEnvironment | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsEnvironment | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsEnvironment | cdktn.IResolvable | undefined);
    private _environmentKey?;
    get environmentKey(): string;
    set environmentKey(value: string);
    get environmentKeyInput(): string | undefined;
    private _spec;
    get spec(): DataDatabricksJobJobSettingsSettingsEnvironmentSpecOutputReference;
    putSpec(value: DataDatabricksJobJobSettingsSettingsEnvironmentSpec): void;
    resetSpec(): void;
    get specInput(): DataDatabricksJobJobSettingsSettingsEnvironmentSpec | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsEnvironmentList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsEnvironment[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsEnvironmentOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsGitSourceJobSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dirty_state DataDatabricksJob#dirty_state}
    */
    readonly dirtyState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#import_from_git_branch DataDatabricksJob#import_from_git_branch}
    */
    readonly importFromGitBranch: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#job_config_path DataDatabricksJob#job_config_path}
    */
    readonly jobConfigPath: string;
}
export declare function dataDatabricksJobJobSettingsSettingsGitSourceJobSourceToTerraform(struct?: DataDatabricksJobJobSettingsSettingsGitSourceJobSourceOutputReference | DataDatabricksJobJobSettingsSettingsGitSourceJobSource): any;
export declare function dataDatabricksJobJobSettingsSettingsGitSourceJobSourceToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsGitSourceJobSourceOutputReference | DataDatabricksJobJobSettingsSettingsGitSourceJobSource): any;
export declare class DataDatabricksJobJobSettingsSettingsGitSourceJobSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsGitSourceJobSource | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsGitSourceJobSource | undefined);
    private _dirtyState?;
    get dirtyState(): string;
    set dirtyState(value: string);
    resetDirtyState(): void;
    get dirtyStateInput(): string | undefined;
    private _importFromGitBranch?;
    get importFromGitBranch(): string;
    set importFromGitBranch(value: string);
    get importFromGitBranchInput(): string | undefined;
    private _jobConfigPath?;
    get jobConfigPath(): string;
    set jobConfigPath(value: string);
    get jobConfigPathInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsGitSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#branch DataDatabricksJob#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#commit DataDatabricksJob#commit}
    */
    readonly commit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#provider DataDatabricksJob#provider}
    */
    readonly provider?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#tag DataDatabricksJob#tag}
    */
    readonly tag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#url DataDatabricksJob#url}
    */
    readonly url: string;
    /**
    * job_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#job_source DataDatabricksJob#job_source}
    */
    readonly jobSource?: DataDatabricksJobJobSettingsSettingsGitSourceJobSource;
}
export declare function dataDatabricksJobJobSettingsSettingsGitSourceToTerraform(struct?: DataDatabricksJobJobSettingsSettingsGitSourceOutputReference | DataDatabricksJobJobSettingsSettingsGitSource): any;
export declare function dataDatabricksJobJobSettingsSettingsGitSourceToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsGitSourceOutputReference | DataDatabricksJobJobSettingsSettingsGitSource): any;
export declare class DataDatabricksJobJobSettingsSettingsGitSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsGitSource | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsGitSource | undefined);
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _commit?;
    get commit(): string;
    set commit(value: string);
    resetCommit(): void;
    get commitInput(): string | undefined;
    private _provider?;
    get provider(): string;
    set provider(value: string);
    resetProvider(): void;
    get providerInput(): string | undefined;
    private _tag?;
    get tag(): string;
    set tag(value: string);
    resetTag(): void;
    get tagInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _jobSource;
    get jobSource(): DataDatabricksJobJobSettingsSettingsGitSourceJobSourceOutputReference;
    putJobSource(value: DataDatabricksJobJobSettingsSettingsGitSourceJobSource): void;
    resetJobSource(): void;
    get jobSourceInput(): DataDatabricksJobJobSettingsSettingsGitSourceJobSource | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsHealthRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#metric DataDatabricksJob#metric}
    */
    readonly metric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#op DataDatabricksJob#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#value DataDatabricksJob#value}
    */
    readonly value: number;
}
export declare function dataDatabricksJobJobSettingsSettingsHealthRulesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsHealthRules | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsHealthRulesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsHealthRules | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsHealthRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsHealthRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsHealthRules | cdktn.IResolvable | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsHealthRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsHealthRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsHealthRulesOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsHealth {
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#rules DataDatabricksJob#rules}
    */
    readonly rules: DataDatabricksJobJobSettingsSettingsHealthRules[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsHealthToTerraform(struct?: DataDatabricksJobJobSettingsSettingsHealthOutputReference | DataDatabricksJobJobSettingsSettingsHealth): any;
export declare function dataDatabricksJobJobSettingsSettingsHealthToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsHealthOutputReference | DataDatabricksJobJobSettingsSettingsHealth): any;
export declare class DataDatabricksJobJobSettingsSettingsHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsHealth | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsHealth | undefined);
    private _rules;
    get rules(): DataDatabricksJobJobSettingsSettingsHealthRulesList;
    putRules(value: DataDatabricksJobJobSettingsSettingsHealthRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsHealthRules[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#max_workers DataDatabricksJob#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#min_workers DataDatabricksJob#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscaleToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscaleToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_count DataDatabricksJob#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_size DataDatabricksJob#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_type DataDatabricksJob#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#instance_profile_arn DataDatabricksJob#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spot_bid_price_percent DataDatabricksJob#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spot_bid_max_price DataDatabricksJob#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfS3 | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#mount_options DataDatabricksJob#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#server_address DataDatabricksJob#server_address}
    */
    readonly serverAddress: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#local_mount_dir_path DataDatabricksJob#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#remote_mount_dir_path DataDatabricksJob#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#network_filesystem_info DataDatabricksJob#network_filesystem_info}
    */
    readonly networkFilesystemInfo: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#password DataDatabricksJob#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#username DataDatabricksJob#username}
    */
    readonly username: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuthToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#url DataDatabricksJob#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#basic_auth DataDatabricksJob#basic_auth}
    */
    readonly basicAuth?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageBasicAuth | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#boot_disk_size DataDatabricksJob#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#google_service_account DataDatabricksJob#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#local_ssd_count DataDatabricksJob#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#use_preemptible_executors DataDatabricksJob#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfssToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfssToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFileToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFileToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspaceToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#abfss DataDatabricksJob#abfss}
    */
    readonly abfss?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#file DataDatabricksJob#file}
    */
    readonly file?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#gcs DataDatabricksJob#gcs}
    */
    readonly gcs?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#volumes DataDatabricksJob#volumes}
    */
    readonly volumes?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workspace DataDatabricksJob#workspace}
    */
    readonly workspace?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFileOutputReference;
    putFile(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcsOutputReference;
    putGcs(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsWorkspace | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#jobs DataDatabricksJob#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#notebooks DataDatabricksJob#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClientsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#clients DataDatabricksJob#clients}
    */
    readonly clients: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients): void;
    get clientsInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeClients | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobClusterNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#apply_policy_default_values DataDatabricksJob#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#autotermination_minutes DataDatabricksJob#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_id DataDatabricksJob#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_name DataDatabricksJob#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#custom_tags DataDatabricksJob#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#data_security_mode DataDatabricksJob#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#driver_instance_pool_id DataDatabricksJob#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#driver_node_type_id DataDatabricksJob#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_elastic_disk DataDatabricksJob#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_local_disk_encryption DataDatabricksJob#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#idempotency_token DataDatabricksJob#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#instance_pool_id DataDatabricksJob#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#node_type_id DataDatabricksJob#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#num_workers DataDatabricksJob#num_workers}
    */
    readonly numWorkers: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#policy_id DataDatabricksJob#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#runtime_engine DataDatabricksJob#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#single_user_name DataDatabricksJob#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_conf DataDatabricksJob#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_env_vars DataDatabricksJob#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_version DataDatabricksJob#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ssh_public_keys DataDatabricksJob#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#autoscale DataDatabricksJob#autoscale}
    */
    readonly autoscale?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#aws_attributes DataDatabricksJob#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#azure_attributes DataDatabricksJob#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_log_conf DataDatabricksJob#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_mount_info DataDatabricksJob#cluster_mount_info}
    */
    readonly clusterMountInfo?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#docker_image DataDatabricksJob#docker_image}
    */
    readonly dockerImage?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#gcp_attributes DataDatabricksJob#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#init_scripts DataDatabricksJob#init_scripts}
    */
    readonly initScripts?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workload_type DataDatabricksJob#workload_type}
    */
    readonly workloadType?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewCluster): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterNewClusterToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsJobClusterNewCluster): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobClusterNewCluster | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobClusterNewCluster | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _autoscale;
    get autoscale(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscaleOutputReference;
    putAutoscale(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfoList;
    putClusterMountInfo(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImageOutputReference;
    putDockerImage(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterDockerImage | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScriptsList;
    putInitScripts(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsJobClusterNewClusterInitScripts[] | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterWorkloadType | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsJobCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#job_cluster_key DataDatabricksJob#job_cluster_key}
    */
    readonly jobClusterKey: string;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#new_cluster DataDatabricksJob#new_cluster}
    */
    readonly newCluster: DataDatabricksJobJobSettingsSettingsJobClusterNewCluster;
}
export declare function dataDatabricksJobJobSettingsSettingsJobClusterToTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobCluster | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsJobClusterToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsJobCluster | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsJobClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsJobCluster | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsJobCluster | cdktn.IResolvable | undefined);
    private _jobClusterKey?;
    get jobClusterKey(): string;
    set jobClusterKey(value: string);
    get jobClusterKeyInput(): string | undefined;
    private _newCluster;
    get newCluster(): DataDatabricksJobJobSettingsSettingsJobClusterNewClusterOutputReference;
    putNewCluster(value: DataDatabricksJobJobSettingsSettingsJobClusterNewCluster): void;
    get newClusterInput(): DataDatabricksJobJobSettingsSettingsJobClusterNewCluster | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsJobClusterList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsJobCluster[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsJobClusterOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#package DataDatabricksJob#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsLibraryCranToTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryCranOutputReference | DataDatabricksJobJobSettingsSettingsLibraryCran): any;
export declare function dataDatabricksJobJobSettingsSettingsLibraryCranToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryCranOutputReference | DataDatabricksJobJobSettingsSettingsLibraryCran): any;
export declare class DataDatabricksJobJobSettingsSettingsLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsLibraryCran | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#coordinates DataDatabricksJob#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#exclusions DataDatabricksJob#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsLibraryMavenToTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryMavenOutputReference | DataDatabricksJobJobSettingsSettingsLibraryMaven): any;
export declare function dataDatabricksJobJobSettingsSettingsLibraryMavenToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryMavenOutputReference | DataDatabricksJobJobSettingsSettingsLibraryMaven): any;
export declare class DataDatabricksJobJobSettingsSettingsLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsLibraryMaven | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workspace_id DataDatabricksJob#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsLibraryProviderConfigToTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryProviderConfigOutputReference | DataDatabricksJobJobSettingsSettingsLibraryProviderConfig): any;
export declare function dataDatabricksJobJobSettingsSettingsLibraryProviderConfigToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryProviderConfigOutputReference | DataDatabricksJobJobSettingsSettingsLibraryProviderConfig): any;
export declare class DataDatabricksJobJobSettingsSettingsLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsLibraryProviderConfig | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#package DataDatabricksJob#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsLibraryPypiToTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryPypiOutputReference | DataDatabricksJobJobSettingsSettingsLibraryPypi): any;
export declare function dataDatabricksJobJobSettingsSettingsLibraryPypiToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibraryPypiOutputReference | DataDatabricksJobJobSettingsSettingsLibraryPypi): any;
export declare class DataDatabricksJobJobSettingsSettingsLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsLibraryPypi | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#egg DataDatabricksJob#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#jar DataDatabricksJob#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#requirements DataDatabricksJob#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#whl DataDatabricksJob#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cran DataDatabricksJob#cran}
    */
    readonly cran?: DataDatabricksJobJobSettingsSettingsLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#maven DataDatabricksJob#maven}
    */
    readonly maven?: DataDatabricksJobJobSettingsSettingsLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#provider_config DataDatabricksJob#provider_config}
    */
    readonly providerConfig?: DataDatabricksJobJobSettingsSettingsLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#pypi DataDatabricksJob#pypi}
    */
    readonly pypi?: DataDatabricksJobJobSettingsSettingsLibraryPypi;
}
export declare function dataDatabricksJobJobSettingsSettingsLibraryToTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibrary | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsLibraryToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsLibrary | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): DataDatabricksJobJobSettingsSettingsLibraryCranOutputReference;
    putCran(value: DataDatabricksJobJobSettingsSettingsLibraryCran): void;
    resetCran(): void;
    get cranInput(): DataDatabricksJobJobSettingsSettingsLibraryCran | undefined;
    private _maven;
    get maven(): DataDatabricksJobJobSettingsSettingsLibraryMavenOutputReference;
    putMaven(value: DataDatabricksJobJobSettingsSettingsLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): DataDatabricksJobJobSettingsSettingsLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksJobJobSettingsSettingsLibraryProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksJobJobSettingsSettingsLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksJobJobSettingsSettingsLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): DataDatabricksJobJobSettingsSettingsLibraryPypiOutputReference;
    putPypi(value: DataDatabricksJobJobSettingsSettingsLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): DataDatabricksJobJobSettingsSettingsLibraryPypi | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsLibraryList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsLibraryOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#max_workers DataDatabricksJob#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#min_workers DataDatabricksJob#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterAutoscaleToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterAutoscale): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterAutoscaleToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterAutoscale): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterAutoscale | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_count DataDatabricksJob#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_size DataDatabricksJob#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_type DataDatabricksJob#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#instance_profile_arn DataDatabricksJob#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spot_bid_price_percent DataDatabricksJob#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterAwsAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterAwsAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spot_bid_max_price DataDatabricksJob#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterAzureAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterAzureAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfS3 | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#mount_options DataDatabricksJob#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#server_address DataDatabricksJob#server_address}
    */
    readonly serverAddress: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#local_mount_dir_path DataDatabricksJob#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#remote_mount_dir_path DataDatabricksJob#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#network_filesystem_info DataDatabricksJob#network_filesystem_info}
    */
    readonly networkFilesystemInfo: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#password DataDatabricksJob#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#username DataDatabricksJob#username}
    */
    readonly username: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuthToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#url DataDatabricksJob#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#basic_auth DataDatabricksJob#basic_auth}
    */
    readonly basicAuth?: DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterDockerImageToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterDockerImage): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterDockerImageToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterDockerImage): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterDockerImage | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): DataDatabricksJobJobSettingsSettingsNewClusterDockerImageBasicAuth | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#boot_disk_size DataDatabricksJob#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#google_service_account DataDatabricksJob#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#local_ssd_count DataDatabricksJob#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#use_preemptible_executors DataDatabricksJob#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterGcpAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterGcpAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfssToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfssToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFileToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFileToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspaceToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#abfss DataDatabricksJob#abfss}
    */
    readonly abfss?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#file DataDatabricksJob#file}
    */
    readonly file?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#gcs DataDatabricksJob#gcs}
    */
    readonly gcs?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#volumes DataDatabricksJob#volumes}
    */
    readonly volumes?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workspace DataDatabricksJob#workspace}
    */
    readonly workspace?: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterInitScriptsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFileOutputReference;
    putFile(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcsOutputReference;
    putGcs(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsWorkspace | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#jobs DataDatabricksJob#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#notebooks DataDatabricksJob#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClientsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#clients DataDatabricksJob#clients}
    */
    readonly clients: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients): void;
    get clientsInput(): DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeClients | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#apply_policy_default_values DataDatabricksJob#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#autotermination_minutes DataDatabricksJob#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_id DataDatabricksJob#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_name DataDatabricksJob#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#custom_tags DataDatabricksJob#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#data_security_mode DataDatabricksJob#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#driver_instance_pool_id DataDatabricksJob#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#driver_node_type_id DataDatabricksJob#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_elastic_disk DataDatabricksJob#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_local_disk_encryption DataDatabricksJob#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#idempotency_token DataDatabricksJob#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#instance_pool_id DataDatabricksJob#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#node_type_id DataDatabricksJob#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#num_workers DataDatabricksJob#num_workers}
    */
    readonly numWorkers: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#policy_id DataDatabricksJob#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#runtime_engine DataDatabricksJob#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#single_user_name DataDatabricksJob#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_conf DataDatabricksJob#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_env_vars DataDatabricksJob#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_version DataDatabricksJob#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ssh_public_keys DataDatabricksJob#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#autoscale DataDatabricksJob#autoscale}
    */
    readonly autoscale?: DataDatabricksJobJobSettingsSettingsNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#aws_attributes DataDatabricksJob#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#azure_attributes DataDatabricksJob#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_log_conf DataDatabricksJob#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_mount_info DataDatabricksJob#cluster_mount_info}
    */
    readonly clusterMountInfo?: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#docker_image DataDatabricksJob#docker_image}
    */
    readonly dockerImage?: DataDatabricksJobJobSettingsSettingsNewClusterDockerImage;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#gcp_attributes DataDatabricksJob#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#init_scripts DataDatabricksJob#init_scripts}
    */
    readonly initScripts?: DataDatabricksJobJobSettingsSettingsNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workload_type DataDatabricksJob#workload_type}
    */
    readonly workloadType?: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType;
}
export declare function dataDatabricksJobJobSettingsSettingsNewClusterToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsNewCluster): any;
export declare function dataDatabricksJobJobSettingsSettingsNewClusterToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsNewCluster): any;
export declare class DataDatabricksJobJobSettingsSettingsNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNewCluster | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNewCluster | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _autoscale;
    get autoscale(): DataDatabricksJobJobSettingsSettingsNewClusterAutoscaleOutputReference;
    putAutoscale(value: DataDatabricksJobJobSettingsSettingsNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): DataDatabricksJobJobSettingsSettingsNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): DataDatabricksJobJobSettingsSettingsNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): DataDatabricksJobJobSettingsSettingsNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): DataDatabricksJobJobSettingsSettingsNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfoList;
    putClusterMountInfo(value: DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksJobJobSettingsSettingsNewClusterDockerImageOutputReference;
    putDockerImage(value: DataDatabricksJobJobSettingsSettingsNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): DataDatabricksJobJobSettingsSettingsNewClusterDockerImage | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): DataDatabricksJobJobSettingsSettingsNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksJobJobSettingsSettingsNewClusterInitScriptsList;
    putInitScripts(value: DataDatabricksJobJobSettingsSettingsNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsNewClusterInitScripts[] | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksJobJobSettingsSettingsNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): DataDatabricksJobJobSettingsSettingsNewClusterWorkloadType | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#base_parameters DataDatabricksJob#base_parameters}
    */
    readonly baseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#notebook_path DataDatabricksJob#notebook_path}
    */
    readonly notebookPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsNotebookTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNotebookTaskOutputReference | DataDatabricksJobJobSettingsSettingsNotebookTask): any;
export declare function dataDatabricksJobJobSettingsSettingsNotebookTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNotebookTaskOutputReference | DataDatabricksJobJobSettingsSettingsNotebookTask): any;
export declare class DataDatabricksJobJobSettingsSettingsNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNotebookTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNotebookTask | undefined);
    private _baseParameters?;
    get baseParameters(): {
        [key: string]: string;
    };
    set baseParameters(value: {
        [key: string]: string;
    });
    resetBaseParameters(): void;
    get baseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    get notebookPathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#no_alert_for_canceled_runs DataDatabricksJob#no_alert_for_canceled_runs}
    */
    readonly noAlertForCanceledRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#no_alert_for_skipped_runs DataDatabricksJob#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsNotificationSettingsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsNotificationSettingsOutputReference | DataDatabricksJobJobSettingsSettingsNotificationSettings): any;
export declare function dataDatabricksJobJobSettingsSettingsNotificationSettingsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsNotificationSettingsOutputReference | DataDatabricksJobJobSettingsSettingsNotificationSettings): any;
export declare class DataDatabricksJobJobSettingsSettingsNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsNotificationSettings | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsNotificationSettings | undefined);
    private _noAlertForCanceledRuns?;
    get noAlertForCanceledRuns(): boolean | cdktn.IResolvable;
    set noAlertForCanceledRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForCanceledRuns(): void;
    get noAlertForCanceledRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#default DataDatabricksJob#default}
    */
    readonly default: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#name DataDatabricksJob#name}
    */
    readonly name: string;
}
export declare function dataDatabricksJobJobSettingsSettingsParameterToTerraform(struct?: DataDatabricksJobJobSettingsSettingsParameter | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsParameterToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsParameter | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsParameter | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsParameter | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    get defaultInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsParameterList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsParameterOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsPipelineTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#full_refresh DataDatabricksJob#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#pipeline_id DataDatabricksJob#pipeline_id}
    */
    readonly pipelineId: string;
}
export declare function dataDatabricksJobJobSettingsSettingsPipelineTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsPipelineTaskOutputReference | DataDatabricksJobJobSettingsSettingsPipelineTask): any;
export declare function dataDatabricksJobJobSettingsSettingsPipelineTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsPipelineTaskOutputReference | DataDatabricksJobJobSettingsSettingsPipelineTask): any;
export declare class DataDatabricksJobJobSettingsSettingsPipelineTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsPipelineTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsPipelineTask | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsPythonWheelTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#entry_point DataDatabricksJob#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#named_parameters DataDatabricksJob#named_parameters}
    */
    readonly namedParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#package_name DataDatabricksJob#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsPythonWheelTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsPythonWheelTaskOutputReference | DataDatabricksJobJobSettingsSettingsPythonWheelTask): any;
export declare function dataDatabricksJobJobSettingsSettingsPythonWheelTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsPythonWheelTaskOutputReference | DataDatabricksJobJobSettingsSettingsPythonWheelTask): any;
export declare class DataDatabricksJobJobSettingsSettingsPythonWheelTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsPythonWheelTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsPythonWheelTask | undefined);
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _namedParameters?;
    get namedParameters(): {
        [key: string]: string;
    };
    set namedParameters(value: {
        [key: string]: string;
    });
    resetNamedParameters(): void;
    get namedParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsQueue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enabled DataDatabricksJob#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsQueueToTerraform(struct?: DataDatabricksJobJobSettingsSettingsQueueOutputReference | DataDatabricksJobJobSettingsSettingsQueue): any;
export declare function dataDatabricksJobJobSettingsSettingsQueueToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsQueueOutputReference | DataDatabricksJobJobSettingsSettingsQueue): any;
export declare class DataDatabricksJobJobSettingsSettingsQueueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsQueue | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsQueue | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#service_principal_name DataDatabricksJob#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#user_name DataDatabricksJob#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsRunAsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsRunAsOutputReference | DataDatabricksJobJobSettingsSettingsRunAs): any;
export declare function dataDatabricksJobJobSettingsSettingsRunAsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsRunAsOutputReference | DataDatabricksJobJobSettingsSettingsRunAs): any;
export declare class DataDatabricksJobJobSettingsSettingsRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsRunAs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsRunAs | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsRunJobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#job_id DataDatabricksJob#job_id}
    */
    readonly jobId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#job_parameters DataDatabricksJob#job_parameters}
    */
    readonly jobParameters?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksJobJobSettingsSettingsRunJobTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsRunJobTaskOutputReference | DataDatabricksJobJobSettingsSettingsRunJobTask): any;
export declare function dataDatabricksJobJobSettingsSettingsRunJobTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsRunJobTaskOutputReference | DataDatabricksJobJobSettingsSettingsRunJobTask): any;
export declare class DataDatabricksJobJobSettingsSettingsRunJobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsRunJobTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsRunJobTask | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    private _jobParameters?;
    get jobParameters(): {
        [key: string]: string;
    };
    set jobParameters(value: {
        [key: string]: string;
    });
    resetJobParameters(): void;
    get jobParametersInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#pause_status DataDatabricksJob#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#quartz_cron_expression DataDatabricksJob#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#timezone_id DataDatabricksJob#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function dataDatabricksJobJobSettingsSettingsScheduleToTerraform(struct?: DataDatabricksJobJobSettingsSettingsScheduleOutputReference | DataDatabricksJobJobSettingsSettingsSchedule): any;
export declare function dataDatabricksJobJobSettingsSettingsScheduleToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsScheduleOutputReference | DataDatabricksJobJobSettingsSettingsSchedule): any;
export declare class DataDatabricksJobJobSettingsSettingsScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsSchedule | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsSchedule | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsSparkJarTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#jar_uri DataDatabricksJob#jar_uri}
    */
    readonly jarUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#main_class_name DataDatabricksJob#main_class_name}
    */
    readonly mainClassName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsSparkJarTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsSparkJarTaskOutputReference | DataDatabricksJobJobSettingsSettingsSparkJarTask): any;
export declare function dataDatabricksJobJobSettingsSettingsSparkJarTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsSparkJarTaskOutputReference | DataDatabricksJobJobSettingsSettingsSparkJarTask): any;
export declare class DataDatabricksJobJobSettingsSettingsSparkJarTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsSparkJarTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsSparkJarTask | undefined);
    private _jarUri?;
    get jarUri(): string;
    set jarUri(value: string);
    resetJarUri(): void;
    get jarUriInput(): string | undefined;
    private _mainClassName?;
    get mainClassName(): string;
    set mainClassName(value: string);
    resetMainClassName(): void;
    get mainClassNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsSparkPythonTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#python_file DataDatabricksJob#python_file}
    */
    readonly pythonFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsSparkPythonTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsSparkPythonTaskOutputReference | DataDatabricksJobJobSettingsSettingsSparkPythonTask): any;
export declare function dataDatabricksJobJobSettingsSettingsSparkPythonTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsSparkPythonTaskOutputReference | DataDatabricksJobJobSettingsSettingsSparkPythonTask): any;
export declare class DataDatabricksJobJobSettingsSettingsSparkPythonTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsSparkPythonTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsSparkPythonTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pythonFile?;
    get pythonFile(): string;
    set pythonFile(value: string);
    get pythonFileInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsSparkSubmitTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsSparkSubmitTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsSparkSubmitTaskOutputReference | DataDatabricksJobJobSettingsSettingsSparkSubmitTask): any;
export declare function dataDatabricksJobJobSettingsSettingsSparkSubmitTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsSparkSubmitTaskOutputReference | DataDatabricksJobJobSettingsSettingsSparkSubmitTask): any;
export declare class DataDatabricksJobJobSettingsSettingsSparkSubmitTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsSparkSubmitTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsSparkSubmitTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskConditionTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#left DataDatabricksJob#left}
    */
    readonly left: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#op DataDatabricksJob#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#right DataDatabricksJob#right}
    */
    readonly right: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskConditionTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskConditionTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskConditionTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskConditionTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskConditionTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskConditionTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskConditionTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskConditionTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskConditionTask | undefined);
    private _left?;
    get left(): string;
    set left(value: string);
    get leftInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _right?;
    get right(): string;
    set right(value: string);
    get rightInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination_id DataDatabricksJob#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#user_name DataDatabricksJob#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribersToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribersToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribersOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#custom_subject DataDatabricksJob#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#paused DataDatabricksJob#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * subscribers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#subscribers DataDatabricksJob#subscribers}
    */
    readonly subscribers?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionOutputReference | DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionOutputReference | DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _subscribers;
    get subscribers(): DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribersList;
    putSubscribers(value: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable): void;
    resetSubscribers(): void;
    get subscribersInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionSubscribers[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskDashboardTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dashboard_id DataDatabricksJob#dashboard_id}
    */
    readonly dashboardId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#filters DataDatabricksJob#filters}
    */
    readonly filters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#subscription DataDatabricksJob#subscription}
    */
    readonly subscription?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskDashboardTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskDashboardTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskDashboardTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskDashboardTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskDashboardTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskDashboardTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskDashboardTask | undefined);
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    resetDashboardId(): void;
    get dashboardIdInput(): string | undefined;
    private _filters?;
    get filters(): {
        [key: string]: string;
    };
    set filters(value: {
        [key: string]: string;
    });
    resetFilters(): void;
    get filtersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _subscription;
    get subscription(): DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscriptionOutputReference;
    putSubscription(value: DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription): void;
    resetSubscription(): void;
    get subscriptionInput(): DataDatabricksJobJobSettingsSettingsTaskDashboardTaskSubscription | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskDbtTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#catalog DataDatabricksJob#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#commands DataDatabricksJob#commands}
    */
    readonly commands: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#profiles_directory DataDatabricksJob#profiles_directory}
    */
    readonly profilesDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#project_directory DataDatabricksJob#project_directory}
    */
    readonly projectDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#schema DataDatabricksJob#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskDbtTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDbtTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskDbtTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskDbtTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDbtTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskDbtTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskDbtTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskDbtTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskDbtTask | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    get commandsInput(): string[] | undefined;
    private _profilesDirectory?;
    get profilesDirectory(): string;
    set profilesDirectory(value: string);
    resetProfilesDirectory(): void;
    get profilesDirectoryInput(): string | undefined;
    private _projectDirectory?;
    get projectDirectory(): string;
    set projectDirectory(value: string);
    resetProjectDirectory(): void;
    get projectDirectoryInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskDependsOn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#outcome DataDatabricksJob#outcome}
    */
    readonly outcome?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#task_key DataDatabricksJob#task_key}
    */
    readonly taskKey: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskDependsOnToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDependsOn | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskDependsOnToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskDependsOn | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskDependsOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskDependsOn | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskDependsOn | cdktn.IResolvable | undefined);
    private _outcome?;
    get outcome(): string;
    set outcome(value: string);
    resetOutcome(): void;
    get outcomeInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskDependsOnList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskDependsOn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskDependsOnOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#no_alert_for_skipped_runs DataDatabricksJob#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_duration_warning_threshold_exceeded DataDatabricksJob#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_failure DataDatabricksJob#on_failure}
    */
    readonly onFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_start DataDatabricksJob#on_start}
    */
    readonly onStart?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_streaming_backlog_exceeded DataDatabricksJob#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_success DataDatabricksJob#on_success}
    */
    readonly onSuccess?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskEmailNotificationsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskEmailNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskEmailNotifications): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskEmailNotificationsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskEmailNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskEmailNotifications): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskEmailNotifications | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskEmailNotifications | undefined);
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _onDurationWarningThresholdExceeded?;
    get onDurationWarningThresholdExceeded(): string[];
    set onDurationWarningThresholdExceeded(value: string[]);
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): string[] | undefined;
    private _onFailure?;
    get onFailure(): string[];
    set onFailure(value: string[]);
    resetOnFailure(): void;
    get onFailureInput(): string[] | undefined;
    private _onStart?;
    get onStart(): string[];
    set onStart(value: string[]);
    resetOnStart(): void;
    get onStartInput(): string[] | undefined;
    private _onStreamingBacklogExceeded?;
    get onStreamingBacklogExceeded(): string[];
    set onStreamingBacklogExceeded(value: string[]);
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): string[] | undefined;
    private _onSuccess?;
    get onSuccess(): string[];
    set onSuccess(value: string[]);
    resetOnSuccess(): void;
    get onSuccessInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#left DataDatabricksJob#left}
    */
    readonly left: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#op DataDatabricksJob#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#right DataDatabricksJob#right}
    */
    readonly right: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskConditionTask | undefined);
    private _left?;
    get left(): string;
    set left(value: string);
    get leftInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _right?;
    get right(): string;
    set right(value: string);
    get rightInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination_id DataDatabricksJob#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#user_name DataDatabricksJob#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#custom_subject DataDatabricksJob#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#paused DataDatabricksJob#paused}
    */
    readonly paused?: boolean | cdktn.IResolvable;
    /**
    * subscribers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#subscribers DataDatabricksJob#subscribers}
    */
    readonly subscribers?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _paused?;
    get paused(): boolean | cdktn.IResolvable;
    set paused(value: boolean | cdktn.IResolvable);
    resetPaused(): void;
    get pausedInput(): boolean | cdktn.IResolvable | undefined;
    private _subscribers;
    get subscribers(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribersList;
    putSubscribers(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | cdktn.IResolvable): void;
    resetSubscribers(): void;
    get subscribersInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionSubscribers[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dashboard_id DataDatabricksJob#dashboard_id}
    */
    readonly dashboardId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#filters DataDatabricksJob#filters}
    */
    readonly filters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#subscription DataDatabricksJob#subscription}
    */
    readonly subscription?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTask | undefined);
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    resetDashboardId(): void;
    get dashboardIdInput(): string | undefined;
    private _filters?;
    get filters(): {
        [key: string]: string;
    };
    set filters(value: {
        [key: string]: string;
    });
    resetFilters(): void;
    get filtersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _subscription;
    get subscription(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscriptionOutputReference;
    putSubscription(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription): void;
    resetSubscription(): void;
    get subscriptionInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDashboardTaskSubscription | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#catalog DataDatabricksJob#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#commands DataDatabricksJob#commands}
    */
    readonly commands: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#profiles_directory DataDatabricksJob#profiles_directory}
    */
    readonly profilesDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#project_directory DataDatabricksJob#project_directory}
    */
    readonly projectDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#schema DataDatabricksJob#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDbtTask | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _commands?;
    get commands(): string[];
    set commands(value: string[]);
    get commandsInput(): string[] | undefined;
    private _profilesDirectory?;
    get profilesDirectory(): string;
    set profilesDirectory(value: string);
    resetProfilesDirectory(): void;
    get profilesDirectoryInput(): string | undefined;
    private _projectDirectory?;
    get projectDirectory(): string;
    set projectDirectory(value: string);
    resetProjectDirectory(): void;
    get projectDirectoryInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#outcome DataDatabricksJob#outcome}
    */
    readonly outcome?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#task_key DataDatabricksJob#task_key}
    */
    readonly taskKey: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOnToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOnToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn | cdktn.IResolvable | undefined);
    private _outcome?;
    get outcome(): string;
    set outcome(value: string);
    resetOutcome(): void;
    get outcomeInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOnList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskDependsOnOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#no_alert_for_skipped_runs DataDatabricksJob#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_duration_warning_threshold_exceeded DataDatabricksJob#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_failure DataDatabricksJob#on_failure}
    */
    readonly onFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_start DataDatabricksJob#on_start}
    */
    readonly onStart?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_streaming_backlog_exceeded DataDatabricksJob#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#on_success DataDatabricksJob#on_success}
    */
    readonly onSuccess?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotificationsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotificationsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotificationsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskEmailNotifications | undefined);
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _onDurationWarningThresholdExceeded?;
    get onDurationWarningThresholdExceeded(): string[];
    set onDurationWarningThresholdExceeded(value: string[]);
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): string[] | undefined;
    private _onFailure?;
    get onFailure(): string[];
    set onFailure(value: string[]);
    resetOnFailure(): void;
    get onFailureInput(): string[] | undefined;
    private _onStart?;
    get onStart(): string[];
    set onStart(value: string[]);
    resetOnStart(): void;
    get onStartInput(): string[] | undefined;
    private _onStreamingBacklogExceeded?;
    get onStreamingBacklogExceeded(): string[];
    set onStreamingBacklogExceeded(value: string[]);
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): string[] | undefined;
    private _onSuccess?;
    get onSuccess(): string[];
    set onSuccess(value: string[]);
    resetOnSuccess(): void;
    get onSuccessInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#metric DataDatabricksJob#metric}
    */
    readonly metric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#op DataDatabricksJob#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#value DataDatabricksJob#value}
    */
    readonly value: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRulesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRulesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules | cdktn.IResolvable | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRulesOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth {
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#rules DataDatabricksJob#rules}
    */
    readonly rules: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealth | undefined);
    private _rules;
    get rules(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRulesList;
    putRules(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskHealthRules[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#package DataDatabricksJob#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCranToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCranOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCranToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCranOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#coordinates DataDatabricksJob#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#exclusions DataDatabricksJob#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMavenToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMavenOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMavenToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMavenOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workspace_id DataDatabricksJob#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfigToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfigOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfigToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfigOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#package DataDatabricksJob#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#repo DataDatabricksJob#repo}
    */
    readonly repo?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypiToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypiOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypiToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypiOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#egg DataDatabricksJob#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#jar DataDatabricksJob#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#requirements DataDatabricksJob#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#whl DataDatabricksJob#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cran DataDatabricksJob#cran}
    */
    readonly cran?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#maven DataDatabricksJob#maven}
    */
    readonly maven?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#provider_config DataDatabricksJob#provider_config}
    */
    readonly providerConfig?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#pypi DataDatabricksJob#pypi}
    */
    readonly pypi?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCranOutputReference;
    putCran(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran): void;
    resetCran(): void;
    get cranInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryCran | undefined;
    private _maven;
    get maven(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMavenOutputReference;
    putMaven(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypiOutputReference;
    putPypi(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryPypi | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskLibraryOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#max_workers DataDatabricksJob#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#min_workers DataDatabricksJob#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscaleToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscaleToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscaleOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_count DataDatabricksJob#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_size DataDatabricksJob#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ebs_volume_type DataDatabricksJob#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#instance_profile_arn DataDatabricksJob#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spot_bid_price_percent DataDatabricksJob#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#first_on_demand DataDatabricksJob#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spot_bid_max_price DataDatabricksJob#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfS3 | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#mount_options DataDatabricksJob#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#server_address DataDatabricksJob#server_address}
    */
    readonly serverAddress: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#local_mount_dir_path DataDatabricksJob#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#remote_mount_dir_path DataDatabricksJob#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#network_filesystem_info DataDatabricksJob#network_filesystem_info}
    */
    readonly networkFilesystemInfo: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#password DataDatabricksJob#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#username DataDatabricksJob#username}
    */
    readonly username: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuthToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuthToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#url DataDatabricksJob#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#basic_auth DataDatabricksJob#basic_auth}
    */
    readonly basicAuth?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageBasicAuth | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#availability DataDatabricksJob#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#boot_disk_size DataDatabricksJob#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#google_service_account DataDatabricksJob#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#local_ssd_count DataDatabricksJob#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#use_preemptible_executors DataDatabricksJob#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#zone_id DataDatabricksJob#zone_id}
    */
    readonly zoneId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfssToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfssToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFileToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFileToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#canned_acl DataDatabricksJob#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_encryption DataDatabricksJob#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#encryption_type DataDatabricksJob#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#endpoint DataDatabricksJob#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#kms_key DataDatabricksJob#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#region DataDatabricksJob#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3ToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3ToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3 | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination DataDatabricksJob#destination}
    */
    readonly destination: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspaceToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspaceToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#abfss DataDatabricksJob#abfss}
    */
    readonly abfss?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#dbfs DataDatabricksJob#dbfs}
    */
    readonly dbfs?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#file DataDatabricksJob#file}
    */
    readonly file?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#gcs DataDatabricksJob#gcs}
    */
    readonly gcs?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#s3 DataDatabricksJob#s3}
    */
    readonly s3?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#volumes DataDatabricksJob#volumes}
    */
    readonly volumes?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workspace DataDatabricksJob#workspace}
    */
    readonly workspace?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference;
    putFile(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference;
    putGcs(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference;
    putS3(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsWorkspace | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#jobs DataDatabricksJob#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#notebooks DataDatabricksJob#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClientsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClientsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#clients DataDatabricksJob#clients}
    */
    readonly clients: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients): void;
    get clientsInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeClients | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#apply_policy_default_values DataDatabricksJob#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#autotermination_minutes DataDatabricksJob#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_id DataDatabricksJob#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_name DataDatabricksJob#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#custom_tags DataDatabricksJob#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#data_security_mode DataDatabricksJob#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#driver_instance_pool_id DataDatabricksJob#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#driver_node_type_id DataDatabricksJob#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_elastic_disk DataDatabricksJob#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#enable_local_disk_encryption DataDatabricksJob#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#idempotency_token DataDatabricksJob#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#instance_pool_id DataDatabricksJob#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#node_type_id DataDatabricksJob#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#num_workers DataDatabricksJob#num_workers}
    */
    readonly numWorkers: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#policy_id DataDatabricksJob#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#runtime_engine DataDatabricksJob#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#single_user_name DataDatabricksJob#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_conf DataDatabricksJob#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_env_vars DataDatabricksJob#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#spark_version DataDatabricksJob#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#ssh_public_keys DataDatabricksJob#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#autoscale DataDatabricksJob#autoscale}
    */
    readonly autoscale?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#aws_attributes DataDatabricksJob#aws_attributes}
    */
    readonly awsAttributes?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#azure_attributes DataDatabricksJob#azure_attributes}
    */
    readonly azureAttributes?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_log_conf DataDatabricksJob#cluster_log_conf}
    */
    readonly clusterLogConf?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#cluster_mount_info DataDatabricksJob#cluster_mount_info}
    */
    readonly clusterMountInfo?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#docker_image DataDatabricksJob#docker_image}
    */
    readonly dockerImage?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#gcp_attributes DataDatabricksJob#gcp_attributes}
    */
    readonly gcpAttributes?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#init_scripts DataDatabricksJob#init_scripts}
    */
    readonly initScripts?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workload_type DataDatabricksJob#workload_type}
    */
    readonly workloadType?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewCluster | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _autoscale;
    get autoscale(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscaleOutputReference;
    putAutoscale(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfoList;
    putClusterMountInfo(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImageOutputReference;
    putDockerImage(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterDockerImage | undefined;
    private _gcpAttributes;
    get gcpAttributes(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScriptsList;
    putInitScripts(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterInitScripts[] | undefined;
    private _workloadType;
    get workloadType(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNewClusterWorkloadType | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#base_parameters DataDatabricksJob#base_parameters}
    */
    readonly baseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#notebook_path DataDatabricksJob#notebook_path}
    */
    readonly notebookPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotebookTask | undefined);
    private _baseParameters?;
    get baseParameters(): {
        [key: string]: string;
    };
    set baseParameters(value: {
        [key: string]: string;
    });
    resetBaseParameters(): void;
    get baseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    get notebookPathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#alert_on_last_attempt DataDatabricksJob#alert_on_last_attempt}
    */
    readonly alertOnLastAttempt?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#no_alert_for_canceled_runs DataDatabricksJob#no_alert_for_canceled_runs}
    */
    readonly noAlertForCanceledRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#no_alert_for_skipped_runs DataDatabricksJob#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettingsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettingsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettingsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettingsOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskNotificationSettings | undefined);
    private _alertOnLastAttempt?;
    get alertOnLastAttempt(): boolean | cdktn.IResolvable;
    set alertOnLastAttempt(value: boolean | cdktn.IResolvable);
    resetAlertOnLastAttempt(): void;
    get alertOnLastAttemptInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForCanceledRuns?;
    get noAlertForCanceledRuns(): boolean | cdktn.IResolvable;
    set noAlertForCanceledRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForCanceledRuns(): void;
    get noAlertForCanceledRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#full_refresh DataDatabricksJob#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#pipeline_id DataDatabricksJob#pipeline_id}
    */
    readonly pipelineId: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPipelineTask | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#authentication_method DataDatabricksJob#authentication_method}
    */
    readonly authenticationMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#model_name DataDatabricksJob#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#overwrite_existing DataDatabricksJob#overwrite_existing}
    */
    readonly overwriteExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#storage_mode DataDatabricksJob#storage_mode}
    */
    readonly storageMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#workspace_name DataDatabricksJob#workspace_name}
    */
    readonly workspaceName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModelToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModelToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel | undefined);
    private _authenticationMethod?;
    get authenticationMethod(): string;
    set authenticationMethod(value: string);
    resetAuthenticationMethod(): void;
    get authenticationMethodInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _overwriteExisting?;
    get overwriteExisting(): boolean | cdktn.IResolvable;
    set overwriteExisting(value: boolean | cdktn.IResolvable);
    resetOverwriteExisting(): void;
    get overwriteExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
    private _workspaceName?;
    get workspaceName(): string;
    set workspaceName(value: string);
    resetWorkspaceName(): void;
    get workspaceNameInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#catalog DataDatabricksJob#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#name DataDatabricksJob#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#schema DataDatabricksJob#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#storage_mode DataDatabricksJob#storage_mode}
    */
    readonly storageMode?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTablesToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTablesToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTablesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTablesOutputReference;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#connection_resource_name DataDatabricksJob#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#refresh_after_update DataDatabricksJob#refresh_after_update}
    */
    readonly refreshAfterUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#warehouse_id DataDatabricksJob#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * power_bi_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#power_bi_model DataDatabricksJob#power_bi_model}
    */
    readonly powerBiModel?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel;
    /**
    * tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#tables DataDatabricksJob#tables}
    */
    readonly tables?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables[] | cdktn.IResolvable;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _refreshAfterUpdate?;
    get refreshAfterUpdate(): boolean | cdktn.IResolvable;
    set refreshAfterUpdate(value: boolean | cdktn.IResolvable);
    resetRefreshAfterUpdate(): void;
    get refreshAfterUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _powerBiModel;
    get powerBiModel(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference;
    putPowerBiModel(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel): void;
    resetPowerBiModel(): void;
    get powerBiModelInput(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskPowerBiModel | undefined;
    private _tables;
    get tables(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTablesList;
    putTables(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPowerBiTaskTables[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#entry_point DataDatabricksJob#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#named_parameters DataDatabricksJob#named_parameters}
    */
    readonly namedParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#package_name DataDatabricksJob#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskPythonWheelTask | undefined);
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _namedParameters?;
    get namedParameters(): {
        [key: string]: string;
    };
    set namedParameters(value: {
        [key: string]: string;
    });
    resetNamedParameters(): void;
    get namedParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#job_id DataDatabricksJob#job_id}
    */
    readonly jobId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#job_parameters DataDatabricksJob#job_parameters}
    */
    readonly jobParameters?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskRunJobTask | undefined);
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    private _jobParameters?;
    get jobParameters(): {
        [key: string]: string;
    };
    set jobParameters(value: {
        [key: string]: string;
    });
    resetJobParameters(): void;
    get jobParametersInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#jar_uri DataDatabricksJob#jar_uri}
    */
    readonly jarUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#main_class_name DataDatabricksJob#main_class_name}
    */
    readonly mainClassName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkJarTask | undefined);
    private _jarUri?;
    get jarUri(): string;
    set jarUri(value: string);
    resetJarUri(): void;
    get jarUriInput(): string | undefined;
    private _mainClassName?;
    get mainClassName(): string;
    set mainClassName(value: string);
    resetMainClassName(): void;
    get mainClassNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#python_file DataDatabricksJob#python_file}
    */
    readonly pythonFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#source DataDatabricksJob#source}
    */
    readonly source?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkPythonTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pythonFile?;
    get pythonFile(): string;
    set pythonFile(value: string);
    get pythonFileInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#parameters DataDatabricksJob#parameters}
    */
    readonly parameters?: string[];
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTaskToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTaskToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTaskOutputReference | DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSparkSubmitTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#destination_id DataDatabricksJob#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/job#user_name DataDatabricksJob#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptionsToTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare function dataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptionsToHclTerraform(struct?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksJobJobSettingsSettingsTaskForEachTaskTaskSqlTaskAlertSubscriptionsOutputReference;
}
