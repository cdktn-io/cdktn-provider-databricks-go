/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamWorkspaceAssignmentV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_assignment_v2#principal_id DataDatabricksWorkspaceIamWorkspaceAssignmentV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_assignment_v2#provider_config DataDatabricksWorkspaceIamWorkspaceAssignmentV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_assignment_v2#workspace_id DataDatabricksWorkspaceIamWorkspaceAssignmentV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_assignment_v2 databricks_workspace_iam_workspace_assignment_v2}
*/
export declare class DataDatabricksWorkspaceIamWorkspaceAssignmentV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_workspace_assignment_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamWorkspaceAssignmentV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamWorkspaceAssignmentV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamWorkspaceAssignmentV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_assignment_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamWorkspaceAssignmentV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_workspace_assignment_v2 databricks_workspace_iam_workspace_assignment_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamWorkspaceAssignmentV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamWorkspaceAssignmentV2Config);
    get accountId(): string;
    get effectiveEntitlements(): string[];
    get entitlements(): string[];
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamWorkspaceAssignmentV2ProviderConfig | undefined;
    get workspaceId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
