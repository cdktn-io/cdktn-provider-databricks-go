/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountIamUserV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/account_iam_user_v2#user_id DataDatabricksAccountIamUserV2#user_id}
    */
    readonly userId: string;
}
export interface DataDatabricksAccountIamUserV2FullName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/account_iam_user_v2#family_name DataDatabricksAccountIamUserV2#family_name}
    */
    readonly familyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/account_iam_user_v2#given_name DataDatabricksAccountIamUserV2#given_name}
    */
    readonly givenName?: string;
}
export declare function dataDatabricksAccountIamUserV2FullNameToTerraform(struct?: DataDatabricksAccountIamUserV2FullName): any;
export declare function dataDatabricksAccountIamUserV2FullNameToHclTerraform(struct?: DataDatabricksAccountIamUserV2FullName): any;
export declare class DataDatabricksAccountIamUserV2FullNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountIamUserV2FullName | undefined;
    set internalValue(value: DataDatabricksAccountIamUserV2FullName | undefined);
    private _familyName?;
    get familyName(): string;
    set familyName(value: string);
    resetFamilyName(): void;
    get familyNameInput(): string | undefined;
    private _givenName?;
    get givenName(): string;
    set givenName(value: string);
    resetGivenName(): void;
    get givenNameInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/account_iam_user_v2 databricks_account_iam_user_v2}
*/
export declare class DataDatabricksAccountIamUserV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_iam_user_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountIamUserV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountIamUserV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountIamUserV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/account_iam_user_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountIamUserV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/account_iam_user_v2 databricks_account_iam_user_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountIamUserV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountIamUserV2Config);
    get accountId(): string;
    get accountUserStatus(): string;
    get externalId(): string;
    private _fullName;
    get fullName(): DataDatabricksAccountIamUserV2FullNameOutputReference;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
