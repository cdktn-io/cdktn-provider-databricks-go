/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#apply_policy_default_values Cluster#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#autotermination_minutes Cluster#autotermination_minutes}
    */
    readonly autoterminationMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#clear_cloud_attributes_on_remove Cluster#clear_cloud_attributes_on_remove}
    */
    readonly clearCloudAttributesOnRemove?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#cluster_name Cluster#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#custom_tags Cluster#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#data_security_mode Cluster#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#dependency_mode Cluster#dependency_mode}
    */
    readonly dependencyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#driver_instance_pool_id Cluster#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#driver_node_type_id Cluster#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#enable_elastic_disk Cluster#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#enable_local_disk_encryption Cluster#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#id Cluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#idempotency_token Cluster#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#instance_pool_id Cluster#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#is_pinned Cluster#is_pinned}
    */
    readonly isPinned?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#is_single_node Cluster#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#kind Cluster#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#no_wait Cluster#no_wait}
    */
    readonly noWait?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#node_type_id Cluster#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#num_workers Cluster#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#policy_id Cluster#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#remote_disk_throughput Cluster#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#runtime_engine Cluster#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#single_user_name Cluster#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#spark_conf Cluster#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#spark_env_vars Cluster#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#spark_version Cluster#spark_version}
    */
    readonly sparkVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#ssh_public_keys Cluster#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#total_initial_remote_disk_size Cluster#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#use_ml_runtime Cluster#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#autoscale Cluster#autoscale}
    */
    readonly autoscale?: ClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#aws_attributes Cluster#aws_attributes}
    */
    readonly awsAttributes?: ClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#azure_attributes Cluster#azure_attributes}
    */
    readonly azureAttributes?: ClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#cluster_log_conf Cluster#cluster_log_conf}
    */
    readonly clusterLogConf?: ClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#cluster_mount_info Cluster#cluster_mount_info}
    */
    readonly clusterMountInfo?: ClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#docker_image Cluster#docker_image}
    */
    readonly dockerImage?: ClusterDockerImage;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#driver_node_type_flexibility Cluster#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: ClusterDriverNodeTypeFlexibility;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#gcp_attributes Cluster#gcp_attributes}
    */
    readonly gcpAttributes?: ClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#init_scripts Cluster#init_scripts}
    */
    readonly initScripts?: ClusterInitScripts[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#library Cluster#library}
    */
    readonly library?: ClusterLibrary[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#provider_config Cluster#provider_config}
    */
    readonly providerConfig?: ClusterProviderConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#timeouts Cluster#timeouts}
    */
    readonly timeouts?: ClusterTimeouts;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#worker_node_type_flexibility Cluster#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: ClusterWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#workload_type Cluster#workload_type}
    */
    readonly workloadType?: ClusterWorkloadType;
}
export interface ClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#max_workers Cluster#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#min_workers Cluster#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function clusterAutoscaleToTerraform(struct?: ClusterAutoscaleOutputReference | ClusterAutoscale): any;
export declare function clusterAutoscaleToHclTerraform(struct?: ClusterAutoscaleOutputReference | ClusterAutoscale): any;
export declare class ClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterAutoscale | undefined;
    set internalValue(value: ClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface ClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#availability Cluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#ebs_volume_count Cluster#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#ebs_volume_iops Cluster#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#ebs_volume_size Cluster#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#ebs_volume_throughput Cluster#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#ebs_volume_type Cluster#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#first_on_demand Cluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#instance_profile_arn Cluster#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#spot_bid_price_percent Cluster#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#zone_id Cluster#zone_id}
    */
    readonly zoneId?: string;
}
export declare function clusterAwsAttributesToTerraform(struct?: ClusterAwsAttributesOutputReference | ClusterAwsAttributes): any;
export declare function clusterAwsAttributesToHclTerraform(struct?: ClusterAwsAttributesOutputReference | ClusterAwsAttributes): any;
export declare class ClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterAwsAttributes | undefined;
    set internalValue(value: ClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface ClusterAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#log_analytics_primary_key Cluster#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#log_analytics_workspace_id Cluster#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function clusterAzureAttributesLogAnalyticsInfoToTerraform(struct?: ClusterAzureAttributesLogAnalyticsInfoOutputReference | ClusterAzureAttributesLogAnalyticsInfo): any;
export declare function clusterAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: ClusterAzureAttributesLogAnalyticsInfoOutputReference | ClusterAzureAttributesLogAnalyticsInfo): any;
export declare class ClusterAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: ClusterAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface ClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#availability Cluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#capacity_reservation_group Cluster#capacity_reservation_group}
    */
    readonly capacityReservationGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#first_on_demand Cluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#spot_bid_max_price Cluster#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#log_analytics_info Cluster#log_analytics_info}
    */
    readonly logAnalyticsInfo?: ClusterAzureAttributesLogAnalyticsInfo;
}
export declare function clusterAzureAttributesToTerraform(struct?: ClusterAzureAttributesOutputReference | ClusterAzureAttributes): any;
export declare function clusterAzureAttributesToHclTerraform(struct?: ClusterAzureAttributesOutputReference | ClusterAzureAttributes): any;
export declare class ClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterAzureAttributes | undefined;
    set internalValue(value: ClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _capacityReservationGroup?;
    get capacityReservationGroup(): string;
    set capacityReservationGroup(value: string);
    resetCapacityReservationGroup(): void;
    get capacityReservationGroupInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): ClusterAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: ClusterAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): ClusterAzureAttributesLogAnalyticsInfo | undefined;
}
export interface ClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterClusterLogConfDbfsToTerraform(struct?: ClusterClusterLogConfDbfsOutputReference | ClusterClusterLogConfDbfs): any;
export declare function clusterClusterLogConfDbfsToHclTerraform(struct?: ClusterClusterLogConfDbfsOutputReference | ClusterClusterLogConfDbfs): any;
export declare class ClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterClusterLogConfDbfs | undefined;
    set internalValue(value: ClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#canned_acl Cluster#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#enable_encryption Cluster#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#encryption_type Cluster#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#endpoint Cluster#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#kms_key Cluster#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#region Cluster#region}
    */
    readonly region?: string;
}
export declare function clusterClusterLogConfS3ToTerraform(struct?: ClusterClusterLogConfS3OutputReference | ClusterClusterLogConfS3): any;
export declare function clusterClusterLogConfS3ToHclTerraform(struct?: ClusterClusterLogConfS3OutputReference | ClusterClusterLogConfS3): any;
export declare class ClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterClusterLogConfS3 | undefined;
    set internalValue(value: ClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface ClusterClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterClusterLogConfVolumesToTerraform(struct?: ClusterClusterLogConfVolumesOutputReference | ClusterClusterLogConfVolumes): any;
export declare function clusterClusterLogConfVolumesToHclTerraform(struct?: ClusterClusterLogConfVolumesOutputReference | ClusterClusterLogConfVolumes): any;
export declare class ClusterClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterClusterLogConfVolumes | undefined;
    set internalValue(value: ClusterClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#dbfs Cluster#dbfs}
    */
    readonly dbfs?: ClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#s3 Cluster#s3}
    */
    readonly s3?: ClusterClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#volumes Cluster#volumes}
    */
    readonly volumes?: ClusterClusterLogConfVolumes;
}
export declare function clusterClusterLogConfToTerraform(struct?: ClusterClusterLogConfOutputReference | ClusterClusterLogConf): any;
export declare function clusterClusterLogConfToHclTerraform(struct?: ClusterClusterLogConfOutputReference | ClusterClusterLogConf): any;
export declare class ClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterClusterLogConf | undefined;
    set internalValue(value: ClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): ClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: ClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): ClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): ClusterClusterLogConfS3OutputReference;
    putS3(value: ClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): ClusterClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): ClusterClusterLogConfVolumesOutputReference;
    putVolumes(value: ClusterClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): ClusterClusterLogConfVolumes | undefined;
}
export interface ClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#mount_options Cluster#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#server_address Cluster#server_address}
    */
    readonly serverAddress: string;
}
export declare function clusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: ClusterClusterMountInfoNetworkFilesystemInfoOutputReference | ClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function clusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: ClusterClusterMountInfoNetworkFilesystemInfoOutputReference | ClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class ClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: ClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface ClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#local_mount_dir_path Cluster#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#remote_mount_dir_path Cluster#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#network_filesystem_info Cluster#network_filesystem_info}
    */
    readonly networkFilesystemInfo: ClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function clusterClusterMountInfoToTerraform(struct?: ClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function clusterClusterMountInfoToHclTerraform(struct?: ClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class ClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): ClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: ClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): ClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class ClusterClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: ClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterClusterMountInfoOutputReference;
}
export interface ClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#password Cluster#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#username Cluster#username}
    */
    readonly username: string;
}
export declare function clusterDockerImageBasicAuthToTerraform(struct?: ClusterDockerImageBasicAuthOutputReference | ClusterDockerImageBasicAuth): any;
export declare function clusterDockerImageBasicAuthToHclTerraform(struct?: ClusterDockerImageBasicAuthOutputReference | ClusterDockerImageBasicAuth): any;
export declare class ClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterDockerImageBasicAuth | undefined;
    set internalValue(value: ClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface ClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#url Cluster#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#basic_auth Cluster#basic_auth}
    */
    readonly basicAuth?: ClusterDockerImageBasicAuth;
}
export declare function clusterDockerImageToTerraform(struct?: ClusterDockerImageOutputReference | ClusterDockerImage): any;
export declare function clusterDockerImageToHclTerraform(struct?: ClusterDockerImageOutputReference | ClusterDockerImage): any;
export declare class ClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterDockerImage | undefined;
    set internalValue(value: ClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): ClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: ClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): ClusterDockerImageBasicAuth | undefined;
}
export interface ClusterDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#alternate_node_type_ids Cluster#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function clusterDriverNodeTypeFlexibilityToTerraform(struct?: ClusterDriverNodeTypeFlexibilityOutputReference | ClusterDriverNodeTypeFlexibility): any;
export declare function clusterDriverNodeTypeFlexibilityToHclTerraform(struct?: ClusterDriverNodeTypeFlexibilityOutputReference | ClusterDriverNodeTypeFlexibility): any;
export declare class ClusterDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterDriverNodeTypeFlexibility | undefined;
    set internalValue(value: ClusterDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface ClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#availability Cluster#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#boot_disk_size Cluster#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#confidential_compute_type Cluster#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#first_on_demand Cluster#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#google_service_account Cluster#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#local_ssd_count Cluster#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#use_preemptible_executors Cluster#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#zone_id Cluster#zone_id}
    */
    readonly zoneId?: string;
}
export declare function clusterGcpAttributesToTerraform(struct?: ClusterGcpAttributesOutputReference | ClusterGcpAttributes): any;
export declare function clusterGcpAttributesToHclTerraform(struct?: ClusterGcpAttributesOutputReference | ClusterGcpAttributes): any;
export declare class ClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterGcpAttributes | undefined;
    set internalValue(value: ClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface ClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterInitScriptsAbfssToTerraform(struct?: ClusterInitScriptsAbfssOutputReference | ClusterInitScriptsAbfss): any;
export declare function clusterInitScriptsAbfssToHclTerraform(struct?: ClusterInitScriptsAbfssOutputReference | ClusterInitScriptsAbfss): any;
export declare class ClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterInitScriptsAbfss | undefined;
    set internalValue(value: ClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterInitScriptsDbfsToTerraform(struct?: ClusterInitScriptsDbfsOutputReference | ClusterInitScriptsDbfs): any;
export declare function clusterInitScriptsDbfsToHclTerraform(struct?: ClusterInitScriptsDbfsOutputReference | ClusterInitScriptsDbfs): any;
export declare class ClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterInitScriptsDbfs | undefined;
    set internalValue(value: ClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterInitScriptsFileToTerraform(struct?: ClusterInitScriptsFileOutputReference | ClusterInitScriptsFile): any;
export declare function clusterInitScriptsFileToHclTerraform(struct?: ClusterInitScriptsFileOutputReference | ClusterInitScriptsFile): any;
export declare class ClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterInitScriptsFile | undefined;
    set internalValue(value: ClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterInitScriptsGcsToTerraform(struct?: ClusterInitScriptsGcsOutputReference | ClusterInitScriptsGcs): any;
export declare function clusterInitScriptsGcsToHclTerraform(struct?: ClusterInitScriptsGcsOutputReference | ClusterInitScriptsGcs): any;
export declare class ClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterInitScriptsGcs | undefined;
    set internalValue(value: ClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#canned_acl Cluster#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#enable_encryption Cluster#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#encryption_type Cluster#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#endpoint Cluster#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#kms_key Cluster#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#region Cluster#region}
    */
    readonly region?: string;
}
export declare function clusterInitScriptsS3ToTerraform(struct?: ClusterInitScriptsS3OutputReference | ClusterInitScriptsS3): any;
export declare function clusterInitScriptsS3ToHclTerraform(struct?: ClusterInitScriptsS3OutputReference | ClusterInitScriptsS3): any;
export declare class ClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterInitScriptsS3 | undefined;
    set internalValue(value: ClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface ClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterInitScriptsVolumesToTerraform(struct?: ClusterInitScriptsVolumesOutputReference | ClusterInitScriptsVolumes): any;
export declare function clusterInitScriptsVolumesToHclTerraform(struct?: ClusterInitScriptsVolumesOutputReference | ClusterInitScriptsVolumes): any;
export declare class ClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterInitScriptsVolumes | undefined;
    set internalValue(value: ClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#destination Cluster#destination}
    */
    readonly destination: string;
}
export declare function clusterInitScriptsWorkspaceToTerraform(struct?: ClusterInitScriptsWorkspaceOutputReference | ClusterInitScriptsWorkspace): any;
export declare function clusterInitScriptsWorkspaceToHclTerraform(struct?: ClusterInitScriptsWorkspaceOutputReference | ClusterInitScriptsWorkspace): any;
export declare class ClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterInitScriptsWorkspace | undefined;
    set internalValue(value: ClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface ClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#abfss Cluster#abfss}
    */
    readonly abfss?: ClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#dbfs Cluster#dbfs}
    */
    readonly dbfs?: ClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#file Cluster#file}
    */
    readonly file?: ClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#gcs Cluster#gcs}
    */
    readonly gcs?: ClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#s3 Cluster#s3}
    */
    readonly s3?: ClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#volumes Cluster#volumes}
    */
    readonly volumes?: ClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#workspace Cluster#workspace}
    */
    readonly workspace?: ClusterInitScriptsWorkspace;
}
export declare function clusterInitScriptsToTerraform(struct?: ClusterInitScripts | cdktn.IResolvable): any;
export declare function clusterInitScriptsToHclTerraform(struct?: ClusterInitScripts | cdktn.IResolvable): any;
export declare class ClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): ClusterInitScriptsAbfssOutputReference;
    putAbfss(value: ClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): ClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): ClusterInitScriptsDbfsOutputReference;
    putDbfs(value: ClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): ClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): ClusterInitScriptsFileOutputReference;
    putFile(value: ClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): ClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): ClusterInitScriptsGcsOutputReference;
    putGcs(value: ClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): ClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): ClusterInitScriptsS3OutputReference;
    putS3(value: ClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): ClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): ClusterInitScriptsVolumesOutputReference;
    putVolumes(value: ClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): ClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): ClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: ClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): ClusterInitScriptsWorkspace | undefined;
}
export declare class ClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: ClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterInitScriptsOutputReference;
}
export interface ClusterLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#package Cluster#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#repo Cluster#repo}
    */
    readonly repo?: string;
}
export declare function clusterLibraryCranToTerraform(struct?: ClusterLibraryCranOutputReference | ClusterLibraryCran): any;
export declare function clusterLibraryCranToHclTerraform(struct?: ClusterLibraryCranOutputReference | ClusterLibraryCran): any;
export declare class ClusterLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterLibraryCran | undefined;
    set internalValue(value: ClusterLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface ClusterLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#coordinates Cluster#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#exclusions Cluster#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#repo Cluster#repo}
    */
    readonly repo?: string;
}
export declare function clusterLibraryMavenToTerraform(struct?: ClusterLibraryMavenOutputReference | ClusterLibraryMaven): any;
export declare function clusterLibraryMavenToHclTerraform(struct?: ClusterLibraryMavenOutputReference | ClusterLibraryMaven): any;
export declare class ClusterLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterLibraryMaven | undefined;
    set internalValue(value: ClusterLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface ClusterLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#package Cluster#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#repo Cluster#repo}
    */
    readonly repo?: string;
}
export declare function clusterLibraryPypiToTerraform(struct?: ClusterLibraryPypiOutputReference | ClusterLibraryPypi): any;
export declare function clusterLibraryPypiToHclTerraform(struct?: ClusterLibraryPypiOutputReference | ClusterLibraryPypi): any;
export declare class ClusterLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterLibraryPypi | undefined;
    set internalValue(value: ClusterLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface ClusterLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#egg Cluster#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#jar Cluster#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#requirements Cluster#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#whl Cluster#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#cran Cluster#cran}
    */
    readonly cran?: ClusterLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#maven Cluster#maven}
    */
    readonly maven?: ClusterLibraryMaven;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#pypi Cluster#pypi}
    */
    readonly pypi?: ClusterLibraryPypi;
}
export declare function clusterLibraryToTerraform(struct?: ClusterLibrary | cdktn.IResolvable): any;
export declare function clusterLibraryToHclTerraform(struct?: ClusterLibrary | cdktn.IResolvable): any;
export declare class ClusterLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ClusterLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): ClusterLibraryCranOutputReference;
    putCran(value: ClusterLibraryCran): void;
    resetCran(): void;
    get cranInput(): ClusterLibraryCran | undefined;
    private _maven;
    get maven(): ClusterLibraryMavenOutputReference;
    putMaven(value: ClusterLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): ClusterLibraryMaven | undefined;
    private _pypi;
    get pypi(): ClusterLibraryPypiOutputReference;
    putPypi(value: ClusterLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): ClusterLibraryPypi | undefined;
}
export declare class ClusterLibraryList extends cdktn.ComplexList {
    internalValue?: ClusterLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ClusterLibraryOutputReference;
}
export interface ClusterProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#workspace_id Cluster#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function clusterProviderConfigToTerraform(struct?: ClusterProviderConfigOutputReference | ClusterProviderConfig): any;
export declare function clusterProviderConfigToHclTerraform(struct?: ClusterProviderConfigOutputReference | ClusterProviderConfig): any;
export declare class ClusterProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterProviderConfig | undefined;
    set internalValue(value: ClusterProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface ClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#create Cluster#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#delete Cluster#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#update Cluster#update}
    */
    readonly update?: string;
}
export declare function clusterTimeoutsToTerraform(struct?: ClusterTimeouts | cdktn.IResolvable): any;
export declare function clusterTimeoutsToHclTerraform(struct?: ClusterTimeouts | cdktn.IResolvable): any;
export declare class ClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ClusterTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ClusterWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#alternate_node_type_ids Cluster#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function clusterWorkerNodeTypeFlexibilityToTerraform(struct?: ClusterWorkerNodeTypeFlexibilityOutputReference | ClusterWorkerNodeTypeFlexibility): any;
export declare function clusterWorkerNodeTypeFlexibilityToHclTerraform(struct?: ClusterWorkerNodeTypeFlexibilityOutputReference | ClusterWorkerNodeTypeFlexibility): any;
export declare class ClusterWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: ClusterWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface ClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#jobs Cluster#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#notebooks Cluster#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function clusterWorkloadTypeClientsToTerraform(struct?: ClusterWorkloadTypeClientsOutputReference | ClusterWorkloadTypeClients): any;
export declare function clusterWorkloadTypeClientsToHclTerraform(struct?: ClusterWorkloadTypeClientsOutputReference | ClusterWorkloadTypeClients): any;
export declare class ClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterWorkloadTypeClients | undefined;
    set internalValue(value: ClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#clients Cluster#clients}
    */
    readonly clients: ClusterWorkloadTypeClients;
}
export declare function clusterWorkloadTypeToTerraform(struct?: ClusterWorkloadTypeOutputReference | ClusterWorkloadType): any;
export declare function clusterWorkloadTypeToHclTerraform(struct?: ClusterWorkloadTypeOutputReference | ClusterWorkloadType): any;
export declare class ClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClusterWorkloadType | undefined;
    set internalValue(value: ClusterWorkloadType | undefined);
    private _clients;
    get clients(): ClusterWorkloadTypeClientsOutputReference;
    putClients(value: ClusterWorkloadTypeClients): void;
    get clientsInput(): ClusterWorkloadTypeClients | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster databricks_cluster}
*/
export declare class Cluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_cluster";
    /**
    * Generates CDKTN code for importing a Cluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Cluster to import
    * @param importFromId The id of the existing Cluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Cluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/cluster databricks_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClusterConfig
    */
    constructor(scope: Construct, id: string, config: ClusterConfig);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _autoterminationMinutes?;
    get autoterminationMinutes(): number;
    set autoterminationMinutes(value: number);
    resetAutoterminationMinutes(): void;
    get autoterminationMinutesInput(): number | undefined;
    private _clearCloudAttributesOnRemove?;
    get clearCloudAttributesOnRemove(): boolean | cdktn.IResolvable;
    set clearCloudAttributesOnRemove(value: boolean | cdktn.IResolvable);
    resetClearCloudAttributesOnRemove(): void;
    get clearCloudAttributesOnRemoveInput(): boolean | cdktn.IResolvable | undefined;
    get clusterId(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _defaultTags;
    get defaultTags(): cdktn.StringMap;
    private _dependencyMode?;
    get dependencyMode(): string;
    set dependencyMode(value: string);
    resetDependencyMode(): void;
    get dependencyModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isPinned?;
    get isPinned(): boolean | cdktn.IResolvable;
    set isPinned(value: boolean | cdktn.IResolvable);
    resetIsPinned(): void;
    get isPinnedInput(): boolean | cdktn.IResolvable | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _noWait?;
    get noWait(): boolean | cdktn.IResolvable;
    set noWait(value: boolean | cdktn.IResolvable);
    resetNoWait(): void;
    get noWaitInput(): boolean | cdktn.IResolvable | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    get state(): string;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    get url(): string;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): ClusterAutoscaleOutputReference;
    putAutoscale(value: ClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): ClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): ClusterAwsAttributesOutputReference;
    putAwsAttributes(value: ClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): ClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): ClusterAzureAttributesOutputReference;
    putAzureAttributes(value: ClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): ClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): ClusterClusterLogConfOutputReference;
    putClusterLogConf(value: ClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): ClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): ClusterClusterMountInfoList;
    putClusterMountInfo(value: ClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | ClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): ClusterDockerImageOutputReference;
    putDockerImage(value: ClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): ClusterDockerImage | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): ClusterDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: ClusterDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): ClusterDriverNodeTypeFlexibility | undefined;
    private _gcpAttributes;
    get gcpAttributes(): ClusterGcpAttributesOutputReference;
    putGcpAttributes(value: ClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): ClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): ClusterInitScriptsList;
    putInitScripts(value: ClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | ClusterInitScripts[] | undefined;
    private _library;
    get library(): ClusterLibraryList;
    putLibrary(value: ClusterLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | ClusterLibrary[] | undefined;
    private _providerConfig;
    get providerConfig(): ClusterProviderConfigOutputReference;
    putProviderConfig(value: ClusterProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ClusterProviderConfig | undefined;
    private _timeouts;
    get timeouts(): ClusterTimeoutsOutputReference;
    putTimeouts(value: ClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ClusterTimeouts | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): ClusterWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: ClusterWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): ClusterWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): ClusterWorkloadTypeOutputReference;
    putWorkloadType(value: ClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): ClusterWorkloadType | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
