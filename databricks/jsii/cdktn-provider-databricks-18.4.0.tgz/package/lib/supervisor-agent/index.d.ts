/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SupervisorAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent#description SupervisorAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent#display_name SupervisorAgent#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent#instructions SupervisorAgent#instructions}
    */
    readonly instructions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent#provider_config SupervisorAgent#provider_config}
    */
    readonly providerConfig?: SupervisorAgentProviderConfig;
}
export interface SupervisorAgentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent#workspace_id SupervisorAgent#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function supervisorAgentProviderConfigToTerraform(struct?: SupervisorAgentProviderConfig | cdktn.IResolvable): any;
export declare function supervisorAgentProviderConfigToHclTerraform(struct?: SupervisorAgentProviderConfig | cdktn.IResolvable): any;
export declare class SupervisorAgentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SupervisorAgentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: SupervisorAgentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent databricks_supervisor_agent}
*/
export declare class SupervisorAgent extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_supervisor_agent";
    /**
    * Generates CDKTN code for importing a SupervisorAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SupervisorAgent to import
    * @param importFromId The id of the existing SupervisorAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SupervisorAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/supervisor_agent databricks_supervisor_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SupervisorAgentConfig
    */
    constructor(scope: Construct, id: string, config: SupervisorAgentConfig);
    get createTime(): string;
    get creator(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get endpointName(): string;
    get experimentId(): string;
    get id(): string;
    private _instructions?;
    get instructions(): string;
    set instructions(value: string);
    resetInstructions(): void;
    get instructionsInput(): string | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): SupervisorAgentProviderConfigOutputReference;
    putProviderConfig(value: SupervisorAgentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | SupervisorAgentProviderConfig | undefined;
    get supervisorAgentId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
