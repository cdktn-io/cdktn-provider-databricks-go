/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AiGatewayMcpServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#comment AiGatewayMcpService#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#config AiGatewayMcpService#config}
    */
    readonly config?: AiGatewayMcpServiceConfigA;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#mcp_service_id AiGatewayMcpService#mcp_service_id}
    */
    readonly mcpServiceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#owner AiGatewayMcpService#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#parent AiGatewayMcpService#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#provider_config AiGatewayMcpService#provider_config}
    */
    readonly providerConfig?: AiGatewayMcpServiceProviderConfig;
}
export interface AiGatewayMcpServiceConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#key AiGatewayMcpService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#principal AiGatewayMcpService#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#renewal_period AiGatewayMcpService#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#request_tag_key AiGatewayMcpService#request_tag_key}
    */
    readonly requestTagKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#request_tag_value AiGatewayMcpService#request_tag_value}
    */
    readonly requestTagValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#requests AiGatewayMcpService#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#tokens AiGatewayMcpService#tokens}
    */
    readonly tokens?: number;
}
export declare function aiGatewayMcpServiceConfigRateLimitsToTerraform(struct?: AiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable): any;
export declare function aiGatewayMcpServiceConfigRateLimitsToHclTerraform(struct?: AiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable): any;
export declare class AiGatewayMcpServiceConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requestTagKey?;
    get requestTagKey(): string;
    set requestTagKey(value: string);
    resetRequestTagKey(): void;
    get requestTagKeyInput(): string | undefined;
    private _requestTagValue?;
    get requestTagValue(): string;
    set requestTagValue(value: string);
    resetRequestTagValue(): void;
    get requestTagValueInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class AiGatewayMcpServiceConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: AiGatewayMcpServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AiGatewayMcpServiceConfigRateLimitsOutputReference;
}
export interface AiGatewayMcpServiceConfigSourceConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#name AiGatewayMcpService#name}
    */
    readonly name: string;
}
export declare function aiGatewayMcpServiceConfigSourceConnectionToTerraform(struct?: AiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable): any;
export declare function aiGatewayMcpServiceConfigSourceConnectionToHclTerraform(struct?: AiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable): any;
export declare class AiGatewayMcpServiceConfigSourceConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable | undefined);
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface AiGatewayMcpServiceConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#include_tool_selectors AiGatewayMcpService#include_tool_selectors}
    */
    readonly includeToolSelectors?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#rate_limits AiGatewayMcpService#rate_limits}
    */
    readonly rateLimits?: AiGatewayMcpServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#source_connection AiGatewayMcpService#source_connection}
    */
    readonly sourceConnection?: AiGatewayMcpServiceConfigSourceConnection;
}
export declare function aiGatewayMcpServiceConfigAToTerraform(struct?: AiGatewayMcpServiceConfigA | cdktn.IResolvable): any;
export declare function aiGatewayMcpServiceConfigAToHclTerraform(struct?: AiGatewayMcpServiceConfigA | cdktn.IResolvable): any;
export declare class AiGatewayMcpServiceConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayMcpServiceConfigA | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayMcpServiceConfigA | cdktn.IResolvable | undefined);
    private _includeToolSelectors?;
    get includeToolSelectors(): string[];
    set includeToolSelectors(value: string[]);
    resetIncludeToolSelectors(): void;
    get includeToolSelectorsInput(): string[] | undefined;
    private _rateLimits;
    get rateLimits(): AiGatewayMcpServiceConfigRateLimitsList;
    putRateLimits(value: AiGatewayMcpServiceConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | AiGatewayMcpServiceConfigRateLimits[] | undefined;
    private _sourceConnection;
    get sourceConnection(): AiGatewayMcpServiceConfigSourceConnectionOutputReference;
    putSourceConnection(value: AiGatewayMcpServiceConfigSourceConnection): void;
    resetSourceConnection(): void;
    get sourceConnectionInput(): cdktn.IResolvable | AiGatewayMcpServiceConfigSourceConnection | undefined;
}
export interface AiGatewayMcpServiceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#workspace_id AiGatewayMcpService#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function aiGatewayMcpServiceProviderConfigToTerraform(struct?: AiGatewayMcpServiceProviderConfig | cdktn.IResolvable): any;
export declare function aiGatewayMcpServiceProviderConfigToHclTerraform(struct?: AiGatewayMcpServiceProviderConfig | cdktn.IResolvable): any;
export declare class AiGatewayMcpServiceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AiGatewayMcpServiceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AiGatewayMcpServiceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service databricks_ai_gateway_mcp_service}
*/
export declare class AiGatewayMcpService extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_ai_gateway_mcp_service";
    /**
    * Generates CDKTN code for importing a AiGatewayMcpService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AiGatewayMcpService to import
    * @param importFromId The id of the existing AiGatewayMcpService that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AiGatewayMcpService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/ai_gateway_mcp_service databricks_ai_gateway_mcp_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AiGatewayMcpServiceConfig
    */
    constructor(scope: Construct, id: string, config: AiGatewayMcpServiceConfig);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _config;
    get config(): AiGatewayMcpServiceConfigAOutputReference;
    putConfig(value: AiGatewayMcpServiceConfigA): void;
    resetConfig(): void;
    get configInput(): cdktn.IResolvable | AiGatewayMcpServiceConfigA | undefined;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    private _mcpServiceId?;
    get mcpServiceId(): string;
    set mcpServiceId(value: string);
    get mcpServiceIdInput(): string | undefined;
    get metastoreId(): string;
    get name(): string;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): AiGatewayMcpServiceProviderConfigOutputReference;
    putProviderConfig(value: AiGatewayMcpServiceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AiGatewayMcpServiceProviderConfig | undefined;
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
