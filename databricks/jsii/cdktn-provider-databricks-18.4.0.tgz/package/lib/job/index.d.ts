/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { JobContinuous, JobContinuousOutputReference, JobDbtTask, JobDbtTaskOutputReference, JobDeployment, JobDeploymentOutputReference, JobEmailNotifications, JobEmailNotificationsOutputReference, JobEnvironment, JobEnvironmentList, JobGitSource, JobGitSourceOutputReference, JobHealth, JobHealthOutputReference, JobJobCluster, JobJobClusterList, JobLibrary, JobLibraryList, JobNewCluster, JobNewClusterOutputReference, JobNotebookTask, JobNotebookTaskOutputReference, JobNotificationSettings, JobNotificationSettingsOutputReference, JobParameter, JobParameterList, JobPipelineTask, JobPipelineTaskOutputReference, JobProviderConfig, JobProviderConfigOutputReference, JobPythonWheelTask, JobPythonWheelTaskOutputReference, JobQueue, JobQueueOutputReference, JobRunAs, JobRunAsOutputReference, JobRunJobTask, JobRunJobTaskOutputReference, JobSchedule, JobScheduleOutputReference, JobSparkJarTask, JobSparkJarTaskOutputReference, JobSparkPythonTask, JobSparkPythonTaskOutputReference, JobSparkSubmitTask, JobSparkSubmitTaskOutputReference, JobTask, JobTaskList, JobTimeouts, JobTimeoutsOutputReference, JobTrigger, JobTriggerOutputReference, JobTriggers, JobTriggersList, JobWebhookNotifications, JobWebhookNotificationsOutputReference } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface JobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#always_running Job#always_running}
    */
    readonly alwaysRunning?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#budget_policy_id Job#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#control_run_state Job#control_run_state}
    */
    readonly controlRunState?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#description Job#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#edit_mode Job#edit_mode}
    */
    readonly editMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#existing_cluster_id Job#existing_cluster_id}
    */
    readonly existingClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#format Job#format}
    */
    readonly format?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#max_concurrent_runs Job#max_concurrent_runs}
    */
    readonly maxConcurrentRuns?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#max_retries Job#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#min_retry_interval_millis Job#min_retry_interval_millis}
    */
    readonly minRetryIntervalMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#name Job#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#parent_path Job#parent_path}
    */
    readonly parentPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#performance_target Job#performance_target}
    */
    readonly performanceTarget?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#retry_on_timeout Job#retry_on_timeout}
    */
    readonly retryOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#tags Job#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#timeout_seconds Job#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#usage_policy_id Job#usage_policy_id}
    */
    readonly usagePolicyId?: string;
    /**
    * continuous block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#continuous Job#continuous}
    */
    readonly continuous?: JobContinuous;
    /**
    * dbt_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#dbt_task Job#dbt_task}
    */
    readonly dbtTask?: JobDbtTask;
    /**
    * deployment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#deployment Job#deployment}
    */
    readonly deployment?: JobDeployment;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#email_notifications Job#email_notifications}
    */
    readonly emailNotifications?: JobEmailNotifications;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#environment Job#environment}
    */
    readonly environment?: JobEnvironment[] | cdktn.IResolvable;
    /**
    * git_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#git_source Job#git_source}
    */
    readonly gitSource?: JobGitSource;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#health Job#health}
    */
    readonly health?: JobHealth;
    /**
    * job_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#job_cluster Job#job_cluster}
    */
    readonly jobCluster?: JobJobCluster[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobLibrary[] | cdktn.IResolvable;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#new_cluster Job#new_cluster}
    */
    readonly newCluster?: JobNewCluster;
    /**
    * notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#notebook_task Job#notebook_task}
    */
    readonly notebookTask?: JobNotebookTask;
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#notification_settings Job#notification_settings}
    */
    readonly notificationSettings?: JobNotificationSettings;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#parameter Job#parameter}
    */
    readonly parameter?: JobParameter[] | cdktn.IResolvable;
    /**
    * pipeline_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#pipeline_task Job#pipeline_task}
    */
    readonly pipelineTask?: JobPipelineTask;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobProviderConfig;
    /**
    * python_wheel_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#python_wheel_task Job#python_wheel_task}
    */
    readonly pythonWheelTask?: JobPythonWheelTask;
    /**
    * queue block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#queue Job#queue}
    */
    readonly queue?: JobQueue;
    /**
    * run_as block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#run_as Job#run_as}
    */
    readonly runAs?: JobRunAs;
    /**
    * run_job_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#run_job_task Job#run_job_task}
    */
    readonly runJobTask?: JobRunJobTask;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#schedule Job#schedule}
    */
    readonly schedule?: JobSchedule;
    /**
    * spark_jar_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#spark_jar_task Job#spark_jar_task}
    */
    readonly sparkJarTask?: JobSparkJarTask;
    /**
    * spark_python_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#spark_python_task Job#spark_python_task}
    */
    readonly sparkPythonTask?: JobSparkPythonTask;
    /**
    * spark_submit_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#spark_submit_task Job#spark_submit_task}
    */
    readonly sparkSubmitTask?: JobSparkSubmitTask;
    /**
    * task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#task Job#task}
    */
    readonly task?: JobTask[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#timeouts Job#timeouts}
    */
    readonly timeouts?: JobTimeouts;
    /**
    * trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#trigger Job#trigger}
    */
    readonly trigger?: JobTrigger;
    /**
    * triggers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#triggers Job#triggers}
    */
    readonly triggers?: JobTriggers[] | cdktn.IResolvable;
    /**
    * webhook_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#webhook_notifications Job#webhook_notifications}
    */
    readonly webhookNotifications?: JobWebhookNotifications;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job databricks_job}
*/
export declare class Job extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_job";
    /**
    * Generates CDKTN code for importing a Job resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Job to import
    * @param importFromId The id of the existing Job that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Job to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/resources/job databricks_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options JobConfig = {}
    */
    constructor(scope: Construct, id: string, config?: JobConfig);
    private _alwaysRunning?;
    get alwaysRunning(): boolean | cdktn.IResolvable;
    set alwaysRunning(value: boolean | cdktn.IResolvable);
    resetAlwaysRunning(): void;
    get alwaysRunningInput(): boolean | cdktn.IResolvable | undefined;
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _controlRunState?;
    get controlRunState(): boolean | cdktn.IResolvable;
    set controlRunState(value: boolean | cdktn.IResolvable);
    resetControlRunState(): void;
    get controlRunStateInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _editMode?;
    get editMode(): string;
    set editMode(value: string);
    resetEditMode(): void;
    get editModeInput(): string | undefined;
    private _existingClusterId?;
    get existingClusterId(): string;
    set existingClusterId(value: string);
    resetExistingClusterId(): void;
    get existingClusterIdInput(): string | undefined;
    private _format?;
    get format(): string;
    set format(value: string);
    resetFormat(): void;
    get formatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxConcurrentRuns?;
    get maxConcurrentRuns(): number;
    set maxConcurrentRuns(value: number);
    resetMaxConcurrentRuns(): void;
    get maxConcurrentRunsInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minRetryIntervalMillis?;
    get minRetryIntervalMillis(): number;
    set minRetryIntervalMillis(value: number);
    resetMinRetryIntervalMillis(): void;
    get minRetryIntervalMillisInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parentPath?;
    get parentPath(): string;
    set parentPath(value: string);
    resetParentPath(): void;
    get parentPathInput(): string | undefined;
    private _performanceTarget?;
    get performanceTarget(): string;
    set performanceTarget(value: string);
    resetPerformanceTarget(): void;
    get performanceTargetInput(): string | undefined;
    private _retryOnTimeout?;
    get retryOnTimeout(): boolean | cdktn.IResolvable;
    set retryOnTimeout(value: boolean | cdktn.IResolvable);
    resetRetryOnTimeout(): void;
    get retryOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    get url(): string;
    private _usagePolicyId?;
    get usagePolicyId(): string;
    set usagePolicyId(value: string);
    resetUsagePolicyId(): void;
    get usagePolicyIdInput(): string | undefined;
    private _continuous;
    get continuous(): JobContinuousOutputReference;
    putContinuous(value: JobContinuous): void;
    resetContinuous(): void;
    get continuousInput(): JobContinuous | undefined;
    private _dbtTask;
    get dbtTask(): JobDbtTaskOutputReference;
    putDbtTask(value: JobDbtTask): void;
    resetDbtTask(): void;
    get dbtTaskInput(): JobDbtTask | undefined;
    private _deployment;
    get deployment(): JobDeploymentOutputReference;
    putDeployment(value: JobDeployment): void;
    resetDeployment(): void;
    get deploymentInput(): JobDeployment | undefined;
    private _emailNotifications;
    get emailNotifications(): JobEmailNotificationsOutputReference;
    putEmailNotifications(value: JobEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): JobEmailNotifications | undefined;
    private _environment;
    get environment(): JobEnvironmentList;
    putEnvironment(value: JobEnvironment[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | JobEnvironment[] | undefined;
    private _gitSource;
    get gitSource(): JobGitSourceOutputReference;
    putGitSource(value: JobGitSource): void;
    resetGitSource(): void;
    get gitSourceInput(): JobGitSource | undefined;
    private _health;
    get health(): JobHealthOutputReference;
    putHealth(value: JobHealth): void;
    resetHealth(): void;
    get healthInput(): JobHealth | undefined;
    private _jobCluster;
    get jobCluster(): JobJobClusterList;
    putJobCluster(value: JobJobCluster[] | cdktn.IResolvable): void;
    resetJobCluster(): void;
    get jobClusterInput(): cdktn.IResolvable | JobJobCluster[] | undefined;
    private _library;
    get library(): JobLibraryList;
    putLibrary(value: JobLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobLibrary[] | undefined;
    private _newCluster;
    get newCluster(): JobNewClusterOutputReference;
    putNewCluster(value: JobNewCluster): void;
    resetNewCluster(): void;
    get newClusterInput(): JobNewCluster | undefined;
    private _notebookTask;
    get notebookTask(): JobNotebookTaskOutputReference;
    putNotebookTask(value: JobNotebookTask): void;
    resetNotebookTask(): void;
    get notebookTaskInput(): JobNotebookTask | undefined;
    private _notificationSettings;
    get notificationSettings(): JobNotificationSettingsOutputReference;
    putNotificationSettings(value: JobNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): JobNotificationSettings | undefined;
    private _parameter;
    get parameter(): JobParameterList;
    putParameter(value: JobParameter[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | JobParameter[] | undefined;
    private _pipelineTask;
    get pipelineTask(): JobPipelineTaskOutputReference;
    putPipelineTask(value: JobPipelineTask): void;
    resetPipelineTask(): void;
    get pipelineTaskInput(): JobPipelineTask | undefined;
    private _providerConfig;
    get providerConfig(): JobProviderConfigOutputReference;
    putProviderConfig(value: JobProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobProviderConfig | undefined;
    private _pythonWheelTask;
    get pythonWheelTask(): JobPythonWheelTaskOutputReference;
    putPythonWheelTask(value: JobPythonWheelTask): void;
    resetPythonWheelTask(): void;
    get pythonWheelTaskInput(): JobPythonWheelTask | undefined;
    private _queue;
    get queue(): JobQueueOutputReference;
    putQueue(value: JobQueue): void;
    resetQueue(): void;
    get queueInput(): JobQueue | undefined;
    private _runAs;
    get runAs(): JobRunAsOutputReference;
    putRunAs(value: JobRunAs): void;
    resetRunAs(): void;
    get runAsInput(): JobRunAs | undefined;
    private _runJobTask;
    get runJobTask(): JobRunJobTaskOutputReference;
    putRunJobTask(value: JobRunJobTask): void;
    resetRunJobTask(): void;
    get runJobTaskInput(): JobRunJobTask | undefined;
    private _schedule;
    get schedule(): JobScheduleOutputReference;
    putSchedule(value: JobSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): JobSchedule | undefined;
    private _sparkJarTask;
    get sparkJarTask(): JobSparkJarTaskOutputReference;
    putSparkJarTask(value: JobSparkJarTask): void;
    resetSparkJarTask(): void;
    get sparkJarTaskInput(): JobSparkJarTask | undefined;
    private _sparkPythonTask;
    get sparkPythonTask(): JobSparkPythonTaskOutputReference;
    putSparkPythonTask(value: JobSparkPythonTask): void;
    resetSparkPythonTask(): void;
    get sparkPythonTaskInput(): JobSparkPythonTask | undefined;
    private _sparkSubmitTask;
    get sparkSubmitTask(): JobSparkSubmitTaskOutputReference;
    putSparkSubmitTask(value: JobSparkSubmitTask): void;
    resetSparkSubmitTask(): void;
    get sparkSubmitTaskInput(): JobSparkSubmitTask | undefined;
    private _task;
    get task(): JobTaskList;
    putTask(value: JobTask[] | cdktn.IResolvable): void;
    resetTask(): void;
    get taskInput(): cdktn.IResolvable | JobTask[] | undefined;
    private _timeouts;
    get timeouts(): JobTimeoutsOutputReference;
    putTimeouts(value: JobTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | JobTimeouts | undefined;
    private _trigger;
    get trigger(): JobTriggerOutputReference;
    putTrigger(value: JobTrigger): void;
    resetTrigger(): void;
    get triggerInput(): JobTrigger | undefined;
    private _triggers;
    get triggers(): JobTriggersList;
    putTriggers(value: JobTriggers[] | cdktn.IResolvable): void;
    resetTriggers(): void;
    get triggersInput(): cdktn.IResolvable | JobTriggers[] | undefined;
    private _webhookNotifications;
    get webhookNotifications(): JobWebhookNotificationsOutputReference;
    putWebhookNotifications(value: JobWebhookNotifications): void;
    resetWebhookNotifications(): void;
    get webhookNotificationsInput(): JobWebhookNotifications | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
