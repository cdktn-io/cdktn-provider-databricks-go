/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamServicePrincipalV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_service_principal_v2#provider_config DataDatabricksWorkspaceIamServicePrincipalV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_service_principal_v2#service_principal_id DataDatabricksWorkspaceIamServicePrincipalV2#service_principal_id}
    */
    readonly servicePrincipalId: string;
}
export interface DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_service_principal_v2#workspace_id DataDatabricksWorkspaceIamServicePrincipalV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamServicePrincipalV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamServicePrincipalV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_service_principal_v2 databricks_workspace_iam_service_principal_v2}
*/
export declare class DataDatabricksWorkspaceIamServicePrincipalV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_service_principal_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamServicePrincipalV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamServicePrincipalV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamServicePrincipalV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_service_principal_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamServicePrincipalV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.129.0/docs/data-sources/workspace_iam_service_principal_v2 databricks_workspace_iam_service_principal_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamServicePrincipalV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamServicePrincipalV2Config);
    get accountId(): string;
    get accountSpStatus(): string;
    get applicationId(): string;
    get displayName(): string;
    get externalId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamServicePrincipalV2ProviderConfig | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
