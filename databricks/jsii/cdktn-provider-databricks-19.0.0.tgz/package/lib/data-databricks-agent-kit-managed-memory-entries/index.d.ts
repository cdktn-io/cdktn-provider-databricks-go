/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAgentKitManagedMemoryEntriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#actor_id DataDatabricksAgentKitManagedMemoryEntries#actor_id}
    */
    readonly actorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#page_size DataDatabricksAgentKitManagedMemoryEntries#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#parent DataDatabricksAgentKitManagedMemoryEntries#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#path_prefix DataDatabricksAgentKitManagedMemoryEntries#path_prefix}
    */
    readonly pathPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#provider_config DataDatabricksAgentKitManagedMemoryEntries#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitManagedMemoryEntriesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#session_id DataDatabricksAgentKitManagedMemoryEntries#session_id}
    */
    readonly sessionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#view DataDatabricksAgentKitManagedMemoryEntries#view}
    */
    readonly view?: string;
}
export interface DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#workspace_id DataDatabricksAgentKitManagedMemoryEntries#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfigToTerraform(struct?: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#name DataDatabricksAgentKitManagedMemoryEntries#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#provider_config DataDatabricksAgentKitManagedMemoryEntries#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig;
}
export declare function dataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesToTerraform(struct?: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntries): any;
export declare function dataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntries): any;
export declare class DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntries | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntries | undefined);
    get actorId(): string;
    get content(): string;
    get createTime(): string;
    get description(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get path(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesProviderConfig | undefined;
    get sessionId(): string;
    get sourceType(): string;
    get updateTime(): string;
}
export declare class DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntries[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesOutputReference;
}
export interface DataDatabricksAgentKitManagedMemoryEntriesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#workspace_id DataDatabricksAgentKitManagedMemoryEntries#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitManagedMemoryEntriesProviderConfigToTerraform(struct?: DataDatabricksAgentKitManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitManagedMemoryEntriesProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryEntriesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitManagedMemoryEntriesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryEntriesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries databricks_agent_kit_managed_memory_entries}
*/
export declare class DataDatabricksAgentKitManagedMemoryEntries extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_agent_kit_managed_memory_entries";
    /**
    * Generates CDKTN code for importing a DataDatabricksAgentKitManagedMemoryEntries resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAgentKitManagedMemoryEntries to import
    * @param importFromId The id of the existing DataDatabricksAgentKitManagedMemoryEntries that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAgentKitManagedMemoryEntries to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_entries databricks_agent_kit_managed_memory_entries} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAgentKitManagedMemoryEntriesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAgentKitManagedMemoryEntriesConfig);
    private _actorId?;
    get actorId(): string;
    set actorId(value: string);
    get actorIdInput(): string | undefined;
    private _managedMemoryEntries;
    get managedMemoryEntries(): DataDatabricksAgentKitManagedMemoryEntriesManagedMemoryEntriesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _pathPrefix?;
    get pathPrefix(): string;
    set pathPrefix(value: string);
    resetPathPrefix(): void;
    get pathPrefixInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitManagedMemoryEntriesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitManagedMemoryEntriesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitManagedMemoryEntriesProviderConfig | undefined;
    private _sessionId?;
    get sessionId(): string;
    set sessionId(value: string);
    resetSessionId(): void;
    get sessionIdInput(): string | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
