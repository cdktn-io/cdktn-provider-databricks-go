/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAgentKitSessionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#filter DataDatabricksAgentKitSessions#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#order_by DataDatabricksAgentKitSessions#order_by}
    */
    readonly orderBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#page_size DataDatabricksAgentKitSessions#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#parent DataDatabricksAgentKitSessions#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#provider_config DataDatabricksAgentKitSessions#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitSessionsProviderConfig;
}
export interface DataDatabricksAgentKitSessionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#workspace_id DataDatabricksAgentKitSessions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitSessionsProviderConfigToTerraform(struct?: DataDatabricksAgentKitSessionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitSessionsProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitSessionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitSessionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitSessionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitSessionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAgentKitSessionsSessionsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#workspace_id DataDatabricksAgentKitSessions#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitSessionsSessionsProviderConfigToTerraform(struct?: DataDatabricksAgentKitSessionsSessionsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitSessionsSessionsProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitSessionsSessionsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitSessionsSessionsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitSessionsSessionsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitSessionsSessionsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAgentKitSessionsSessions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#name DataDatabricksAgentKitSessions#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#provider_config DataDatabricksAgentKitSessions#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitSessionsSessionsProviderConfig;
}
export declare function dataDatabricksAgentKitSessionsSessionsToTerraform(struct?: DataDatabricksAgentKitSessionsSessions): any;
export declare function dataDatabricksAgentKitSessionsSessionsToHclTerraform(struct?: DataDatabricksAgentKitSessionsSessions): any;
export declare class DataDatabricksAgentKitSessionsSessionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAgentKitSessionsSessions | undefined;
    set internalValue(value: DataDatabricksAgentKitSessionsSessions | undefined);
    get actorId(): string;
    get createTime(): string;
    get lastActivityTime(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentSessionId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitSessionsSessionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitSessionsSessionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitSessionsSessionsProviderConfig | undefined;
    get rootSessionId(): string;
    get sessionId(): string;
    get updateTime(): string;
}
export declare class DataDatabricksAgentKitSessionsSessionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAgentKitSessionsSessions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAgentKitSessionsSessionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions databricks_agent_kit_sessions}
*/
export declare class DataDatabricksAgentKitSessions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_agent_kit_sessions";
    /**
    * Generates CDKTN code for importing a DataDatabricksAgentKitSessions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAgentKitSessions to import
    * @param importFromId The id of the existing DataDatabricksAgentKitSessions that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAgentKitSessions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_sessions databricks_agent_kit_sessions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAgentKitSessionsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAgentKitSessionsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitSessionsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitSessionsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitSessionsProviderConfig | undefined;
    private _sessions;
    get sessions(): DataDatabricksAgentKitSessionsSessionsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
