/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AgentKitManagedMemoryStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store#description AgentKitManagedMemoryStore#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store#display_name AgentKitManagedMemoryStore#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store#managed_memory_store_id AgentKitManagedMemoryStore#managed_memory_store_id}
    */
    readonly managedMemoryStoreId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store#provider_config AgentKitManagedMemoryStore#provider_config}
    */
    readonly providerConfig?: AgentKitManagedMemoryStoreProviderConfig;
}
export interface AgentKitManagedMemoryStoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store#workspace_id AgentKitManagedMemoryStore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function agentKitManagedMemoryStoreProviderConfigToTerraform(struct?: AgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare function agentKitManagedMemoryStoreProviderConfigToHclTerraform(struct?: AgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare class AgentKitManagedMemoryStoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: AgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface AgentKitManagedMemoryStoreStorageBackend {
}
export declare function agentKitManagedMemoryStoreStorageBackendToTerraform(struct?: AgentKitManagedMemoryStoreStorageBackend): any;
export declare function agentKitManagedMemoryStoreStorageBackendToHclTerraform(struct?: AgentKitManagedMemoryStoreStorageBackend): any;
export declare class AgentKitManagedMemoryStoreStorageBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AgentKitManagedMemoryStoreStorageBackend | undefined;
    set internalValue(value: AgentKitManagedMemoryStoreStorageBackend | undefined);
    get backendId(): string;
    get backendType(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store databricks_agent_kit_managed_memory_store}
*/
export declare class AgentKitManagedMemoryStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_agent_kit_managed_memory_store";
    /**
    * Generates CDKTN code for importing a AgentKitManagedMemoryStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AgentKitManagedMemoryStore to import
    * @param importFromId The id of the existing AgentKitManagedMemoryStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AgentKitManagedMemoryStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/resources/agent_kit_managed_memory_store databricks_agent_kit_managed_memory_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AgentKitManagedMemoryStoreConfig
    */
    constructor(scope: Construct, id: string, config: AgentKitManagedMemoryStoreConfig);
    get createTime(): string;
    get creatorUserId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _managedMemoryStoreId?;
    get managedMemoryStoreId(): string;
    set managedMemoryStoreId(value: string);
    get managedMemoryStoreIdInput(): string | undefined;
    get name(): string;
    get ownerUserId(): string;
    private _providerConfig;
    get providerConfig(): AgentKitManagedMemoryStoreProviderConfigOutputReference;
    putProviderConfig(value: AgentKitManagedMemoryStoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | AgentKitManagedMemoryStoreProviderConfig | undefined;
    private _storageBackend;
    get storageBackend(): AgentKitManagedMemoryStoreStorageBackendOutputReference;
    get updateTime(): string;
    get workspaceId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
