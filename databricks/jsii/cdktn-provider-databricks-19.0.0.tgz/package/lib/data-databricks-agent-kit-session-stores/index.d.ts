/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAgentKitSessionStoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores#page_size DataDatabricksAgentKitSessionStores#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores#provider_config DataDatabricksAgentKitSessionStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitSessionStoresProviderConfig;
}
export interface DataDatabricksAgentKitSessionStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores#workspace_id DataDatabricksAgentKitSessionStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitSessionStoresProviderConfigToTerraform(struct?: DataDatabricksAgentKitSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitSessionStoresProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitSessionStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitSessionStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitSessionStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores#workspace_id DataDatabricksAgentKitSessionStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitSessionStoresSessionStoresProviderConfigToTerraform(struct?: DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitSessionStoresSessionStoresProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitSessionStoresSessionStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAgentKitSessionStoresSessionStores {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores#name DataDatabricksAgentKitSessionStores#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores#provider_config DataDatabricksAgentKitSessionStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig;
}
export declare function dataDatabricksAgentKitSessionStoresSessionStoresToTerraform(struct?: DataDatabricksAgentKitSessionStoresSessionStores): any;
export declare function dataDatabricksAgentKitSessionStoresSessionStoresToHclTerraform(struct?: DataDatabricksAgentKitSessionStoresSessionStores): any;
export declare class DataDatabricksAgentKitSessionStoresSessionStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAgentKitSessionStoresSessionStores | undefined;
    set internalValue(value: DataDatabricksAgentKitSessionStoresSessionStores | undefined);
    get createTime(): string;
    get creatorUserId(): string;
    get description(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitSessionStoresSessionStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitSessionStoresSessionStoresProviderConfig | undefined;
    get updateTime(): string;
}
export declare class DataDatabricksAgentKitSessionStoresSessionStoresList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAgentKitSessionStoresSessionStores[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAgentKitSessionStoresSessionStoresOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores databricks_agent_kit_session_stores}
*/
export declare class DataDatabricksAgentKitSessionStores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_agent_kit_session_stores";
    /**
    * Generates CDKTN code for importing a DataDatabricksAgentKitSessionStores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAgentKitSessionStores to import
    * @param importFromId The id of the existing DataDatabricksAgentKitSessionStores that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAgentKitSessionStores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session_stores databricks_agent_kit_session_stores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAgentKitSessionStoresConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAgentKitSessionStoresConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitSessionStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitSessionStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitSessionStoresProviderConfig | undefined;
    private _sessionStores;
    get sessionStores(): DataDatabricksAgentKitSessionStoresSessionStoresList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
