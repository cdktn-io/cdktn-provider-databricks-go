/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAgentKitManagedMemoryStoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores#page_size DataDatabricksAgentKitManagedMemoryStores#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores#provider_config DataDatabricksAgentKitManagedMemoryStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitManagedMemoryStoresProviderConfig;
}
export interface DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores#workspace_id DataDatabricksAgentKitManagedMemoryStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfigToTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackend {
}
export declare function dataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackendToTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackend): any;
export declare function dataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackendToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackend): any;
export declare class DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackend | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackend | undefined);
    get backendId(): string;
    get backendType(): string;
}
export interface DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStores {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores#name DataDatabricksAgentKitManagedMemoryStores#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores#provider_config DataDatabricksAgentKitManagedMemoryStores#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig;
}
export declare function dataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresToTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStores): any;
export declare function dataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStores): any;
export declare class DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStores | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStores | undefined);
    get createTime(): string;
    get creatorUserId(): string;
    get description(): string;
    get displayName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerUserId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresProviderConfig | undefined;
    private _storageBackend;
    get storageBackend(): DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresStorageBackendOutputReference;
    get updateTime(): string;
    get workspaceId(): number;
}
export declare class DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStores[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresOutputReference;
}
export interface DataDatabricksAgentKitManagedMemoryStoresProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores#workspace_id DataDatabricksAgentKitManagedMemoryStores#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitManagedMemoryStoresProviderConfigToTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitManagedMemoryStoresProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoresProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitManagedMemoryStoresProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryStoresProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores databricks_agent_kit_managed_memory_stores}
*/
export declare class DataDatabricksAgentKitManagedMemoryStores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_agent_kit_managed_memory_stores";
    /**
    * Generates CDKTN code for importing a DataDatabricksAgentKitManagedMemoryStores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAgentKitManagedMemoryStores to import
    * @param importFromId The id of the existing DataDatabricksAgentKitManagedMemoryStores that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAgentKitManagedMemoryStores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_stores databricks_agent_kit_managed_memory_stores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAgentKitManagedMemoryStoresConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAgentKitManagedMemoryStoresConfig);
    private _managedMemoryStores;
    get managedMemoryStores(): DataDatabricksAgentKitManagedMemoryStoresManagedMemoryStoresList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitManagedMemoryStoresProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitManagedMemoryStoresProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitManagedMemoryStoresProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
