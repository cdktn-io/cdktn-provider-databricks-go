/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAgentKitSessionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session#name DataDatabricksAgentKitSession#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session#provider_config DataDatabricksAgentKitSession#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitSessionProviderConfig;
}
export interface DataDatabricksAgentKitSessionProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session#workspace_id DataDatabricksAgentKitSession#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitSessionProviderConfigToTerraform(struct?: DataDatabricksAgentKitSessionProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitSessionProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitSessionProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitSessionProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitSessionProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitSessionProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session databricks_agent_kit_session}
*/
export declare class DataDatabricksAgentKitSession extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_agent_kit_session";
    /**
    * Generates CDKTN code for importing a DataDatabricksAgentKitSession resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAgentKitSession to import
    * @param importFromId The id of the existing DataDatabricksAgentKitSession that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAgentKitSession to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_session databricks_agent_kit_session} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAgentKitSessionConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAgentKitSessionConfig);
    get actorId(): string;
    get createTime(): string;
    get lastActivityTime(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentSessionId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitSessionProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitSessionProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitSessionProviderConfig | undefined;
    get rootSessionId(): string;
    get sessionId(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
