/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAgentKitManagedMemoryStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_store#name DataDatabricksAgentKitManagedMemoryStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_store#provider_config DataDatabricksAgentKitManagedMemoryStore#provider_config}
    */
    readonly providerConfig?: DataDatabricksAgentKitManagedMemoryStoreProviderConfig;
}
export interface DataDatabricksAgentKitManagedMemoryStoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_store#workspace_id DataDatabricksAgentKitManagedMemoryStore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAgentKitManagedMemoryStoreProviderConfigToTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAgentKitManagedMemoryStoreProviderConfigToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAgentKitManagedMemoryStoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryStoreProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAgentKitManagedMemoryStoreStorageBackend {
}
export declare function dataDatabricksAgentKitManagedMemoryStoreStorageBackendToTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoreStorageBackend): any;
export declare function dataDatabricksAgentKitManagedMemoryStoreStorageBackendToHclTerraform(struct?: DataDatabricksAgentKitManagedMemoryStoreStorageBackend): any;
export declare class DataDatabricksAgentKitManagedMemoryStoreStorageBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAgentKitManagedMemoryStoreStorageBackend | undefined;
    set internalValue(value: DataDatabricksAgentKitManagedMemoryStoreStorageBackend | undefined);
    get backendId(): string;
    get backendType(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_store databricks_agent_kit_managed_memory_store}
*/
export declare class DataDatabricksAgentKitManagedMemoryStore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_agent_kit_managed_memory_store";
    /**
    * Generates CDKTN code for importing a DataDatabricksAgentKitManagedMemoryStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAgentKitManagedMemoryStore to import
    * @param importFromId The id of the existing DataDatabricksAgentKitManagedMemoryStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAgentKitManagedMemoryStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.140.0/docs/data-sources/agent_kit_managed_memory_store databricks_agent_kit_managed_memory_store} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAgentKitManagedMemoryStoreConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAgentKitManagedMemoryStoreConfig);
    get createTime(): string;
    get creatorUserId(): string;
    get description(): string;
    get displayName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerUserId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAgentKitManagedMemoryStoreProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAgentKitManagedMemoryStoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAgentKitManagedMemoryStoreProviderConfig | undefined;
    private _storageBackend;
    get storageBackend(): DataDatabricksAgentKitManagedMemoryStoreStorageBackendOutputReference;
    get updateTime(): string;
    get workspaceId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
