/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceNetworkOptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_network_option#workspace_id DataDatabricksWorkspaceNetworkOption#workspace_id}
    */
    readonly workspaceId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_network_option databricks_workspace_network_option}
*/
export declare class DataDatabricksWorkspaceNetworkOption extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_network_option";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceNetworkOption resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceNetworkOption to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceNetworkOption that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_network_option#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceNetworkOption to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_network_option databricks_workspace_network_option} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceNetworkOptionConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceNetworkOptionConfig);
    get networkPolicyId(): string;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    get workspaceIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
