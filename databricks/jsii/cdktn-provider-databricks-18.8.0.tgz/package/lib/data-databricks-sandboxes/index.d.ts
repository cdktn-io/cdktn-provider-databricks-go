/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSandboxesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#page_size DataDatabricksSandboxes#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#provider_config DataDatabricksSandboxes#provider_config}
    */
    readonly providerConfig?: DataDatabricksSandboxesProviderConfig;
}
export interface DataDatabricksSandboxesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#workspace_id DataDatabricksSandboxes#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSandboxesProviderConfigToTerraform(struct?: DataDatabricksSandboxesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSandboxesProviderConfigToHclTerraform(struct?: DataDatabricksSandboxesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSandboxesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSandboxesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSandboxesSandboxesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#workspace_id DataDatabricksSandboxes#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSandboxesSandboxesProviderConfigToTerraform(struct?: DataDatabricksSandboxesSandboxesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSandboxesSandboxesProviderConfigToHclTerraform(struct?: DataDatabricksSandboxesSandboxesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSandboxesSandboxesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxesSandboxesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSandboxesSandboxesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksSandboxesSandboxesSpecCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#inactivity_timeout DataDatabricksSandboxes#inactivity_timeout}
    */
    readonly inactivityTimeout?: string;
}
export declare function dataDatabricksSandboxesSandboxesSpecComputeToTerraform(struct?: DataDatabricksSandboxesSandboxesSpecCompute | cdktn.IResolvable): any;
export declare function dataDatabricksSandboxesSandboxesSpecComputeToHclTerraform(struct?: DataDatabricksSandboxesSandboxesSpecCompute | cdktn.IResolvable): any;
export declare class DataDatabricksSandboxesSandboxesSpecComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxesSandboxesSpecCompute | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSandboxesSandboxesSpecCompute | cdktn.IResolvable | undefined);
    private _inactivityTimeout?;
    get inactivityTimeout(): string;
    set inactivityTimeout(value: string);
    resetInactivityTimeout(): void;
    get inactivityTimeoutInput(): string | undefined;
}
export interface DataDatabricksSandboxesSandboxesSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#compute DataDatabricksSandboxes#compute}
    */
    readonly compute?: DataDatabricksSandboxesSandboxesSpecCompute;
}
export declare function dataDatabricksSandboxesSandboxesSpecToTerraform(struct?: DataDatabricksSandboxesSandboxesSpec): any;
export declare function dataDatabricksSandboxesSandboxesSpecToHclTerraform(struct?: DataDatabricksSandboxesSandboxesSpec): any;
export declare class DataDatabricksSandboxesSandboxesSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxesSandboxesSpec | undefined;
    set internalValue(value: DataDatabricksSandboxesSandboxesSpec | undefined);
    private _compute;
    get compute(): DataDatabricksSandboxesSandboxesSpecComputeOutputReference;
    putCompute(value: DataDatabricksSandboxesSandboxesSpecCompute): void;
    resetCompute(): void;
    get computeInput(): cdktn.IResolvable | DataDatabricksSandboxesSandboxesSpecCompute | undefined;
}
export interface DataDatabricksSandboxesSandboxesStatus {
}
export declare function dataDatabricksSandboxesSandboxesStatusToTerraform(struct?: DataDatabricksSandboxesSandboxesStatus): any;
export declare function dataDatabricksSandboxesSandboxesStatusToHclTerraform(struct?: DataDatabricksSandboxesSandboxesStatus): any;
export declare class DataDatabricksSandboxesSandboxesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSandboxesSandboxesStatus | undefined;
    set internalValue(value: DataDatabricksSandboxesSandboxesStatus | undefined);
    get state(): string;
}
export interface DataDatabricksSandboxesSandboxes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#name DataDatabricksSandboxes#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#provider_config DataDatabricksSandboxes#provider_config}
    */
    readonly providerConfig?: DataDatabricksSandboxesSandboxesProviderConfig;
}
export declare function dataDatabricksSandboxesSandboxesToTerraform(struct?: DataDatabricksSandboxesSandboxes): any;
export declare function dataDatabricksSandboxesSandboxesToHclTerraform(struct?: DataDatabricksSandboxesSandboxes): any;
export declare class DataDatabricksSandboxesSandboxesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksSandboxesSandboxes | undefined;
    set internalValue(value: DataDatabricksSandboxesSandboxes | undefined);
    get createTime(): string;
    get displayName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSandboxesSandboxesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSandboxesSandboxesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSandboxesSandboxesProviderConfig | undefined;
    private _spec;
    get spec(): DataDatabricksSandboxesSandboxesSpecOutputReference;
    private _status;
    get status(): DataDatabricksSandboxesSandboxesStatusOutputReference;
    get updateTime(): string;
}
export declare class DataDatabricksSandboxesSandboxesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksSandboxesSandboxes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksSandboxesSandboxesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes databricks_sandboxes}
*/
export declare class DataDatabricksSandboxes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_sandboxes";
    /**
    * Generates CDKTN code for importing a DataDatabricksSandboxes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSandboxes to import
    * @param importFromId The id of the existing DataDatabricksSandboxes that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSandboxes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/sandboxes databricks_sandboxes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSandboxesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksSandboxesConfig);
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSandboxesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSandboxesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSandboxesProviderConfig | undefined;
    private _sandboxes;
    get sandboxes(): DataDatabricksSandboxesSandboxesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
