/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiGatewayMcpServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#name DataDatabricksAiGatewayMcpService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#provider_config DataDatabricksAiGatewayMcpService#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayMcpServiceProviderConfig;
}
export interface DataDatabricksAiGatewayMcpServiceConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#key DataDatabricksAiGatewayMcpService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#principal DataDatabricksAiGatewayMcpService#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#renewal_period DataDatabricksAiGatewayMcpService#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#requests DataDatabricksAiGatewayMcpService#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#tokens DataDatabricksAiGatewayMcpService#tokens}
    */
    readonly tokens?: number;
}
export declare function dataDatabricksAiGatewayMcpServiceConfigRateLimitsToTerraform(struct?: DataDatabricksAiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayMcpServiceConfigRateLimitsToHclTerraform(struct?: DataDatabricksAiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayMcpServiceConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServiceConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayMcpServiceConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayMcpServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayMcpServiceConfigRateLimitsOutputReference;
}
export interface DataDatabricksAiGatewayMcpServiceConfigSourceConnection {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#name DataDatabricksAiGatewayMcpService#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayMcpServiceConfigSourceConnectionToTerraform(struct?: DataDatabricksAiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayMcpServiceConfigSourceConnectionToHclTerraform(struct?: DataDatabricksAiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayMcpServiceConfigSourceConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServiceConfigSourceConnection | cdktn.IResolvable | undefined);
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAiGatewayMcpServiceConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#include_tool_selectors DataDatabricksAiGatewayMcpService#include_tool_selectors}
    */
    readonly includeToolSelectors?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#rate_limits DataDatabricksAiGatewayMcpService#rate_limits}
    */
    readonly rateLimits?: DataDatabricksAiGatewayMcpServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#source_connection DataDatabricksAiGatewayMcpService#source_connection}
    */
    readonly sourceConnection?: DataDatabricksAiGatewayMcpServiceConfigSourceConnection;
}
export declare function dataDatabricksAiGatewayMcpServiceConfigAToTerraform(struct?: DataDatabricksAiGatewayMcpServiceConfigA): any;
export declare function dataDatabricksAiGatewayMcpServiceConfigAToHclTerraform(struct?: DataDatabricksAiGatewayMcpServiceConfigA): any;
export declare class DataDatabricksAiGatewayMcpServiceConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayMcpServiceConfigA | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServiceConfigA | undefined);
    private _includeToolSelectors?;
    get includeToolSelectors(): string[];
    set includeToolSelectors(value: string[]);
    resetIncludeToolSelectors(): void;
    get includeToolSelectorsInput(): string[] | undefined;
    private _rateLimits;
    get rateLimits(): DataDatabricksAiGatewayMcpServiceConfigRateLimitsList;
    putRateLimits(value: DataDatabricksAiGatewayMcpServiceConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | DataDatabricksAiGatewayMcpServiceConfigRateLimits[] | undefined;
    private _sourceConnection;
    get sourceConnection(): DataDatabricksAiGatewayMcpServiceConfigSourceConnectionOutputReference;
    putSourceConnection(value: DataDatabricksAiGatewayMcpServiceConfigSourceConnection): void;
    resetSourceConnection(): void;
    get sourceConnectionInput(): cdktn.IResolvable | DataDatabricksAiGatewayMcpServiceConfigSourceConnection | undefined;
}
export interface DataDatabricksAiGatewayMcpServiceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#workspace_id DataDatabricksAiGatewayMcpService#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayMcpServiceProviderConfigToTerraform(struct?: DataDatabricksAiGatewayMcpServiceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayMcpServiceProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayMcpServiceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayMcpServiceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayMcpServiceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayMcpServiceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service databricks_ai_gateway_mcp_service}
*/
export declare class DataDatabricksAiGatewayMcpService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_gateway_mcp_service";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiGatewayMcpService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiGatewayMcpService to import
    * @param importFromId The id of the existing DataDatabricksAiGatewayMcpService that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiGatewayMcpService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_mcp_service databricks_ai_gateway_mcp_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiGatewayMcpServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAiGatewayMcpServiceConfig);
    get comment(): string;
    private _config;
    get config(): DataDatabricksAiGatewayMcpServiceConfigAOutputReference;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayMcpServiceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayMcpServiceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayMcpServiceProviderConfig | undefined;
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
