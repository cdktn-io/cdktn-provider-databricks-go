/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamDirectGroupMemberV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_iam_direct_group_member_v2#group_id DataDatabricksWorkspaceIamDirectGroupMemberV2#group_id}
    */
    readonly groupId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_iam_direct_group_member_v2#principal_id DataDatabricksWorkspaceIamDirectGroupMemberV2#principal_id}
    */
    readonly principalId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_iam_direct_group_member_v2#provider_config DataDatabricksWorkspaceIamDirectGroupMemberV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_iam_direct_group_member_v2#workspace_id DataDatabricksWorkspaceIamDirectGroupMemberV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_iam_direct_group_member_v2 databricks_workspace_iam_direct_group_member_v2}
*/
export declare class DataDatabricksWorkspaceIamDirectGroupMemberV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_direct_group_member_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamDirectGroupMemberV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamDirectGroupMemberV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamDirectGroupMemberV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_iam_direct_group_member_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamDirectGroupMemberV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/workspace_iam_direct_group_member_v2 databricks_workspace_iam_direct_group_member_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamDirectGroupMemberV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamDirectGroupMemberV2Config);
    get displayName(): string;
    get externalId(): string;
    private _groupId?;
    get groupId(): number;
    set groupId(value: number);
    get groupIdInput(): number | undefined;
    get membershipSource(): string;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    get principalIdInput(): number | undefined;
    get principalType(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamDirectGroupMemberV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
