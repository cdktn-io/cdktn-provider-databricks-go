/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSchemasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas#catalog_name DataDatabricksSchemas#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas#id DataDatabricksSchemas#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas#ids DataDatabricksSchemas#ids}
    */
    readonly ids?: string[];
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas#provider_config DataDatabricksSchemas#provider_config}
    */
    readonly providerConfig?: DataDatabricksSchemasProviderConfig;
}
export interface DataDatabricksSchemasProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas#workspace_id DataDatabricksSchemas#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSchemasProviderConfigToTerraform(struct?: DataDatabricksSchemasProviderConfigOutputReference | DataDatabricksSchemasProviderConfig): any;
export declare function dataDatabricksSchemasProviderConfigToHclTerraform(struct?: DataDatabricksSchemasProviderConfigOutputReference | DataDatabricksSchemasProviderConfig): any;
export declare class DataDatabricksSchemasProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSchemasProviderConfig | undefined;
    set internalValue(value: DataDatabricksSchemasProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas databricks_schemas}
*/
export declare class DataDatabricksSchemas extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_schemas";
    /**
    * Generates CDKTN code for importing a DataDatabricksSchemas resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSchemas to import
    * @param importFromId The id of the existing DataDatabricksSchemas that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSchemas to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/schemas databricks_schemas} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSchemasConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksSchemasConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSchemasProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSchemasProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksSchemasProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
