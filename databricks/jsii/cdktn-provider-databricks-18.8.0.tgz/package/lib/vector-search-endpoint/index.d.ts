/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VectorSearchEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#budget_policy_id VectorSearchEndpoint#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#endpoint_type VectorSearchEndpoint#endpoint_type}
    */
    readonly endpointType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#id VectorSearchEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#name VectorSearchEndpoint#name}
    */
    readonly name: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#provider_config VectorSearchEndpoint#provider_config}
    */
    readonly providerConfig?: VectorSearchEndpointProviderConfig;
    /**
    * scaling_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#scaling_info VectorSearchEndpoint#scaling_info}
    */
    readonly scalingInfo?: VectorSearchEndpointScalingInfo;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#timeouts VectorSearchEndpoint#timeouts}
    */
    readonly timeouts?: VectorSearchEndpointTimeouts;
}
export interface VectorSearchEndpointEndpointStatus {
}
export declare function vectorSearchEndpointEndpointStatusToTerraform(struct?: VectorSearchEndpointEndpointStatus): any;
export declare function vectorSearchEndpointEndpointStatusToHclTerraform(struct?: VectorSearchEndpointEndpointStatus): any;
export declare class VectorSearchEndpointEndpointStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VectorSearchEndpointEndpointStatus | undefined;
    set internalValue(value: VectorSearchEndpointEndpointStatus | undefined);
    get message(): string;
    get state(): string;
}
export declare class VectorSearchEndpointEndpointStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VectorSearchEndpointEndpointStatusOutputReference;
}
export interface VectorSearchEndpointProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#workspace_id VectorSearchEndpoint#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function vectorSearchEndpointProviderConfigToTerraform(struct?: VectorSearchEndpointProviderConfigOutputReference | VectorSearchEndpointProviderConfig): any;
export declare function vectorSearchEndpointProviderConfigToHclTerraform(struct?: VectorSearchEndpointProviderConfigOutputReference | VectorSearchEndpointProviderConfig): any;
export declare class VectorSearchEndpointProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VectorSearchEndpointProviderConfig | undefined;
    set internalValue(value: VectorSearchEndpointProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface VectorSearchEndpointScalingInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#requested_target_qps VectorSearchEndpoint#requested_target_qps}
    */
    readonly requestedTargetQps?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#state VectorSearchEndpoint#state}
    */
    readonly state?: string;
}
export declare function vectorSearchEndpointScalingInfoToTerraform(struct?: VectorSearchEndpointScalingInfoOutputReference | VectorSearchEndpointScalingInfo): any;
export declare function vectorSearchEndpointScalingInfoToHclTerraform(struct?: VectorSearchEndpointScalingInfoOutputReference | VectorSearchEndpointScalingInfo): any;
export declare class VectorSearchEndpointScalingInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VectorSearchEndpointScalingInfo | undefined;
    set internalValue(value: VectorSearchEndpointScalingInfo | undefined);
    private _requestedTargetQps?;
    get requestedTargetQps(): number;
    set requestedTargetQps(value: number);
    resetRequestedTargetQps(): void;
    get requestedTargetQpsInput(): number | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
}
export interface VectorSearchEndpointTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#create VectorSearchEndpoint#create}
    */
    readonly create?: string;
}
export declare function vectorSearchEndpointTimeoutsToTerraform(struct?: VectorSearchEndpointTimeouts | cdktn.IResolvable): any;
export declare function vectorSearchEndpointTimeoutsToHclTerraform(struct?: VectorSearchEndpointTimeouts | cdktn.IResolvable): any;
export declare class VectorSearchEndpointTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VectorSearchEndpointTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: VectorSearchEndpointTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint databricks_vector_search_endpoint}
*/
export declare class VectorSearchEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_vector_search_endpoint";
    /**
    * Generates CDKTN code for importing a VectorSearchEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VectorSearchEndpoint to import
    * @param importFromId The id of the existing VectorSearchEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VectorSearchEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_endpoint databricks_vector_search_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VectorSearchEndpointConfig
    */
    constructor(scope: Construct, id: string, config: VectorSearchEndpointConfig);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    get creationTimestamp(): number;
    get creator(): string;
    get effectiveBudgetPolicyId(): string;
    get endpointId(): string;
    private _endpointStatus;
    get endpointStatus(): VectorSearchEndpointEndpointStatusList;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    get endpointTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTimestamp(): number;
    get lastUpdatedUser(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get numIndexes(): number;
    private _providerConfig;
    get providerConfig(): VectorSearchEndpointProviderConfigOutputReference;
    putProviderConfig(value: VectorSearchEndpointProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): VectorSearchEndpointProviderConfig | undefined;
    private _scalingInfo;
    get scalingInfo(): VectorSearchEndpointScalingInfoOutputReference;
    putScalingInfo(value: VectorSearchEndpointScalingInfo): void;
    resetScalingInfo(): void;
    get scalingInfoInput(): VectorSearchEndpointScalingInfo | undefined;
    private _timeouts;
    get timeouts(): VectorSearchEndpointTimeoutsOutputReference;
    putTimeouts(value: VectorSearchEndpointTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | VectorSearchEndpointTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
