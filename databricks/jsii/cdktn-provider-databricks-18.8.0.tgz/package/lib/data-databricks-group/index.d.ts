/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#acl_principal_id DataDatabricksGroup#acl_principal_id}
    */
    readonly aclPrincipalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#allow_cluster_create DataDatabricksGroup#allow_cluster_create}
    */
    readonly allowClusterCreate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#allow_instance_pool_create DataDatabricksGroup#allow_instance_pool_create}
    */
    readonly allowInstancePoolCreate?: boolean | cdktn.IResolvable;
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#api DataDatabricksGroup#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#child_groups DataDatabricksGroup#child_groups}
    */
    readonly childGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#databricks_sql_access DataDatabricksGroup#databricks_sql_access}
    */
    readonly databricksSqlAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#display_name DataDatabricksGroup#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#external_id DataDatabricksGroup#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#groups DataDatabricksGroup#groups}
    */
    readonly groups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#id DataDatabricksGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#instance_profiles DataDatabricksGroup#instance_profiles}
    */
    readonly instanceProfiles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#members DataDatabricksGroup#members}
    */
    readonly members?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#recursive DataDatabricksGroup#recursive}
    */
    readonly recursive?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#roles DataDatabricksGroup#roles}
    */
    readonly roles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#service_principals DataDatabricksGroup#service_principals}
    */
    readonly servicePrincipals?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#users DataDatabricksGroup#users}
    */
    readonly users?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#workspace_access DataDatabricksGroup#workspace_access}
    */
    readonly workspaceAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#workspace_consume DataDatabricksGroup#workspace_consume}
    */
    readonly workspaceConsume?: boolean | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#provider_config DataDatabricksGroup#provider_config}
    */
    readonly providerConfig?: DataDatabricksGroupProviderConfig;
}
export interface DataDatabricksGroupProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#workspace_id DataDatabricksGroup#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksGroupProviderConfigToTerraform(struct?: DataDatabricksGroupProviderConfigOutputReference | DataDatabricksGroupProviderConfig): any;
export declare function dataDatabricksGroupProviderConfigToHclTerraform(struct?: DataDatabricksGroupProviderConfigOutputReference | DataDatabricksGroupProviderConfig): any;
export declare class DataDatabricksGroupProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksGroupProviderConfig | undefined;
    set internalValue(value: DataDatabricksGroupProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group databricks_group}
*/
export declare class DataDatabricksGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_group";
    /**
    * Generates CDKTN code for importing a DataDatabricksGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksGroup to import
    * @param importFromId The id of the existing DataDatabricksGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/group databricks_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksGroupConfig);
    private _aclPrincipalId?;
    get aclPrincipalId(): string;
    set aclPrincipalId(value: string);
    resetAclPrincipalId(): void;
    get aclPrincipalIdInput(): string | undefined;
    private _allowClusterCreate?;
    get allowClusterCreate(): boolean | cdktn.IResolvable;
    set allowClusterCreate(value: boolean | cdktn.IResolvable);
    resetAllowClusterCreate(): void;
    get allowClusterCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _allowInstancePoolCreate?;
    get allowInstancePoolCreate(): boolean | cdktn.IResolvable;
    set allowInstancePoolCreate(value: boolean | cdktn.IResolvable);
    resetAllowInstancePoolCreate(): void;
    get allowInstancePoolCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    private _childGroups?;
    get childGroups(): string[];
    set childGroups(value: string[]);
    resetChildGroups(): void;
    get childGroupsInput(): string[] | undefined;
    private _databricksSqlAccess?;
    get databricksSqlAccess(): boolean | cdktn.IResolvable;
    set databricksSqlAccess(value: boolean | cdktn.IResolvable);
    resetDatabricksSqlAccess(): void;
    get databricksSqlAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _groups?;
    get groups(): string[];
    set groups(value: string[]);
    resetGroups(): void;
    get groupsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfiles?;
    get instanceProfiles(): string[];
    set instanceProfiles(value: string[]);
    resetInstanceProfiles(): void;
    get instanceProfilesInput(): string[] | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    resetMembers(): void;
    get membersInput(): string[] | undefined;
    private _recursive?;
    get recursive(): boolean | cdktn.IResolvable;
    set recursive(value: boolean | cdktn.IResolvable);
    resetRecursive(): void;
    get recursiveInput(): boolean | cdktn.IResolvable | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    resetRoles(): void;
    get rolesInput(): string[] | undefined;
    private _servicePrincipals?;
    get servicePrincipals(): string[];
    set servicePrincipals(value: string[]);
    resetServicePrincipals(): void;
    get servicePrincipalsInput(): string[] | undefined;
    private _users?;
    get users(): string[];
    set users(value: string[]);
    resetUsers(): void;
    get usersInput(): string[] | undefined;
    private _workspaceAccess?;
    get workspaceAccess(): boolean | cdktn.IResolvable;
    set workspaceAccess(value: boolean | cdktn.IResolvable);
    resetWorkspaceAccess(): void;
    get workspaceAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _workspaceConsume?;
    get workspaceConsume(): boolean | cdktn.IResolvable;
    set workspaceConsume(value: boolean | cdktn.IResolvable);
    resetWorkspaceConsume(): void;
    get workspaceConsumeInput(): boolean | cdktn.IResolvable | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksGroupProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksGroupProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksGroupProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
