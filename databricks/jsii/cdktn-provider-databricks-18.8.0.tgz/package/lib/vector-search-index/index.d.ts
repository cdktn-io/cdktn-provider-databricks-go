/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface VectorSearchIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#endpoint_id VectorSearchIndex#endpoint_id}
    */
    readonly endpointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#endpoint_name VectorSearchIndex#endpoint_name}
    */
    readonly endpointName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#id VectorSearchIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#index_subtype VectorSearchIndex#index_subtype}
    */
    readonly indexSubtype?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#index_type VectorSearchIndex#index_type}
    */
    readonly indexType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#name VectorSearchIndex#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#primary_key VectorSearchIndex#primary_key}
    */
    readonly primaryKey: string;
    /**
    * delta_sync_index_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#delta_sync_index_spec VectorSearchIndex#delta_sync_index_spec}
    */
    readonly deltaSyncIndexSpec?: VectorSearchIndexDeltaSyncIndexSpec;
    /**
    * direct_access_index_spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#direct_access_index_spec VectorSearchIndex#direct_access_index_spec}
    */
    readonly directAccessIndexSpec?: VectorSearchIndexDirectAccessIndexSpec;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#provider_config VectorSearchIndex#provider_config}
    */
    readonly providerConfig?: VectorSearchIndexProviderConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#timeouts VectorSearchIndex#timeouts}
    */
    readonly timeouts?: VectorSearchIndexTimeouts;
}
export interface VectorSearchIndexStatus {
}
export declare function vectorSearchIndexStatusToTerraform(struct?: VectorSearchIndexStatus): any;
export declare function vectorSearchIndexStatusToHclTerraform(struct?: VectorSearchIndexStatus): any;
export declare class VectorSearchIndexStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VectorSearchIndexStatus | undefined;
    set internalValue(value: VectorSearchIndexStatus | undefined);
    get indexUrl(): string;
    get indexedRowCount(): number;
    get message(): string;
    get ready(): cdktn.IResolvable;
}
export declare class VectorSearchIndexStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VectorSearchIndexStatusOutputReference;
}
export interface VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_model_endpoint_name VectorSearchIndex#embedding_model_endpoint_name}
    */
    readonly embeddingModelEndpointName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#model_endpoint_name_for_query VectorSearchIndex#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#name VectorSearchIndex#name}
    */
    readonly name?: string;
}
export declare function vectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsToTerraform(struct?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function vectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpointName?;
    get embeddingModelEndpointName(): string;
    set embeddingModelEndpointName(value: string);
    resetEmbeddingModelEndpointName(): void;
    get embeddingModelEndpointNameInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_dimension VectorSearchIndex#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#name VectorSearchIndex#name}
    */
    readonly name?: string;
}
export declare function vectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsToTerraform(struct?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function vectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface VectorSearchIndexDeltaSyncIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#columns_to_index VectorSearchIndex#columns_to_index}
    */
    readonly columnsToIndex?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#columns_to_sync VectorSearchIndex#columns_to_sync}
    */
    readonly columnsToSync?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_writeback_table VectorSearchIndex#embedding_writeback_table}
    */
    readonly embeddingWritebackTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#pipeline_type VectorSearchIndex#pipeline_type}
    */
    readonly pipelineType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#source_table VectorSearchIndex#source_table}
    */
    readonly sourceTable?: string;
    /**
    * embedding_source_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_source_columns VectorSearchIndex#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * embedding_vector_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_vector_columns VectorSearchIndex#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
}
export declare function vectorSearchIndexDeltaSyncIndexSpecToTerraform(struct?: VectorSearchIndexDeltaSyncIndexSpecOutputReference | VectorSearchIndexDeltaSyncIndexSpec): any;
export declare function vectorSearchIndexDeltaSyncIndexSpecToHclTerraform(struct?: VectorSearchIndexDeltaSyncIndexSpecOutputReference | VectorSearchIndexDeltaSyncIndexSpec): any;
export declare class VectorSearchIndexDeltaSyncIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VectorSearchIndexDeltaSyncIndexSpec | undefined;
    set internalValue(value: VectorSearchIndexDeltaSyncIndexSpec | undefined);
    private _columnsToIndex?;
    get columnsToIndex(): string[];
    set columnsToIndex(value: string[]);
    resetColumnsToIndex(): void;
    get columnsToIndexInput(): string[] | undefined;
    private _columnsToSync?;
    get columnsToSync(): string[];
    set columnsToSync(value: string[]);
    resetColumnsToSync(): void;
    get columnsToSyncInput(): string[] | undefined;
    private _embeddingWritebackTable?;
    get embeddingWritebackTable(): string;
    set embeddingWritebackTable(value: string);
    resetEmbeddingWritebackTable(): void;
    get embeddingWritebackTableInput(): string | undefined;
    get pipelineId(): string;
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    resetPipelineType(): void;
    get pipelineTypeInput(): string | undefined;
    private _sourceTable?;
    get sourceTable(): string;
    set sourceTable(value: string);
    resetSourceTable(): void;
    get sourceTableInput(): string | undefined;
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | VectorSearchIndexDeltaSyncIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | VectorSearchIndexDeltaSyncIndexSpecEmbeddingVectorColumns[] | undefined;
}
export interface VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_model_endpoint_name VectorSearchIndex#embedding_model_endpoint_name}
    */
    readonly embeddingModelEndpointName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#model_endpoint_name_for_query VectorSearchIndex#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#name VectorSearchIndex#name}
    */
    readonly name?: string;
}
export declare function vectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsToTerraform(struct?: VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function vectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpointName?;
    get embeddingModelEndpointName(): string;
    set embeddingModelEndpointName(value: string);
    resetEmbeddingModelEndpointName(): void;
    get embeddingModelEndpointNameInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_dimension VectorSearchIndex#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#name VectorSearchIndex#name}
    */
    readonly name?: string;
}
export declare function vectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsToTerraform(struct?: VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function vectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface VectorSearchIndexDirectAccessIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#schema_json VectorSearchIndex#schema_json}
    */
    readonly schemaJson?: string;
    /**
    * embedding_source_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_source_columns VectorSearchIndex#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * embedding_vector_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#embedding_vector_columns VectorSearchIndex#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
}
export declare function vectorSearchIndexDirectAccessIndexSpecToTerraform(struct?: VectorSearchIndexDirectAccessIndexSpecOutputReference | VectorSearchIndexDirectAccessIndexSpec): any;
export declare function vectorSearchIndexDirectAccessIndexSpecToHclTerraform(struct?: VectorSearchIndexDirectAccessIndexSpecOutputReference | VectorSearchIndexDirectAccessIndexSpec): any;
export declare class VectorSearchIndexDirectAccessIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VectorSearchIndexDirectAccessIndexSpec | undefined;
    set internalValue(value: VectorSearchIndexDirectAccessIndexSpec | undefined);
    private _schemaJson?;
    get schemaJson(): string;
    set schemaJson(value: string);
    resetSchemaJson(): void;
    get schemaJsonInput(): string | undefined;
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | VectorSearchIndexDirectAccessIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | VectorSearchIndexDirectAccessIndexSpecEmbeddingVectorColumns[] | undefined;
}
export interface VectorSearchIndexProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#workspace_id VectorSearchIndex#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function vectorSearchIndexProviderConfigToTerraform(struct?: VectorSearchIndexProviderConfigOutputReference | VectorSearchIndexProviderConfig): any;
export declare function vectorSearchIndexProviderConfigToHclTerraform(struct?: VectorSearchIndexProviderConfigOutputReference | VectorSearchIndexProviderConfig): any;
export declare class VectorSearchIndexProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VectorSearchIndexProviderConfig | undefined;
    set internalValue(value: VectorSearchIndexProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface VectorSearchIndexTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#create VectorSearchIndex#create}
    */
    readonly create?: string;
}
export declare function vectorSearchIndexTimeoutsToTerraform(struct?: VectorSearchIndexTimeouts | cdktn.IResolvable): any;
export declare function vectorSearchIndexTimeoutsToHclTerraform(struct?: VectorSearchIndexTimeouts | cdktn.IResolvable): any;
export declare class VectorSearchIndexTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): VectorSearchIndexTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: VectorSearchIndexTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index databricks_vector_search_index}
*/
export declare class VectorSearchIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_vector_search_index";
    /**
    * Generates CDKTN code for importing a VectorSearchIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the VectorSearchIndex to import
    * @param importFromId The id of the existing VectorSearchIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the VectorSearchIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/vector_search_index databricks_vector_search_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options VectorSearchIndexConfig
    */
    constructor(scope: Construct, id: string, config: VectorSearchIndexConfig);
    get creator(): string;
    private _endpointId?;
    get endpointId(): string;
    set endpointId(value: string);
    resetEndpointId(): void;
    get endpointIdInput(): string | undefined;
    private _endpointName?;
    get endpointName(): string;
    set endpointName(value: string);
    get endpointNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexSubtype?;
    get indexSubtype(): string;
    set indexSubtype(value: string);
    resetIndexSubtype(): void;
    get indexSubtypeInput(): string | undefined;
    private _indexType?;
    get indexType(): string;
    set indexType(value: string);
    get indexTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryKey?;
    get primaryKey(): string;
    set primaryKey(value: string);
    get primaryKeyInput(): string | undefined;
    private _status;
    get status(): VectorSearchIndexStatusList;
    private _deltaSyncIndexSpec;
    get deltaSyncIndexSpec(): VectorSearchIndexDeltaSyncIndexSpecOutputReference;
    putDeltaSyncIndexSpec(value: VectorSearchIndexDeltaSyncIndexSpec): void;
    resetDeltaSyncIndexSpec(): void;
    get deltaSyncIndexSpecInput(): VectorSearchIndexDeltaSyncIndexSpec | undefined;
    private _directAccessIndexSpec;
    get directAccessIndexSpec(): VectorSearchIndexDirectAccessIndexSpecOutputReference;
    putDirectAccessIndexSpec(value: VectorSearchIndexDirectAccessIndexSpec): void;
    resetDirectAccessIndexSpec(): void;
    get directAccessIndexSpecInput(): VectorSearchIndexDirectAccessIndexSpec | undefined;
    private _providerConfig;
    get providerConfig(): VectorSearchIndexProviderConfigOutputReference;
    putProviderConfig(value: VectorSearchIndexProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): VectorSearchIndexProviderConfig | undefined;
    private _timeouts;
    get timeouts(): VectorSearchIndexTimeoutsOutputReference;
    putTimeouts(value: VectorSearchIndexTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | VectorSearchIndexTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
