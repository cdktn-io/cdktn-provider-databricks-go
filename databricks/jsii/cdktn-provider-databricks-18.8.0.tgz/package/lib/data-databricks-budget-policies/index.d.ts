/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksBudgetPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#filter_by DataDatabricksBudgetPolicies#filter_by}
    */
    readonly filterBy?: DataDatabricksBudgetPoliciesFilterBy;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#page_size DataDatabricksBudgetPolicies#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#sort_spec DataDatabricksBudgetPolicies#sort_spec}
    */
    readonly sortSpec?: DataDatabricksBudgetPoliciesSortSpec;
}
export interface DataDatabricksBudgetPoliciesFilterBy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#creator_user_id DataDatabricksBudgetPolicies#creator_user_id}
    */
    readonly creatorUserId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#creator_user_name DataDatabricksBudgetPolicies#creator_user_name}
    */
    readonly creatorUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#policy_name DataDatabricksBudgetPolicies#policy_name}
    */
    readonly policyName?: string;
}
export declare function dataDatabricksBudgetPoliciesFilterByToTerraform(struct?: DataDatabricksBudgetPoliciesFilterBy | cdktn.IResolvable): any;
export declare function dataDatabricksBudgetPoliciesFilterByToHclTerraform(struct?: DataDatabricksBudgetPoliciesFilterBy | cdktn.IResolvable): any;
export declare class DataDatabricksBudgetPoliciesFilterByOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksBudgetPoliciesFilterBy | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksBudgetPoliciesFilterBy | cdktn.IResolvable | undefined);
    private _creatorUserId?;
    get creatorUserId(): number;
    set creatorUserId(value: number);
    resetCreatorUserId(): void;
    get creatorUserIdInput(): number | undefined;
    private _creatorUserName?;
    get creatorUserName(): string;
    set creatorUserName(value: string);
    resetCreatorUserName(): void;
    get creatorUserNameInput(): string | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    resetPolicyName(): void;
    get policyNameInput(): string | undefined;
}
export interface DataDatabricksBudgetPoliciesPoliciesCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#key DataDatabricksBudgetPolicies#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#value DataDatabricksBudgetPolicies#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksBudgetPoliciesPoliciesCustomTagsToTerraform(struct?: DataDatabricksBudgetPoliciesPoliciesCustomTags): any;
export declare function dataDatabricksBudgetPoliciesPoliciesCustomTagsToHclTerraform(struct?: DataDatabricksBudgetPoliciesPoliciesCustomTags): any;
export declare class DataDatabricksBudgetPoliciesPoliciesCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksBudgetPoliciesPoliciesCustomTags | undefined;
    set internalValue(value: DataDatabricksBudgetPoliciesPoliciesCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksBudgetPoliciesPoliciesCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksBudgetPoliciesPoliciesCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksBudgetPoliciesPoliciesCustomTagsOutputReference;
}
export interface DataDatabricksBudgetPoliciesPolicies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#policy_id DataDatabricksBudgetPolicies#policy_id}
    */
    readonly policyId: string;
}
export declare function dataDatabricksBudgetPoliciesPoliciesToTerraform(struct?: DataDatabricksBudgetPoliciesPolicies): any;
export declare function dataDatabricksBudgetPoliciesPoliciesToHclTerraform(struct?: DataDatabricksBudgetPoliciesPolicies): any;
export declare class DataDatabricksBudgetPoliciesPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksBudgetPoliciesPolicies | undefined;
    set internalValue(value: DataDatabricksBudgetPoliciesPolicies | undefined);
    get bindingWorkspaceIds(): number[];
    private _customTags;
    get customTags(): DataDatabricksBudgetPoliciesPoliciesCustomTagsList;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    get policyName(): string;
}
export declare class DataDatabricksBudgetPoliciesPoliciesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksBudgetPoliciesPolicies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksBudgetPoliciesPoliciesOutputReference;
}
export interface DataDatabricksBudgetPoliciesSortSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#descending DataDatabricksBudgetPolicies#descending}
    */
    readonly descending?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#field DataDatabricksBudgetPolicies#field}
    */
    readonly field?: string;
}
export declare function dataDatabricksBudgetPoliciesSortSpecToTerraform(struct?: DataDatabricksBudgetPoliciesSortSpec | cdktn.IResolvable): any;
export declare function dataDatabricksBudgetPoliciesSortSpecToHclTerraform(struct?: DataDatabricksBudgetPoliciesSortSpec | cdktn.IResolvable): any;
export declare class DataDatabricksBudgetPoliciesSortSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksBudgetPoliciesSortSpec | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksBudgetPoliciesSortSpec | cdktn.IResolvable | undefined);
    private _descending?;
    get descending(): boolean | cdktn.IResolvable;
    set descending(value: boolean | cdktn.IResolvable);
    resetDescending(): void;
    get descendingInput(): boolean | cdktn.IResolvable | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    resetField(): void;
    get fieldInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies databricks_budget_policies}
*/
export declare class DataDatabricksBudgetPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_budget_policies";
    /**
    * Generates CDKTN code for importing a DataDatabricksBudgetPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksBudgetPolicies to import
    * @param importFromId The id of the existing DataDatabricksBudgetPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksBudgetPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/budget_policies databricks_budget_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksBudgetPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksBudgetPoliciesConfig);
    private _filterBy;
    get filterBy(): DataDatabricksBudgetPoliciesFilterByOutputReference;
    putFilterBy(value: DataDatabricksBudgetPoliciesFilterBy): void;
    resetFilterBy(): void;
    get filterByInput(): cdktn.IResolvable | DataDatabricksBudgetPoliciesFilterBy | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _policies;
    get policies(): DataDatabricksBudgetPoliciesPoliciesList;
    private _sortSpec;
    get sortSpec(): DataDatabricksBudgetPoliciesSortSpecOutputReference;
    putSortSpec(value: DataDatabricksBudgetPoliciesSortSpec): void;
    resetSortSpec(): void;
    get sortSpecInput(): cdktn.IResolvable | DataDatabricksBudgetPoliciesSortSpec | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
