/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksJobsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs#id DataDatabricksJobs#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs#ids DataDatabricksJobs#ids}
    */
    readonly ids?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs#job_name_contains DataDatabricksJobs#job_name_contains}
    */
    readonly jobNameContains?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs#key DataDatabricksJobs#key}
    */
    readonly key?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs#provider_config DataDatabricksJobs#provider_config}
    */
    readonly providerConfig?: DataDatabricksJobsProviderConfig;
}
export interface DataDatabricksJobsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs#workspace_id DataDatabricksJobs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksJobsProviderConfigToTerraform(struct?: DataDatabricksJobsProviderConfigOutputReference | DataDatabricksJobsProviderConfig): any;
export declare function dataDatabricksJobsProviderConfigToHclTerraform(struct?: DataDatabricksJobsProviderConfigOutputReference | DataDatabricksJobsProviderConfig): any;
export declare class DataDatabricksJobsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksJobsProviderConfig | undefined;
    set internalValue(value: DataDatabricksJobsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs databricks_jobs}
*/
export declare class DataDatabricksJobs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_jobs";
    /**
    * Generates CDKTN code for importing a DataDatabricksJobs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksJobs to import
    * @param importFromId The id of the existing DataDatabricksJobs that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksJobs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/jobs databricks_jobs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksJobsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksJobsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): {
        [key: string]: string;
    };
    set ids(value: {
        [key: string]: string;
    });
    resetIds(): void;
    get idsInput(): {
        [key: string]: string;
    } | undefined;
    private _jobNameContains?;
    get jobNameContains(): string;
    set jobNameContains(value: string);
    resetJobNameContains(): void;
    get jobNameContainsInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksJobsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksJobsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksJobsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
