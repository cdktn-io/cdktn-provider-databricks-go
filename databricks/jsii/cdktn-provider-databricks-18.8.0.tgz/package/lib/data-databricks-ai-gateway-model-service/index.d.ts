/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiGatewayModelServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#name DataDatabricksAiGatewayModelService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#provider_config DataDatabricksAiGatewayModelService#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayModelServiceProviderConfig;
}
export interface DataDatabricksAiGatewayModelServiceConfigInferenceTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#parent DataDatabricksAiGatewayModelService#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#table_name_prefix DataDatabricksAiGatewayModelService#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function dataDatabricksAiGatewayModelServiceConfigInferenceTableToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigInferenceTableToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigInferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigInferenceTable | cdktn.IResolvable | undefined);
    get isDeleted(): cdktn.IResolvable;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get table(): string;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#key DataDatabricksAiGatewayModelService#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#principal DataDatabricksAiGatewayModelService#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#renewal_period DataDatabricksAiGatewayModelService#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#requests DataDatabricksAiGatewayModelService#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#tokens DataDatabricksAiGatewayModelService#tokens}
    */
    readonly tokens?: number;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRateLimitsToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRateLimits | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRateLimitsToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRateLimits | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelServiceConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelServiceConfigRateLimitsOutputReference;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model DataDatabricksAiGatewayModelService#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#native_api_types DataDatabricksAiGatewayModelService#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model_provider_service DataDatabricksAiGatewayModelService#model_provider_service}
    */
    readonly modelProviderService: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#target DataDatabricksAiGatewayModelService#target}
    */
    readonly target: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | cdktn.IResolvable | undefined);
    private _modelProviderService?;
    get modelProviderService(): string;
    set modelProviderService(value: string);
    get modelProviderServiceInput(): string | undefined;
    private _target;
    get target(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTargetOutputReference;
    putTarget(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget): void;
    get targetInput(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigTarget | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model DataDatabricksAiGatewayModelService#model}
    */
    readonly model: string;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model_serving_endpoint DataDatabricksAiGatewayModelService#model_serving_endpoint}
    */
    readonly modelServingEndpoint: string;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined);
    get model(): string;
    private _modelServingEndpoint?;
    get modelServingEndpoint(): string;
    set modelServingEndpoint(value: string);
    get modelServingEndpointInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#destination_type DataDatabricksAiGatewayModelService#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#external_model_config DataDatabricksAiGatewayModelService#external_model_config}
    */
    readonly externalModelConfig?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#name DataDatabricksAiGatewayModelService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#pay_per_token_config DataDatabricksAiGatewayModelService#pay_per_token_config}
    */
    readonly payPerTokenConfig?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#provisioned_throughput_config DataDatabricksAiGatewayModelService#provisioned_throughput_config}
    */
    readonly provisionedThroughputConfig?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#traffic_percentage DataDatabricksAiGatewayModelService#traffic_percentage}
    */
    readonly trafficPercentage?: number;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingDestinationsToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinations | cdktn.IResolvable | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _externalModelConfig;
    get externalModelConfig(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfigOutputReference;
    putExternalModelConfig(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig): void;
    resetExternalModelConfig(): void;
    get externalModelConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsExternalModelConfig | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _payPerTokenConfig;
    get payPerTokenConfig(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfigOutputReference;
    putPayPerTokenConfig(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig): void;
    resetPayPerTokenConfig(): void;
    get payPerTokenConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsPayPerTokenConfig | undefined;
    private _provisionedThroughputConfig;
    get provisionedThroughputConfig(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfigOutputReference;
    putProvisionedThroughputConfig(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig): void;
    resetProvisionedThroughputConfig(): void;
    get provisionedThroughputConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsProvisionedThroughputConfig | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    resetTrafficPercentage(): void;
    get trafficPercentageInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsOutputReference;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model DataDatabricksAiGatewayModelService#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#native_api_types DataDatabricksAiGatewayModelService#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model_provider_service DataDatabricksAiGatewayModelService#model_provider_service}
    */
    readonly modelProviderService: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#target DataDatabricksAiGatewayModelService#target}
    */
    readonly target: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | cdktn.IResolvable | undefined);
    private _modelProviderService?;
    get modelProviderService(): string;
    set modelProviderService(value: string);
    get modelProviderServiceInput(): string | undefined;
    private _target;
    get target(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTargetOutputReference;
    putTarget(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget): void;
    get targetInput(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigTarget | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model DataDatabricksAiGatewayModelService#model}
    */
    readonly model: string;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#model_serving_endpoint DataDatabricksAiGatewayModelService#model_serving_endpoint}
    */
    readonly modelServingEndpoint: string;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | cdktn.IResolvable | undefined);
    get model(): string;
    private _modelServingEndpoint?;
    get modelServingEndpoint(): string;
    set modelServingEndpoint(value: string);
    get modelServingEndpointInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#destination_type DataDatabricksAiGatewayModelService#destination_type}
    */
    readonly destinationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#external_model_config DataDatabricksAiGatewayModelService#external_model_config}
    */
    readonly externalModelConfig?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#name DataDatabricksAiGatewayModelService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#pay_per_token_config DataDatabricksAiGatewayModelService#pay_per_token_config}
    */
    readonly payPerTokenConfig?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#provisioned_throughput_config DataDatabricksAiGatewayModelService#provisioned_throughput_config}
    */
    readonly provisionedThroughputConfig?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#traffic_percentage DataDatabricksAiGatewayModelService#traffic_percentage}
    */
    readonly trafficPercentage?: number;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations | cdktn.IResolvable | undefined);
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _externalModelConfig;
    get externalModelConfig(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfigOutputReference;
    putExternalModelConfig(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig): void;
    resetExternalModelConfig(): void;
    get externalModelConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsExternalModelConfig | undefined;
    get isDeleted(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _payPerTokenConfig;
    get payPerTokenConfig(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfigOutputReference;
    putPayPerTokenConfig(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig): void;
    resetPayPerTokenConfig(): void;
    get payPerTokenConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsPayPerTokenConfig | undefined;
    private _provisionedThroughputConfig;
    get provisionedThroughputConfig(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfigOutputReference;
    putProvisionedThroughputConfig(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig): void;
    resetProvisionedThroughputConfig(): void;
    get provisionedThroughputConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsProvisionedThroughputConfig | undefined;
    private _trafficPercentage?;
    get trafficPercentage(): number;
    set trafficPercentage(value: number);
    resetTrafficPercentage(): void;
    get trafficPercentageInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsOutputReference;
}
export interface DataDatabricksAiGatewayModelServiceConfigRoutingFallback {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#destinations DataDatabricksAiGatewayModelService#destinations}
    */
    readonly destinations?: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations[] | cdktn.IResolvable;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingFallbackToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingFallbackOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallback | cdktn.IResolvable | undefined);
    private _destinations;
    get destinations(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinationsList;
    putDestinations(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingFallbackDestinations[] | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigRouting {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#destinations DataDatabricksAiGatewayModelService#destinations}
    */
    readonly destinations?: DataDatabricksAiGatewayModelServiceConfigRoutingDestinations[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#fallback DataDatabricksAiGatewayModelService#fallback}
    */
    readonly fallback?: DataDatabricksAiGatewayModelServiceConfigRoutingFallback;
}
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRouting | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceConfigRoutingToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigRouting | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceConfigRoutingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigRouting | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigRouting | cdktn.IResolvable | undefined);
    private _destinations;
    get destinations(): DataDatabricksAiGatewayModelServiceConfigRoutingDestinationsList;
    putDestinations(value: DataDatabricksAiGatewayModelServiceConfigRoutingDestinations[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingDestinations[] | undefined;
    private _fallback;
    get fallback(): DataDatabricksAiGatewayModelServiceConfigRoutingFallbackOutputReference;
    putFallback(value: DataDatabricksAiGatewayModelServiceConfigRoutingFallback): void;
    resetFallback(): void;
    get fallbackInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRoutingFallback | undefined;
}
export interface DataDatabricksAiGatewayModelServiceConfigA {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#inference_table DataDatabricksAiGatewayModelService#inference_table}
    */
    readonly inferenceTable?: DataDatabricksAiGatewayModelServiceConfigInferenceTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#rate_limits DataDatabricksAiGatewayModelService#rate_limits}
    */
    readonly rateLimits?: DataDatabricksAiGatewayModelServiceConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#routing DataDatabricksAiGatewayModelService#routing}
    */
    readonly routing?: DataDatabricksAiGatewayModelServiceConfigRouting;
}
export declare function dataDatabricksAiGatewayModelServiceConfigAToTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigA): any;
export declare function dataDatabricksAiGatewayModelServiceConfigAToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceConfigA): any;
export declare class DataDatabricksAiGatewayModelServiceConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceConfigA | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceConfigA | undefined);
    private _inferenceTable;
    get inferenceTable(): DataDatabricksAiGatewayModelServiceConfigInferenceTableOutputReference;
    putInferenceTable(value: DataDatabricksAiGatewayModelServiceConfigInferenceTable): void;
    resetInferenceTable(): void;
    get inferenceTableInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigInferenceTable | undefined;
    private _rateLimits;
    get rateLimits(): DataDatabricksAiGatewayModelServiceConfigRateLimitsList;
    putRateLimits(value: DataDatabricksAiGatewayModelServiceConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRateLimits[] | undefined;
    private _routing;
    get routing(): DataDatabricksAiGatewayModelServiceConfigRoutingOutputReference;
    putRouting(value: DataDatabricksAiGatewayModelServiceConfigRouting): void;
    resetRouting(): void;
    get routingInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceConfigRouting | undefined;
}
export interface DataDatabricksAiGatewayModelServiceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#workspace_id DataDatabricksAiGatewayModelService#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayModelServiceProviderConfigToTerraform(struct?: DataDatabricksAiGatewayModelServiceProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelServiceProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelServiceProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelServiceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelServiceProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelServiceProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service databricks_ai_gateway_model_service}
*/
export declare class DataDatabricksAiGatewayModelService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_gateway_model_service";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiGatewayModelService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiGatewayModelService to import
    * @param importFromId The id of the existing DataDatabricksAiGatewayModelService that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiGatewayModelService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_gateway_model_service databricks_ai_gateway_model_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiGatewayModelServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAiGatewayModelServiceConfig);
    get comment(): string;
    private _config;
    get config(): DataDatabricksAiGatewayModelServiceConfigAOutputReference;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayModelServiceProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayModelServiceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelServiceProviderConfig | undefined;
    get supportedApiTypes(): string[];
    get updateTime(): string;
    get updatedBy(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
