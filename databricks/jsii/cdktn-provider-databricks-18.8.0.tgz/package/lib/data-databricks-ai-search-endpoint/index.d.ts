/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiSearchEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#name DataDatabricksAiSearchEndpoint#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#provider_config DataDatabricksAiSearchEndpoint#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiSearchEndpointProviderConfig;
}
export interface DataDatabricksAiSearchEndpointCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#key DataDatabricksAiSearchEndpoint#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#value DataDatabricksAiSearchEndpoint#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAiSearchEndpointCustomTagsToTerraform(struct?: DataDatabricksAiSearchEndpointCustomTags): any;
export declare function dataDatabricksAiSearchEndpointCustomTagsToHclTerraform(struct?: DataDatabricksAiSearchEndpointCustomTags): any;
export declare class DataDatabricksAiSearchEndpointCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchEndpointCustomTags | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksAiSearchEndpointCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchEndpointCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchEndpointCustomTagsOutputReference;
}
export interface DataDatabricksAiSearchEndpointEndpointStatus {
}
export declare function dataDatabricksAiSearchEndpointEndpointStatusToTerraform(struct?: DataDatabricksAiSearchEndpointEndpointStatus): any;
export declare function dataDatabricksAiSearchEndpointEndpointStatusToHclTerraform(struct?: DataDatabricksAiSearchEndpointEndpointStatus): any;
export declare class DataDatabricksAiSearchEndpointEndpointStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointEndpointStatus | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointEndpointStatus | undefined);
    get message(): string;
    get state(): string;
}
export interface DataDatabricksAiSearchEndpointProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#workspace_id DataDatabricksAiSearchEndpoint#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiSearchEndpointProviderConfigToTerraform(struct?: DataDatabricksAiSearchEndpointProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchEndpointProviderConfigToHclTerraform(struct?: DataDatabricksAiSearchEndpointProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchEndpointProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAiSearchEndpointScalingInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#requested_target_qps DataDatabricksAiSearchEndpoint#requested_target_qps}
    */
    readonly requestedTargetQps?: number;
}
export declare function dataDatabricksAiSearchEndpointScalingInfoToTerraform(struct?: DataDatabricksAiSearchEndpointScalingInfo): any;
export declare function dataDatabricksAiSearchEndpointScalingInfoToHclTerraform(struct?: DataDatabricksAiSearchEndpointScalingInfo): any;
export declare class DataDatabricksAiSearchEndpointScalingInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointScalingInfo | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointScalingInfo | undefined);
    private _requestedTargetQps?;
    get requestedTargetQps(): number;
    set requestedTargetQps(value: number);
    resetRequestedTargetQps(): void;
    get requestedTargetQpsInput(): number | undefined;
    get state(): string;
}
export interface DataDatabricksAiSearchEndpointThroughputInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#maximum_concurrency_allowed DataDatabricksAiSearchEndpoint#maximum_concurrency_allowed}
    */
    readonly maximumConcurrencyAllowed?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#minimal_concurrency_allowed DataDatabricksAiSearchEndpoint#minimal_concurrency_allowed}
    */
    readonly minimalConcurrencyAllowed?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#requested_concurrency DataDatabricksAiSearchEndpoint#requested_concurrency}
    */
    readonly requestedConcurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#requested_num_replicas DataDatabricksAiSearchEndpoint#requested_num_replicas}
    */
    readonly requestedNumReplicas?: number;
}
export declare function dataDatabricksAiSearchEndpointThroughputInfoToTerraform(struct?: DataDatabricksAiSearchEndpointThroughputInfo): any;
export declare function dataDatabricksAiSearchEndpointThroughputInfoToHclTerraform(struct?: DataDatabricksAiSearchEndpointThroughputInfo): any;
export declare class DataDatabricksAiSearchEndpointThroughputInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchEndpointThroughputInfo | undefined;
    set internalValue(value: DataDatabricksAiSearchEndpointThroughputInfo | undefined);
    get changeRequestMessage(): string;
    get changeRequestState(): string;
    get currentConcurrency(): number;
    get currentConcurrencyUtilizationPercentage(): number;
    get currentNumReplicas(): number;
    private _maximumConcurrencyAllowed?;
    get maximumConcurrencyAllowed(): number;
    set maximumConcurrencyAllowed(value: number);
    resetMaximumConcurrencyAllowed(): void;
    get maximumConcurrencyAllowedInput(): number | undefined;
    private _minimalConcurrencyAllowed?;
    get minimalConcurrencyAllowed(): number;
    set minimalConcurrencyAllowed(value: number);
    resetMinimalConcurrencyAllowed(): void;
    get minimalConcurrencyAllowedInput(): number | undefined;
    private _requestedConcurrency?;
    get requestedConcurrency(): number;
    set requestedConcurrency(value: number);
    resetRequestedConcurrency(): void;
    get requestedConcurrencyInput(): number | undefined;
    private _requestedNumReplicas?;
    get requestedNumReplicas(): number;
    set requestedNumReplicas(value: number);
    resetRequestedNumReplicas(): void;
    get requestedNumReplicasInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint databricks_ai_search_endpoint}
*/
export declare class DataDatabricksAiSearchEndpoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_search_endpoint";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiSearchEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiSearchEndpoint to import
    * @param importFromId The id of the existing DataDatabricksAiSearchEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiSearchEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/ai_search_endpoint databricks_ai_search_endpoint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiSearchEndpointConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAiSearchEndpointConfig);
    get budgetPolicyId(): string;
    get createTime(): string;
    get creator(): string;
    private _customTags;
    get customTags(): DataDatabricksAiSearchEndpointCustomTagsList;
    get effectiveBudgetPolicyId(): string;
    private _endpointStatus;
    get endpointStatus(): DataDatabricksAiSearchEndpointEndpointStatusOutputReference;
    get endpointType(): string;
    get id(): string;
    get indexCount(): number;
    get lastUpdatedUser(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiSearchEndpointProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiSearchEndpointProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiSearchEndpointProviderConfig | undefined;
    get replicaCount(): number;
    private _scalingInfo;
    get scalingInfo(): DataDatabricksAiSearchEndpointScalingInfoOutputReference;
    get targetQps(): number;
    private _throughputInfo;
    get throughputInfo(): DataDatabricksAiSearchEndpointThroughputInfoOutputReference;
    get updateTime(): string;
    get usagePolicyId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
