/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MetastoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#api Metastore#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#default_data_access_config_id Metastore#default_data_access_config_id}
    */
    readonly defaultDataAccessConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#delta_sharing_organization_name Metastore#delta_sharing_organization_name}
    */
    readonly deltaSharingOrganizationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#delta_sharing_recipient_token_lifetime_in_seconds Metastore#delta_sharing_recipient_token_lifetime_in_seconds}
    */
    readonly deltaSharingRecipientTokenLifetimeInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#delta_sharing_scope Metastore#delta_sharing_scope}
    */
    readonly deltaSharingScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#external_access_enabled Metastore#external_access_enabled}
    */
    readonly externalAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#force_destroy Metastore#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#id Metastore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#name Metastore#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#owner Metastore#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#privilege_model_version Metastore#privilege_model_version}
    */
    readonly privilegeModelVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#region Metastore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#storage_root Metastore#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#storage_root_credential_id Metastore#storage_root_credential_id}
    */
    readonly storageRootCredentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#storage_root_credential_name Metastore#storage_root_credential_name}
    */
    readonly storageRootCredentialName?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#provider_config Metastore#provider_config}
    */
    readonly providerConfig?: MetastoreProviderConfig;
}
export interface MetastoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#workspace_id Metastore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function metastoreProviderConfigToTerraform(struct?: MetastoreProviderConfigOutputReference | MetastoreProviderConfig): any;
export declare function metastoreProviderConfigToHclTerraform(struct?: MetastoreProviderConfigOutputReference | MetastoreProviderConfig): any;
export declare class MetastoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MetastoreProviderConfig | undefined;
    set internalValue(value: MetastoreProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore databricks_metastore}
*/
export declare class Metastore extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_metastore";
    /**
    * Generates CDKTN code for importing a Metastore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Metastore to import
    * @param importFromId The id of the existing Metastore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Metastore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/resources/metastore databricks_metastore} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MetastoreConfig = {}
    */
    constructor(scope: Construct, id: string, config?: MetastoreConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    get cloud(): string;
    get createdAt(): number;
    get createdBy(): string;
    private _defaultDataAccessConfigId?;
    get defaultDataAccessConfigId(): string;
    set defaultDataAccessConfigId(value: string);
    resetDefaultDataAccessConfigId(): void;
    get defaultDataAccessConfigIdInput(): string | undefined;
    private _deltaSharingOrganizationName?;
    get deltaSharingOrganizationName(): string;
    set deltaSharingOrganizationName(value: string);
    resetDeltaSharingOrganizationName(): void;
    get deltaSharingOrganizationNameInput(): string | undefined;
    private _deltaSharingRecipientTokenLifetimeInSeconds?;
    get deltaSharingRecipientTokenLifetimeInSeconds(): number;
    set deltaSharingRecipientTokenLifetimeInSeconds(value: number);
    resetDeltaSharingRecipientTokenLifetimeInSeconds(): void;
    get deltaSharingRecipientTokenLifetimeInSecondsInput(): number | undefined;
    private _deltaSharingScope?;
    get deltaSharingScope(): string;
    set deltaSharingScope(value: string);
    resetDeltaSharingScope(): void;
    get deltaSharingScopeInput(): string | undefined;
    private _externalAccessEnabled?;
    get externalAccessEnabled(): boolean | cdktn.IResolvable;
    set externalAccessEnabled(value: boolean | cdktn.IResolvable);
    resetExternalAccessEnabled(): void;
    get externalAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get globalMetastoreId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _privilegeModelVersion?;
    get privilegeModelVersion(): string;
    set privilegeModelVersion(value: string);
    resetPrivilegeModelVersion(): void;
    get privilegeModelVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    private _storageRootCredentialId?;
    get storageRootCredentialId(): string;
    set storageRootCredentialId(value: string);
    resetStorageRootCredentialId(): void;
    get storageRootCredentialIdInput(): string | undefined;
    private _storageRootCredentialName?;
    get storageRootCredentialName(): string;
    set storageRootCredentialName(value: string);
    resetStorageRootCredentialName(): void;
    get storageRootCredentialNameInput(): string | undefined;
    get updatedAt(): number;
    get updatedBy(): string;
    private _providerConfig;
    get providerConfig(): MetastoreProviderConfigOutputReference;
    putProviderConfig(value: MetastoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): MetastoreProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
