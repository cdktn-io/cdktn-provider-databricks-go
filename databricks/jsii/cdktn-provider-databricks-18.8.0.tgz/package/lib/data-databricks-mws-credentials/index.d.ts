/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMwsCredentialsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mws_credentials#id DataDatabricksMwsCredentials#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mws_credentials#ids DataDatabricksMwsCredentials#ids}
    */
    readonly ids?: {
        [key: string]: string;
    };
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mws_credentials#provider_config DataDatabricksMwsCredentials#provider_config}
    */
    readonly providerConfig?: DataDatabricksMwsCredentialsProviderConfig;
}
export interface DataDatabricksMwsCredentialsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mws_credentials#workspace_id DataDatabricksMwsCredentials#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMwsCredentialsProviderConfigToTerraform(struct?: DataDatabricksMwsCredentialsProviderConfigOutputReference | DataDatabricksMwsCredentialsProviderConfig): any;
export declare function dataDatabricksMwsCredentialsProviderConfigToHclTerraform(struct?: DataDatabricksMwsCredentialsProviderConfigOutputReference | DataDatabricksMwsCredentialsProviderConfig): any;
export declare class DataDatabricksMwsCredentialsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMwsCredentialsProviderConfig | undefined;
    set internalValue(value: DataDatabricksMwsCredentialsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mws_credentials databricks_mws_credentials}
*/
export declare class DataDatabricksMwsCredentials extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mws_credentials";
    /**
    * Generates CDKTN code for importing a DataDatabricksMwsCredentials resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMwsCredentials to import
    * @param importFromId The id of the existing DataDatabricksMwsCredentials that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mws_credentials#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMwsCredentials to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mws_credentials databricks_mws_credentials} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMwsCredentialsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksMwsCredentialsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): {
        [key: string]: string;
    };
    set ids(value: {
        [key: string]: string;
    });
    resetIds(): void;
    get idsInput(): {
        [key: string]: string;
    } | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMwsCredentialsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMwsCredentialsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksMwsCredentialsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
