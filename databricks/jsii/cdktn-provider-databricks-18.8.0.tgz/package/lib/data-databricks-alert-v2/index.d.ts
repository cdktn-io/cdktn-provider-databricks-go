/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAlertV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#id DataDatabricksAlertV2#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#provider_config DataDatabricksAlertV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksAlertV2ProviderConfig;
}
export interface DataDatabricksAlertV2EffectiveRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#service_principal_name DataDatabricksAlertV2#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#user_name DataDatabricksAlertV2#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksAlertV2EffectiveRunAsToTerraform(struct?: DataDatabricksAlertV2EffectiveRunAs): any;
export declare function dataDatabricksAlertV2EffectiveRunAsToHclTerraform(struct?: DataDatabricksAlertV2EffectiveRunAs): any;
export declare class DataDatabricksAlertV2EffectiveRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2EffectiveRunAs | undefined;
    set internalValue(value: DataDatabricksAlertV2EffectiveRunAs | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface DataDatabricksAlertV2EvaluationNotificationSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#destination_id DataDatabricksAlertV2#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#user_email DataDatabricksAlertV2#user_email}
    */
    readonly userEmail?: string;
}
export declare function dataDatabricksAlertV2EvaluationNotificationSubscriptionsToTerraform(struct?: DataDatabricksAlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable): any;
export declare function dataDatabricksAlertV2EvaluationNotificationSubscriptionsToHclTerraform(struct?: DataDatabricksAlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable): any;
export declare class DataDatabricksAlertV2EvaluationNotificationSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertV2EvaluationNotificationSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userEmail?;
    get userEmail(): string;
    set userEmail(value: string);
    resetUserEmail(): void;
    get userEmailInput(): string | undefined;
}
export declare class DataDatabricksAlertV2EvaluationNotificationSubscriptionsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAlertV2EvaluationNotificationSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAlertV2EvaluationNotificationSubscriptionsOutputReference;
}
export interface DataDatabricksAlertV2EvaluationNotification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#notify_on_ok DataDatabricksAlertV2#notify_on_ok}
    */
    readonly notifyOnOk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#retrigger_seconds DataDatabricksAlertV2#retrigger_seconds}
    */
    readonly retriggerSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#subscriptions DataDatabricksAlertV2#subscriptions}
    */
    readonly subscriptions?: DataDatabricksAlertV2EvaluationNotificationSubscriptions[] | cdktn.IResolvable;
}
export declare function dataDatabricksAlertV2EvaluationNotificationToTerraform(struct?: DataDatabricksAlertV2EvaluationNotification | cdktn.IResolvable): any;
export declare function dataDatabricksAlertV2EvaluationNotificationToHclTerraform(struct?: DataDatabricksAlertV2EvaluationNotification | cdktn.IResolvable): any;
export declare class DataDatabricksAlertV2EvaluationNotificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2EvaluationNotification | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertV2EvaluationNotification | cdktn.IResolvable | undefined);
    get effectiveNotifyOnOk(): cdktn.IResolvable;
    get effectiveRetriggerSeconds(): number;
    private _notifyOnOk?;
    get notifyOnOk(): boolean | cdktn.IResolvable;
    set notifyOnOk(value: boolean | cdktn.IResolvable);
    resetNotifyOnOk(): void;
    get notifyOnOkInput(): boolean | cdktn.IResolvable | undefined;
    private _retriggerSeconds?;
    get retriggerSeconds(): number;
    set retriggerSeconds(value: number);
    resetRetriggerSeconds(): void;
    get retriggerSecondsInput(): number | undefined;
    private _subscriptions;
    get subscriptions(): DataDatabricksAlertV2EvaluationNotificationSubscriptionsList;
    putSubscriptions(value: DataDatabricksAlertV2EvaluationNotificationSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | DataDatabricksAlertV2EvaluationNotificationSubscriptions[] | undefined;
}
export interface DataDatabricksAlertV2EvaluationSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#aggregation DataDatabricksAlertV2#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#display DataDatabricksAlertV2#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#name DataDatabricksAlertV2#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAlertV2EvaluationSourceToTerraform(struct?: DataDatabricksAlertV2EvaluationSource): any;
export declare function dataDatabricksAlertV2EvaluationSourceToHclTerraform(struct?: DataDatabricksAlertV2EvaluationSource): any;
export declare class DataDatabricksAlertV2EvaluationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2EvaluationSource | undefined;
    set internalValue(value: DataDatabricksAlertV2EvaluationSource | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAlertV2EvaluationThresholdColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#aggregation DataDatabricksAlertV2#aggregation}
    */
    readonly aggregation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#display DataDatabricksAlertV2#display}
    */
    readonly display?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#name DataDatabricksAlertV2#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAlertV2EvaluationThresholdColumnToTerraform(struct?: DataDatabricksAlertV2EvaluationThresholdColumn | cdktn.IResolvable): any;
export declare function dataDatabricksAlertV2EvaluationThresholdColumnToHclTerraform(struct?: DataDatabricksAlertV2EvaluationThresholdColumn | cdktn.IResolvable): any;
export declare class DataDatabricksAlertV2EvaluationThresholdColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2EvaluationThresholdColumn | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertV2EvaluationThresholdColumn | cdktn.IResolvable | undefined);
    private _aggregation?;
    get aggregation(): string;
    set aggregation(value: string);
    resetAggregation(): void;
    get aggregationInput(): string | undefined;
    private _display?;
    get display(): string;
    set display(value: string);
    resetDisplay(): void;
    get displayInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAlertV2EvaluationThresholdValue {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#bool_value DataDatabricksAlertV2#bool_value}
    */
    readonly boolValue?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#double_value DataDatabricksAlertV2#double_value}
    */
    readonly doubleValue?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#string_value DataDatabricksAlertV2#string_value}
    */
    readonly stringValue?: string;
}
export declare function dataDatabricksAlertV2EvaluationThresholdValueToTerraform(struct?: DataDatabricksAlertV2EvaluationThresholdValue | cdktn.IResolvable): any;
export declare function dataDatabricksAlertV2EvaluationThresholdValueToHclTerraform(struct?: DataDatabricksAlertV2EvaluationThresholdValue | cdktn.IResolvable): any;
export declare class DataDatabricksAlertV2EvaluationThresholdValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2EvaluationThresholdValue | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertV2EvaluationThresholdValue | cdktn.IResolvable | undefined);
    private _boolValue?;
    get boolValue(): boolean | cdktn.IResolvable;
    set boolValue(value: boolean | cdktn.IResolvable);
    resetBoolValue(): void;
    get boolValueInput(): boolean | cdktn.IResolvable | undefined;
    private _doubleValue?;
    get doubleValue(): number;
    set doubleValue(value: number);
    resetDoubleValue(): void;
    get doubleValueInput(): number | undefined;
    private _stringValue?;
    get stringValue(): string;
    set stringValue(value: string);
    resetStringValue(): void;
    get stringValueInput(): string | undefined;
}
export interface DataDatabricksAlertV2EvaluationThreshold {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#column DataDatabricksAlertV2#column}
    */
    readonly column?: DataDatabricksAlertV2EvaluationThresholdColumn;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#value DataDatabricksAlertV2#value}
    */
    readonly value?: DataDatabricksAlertV2EvaluationThresholdValue;
}
export declare function dataDatabricksAlertV2EvaluationThresholdToTerraform(struct?: DataDatabricksAlertV2EvaluationThreshold | cdktn.IResolvable): any;
export declare function dataDatabricksAlertV2EvaluationThresholdToHclTerraform(struct?: DataDatabricksAlertV2EvaluationThreshold | cdktn.IResolvable): any;
export declare class DataDatabricksAlertV2EvaluationThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2EvaluationThreshold | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertV2EvaluationThreshold | cdktn.IResolvable | undefined);
    private _column;
    get column(): DataDatabricksAlertV2EvaluationThresholdColumnOutputReference;
    putColumn(value: DataDatabricksAlertV2EvaluationThresholdColumn): void;
    resetColumn(): void;
    get columnInput(): cdktn.IResolvable | DataDatabricksAlertV2EvaluationThresholdColumn | undefined;
    private _value;
    get value(): DataDatabricksAlertV2EvaluationThresholdValueOutputReference;
    putValue(value: DataDatabricksAlertV2EvaluationThresholdValue): void;
    resetValue(): void;
    get valueInput(): cdktn.IResolvable | DataDatabricksAlertV2EvaluationThresholdValue | undefined;
}
export interface DataDatabricksAlertV2Evaluation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#comparison_operator DataDatabricksAlertV2#comparison_operator}
    */
    readonly comparisonOperator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#empty_result_state DataDatabricksAlertV2#empty_result_state}
    */
    readonly emptyResultState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#notification DataDatabricksAlertV2#notification}
    */
    readonly notification?: DataDatabricksAlertV2EvaluationNotification;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#source DataDatabricksAlertV2#source}
    */
    readonly source: DataDatabricksAlertV2EvaluationSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#threshold DataDatabricksAlertV2#threshold}
    */
    readonly threshold?: DataDatabricksAlertV2EvaluationThreshold;
}
export declare function dataDatabricksAlertV2EvaluationToTerraform(struct?: DataDatabricksAlertV2Evaluation): any;
export declare function dataDatabricksAlertV2EvaluationToHclTerraform(struct?: DataDatabricksAlertV2Evaluation): any;
export declare class DataDatabricksAlertV2EvaluationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2Evaluation | undefined;
    set internalValue(value: DataDatabricksAlertV2Evaluation | undefined);
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    get comparisonOperatorInput(): string | undefined;
    private _emptyResultState?;
    get emptyResultState(): string;
    set emptyResultState(value: string);
    resetEmptyResultState(): void;
    get emptyResultStateInput(): string | undefined;
    get lastEvaluatedAt(): string;
    private _notification;
    get notification(): DataDatabricksAlertV2EvaluationNotificationOutputReference;
    putNotification(value: DataDatabricksAlertV2EvaluationNotification): void;
    resetNotification(): void;
    get notificationInput(): cdktn.IResolvable | DataDatabricksAlertV2EvaluationNotification | undefined;
    private _source;
    get source(): DataDatabricksAlertV2EvaluationSourceOutputReference;
    putSource(value: DataDatabricksAlertV2EvaluationSource): void;
    get sourceInput(): DataDatabricksAlertV2EvaluationSource | undefined;
    get state(): string;
    private _threshold;
    get threshold(): DataDatabricksAlertV2EvaluationThresholdOutputReference;
    putThreshold(value: DataDatabricksAlertV2EvaluationThreshold): void;
    resetThreshold(): void;
    get thresholdInput(): cdktn.IResolvable | DataDatabricksAlertV2EvaluationThreshold | undefined;
}
export interface DataDatabricksAlertV2Parameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#name DataDatabricksAlertV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#type DataDatabricksAlertV2#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#value DataDatabricksAlertV2#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksAlertV2ParametersToTerraform(struct?: DataDatabricksAlertV2Parameters): any;
export declare function dataDatabricksAlertV2ParametersToHclTerraform(struct?: DataDatabricksAlertV2Parameters): any;
export declare class DataDatabricksAlertV2ParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAlertV2Parameters | undefined;
    set internalValue(value: DataDatabricksAlertV2Parameters | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksAlertV2ParametersList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAlertV2Parameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAlertV2ParametersOutputReference;
}
export interface DataDatabricksAlertV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#workspace_id DataDatabricksAlertV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAlertV2ProviderConfigToTerraform(struct?: DataDatabricksAlertV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAlertV2ProviderConfigToHclTerraform(struct?: DataDatabricksAlertV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAlertV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAlertV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAlertV2RunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#service_principal_name DataDatabricksAlertV2#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#user_name DataDatabricksAlertV2#user_name}
    */
    readonly userName?: string;
}
export declare function dataDatabricksAlertV2RunAsToTerraform(struct?: DataDatabricksAlertV2RunAs): any;
export declare function dataDatabricksAlertV2RunAsToHclTerraform(struct?: DataDatabricksAlertV2RunAs): any;
export declare class DataDatabricksAlertV2RunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2RunAs | undefined;
    set internalValue(value: DataDatabricksAlertV2RunAs | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface DataDatabricksAlertV2Schedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#pause_status DataDatabricksAlertV2#pause_status}
    */
    readonly pauseStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#quartz_cron_schedule DataDatabricksAlertV2#quartz_cron_schedule}
    */
    readonly quartzCronSchedule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#timezone_id DataDatabricksAlertV2#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function dataDatabricksAlertV2ScheduleToTerraform(struct?: DataDatabricksAlertV2Schedule): any;
export declare function dataDatabricksAlertV2ScheduleToHclTerraform(struct?: DataDatabricksAlertV2Schedule): any;
export declare class DataDatabricksAlertV2ScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAlertV2Schedule | undefined;
    set internalValue(value: DataDatabricksAlertV2Schedule | undefined);
    private _pauseStatus?;
    get pauseStatus(): string;
    set pauseStatus(value: string);
    resetPauseStatus(): void;
    get pauseStatusInput(): string | undefined;
    private _quartzCronSchedule?;
    get quartzCronSchedule(): string;
    set quartzCronSchedule(value: string);
    get quartzCronScheduleInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2 databricks_alert_v2}
*/
export declare class DataDatabricksAlertV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_alert_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAlertV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAlertV2 to import
    * @param importFromId The id of the existing DataDatabricksAlertV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAlertV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/alert_v2 databricks_alert_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAlertV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAlertV2Config);
    get createTime(): string;
    get customDescription(): string;
    get customSummary(): string;
    get displayName(): string;
    private _effectiveRunAs;
    get effectiveRunAs(): DataDatabricksAlertV2EffectiveRunAsOutputReference;
    private _evaluation;
    get evaluation(): DataDatabricksAlertV2EvaluationOutputReference;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get lifecycleState(): string;
    get ownerUserName(): string;
    private _parameters;
    get parameters(): DataDatabricksAlertV2ParametersList;
    get parentPath(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAlertV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAlertV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAlertV2ProviderConfig | undefined;
    get queryText(): string;
    private _runAs;
    get runAs(): DataDatabricksAlertV2RunAsOutputReference;
    get runAsUserName(): string;
    private _schedule;
    get schedule(): DataDatabricksAlertV2ScheduleOutputReference;
    get updateTime(): string;
    get warehouseId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
