/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksMlflowModelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mlflow_models#id DataDatabricksMlflowModels#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mlflow_models#names DataDatabricksMlflowModels#names}
    */
    readonly names?: string[];
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mlflow_models#provider_config DataDatabricksMlflowModels#provider_config}
    */
    readonly providerConfig?: DataDatabricksMlflowModelsProviderConfig;
}
export interface DataDatabricksMlflowModelsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mlflow_models#workspace_id DataDatabricksMlflowModels#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksMlflowModelsProviderConfigToTerraform(struct?: DataDatabricksMlflowModelsProviderConfigOutputReference | DataDatabricksMlflowModelsProviderConfig): any;
export declare function dataDatabricksMlflowModelsProviderConfigToHclTerraform(struct?: DataDatabricksMlflowModelsProviderConfigOutputReference | DataDatabricksMlflowModelsProviderConfig): any;
export declare class DataDatabricksMlflowModelsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksMlflowModelsProviderConfig | undefined;
    set internalValue(value: DataDatabricksMlflowModelsProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mlflow_models databricks_mlflow_models}
*/
export declare class DataDatabricksMlflowModels extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_mlflow_models";
    /**
    * Generates CDKTN code for importing a DataDatabricksMlflowModels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksMlflowModels to import
    * @param importFromId The id of the existing DataDatabricksMlflowModels that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mlflow_models#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksMlflowModels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.133.0/docs/data-sources/mlflow_models databricks_mlflow_models} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksMlflowModelsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksMlflowModelsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _names?;
    get names(): string[];
    set names(value: string[]);
    resetNames(): void;
    get namesInput(): string[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksMlflowModelsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksMlflowModelsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksMlflowModelsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
