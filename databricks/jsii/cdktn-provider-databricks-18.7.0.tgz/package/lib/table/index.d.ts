/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#catalog_name Table#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#comment Table#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#data_source_format Table#data_source_format}
    */
    readonly dataSourceFormat: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#id Table#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#name Table#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#owner Table#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#properties Table#properties}
    */
    readonly properties?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#schema_name Table#schema_name}
    */
    readonly schemaName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#storage_credential_name Table#storage_credential_name}
    */
    readonly storageCredentialName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#storage_location Table#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#table_type Table#table_type}
    */
    readonly tableType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#view_definition Table#view_definition}
    */
    readonly viewDefinition?: string;
    /**
    * column block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#column Table#column}
    */
    readonly column: TableColumn[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#provider_config Table#provider_config}
    */
    readonly providerConfig?: TableProviderConfig;
}
export interface TableColumn {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#comment Table#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#name Table#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#nullable Table#nullable}
    */
    readonly nullable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#partition_index Table#partition_index}
    */
    readonly partitionIndex?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#position Table#position}
    */
    readonly position: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#type_interval_type Table#type_interval_type}
    */
    readonly typeIntervalType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#type_json Table#type_json}
    */
    readonly typeJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#type_name Table#type_name}
    */
    readonly typeName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#type_precision Table#type_precision}
    */
    readonly typePrecision?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#type_scale Table#type_scale}
    */
    readonly typeScale?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#type_text Table#type_text}
    */
    readonly typeText: string;
}
export declare function tableColumnToTerraform(struct?: TableColumn | cdktn.IResolvable): any;
export declare function tableColumnToHclTerraform(struct?: TableColumn | cdktn.IResolvable): any;
export declare class TableColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): TableColumn | cdktn.IResolvable | undefined;
    set internalValue(value: TableColumn | cdktn.IResolvable | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nullable?;
    get nullable(): boolean | cdktn.IResolvable;
    set nullable(value: boolean | cdktn.IResolvable);
    resetNullable(): void;
    get nullableInput(): boolean | cdktn.IResolvable | undefined;
    private _partitionIndex?;
    get partitionIndex(): number;
    set partitionIndex(value: number);
    resetPartitionIndex(): void;
    get partitionIndexInput(): number | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    get positionInput(): number | undefined;
    private _typeIntervalType?;
    get typeIntervalType(): string;
    set typeIntervalType(value: string);
    resetTypeIntervalType(): void;
    get typeIntervalTypeInput(): string | undefined;
    private _typeJson?;
    get typeJson(): string;
    set typeJson(value: string);
    resetTypeJson(): void;
    get typeJsonInput(): string | undefined;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    get typeNameInput(): string | undefined;
    private _typePrecision?;
    get typePrecision(): number;
    set typePrecision(value: number);
    resetTypePrecision(): void;
    get typePrecisionInput(): number | undefined;
    private _typeScale?;
    get typeScale(): number;
    set typeScale(value: number);
    resetTypeScale(): void;
    get typeScaleInput(): number | undefined;
    private _typeText?;
    get typeText(): string;
    set typeText(value: string);
    get typeTextInput(): string | undefined;
}
export declare class TableColumnList extends cdktn.ComplexList {
    internalValue?: TableColumn[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): TableColumnOutputReference;
}
export interface TableProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#workspace_id Table#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function tableProviderConfigToTerraform(struct?: TableProviderConfigOutputReference | TableProviderConfig): any;
export declare function tableProviderConfigToHclTerraform(struct?: TableProviderConfigOutputReference | TableProviderConfig): any;
export declare class TableProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): TableProviderConfig | undefined;
    set internalValue(value: TableProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table databricks_table}
*/
export declare class Table extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_table";
    /**
    * Generates CDKTN code for importing a Table resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Table to import
    * @param importFromId The id of the existing Table that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Table to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/table databricks_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TableConfig
    */
    constructor(scope: Construct, id: string, config: TableConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _dataSourceFormat?;
    get dataSourceFormat(): string;
    set dataSourceFormat(value: string);
    get dataSourceFormatInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _properties?;
    get properties(): {
        [key: string]: string;
    };
    set properties(value: {
        [key: string]: string;
    });
    resetProperties(): void;
    get propertiesInput(): {
        [key: string]: string;
    } | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    private _storageCredentialName?;
    get storageCredentialName(): string;
    set storageCredentialName(value: string);
    resetStorageCredentialName(): void;
    get storageCredentialNameInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    private _tableType?;
    get tableType(): string;
    set tableType(value: string);
    get tableTypeInput(): string | undefined;
    private _viewDefinition?;
    get viewDefinition(): string;
    set viewDefinition(value: string);
    resetViewDefinition(): void;
    get viewDefinitionInput(): string | undefined;
    private _column;
    get column(): TableColumnList;
    putColumn(value: TableColumn[] | cdktn.IResolvable): void;
    get columnInput(): cdktn.IResolvable | TableColumn[] | undefined;
    private _providerConfig;
    get providerConfig(): TableProviderConfigOutputReference;
    putProviderConfig(value: TableProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): TableProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
