/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksFeatureEngineeringKafkaConfigsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#page_size DataDatabricksFeatureEngineeringKafkaConfigs#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#provider_config DataDatabricksFeatureEngineeringKafkaConfigs#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#key DataDatabricksFeatureEngineeringKafkaConfigs#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#scope DataDatabricksFeatureEngineeringKafkaConfigs#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRefToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRefToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#key DataDatabricksFeatureEngineeringKafkaConfigs#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#scope DataDatabricksFeatureEngineeringKafkaConfigs#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRefToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRefToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#key DataDatabricksFeatureEngineeringKafkaConfigs#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#scope DataDatabricksFeatureEngineeringKafkaConfigs#scope}
    */
    readonly scope: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRefToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRefToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#disable_hostname_verification DataDatabricksFeatureEngineeringKafkaConfigs#disable_hostname_verification}
    */
    readonly disableHostnameVerification?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#key_password_ref DataDatabricksFeatureEngineeringKafkaConfigs#key_password_ref}
    */
    readonly keyPasswordRef: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#keystore_location DataDatabricksFeatureEngineeringKafkaConfigs#keystore_location}
    */
    readonly keystoreLocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#keystore_password_ref DataDatabricksFeatureEngineeringKafkaConfigs#keystore_password_ref}
    */
    readonly keystorePasswordRef: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#truststore_location DataDatabricksFeatureEngineeringKafkaConfigs#truststore_location}
    */
    readonly truststoreLocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#truststore_password_ref DataDatabricksFeatureEngineeringKafkaConfigs#truststore_password_ref}
    */
    readonly truststorePasswordRef: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig | cdktn.IResolvable | undefined);
    private _disableHostnameVerification?;
    get disableHostnameVerification(): boolean | cdktn.IResolvable;
    set disableHostnameVerification(value: boolean | cdktn.IResolvable);
    resetDisableHostnameVerification(): void;
    get disableHostnameVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _keyPasswordRef;
    get keyPasswordRef(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRefOutputReference;
    putKeyPasswordRef(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef): void;
    get keyPasswordRefInput(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeyPasswordRef | undefined;
    private _keystoreLocation?;
    get keystoreLocation(): string;
    set keystoreLocation(value: string);
    get keystoreLocationInput(): string | undefined;
    private _keystorePasswordRef;
    get keystorePasswordRef(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRefOutputReference;
    putKeystorePasswordRef(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef): void;
    get keystorePasswordRefInput(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigKeystorePasswordRef | undefined;
    private _truststoreLocation?;
    get truststoreLocation(): string;
    set truststoreLocation(value: string);
    get truststoreLocationInput(): string | undefined;
    private _truststorePasswordRef;
    get truststorePasswordRef(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRefOutputReference;
    putTruststorePasswordRef(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef): void;
    get truststorePasswordRefInput(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigTruststorePasswordRef | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#mtls_config DataDatabricksFeatureEngineeringKafkaConfigs#mtls_config}
    */
    readonly mtlsConfig?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#uc_service_credential_name DataDatabricksFeatureEngineeringKafkaConfigs#uc_service_credential_name}
    */
    readonly ucServiceCredentialName?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfig): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfig): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfig | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfig | undefined);
    private _mtlsConfig;
    get mtlsConfig(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfigOutputReference;
    putMtlsConfig(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig): void;
    resetMtlsConfig(): void;
    get mtlsConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigMtlsConfig | undefined;
    private _ucServiceCredentialName?;
    get ucServiceCredentialName(): string;
    set ucServiceCredentialName(value: string);
    resetUcServiceCredentialName(): void;
    get ucServiceCredentialNameInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#dataframe_schema DataDatabricksFeatureEngineeringKafkaConfigs#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#entity_columns DataDatabricksFeatureEngineeringKafkaConfigs#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#filter_condition DataDatabricksFeatureEngineeringKafkaConfigs#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#full_name DataDatabricksFeatureEngineeringKafkaConfigs#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#timeseries_column DataDatabricksFeatureEngineeringKafkaConfigs#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#transformation_sql DataDatabricksFeatureEngineeringKafkaConfigs#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#delta_table_name DataDatabricksFeatureEngineeringKafkaConfigs#delta_table_name}
    */
    readonly deltaTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#delta_table_source DataDatabricksFeatureEngineeringKafkaConfigs#delta_table_source}
    */
    readonly deltaTableSource?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSource): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSource): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSource | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSource | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
    private _deltaTableSource;
    get deltaTableSource(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceDeltaTableSource | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#dataframe_schema DataDatabricksFeatureEngineeringKafkaConfigs#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#entity_columns DataDatabricksFeatureEngineeringKafkaConfigs#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#filter_condition DataDatabricksFeatureEngineeringKafkaConfigs#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#full_name DataDatabricksFeatureEngineeringKafkaConfigs#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#timeseries_column DataDatabricksFeatureEngineeringKafkaConfigs#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#transformation_sql DataDatabricksFeatureEngineeringKafkaConfigs#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#delta_table_name DataDatabricksFeatureEngineeringKafkaConfigs#delta_table_name}
    */
    readonly deltaTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#delta_table_source DataDatabricksFeatureEngineeringKafkaConfigs#delta_table_source}
    */
    readonly deltaTableSource?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource | cdktn.IResolvable | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
    private _deltaTableSource;
    get deltaTableSource(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceDeltaTableSource | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#delta_table_name DataDatabricksFeatureEngineeringKafkaConfigs#delta_table_name}
    */
    readonly deltaTableName?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestinationToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestinationToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#backfill_source DataDatabricksFeatureEngineeringKafkaConfigs#backfill_source}
    */
    readonly backfillSource?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#budget_policy_id DataDatabricksFeatureEngineeringKafkaConfigs#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#deduplication_columns DataDatabricksFeatureEngineeringKafkaConfigs#deduplication_columns}
    */
    readonly deduplicationColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#ingestion_destination DataDatabricksFeatureEngineeringKafkaConfigs#ingestion_destination}
    */
    readonly ingestionDestination: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#tags DataDatabricksFeatureEngineeringKafkaConfigs#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfig): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfig): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfig | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfig | undefined);
    get backfillJobId(): number;
    private _backfillSource;
    get backfillSource(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSourceOutputReference;
    putBackfillSource(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource): void;
    resetBackfillSource(): void;
    get backfillSourceInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigBackfillSource | undefined;
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _deduplicationColumns?;
    get deduplicationColumns(): string[];
    set deduplicationColumns(value: string[]);
    resetDeduplicationColumns(): void;
    get deduplicationColumnsInput(): string[] | undefined;
    private _ingestionDestination;
    get ingestionDestination(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestinationOutputReference;
    putIngestionDestination(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination): void;
    get ingestionDestinationInput(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigIngestionDestination | undefined;
    get ingestionJobId(): number;
    get ingestionPipelineId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#message_name DataDatabricksFeatureEngineeringKafkaConfigs#message_name}
    */
    readonly messageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#schema_text DataDatabricksFeatureEngineeringKafkaConfigs#schema_text}
    */
    readonly schemaText: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema | cdktn.IResolvable | undefined);
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    get messageNameInput(): string | undefined;
    private _schemaText?;
    get schemaText(): string;
    set schemaText(value: string);
    get schemaTextInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#avro_schema DataDatabricksFeatureEngineeringKafkaConfigs#avro_schema}
    */
    readonly avroSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#json_schema DataDatabricksFeatureEngineeringKafkaConfigs#json_schema}
    */
    readonly jsonSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#proto_schema DataDatabricksFeatureEngineeringKafkaConfigs#proto_schema}
    */
    readonly protoSchema?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchema): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchema): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchema | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchema | undefined);
    private _avroSchema?;
    get avroSchema(): string;
    set avroSchema(value: string);
    resetAvroSchema(): void;
    get avroSchemaInput(): string | undefined;
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
    private _protoSchema;
    get protoSchema(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchemaOutputReference;
    putProtoSchema(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema): void;
    resetProtoSchema(): void;
    get protoSchemaInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaProtoSchema | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#workspace_id DataDatabricksFeatureEngineeringKafkaConfigs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#assign DataDatabricksFeatureEngineeringKafkaConfigs#assign}
    */
    readonly assign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#subscribe DataDatabricksFeatureEngineeringKafkaConfigs#subscribe}
    */
    readonly subscribe?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#subscribe_pattern DataDatabricksFeatureEngineeringKafkaConfigs#subscribe_pattern}
    */
    readonly subscribePattern?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionModeToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionMode): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionModeToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionMode): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionMode | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionMode | undefined);
    private _assign?;
    get assign(): string;
    set assign(value: string);
    resetAssign(): void;
    get assignInput(): string | undefined;
    private _subscribe?;
    get subscribe(): string;
    set subscribe(value: string);
    resetSubscribe(): void;
    get subscribeInput(): string | undefined;
    private _subscribePattern?;
    get subscribePattern(): string;
    set subscribePattern(value: string);
    resetSubscribePattern(): void;
    get subscribePatternInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#message_name DataDatabricksFeatureEngineeringKafkaConfigs#message_name}
    */
    readonly messageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#schema_text DataDatabricksFeatureEngineeringKafkaConfigs#schema_text}
    */
    readonly schemaText: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema | cdktn.IResolvable | undefined);
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    get messageNameInput(): string | undefined;
    private _schemaText?;
    get schemaText(): string;
    set schemaText(value: string);
    get schemaTextInput(): string | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#avro_schema DataDatabricksFeatureEngineeringKafkaConfigs#avro_schema}
    */
    readonly avroSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#json_schema DataDatabricksFeatureEngineeringKafkaConfigs#json_schema}
    */
    readonly jsonSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#proto_schema DataDatabricksFeatureEngineeringKafkaConfigs#proto_schema}
    */
    readonly protoSchema?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchema): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchema): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchema | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchema | undefined);
    private _avroSchema?;
    get avroSchema(): string;
    set avroSchema(value: string);
    resetAvroSchema(): void;
    get avroSchemaInput(): string | undefined;
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
    private _protoSchema;
    get protoSchema(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchemaOutputReference;
    putProtoSchema(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema): void;
    resetProtoSchema(): void;
    get protoSchemaInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaProtoSchema | undefined;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#name DataDatabricksFeatureEngineeringKafkaConfigs#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#provider_config DataDatabricksFeatureEngineeringKafkaConfigs#provider_config}
    */
    readonly providerConfig?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigs): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigs): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigs | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigs | undefined);
    private _authConfig;
    get authConfig(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsAuthConfigOutputReference;
    private _backfillSource;
    get backfillSource(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsBackfillSourceOutputReference;
    get bootstrapServers(): string;
    private _extraOptions;
    get extraOptions(): cdktn.StringMap;
    private _ingestionConfig;
    get ingestionConfig(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsIngestionConfigOutputReference;
    private _keySchema;
    get keySchema(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsKeySchemaOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsProviderConfig | undefined;
    private _subscriptionMode;
    get subscriptionMode(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsSubscriptionModeOutputReference;
    private _valueSchema;
    get valueSchema(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsValueSchemaOutputReference;
}
export declare class DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsOutputReference;
}
export interface DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#workspace_id DataDatabricksFeatureEngineeringKafkaConfigs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksFeatureEngineeringKafkaConfigsProviderConfigToTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksFeatureEngineeringKafkaConfigsProviderConfigToHclTerraform(struct?: DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksFeatureEngineeringKafkaConfigsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs databricks_feature_engineering_kafka_configs}
*/
export declare class DataDatabricksFeatureEngineeringKafkaConfigs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_feature_engineering_kafka_configs";
    /**
    * Generates CDKTN code for importing a DataDatabricksFeatureEngineeringKafkaConfigs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksFeatureEngineeringKafkaConfigs to import
    * @param importFromId The id of the existing DataDatabricksFeatureEngineeringKafkaConfigs that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksFeatureEngineeringKafkaConfigs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/feature_engineering_kafka_configs databricks_feature_engineering_kafka_configs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksFeatureEngineeringKafkaConfigsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksFeatureEngineeringKafkaConfigsConfig);
    private _kafkaConfigs;
    get kafkaConfigs(): DataDatabricksFeatureEngineeringKafkaConfigsKafkaConfigsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksFeatureEngineeringKafkaConfigsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksFeatureEngineeringKafkaConfigsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
