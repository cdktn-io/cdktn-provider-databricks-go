/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#name DataDatabricksPostgresRole#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#provider_config DataDatabricksPostgresRole#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresRoleProviderConfig;
}
export interface DataDatabricksPostgresRoleProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#workspace_id DataDatabricksPostgresRole#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresRoleProviderConfigToTerraform(struct?: DataDatabricksPostgresRoleProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresRoleProviderConfigToHclTerraform(struct?: DataDatabricksPostgresRoleProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresRoleProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRoleProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresRoleProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresRoleSpecAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#bypassrls DataDatabricksPostgresRole#bypassrls}
    */
    readonly bypassrls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#createdb DataDatabricksPostgresRole#createdb}
    */
    readonly createdb?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#createrole DataDatabricksPostgresRole#createrole}
    */
    readonly createrole?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresRoleSpecAttributesToTerraform(struct?: DataDatabricksPostgresRoleSpecAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresRoleSpecAttributesToHclTerraform(struct?: DataDatabricksPostgresRoleSpecAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresRoleSpecAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRoleSpecAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresRoleSpecAttributes | cdktn.IResolvable | undefined);
    private _bypassrls?;
    get bypassrls(): boolean | cdktn.IResolvable;
    set bypassrls(value: boolean | cdktn.IResolvable);
    resetBypassrls(): void;
    get bypassrlsInput(): boolean | cdktn.IResolvable | undefined;
    private _createdb?;
    get createdb(): boolean | cdktn.IResolvable;
    set createdb(value: boolean | cdktn.IResolvable);
    resetCreatedb(): void;
    get createdbInput(): boolean | cdktn.IResolvable | undefined;
    private _createrole?;
    get createrole(): boolean | cdktn.IResolvable;
    set createrole(value: boolean | cdktn.IResolvable);
    resetCreaterole(): void;
    get createroleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksPostgresRoleSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#attributes DataDatabricksPostgresRole#attributes}
    */
    readonly attributes?: DataDatabricksPostgresRoleSpecAttributes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#auth_method DataDatabricksPostgresRole#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#identity_type DataDatabricksPostgresRole#identity_type}
    */
    readonly identityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#membership_roles DataDatabricksPostgresRole#membership_roles}
    */
    readonly membershipRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#postgres_role DataDatabricksPostgresRole#postgres_role}
    */
    readonly postgresRole?: string;
}
export declare function dataDatabricksPostgresRoleSpecToTerraform(struct?: DataDatabricksPostgresRoleSpec): any;
export declare function dataDatabricksPostgresRoleSpecToHclTerraform(struct?: DataDatabricksPostgresRoleSpec): any;
export declare class DataDatabricksPostgresRoleSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRoleSpec | undefined;
    set internalValue(value: DataDatabricksPostgresRoleSpec | undefined);
    private _attributes;
    get attributes(): DataDatabricksPostgresRoleSpecAttributesOutputReference;
    putAttributes(value: DataDatabricksPostgresRoleSpecAttributes): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | DataDatabricksPostgresRoleSpecAttributes | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _membershipRoles?;
    get membershipRoles(): string[];
    set membershipRoles(value: string[]);
    resetMembershipRoles(): void;
    get membershipRolesInput(): string[] | undefined;
    private _postgresRole?;
    get postgresRole(): string;
    set postgresRole(value: string);
    resetPostgresRole(): void;
    get postgresRoleInput(): string | undefined;
}
export interface DataDatabricksPostgresRoleStatusAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#bypassrls DataDatabricksPostgresRole#bypassrls}
    */
    readonly bypassrls?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#createdb DataDatabricksPostgresRole#createdb}
    */
    readonly createdb?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#createrole DataDatabricksPostgresRole#createrole}
    */
    readonly createrole?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresRoleStatusAttributesToTerraform(struct?: DataDatabricksPostgresRoleStatusAttributes | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresRoleStatusAttributesToHclTerraform(struct?: DataDatabricksPostgresRoleStatusAttributes | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresRoleStatusAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRoleStatusAttributes | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresRoleStatusAttributes | cdktn.IResolvable | undefined);
    private _bypassrls?;
    get bypassrls(): boolean | cdktn.IResolvable;
    set bypassrls(value: boolean | cdktn.IResolvable);
    resetBypassrls(): void;
    get bypassrlsInput(): boolean | cdktn.IResolvable | undefined;
    private _createdb?;
    get createdb(): boolean | cdktn.IResolvable;
    set createdb(value: boolean | cdktn.IResolvable);
    resetCreatedb(): void;
    get createdbInput(): boolean | cdktn.IResolvable | undefined;
    private _createrole?;
    get createrole(): boolean | cdktn.IResolvable;
    set createrole(value: boolean | cdktn.IResolvable);
    resetCreaterole(): void;
    get createroleInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksPostgresRoleStatus {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#attributes DataDatabricksPostgresRole#attributes}
    */
    readonly attributes?: DataDatabricksPostgresRoleStatusAttributes;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#auth_method DataDatabricksPostgresRole#auth_method}
    */
    readonly authMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#identity_type DataDatabricksPostgresRole#identity_type}
    */
    readonly identityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#membership_roles DataDatabricksPostgresRole#membership_roles}
    */
    readonly membershipRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#postgres_role DataDatabricksPostgresRole#postgres_role}
    */
    readonly postgresRole?: string;
}
export declare function dataDatabricksPostgresRoleStatusToTerraform(struct?: DataDatabricksPostgresRoleStatus): any;
export declare function dataDatabricksPostgresRoleStatusToHclTerraform(struct?: DataDatabricksPostgresRoleStatus): any;
export declare class DataDatabricksPostgresRoleStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresRoleStatus | undefined;
    set internalValue(value: DataDatabricksPostgresRoleStatus | undefined);
    private _attributes;
    get attributes(): DataDatabricksPostgresRoleStatusAttributesOutputReference;
    putAttributes(value: DataDatabricksPostgresRoleStatusAttributes): void;
    resetAttributes(): void;
    get attributesInput(): cdktn.IResolvable | DataDatabricksPostgresRoleStatusAttributes | undefined;
    private _authMethod?;
    get authMethod(): string;
    set authMethod(value: string);
    resetAuthMethod(): void;
    get authMethodInput(): string | undefined;
    private _identityType?;
    get identityType(): string;
    set identityType(value: string);
    resetIdentityType(): void;
    get identityTypeInput(): string | undefined;
    private _membershipRoles?;
    get membershipRoles(): string[];
    set membershipRoles(value: string[]);
    resetMembershipRoles(): void;
    get membershipRolesInput(): string[] | undefined;
    private _postgresRole?;
    get postgresRole(): string;
    set postgresRole(value: string);
    resetPostgresRole(): void;
    get postgresRoleInput(): string | undefined;
    get roleId(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role databricks_postgres_role}
*/
export declare class DataDatabricksPostgresRole extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_role";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresRole to import
    * @param importFromId The id of the existing DataDatabricksPostgresRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_role databricks_postgres_role} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresRoleConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresRoleConfig);
    get createTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parent(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresRoleProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresRoleProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresRoleProviderConfig | undefined;
    get roleId(): string;
    private _spec;
    get spec(): DataDatabricksPostgresRoleSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresRoleStatusOutputReference;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
