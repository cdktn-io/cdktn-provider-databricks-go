/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiGatewayModelProviderServicesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#page_size DataDatabricksAiGatewayModelProviderServices#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#parent DataDatabricksAiGatewayModelProviderServices#parent}
    */
    readonly parent?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#provider_config DataDatabricksAiGatewayModelProviderServices#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayModelProviderServicesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#view DataDatabricksAiGatewayModelProviderServices#view}
    */
    readonly view?: string;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#access_key_id DataDatabricksAiGatewayModelProviderServices#access_key_id}
    */
    readonly accessKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#secret_access_key DataDatabricksAiGatewayModelProviderServices#secret_access_key}
    */
    readonly secretAccessKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey | cdktn.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    resetAccessKeyId(): void;
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey;
    get secretAccessKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKeyOutputReference;
    putSecretAccessKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey): void;
    resetSecretAccessKey(): void;
    get secretAccessKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeySecretAccessKey | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#name DataDatabricksAiGatewayModelProviderServices#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredentialToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredentialToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#aws_access_key DataDatabricksAiGatewayModelProviderServices#aws_access_key}
    */
    readonly awsAccessKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#region DataDatabricksAiGatewayModelProviderServices#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#service_credential DataDatabricksAiGatewayModelProviderServices#service_credential}
    */
    readonly serviceCredential?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect | cdktn.IResolvable | undefined);
    private _awsAccessKey;
    get awsAccessKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKeyOutputReference;
    putAwsAccessKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey): void;
    resetAwsAccessKey(): void;
    get awsAccessKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectAwsAccessKey | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceCredential;
    get serviceCredential(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredentialOutputReference;
    putServiceCredential(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectServiceCredential | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#direct DataDatabricksAiGatewayModelProviderServices#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#api_key DataDatabricksAiGatewayModelProviderServices#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectApiKey | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed {
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayedToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayedToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed | cdktn.IResolvable | undefined);
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#direct DataDatabricksAiGatewayModelProviderServices#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#relayed DataDatabricksAiGatewayModelProviderServices#relayed}
    */
    readonly relayed?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicDirect | undefined;
    private _relayed;
    get relayed(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayedOutputReference;
    putRelayed(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed): void;
    resetRelayed(): void;
    get relayedInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicRelayed | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecretToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecretToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#client_id DataDatabricksAiGatewayModelProviderServices#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#client_secret DataDatabricksAiGatewayModelProviderServices#client_secret}
    */
    readonly clientSecret?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#tenant_id DataDatabricksAiGatewayModelProviderServices#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret;
    get clientSecret(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecretOutputReference;
    putClientSecret(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret): void;
    resetClientSecret(): void;
    get clientSecretInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalClientSecret | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#name DataDatabricksAiGatewayModelProviderServices#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredentialToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredentialToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#api_key DataDatabricksAiGatewayModelProviderServices#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#base_url DataDatabricksAiGatewayModelProviderServices#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#entra_service_principal DataDatabricksAiGatewayModelProviderServices#entra_service_principal}
    */
    readonly entraServicePrincipal?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#service_credential DataDatabricksAiGatewayModelProviderServices#service_credential}
    */
    readonly serviceCredential?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _entraServicePrincipal;
    get entraServicePrincipal(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipalOutputReference;
    putEntraServicePrincipal(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal): void;
    resetEntraServicePrincipal(): void;
    get entraServicePrincipalInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectEntraServicePrincipal | undefined;
    private _serviceCredential;
    get serviceCredential(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredentialOutputReference;
    putServiceCredential(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectServiceCredential | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#direct DataDatabricksAiGatewayModelProviderServices#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#api_key DataDatabricksAiGatewayModelProviderServices#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#base_url DataDatabricksAiGatewayModelProviderServices#base_url}
    */
    readonly baseUrl?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#direct DataDatabricksAiGatewayModelProviderServices#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#api_key DataDatabricksAiGatewayModelProviderServices#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#project_id DataDatabricksAiGatewayModelProviderServices#project_id}
    */
    readonly projectId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#region DataDatabricksAiGatewayModelProviderServices#region}
    */
    readonly region?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectApiKey | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#direct DataDatabricksAiGatewayModelProviderServices#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#parent DataDatabricksAiGatewayModelProviderServices#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#table_name_prefix DataDatabricksAiGatewayModelProviderServices#table_name_prefix}
    */
    readonly tableNamePrefix?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTableToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTableToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable | cdktn.IResolvable | undefined);
    get isDeleted(): cdktn.IResolvable;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get table(): string;
    private _tableNamePrefix?;
    get tableNamePrefix(): string;
    set tableNamePrefix(value: string);
    resetTableNamePrefix(): void;
    get tableNamePrefixInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#client_id DataDatabricksAiGatewayModelProviderServices#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#client_secret DataDatabricksAiGatewayModelProviderServices#client_secret}
    */
    readonly clientSecret?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#tenant_id DataDatabricksAiGatewayModelProviderServices#tenant_id}
    */
    readonly tenantId?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal | cdktn.IResolvable | undefined);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret;
    get clientSecret(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecretOutputReference;
    putClientSecret(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret): void;
    resetClientSecret(): void;
    get clientSecretInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalClientSecret | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#name DataDatabricksAiGatewayModelProviderServices#name}
    */
    readonly name: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredentialToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredentialToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#api_key DataDatabricksAiGatewayModelProviderServices#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#base_url DataDatabricksAiGatewayModelProviderServices#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#entra_service_principal DataDatabricksAiGatewayModelProviderServices#entra_service_principal}
    */
    readonly entraServicePrincipal?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#service_credential DataDatabricksAiGatewayModelProviderServices#service_credential}
    */
    readonly serviceCredential?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _entraServicePrincipal;
    get entraServicePrincipal(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipalOutputReference;
    putEntraServicePrincipal(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal): void;
    resetEntraServicePrincipal(): void;
    get entraServicePrincipalInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectEntraServicePrincipal | undefined;
    private _serviceCredential;
    get serviceCredential(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredentialOutputReference;
    putServiceCredential(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential): void;
    resetServiceCredential(): void;
    get serviceCredentialInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectServiceCredential | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#direct DataDatabricksAiGatewayModelProviderServices#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#plaintext DataDatabricksAiGatewayModelProviderServices#plaintext}
    */
    readonly plaintext?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKeyToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKeyToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey | cdktn.IResolvable | undefined);
    private _plaintext?;
    get plaintext(): string;
    set plaintext(value: string);
    resetPlaintext(): void;
    get plaintextInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#api_key DataDatabricksAiGatewayModelProviderServices#api_key}
    */
    readonly apiKey?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#base_url DataDatabricksAiGatewayModelProviderServices#base_url}
    */
    readonly baseUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#organization DataDatabricksAiGatewayModelProviderServices#organization}
    */
    readonly organization?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect | cdktn.IResolvable | undefined);
    private _apiKey;
    get apiKey(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKeyOutputReference;
    putApiKey(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey): void;
    resetApiKey(): void;
    get apiKeyInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectApiKey | undefined;
    private _baseUrl?;
    get baseUrl(): string;
    set baseUrl(value: string);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#direct DataDatabricksAiGatewayModelProviderServices#direct}
    */
    readonly direct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai | cdktn.IResolvable | undefined);
    private _direct;
    get direct(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirectOutputReference;
    putDirect(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect): void;
    resetDirect(): void;
    get directInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiDirect | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#key DataDatabricksAiGatewayModelProviderServices#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#principal DataDatabricksAiGatewayModelProviderServices#principal}
    */
    readonly principal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#renewal_period DataDatabricksAiGatewayModelProviderServices#renewal_period}
    */
    readonly renewalPeriod: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#requests DataDatabricksAiGatewayModelProviderServices#requests}
    */
    readonly requests?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#tokens DataDatabricksAiGatewayModelProviderServices#tokens}
    */
    readonly tokens?: number;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimitsToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimitsToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    resetPrincipal(): void;
    get principalInput(): string | undefined;
    private _renewalPeriod?;
    get renewalPeriod(): string;
    set renewalPeriod(value: string);
    get renewalPeriodInput(): string | undefined;
    private _requests?;
    get requests(): number;
    set requests(value: number);
    resetRequests(): void;
    get requestsInput(): number | undefined;
    private _tokens?;
    get tokens(): number;
    set tokens(value: number);
    resetTokens(): void;
    get tokensInput(): number | undefined;
}
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimitsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimitsOutputReference;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#model DataDatabricksAiGatewayModelProviderServices#model}
    */
    readonly model: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#native_api_types DataDatabricksAiGatewayModelProviderServices#native_api_types}
    */
    readonly nativeApiTypes?: string[];
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargetsToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargetsToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets | cdktn.IResolvable | undefined);
    private _model?;
    get model(): string;
    set model(value: string);
    get modelInput(): string | undefined;
    private _nativeApiTypes?;
    get nativeApiTypes(): string[];
    set nativeApiTypes(value: string[]);
    resetNativeApiTypes(): void;
    get nativeApiTypesInput(): string[] | undefined;
}
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargetsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargetsOutputReference;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#allow_all_targets DataDatabricksAiGatewayModelProviderServices#allow_all_targets}
    */
    readonly allowAllTargets?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#amazon_bedrock DataDatabricksAiGatewayModelProviderServices#amazon_bedrock}
    */
    readonly amazonBedrock?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#anthropic DataDatabricksAiGatewayModelProviderServices#anthropic}
    */
    readonly anthropic?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#azure_openai DataDatabricksAiGatewayModelProviderServices#azure_openai}
    */
    readonly azureOpenai?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#custom DataDatabricksAiGatewayModelProviderServices#custom}
    */
    readonly custom?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#forward_headers DataDatabricksAiGatewayModelProviderServices#forward_headers}
    */
    readonly forwardHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#forward_query_parameters DataDatabricksAiGatewayModelProviderServices#forward_query_parameters}
    */
    readonly forwardQueryParameters?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#forward_unmanaged_paths DataDatabricksAiGatewayModelProviderServices#forward_unmanaged_paths}
    */
    readonly forwardUnmanagedPaths?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#gemini_enterprise DataDatabricksAiGatewayModelProviderServices#gemini_enterprise}
    */
    readonly geminiEnterprise?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#inference_table DataDatabricksAiGatewayModelProviderServices#inference_table}
    */
    readonly inferenceTable?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#microsoft_foundry DataDatabricksAiGatewayModelProviderServices#microsoft_foundry}
    */
    readonly microsoftFoundry?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#openai DataDatabricksAiGatewayModelProviderServices#openai}
    */
    readonly openai?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#provider_type DataDatabricksAiGatewayModelProviderServices#provider_type}
    */
    readonly providerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#rate_limits DataDatabricksAiGatewayModelProviderServices#rate_limits}
    */
    readonly rateLimits?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#targets DataDatabricksAiGatewayModelProviderServices#targets}
    */
    readonly targets?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets[] | cdktn.IResolvable;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfig): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfig): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfig | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfig | undefined);
    private _allowAllTargets?;
    get allowAllTargets(): boolean | cdktn.IResolvable;
    set allowAllTargets(value: boolean | cdktn.IResolvable);
    resetAllowAllTargets(): void;
    get allowAllTargetsInput(): boolean | cdktn.IResolvable | undefined;
    private _amazonBedrock;
    get amazonBedrock(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrockOutputReference;
    putAmazonBedrock(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock): void;
    resetAmazonBedrock(): void;
    get amazonBedrockInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAmazonBedrock | undefined;
    private _anthropic;
    get anthropic(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropicOutputReference;
    putAnthropic(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic): void;
    resetAnthropic(): void;
    get anthropicInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAnthropic | undefined;
    private _azureOpenai;
    get azureOpenai(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenaiOutputReference;
    putAzureOpenai(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai): void;
    resetAzureOpenai(): void;
    get azureOpenaiInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigAzureOpenai | undefined;
    private _custom;
    get custom(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustomOutputReference;
    putCustom(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom): void;
    resetCustom(): void;
    get customInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigCustom | undefined;
    private _forwardHeaders?;
    get forwardHeaders(): boolean | cdktn.IResolvable;
    set forwardHeaders(value: boolean | cdktn.IResolvable);
    resetForwardHeaders(): void;
    get forwardHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardQueryParameters?;
    get forwardQueryParameters(): boolean | cdktn.IResolvable;
    set forwardQueryParameters(value: boolean | cdktn.IResolvable);
    resetForwardQueryParameters(): void;
    get forwardQueryParametersInput(): boolean | cdktn.IResolvable | undefined;
    private _forwardUnmanagedPaths?;
    get forwardUnmanagedPaths(): boolean | cdktn.IResolvable;
    set forwardUnmanagedPaths(value: boolean | cdktn.IResolvable);
    resetForwardUnmanagedPaths(): void;
    get forwardUnmanagedPathsInput(): boolean | cdktn.IResolvable | undefined;
    private _geminiEnterprise;
    get geminiEnterprise(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterpriseOutputReference;
    putGeminiEnterprise(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise): void;
    resetGeminiEnterprise(): void;
    get geminiEnterpriseInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigGeminiEnterprise | undefined;
    private _inferenceTable;
    get inferenceTable(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTableOutputReference;
    putInferenceTable(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable): void;
    resetInferenceTable(): void;
    get inferenceTableInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigInferenceTable | undefined;
    private _microsoftFoundry;
    get microsoftFoundry(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundryOutputReference;
    putMicrosoftFoundry(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry): void;
    resetMicrosoftFoundry(): void;
    get microsoftFoundryInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigMicrosoftFoundry | undefined;
    private _openai;
    get openai(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenaiOutputReference;
    putOpenai(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai): void;
    resetOpenai(): void;
    get openaiInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOpenai | undefined;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    resetProviderType(): void;
    get providerTypeInput(): string | undefined;
    private _rateLimits;
    get rateLimits(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimitsList;
    putRateLimits(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits[] | cdktn.IResolvable): void;
    resetRateLimits(): void;
    get rateLimitsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigRateLimits[] | undefined;
    private _targets;
    get targets(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargetsList;
    putTargets(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets[] | cdktn.IResolvable): void;
    resetTargets(): void;
    get targetsInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigTargets[] | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#workspace_id DataDatabricksAiGatewayModelProviderServices#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfigToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAiGatewayModelProviderServicesModelProviderServices {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#name DataDatabricksAiGatewayModelProviderServices#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#provider_config DataDatabricksAiGatewayModelProviderServices#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig;
}
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServices): any;
export declare function dataDatabricksAiGatewayModelProviderServicesModelProviderServicesToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesModelProviderServices): any;
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesModelProviderServices | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServices | undefined);
    get comment(): string;
    private _config;
    get config(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesConfigOutputReference;
    get createTime(): string;
    get createdBy(): string;
    get effectiveOwner(): string;
    get etag(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesModelProviderServicesProviderConfig | undefined;
    get updateTime(): string;
    get updatedBy(): string;
}
export declare class DataDatabricksAiGatewayModelProviderServicesModelProviderServicesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiGatewayModelProviderServicesModelProviderServices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesOutputReference;
}
export interface DataDatabricksAiGatewayModelProviderServicesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#workspace_id DataDatabricksAiGatewayModelProviderServices#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiGatewayModelProviderServicesProviderConfigToTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiGatewayModelProviderServicesProviderConfigToHclTerraform(struct?: DataDatabricksAiGatewayModelProviderServicesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiGatewayModelProviderServicesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiGatewayModelProviderServicesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiGatewayModelProviderServicesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services databricks_ai_gateway_model_provider_services}
*/
export declare class DataDatabricksAiGatewayModelProviderServices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_gateway_model_provider_services";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiGatewayModelProviderServices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiGatewayModelProviderServices to import
    * @param importFromId The id of the existing DataDatabricksAiGatewayModelProviderServices that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiGatewayModelProviderServices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_gateway_model_provider_services databricks_ai_gateway_model_provider_services} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiGatewayModelProviderServicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksAiGatewayModelProviderServicesConfig);
    private _modelProviderServices;
    get modelProviderServices(): DataDatabricksAiGatewayModelProviderServicesModelProviderServicesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiGatewayModelProviderServicesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiGatewayModelProviderServicesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiGatewayModelProviderServicesProviderConfig | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
