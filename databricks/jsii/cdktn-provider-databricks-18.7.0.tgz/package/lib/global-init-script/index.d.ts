/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GlobalInitScriptConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#content_base64 GlobalInitScript#content_base64}
    */
    readonly contentBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#enabled GlobalInitScript#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#id GlobalInitScript#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#md5 GlobalInitScript#md5}
    */
    readonly md5?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#name GlobalInitScript#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#position GlobalInitScript#position}
    */
    readonly position?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#source GlobalInitScript#source}
    */
    readonly source?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#provider_config GlobalInitScript#provider_config}
    */
    readonly providerConfig?: GlobalInitScriptProviderConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#timeouts GlobalInitScript#timeouts}
    */
    readonly timeouts?: GlobalInitScriptTimeouts;
}
export interface GlobalInitScriptProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#workspace_id GlobalInitScript#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function globalInitScriptProviderConfigToTerraform(struct?: GlobalInitScriptProviderConfigOutputReference | GlobalInitScriptProviderConfig): any;
export declare function globalInitScriptProviderConfigToHclTerraform(struct?: GlobalInitScriptProviderConfigOutputReference | GlobalInitScriptProviderConfig): any;
export declare class GlobalInitScriptProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GlobalInitScriptProviderConfig | undefined;
    set internalValue(value: GlobalInitScriptProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface GlobalInitScriptTimeouts {
}
export declare function globalInitScriptTimeoutsToTerraform(struct?: GlobalInitScriptTimeouts | cdktn.IResolvable): any;
export declare function globalInitScriptTimeoutsToHclTerraform(struct?: GlobalInitScriptTimeouts | cdktn.IResolvable): any;
export declare class GlobalInitScriptTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GlobalInitScriptTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: GlobalInitScriptTimeouts | cdktn.IResolvable | undefined);
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script databricks_global_init_script}
*/
export declare class GlobalInitScript extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_global_init_script";
    /**
    * Generates CDKTN code for importing a GlobalInitScript resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GlobalInitScript to import
    * @param importFromId The id of the existing GlobalInitScript that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GlobalInitScript to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/global_init_script databricks_global_init_script} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GlobalInitScriptConfig
    */
    constructor(scope: Construct, id: string, config: GlobalInitScriptConfig);
    private _contentBase64?;
    get contentBase64(): string;
    set contentBase64(value: string);
    resetContentBase64(): void;
    get contentBase64Input(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _md5?;
    get md5(): string;
    set md5(value: string);
    resetMd5(): void;
    get md5Input(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): GlobalInitScriptProviderConfigOutputReference;
    putProviderConfig(value: GlobalInitScriptProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): GlobalInitScriptProviderConfig | undefined;
    private _timeouts;
    get timeouts(): GlobalInitScriptTimeoutsOutputReference;
    putTimeouts(value: GlobalInitScriptTimeouts): void;
    get timeoutsInput(): cdktn.IResolvable | GlobalInitScriptTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
