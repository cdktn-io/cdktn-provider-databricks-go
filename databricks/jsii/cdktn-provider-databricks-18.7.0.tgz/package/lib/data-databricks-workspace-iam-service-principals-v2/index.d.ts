/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamServicePrincipalsV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#filter DataDatabricksWorkspaceIamServicePrincipalsV2#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#page_size DataDatabricksWorkspaceIamServicePrincipalsV2#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#provider_config DataDatabricksWorkspaceIamServicePrincipalsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#workspace_id DataDatabricksWorkspaceIamServicePrincipalsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#workspace_id DataDatabricksWorkspaceIamServicePrincipalsV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipals {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#provider_config DataDatabricksWorkspaceIamServicePrincipalsV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#service_principal_id DataDatabricksWorkspaceIamServicePrincipalsV2#service_principal_id}
    */
    readonly servicePrincipalId: string;
}
export declare function dataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsToTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipals): any;
export declare function dataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsToHclTerraform(struct?: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipals): any;
export declare class DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipals | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipals | undefined);
    get accountId(): string;
    get accountSpStatus(): string;
    get applicationId(): string;
    get displayName(): string;
    get externalId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsProviderConfig | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
}
export declare class DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipals[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2 databricks_workspace_iam_service_principals_v2}
*/
export declare class DataDatabricksWorkspaceIamServicePrincipalsV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_service_principals_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamServicePrincipalsV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamServicePrincipalsV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamServicePrincipalsV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamServicePrincipalsV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_service_principals_v2 databricks_workspace_iam_service_principals_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamServicePrincipalsV2Config = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksWorkspaceIamServicePrincipalsV2Config);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamServicePrincipalsV2ProviderConfig | undefined;
    private _servicePrincipals;
    get servicePrincipals(): DataDatabricksWorkspaceIamServicePrincipalsV2ServicePrincipalsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
