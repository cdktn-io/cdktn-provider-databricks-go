/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
export interface PipelineRestartWindow {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#days_of_week Pipeline#days_of_week}
    */
    readonly daysOfWeek?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#start_hour Pipeline#start_hour}
    */
    readonly startHour: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#time_zone_id Pipeline#time_zone_id}
    */
    readonly timeZoneId?: string;
}
export declare function pipelineRestartWindowToTerraform(struct?: PipelineRestartWindowOutputReference | PipelineRestartWindow): any;
export declare function pipelineRestartWindowToHclTerraform(struct?: PipelineRestartWindowOutputReference | PipelineRestartWindow): any;
export declare class PipelineRestartWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineRestartWindow | undefined;
    set internalValue(value: PipelineRestartWindow | undefined);
    private _daysOfWeek?;
    get daysOfWeek(): string[];
    set daysOfWeek(value: string[]);
    resetDaysOfWeek(): void;
    get daysOfWeekInput(): string[] | undefined;
    private _startHour?;
    get startHour(): number;
    set startHour(value: number);
    get startHourInput(): number | undefined;
    private _timeZoneId?;
    get timeZoneId(): string;
    set timeZoneId(value: string);
    resetTimeZoneId(): void;
    get timeZoneIdInput(): string | undefined;
}
export interface PipelineRunAs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#service_principal_name Pipeline#service_principal_name}
    */
    readonly servicePrincipalName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#user_name Pipeline#user_name}
    */
    readonly userName?: string;
}
export declare function pipelineRunAsToTerraform(struct?: PipelineRunAsOutputReference | PipelineRunAs): any;
export declare function pipelineRunAsToHclTerraform(struct?: PipelineRunAsOutputReference | PipelineRunAs): any;
export declare class PipelineRunAsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineRunAs | undefined;
    set internalValue(value: PipelineRunAs | undefined);
    private _servicePrincipalName?;
    get servicePrincipalName(): string;
    set servicePrincipalName(value: string);
    resetServicePrincipalName(): void;
    get servicePrincipalNameInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export interface PipelineTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#default Pipeline#default}
    */
    readonly default?: string;
}
export declare function pipelineTimeoutsToTerraform(struct?: PipelineTimeouts | cdktn.IResolvable): any;
export declare function pipelineTimeoutsToHclTerraform(struct?: PipelineTimeouts | cdktn.IResolvable): any;
export declare class PipelineTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PipelineTimeouts | cdktn.IResolvable | undefined);
    private _default?;
    get default(): string;
    set default(value: string);
    resetDefault(): void;
    get defaultInput(): string | undefined;
}
export interface PipelineTriggerCron {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#quartz_cron_schedule Pipeline#quartz_cron_schedule}
    */
    readonly quartzCronSchedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#timezone_id Pipeline#timezone_id}
    */
    readonly timezoneId?: string;
}
export declare function pipelineTriggerCronToTerraform(struct?: PipelineTriggerCronOutputReference | PipelineTriggerCron): any;
export declare function pipelineTriggerCronToHclTerraform(struct?: PipelineTriggerCronOutputReference | PipelineTriggerCron): any;
export declare class PipelineTriggerCronOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTriggerCron | undefined;
    set internalValue(value: PipelineTriggerCron | undefined);
    private _quartzCronSchedule?;
    get quartzCronSchedule(): string;
    set quartzCronSchedule(value: string);
    resetQuartzCronSchedule(): void;
    get quartzCronScheduleInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    resetTimezoneId(): void;
    get timezoneIdInput(): string | undefined;
}
export interface PipelineTriggerManual {
}
export declare function pipelineTriggerManualToTerraform(struct?: PipelineTriggerManualOutputReference | PipelineTriggerManual): any;
export declare function pipelineTriggerManualToHclTerraform(struct?: PipelineTriggerManualOutputReference | PipelineTriggerManual): any;
export declare class PipelineTriggerManualOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTriggerManual | undefined;
    set internalValue(value: PipelineTriggerManual | undefined);
}
export interface PipelineTrigger {
    /**
    * cron block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#cron Pipeline#cron}
    */
    readonly cron?: PipelineTriggerCron;
    /**
    * manual block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/pipeline#manual Pipeline#manual}
    */
    readonly manual?: PipelineTriggerManual;
}
export declare function pipelineTriggerToTerraform(struct?: PipelineTriggerOutputReference | PipelineTrigger): any;
export declare function pipelineTriggerToHclTerraform(struct?: PipelineTriggerOutputReference | PipelineTrigger): any;
export declare class PipelineTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PipelineTrigger | undefined;
    set internalValue(value: PipelineTrigger | undefined);
    private _cron;
    get cron(): PipelineTriggerCronOutputReference;
    putCron(value: PipelineTriggerCron): void;
    resetCron(): void;
    get cronInput(): PipelineTriggerCron | undefined;
    private _manual;
    get manual(): PipelineTriggerManualOutputReference;
    putManual(value: PipelineTriggerManual): void;
    resetManual(): void;
    get manualInput(): PipelineTriggerManual | undefined;
}
