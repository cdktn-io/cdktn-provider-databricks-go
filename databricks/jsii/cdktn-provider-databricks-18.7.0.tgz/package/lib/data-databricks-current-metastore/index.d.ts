/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksCurrentMetastoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#id DataDatabricksCurrentMetastore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * metastore_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#metastore_info DataDatabricksCurrentMetastore#metastore_info}
    */
    readonly metastoreInfo?: DataDatabricksCurrentMetastoreMetastoreInfo;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#provider_config DataDatabricksCurrentMetastore#provider_config}
    */
    readonly providerConfig?: DataDatabricksCurrentMetastoreProviderConfig;
}
export interface DataDatabricksCurrentMetastoreMetastoreInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#cloud DataDatabricksCurrentMetastore#cloud}
    */
    readonly cloud?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#created_at DataDatabricksCurrentMetastore#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#created_by DataDatabricksCurrentMetastore#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#default_data_access_config_id DataDatabricksCurrentMetastore#default_data_access_config_id}
    */
    readonly defaultDataAccessConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#delta_sharing_organization_name DataDatabricksCurrentMetastore#delta_sharing_organization_name}
    */
    readonly deltaSharingOrganizationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#delta_sharing_recipient_token_lifetime_in_seconds DataDatabricksCurrentMetastore#delta_sharing_recipient_token_lifetime_in_seconds}
    */
    readonly deltaSharingRecipientTokenLifetimeInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#delta_sharing_scope DataDatabricksCurrentMetastore#delta_sharing_scope}
    */
    readonly deltaSharingScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#external_access_enabled DataDatabricksCurrentMetastore#external_access_enabled}
    */
    readonly externalAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#global_metastore_id DataDatabricksCurrentMetastore#global_metastore_id}
    */
    readonly globalMetastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#metastore_id DataDatabricksCurrentMetastore#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#name DataDatabricksCurrentMetastore#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#owner DataDatabricksCurrentMetastore#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#privilege_model_version DataDatabricksCurrentMetastore#privilege_model_version}
    */
    readonly privilegeModelVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#region DataDatabricksCurrentMetastore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#storage_root DataDatabricksCurrentMetastore#storage_root}
    */
    readonly storageRoot?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#storage_root_credential_id DataDatabricksCurrentMetastore#storage_root_credential_id}
    */
    readonly storageRootCredentialId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#storage_root_credential_name DataDatabricksCurrentMetastore#storage_root_credential_name}
    */
    readonly storageRootCredentialName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#updated_at DataDatabricksCurrentMetastore#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#updated_by DataDatabricksCurrentMetastore#updated_by}
    */
    readonly updatedBy?: string;
}
export declare function dataDatabricksCurrentMetastoreMetastoreInfoToTerraform(struct?: DataDatabricksCurrentMetastoreMetastoreInfoOutputReference | DataDatabricksCurrentMetastoreMetastoreInfo): any;
export declare function dataDatabricksCurrentMetastoreMetastoreInfoToHclTerraform(struct?: DataDatabricksCurrentMetastoreMetastoreInfoOutputReference | DataDatabricksCurrentMetastoreMetastoreInfo): any;
export declare class DataDatabricksCurrentMetastoreMetastoreInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCurrentMetastoreMetastoreInfo | undefined;
    set internalValue(value: DataDatabricksCurrentMetastoreMetastoreInfo | undefined);
    private _cloud?;
    get cloud(): string;
    set cloud(value: string);
    resetCloud(): void;
    get cloudInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _defaultDataAccessConfigId?;
    get defaultDataAccessConfigId(): string;
    set defaultDataAccessConfigId(value: string);
    resetDefaultDataAccessConfigId(): void;
    get defaultDataAccessConfigIdInput(): string | undefined;
    private _deltaSharingOrganizationName?;
    get deltaSharingOrganizationName(): string;
    set deltaSharingOrganizationName(value: string);
    resetDeltaSharingOrganizationName(): void;
    get deltaSharingOrganizationNameInput(): string | undefined;
    private _deltaSharingRecipientTokenLifetimeInSeconds?;
    get deltaSharingRecipientTokenLifetimeInSeconds(): number;
    set deltaSharingRecipientTokenLifetimeInSeconds(value: number);
    resetDeltaSharingRecipientTokenLifetimeInSeconds(): void;
    get deltaSharingRecipientTokenLifetimeInSecondsInput(): number | undefined;
    private _deltaSharingScope?;
    get deltaSharingScope(): string;
    set deltaSharingScope(value: string);
    resetDeltaSharingScope(): void;
    get deltaSharingScopeInput(): string | undefined;
    private _externalAccessEnabled?;
    get externalAccessEnabled(): boolean | cdktn.IResolvable;
    set externalAccessEnabled(value: boolean | cdktn.IResolvable);
    resetExternalAccessEnabled(): void;
    get externalAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _globalMetastoreId?;
    get globalMetastoreId(): string;
    set globalMetastoreId(value: string);
    resetGlobalMetastoreId(): void;
    get globalMetastoreIdInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _privilegeModelVersion?;
    get privilegeModelVersion(): string;
    set privilegeModelVersion(value: string);
    resetPrivilegeModelVersion(): void;
    get privilegeModelVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageRoot?;
    get storageRoot(): string;
    set storageRoot(value: string);
    resetStorageRoot(): void;
    get storageRootInput(): string | undefined;
    private _storageRootCredentialId?;
    get storageRootCredentialId(): string;
    set storageRootCredentialId(value: string);
    resetStorageRootCredentialId(): void;
    get storageRootCredentialIdInput(): string | undefined;
    private _storageRootCredentialName?;
    get storageRootCredentialName(): string;
    set storageRootCredentialName(value: string);
    resetStorageRootCredentialName(): void;
    get storageRootCredentialNameInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
}
export interface DataDatabricksCurrentMetastoreProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#workspace_id DataDatabricksCurrentMetastore#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksCurrentMetastoreProviderConfigToTerraform(struct?: DataDatabricksCurrentMetastoreProviderConfigOutputReference | DataDatabricksCurrentMetastoreProviderConfig): any;
export declare function dataDatabricksCurrentMetastoreProviderConfigToHclTerraform(struct?: DataDatabricksCurrentMetastoreProviderConfigOutputReference | DataDatabricksCurrentMetastoreProviderConfig): any;
export declare class DataDatabricksCurrentMetastoreProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksCurrentMetastoreProviderConfig | undefined;
    set internalValue(value: DataDatabricksCurrentMetastoreProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore databricks_current_metastore}
*/
export declare class DataDatabricksCurrentMetastore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_current_metastore";
    /**
    * Generates CDKTN code for importing a DataDatabricksCurrentMetastore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksCurrentMetastore to import
    * @param importFromId The id of the existing DataDatabricksCurrentMetastore that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksCurrentMetastore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/current_metastore databricks_current_metastore} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksCurrentMetastoreConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksCurrentMetastoreConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metastoreInfo;
    get metastoreInfo(): DataDatabricksCurrentMetastoreMetastoreInfoOutputReference;
    putMetastoreInfo(value: DataDatabricksCurrentMetastoreMetastoreInfo): void;
    resetMetastoreInfo(): void;
    get metastoreInfoInput(): DataDatabricksCurrentMetastoreMetastoreInfo | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksCurrentMetastoreProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksCurrentMetastoreProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksCurrentMetastoreProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
