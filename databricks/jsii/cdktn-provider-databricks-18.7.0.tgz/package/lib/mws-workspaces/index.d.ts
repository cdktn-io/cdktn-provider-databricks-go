/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface MwsWorkspacesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#account_id MwsWorkspaces#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#aws_region MwsWorkspaces#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#cloud MwsWorkspaces#cloud}
    */
    readonly cloud?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#compute_mode MwsWorkspaces#compute_mode}
    */
    readonly computeMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#creation_time MwsWorkspaces#creation_time}
    */
    readonly creationTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#credentials_id MwsWorkspaces#credentials_id}
    */
    readonly credentialsId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#custom_tags MwsWorkspaces#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#customer_managed_key_id MwsWorkspaces#customer_managed_key_id}
    */
    readonly customerManagedKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#deployment_name MwsWorkspaces#deployment_name}
    */
    readonly deploymentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#expected_workspace_status MwsWorkspaces#expected_workspace_status}
    */
    readonly expectedWorkspaceStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#id MwsWorkspaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#is_no_public_ip_enabled MwsWorkspaces#is_no_public_ip_enabled}
    */
    readonly isNoPublicIpEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#location MwsWorkspaces#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#managed_services_customer_managed_key_id MwsWorkspaces#managed_services_customer_managed_key_id}
    */
    readonly managedServicesCustomerManagedKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#network_connectivity_config_id MwsWorkspaces#network_connectivity_config_id}
    */
    readonly networkConnectivityConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#network_id MwsWorkspaces#network_id}
    */
    readonly networkId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#pricing_tier MwsWorkspaces#pricing_tier}
    */
    readonly pricingTier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#private_access_settings_id MwsWorkspaces#private_access_settings_id}
    */
    readonly privateAccessSettingsId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#storage_configuration_id MwsWorkspaces#storage_configuration_id}
    */
    readonly storageConfigurationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#storage_customer_managed_key_id MwsWorkspaces#storage_customer_managed_key_id}
    */
    readonly storageCustomerManagedKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#workspace_id MwsWorkspaces#workspace_id}
    */
    readonly workspaceId?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#workspace_name MwsWorkspaces#workspace_name}
    */
    readonly workspaceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#workspace_status MwsWorkspaces#workspace_status}
    */
    readonly workspaceStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#workspace_status_message MwsWorkspaces#workspace_status_message}
    */
    readonly workspaceStatusMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#workspace_url MwsWorkspaces#workspace_url}
    */
    readonly workspaceUrl?: string;
    /**
    * cloud_resource_container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#cloud_resource_container MwsWorkspaces#cloud_resource_container}
    */
    readonly cloudResourceContainer?: MwsWorkspacesCloudResourceContainer;
    /**
    * external_customer_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#external_customer_info MwsWorkspaces#external_customer_info}
    */
    readonly externalCustomerInfo?: MwsWorkspacesExternalCustomerInfo;
    /**
    * gcp_managed_network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#gcp_managed_network_config MwsWorkspaces#gcp_managed_network_config}
    */
    readonly gcpManagedNetworkConfig?: MwsWorkspacesGcpManagedNetworkConfig;
    /**
    * gke_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#gke_config MwsWorkspaces#gke_config}
    */
    readonly gkeConfig?: MwsWorkspacesGkeConfig;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#timeouts MwsWorkspaces#timeouts}
    */
    readonly timeouts?: MwsWorkspacesTimeouts;
    /**
    * token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#token MwsWorkspaces#token}
    */
    readonly token?: MwsWorkspacesToken;
}
export interface MwsWorkspacesCloudResourceContainerGcp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#project_id MwsWorkspaces#project_id}
    */
    readonly projectId: string;
}
export declare function mwsWorkspacesCloudResourceContainerGcpToTerraform(struct?: MwsWorkspacesCloudResourceContainerGcpOutputReference | MwsWorkspacesCloudResourceContainerGcp): any;
export declare function mwsWorkspacesCloudResourceContainerGcpToHclTerraform(struct?: MwsWorkspacesCloudResourceContainerGcpOutputReference | MwsWorkspacesCloudResourceContainerGcp): any;
export declare class MwsWorkspacesCloudResourceContainerGcpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsWorkspacesCloudResourceContainerGcp | undefined;
    set internalValue(value: MwsWorkspacesCloudResourceContainerGcp | undefined);
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
}
export interface MwsWorkspacesCloudResourceContainer {
    /**
    * gcp block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#gcp MwsWorkspaces#gcp}
    */
    readonly gcp: MwsWorkspacesCloudResourceContainerGcp;
}
export declare function mwsWorkspacesCloudResourceContainerToTerraform(struct?: MwsWorkspacesCloudResourceContainerOutputReference | MwsWorkspacesCloudResourceContainer): any;
export declare function mwsWorkspacesCloudResourceContainerToHclTerraform(struct?: MwsWorkspacesCloudResourceContainerOutputReference | MwsWorkspacesCloudResourceContainer): any;
export declare class MwsWorkspacesCloudResourceContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsWorkspacesCloudResourceContainer | undefined;
    set internalValue(value: MwsWorkspacesCloudResourceContainer | undefined);
    private _gcp;
    get gcp(): MwsWorkspacesCloudResourceContainerGcpOutputReference;
    putGcp(value: MwsWorkspacesCloudResourceContainerGcp): void;
    get gcpInput(): MwsWorkspacesCloudResourceContainerGcp | undefined;
}
export interface MwsWorkspacesExternalCustomerInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#authoritative_user_email MwsWorkspaces#authoritative_user_email}
    */
    readonly authoritativeUserEmail: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#authoritative_user_full_name MwsWorkspaces#authoritative_user_full_name}
    */
    readonly authoritativeUserFullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#customer_name MwsWorkspaces#customer_name}
    */
    readonly customerName: string;
}
export declare function mwsWorkspacesExternalCustomerInfoToTerraform(struct?: MwsWorkspacesExternalCustomerInfoOutputReference | MwsWorkspacesExternalCustomerInfo): any;
export declare function mwsWorkspacesExternalCustomerInfoToHclTerraform(struct?: MwsWorkspacesExternalCustomerInfoOutputReference | MwsWorkspacesExternalCustomerInfo): any;
export declare class MwsWorkspacesExternalCustomerInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsWorkspacesExternalCustomerInfo | undefined;
    set internalValue(value: MwsWorkspacesExternalCustomerInfo | undefined);
    private _authoritativeUserEmail?;
    get authoritativeUserEmail(): string;
    set authoritativeUserEmail(value: string);
    get authoritativeUserEmailInput(): string | undefined;
    private _authoritativeUserFullName?;
    get authoritativeUserFullName(): string;
    set authoritativeUserFullName(value: string);
    get authoritativeUserFullNameInput(): string | undefined;
    private _customerName?;
    get customerName(): string;
    set customerName(value: string);
    get customerNameInput(): string | undefined;
}
export interface MwsWorkspacesGcpManagedNetworkConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#gke_cluster_pod_ip_range MwsWorkspaces#gke_cluster_pod_ip_range}
    */
    readonly gkeClusterPodIpRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#gke_cluster_service_ip_range MwsWorkspaces#gke_cluster_service_ip_range}
    */
    readonly gkeClusterServiceIpRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#subnet_cidr MwsWorkspaces#subnet_cidr}
    */
    readonly subnetCidr: string;
}
export declare function mwsWorkspacesGcpManagedNetworkConfigToTerraform(struct?: MwsWorkspacesGcpManagedNetworkConfigOutputReference | MwsWorkspacesGcpManagedNetworkConfig): any;
export declare function mwsWorkspacesGcpManagedNetworkConfigToHclTerraform(struct?: MwsWorkspacesGcpManagedNetworkConfigOutputReference | MwsWorkspacesGcpManagedNetworkConfig): any;
export declare class MwsWorkspacesGcpManagedNetworkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsWorkspacesGcpManagedNetworkConfig | undefined;
    set internalValue(value: MwsWorkspacesGcpManagedNetworkConfig | undefined);
    private _gkeClusterPodIpRange?;
    get gkeClusterPodIpRange(): string;
    set gkeClusterPodIpRange(value: string);
    resetGkeClusterPodIpRange(): void;
    get gkeClusterPodIpRangeInput(): string | undefined;
    private _gkeClusterServiceIpRange?;
    get gkeClusterServiceIpRange(): string;
    set gkeClusterServiceIpRange(value: string);
    resetGkeClusterServiceIpRange(): void;
    get gkeClusterServiceIpRangeInput(): string | undefined;
    private _subnetCidr?;
    get subnetCidr(): string;
    set subnetCidr(value: string);
    get subnetCidrInput(): string | undefined;
}
export interface MwsWorkspacesGkeConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#connectivity_type MwsWorkspaces#connectivity_type}
    */
    readonly connectivityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#master_ip_range MwsWorkspaces#master_ip_range}
    */
    readonly masterIpRange?: string;
}
export declare function mwsWorkspacesGkeConfigToTerraform(struct?: MwsWorkspacesGkeConfigOutputReference | MwsWorkspacesGkeConfig): any;
export declare function mwsWorkspacesGkeConfigToHclTerraform(struct?: MwsWorkspacesGkeConfigOutputReference | MwsWorkspacesGkeConfig): any;
export declare class MwsWorkspacesGkeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsWorkspacesGkeConfig | undefined;
    set internalValue(value: MwsWorkspacesGkeConfig | undefined);
    private _connectivityType?;
    get connectivityType(): string;
    set connectivityType(value: string);
    resetConnectivityType(): void;
    get connectivityTypeInput(): string | undefined;
    private _masterIpRange?;
    get masterIpRange(): string;
    set masterIpRange(value: string);
    resetMasterIpRange(): void;
    get masterIpRangeInput(): string | undefined;
}
export interface MwsWorkspacesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#create MwsWorkspaces#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#read MwsWorkspaces#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#update MwsWorkspaces#update}
    */
    readonly update?: string;
}
export declare function mwsWorkspacesTimeoutsToTerraform(struct?: MwsWorkspacesTimeouts | cdktn.IResolvable): any;
export declare function mwsWorkspacesTimeoutsToHclTerraform(struct?: MwsWorkspacesTimeouts | cdktn.IResolvable): any;
export declare class MwsWorkspacesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsWorkspacesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: MwsWorkspacesTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface MwsWorkspacesToken {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#comment MwsWorkspaces#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#lifetime_seconds MwsWorkspaces#lifetime_seconds}
    */
    readonly lifetimeSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#token_id MwsWorkspaces#token_id}
    */
    readonly tokenId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#token_value MwsWorkspaces#token_value}
    */
    readonly tokenValue?: string;
}
export declare function mwsWorkspacesTokenToTerraform(struct?: MwsWorkspacesTokenOutputReference | MwsWorkspacesToken): any;
export declare function mwsWorkspacesTokenToHclTerraform(struct?: MwsWorkspacesTokenOutputReference | MwsWorkspacesToken): any;
export declare class MwsWorkspacesTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MwsWorkspacesToken | undefined;
    set internalValue(value: MwsWorkspacesToken | undefined);
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _lifetimeSeconds?;
    get lifetimeSeconds(): number;
    set lifetimeSeconds(value: number);
    resetLifetimeSeconds(): void;
    get lifetimeSecondsInput(): number | undefined;
    private _tokenId?;
    get tokenId(): string;
    set tokenId(value: string);
    resetTokenId(): void;
    get tokenIdInput(): string | undefined;
    private _tokenValue?;
    get tokenValue(): string;
    set tokenValue(value: string);
    resetTokenValue(): void;
    get tokenValueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces databricks_mws_workspaces}
*/
export declare class MwsWorkspaces extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_mws_workspaces";
    /**
    * Generates CDKTN code for importing a MwsWorkspaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MwsWorkspaces to import
    * @param importFromId The id of the existing MwsWorkspaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MwsWorkspaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/mws_workspaces databricks_mws_workspaces} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MwsWorkspacesConfig
    */
    constructor(scope: Construct, id: string, config: MwsWorkspacesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    private _cloud?;
    get cloud(): string;
    set cloud(value: string);
    resetCloud(): void;
    get cloudInput(): string | undefined;
    private _computeMode?;
    get computeMode(): string;
    set computeMode(value: string);
    resetComputeMode(): void;
    get computeModeInput(): string | undefined;
    private _creationTime?;
    get creationTime(): number;
    set creationTime(value: number);
    resetCreationTime(): void;
    get creationTimeInput(): number | undefined;
    private _credentialsId?;
    get credentialsId(): string;
    set credentialsId(value: string);
    resetCredentialsId(): void;
    get credentialsIdInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _customerManagedKeyId?;
    get customerManagedKeyId(): string;
    set customerManagedKeyId(value: string);
    resetCustomerManagedKeyId(): void;
    get customerManagedKeyIdInput(): string | undefined;
    private _deploymentName?;
    get deploymentName(): string;
    set deploymentName(value: string);
    resetDeploymentName(): void;
    get deploymentNameInput(): string | undefined;
    get effectiveComputeMode(): string;
    private _expectedWorkspaceStatus?;
    get expectedWorkspaceStatus(): string;
    set expectedWorkspaceStatus(value: string);
    resetExpectedWorkspaceStatus(): void;
    get expectedWorkspaceStatusInput(): string | undefined;
    get gcpWorkspaceSa(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isNoPublicIpEnabled?;
    get isNoPublicIpEnabled(): boolean | cdktn.IResolvable;
    set isNoPublicIpEnabled(value: boolean | cdktn.IResolvable);
    resetIsNoPublicIpEnabled(): void;
    get isNoPublicIpEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _managedServicesCustomerManagedKeyId?;
    get managedServicesCustomerManagedKeyId(): string;
    set managedServicesCustomerManagedKeyId(value: string);
    resetManagedServicesCustomerManagedKeyId(): void;
    get managedServicesCustomerManagedKeyIdInput(): string | undefined;
    private _networkConnectivityConfigId?;
    get networkConnectivityConfigId(): string;
    set networkConnectivityConfigId(value: string);
    resetNetworkConnectivityConfigId(): void;
    get networkConnectivityConfigIdInput(): string | undefined;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    resetNetworkId(): void;
    get networkIdInput(): string | undefined;
    private _pricingTier?;
    get pricingTier(): string;
    set pricingTier(value: string);
    resetPricingTier(): void;
    get pricingTierInput(): string | undefined;
    private _privateAccessSettingsId?;
    get privateAccessSettingsId(): string;
    set privateAccessSettingsId(value: string);
    resetPrivateAccessSettingsId(): void;
    get privateAccessSettingsIdInput(): string | undefined;
    private _storageConfigurationId?;
    get storageConfigurationId(): string;
    set storageConfigurationId(value: string);
    resetStorageConfigurationId(): void;
    get storageConfigurationIdInput(): string | undefined;
    private _storageCustomerManagedKeyId?;
    get storageCustomerManagedKeyId(): string;
    set storageCustomerManagedKeyId(value: string);
    resetStorageCustomerManagedKeyId(): void;
    get storageCustomerManagedKeyIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    resetWorkspaceId(): void;
    get workspaceIdInput(): number | undefined;
    private _workspaceName?;
    get workspaceName(): string;
    set workspaceName(value: string);
    get workspaceNameInput(): string | undefined;
    private _workspaceStatus?;
    get workspaceStatus(): string;
    set workspaceStatus(value: string);
    resetWorkspaceStatus(): void;
    get workspaceStatusInput(): string | undefined;
    private _workspaceStatusMessage?;
    get workspaceStatusMessage(): string;
    set workspaceStatusMessage(value: string);
    resetWorkspaceStatusMessage(): void;
    get workspaceStatusMessageInput(): string | undefined;
    private _workspaceUrl?;
    get workspaceUrl(): string;
    set workspaceUrl(value: string);
    resetWorkspaceUrl(): void;
    get workspaceUrlInput(): string | undefined;
    private _cloudResourceContainer;
    get cloudResourceContainer(): MwsWorkspacesCloudResourceContainerOutputReference;
    putCloudResourceContainer(value: MwsWorkspacesCloudResourceContainer): void;
    resetCloudResourceContainer(): void;
    get cloudResourceContainerInput(): MwsWorkspacesCloudResourceContainer | undefined;
    private _externalCustomerInfo;
    get externalCustomerInfo(): MwsWorkspacesExternalCustomerInfoOutputReference;
    putExternalCustomerInfo(value: MwsWorkspacesExternalCustomerInfo): void;
    resetExternalCustomerInfo(): void;
    get externalCustomerInfoInput(): MwsWorkspacesExternalCustomerInfo | undefined;
    private _gcpManagedNetworkConfig;
    get gcpManagedNetworkConfig(): MwsWorkspacesGcpManagedNetworkConfigOutputReference;
    putGcpManagedNetworkConfig(value: MwsWorkspacesGcpManagedNetworkConfig): void;
    resetGcpManagedNetworkConfig(): void;
    get gcpManagedNetworkConfigInput(): MwsWorkspacesGcpManagedNetworkConfig | undefined;
    private _gkeConfig;
    get gkeConfig(): MwsWorkspacesGkeConfigOutputReference;
    putGkeConfig(value: MwsWorkspacesGkeConfig): void;
    resetGkeConfig(): void;
    get gkeConfigInput(): MwsWorkspacesGkeConfig | undefined;
    private _timeouts;
    get timeouts(): MwsWorkspacesTimeoutsOutputReference;
    putTimeouts(value: MwsWorkspacesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | MwsWorkspacesTimeouts | undefined;
    private _token;
    get token(): MwsWorkspacesTokenOutputReference;
    putToken(value: MwsWorkspacesToken): void;
    resetToken(): void;
    get tokenInput(): MwsWorkspacesToken | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
