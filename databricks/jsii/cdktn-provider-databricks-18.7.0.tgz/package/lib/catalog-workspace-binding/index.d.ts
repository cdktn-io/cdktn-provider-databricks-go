/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CatalogWorkspaceBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#binding_type CatalogWorkspaceBinding#binding_type}
    */
    readonly bindingType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#catalog_name CatalogWorkspaceBinding#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#id CatalogWorkspaceBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#securable_name CatalogWorkspaceBinding#securable_name}
    */
    readonly securableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#securable_type CatalogWorkspaceBinding#securable_type}
    */
    readonly securableType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#workspace_id CatalogWorkspaceBinding#workspace_id}
    */
    readonly workspaceId: number;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#provider_config CatalogWorkspaceBinding#provider_config}
    */
    readonly providerConfig?: CatalogWorkspaceBindingProviderConfig;
}
export interface CatalogWorkspaceBindingProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#workspace_id CatalogWorkspaceBinding#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function catalogWorkspaceBindingProviderConfigToTerraform(struct?: CatalogWorkspaceBindingProviderConfigOutputReference | CatalogWorkspaceBindingProviderConfig): any;
export declare function catalogWorkspaceBindingProviderConfigToHclTerraform(struct?: CatalogWorkspaceBindingProviderConfigOutputReference | CatalogWorkspaceBindingProviderConfig): any;
export declare class CatalogWorkspaceBindingProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CatalogWorkspaceBindingProviderConfig | undefined;
    set internalValue(value: CatalogWorkspaceBindingProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding databricks_catalog_workspace_binding}
*/
export declare class CatalogWorkspaceBinding extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_catalog_workspace_binding";
    /**
    * Generates CDKTN code for importing a CatalogWorkspaceBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CatalogWorkspaceBinding to import
    * @param importFromId The id of the existing CatalogWorkspaceBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CatalogWorkspaceBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/catalog_workspace_binding databricks_catalog_workspace_binding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CatalogWorkspaceBindingConfig
    */
    constructor(scope: Construct, id: string, config: CatalogWorkspaceBindingConfig);
    private _bindingType?;
    get bindingType(): string;
    set bindingType(value: string);
    resetBindingType(): void;
    get bindingTypeInput(): string | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _securableName?;
    get securableName(): string;
    set securableName(value: string);
    resetSecurableName(): void;
    get securableNameInput(): string | undefined;
    private _securableType?;
    get securableType(): string;
    set securableType(value: string);
    resetSecurableType(): void;
    get securableTypeInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): number;
    set workspaceId(value: number);
    get workspaceIdInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): CatalogWorkspaceBindingProviderConfigOutputReference;
    putProviderConfig(value: CatalogWorkspaceBindingProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): CatalogWorkspaceBindingProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
