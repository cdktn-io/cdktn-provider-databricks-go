/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDatabaseDatabaseCatalogsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#instance_name DataDatabricksDatabaseDatabaseCatalogs#instance_name}
    */
    readonly instanceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#page_size DataDatabricksDatabaseDatabaseCatalogs#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#provider_config DataDatabricksDatabaseDatabaseCatalogs#provider_config}
    */
    readonly providerConfig?: DataDatabricksDatabaseDatabaseCatalogsProviderConfig;
}
export interface DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#workspace_id DataDatabricksDatabaseDatabaseCatalogs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfigToTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfigToHclTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#name DataDatabricksDatabaseDatabaseCatalogs#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#provider_config DataDatabricksDatabaseDatabaseCatalogs#provider_config}
    */
    readonly providerConfig?: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig;
}
export declare function dataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsToTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogs): any;
export declare function dataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsToHclTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogs): any;
export declare class DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogs | undefined;
    set internalValue(value: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogs | undefined);
    get createDatabaseIfNotExists(): cdktn.IResolvable;
    get databaseInstanceName(): string;
    get databaseName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsProviderConfig | undefined;
    get uid(): string;
}
export declare class DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogs[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsOutputReference;
}
export interface DataDatabricksDatabaseDatabaseCatalogsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#workspace_id DataDatabricksDatabaseDatabaseCatalogs#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDatabaseDatabaseCatalogsProviderConfigToTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDatabaseDatabaseCatalogsProviderConfigToHclTerraform(struct?: DataDatabricksDatabaseDatabaseCatalogsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDatabaseDatabaseCatalogsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDatabaseDatabaseCatalogsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDatabaseDatabaseCatalogsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs databricks_database_database_catalogs}
*/
export declare class DataDatabricksDatabaseDatabaseCatalogs extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_database_database_catalogs";
    /**
    * Generates CDKTN code for importing a DataDatabricksDatabaseDatabaseCatalogs resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDatabaseDatabaseCatalogs to import
    * @param importFromId The id of the existing DataDatabricksDatabaseDatabaseCatalogs that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDatabaseDatabaseCatalogs to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/database_database_catalogs databricks_database_database_catalogs} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDatabaseDatabaseCatalogsConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDatabaseDatabaseCatalogsConfig);
    private _databaseCatalogs;
    get databaseCatalogs(): DataDatabricksDatabaseDatabaseCatalogsDatabaseCatalogsList;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDatabaseDatabaseCatalogsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDatabaseDatabaseCatalogsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDatabaseDatabaseCatalogsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
