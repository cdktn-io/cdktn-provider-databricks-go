/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAccountIamServicePrincipalV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/account_iam_service_principal_v2#service_principal_id DataDatabricksAccountIamServicePrincipalV2#service_principal_id}
    */
    readonly servicePrincipalId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/account_iam_service_principal_v2 databricks_account_iam_service_principal_v2}
*/
export declare class DataDatabricksAccountIamServicePrincipalV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_account_iam_service_principal_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksAccountIamServicePrincipalV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAccountIamServicePrincipalV2 to import
    * @param importFromId The id of the existing DataDatabricksAccountIamServicePrincipalV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/account_iam_service_principal_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAccountIamServicePrincipalV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/account_iam_service_principal_v2 databricks_account_iam_service_principal_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAccountIamServicePrincipalV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAccountIamServicePrincipalV2Config);
    get accountId(): string;
    get accountSpStatus(): string;
    get applicationId(): string;
    get displayName(): string;
    get externalId(): string;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
