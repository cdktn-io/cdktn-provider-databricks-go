/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksAiSearchIndexesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#page_size DataDatabricksAiSearchIndexes#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#parent DataDatabricksAiSearchIndexes#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#provider_config DataDatabricksAiSearchIndexes#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiSearchIndexesProviderConfig;
}
export interface DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_model_endpoint DataDatabricksAiSearchIndexes#embedding_model_endpoint}
    */
    readonly embeddingModelEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#model_endpoint_name_for_query DataDatabricksAiSearchIndexes#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#name DataDatabricksAiSearchIndexes#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumnsToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpoint?;
    get embeddingModelEndpoint(): string;
    set embeddingModelEndpoint(value: string);
    resetEmbeddingModelEndpoint(): void;
    get embeddingModelEndpointInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_dimension DataDatabricksAiSearchIndexes#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#name DataDatabricksAiSearchIndexes#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumnsToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#columns_to_sync DataDatabricksAiSearchIndexes#columns_to_sync}
    */
    readonly columnsToSync?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_source_columns DataDatabricksAiSearchIndexes#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_vector_columns DataDatabricksAiSearchIndexes#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_writeback_table DataDatabricksAiSearchIndexes#embedding_writeback_table}
    */
    readonly embeddingWritebackTable?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#pipeline_type DataDatabricksAiSearchIndexes#pipeline_type}
    */
    readonly pipelineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#source_table DataDatabricksAiSearchIndexes#source_table}
    */
    readonly sourceTable?: string;
}
export declare function dataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpec): any;
export declare function dataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpec): any;
export declare class DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpec | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpec | undefined);
    private _columnsToSync?;
    get columnsToSync(): string[];
    set columnsToSync(value: string[]);
    resetColumnsToSync(): void;
    get columnsToSyncInput(): string[] | undefined;
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecEmbeddingVectorColumns[] | undefined;
    private _embeddingWritebackTable?;
    get embeddingWritebackTable(): string;
    set embeddingWritebackTable(value: string);
    resetEmbeddingWritebackTable(): void;
    get embeddingWritebackTableInput(): string | undefined;
    get pipelineId(): string;
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    get pipelineTypeInput(): string | undefined;
    private _sourceTable?;
    get sourceTable(): string;
    set sourceTable(value: string);
    resetSourceTable(): void;
    get sourceTableInput(): string | undefined;
}
export interface DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_model_endpoint DataDatabricksAiSearchIndexes#embedding_model_endpoint}
    */
    readonly embeddingModelEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#model_endpoint_name_for_query DataDatabricksAiSearchIndexes#model_endpoint_name_for_query}
    */
    readonly modelEndpointNameForQuery?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#name DataDatabricksAiSearchIndexes#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumnsToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns | cdktn.IResolvable | undefined);
    private _embeddingModelEndpoint?;
    get embeddingModelEndpoint(): string;
    set embeddingModelEndpoint(value: string);
    resetEmbeddingModelEndpoint(): void;
    get embeddingModelEndpointInput(): string | undefined;
    private _modelEndpointNameForQuery?;
    get modelEndpointNameForQuery(): string;
    set modelEndpointNameForQuery(value: string);
    resetModelEndpointNameForQuery(): void;
    get modelEndpointNameForQueryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_dimension DataDatabricksAiSearchIndexes#embedding_dimension}
    */
    readonly embeddingDimension?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#name DataDatabricksAiSearchIndexes#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumnsToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumnsToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns | cdktn.IResolvable | undefined);
    private _embeddingDimension?;
    get embeddingDimension(): number;
    set embeddingDimension(value: number);
    resetEmbeddingDimension(): void;
    get embeddingDimensionInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumnsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumnsOutputReference;
}
export interface DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_source_columns DataDatabricksAiSearchIndexes#embedding_source_columns}
    */
    readonly embeddingSourceColumns?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#embedding_vector_columns DataDatabricksAiSearchIndexes#embedding_vector_columns}
    */
    readonly embeddingVectorColumns?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#schema_json DataDatabricksAiSearchIndexes#schema_json}
    */
    readonly schemaJson?: string;
}
export declare function dataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpec): any;
export declare function dataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpec): any;
export declare class DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpec | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpec | undefined);
    private _embeddingSourceColumns;
    get embeddingSourceColumns(): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumnsList;
    putEmbeddingSourceColumns(value: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns[] | cdktn.IResolvable): void;
    resetEmbeddingSourceColumns(): void;
    get embeddingSourceColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingSourceColumns[] | undefined;
    private _embeddingVectorColumns;
    get embeddingVectorColumns(): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumnsList;
    putEmbeddingVectorColumns(value: DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns[] | cdktn.IResolvable): void;
    resetEmbeddingVectorColumns(): void;
    get embeddingVectorColumnsInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecEmbeddingVectorColumns[] | undefined;
    private _schemaJson?;
    get schemaJson(): string;
    set schemaJson(value: string);
    resetSchemaJson(): void;
    get schemaJsonInput(): string | undefined;
}
export interface DataDatabricksAiSearchIndexesIndexesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#workspace_id DataDatabricksAiSearchIndexes#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiSearchIndexesIndexesProviderConfigToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexesIndexesProviderConfigToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexesIndexesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksAiSearchIndexesIndexesStatus {
}
export declare function dataDatabricksAiSearchIndexesIndexesStatusToTerraform(struct?: DataDatabricksAiSearchIndexesIndexesStatus): any;
export declare function dataDatabricksAiSearchIndexesIndexesStatusToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexesStatus): any;
export declare class DataDatabricksAiSearchIndexesIndexesStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexesIndexesStatus | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexesStatus | undefined);
    get indexUrl(): string;
    get indexedRowCount(): number;
    get message(): string;
    get ready(): cdktn.IResolvable;
}
export interface DataDatabricksAiSearchIndexesIndexes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#name DataDatabricksAiSearchIndexes#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#provider_config DataDatabricksAiSearchIndexes#provider_config}
    */
    readonly providerConfig?: DataDatabricksAiSearchIndexesIndexesProviderConfig;
}
export declare function dataDatabricksAiSearchIndexesIndexesToTerraform(struct?: DataDatabricksAiSearchIndexesIndexes): any;
export declare function dataDatabricksAiSearchIndexesIndexesToHclTerraform(struct?: DataDatabricksAiSearchIndexesIndexes): any;
export declare class DataDatabricksAiSearchIndexesIndexesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAiSearchIndexesIndexes | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesIndexes | undefined);
    get creator(): string;
    private _deltaSyncIndexSpec;
    get deltaSyncIndexSpec(): DataDatabricksAiSearchIndexesIndexesDeltaSyncIndexSpecOutputReference;
    private _directAccessIndexSpec;
    get directAccessIndexSpec(): DataDatabricksAiSearchIndexesIndexesDirectAccessIndexSpecOutputReference;
    get endpoint(): string;
    get indexSubtype(): string;
    get indexType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get primaryKey(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiSearchIndexesIndexesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiSearchIndexesIndexesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexesIndexesProviderConfig | undefined;
    private _status;
    get status(): DataDatabricksAiSearchIndexesIndexesStatusOutputReference;
}
export declare class DataDatabricksAiSearchIndexesIndexesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAiSearchIndexesIndexes[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAiSearchIndexesIndexesOutputReference;
}
export interface DataDatabricksAiSearchIndexesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#workspace_id DataDatabricksAiSearchIndexes#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksAiSearchIndexesProviderConfigToTerraform(struct?: DataDatabricksAiSearchIndexesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksAiSearchIndexesProviderConfigToHclTerraform(struct?: DataDatabricksAiSearchIndexesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksAiSearchIndexesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAiSearchIndexesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAiSearchIndexesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes databricks_ai_search_indexes}
*/
export declare class DataDatabricksAiSearchIndexes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_ai_search_indexes";
    /**
    * Generates CDKTN code for importing a DataDatabricksAiSearchIndexes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksAiSearchIndexes to import
    * @param importFromId The id of the existing DataDatabricksAiSearchIndexes that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksAiSearchIndexes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/ai_search_indexes databricks_ai_search_indexes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksAiSearchIndexesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksAiSearchIndexesConfig);
    private _indexes;
    get indexes(): DataDatabricksAiSearchIndexesIndexesList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksAiSearchIndexesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksAiSearchIndexesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksAiSearchIndexesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
