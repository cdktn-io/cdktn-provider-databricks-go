/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksWorkspaceIamExternalServicePrincipalV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_external_service_principal_v2#name DataDatabricksWorkspaceIamExternalServicePrincipalV2#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_external_service_principal_v2#provider_config DataDatabricksWorkspaceIamExternalServicePrincipalV2#provider_config}
    */
    readonly providerConfig?: DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig;
}
export interface DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_external_service_principal_v2#workspace_id DataDatabricksWorkspaceIamExternalServicePrincipalV2#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfigToTerraform(struct?: DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfigToHclTerraform(struct?: DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_external_service_principal_v2 databricks_workspace_iam_external_service_principal_v2}
*/
export declare class DataDatabricksWorkspaceIamExternalServicePrincipalV2 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_workspace_iam_external_service_principal_v2";
    /**
    * Generates CDKTN code for importing a DataDatabricksWorkspaceIamExternalServicePrincipalV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksWorkspaceIamExternalServicePrincipalV2 to import
    * @param importFromId The id of the existing DataDatabricksWorkspaceIamExternalServicePrincipalV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_external_service_principal_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksWorkspaceIamExternalServicePrincipalV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/workspace_iam_external_service_principal_v2 databricks_workspace_iam_external_service_principal_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksWorkspaceIamExternalServicePrincipalV2Config
    */
    constructor(scope: Construct, id: string, config: DataDatabricksWorkspaceIamExternalServicePrincipalV2Config);
    get accountId(): string;
    get accountSpStatus(): string;
    get applicationId(): string;
    get displayName(): string;
    get externalServicePrincipalId(): string;
    get internalId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksWorkspaceIamExternalServicePrincipalV2ProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
