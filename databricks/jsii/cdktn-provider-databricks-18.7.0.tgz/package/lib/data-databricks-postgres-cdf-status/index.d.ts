/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresCdfStatusConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_cdf_status#name DataDatabricksPostgresCdfStatus#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_cdf_status#provider_config DataDatabricksPostgresCdfStatus#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresCdfStatusProviderConfig;
}
export interface DataDatabricksPostgresCdfStatusProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_cdf_status#workspace_id DataDatabricksPostgresCdfStatus#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresCdfStatusProviderConfigToTerraform(struct?: DataDatabricksPostgresCdfStatusProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresCdfStatusProviderConfigToHclTerraform(struct?: DataDatabricksPostgresCdfStatusProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresCdfStatusProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresCdfStatusProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresCdfStatusProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_cdf_status databricks_postgres_cdf_status}
*/
export declare class DataDatabricksPostgresCdfStatus extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_cdf_status";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresCdfStatus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresCdfStatus to import
    * @param importFromId The id of the existing DataDatabricksPostgresCdfStatus that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_cdf_status#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresCdfStatus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/postgres_cdf_status databricks_postgres_cdf_status} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresCdfStatusConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresCdfStatusConfig);
    get committedLsn(): string;
    get createTime(): string;
    get lastSyncTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get postgresTable(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresCdfStatusProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresCdfStatusProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresCdfStatusProviderConfig | undefined;
    get state(): string;
    get statusDetail(): string;
    get ucTable(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
