/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#page_size DataDatabricksDomains#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#parent_domain_id DataDatabricksDomains#parent_domain_id}
    */
    readonly parentDomainId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#provider_config DataDatabricksDomains#provider_config}
    */
    readonly providerConfig?: DataDatabricksDomainsProviderConfig;
}
export interface DataDatabricksDomainsDomainsIcon {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#color DataDatabricksDomains#color}
    */
    readonly color?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#name DataDatabricksDomains#name}
    */
    readonly name?: string;
}
export declare function dataDatabricksDomainsDomainsIconToTerraform(struct?: DataDatabricksDomainsDomainsIcon): any;
export declare function dataDatabricksDomainsDomainsIconToHclTerraform(struct?: DataDatabricksDomainsDomainsIcon): any;
export declare class DataDatabricksDomainsDomainsIconOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDomainsDomainsIcon | undefined;
    set internalValue(value: DataDatabricksDomainsDomainsIcon | undefined);
    private _color?;
    get color(): string;
    set color(value: string);
    resetColor(): void;
    get colorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export interface DataDatabricksDomainsDomainsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#workspace_id DataDatabricksDomains#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDomainsDomainsProviderConfigToTerraform(struct?: DataDatabricksDomainsDomainsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDomainsDomainsProviderConfigToHclTerraform(struct?: DataDatabricksDomainsDomainsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDomainsDomainsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDomainsDomainsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDomainsDomainsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksDomainsDomains {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#name DataDatabricksDomains#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#provider_config DataDatabricksDomains#provider_config}
    */
    readonly providerConfig?: DataDatabricksDomainsDomainsProviderConfig;
}
export declare function dataDatabricksDomainsDomainsToTerraform(struct?: DataDatabricksDomainsDomains): any;
export declare function dataDatabricksDomainsDomainsToHclTerraform(struct?: DataDatabricksDomainsDomains): any;
export declare class DataDatabricksDomainsDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDomainsDomains | undefined;
    set internalValue(value: DataDatabricksDomainsDomains | undefined);
    get businessOwnerIds(): number[];
    get createTime(): string;
    get description(): string;
    get domainId(): string;
    get draft(): cdktn.IResolvable;
    get effectiveDraft(): cdktn.IResolvable;
    private _icon;
    get icon(): DataDatabricksDomainsDomainsIconOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentDomainId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksDomainsDomainsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDomainsDomainsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDomainsDomainsProviderConfig | undefined;
    get subtitle(): string;
    get tagKey(): string;
    get technicalOwnerIds(): number[];
    get updateTime(): string;
}
export declare class DataDatabricksDomainsDomainsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDomainsDomains[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDomainsDomainsOutputReference;
}
export interface DataDatabricksDomainsProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#workspace_id DataDatabricksDomains#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDomainsProviderConfigToTerraform(struct?: DataDatabricksDomainsProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDomainsProviderConfigToHclTerraform(struct?: DataDatabricksDomainsProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDomainsProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDomainsProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDomainsProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains databricks_domains}
*/
export declare class DataDatabricksDomains extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_domains";
    /**
    * Generates CDKTN code for importing a DataDatabricksDomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDomains to import
    * @param importFromId The id of the existing DataDatabricksDomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/data-sources/domains databricks_domains} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDomainsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksDomainsConfig);
    private _domains;
    get domains(): DataDatabricksDomainsDomainsList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _parentDomainId?;
    get parentDomainId(): string;
    set parentDomainId(value: string);
    resetParentDomainId(): void;
    get parentDomainIdInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDomainsProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDomainsProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDomainsProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
