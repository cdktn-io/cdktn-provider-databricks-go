/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessControlRuleSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether to use account-level or workspace-level API. Valid values are `account` and `workspace`. When not set, the API level is inferred from the provider host.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#api AccessControlRuleSet#api}
    */
    readonly api?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#id AccessControlRuleSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#name AccessControlRuleSet#name}
    */
    readonly name: string;
    /**
    * grant_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#grant_rules AccessControlRuleSet#grant_rules}
    */
    readonly grantRules?: AccessControlRuleSetGrantRules[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#provider_config AccessControlRuleSet#provider_config}
    */
    readonly providerConfig?: AccessControlRuleSetProviderConfig;
}
export interface AccessControlRuleSetGrantRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#principals AccessControlRuleSet#principals}
    */
    readonly principals?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#role AccessControlRuleSet#role}
    */
    readonly role: string;
}
export declare function accessControlRuleSetGrantRulesToTerraform(struct?: AccessControlRuleSetGrantRules | cdktn.IResolvable): any;
export declare function accessControlRuleSetGrantRulesToHclTerraform(struct?: AccessControlRuleSetGrantRules | cdktn.IResolvable): any;
export declare class AccessControlRuleSetGrantRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessControlRuleSetGrantRules | cdktn.IResolvable | undefined;
    set internalValue(value: AccessControlRuleSetGrantRules | cdktn.IResolvable | undefined);
    private _principals?;
    get principals(): string[];
    set principals(value: string[]);
    resetPrincipals(): void;
    get principalsInput(): string[] | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
}
export declare class AccessControlRuleSetGrantRulesList extends cdktn.ComplexList {
    internalValue?: AccessControlRuleSetGrantRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessControlRuleSetGrantRulesOutputReference;
}
export interface AccessControlRuleSetProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#workspace_id AccessControlRuleSet#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function accessControlRuleSetProviderConfigToTerraform(struct?: AccessControlRuleSetProviderConfigOutputReference | AccessControlRuleSetProviderConfig): any;
export declare function accessControlRuleSetProviderConfigToHclTerraform(struct?: AccessControlRuleSetProviderConfigOutputReference | AccessControlRuleSetProviderConfig): any;
export declare class AccessControlRuleSetProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessControlRuleSetProviderConfig | undefined;
    set internalValue(value: AccessControlRuleSetProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set databricks_access_control_rule_set}
*/
export declare class AccessControlRuleSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_access_control_rule_set";
    /**
    * Generates CDKTN code for importing a AccessControlRuleSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessControlRuleSet to import
    * @param importFromId The id of the existing AccessControlRuleSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessControlRuleSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.132.0/docs/resources/access_control_rule_set databricks_access_control_rule_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessControlRuleSetConfig
    */
    constructor(scope: Construct, id: string, config: AccessControlRuleSetConfig);
    private _api?;
    get api(): string;
    set api(value: string);
    resetApi(): void;
    get apiInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _grantRules;
    get grantRules(): AccessControlRuleSetGrantRulesList;
    putGrantRules(value: AccessControlRuleSetGrantRules[] | cdktn.IResolvable): void;
    resetGrantRules(): void;
    get grantRulesInput(): cdktn.IResolvable | AccessControlRuleSetGrantRules[] | undefined;
    private _providerConfig;
    get providerConfig(): AccessControlRuleSetProviderConfigOutputReference;
    putProviderConfig(value: AccessControlRuleSetProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): AccessControlRuleSetProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
