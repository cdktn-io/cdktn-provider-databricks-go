/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPipelinesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines#id DataDatabricksPipelines#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines#ids DataDatabricksPipelines#ids}
    */
    readonly ids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines#pipeline_name DataDatabricksPipelines#pipeline_name}
    */
    readonly pipelineName?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines#provider_config DataDatabricksPipelines#provider_config}
    */
    readonly providerConfig?: DataDatabricksPipelinesProviderConfig;
}
export interface DataDatabricksPipelinesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines#workspace_id DataDatabricksPipelines#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPipelinesProviderConfigToTerraform(struct?: DataDatabricksPipelinesProviderConfigOutputReference | DataDatabricksPipelinesProviderConfig): any;
export declare function dataDatabricksPipelinesProviderConfigToHclTerraform(struct?: DataDatabricksPipelinesProviderConfigOutputReference | DataDatabricksPipelinesProviderConfig): any;
export declare class DataDatabricksPipelinesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPipelinesProviderConfig | undefined;
    set internalValue(value: DataDatabricksPipelinesProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines databricks_pipelines}
*/
export declare class DataDatabricksPipelines extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_pipelines";
    /**
    * Generates CDKTN code for importing a DataDatabricksPipelines resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPipelines to import
    * @param importFromId The id of the existing DataDatabricksPipelines that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPipelines to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/pipelines databricks_pipelines} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPipelinesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksPipelinesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _pipelineName?;
    get pipelineName(): string;
    set pipelineName(value: string);
    resetPipelineName(): void;
    get pipelineNameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksPipelinesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPipelinesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): DataDatabricksPipelinesProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
