/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksSupervisorAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/supervisor_agent#name DataDatabricksSupervisorAgent#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/supervisor_agent#provider_config DataDatabricksSupervisorAgent#provider_config}
    */
    readonly providerConfig?: DataDatabricksSupervisorAgentProviderConfig;
}
export interface DataDatabricksSupervisorAgentProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/supervisor_agent#workspace_id DataDatabricksSupervisorAgent#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksSupervisorAgentProviderConfigToTerraform(struct?: DataDatabricksSupervisorAgentProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksSupervisorAgentProviderConfigToHclTerraform(struct?: DataDatabricksSupervisorAgentProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksSupervisorAgentProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksSupervisorAgentProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksSupervisorAgentProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/supervisor_agent databricks_supervisor_agent}
*/
export declare class DataDatabricksSupervisorAgent extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_supervisor_agent";
    /**
    * Generates CDKTN code for importing a DataDatabricksSupervisorAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksSupervisorAgent to import
    * @param importFromId The id of the existing DataDatabricksSupervisorAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/supervisor_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksSupervisorAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/supervisor_agent databricks_supervisor_agent} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksSupervisorAgentConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksSupervisorAgentConfig);
    get createTime(): string;
    get creator(): string;
    get description(): string;
    get displayName(): string;
    get endpointName(): string;
    get experimentId(): string;
    get id(): string;
    get instructions(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksSupervisorAgentProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksSupervisorAgentProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksSupervisorAgentProviderConfig | undefined;
    get supervisorAgentId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
