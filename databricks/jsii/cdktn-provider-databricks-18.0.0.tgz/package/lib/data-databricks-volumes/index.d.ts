/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksVolumesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes#catalog_name DataDatabricksVolumes#catalog_name}
    */
    readonly catalogName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes#ids DataDatabricksVolumes#ids}
    */
    readonly ids?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes#provider_config DataDatabricksVolumes#provider_config}
    */
    readonly providerConfig?: DataDatabricksVolumesProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes#schema_name DataDatabricksVolumes#schema_name}
    */
    readonly schemaName: string;
}
export interface DataDatabricksVolumesProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes#workspace_id DataDatabricksVolumes#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksVolumesProviderConfigToTerraform(struct?: DataDatabricksVolumesProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksVolumesProviderConfigToHclTerraform(struct?: DataDatabricksVolumesProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksVolumesProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksVolumesProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksVolumesProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes databricks_volumes}
*/
export declare class DataDatabricksVolumes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_volumes";
    /**
    * Generates CDKTN code for importing a DataDatabricksVolumes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksVolumes to import
    * @param importFromId The id of the existing DataDatabricksVolumes that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksVolumes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/volumes databricks_volumes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksVolumesConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksVolumesConfig);
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    get catalogNameInput(): string | undefined;
    private _ids?;
    get ids(): string[];
    set ids(value: string[]);
    resetIds(): void;
    get idsInput(): string[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksVolumesProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksVolumesProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksVolumesProviderConfig | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    get schemaNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
