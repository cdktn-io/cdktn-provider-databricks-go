/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksRegisteredModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#full_name DataDatabricksRegisteredModel#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#include_aliases DataDatabricksRegisteredModel#include_aliases}
    */
    readonly includeAliases?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#include_browse DataDatabricksRegisteredModel#include_browse}
    */
    readonly includeBrowse?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#model_info DataDatabricksRegisteredModel#model_info}
    */
    readonly modelInfo?: DataDatabricksRegisteredModelModelInfo[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#provider_config DataDatabricksRegisteredModel#provider_config}
    */
    readonly providerConfig?: DataDatabricksRegisteredModelProviderConfig;
}
export interface DataDatabricksRegisteredModelModelInfoAliases {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#alias_name DataDatabricksRegisteredModel#alias_name}
    */
    readonly aliasName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#catalog_name DataDatabricksRegisteredModel#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#id DataDatabricksRegisteredModel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#model_name DataDatabricksRegisteredModel#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#schema_name DataDatabricksRegisteredModel#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#version_num DataDatabricksRegisteredModel#version_num}
    */
    readonly versionNum?: number;
}
export declare function dataDatabricksRegisteredModelModelInfoAliasesToTerraform(struct?: DataDatabricksRegisteredModelModelInfoAliases | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelModelInfoAliasesToHclTerraform(struct?: DataDatabricksRegisteredModelModelInfoAliases | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelModelInfoAliasesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelModelInfoAliases | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelModelInfoAliases | cdktn.IResolvable | undefined);
    private _aliasName?;
    get aliasName(): string;
    set aliasName(value: string);
    resetAliasName(): void;
    get aliasNameInput(): string | undefined;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _versionNum?;
    get versionNum(): number;
    set versionNum(value: number);
    resetVersionNum(): void;
    get versionNumInput(): number | undefined;
}
export declare class DataDatabricksRegisteredModelModelInfoAliasesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelModelInfoAliases[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelModelInfoAliasesOutputReference;
}
export interface DataDatabricksRegisteredModelModelInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#aliases DataDatabricksRegisteredModel#aliases}
    */
    readonly aliases?: DataDatabricksRegisteredModelModelInfoAliases[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#catalog_name DataDatabricksRegisteredModel#catalog_name}
    */
    readonly catalogName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#comment DataDatabricksRegisteredModel#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#created_at DataDatabricksRegisteredModel#created_at}
    */
    readonly createdAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#created_by DataDatabricksRegisteredModel#created_by}
    */
    readonly createdBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#full_name DataDatabricksRegisteredModel#full_name}
    */
    readonly fullName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#metastore_id DataDatabricksRegisteredModel#metastore_id}
    */
    readonly metastoreId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#name DataDatabricksRegisteredModel#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#owner DataDatabricksRegisteredModel#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#schema_name DataDatabricksRegisteredModel#schema_name}
    */
    readonly schemaName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#storage_location DataDatabricksRegisteredModel#storage_location}
    */
    readonly storageLocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#updated_at DataDatabricksRegisteredModel#updated_at}
    */
    readonly updatedAt?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#updated_by DataDatabricksRegisteredModel#updated_by}
    */
    readonly updatedBy?: string;
}
export declare function dataDatabricksRegisteredModelModelInfoToTerraform(struct?: DataDatabricksRegisteredModelModelInfo | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelModelInfoToHclTerraform(struct?: DataDatabricksRegisteredModelModelInfo | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelModelInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksRegisteredModelModelInfo | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelModelInfo | cdktn.IResolvable | undefined);
    private _aliases;
    get aliases(): DataDatabricksRegisteredModelModelInfoAliasesList;
    putAliases(value: DataDatabricksRegisteredModelModelInfoAliases[] | cdktn.IResolvable): void;
    resetAliases(): void;
    get aliasesInput(): cdktn.IResolvable | DataDatabricksRegisteredModelModelInfoAliases[] | undefined;
    get browseOnly(): cdktn.IResolvable;
    private _catalogName?;
    get catalogName(): string;
    set catalogName(value: string);
    resetCatalogName(): void;
    get catalogNameInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _createdAt?;
    get createdAt(): number;
    set createdAt(value: number);
    resetCreatedAt(): void;
    get createdAtInput(): number | undefined;
    private _createdBy?;
    get createdBy(): string;
    set createdBy(value: string);
    resetCreatedBy(): void;
    get createdByInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    resetFullName(): void;
    get fullNameInput(): string | undefined;
    private _metastoreId?;
    get metastoreId(): string;
    set metastoreId(value: string);
    resetMetastoreId(): void;
    get metastoreIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _schemaName?;
    get schemaName(): string;
    set schemaName(value: string);
    resetSchemaName(): void;
    get schemaNameInput(): string | undefined;
    private _storageLocation?;
    get storageLocation(): string;
    set storageLocation(value: string);
    resetStorageLocation(): void;
    get storageLocationInput(): string | undefined;
    private _updatedAt?;
    get updatedAt(): number;
    set updatedAt(value: number);
    resetUpdatedAt(): void;
    get updatedAtInput(): number | undefined;
    private _updatedBy?;
    get updatedBy(): string;
    set updatedBy(value: string);
    resetUpdatedBy(): void;
    get updatedByInput(): string | undefined;
}
export declare class DataDatabricksRegisteredModelModelInfoList extends cdktn.ComplexList {
    internalValue?: DataDatabricksRegisteredModelModelInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksRegisteredModelModelInfoOutputReference;
}
export interface DataDatabricksRegisteredModelProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#workspace_id DataDatabricksRegisteredModel#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksRegisteredModelProviderConfigToTerraform(struct?: DataDatabricksRegisteredModelProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksRegisteredModelProviderConfigToHclTerraform(struct?: DataDatabricksRegisteredModelProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksRegisteredModelProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksRegisteredModelProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksRegisteredModelProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model databricks_registered_model}
*/
export declare class DataDatabricksRegisteredModel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_registered_model";
    /**
    * Generates CDKTN code for importing a DataDatabricksRegisteredModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksRegisteredModel to import
    * @param importFromId The id of the existing DataDatabricksRegisteredModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksRegisteredModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/registered_model databricks_registered_model} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksRegisteredModelConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksRegisteredModelConfig);
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _includeAliases?;
    get includeAliases(): boolean | cdktn.IResolvable;
    set includeAliases(value: boolean | cdktn.IResolvable);
    resetIncludeAliases(): void;
    get includeAliasesInput(): boolean | cdktn.IResolvable | undefined;
    private _includeBrowse?;
    get includeBrowse(): boolean | cdktn.IResolvable;
    set includeBrowse(value: boolean | cdktn.IResolvable);
    resetIncludeBrowse(): void;
    get includeBrowseInput(): boolean | cdktn.IResolvable | undefined;
    private _modelInfo;
    get modelInfo(): DataDatabricksRegisteredModelModelInfoList;
    putModelInfo(value: DataDatabricksRegisteredModelModelInfo[] | cdktn.IResolvable): void;
    resetModelInfo(): void;
    get modelInfoInput(): cdktn.IResolvable | DataDatabricksRegisteredModelModelInfo[] | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksRegisteredModelProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksRegisteredModelProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksRegisteredModelProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
