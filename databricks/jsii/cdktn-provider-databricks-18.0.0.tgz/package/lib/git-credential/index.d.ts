/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GitCredentialConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#force GitCredential#force}
    */
    readonly force?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#git_email GitCredential#git_email}
    */
    readonly gitEmail?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#git_provider GitCredential#git_provider}
    */
    readonly gitProvider: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#git_username GitCredential#git_username}
    */
    readonly gitUsername?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#id GitCredential#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#is_default_for_provider GitCredential#is_default_for_provider}
    */
    readonly isDefaultForProvider?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#name GitCredential#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#personal_access_token GitCredential#personal_access_token}
    */
    readonly personalAccessToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#principal_id GitCredential#principal_id}
    */
    readonly principalId?: number;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#provider_config GitCredential#provider_config}
    */
    readonly providerConfig?: GitCredentialProviderConfig;
}
export interface GitCredentialProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#workspace_id GitCredential#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function gitCredentialProviderConfigToTerraform(struct?: GitCredentialProviderConfigOutputReference | GitCredentialProviderConfig): any;
export declare function gitCredentialProviderConfigToHclTerraform(struct?: GitCredentialProviderConfigOutputReference | GitCredentialProviderConfig): any;
export declare class GitCredentialProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GitCredentialProviderConfig | undefined;
    set internalValue(value: GitCredentialProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential databricks_git_credential}
*/
export declare class GitCredential extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_git_credential";
    /**
    * Generates CDKTN code for importing a GitCredential resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GitCredential to import
    * @param importFromId The id of the existing GitCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GitCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/git_credential databricks_git_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GitCredentialConfig
    */
    constructor(scope: Construct, id: string, config: GitCredentialConfig);
    private _force?;
    get force(): boolean | cdktn.IResolvable;
    set force(value: boolean | cdktn.IResolvable);
    resetForce(): void;
    get forceInput(): boolean | cdktn.IResolvable | undefined;
    private _gitEmail?;
    get gitEmail(): string;
    set gitEmail(value: string);
    resetGitEmail(): void;
    get gitEmailInput(): string | undefined;
    private _gitProvider?;
    get gitProvider(): string;
    set gitProvider(value: string);
    get gitProviderInput(): string | undefined;
    private _gitUsername?;
    get gitUsername(): string;
    set gitUsername(value: string);
    resetGitUsername(): void;
    get gitUsernameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isDefaultForProvider?;
    get isDefaultForProvider(): boolean | cdktn.IResolvable;
    set isDefaultForProvider(value: boolean | cdktn.IResolvable);
    resetIsDefaultForProvider(): void;
    get isDefaultForProviderInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _personalAccessToken?;
    get personalAccessToken(): string;
    set personalAccessToken(value: string);
    resetPersonalAccessToken(): void;
    get personalAccessTokenInput(): string | undefined;
    private _principalId?;
    get principalId(): number;
    set principalId(value: number);
    resetPrincipalId(): void;
    get principalIdInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): GitCredentialProviderConfigOutputReference;
    putProviderConfig(value: GitCredentialProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): GitCredentialProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
