/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SqlDashboardConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#created_at SqlDashboard#created_at}
    */
    readonly createdAt?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#dashboard_filters_enabled SqlDashboard#dashboard_filters_enabled}
    */
    readonly dashboardFiltersEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#id SqlDashboard#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#name SqlDashboard#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#parent SqlDashboard#parent}
    */
    readonly parent?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#run_as_role SqlDashboard#run_as_role}
    */
    readonly runAsRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#tags SqlDashboard#tags}
    */
    readonly tags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#updated_at SqlDashboard#updated_at}
    */
    readonly updatedAt?: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#provider_config SqlDashboard#provider_config}
    */
    readonly providerConfig?: SqlDashboardProviderConfig;
}
export interface SqlDashboardProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#workspace_id SqlDashboard#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function sqlDashboardProviderConfigToTerraform(struct?: SqlDashboardProviderConfigOutputReference | SqlDashboardProviderConfig): any;
export declare function sqlDashboardProviderConfigToHclTerraform(struct?: SqlDashboardProviderConfigOutputReference | SqlDashboardProviderConfig): any;
export declare class SqlDashboardProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlDashboardProviderConfig | undefined;
    set internalValue(value: SqlDashboardProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard databricks_sql_dashboard}
*/
export declare class SqlDashboard extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_sql_dashboard";
    /**
    * Generates CDKTN code for importing a SqlDashboard resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlDashboard to import
    * @param importFromId The id of the existing SqlDashboard that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlDashboard to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/sql_dashboard databricks_sql_dashboard} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlDashboardConfig
    */
    constructor(scope: Construct, id: string, config: SqlDashboardConfig);
    private _createdAt?;
    get createdAt(): string;
    set createdAt(value: string);
    resetCreatedAt(): void;
    get createdAtInput(): string | undefined;
    private _dashboardFiltersEnabled?;
    get dashboardFiltersEnabled(): boolean | cdktn.IResolvable;
    set dashboardFiltersEnabled(value: boolean | cdktn.IResolvable);
    resetDashboardFiltersEnabled(): void;
    get dashboardFiltersEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _runAsRole?;
    get runAsRole(): string;
    set runAsRole(value: string);
    resetRunAsRole(): void;
    get runAsRoleInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _updatedAt?;
    get updatedAt(): string;
    set updatedAt(value: string);
    resetUpdatedAt(): void;
    get updatedAtInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): SqlDashboardProviderConfigOutputReference;
    putProviderConfig(value: SqlDashboardProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SqlDashboardProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
