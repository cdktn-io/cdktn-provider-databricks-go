/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ProviderResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#authentication_type ProviderResource#authentication_type}
    */
    readonly authenticationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#comment ProviderResource#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#id ProviderResource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#name ProviderResource#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#recipient_profile_str ProviderResource#recipient_profile_str}
    */
    readonly recipientProfileStr: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#provider_config ProviderResource#provider_config}
    */
    readonly providerConfig?: ProviderResourceProviderConfig;
}
export interface ProviderResourceProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#workspace_id ProviderResource#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function providerResourceProviderConfigToTerraform(struct?: ProviderResourceProviderConfigOutputReference | ProviderResourceProviderConfig): any;
export declare function providerResourceProviderConfigToHclTerraform(struct?: ProviderResourceProviderConfigOutputReference | ProviderResourceProviderConfig): any;
export declare class ProviderResourceProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ProviderResourceProviderConfig | undefined;
    set internalValue(value: ProviderResourceProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider databricks_provider}
*/
export declare class ProviderResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_provider";
    /**
    * Generates CDKTN code for importing a ProviderResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ProviderResource to import
    * @param importFromId The id of the existing ProviderResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ProviderResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/provider databricks_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ProviderResourceConfig
    */
    constructor(scope: Construct, id: string, config: ProviderResourceConfig);
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    get authenticationTypeInput(): string | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _recipientProfileStr?;
    get recipientProfileStr(): string;
    set recipientProfileStr(value: string);
    get recipientProfileStrInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): ProviderResourceProviderConfigOutputReference;
    putProviderConfig(value: ProviderResourceProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): ProviderResourceProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
