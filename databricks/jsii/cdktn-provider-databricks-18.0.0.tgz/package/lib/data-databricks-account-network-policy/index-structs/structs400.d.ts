/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules, DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList, DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess, DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference, DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess, DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessOutputReference } from './structs0';
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#authentication DataDatabricksAccountNetworkPolicy#authentication}
    */
    readonly authentication?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#destination DataDatabricksAccountNetworkPolicy#destination}
    */
    readonly destination?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#label DataDatabricksAccountNetworkPolicy#label}
    */
    readonly label?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#origin DataDatabricksAccountNetworkPolicy#origin}
    */
    readonly origin?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules | cdktn.IResolvable | undefined);
    private _authentication;
    get authentication(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthenticationOutputReference;
    putAuthentication(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesAuthentication | undefined;
    private _destination;
    get destination(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestinationOutputReference;
    putDestination(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesDestination | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _origin;
    get origin(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOriginOutputReference;
    putOrigin(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOrigin | undefined;
}
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesList extends cdktn.ComplexList {
    internalValue?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesOutputReference;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#allow_rules DataDatabricksAccountNetworkPolicy#allow_rules}
    */
    readonly allowRules?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#deny_rules DataDatabricksAccountNetworkPolicy#deny_rules}
    */
    readonly denyRules?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#restriction_mode DataDatabricksAccountNetworkPolicy#restriction_mode}
    */
    readonly restrictionMode: string;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess | cdktn.IResolvable | undefined);
    private _allowRules;
    get allowRules(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRulesList;
    putAllowRules(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | cdktn.IResolvable): void;
    resetAllowRules(): void;
    get allowRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessAllowRules[] | undefined;
    private _denyRules;
    get denyRules(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRulesList;
    putDenyRules(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | cdktn.IResolvable): void;
    resetDenyRules(): void;
    get denyRulesInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessDenyRules[] | undefined;
    private _restrictionMode?;
    get restrictionMode(): string;
    set restrictionMode(value: string);
    get restrictionModeInput(): string | undefined;
}
export interface DataDatabricksAccountNetworkPolicyIngressDryRun {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#cross_workspace_access DataDatabricksAccountNetworkPolicy#cross_workspace_access}
    */
    readonly crossWorkspaceAccess?: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#private_access DataDatabricksAccountNetworkPolicy#private_access}
    */
    readonly privateAccess?: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/account_network_policy#public_access DataDatabricksAccountNetworkPolicy#public_access}
    */
    readonly publicAccess?: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess;
}
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunToTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRun): any;
export declare function dataDatabricksAccountNetworkPolicyIngressDryRunToHclTerraform(struct?: DataDatabricksAccountNetworkPolicyIngressDryRun): any;
export declare class DataDatabricksAccountNetworkPolicyIngressDryRunOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksAccountNetworkPolicyIngressDryRun | undefined;
    set internalValue(value: DataDatabricksAccountNetworkPolicyIngressDryRun | undefined);
    private _crossWorkspaceAccess;
    get crossWorkspaceAccess(): DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccessOutputReference;
    putCrossWorkspaceAccess(value: DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess): void;
    resetCrossWorkspaceAccess(): void;
    get crossWorkspaceAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunCrossWorkspaceAccess | undefined;
    private _privateAccess;
    get privateAccess(): DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccessOutputReference;
    putPrivateAccess(value: DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess): void;
    resetPrivateAccess(): void;
    get privateAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPrivateAccess | undefined;
    private _publicAccess;
    get publicAccess(): DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccessOutputReference;
    putPublicAccess(value: DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess): void;
    resetPublicAccess(): void;
    get publicAccessInput(): cdktn.IResolvable | DataDatabricksAccountNetworkPolicyIngressDryRunPublicAccess | undefined;
}
