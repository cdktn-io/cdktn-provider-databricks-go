/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDataQualityMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#object_id DataDatabricksDataQualityMonitor#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#object_type DataDatabricksDataQualityMonitor#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#provider_config DataDatabricksDataQualityMonitor#provider_config}
    */
    readonly providerConfig?: DataDatabricksDataQualityMonitorProviderConfig;
}
export interface DataDatabricksDataQualityMonitorAnomalyDetectionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#excluded_table_full_names DataDatabricksDataQualityMonitor#excluded_table_full_names}
    */
    readonly excludedTableFullNames?: string[];
}
export declare function dataDatabricksDataQualityMonitorAnomalyDetectionConfigToTerraform(struct?: DataDatabricksDataQualityMonitorAnomalyDetectionConfig): any;
export declare function dataDatabricksDataQualityMonitorAnomalyDetectionConfigToHclTerraform(struct?: DataDatabricksDataQualityMonitorAnomalyDetectionConfig): any;
export declare class DataDatabricksDataQualityMonitorAnomalyDetectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorAnomalyDetectionConfig | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorAnomalyDetectionConfig | undefined);
    private _excludedTableFullNames?;
    get excludedTableFullNames(): string[];
    set excludedTableFullNames(value: string[]);
    resetExcludedTableFullNames(): void;
    get excludedTableFullNamesInput(): string[] | undefined;
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#definition DataDatabricksDataQualityMonitor#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#input_columns DataDatabricksDataQualityMonitor#input_columns}
    */
    readonly inputColumns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#name DataDatabricksDataQualityMonitor#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#output_data_type DataDatabricksDataQualityMonitor#output_data_type}
    */
    readonly outputDataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#type DataDatabricksDataQualityMonitor#type}
    */
    readonly type: string;
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigCustomMetricsToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigCustomMetricsToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics | cdktn.IResolvable | undefined);
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    private _inputColumns?;
    get inputColumns(): string[];
    set inputColumns(value: string[]);
    get inputColumnsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputDataType?;
    get outputDataType(): string;
    set outputDataType(value: string);
    get outputDataTypeInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetricsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetricsOutputReference;
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#granularities DataDatabricksDataQualityMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#label_column DataDatabricksDataQualityMonitor#label_column}
    */
    readonly labelColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#model_id_column DataDatabricksDataQualityMonitor#model_id_column}
    */
    readonly modelIdColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#prediction_column DataDatabricksDataQualityMonitor#prediction_column}
    */
    readonly predictionColumn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#problem_type DataDatabricksDataQualityMonitor#problem_type}
    */
    readonly problemType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#timestamp_column DataDatabricksDataQualityMonitor#timestamp_column}
    */
    readonly timestampColumn: string;
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigInferenceLogToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigInferenceLogToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLogOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _labelColumn?;
    get labelColumn(): string;
    set labelColumn(value: string);
    resetLabelColumn(): void;
    get labelColumnInput(): string | undefined;
    private _modelIdColumn?;
    get modelIdColumn(): string;
    set modelIdColumn(value: string);
    get modelIdColumnInput(): string | undefined;
    private _predictionColumn?;
    get predictionColumn(): string;
    set predictionColumn(value: string);
    get predictionColumnInput(): string | undefined;
    private _problemType?;
    get problemType(): string;
    set problemType(value: string);
    get problemTypeInput(): string | undefined;
    private _timestampColumn?;
    get timestampColumn(): string;
    set timestampColumn(value: string);
    get timestampColumnInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#email_addresses DataDatabricksDataQualityMonitor#email_addresses}
    */
    readonly emailAddresses?: string[];
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | cdktn.IResolvable | undefined);
    private _emailAddresses?;
    get emailAddresses(): string[];
    set emailAddresses(value: string[]);
    resetEmailAddresses(): void;
    get emailAddressesInput(): string[] | undefined;
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#on_failure DataDatabricksDataQualityMonitor#on_failure}
    */
    readonly onFailure?: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure;
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings | cdktn.IResolvable | undefined);
    private _onFailure;
    get onFailure(): DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailureOutputReference;
    putOnFailure(value: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOnFailure | undefined;
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfigSchedule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#quartz_cron_expression DataDatabricksDataQualityMonitor#quartz_cron_expression}
    */
    readonly quartzCronExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#timezone_id DataDatabricksDataQualityMonitor#timezone_id}
    */
    readonly timezoneId: string;
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigScheduleToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigScheduleToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfigSchedule | cdktn.IResolvable | undefined);
    get pauseStatus(): string;
    private _quartzCronExpression?;
    get quartzCronExpression(): string;
    set quartzCronExpression(value: string);
    get quartzCronExpressionInput(): string | undefined;
    private _timezoneId?;
    get timezoneId(): string;
    set timezoneId(value: string);
    get timezoneIdInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot {
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigSnapshotToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigSnapshotToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigSnapshotOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot | cdktn.IResolvable | undefined);
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#granularities DataDatabricksDataQualityMonitor#granularities}
    */
    readonly granularities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#timestamp_column DataDatabricksDataQualityMonitor#timestamp_column}
    */
    readonly timestampColumn: string;
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigTimeSeriesToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigTimeSeriesToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries | cdktn.IResolvable | undefined);
    private _granularities?;
    get granularities(): string[];
    set granularities(value: string[]);
    get granularitiesInput(): string[] | undefined;
    private _timestampColumn?;
    get timestampColumn(): string;
    set timestampColumn(value: string);
    get timestampColumnInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorDataProfilingConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#assets_dir DataDatabricksDataQualityMonitor#assets_dir}
    */
    readonly assetsDir?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#baseline_table_name DataDatabricksDataQualityMonitor#baseline_table_name}
    */
    readonly baselineTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#custom_metrics DataDatabricksDataQualityMonitor#custom_metrics}
    */
    readonly customMetrics?: DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#inference_log DataDatabricksDataQualityMonitor#inference_log}
    */
    readonly inferenceLog?: DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#notification_settings DataDatabricksDataQualityMonitor#notification_settings}
    */
    readonly notificationSettings?: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#output_schema_id DataDatabricksDataQualityMonitor#output_schema_id}
    */
    readonly outputSchemaId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#schedule DataDatabricksDataQualityMonitor#schedule}
    */
    readonly schedule?: DataDatabricksDataQualityMonitorDataProfilingConfigSchedule;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#skip_builtin_dashboard DataDatabricksDataQualityMonitor#skip_builtin_dashboard}
    */
    readonly skipBuiltinDashboard?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#slicing_exprs DataDatabricksDataQualityMonitor#slicing_exprs}
    */
    readonly slicingExprs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#snapshot DataDatabricksDataQualityMonitor#snapshot}
    */
    readonly snapshot?: DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#time_series DataDatabricksDataQualityMonitor#time_series}
    */
    readonly timeSeries?: DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#warehouse_id DataDatabricksDataQualityMonitor#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigToTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfig): any;
export declare function dataDatabricksDataQualityMonitorDataProfilingConfigToHclTerraform(struct?: DataDatabricksDataQualityMonitorDataProfilingConfig): any;
export declare class DataDatabricksDataQualityMonitorDataProfilingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorDataProfilingConfig | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorDataProfilingConfig | undefined);
    private _assetsDir?;
    get assetsDir(): string;
    set assetsDir(value: string);
    resetAssetsDir(): void;
    get assetsDirInput(): string | undefined;
    private _baselineTableName?;
    get baselineTableName(): string;
    set baselineTableName(value: string);
    resetBaselineTableName(): void;
    get baselineTableNameInput(): string | undefined;
    private _customMetrics;
    get customMetrics(): DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetricsList;
    putCustomMetrics(value: DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics[] | cdktn.IResolvable): void;
    resetCustomMetrics(): void;
    get customMetricsInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorDataProfilingConfigCustomMetrics[] | undefined;
    get dashboardId(): string;
    get driftMetricsTableName(): string;
    get effectiveWarehouseId(): string;
    private _inferenceLog;
    get inferenceLog(): DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLogOutputReference;
    putInferenceLog(value: DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog): void;
    resetInferenceLog(): void;
    get inferenceLogInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorDataProfilingConfigInferenceLog | undefined;
    get latestMonitorFailureMessage(): string;
    get monitorVersion(): number;
    get monitoredTableName(): string;
    private _notificationSettings;
    get notificationSettings(): DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettingsOutputReference;
    putNotificationSettings(value: DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorDataProfilingConfigNotificationSettings | undefined;
    private _outputSchemaId?;
    get outputSchemaId(): string;
    set outputSchemaId(value: string);
    get outputSchemaIdInput(): string | undefined;
    get profileMetricsTableName(): string;
    private _schedule;
    get schedule(): DataDatabricksDataQualityMonitorDataProfilingConfigScheduleOutputReference;
    putSchedule(value: DataDatabricksDataQualityMonitorDataProfilingConfigSchedule): void;
    resetSchedule(): void;
    get scheduleInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorDataProfilingConfigSchedule | undefined;
    private _skipBuiltinDashboard?;
    get skipBuiltinDashboard(): boolean | cdktn.IResolvable;
    set skipBuiltinDashboard(value: boolean | cdktn.IResolvable);
    resetSkipBuiltinDashboard(): void;
    get skipBuiltinDashboardInput(): boolean | cdktn.IResolvable | undefined;
    private _slicingExprs?;
    get slicingExprs(): string[];
    set slicingExprs(value: string[]);
    resetSlicingExprs(): void;
    get slicingExprsInput(): string[] | undefined;
    private _snapshot;
    get snapshot(): DataDatabricksDataQualityMonitorDataProfilingConfigSnapshotOutputReference;
    putSnapshot(value: DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot): void;
    resetSnapshot(): void;
    get snapshotInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorDataProfilingConfigSnapshot | undefined;
    get status(): string;
    private _timeSeries;
    get timeSeries(): DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeriesOutputReference;
    putTimeSeries(value: DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries): void;
    resetTimeSeries(): void;
    get timeSeriesInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorDataProfilingConfigTimeSeries | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface DataDatabricksDataQualityMonitorProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#workspace_id DataDatabricksDataQualityMonitor#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDataQualityMonitorProviderConfigToTerraform(struct?: DataDatabricksDataQualityMonitorProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityMonitorProviderConfigToHclTerraform(struct?: DataDatabricksDataQualityMonitorProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityMonitorProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityMonitorProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityMonitorProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor databricks_data_quality_monitor}
*/
export declare class DataDatabricksDataQualityMonitor extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_data_quality_monitor";
    /**
    * Generates CDKTN code for importing a DataDatabricksDataQualityMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDataQualityMonitor to import
    * @param importFromId The id of the existing DataDatabricksDataQualityMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDataQualityMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_monitor databricks_data_quality_monitor} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDataQualityMonitorConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDataQualityMonitorConfig);
    private _anomalyDetectionConfig;
    get anomalyDetectionConfig(): DataDatabricksDataQualityMonitorAnomalyDetectionConfigOutputReference;
    private _dataProfilingConfig;
    get dataProfilingConfig(): DataDatabricksDataQualityMonitorDataProfilingConfigOutputReference;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDataQualityMonitorProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDataQualityMonitorProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDataQualityMonitorProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
