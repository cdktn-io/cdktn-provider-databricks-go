/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SystemSchemaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/system_schema#id SystemSchema#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/system_schema#schema SystemSchema#schema}
    */
    readonly schema: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/system_schema#provider_config SystemSchema#provider_config}
    */
    readonly providerConfig?: SystemSchemaProviderConfig;
}
export interface SystemSchemaProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/system_schema#workspace_id SystemSchema#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function systemSchemaProviderConfigToTerraform(struct?: SystemSchemaProviderConfigOutputReference | SystemSchemaProviderConfig): any;
export declare function systemSchemaProviderConfigToHclTerraform(struct?: SystemSchemaProviderConfigOutputReference | SystemSchemaProviderConfig): any;
export declare class SystemSchemaProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SystemSchemaProviderConfig | undefined;
    set internalValue(value: SystemSchemaProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/system_schema databricks_system_schema}
*/
export declare class SystemSchema extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_system_schema";
    /**
    * Generates CDKTN code for importing a SystemSchema resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SystemSchema to import
    * @param importFromId The id of the existing SystemSchema that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/system_schema#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SystemSchema to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/system_schema databricks_system_schema} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SystemSchemaConfig
    */
    constructor(scope: Construct, id: string, config: SystemSchemaConfig);
    get autoEnabled(): cdktn.IResolvable;
    get fullName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get metastoreId(): string;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    get state(): string;
    private _providerConfig;
    get providerConfig(): SystemSchemaProviderConfigOutputReference;
    putProviderConfig(value: SystemSchemaProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): SystemSchemaProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
