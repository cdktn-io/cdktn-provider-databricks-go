/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksExternalMetadatasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas#page_size DataDatabricksExternalMetadatas#page_size}
    */
    readonly pageSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas#provider_config DataDatabricksExternalMetadatas#provider_config}
    */
    readonly providerConfig?: DataDatabricksExternalMetadatasProviderConfig;
}
export interface DataDatabricksExternalMetadatasExternalMetadataProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas#workspace_id DataDatabricksExternalMetadatas#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksExternalMetadatasExternalMetadataProviderConfigToTerraform(struct?: DataDatabricksExternalMetadatasExternalMetadataProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksExternalMetadatasExternalMetadataProviderConfigToHclTerraform(struct?: DataDatabricksExternalMetadatasExternalMetadataProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksExternalMetadatasExternalMetadataProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalMetadatasExternalMetadataProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksExternalMetadatasExternalMetadataProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksExternalMetadatasExternalMetadata {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas#name DataDatabricksExternalMetadatas#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas#provider_config DataDatabricksExternalMetadatas#provider_config}
    */
    readonly providerConfig?: DataDatabricksExternalMetadatasExternalMetadataProviderConfig;
}
export declare function dataDatabricksExternalMetadatasExternalMetadataToTerraform(struct?: DataDatabricksExternalMetadatasExternalMetadata): any;
export declare function dataDatabricksExternalMetadatasExternalMetadataToHclTerraform(struct?: DataDatabricksExternalMetadatasExternalMetadata): any;
export declare class DataDatabricksExternalMetadatasExternalMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksExternalMetadatasExternalMetadata | undefined;
    set internalValue(value: DataDatabricksExternalMetadatasExternalMetadata | undefined);
    get columns(): string[];
    get createTime(): string;
    get createdBy(): string;
    get description(): string;
    get entityType(): string;
    get id(): string;
    get metastoreId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get owner(): string;
    private _properties;
    get properties(): cdktn.StringMap;
    private _providerConfig;
    get providerConfig(): DataDatabricksExternalMetadatasExternalMetadataProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksExternalMetadatasExternalMetadataProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksExternalMetadatasExternalMetadataProviderConfig | undefined;
    get systemType(): string;
    get updateTime(): string;
    get updatedBy(): string;
    get url(): string;
}
export declare class DataDatabricksExternalMetadatasExternalMetadataList extends cdktn.ComplexList {
    internalValue?: DataDatabricksExternalMetadatasExternalMetadata[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksExternalMetadatasExternalMetadataOutputReference;
}
export interface DataDatabricksExternalMetadatasProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas#workspace_id DataDatabricksExternalMetadatas#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksExternalMetadatasProviderConfigToTerraform(struct?: DataDatabricksExternalMetadatasProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksExternalMetadatasProviderConfigToHclTerraform(struct?: DataDatabricksExternalMetadatasProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksExternalMetadatasProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksExternalMetadatasProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksExternalMetadatasProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas databricks_external_metadatas}
*/
export declare class DataDatabricksExternalMetadatas extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_external_metadatas";
    /**
    * Generates CDKTN code for importing a DataDatabricksExternalMetadatas resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksExternalMetadatas to import
    * @param importFromId The id of the existing DataDatabricksExternalMetadatas that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksExternalMetadatas to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/external_metadatas databricks_external_metadatas} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksExternalMetadatasConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataDatabricksExternalMetadatasConfig);
    private _externalMetadata;
    get externalMetadata(): DataDatabricksExternalMetadatasExternalMetadataList;
    private _pageSize?;
    get pageSize(): number;
    set pageSize(value: number);
    resetPageSize(): void;
    get pageSizeInput(): number | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksExternalMetadatasProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksExternalMetadatasProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksExternalMetadatasProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
