/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IpAccessListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#enabled IpAccessList#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#id IpAccessList#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#ip_addresses IpAccessList#ip_addresses}
    */
    readonly ipAddresses: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#label IpAccessList#label}
    */
    readonly label: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#list_type IpAccessList#list_type}
    */
    readonly listType: string;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#provider_config IpAccessList#provider_config}
    */
    readonly providerConfig?: IpAccessListProviderConfig;
}
export interface IpAccessListProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#workspace_id IpAccessList#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function ipAccessListProviderConfigToTerraform(struct?: IpAccessListProviderConfigOutputReference | IpAccessListProviderConfig): any;
export declare function ipAccessListProviderConfigToHclTerraform(struct?: IpAccessListProviderConfigOutputReference | IpAccessListProviderConfig): any;
export declare class IpAccessListProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): IpAccessListProviderConfig | undefined;
    set internalValue(value: IpAccessListProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list databricks_ip_access_list}
*/
export declare class IpAccessList extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_ip_access_list";
    /**
    * Generates CDKTN code for importing a IpAccessList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IpAccessList to import
    * @param importFromId The id of the existing IpAccessList that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IpAccessList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/ip_access_list databricks_ip_access_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IpAccessListConfig
    */
    constructor(scope: Construct, id: string, config: IpAccessListConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddresses?;
    get ipAddresses(): string[];
    set ipAddresses(value: string[]);
    get ipAddressesInput(): string[] | undefined;
    private _label?;
    get label(): string;
    set label(value: string);
    get labelInput(): string | undefined;
    private _listType?;
    get listType(): string;
    set listType(value: string);
    get listTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): IpAccessListProviderConfigOutputReference;
    putProviderConfig(value: IpAccessListProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): IpAccessListProviderConfig | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
