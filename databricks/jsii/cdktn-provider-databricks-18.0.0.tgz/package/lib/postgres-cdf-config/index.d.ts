/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostgresCdfConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#catalog PostgresCdfConfig#catalog}
    */
    readonly catalog: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#cdf_config_id PostgresCdfConfig#cdf_config_id}
    */
    readonly cdfConfigId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#parent PostgresCdfConfig#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#postgres_schema PostgresCdfConfig#postgres_schema}
    */
    readonly postgresSchema: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#provider_config PostgresCdfConfig#provider_config}
    */
    readonly providerConfig?: PostgresCdfConfigProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#schema PostgresCdfConfig#schema}
    */
    readonly schema: string;
}
export interface PostgresCdfConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#workspace_id PostgresCdfConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function postgresCdfConfigProviderConfigToTerraform(struct?: PostgresCdfConfigProviderConfig | cdktn.IResolvable): any;
export declare function postgresCdfConfigProviderConfigToHclTerraform(struct?: PostgresCdfConfigProviderConfig | cdktn.IResolvable): any;
export declare class PostgresCdfConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresCdfConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: PostgresCdfConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config databricks_postgres_cdf_config}
*/
export declare class PostgresCdfConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_postgres_cdf_config";
    /**
    * Generates CDKTN code for importing a PostgresCdfConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresCdfConfig to import
    * @param importFromId The id of the existing PostgresCdfConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresCdfConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/postgres_cdf_config databricks_postgres_cdf_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresCdfConfigConfig
    */
    constructor(scope: Construct, id: string, config: PostgresCdfConfigConfig);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    get catalogInput(): string | undefined;
    private _cdfConfigId?;
    get cdfConfigId(): string;
    set cdfConfigId(value: string);
    resetCdfConfigId(): void;
    get cdfConfigIdInput(): string | undefined;
    get createTime(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _postgresSchema?;
    get postgresSchema(): string;
    set postgresSchema(value: string);
    get postgresSchemaInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): PostgresCdfConfigProviderConfigOutputReference;
    putProviderConfig(value: PostgresCdfConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | PostgresCdfConfigProviderConfig | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    get schemaInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
