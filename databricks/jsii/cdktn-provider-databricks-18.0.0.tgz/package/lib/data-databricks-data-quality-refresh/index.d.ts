/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksDataQualityRefreshConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh#object_id DataDatabricksDataQualityRefresh#object_id}
    */
    readonly objectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh#object_type DataDatabricksDataQualityRefresh#object_type}
    */
    readonly objectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh#provider_config DataDatabricksDataQualityRefresh#provider_config}
    */
    readonly providerConfig?: DataDatabricksDataQualityRefreshProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh#refresh_id DataDatabricksDataQualityRefresh#refresh_id}
    */
    readonly refreshId: number;
}
export interface DataDatabricksDataQualityRefreshProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh#workspace_id DataDatabricksDataQualityRefresh#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksDataQualityRefreshProviderConfigToTerraform(struct?: DataDatabricksDataQualityRefreshProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksDataQualityRefreshProviderConfigToHclTerraform(struct?: DataDatabricksDataQualityRefreshProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksDataQualityRefreshProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksDataQualityRefreshProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksDataQualityRefreshProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh databricks_data_quality_refresh}
*/
export declare class DataDatabricksDataQualityRefresh extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_data_quality_refresh";
    /**
    * Generates CDKTN code for importing a DataDatabricksDataQualityRefresh resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksDataQualityRefresh to import
    * @param importFromId The id of the existing DataDatabricksDataQualityRefresh that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksDataQualityRefresh to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/data_quality_refresh databricks_data_quality_refresh} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksDataQualityRefreshConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksDataQualityRefreshConfig);
    get endTimeMs(): number;
    get message(): string;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectType?;
    get objectType(): string;
    set objectType(value: string);
    get objectTypeInput(): string | undefined;
    private _providerConfig;
    get providerConfig(): DataDatabricksDataQualityRefreshProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksDataQualityRefreshProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksDataQualityRefreshProviderConfig | undefined;
    private _refreshId?;
    get refreshId(): number;
    set refreshId(value: number);
    get refreshIdInput(): number | undefined;
    get startTimeMs(): number;
    get state(): string;
    get trigger(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
