/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataDatabricksPostgresProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#name DataDatabricksPostgresProject#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#provider_config DataDatabricksPostgresProject#provider_config}
    */
    readonly providerConfig?: DataDatabricksPostgresProjectProviderConfig;
}
export interface DataDatabricksPostgresProjectInitialBranchSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#is_protected DataDatabricksPostgresProject#is_protected}
    */
    readonly isProtected?: boolean | cdktn.IResolvable;
}
export declare function dataDatabricksPostgresProjectInitialBranchSpecToTerraform(struct?: DataDatabricksPostgresProjectInitialBranchSpec): any;
export declare function dataDatabricksPostgresProjectInitialBranchSpecToHclTerraform(struct?: DataDatabricksPostgresProjectInitialBranchSpec): any;
export declare class DataDatabricksPostgresProjectInitialBranchSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectInitialBranchSpec | undefined;
    set internalValue(value: DataDatabricksPostgresProjectInitialBranchSpec | undefined);
    private _isProtected?;
    get isProtected(): boolean | cdktn.IResolvable;
    set isProtected(value: boolean | cdktn.IResolvable);
    resetIsProtected(): void;
    get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface DataDatabricksPostgresProjectInitialEndpointSpecGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#enable_readable_secondaries DataDatabricksPostgresProject#enable_readable_secondaries}
    */
    readonly enableReadableSecondaries?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#max DataDatabricksPostgresProject#max}
    */
    readonly max: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#min DataDatabricksPostgresProject#min}
    */
    readonly min: number;
}
export declare function dataDatabricksPostgresProjectInitialEndpointSpecGroupToTerraform(struct?: DataDatabricksPostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectInitialEndpointSpecGroupToHclTerraform(struct?: DataDatabricksPostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectInitialEndpointSpecGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectInitialEndpointSpecGroup | cdktn.IResolvable | undefined);
    private _enableReadableSecondaries?;
    get enableReadableSecondaries(): boolean | cdktn.IResolvable;
    set enableReadableSecondaries(value: boolean | cdktn.IResolvable);
    resetEnableReadableSecondaries(): void;
    get enableReadableSecondariesInput(): boolean | cdktn.IResolvable | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface DataDatabricksPostgresProjectInitialEndpointSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#autoscaling_limit_max_cu DataDatabricksPostgresProject#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#autoscaling_limit_min_cu DataDatabricksPostgresProject#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#group DataDatabricksPostgresProject#group}
    */
    readonly group?: DataDatabricksPostgresProjectInitialEndpointSpecGroup;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#no_suspension DataDatabricksPostgresProject#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#suspend_timeout_duration DataDatabricksPostgresProject#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresProjectInitialEndpointSpecToTerraform(struct?: DataDatabricksPostgresProjectInitialEndpointSpec): any;
export declare function dataDatabricksPostgresProjectInitialEndpointSpecToHclTerraform(struct?: DataDatabricksPostgresProjectInitialEndpointSpec): any;
export declare class DataDatabricksPostgresProjectInitialEndpointSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectInitialEndpointSpec | undefined;
    set internalValue(value: DataDatabricksPostgresProjectInitialEndpointSpec | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _group;
    get group(): DataDatabricksPostgresProjectInitialEndpointSpecGroupOutputReference;
    putGroup(value: DataDatabricksPostgresProjectInitialEndpointSpecGroup): void;
    resetGroup(): void;
    get groupInput(): cdktn.IResolvable | DataDatabricksPostgresProjectInitialEndpointSpecGroup | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#workspace_id DataDatabricksPostgresProject#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function dataDatabricksPostgresProjectProviderConfigToTerraform(struct?: DataDatabricksPostgresProjectProviderConfig | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectProviderConfigToHclTerraform(struct?: DataDatabricksPostgresProjectProviderConfig | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectSpecCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#key DataDatabricksPostgresProject#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#value DataDatabricksPostgresProject#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksPostgresProjectSpecCustomTagsToTerraform(struct?: DataDatabricksPostgresProjectSpecCustomTags | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectSpecCustomTagsToHclTerraform(struct?: DataDatabricksPostgresProjectSpecCustomTags | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectSpecCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresProjectSpecCustomTags | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectSpecCustomTags | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPostgresProjectSpecCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresProjectSpecCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresProjectSpecCustomTagsOutputReference;
}
export interface DataDatabricksPostgresProjectSpecDefaultEndpointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#autoscaling_limit_max_cu DataDatabricksPostgresProject#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#autoscaling_limit_min_cu DataDatabricksPostgresProject#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#no_suspension DataDatabricksPostgresProject#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#pg_settings DataDatabricksPostgresProject#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#suspend_timeout_duration DataDatabricksPostgresProject#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresProjectSpecDefaultEndpointSettingsToTerraform(struct?: DataDatabricksPostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable): any;
export declare function dataDatabricksPostgresProjectSpecDefaultEndpointSettingsToHclTerraform(struct?: DataDatabricksPostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable): any;
export declare class DataDatabricksPostgresProjectSpecDefaultEndpointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable | undefined;
    set internalValue(value: DataDatabricksPostgresProjectSpecDefaultEndpointSettings | cdktn.IResolvable | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectSpec {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#budget_policy_id DataDatabricksPostgresProject#budget_policy_id}
    */
    readonly budgetPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#custom_tags DataDatabricksPostgresProject#custom_tags}
    */
    readonly customTags?: DataDatabricksPostgresProjectSpecCustomTags[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#default_branch DataDatabricksPostgresProject#default_branch}
    */
    readonly defaultBranch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#default_endpoint_settings DataDatabricksPostgresProject#default_endpoint_settings}
    */
    readonly defaultEndpointSettings?: DataDatabricksPostgresProjectSpecDefaultEndpointSettings;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#display_name DataDatabricksPostgresProject#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#enable_pg_native_login DataDatabricksPostgresProject#enable_pg_native_login}
    */
    readonly enablePgNativeLogin?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#history_retention_duration DataDatabricksPostgresProject#history_retention_duration}
    */
    readonly historyRetentionDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#pg_version DataDatabricksPostgresProject#pg_version}
    */
    readonly pgVersion?: number;
}
export declare function dataDatabricksPostgresProjectSpecToTerraform(struct?: DataDatabricksPostgresProjectSpec): any;
export declare function dataDatabricksPostgresProjectSpecToHclTerraform(struct?: DataDatabricksPostgresProjectSpec): any;
export declare class DataDatabricksPostgresProjectSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectSpec | undefined;
    set internalValue(value: DataDatabricksPostgresProjectSpec | undefined);
    private _budgetPolicyId?;
    get budgetPolicyId(): string;
    set budgetPolicyId(value: string);
    resetBudgetPolicyId(): void;
    get budgetPolicyIdInput(): string | undefined;
    private _customTags;
    get customTags(): DataDatabricksPostgresProjectSpecCustomTagsList;
    putCustomTags(value: DataDatabricksPostgresProjectSpecCustomTags[] | cdktn.IResolvable): void;
    resetCustomTags(): void;
    get customTagsInput(): cdktn.IResolvable | DataDatabricksPostgresProjectSpecCustomTags[] | undefined;
    private _defaultBranch?;
    get defaultBranch(): string;
    set defaultBranch(value: string);
    resetDefaultBranch(): void;
    get defaultBranchInput(): string | undefined;
    private _defaultEndpointSettings;
    get defaultEndpointSettings(): DataDatabricksPostgresProjectSpecDefaultEndpointSettingsOutputReference;
    putDefaultEndpointSettings(value: DataDatabricksPostgresProjectSpecDefaultEndpointSettings): void;
    resetDefaultEndpointSettings(): void;
    get defaultEndpointSettingsInput(): cdktn.IResolvable | DataDatabricksPostgresProjectSpecDefaultEndpointSettings | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enablePgNativeLogin?;
    get enablePgNativeLogin(): boolean | cdktn.IResolvable;
    set enablePgNativeLogin(value: boolean | cdktn.IResolvable);
    resetEnablePgNativeLogin(): void;
    get enablePgNativeLoginInput(): boolean | cdktn.IResolvable | undefined;
    private _historyRetentionDuration?;
    get historyRetentionDuration(): string;
    set historyRetentionDuration(value: string);
    resetHistoryRetentionDuration(): void;
    get historyRetentionDurationInput(): string | undefined;
    private _pgVersion?;
    get pgVersion(): number;
    set pgVersion(value: number);
    resetPgVersion(): void;
    get pgVersionInput(): number | undefined;
}
export interface DataDatabricksPostgresProjectStatusCustomTags {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#key DataDatabricksPostgresProject#key}
    */
    readonly key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#value DataDatabricksPostgresProject#value}
    */
    readonly value?: string;
}
export declare function dataDatabricksPostgresProjectStatusCustomTagsToTerraform(struct?: DataDatabricksPostgresProjectStatusCustomTags): any;
export declare function dataDatabricksPostgresProjectStatusCustomTagsToHclTerraform(struct?: DataDatabricksPostgresProjectStatusCustomTags): any;
export declare class DataDatabricksPostgresProjectStatusCustomTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataDatabricksPostgresProjectStatusCustomTags | undefined;
    set internalValue(value: DataDatabricksPostgresProjectStatusCustomTags | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    resetKey(): void;
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class DataDatabricksPostgresProjectStatusCustomTagsList extends cdktn.ComplexList {
    internalValue?: DataDatabricksPostgresProjectStatusCustomTags[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataDatabricksPostgresProjectStatusCustomTagsOutputReference;
}
export interface DataDatabricksPostgresProjectStatusDefaultEndpointSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#autoscaling_limit_max_cu DataDatabricksPostgresProject#autoscaling_limit_max_cu}
    */
    readonly autoscalingLimitMaxCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#autoscaling_limit_min_cu DataDatabricksPostgresProject#autoscaling_limit_min_cu}
    */
    readonly autoscalingLimitMinCu?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#no_suspension DataDatabricksPostgresProject#no_suspension}
    */
    readonly noSuspension?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#pg_settings DataDatabricksPostgresProject#pg_settings}
    */
    readonly pgSettings?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#suspend_timeout_duration DataDatabricksPostgresProject#suspend_timeout_duration}
    */
    readonly suspendTimeoutDuration?: string;
}
export declare function dataDatabricksPostgresProjectStatusDefaultEndpointSettingsToTerraform(struct?: DataDatabricksPostgresProjectStatusDefaultEndpointSettings): any;
export declare function dataDatabricksPostgresProjectStatusDefaultEndpointSettingsToHclTerraform(struct?: DataDatabricksPostgresProjectStatusDefaultEndpointSettings): any;
export declare class DataDatabricksPostgresProjectStatusDefaultEndpointSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectStatusDefaultEndpointSettings | undefined;
    set internalValue(value: DataDatabricksPostgresProjectStatusDefaultEndpointSettings | undefined);
    private _autoscalingLimitMaxCu?;
    get autoscalingLimitMaxCu(): number;
    set autoscalingLimitMaxCu(value: number);
    resetAutoscalingLimitMaxCu(): void;
    get autoscalingLimitMaxCuInput(): number | undefined;
    private _autoscalingLimitMinCu?;
    get autoscalingLimitMinCu(): number;
    set autoscalingLimitMinCu(value: number);
    resetAutoscalingLimitMinCu(): void;
    get autoscalingLimitMinCuInput(): number | undefined;
    private _noSuspension?;
    get noSuspension(): boolean | cdktn.IResolvable;
    set noSuspension(value: boolean | cdktn.IResolvable);
    resetNoSuspension(): void;
    get noSuspensionInput(): boolean | cdktn.IResolvable | undefined;
    private _pgSettings?;
    get pgSettings(): {
        [key: string]: string;
    };
    set pgSettings(value: {
        [key: string]: string;
    });
    resetPgSettings(): void;
    get pgSettingsInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendTimeoutDuration?;
    get suspendTimeoutDuration(): string;
    set suspendTimeoutDuration(value: string);
    resetSuspendTimeoutDuration(): void;
    get suspendTimeoutDurationInput(): string | undefined;
}
export interface DataDatabricksPostgresProjectStatus {
}
export declare function dataDatabricksPostgresProjectStatusToTerraform(struct?: DataDatabricksPostgresProjectStatus): any;
export declare function dataDatabricksPostgresProjectStatusToHclTerraform(struct?: DataDatabricksPostgresProjectStatus): any;
export declare class DataDatabricksPostgresProjectStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataDatabricksPostgresProjectStatus | undefined;
    set internalValue(value: DataDatabricksPostgresProjectStatus | undefined);
    get branchLogicalSizeLimitBytes(): number;
    get budgetPolicyId(): string;
    get computeLastActiveTime(): string;
    private _customTags;
    get customTags(): DataDatabricksPostgresProjectStatusCustomTagsList;
    get defaultBranch(): string;
    private _defaultEndpointSettings;
    get defaultEndpointSettings(): DataDatabricksPostgresProjectStatusDefaultEndpointSettingsOutputReference;
    get displayName(): string;
    get enablePgNativeLogin(): cdktn.IResolvable;
    get historyRetentionDuration(): string;
    get owner(): string;
    get pgVersion(): number;
    get projectId(): string;
    get syntheticStorageSizeBytes(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project databricks_postgres_project}
*/
export declare class DataDatabricksPostgresProject extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "databricks_postgres_project";
    /**
    * Generates CDKTN code for importing a DataDatabricksPostgresProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataDatabricksPostgresProject to import
    * @param importFromId The id of the existing DataDatabricksPostgresProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataDatabricksPostgresProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/data-sources/postgres_project databricks_postgres_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataDatabricksPostgresProjectConfig
    */
    constructor(scope: Construct, id: string, config: DataDatabricksPostgresProjectConfig);
    get createTime(): string;
    get deleteTime(): string;
    private _initialBranchSpec;
    get initialBranchSpec(): DataDatabricksPostgresProjectInitialBranchSpecOutputReference;
    private _initialEndpointSpec;
    get initialEndpointSpec(): DataDatabricksPostgresProjectInitialEndpointSpecOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get projectId(): string;
    private _providerConfig;
    get providerConfig(): DataDatabricksPostgresProjectProviderConfigOutputReference;
    putProviderConfig(value: DataDatabricksPostgresProjectProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | DataDatabricksPostgresProjectProviderConfig | undefined;
    get purgeTime(): string;
    private _spec;
    get spec(): DataDatabricksPostgresProjectSpecOutputReference;
    private _status;
    get status(): DataDatabricksPostgresProjectStatusOutputReference;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
