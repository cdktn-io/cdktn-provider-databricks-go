/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import * as cdktn from 'cdktn';
import { JobTaskForEachTaskTaskAiRuntimeTask, JobTaskForEachTaskTaskAiRuntimeTaskOutputReference, JobTaskForEachTaskTaskAlertTask, JobTaskForEachTaskTaskAlertTaskOutputReference, JobTaskForEachTaskTaskCleanRoomsNotebookTask, JobTaskForEachTaskTaskCleanRoomsNotebookTaskOutputReference, JobTaskForEachTaskTaskCompute, JobTaskForEachTaskTaskComputeOutputReference, JobTaskForEachTaskTaskConditionTask, JobTaskForEachTaskTaskConditionTaskOutputReference, JobTaskForEachTaskTaskDashboardTask, JobTaskForEachTaskTaskDashboardTaskOutputReference, JobTaskForEachTaskTaskDbtCloudTask, JobTaskForEachTaskTaskDbtCloudTaskOutputReference, JobTaskForEachTaskTaskDbtPlatformTask, JobTaskForEachTaskTaskDbtPlatformTaskOutputReference, JobTaskForEachTaskTaskDbtTask, JobTaskForEachTaskTaskDbtTaskOutputReference, JobTaskForEachTaskTaskDependsOn, JobTaskForEachTaskTaskDependsOnList } from './structs0';
export interface JobTaskForEachTaskTaskEmailNotifications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: string[];
}
export declare function jobTaskForEachTaskTaskEmailNotificationsToTerraform(struct?: JobTaskForEachTaskTaskEmailNotificationsOutputReference | JobTaskForEachTaskTaskEmailNotifications): any;
export declare function jobTaskForEachTaskTaskEmailNotificationsToHclTerraform(struct?: JobTaskForEachTaskTaskEmailNotificationsOutputReference | JobTaskForEachTaskTaskEmailNotifications): any;
export declare class JobTaskForEachTaskTaskEmailNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskEmailNotifications | undefined;
    set internalValue(value: JobTaskForEachTaskTaskEmailNotifications | undefined);
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _onDurationWarningThresholdExceeded?;
    get onDurationWarningThresholdExceeded(): string[];
    set onDurationWarningThresholdExceeded(value: string[]);
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): string[] | undefined;
    private _onFailure?;
    get onFailure(): string[];
    set onFailure(value: string[]);
    resetOnFailure(): void;
    get onFailureInput(): string[] | undefined;
    private _onStart?;
    get onStart(): string[];
    set onStart(value: string[]);
    resetOnStart(): void;
    get onStartInput(): string[] | undefined;
    private _onStreamingBacklogExceeded?;
    get onStreamingBacklogExceeded(): string[];
    set onStreamingBacklogExceeded(value: string[]);
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): string[] | undefined;
    private _onSuccess?;
    get onSuccess(): string[];
    set onSuccess(value: string[]);
    resetOnSuccess(): void;
    get onSuccessInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskGenAiComputeTaskCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gpu_node_pool_id Job#gpu_node_pool_id}
    */
    readonly gpuNodePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gpu_type Job#gpu_type}
    */
    readonly gpuType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#num_gpus Job#num_gpus}
    */
    readonly numGpus: number;
}
export declare function jobTaskForEachTaskTaskGenAiComputeTaskComputeToTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference | JobTaskForEachTaskTaskGenAiComputeTaskCompute): any;
export declare function jobTaskForEachTaskTaskGenAiComputeTaskComputeToHclTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference | JobTaskForEachTaskTaskGenAiComputeTaskCompute): any;
export declare class JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskGenAiComputeTaskCompute | undefined;
    set internalValue(value: JobTaskForEachTaskTaskGenAiComputeTaskCompute | undefined);
    private _gpuNodePoolId?;
    get gpuNodePoolId(): string;
    set gpuNodePoolId(value: string);
    resetGpuNodePoolId(): void;
    get gpuNodePoolIdInput(): string | undefined;
    private _gpuType?;
    get gpuType(): string;
    set gpuType(value: string);
    resetGpuType(): void;
    get gpuTypeInput(): string | undefined;
    private _numGpus?;
    get numGpus(): number;
    set numGpus(value: number);
    get numGpusInput(): number | undefined;
}
export interface JobTaskForEachTaskTaskGenAiComputeTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#command Job#command}
    */
    readonly command?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dl_runtime_image Job#dl_runtime_image}
    */
    readonly dlRuntimeImage: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#mlflow_experiment_name Job#mlflow_experiment_name}
    */
    readonly mlflowExperimentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#training_script_path Job#training_script_path}
    */
    readonly trainingScriptPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#yaml_parameters Job#yaml_parameters}
    */
    readonly yamlParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#yaml_parameters_file_path Job#yaml_parameters_file_path}
    */
    readonly yamlParametersFilePath?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#compute Job#compute}
    */
    readonly compute?: JobTaskForEachTaskTaskGenAiComputeTaskCompute;
}
export declare function jobTaskForEachTaskTaskGenAiComputeTaskToTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskOutputReference | JobTaskForEachTaskTaskGenAiComputeTask): any;
export declare function jobTaskForEachTaskTaskGenAiComputeTaskToHclTerraform(struct?: JobTaskForEachTaskTaskGenAiComputeTaskOutputReference | JobTaskForEachTaskTaskGenAiComputeTask): any;
export declare class JobTaskForEachTaskTaskGenAiComputeTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskGenAiComputeTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskGenAiComputeTask | undefined);
    private _command?;
    get command(): string;
    set command(value: string);
    resetCommand(): void;
    get commandInput(): string | undefined;
    private _dlRuntimeImage?;
    get dlRuntimeImage(): string;
    set dlRuntimeImage(value: string);
    get dlRuntimeImageInput(): string | undefined;
    private _mlflowExperimentName?;
    get mlflowExperimentName(): string;
    set mlflowExperimentName(value: string);
    resetMlflowExperimentName(): void;
    get mlflowExperimentNameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _trainingScriptPath?;
    get trainingScriptPath(): string;
    set trainingScriptPath(value: string);
    resetTrainingScriptPath(): void;
    get trainingScriptPathInput(): string | undefined;
    private _yamlParameters?;
    get yamlParameters(): string;
    set yamlParameters(value: string);
    resetYamlParameters(): void;
    get yamlParametersInput(): string | undefined;
    private _yamlParametersFilePath?;
    get yamlParametersFilePath(): string;
    set yamlParametersFilePath(value: string);
    resetYamlParametersFilePath(): void;
    get yamlParametersFilePathInput(): string | undefined;
    private _compute;
    get compute(): JobTaskForEachTaskTaskGenAiComputeTaskComputeOutputReference;
    putCompute(value: JobTaskForEachTaskTaskGenAiComputeTaskCompute): void;
    resetCompute(): void;
    get computeInput(): JobTaskForEachTaskTaskGenAiComputeTaskCompute | undefined;
}
export interface JobTaskForEachTaskTaskHealthRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#metric Job#metric}
    */
    readonly metric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#op Job#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#value Job#value}
    */
    readonly value: number;
}
export declare function jobTaskForEachTaskTaskHealthRulesToTerraform(struct?: JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskHealthRulesToHclTerraform(struct?: JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskHealthRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskHealthRules | cdktn.IResolvable | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class JobTaskForEachTaskTaskHealthRulesList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskHealthRulesOutputReference;
}
export interface JobTaskForEachTaskTaskHealth {
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#rules Job#rules}
    */
    readonly rules: JobTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskHealthToTerraform(struct?: JobTaskForEachTaskTaskHealthOutputReference | JobTaskForEachTaskTaskHealth): any;
export declare function jobTaskForEachTaskTaskHealthToHclTerraform(struct?: JobTaskForEachTaskTaskHealthOutputReference | JobTaskForEachTaskTaskHealth): any;
export declare class JobTaskForEachTaskTaskHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskHealth | undefined;
    set internalValue(value: JobTaskForEachTaskTaskHealth | undefined);
    private _rules;
    get rules(): JobTaskForEachTaskTaskHealthRulesList;
    putRules(value: JobTaskForEachTaskTaskHealthRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | JobTaskForEachTaskTaskHealthRules[] | undefined;
}
export interface JobTaskForEachTaskTaskLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskLibraryCranToTerraform(struct?: JobTaskForEachTaskTaskLibraryCranOutputReference | JobTaskForEachTaskTaskLibraryCran): any;
export declare function jobTaskForEachTaskTaskLibraryCranToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryCranOutputReference | JobTaskForEachTaskTaskLibraryCran): any;
export declare class JobTaskForEachTaskTaskLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryCran | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskLibraryMavenToTerraform(struct?: JobTaskForEachTaskTaskLibraryMavenOutputReference | JobTaskForEachTaskTaskLibraryMaven): any;
export declare function jobTaskForEachTaskTaskLibraryMavenToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryMavenOutputReference | JobTaskForEachTaskTaskLibraryMaven): any;
export declare class JobTaskForEachTaskTaskLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryMaven | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskForEachTaskTaskLibraryProviderConfigToTerraform(struct?: JobTaskForEachTaskTaskLibraryProviderConfigOutputReference | JobTaskForEachTaskTaskLibraryProviderConfig): any;
export declare function jobTaskForEachTaskTaskLibraryProviderConfigToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryProviderConfigOutputReference | JobTaskForEachTaskTaskLibraryProviderConfig): any;
export declare class JobTaskForEachTaskTaskLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryProviderConfig | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskLibraryPypiToTerraform(struct?: JobTaskForEachTaskTaskLibraryPypiOutputReference | JobTaskForEachTaskTaskLibraryPypi): any;
export declare function jobTaskForEachTaskTaskLibraryPypiToHclTerraform(struct?: JobTaskForEachTaskTaskLibraryPypiOutputReference | JobTaskForEachTaskTaskLibraryPypi): any;
export declare class JobTaskForEachTaskTaskLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskLibraryPypi | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobTaskForEachTaskTaskLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobTaskForEachTaskTaskLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskForEachTaskTaskLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobTaskForEachTaskTaskLibraryPypi;
}
export declare function jobTaskForEachTaskTaskLibraryToTerraform(struct?: JobTaskForEachTaskTaskLibrary | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskLibraryToHclTerraform(struct?: JobTaskForEachTaskTaskLibrary | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobTaskForEachTaskTaskLibraryCranOutputReference;
    putCran(value: JobTaskForEachTaskTaskLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobTaskForEachTaskTaskLibraryCran | undefined;
    private _maven;
    get maven(): JobTaskForEachTaskTaskLibraryMavenOutputReference;
    putMaven(value: JobTaskForEachTaskTaskLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobTaskForEachTaskTaskLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskForEachTaskTaskLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobTaskForEachTaskTaskLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskForEachTaskTaskLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobTaskForEachTaskTaskLibraryPypiOutputReference;
    putPypi(value: JobTaskForEachTaskTaskLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobTaskForEachTaskTaskLibraryPypi | undefined;
}
export declare class JobTaskForEachTaskTaskLibraryList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskLibraryOutputReference;
}
export interface JobTaskForEachTaskTaskNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#max_workers Job#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#min_workers Job#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function jobTaskForEachTaskTaskNewClusterAutoscaleToTerraform(struct?: JobTaskForEachTaskTaskNewClusterAutoscaleOutputReference | JobTaskForEachTaskTaskNewClusterAutoscale): any;
export declare function jobTaskForEachTaskTaskNewClusterAutoscaleToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterAutoscaleOutputReference | JobTaskForEachTaskTaskNewClusterAutoscale): any;
export declare class JobTaskForEachTaskTaskNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterAutoscale | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_count Job#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_iops Job#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_size Job#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_throughput Job#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_type Job#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#instance_profile_arn Job#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spot_bid_price_percent Job#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterAwsAttributesToTerraform(struct?: JobTaskForEachTaskTaskNewClusterAwsAttributesOutputReference | JobTaskForEachTaskTaskNewClusterAwsAttributes): any;
export declare function jobTaskForEachTaskTaskNewClusterAwsAttributesToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterAwsAttributesOutputReference | JobTaskForEachTaskTaskNewClusterAwsAttributes): any;
export declare class JobTaskForEachTaskTaskNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterAwsAttributes | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#log_analytics_primary_key Job#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#log_analytics_workspace_id Job#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfoToTerraform(struct?: JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare function jobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare class JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#capacity_reservation_group Job#capacity_reservation_group}
    */
    readonly capacityReservationGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spot_bid_max_price Job#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#log_analytics_info Job#log_analytics_info}
    */
    readonly logAnalyticsInfo?: JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo;
}
export declare function jobTaskForEachTaskTaskNewClusterAzureAttributesToTerraform(struct?: JobTaskForEachTaskTaskNewClusterAzureAttributesOutputReference | JobTaskForEachTaskTaskNewClusterAzureAttributes): any;
export declare function jobTaskForEachTaskTaskNewClusterAzureAttributesToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterAzureAttributesOutputReference | JobTaskForEachTaskTaskNewClusterAzureAttributes): any;
export declare class JobTaskForEachTaskTaskNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterAzureAttributes | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _capacityReservationGroup?;
    get capacityReservationGroup(): string;
    set capacityReservationGroup(value: string);
    resetCapacityReservationGroup(): void;
    get capacityReservationGroupInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): JobTaskForEachTaskTaskNewClusterAzureAttributesLogAnalyticsInfo | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfDbfsToTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs): any;
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfDbfsToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs): any;
export declare class JobTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfS3ToTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConfS3): any;
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfS3ToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConfS3): any;
export declare class JobTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfVolumesToTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfVolumesOutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes): any;
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfVolumesToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfVolumesOutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes): any;
export declare class JobTaskForEachTaskTaskNewClusterClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobTaskForEachTaskTaskNewClusterClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes;
}
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfToTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfOutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConf): any;
export declare function jobTaskForEachTaskTaskNewClusterClusterLogConfToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterLogConfOutputReference | JobTaskForEachTaskTaskNewClusterClusterLogConf): any;
export declare class JobTaskForEachTaskTaskNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterClusterLogConf | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): JobTaskForEachTaskTaskNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobTaskForEachTaskTaskNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): JobTaskForEachTaskTaskNewClusterClusterLogConfS3OutputReference;
    putS3(value: JobTaskForEachTaskTaskNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): JobTaskForEachTaskTaskNewClusterClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): JobTaskForEachTaskTaskNewClusterClusterLogConfVolumesOutputReference;
    putVolumes(value: JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobTaskForEachTaskTaskNewClusterClusterLogConfVolumes | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#mount_options Job#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#server_address Job#server_address}
    */
    readonly serverAddress: string;
}
export declare function jobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function jobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#local_mount_dir_path Job#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#remote_mount_dir_path Job#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#network_filesystem_info Job#network_filesystem_info}
    */
    readonly networkFilesystemInfo: JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function jobTaskForEachTaskTaskNewClusterClusterMountInfoToTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskNewClusterClusterMountInfoToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): JobTaskForEachTaskTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class JobTaskForEachTaskTaskNewClusterClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskNewClusterClusterMountInfoOutputReference;
}
export interface JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#password Job#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#username Job#username}
    */
    readonly username: string;
}
export declare function jobTaskForEachTaskTaskNewClusterDockerImageBasicAuthToTerraform(struct?: JobTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference | JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth): any;
export declare function jobTaskForEachTaskTaskNewClusterDockerImageBasicAuthToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference | JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth): any;
export declare class JobTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#basic_auth Job#basic_auth}
    */
    readonly basicAuth?: JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth;
}
export declare function jobTaskForEachTaskTaskNewClusterDockerImageToTerraform(struct?: JobTaskForEachTaskTaskNewClusterDockerImageOutputReference | JobTaskForEachTaskTaskNewClusterDockerImage): any;
export declare function jobTaskForEachTaskTaskNewClusterDockerImageToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterDockerImageOutputReference | JobTaskForEachTaskTaskNewClusterDockerImage): any;
export declare class JobTaskForEachTaskTaskNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterDockerImage | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): JobTaskForEachTaskTaskNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): JobTaskForEachTaskTaskNewClusterDockerImageBasicAuth | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibilityToTerraform(struct?: JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibilityOutputReference | JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility): any;
export declare function jobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibilityToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibilityOutputReference | JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility): any;
export declare class JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#boot_disk_size Job#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#confidential_compute_type Job#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#google_service_account Job#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#local_ssd_count Job#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#use_preemptible_executors Job#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterGcpAttributesToTerraform(struct?: JobTaskForEachTaskTaskNewClusterGcpAttributesOutputReference | JobTaskForEachTaskTaskNewClusterGcpAttributes): any;
export declare function jobTaskForEachTaskTaskNewClusterGcpAttributesToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterGcpAttributesOutputReference | JobTaskForEachTaskTaskNewClusterGcpAttributes): any;
export declare class JobTaskForEachTaskTaskNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterGcpAttributes | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsAbfssToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsAbfss): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsAbfssToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsAbfss): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsDbfsToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsDbfs): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsDbfsToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsDbfs): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsFileToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsFile): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsFileToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsFile): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScriptsFile | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsGcsToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsGcs): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsGcsToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsGcs): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScriptsGcs | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsS3ToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsS3): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsS3ToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsS3): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScriptsS3 | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsVolumesToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsVolumes): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsVolumesToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsVolumes): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsWorkspaceToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsWorkspaceToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference | JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#abfss Job#abfss}
    */
    readonly abfss?: JobTaskForEachTaskTaskNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobTaskForEachTaskTaskNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobTaskForEachTaskTaskNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gcs Job#gcs}
    */
    readonly gcs?: JobTaskForEachTaskTaskNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobTaskForEachTaskTaskNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobTaskForEachTaskTaskNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace Job#workspace}
    */
    readonly workspace?: JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace;
}
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsToTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskNewClusterInitScriptsToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): JobTaskForEachTaskTaskNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: JobTaskForEachTaskTaskNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): JobTaskForEachTaskTaskNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): JobTaskForEachTaskTaskNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: JobTaskForEachTaskTaskNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobTaskForEachTaskTaskNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): JobTaskForEachTaskTaskNewClusterInitScriptsFileOutputReference;
    putFile(value: JobTaskForEachTaskTaskNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): JobTaskForEachTaskTaskNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): JobTaskForEachTaskTaskNewClusterInitScriptsGcsOutputReference;
    putGcs(value: JobTaskForEachTaskTaskNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): JobTaskForEachTaskTaskNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): JobTaskForEachTaskTaskNewClusterInitScriptsS3OutputReference;
    putS3(value: JobTaskForEachTaskTaskNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): JobTaskForEachTaskTaskNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): JobTaskForEachTaskTaskNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: JobTaskForEachTaskTaskNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobTaskForEachTaskTaskNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): JobTaskForEachTaskTaskNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): JobTaskForEachTaskTaskNewClusterInitScriptsWorkspace | undefined;
}
export declare class JobTaskForEachTaskTaskNewClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskNewClusterInitScriptsOutputReference;
}
export interface JobTaskForEachTaskTaskNewClusterLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterLibraryCranToTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryCranOutputReference | JobTaskForEachTaskTaskNewClusterLibraryCran): any;
export declare function jobTaskForEachTaskTaskNewClusterLibraryCranToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryCranOutputReference | JobTaskForEachTaskTaskNewClusterLibraryCran): any;
export declare class JobTaskForEachTaskTaskNewClusterLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterLibraryCran | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterLibraryMavenToTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryMavenOutputReference | JobTaskForEachTaskTaskNewClusterLibraryMaven): any;
export declare function jobTaskForEachTaskTaskNewClusterLibraryMavenToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryMavenOutputReference | JobTaskForEachTaskTaskNewClusterLibraryMaven): any;
export declare class JobTaskForEachTaskTaskNewClusterLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterLibraryMaven | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterLibraryProviderConfigToTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryProviderConfigOutputReference | JobTaskForEachTaskTaskNewClusterLibraryProviderConfig): any;
export declare function jobTaskForEachTaskTaskNewClusterLibraryProviderConfigToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryProviderConfigOutputReference | JobTaskForEachTaskTaskNewClusterLibraryProviderConfig): any;
export declare class JobTaskForEachTaskTaskNewClusterLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterLibraryProviderConfig | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterLibraryPypiToTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryPypiOutputReference | JobTaskForEachTaskTaskNewClusterLibraryPypi): any;
export declare function jobTaskForEachTaskTaskNewClusterLibraryPypiToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibraryPypiOutputReference | JobTaskForEachTaskTaskNewClusterLibraryPypi): any;
export declare class JobTaskForEachTaskTaskNewClusterLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterLibraryPypi | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobTaskForEachTaskTaskNewClusterLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobTaskForEachTaskTaskNewClusterLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskForEachTaskTaskNewClusterLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobTaskForEachTaskTaskNewClusterLibraryPypi;
}
export declare function jobTaskForEachTaskTaskNewClusterLibraryToTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibrary | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskNewClusterLibraryToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterLibrary | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskNewClusterLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskNewClusterLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobTaskForEachTaskTaskNewClusterLibraryCranOutputReference;
    putCran(value: JobTaskForEachTaskTaskNewClusterLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobTaskForEachTaskTaskNewClusterLibraryCran | undefined;
    private _maven;
    get maven(): JobTaskForEachTaskTaskNewClusterLibraryMavenOutputReference;
    putMaven(value: JobTaskForEachTaskTaskNewClusterLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobTaskForEachTaskTaskNewClusterLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskForEachTaskTaskNewClusterLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobTaskForEachTaskTaskNewClusterLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskForEachTaskTaskNewClusterLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobTaskForEachTaskTaskNewClusterLibraryPypiOutputReference;
    putPypi(value: JobTaskForEachTaskTaskNewClusterLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobTaskForEachTaskTaskNewClusterLibraryPypi | undefined;
}
export declare class JobTaskForEachTaskTaskNewClusterLibraryList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskNewClusterLibraryOutputReference;
}
export interface JobTaskForEachTaskTaskNewClusterProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskForEachTaskTaskNewClusterProviderConfigToTerraform(struct?: JobTaskForEachTaskTaskNewClusterProviderConfigOutputReference | JobTaskForEachTaskTaskNewClusterProviderConfig): any;
export declare function jobTaskForEachTaskTaskNewClusterProviderConfigToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterProviderConfigOutputReference | JobTaskForEachTaskTaskNewClusterProviderConfig): any;
export declare class JobTaskForEachTaskTaskNewClusterProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterProviderConfig | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibilityToTerraform(struct?: JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibilityOutputReference | JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility): any;
export declare function jobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibilityToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibilityOutputReference | JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility): any;
export declare class JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jobs Job#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notebooks Job#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskNewClusterWorkloadTypeClientsToTerraform(struct?: JobTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference | JobTaskForEachTaskTaskNewClusterWorkloadTypeClients): any;
export declare function jobTaskForEachTaskTaskNewClusterWorkloadTypeClientsToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference | JobTaskForEachTaskTaskNewClusterWorkloadTypeClients): any;
export declare class JobTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskForEachTaskTaskNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#clients Job#clients}
    */
    readonly clients: JobTaskForEachTaskTaskNewClusterWorkloadTypeClients;
}
export declare function jobTaskForEachTaskTaskNewClusterWorkloadTypeToTerraform(struct?: JobTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference | JobTaskForEachTaskTaskNewClusterWorkloadType): any;
export declare function jobTaskForEachTaskTaskNewClusterWorkloadTypeToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference | JobTaskForEachTaskTaskNewClusterWorkloadType): any;
export declare class JobTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewClusterWorkloadType | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): JobTaskForEachTaskTaskNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: JobTaskForEachTaskTaskNewClusterWorkloadTypeClients): void;
    get clientsInput(): JobTaskForEachTaskTaskNewClusterWorkloadTypeClients | undefined;
}
export interface JobTaskForEachTaskTaskNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#apply_policy_default_values Job#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_id Job#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_name Job#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#custom_tags Job#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#data_security_mode Job#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dependency_mode Job#dependency_mode}
    */
    readonly dependencyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#driver_instance_pool_id Job#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#driver_node_type_id Job#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_elastic_disk Job#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_local_disk_encryption Job#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#idempotency_token Job#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#instance_pool_id Job#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#is_single_node Job#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#kind Job#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#node_type_id Job#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#num_workers Job#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#policy_id Job#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#remote_disk_throughput Job#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#runtime_engine Job#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#single_user_name Job#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_conf Job#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_env_vars Job#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_version Job#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ssh_public_keys Job#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#total_initial_remote_disk_size Job#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#use_ml_runtime Job#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#autoscale Job#autoscale}
    */
    readonly autoscale?: JobTaskForEachTaskTaskNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#aws_attributes Job#aws_attributes}
    */
    readonly awsAttributes?: JobTaskForEachTaskTaskNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#azure_attributes Job#azure_attributes}
    */
    readonly azureAttributes?: JobTaskForEachTaskTaskNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_log_conf Job#cluster_log_conf}
    */
    readonly clusterLogConf?: JobTaskForEachTaskTaskNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_mount_info Job#cluster_mount_info}
    */
    readonly clusterMountInfo?: JobTaskForEachTaskTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#docker_image Job#docker_image}
    */
    readonly dockerImage?: JobTaskForEachTaskTaskNewClusterDockerImage;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#driver_node_type_flexibility Job#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gcp_attributes Job#gcp_attributes}
    */
    readonly gcpAttributes?: JobTaskForEachTaskTaskNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#init_scripts Job#init_scripts}
    */
    readonly initScripts?: JobTaskForEachTaskTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobTaskForEachTaskTaskNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskForEachTaskTaskNewClusterProviderConfig;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#worker_node_type_flexibility Job#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workload_type Job#workload_type}
    */
    readonly workloadType?: JobTaskForEachTaskTaskNewClusterWorkloadType;
}
export declare function jobTaskForEachTaskTaskNewClusterToTerraform(struct?: JobTaskForEachTaskTaskNewClusterOutputReference | JobTaskForEachTaskTaskNewCluster): any;
export declare function jobTaskForEachTaskTaskNewClusterToHclTerraform(struct?: JobTaskForEachTaskTaskNewClusterOutputReference | JobTaskForEachTaskTaskNewCluster): any;
export declare class JobTaskForEachTaskTaskNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNewCluster | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNewCluster | undefined);
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _dependencyMode?;
    get dependencyMode(): string;
    set dependencyMode(value: string);
    resetDependencyMode(): void;
    get dependencyModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): JobTaskForEachTaskTaskNewClusterAutoscaleOutputReference;
    putAutoscale(value: JobTaskForEachTaskTaskNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): JobTaskForEachTaskTaskNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): JobTaskForEachTaskTaskNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: JobTaskForEachTaskTaskNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): JobTaskForEachTaskTaskNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): JobTaskForEachTaskTaskNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: JobTaskForEachTaskTaskNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): JobTaskForEachTaskTaskNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): JobTaskForEachTaskTaskNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: JobTaskForEachTaskTaskNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): JobTaskForEachTaskTaskNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): JobTaskForEachTaskTaskNewClusterClusterMountInfoList;
    putClusterMountInfo(value: JobTaskForEachTaskTaskNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | JobTaskForEachTaskTaskNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): JobTaskForEachTaskTaskNewClusterDockerImageOutputReference;
    putDockerImage(value: JobTaskForEachTaskTaskNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): JobTaskForEachTaskTaskNewClusterDockerImage | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): JobTaskForEachTaskTaskNewClusterDriverNodeTypeFlexibility | undefined;
    private _gcpAttributes;
    get gcpAttributes(): JobTaskForEachTaskTaskNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: JobTaskForEachTaskTaskNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): JobTaskForEachTaskTaskNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): JobTaskForEachTaskTaskNewClusterInitScriptsList;
    putInitScripts(value: JobTaskForEachTaskTaskNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | JobTaskForEachTaskTaskNewClusterInitScripts[] | undefined;
    private _library;
    get library(): JobTaskForEachTaskTaskNewClusterLibraryList;
    putLibrary(value: JobTaskForEachTaskTaskNewClusterLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobTaskForEachTaskTaskNewClusterLibrary[] | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskForEachTaskTaskNewClusterProviderConfigOutputReference;
    putProviderConfig(value: JobTaskForEachTaskTaskNewClusterProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskForEachTaskTaskNewClusterProviderConfig | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): JobTaskForEachTaskTaskNewClusterWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): JobTaskForEachTaskTaskNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: JobTaskForEachTaskTaskNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): JobTaskForEachTaskTaskNewClusterWorkloadType | undefined;
}
export interface JobTaskForEachTaskTaskNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#base_parameters Job#base_parameters}
    */
    readonly baseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notebook_path Job#notebook_path}
    */
    readonly notebookPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function jobTaskForEachTaskTaskNotebookTaskToTerraform(struct?: JobTaskForEachTaskTaskNotebookTaskOutputReference | JobTaskForEachTaskTaskNotebookTask): any;
export declare function jobTaskForEachTaskTaskNotebookTaskToHclTerraform(struct?: JobTaskForEachTaskTaskNotebookTaskOutputReference | JobTaskForEachTaskTaskNotebookTask): any;
export declare class JobTaskForEachTaskTaskNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNotebookTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNotebookTask | undefined);
    private _baseParameters?;
    get baseParameters(): {
        [key: string]: string;
    };
    set baseParameters(value: {
        [key: string]: string;
    });
    resetBaseParameters(): void;
    get baseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    get notebookPathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alert_on_last_attempt Job#alert_on_last_attempt}
    */
    readonly alertOnLastAttempt?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#no_alert_for_canceled_runs Job#no_alert_for_canceled_runs}
    */
    readonly noAlertForCanceledRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskNotificationSettingsToTerraform(struct?: JobTaskForEachTaskTaskNotificationSettingsOutputReference | JobTaskForEachTaskTaskNotificationSettings): any;
export declare function jobTaskForEachTaskTaskNotificationSettingsToHclTerraform(struct?: JobTaskForEachTaskTaskNotificationSettingsOutputReference | JobTaskForEachTaskTaskNotificationSettings): any;
export declare class JobTaskForEachTaskTaskNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskNotificationSettings | undefined;
    set internalValue(value: JobTaskForEachTaskTaskNotificationSettings | undefined);
    private _alertOnLastAttempt?;
    get alertOnLastAttempt(): boolean | cdktn.IResolvable;
    set alertOnLastAttempt(value: boolean | cdktn.IResolvable);
    resetAlertOnLastAttempt(): void;
    get alertOnLastAttemptInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForCanceledRuns?;
    get noAlertForCanceledRuns(): boolean | cdktn.IResolvable;
    set noAlertForCanceledRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForCanceledRuns(): void;
    get noAlertForCanceledRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskForEachTaskTaskPipelineTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh Job#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh_selection Job#full_refresh_selection}
    */
    readonly fullRefreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pipeline_id Job#pipeline_id}
    */
    readonly pipelineId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_flow_selection Job#refresh_flow_selection}
    */
    readonly refreshFlowSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_selection Job#refresh_selection}
    */
    readonly refreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#reset_checkpoint_selection Job#reset_checkpoint_selection}
    */
    readonly resetCheckpointSelection?: string[];
}
export declare function jobTaskForEachTaskTaskPipelineTaskToTerraform(struct?: JobTaskForEachTaskTaskPipelineTaskOutputReference | JobTaskForEachTaskTaskPipelineTask): any;
export declare function jobTaskForEachTaskTaskPipelineTaskToHclTerraform(struct?: JobTaskForEachTaskTaskPipelineTaskOutputReference | JobTaskForEachTaskTaskPipelineTask): any;
export declare class JobTaskForEachTaskTaskPipelineTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskPipelineTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskPipelineTask | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _fullRefreshSelection?;
    get fullRefreshSelection(): string[];
    set fullRefreshSelection(value: string[]);
    resetFullRefreshSelection(): void;
    get fullRefreshSelectionInput(): string[] | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
    private _refreshFlowSelection?;
    get refreshFlowSelection(): string[];
    set refreshFlowSelection(value: string[]);
    resetRefreshFlowSelection(): void;
    get refreshFlowSelectionInput(): string[] | undefined;
    private _refreshSelection?;
    get refreshSelection(): string[];
    set refreshSelection(value: string[]);
    resetRefreshSelection(): void;
    get refreshSelectionInput(): string[] | undefined;
    private _resetCheckpointSelection?;
    get resetCheckpointSelection(): string[];
    set resetCheckpointSelection(value: string[]);
    resetResetCheckpointSelection(): void;
    get resetCheckpointSelectionInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskPowerBiTaskPowerBiModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#authentication_method Job#authentication_method}
    */
    readonly authenticationMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#model_name Job#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#overwrite_existing Job#overwrite_existing}
    */
    readonly overwriteExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#storage_mode Job#storage_mode}
    */
    readonly storageMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_name Job#workspace_name}
    */
    readonly workspaceName?: string;
}
export declare function jobTaskForEachTaskTaskPowerBiTaskPowerBiModelToTerraform(struct?: JobTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference | JobTaskForEachTaskTaskPowerBiTaskPowerBiModel): any;
export declare function jobTaskForEachTaskTaskPowerBiTaskPowerBiModelToHclTerraform(struct?: JobTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference | JobTaskForEachTaskTaskPowerBiTaskPowerBiModel): any;
export declare class JobTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskPowerBiTaskPowerBiModel | undefined;
    set internalValue(value: JobTaskForEachTaskTaskPowerBiTaskPowerBiModel | undefined);
    private _authenticationMethod?;
    get authenticationMethod(): string;
    set authenticationMethod(value: string);
    resetAuthenticationMethod(): void;
    get authenticationMethodInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _overwriteExisting?;
    get overwriteExisting(): boolean | cdktn.IResolvable;
    set overwriteExisting(value: boolean | cdktn.IResolvable);
    resetOverwriteExisting(): void;
    get overwriteExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
    private _workspaceName?;
    get workspaceName(): string;
    set workspaceName(value: string);
    resetWorkspaceName(): void;
    get workspaceNameInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskPowerBiTaskTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#catalog Job#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#name Job#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#schema Job#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#storage_mode Job#storage_mode}
    */
    readonly storageMode?: string;
}
export declare function jobTaskForEachTaskTaskPowerBiTaskTablesToTerraform(struct?: JobTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskPowerBiTaskTablesToHclTerraform(struct?: JobTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskPowerBiTaskTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskPowerBiTaskTables | cdktn.IResolvable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskPowerBiTaskTablesList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskPowerBiTaskTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskPowerBiTaskTablesOutputReference;
}
export interface JobTaskForEachTaskTaskPowerBiTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#connection_resource_name Job#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_after_update Job#refresh_after_update}
    */
    readonly refreshAfterUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * power_bi_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#power_bi_model Job#power_bi_model}
    */
    readonly powerBiModel?: JobTaskForEachTaskTaskPowerBiTaskPowerBiModel;
    /**
    * tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#tables Job#tables}
    */
    readonly tables?: JobTaskForEachTaskTaskPowerBiTaskTables[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskPowerBiTaskToTerraform(struct?: JobTaskForEachTaskTaskPowerBiTaskOutputReference | JobTaskForEachTaskTaskPowerBiTask): any;
export declare function jobTaskForEachTaskTaskPowerBiTaskToHclTerraform(struct?: JobTaskForEachTaskTaskPowerBiTaskOutputReference | JobTaskForEachTaskTaskPowerBiTask): any;
export declare class JobTaskForEachTaskTaskPowerBiTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskPowerBiTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskPowerBiTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _refreshAfterUpdate?;
    get refreshAfterUpdate(): boolean | cdktn.IResolvable;
    set refreshAfterUpdate(value: boolean | cdktn.IResolvable);
    resetRefreshAfterUpdate(): void;
    get refreshAfterUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _powerBiModel;
    get powerBiModel(): JobTaskForEachTaskTaskPowerBiTaskPowerBiModelOutputReference;
    putPowerBiModel(value: JobTaskForEachTaskTaskPowerBiTaskPowerBiModel): void;
    resetPowerBiModel(): void;
    get powerBiModelInput(): JobTaskForEachTaskTaskPowerBiTaskPowerBiModel | undefined;
    private _tables;
    get tables(): JobTaskForEachTaskTaskPowerBiTaskTablesList;
    putTables(value: JobTaskForEachTaskTaskPowerBiTaskTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | JobTaskForEachTaskTaskPowerBiTaskTables[] | undefined;
}
export interface JobTaskForEachTaskTaskPythonOperatorTaskParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#name Job#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#value Job#value}
    */
    readonly value?: string;
}
export declare function jobTaskForEachTaskTaskPythonOperatorTaskParametersToTerraform(struct?: JobTaskForEachTaskTaskPythonOperatorTaskParameters | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskPythonOperatorTaskParametersToHclTerraform(struct?: JobTaskForEachTaskTaskPythonOperatorTaskParameters | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskPythonOperatorTaskParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskPythonOperatorTaskParameters | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskPythonOperatorTaskParameters | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskPythonOperatorTaskParametersList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskPythonOperatorTaskParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskPythonOperatorTaskParametersOutputReference;
}
export interface JobTaskForEachTaskTaskPythonOperatorTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#main Job#main}
    */
    readonly main?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: JobTaskForEachTaskTaskPythonOperatorTaskParameters[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskPythonOperatorTaskToTerraform(struct?: JobTaskForEachTaskTaskPythonOperatorTaskOutputReference | JobTaskForEachTaskTaskPythonOperatorTask): any;
export declare function jobTaskForEachTaskTaskPythonOperatorTaskToHclTerraform(struct?: JobTaskForEachTaskTaskPythonOperatorTaskOutputReference | JobTaskForEachTaskTaskPythonOperatorTask): any;
export declare class JobTaskForEachTaskTaskPythonOperatorTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskPythonOperatorTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskPythonOperatorTask | undefined);
    private _main?;
    get main(): string;
    set main(value: string);
    resetMain(): void;
    get mainInput(): string | undefined;
    private _parameters;
    get parameters(): JobTaskForEachTaskTaskPythonOperatorTaskParametersList;
    putParameters(value: JobTaskForEachTaskTaskPythonOperatorTaskParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | JobTaskForEachTaskTaskPythonOperatorTaskParameters[] | undefined;
}
export interface JobTaskForEachTaskTaskPythonWheelTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#entry_point Job#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#named_parameters Job#named_parameters}
    */
    readonly namedParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package_name Job#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobTaskForEachTaskTaskPythonWheelTaskToTerraform(struct?: JobTaskForEachTaskTaskPythonWheelTaskOutputReference | JobTaskForEachTaskTaskPythonWheelTask): any;
export declare function jobTaskForEachTaskTaskPythonWheelTaskToHclTerraform(struct?: JobTaskForEachTaskTaskPythonWheelTaskOutputReference | JobTaskForEachTaskTaskPythonWheelTask): any;
export declare class JobTaskForEachTaskTaskPythonWheelTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskPythonWheelTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskPythonWheelTask | undefined);
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _namedParameters?;
    get namedParameters(): {
        [key: string]: string;
    };
    set namedParameters(value: {
        [key: string]: string;
    });
    resetNamedParameters(): void;
    get namedParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskRunJobTaskPipelineParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh Job#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh_selection Job#full_refresh_selection}
    */
    readonly fullRefreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_flow_selection Job#refresh_flow_selection}
    */
    readonly refreshFlowSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_selection Job#refresh_selection}
    */
    readonly refreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#reset_checkpoint_selection Job#reset_checkpoint_selection}
    */
    readonly resetCheckpointSelection?: string[];
}
export declare function jobTaskForEachTaskTaskRunJobTaskPipelineParamsToTerraform(struct?: JobTaskForEachTaskTaskRunJobTaskPipelineParamsOutputReference | JobTaskForEachTaskTaskRunJobTaskPipelineParams): any;
export declare function jobTaskForEachTaskTaskRunJobTaskPipelineParamsToHclTerraform(struct?: JobTaskForEachTaskTaskRunJobTaskPipelineParamsOutputReference | JobTaskForEachTaskTaskRunJobTaskPipelineParams): any;
export declare class JobTaskForEachTaskTaskRunJobTaskPipelineParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskRunJobTaskPipelineParams | undefined;
    set internalValue(value: JobTaskForEachTaskTaskRunJobTaskPipelineParams | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _fullRefreshSelection?;
    get fullRefreshSelection(): string[];
    set fullRefreshSelection(value: string[]);
    resetFullRefreshSelection(): void;
    get fullRefreshSelectionInput(): string[] | undefined;
    private _refreshFlowSelection?;
    get refreshFlowSelection(): string[];
    set refreshFlowSelection(value: string[]);
    resetRefreshFlowSelection(): void;
    get refreshFlowSelectionInput(): string[] | undefined;
    private _refreshSelection?;
    get refreshSelection(): string[];
    set refreshSelection(value: string[]);
    resetRefreshSelection(): void;
    get refreshSelectionInput(): string[] | undefined;
    private _resetCheckpointSelection?;
    get resetCheckpointSelection(): string[];
    set resetCheckpointSelection(value: string[]);
    resetResetCheckpointSelection(): void;
    get resetCheckpointSelectionInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskRunJobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbt_commands Job#dbt_commands}
    */
    readonly dbtCommands?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar_params Job#jar_params}
    */
    readonly jarParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#job_id Job#job_id}
    */
    readonly jobId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#job_parameters Job#job_parameters}
    */
    readonly jobParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notebook_params Job#notebook_params}
    */
    readonly notebookParams?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_named_params Job#python_named_params}
    */
    readonly pythonNamedParams?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_params Job#python_params}
    */
    readonly pythonParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_submit_params Job#spark_submit_params}
    */
    readonly sparkSubmitParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#sql_params Job#sql_params}
    */
    readonly sqlParams?: {
        [key: string]: string;
    };
    /**
    * pipeline_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pipeline_params Job#pipeline_params}
    */
    readonly pipelineParams?: JobTaskForEachTaskTaskRunJobTaskPipelineParams;
}
export declare function jobTaskForEachTaskTaskRunJobTaskToTerraform(struct?: JobTaskForEachTaskTaskRunJobTaskOutputReference | JobTaskForEachTaskTaskRunJobTask): any;
export declare function jobTaskForEachTaskTaskRunJobTaskToHclTerraform(struct?: JobTaskForEachTaskTaskRunJobTaskOutputReference | JobTaskForEachTaskTaskRunJobTask): any;
export declare class JobTaskForEachTaskTaskRunJobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskRunJobTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskRunJobTask | undefined);
    private _dbtCommands?;
    get dbtCommands(): string[];
    set dbtCommands(value: string[]);
    resetDbtCommands(): void;
    get dbtCommandsInput(): string[] | undefined;
    private _jarParams?;
    get jarParams(): string[];
    set jarParams(value: string[]);
    resetJarParams(): void;
    get jarParamsInput(): string[] | undefined;
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    private _jobParameters?;
    get jobParameters(): {
        [key: string]: string;
    };
    set jobParameters(value: {
        [key: string]: string;
    });
    resetJobParameters(): void;
    get jobParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookParams?;
    get notebookParams(): {
        [key: string]: string;
    };
    set notebookParams(value: {
        [key: string]: string;
    });
    resetNotebookParams(): void;
    get notebookParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pythonNamedParams?;
    get pythonNamedParams(): {
        [key: string]: string;
    };
    set pythonNamedParams(value: {
        [key: string]: string;
    });
    resetPythonNamedParams(): void;
    get pythonNamedParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pythonParams?;
    get pythonParams(): string[];
    set pythonParams(value: string[]);
    resetPythonParams(): void;
    get pythonParamsInput(): string[] | undefined;
    private _sparkSubmitParams?;
    get sparkSubmitParams(): string[];
    set sparkSubmitParams(value: string[]);
    resetSparkSubmitParams(): void;
    get sparkSubmitParamsInput(): string[] | undefined;
    private _sqlParams?;
    get sqlParams(): {
        [key: string]: string;
    };
    set sqlParams(value: {
        [key: string]: string;
    });
    resetSqlParams(): void;
    get sqlParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pipelineParams;
    get pipelineParams(): JobTaskForEachTaskTaskRunJobTaskPipelineParamsOutputReference;
    putPipelineParams(value: JobTaskForEachTaskTaskRunJobTaskPipelineParams): void;
    resetPipelineParams(): void;
    get pipelineParamsInput(): JobTaskForEachTaskTaskRunJobTaskPipelineParams | undefined;
}
export interface JobTaskForEachTaskTaskSparkJarTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar_uri Job#jar_uri}
    */
    readonly jarUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#main_class_name Job#main_class_name}
    */
    readonly mainClassName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#run_as_repl Job#run_as_repl}
    */
    readonly runAsRepl?: boolean | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskSparkJarTaskToTerraform(struct?: JobTaskForEachTaskTaskSparkJarTaskOutputReference | JobTaskForEachTaskTaskSparkJarTask): any;
export declare function jobTaskForEachTaskTaskSparkJarTaskToHclTerraform(struct?: JobTaskForEachTaskTaskSparkJarTaskOutputReference | JobTaskForEachTaskTaskSparkJarTask): any;
export declare class JobTaskForEachTaskTaskSparkJarTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSparkJarTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSparkJarTask | undefined);
    private _jarUri?;
    get jarUri(): string;
    set jarUri(value: string);
    resetJarUri(): void;
    get jarUriInput(): string | undefined;
    private _mainClassName?;
    get mainClassName(): string;
    set mainClassName(value: string);
    resetMainClassName(): void;
    get mainClassNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _runAsRepl?;
    get runAsRepl(): boolean | cdktn.IResolvable;
    set runAsRepl(value: boolean | cdktn.IResolvable);
    resetRunAsRepl(): void;
    get runAsReplInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskForEachTaskTaskSparkPythonTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_file Job#python_file}
    */
    readonly pythonFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
}
export declare function jobTaskForEachTaskTaskSparkPythonTaskToTerraform(struct?: JobTaskForEachTaskTaskSparkPythonTaskOutputReference | JobTaskForEachTaskTaskSparkPythonTask): any;
export declare function jobTaskForEachTaskTaskSparkPythonTaskToHclTerraform(struct?: JobTaskForEachTaskTaskSparkPythonTaskOutputReference | JobTaskForEachTaskTaskSparkPythonTask): any;
export declare class JobTaskForEachTaskTaskSparkPythonTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSparkPythonTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSparkPythonTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pythonFile?;
    get pythonFile(): string;
    set pythonFile(value: string);
    get pythonFileInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskSparkSubmitTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobTaskForEachTaskTaskSparkSubmitTaskToTerraform(struct?: JobTaskForEachTaskTaskSparkSubmitTaskOutputReference | JobTaskForEachTaskTaskSparkSubmitTask): any;
export declare function jobTaskForEachTaskTaskSparkSubmitTaskToHclTerraform(struct?: JobTaskForEachTaskTaskSparkSubmitTaskOutputReference | JobTaskForEachTaskTaskSparkSubmitTask): any;
export declare class JobTaskForEachTaskTaskSparkSubmitTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSparkSubmitTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSparkSubmitTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobTaskForEachTaskTaskSqlTaskAlertSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskForEachTaskTaskSqlTaskAlertSubscriptionsToTerraform(struct?: JobTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskSqlTaskAlertSubscriptionsToHclTerraform(struct?: JobTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskSqlTaskAlertSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSqlTaskAlertSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskSqlTaskAlertSubscriptionsList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskSqlTaskAlertSubscriptionsOutputReference;
}
export interface JobTaskForEachTaskTaskSqlTaskAlert {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alert_id Job#alert_id}
    */
    readonly alertId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pause_subscriptions Job#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#subscriptions Job#subscriptions}
    */
    readonly subscriptions?: JobTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskSqlTaskAlertToTerraform(struct?: JobTaskForEachTaskTaskSqlTaskAlertOutputReference | JobTaskForEachTaskTaskSqlTaskAlert): any;
export declare function jobTaskForEachTaskTaskSqlTaskAlertToHclTerraform(struct?: JobTaskForEachTaskTaskSqlTaskAlertOutputReference | JobTaskForEachTaskTaskSqlTaskAlert): any;
export declare class JobTaskForEachTaskTaskSqlTaskAlertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSqlTaskAlert | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSqlTaskAlert | undefined);
    private _alertId?;
    get alertId(): string;
    set alertId(value: string);
    get alertIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): JobTaskForEachTaskTaskSqlTaskAlertSubscriptionsList;
    putSubscriptions(value: JobTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | JobTaskForEachTaskTaskSqlTaskAlertSubscriptions[] | undefined;
}
export interface JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination_id Job#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#user_name Job#user_name}
    */
    readonly userName?: string;
}
export declare function jobTaskForEachTaskTaskSqlTaskDashboardSubscriptionsToTerraform(struct?: JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskSqlTaskDashboardSubscriptionsToHclTerraform(struct?: JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskSqlTaskDashboardSubscriptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions | cdktn.IResolvable | undefined);
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskSqlTaskDashboardSubscriptionsList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskSqlTaskDashboardSubscriptionsOutputReference;
}
export interface JobTaskForEachTaskTaskSqlTaskDashboard {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#custom_subject Job#custom_subject}
    */
    readonly customSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dashboard_id Job#dashboard_id}
    */
    readonly dashboardId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pause_subscriptions Job#pause_subscriptions}
    */
    readonly pauseSubscriptions?: boolean | cdktn.IResolvable;
    /**
    * subscriptions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#subscriptions Job#subscriptions}
    */
    readonly subscriptions?: JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskSqlTaskDashboardToTerraform(struct?: JobTaskForEachTaskTaskSqlTaskDashboardOutputReference | JobTaskForEachTaskTaskSqlTaskDashboard): any;
export declare function jobTaskForEachTaskTaskSqlTaskDashboardToHclTerraform(struct?: JobTaskForEachTaskTaskSqlTaskDashboardOutputReference | JobTaskForEachTaskTaskSqlTaskDashboard): any;
export declare class JobTaskForEachTaskTaskSqlTaskDashboardOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSqlTaskDashboard | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSqlTaskDashboard | undefined);
    private _customSubject?;
    get customSubject(): string;
    set customSubject(value: string);
    resetCustomSubject(): void;
    get customSubjectInput(): string | undefined;
    private _dashboardId?;
    get dashboardId(): string;
    set dashboardId(value: string);
    get dashboardIdInput(): string | undefined;
    private _pauseSubscriptions?;
    get pauseSubscriptions(): boolean | cdktn.IResolvable;
    set pauseSubscriptions(value: boolean | cdktn.IResolvable);
    resetPauseSubscriptions(): void;
    get pauseSubscriptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _subscriptions;
    get subscriptions(): JobTaskForEachTaskTaskSqlTaskDashboardSubscriptionsList;
    putSubscriptions(value: JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | cdktn.IResolvable): void;
    resetSubscriptions(): void;
    get subscriptionsInput(): cdktn.IResolvable | JobTaskForEachTaskTaskSqlTaskDashboardSubscriptions[] | undefined;
}
export interface JobTaskForEachTaskTaskSqlTaskFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#path Job#path}
    */
    readonly path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
}
export declare function jobTaskForEachTaskTaskSqlTaskFileToTerraform(struct?: JobTaskForEachTaskTaskSqlTaskFileOutputReference | JobTaskForEachTaskTaskSqlTaskFile): any;
export declare function jobTaskForEachTaskTaskSqlTaskFileToHclTerraform(struct?: JobTaskForEachTaskTaskSqlTaskFileOutputReference | JobTaskForEachTaskTaskSqlTaskFile): any;
export declare class JobTaskForEachTaskTaskSqlTaskFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSqlTaskFile | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSqlTaskFile | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskSqlTaskQuery {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#query_id Job#query_id}
    */
    readonly queryId: string;
}
export declare function jobTaskForEachTaskTaskSqlTaskQueryToTerraform(struct?: JobTaskForEachTaskTaskSqlTaskQueryOutputReference | JobTaskForEachTaskTaskSqlTaskQuery): any;
export declare function jobTaskForEachTaskTaskSqlTaskQueryToHclTerraform(struct?: JobTaskForEachTaskTaskSqlTaskQueryOutputReference | JobTaskForEachTaskTaskSqlTaskQuery): any;
export declare class JobTaskForEachTaskTaskSqlTaskQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSqlTaskQuery | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSqlTaskQuery | undefined);
    private _queryId?;
    get queryId(): string;
    set queryId(value: string);
    get queryIdInput(): string | undefined;
}
export interface JobTaskForEachTaskTaskSqlTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId: string;
    /**
    * alert block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alert Job#alert}
    */
    readonly alert?: JobTaskForEachTaskTaskSqlTaskAlert;
    /**
    * dashboard block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dashboard Job#dashboard}
    */
    readonly dashboard?: JobTaskForEachTaskTaskSqlTaskDashboard;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobTaskForEachTaskTaskSqlTaskFile;
    /**
    * query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#query Job#query}
    */
    readonly query?: JobTaskForEachTaskTaskSqlTaskQuery;
}
export declare function jobTaskForEachTaskTaskSqlTaskToTerraform(struct?: JobTaskForEachTaskTaskSqlTaskOutputReference | JobTaskForEachTaskTaskSqlTask): any;
export declare function jobTaskForEachTaskTaskSqlTaskToHclTerraform(struct?: JobTaskForEachTaskTaskSqlTaskOutputReference | JobTaskForEachTaskTaskSqlTask): any;
export declare class JobTaskForEachTaskTaskSqlTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskSqlTask | undefined;
    set internalValue(value: JobTaskForEachTaskTaskSqlTask | undefined);
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    get warehouseIdInput(): string | undefined;
    private _alert;
    get alert(): JobTaskForEachTaskTaskSqlTaskAlertOutputReference;
    putAlert(value: JobTaskForEachTaskTaskSqlTaskAlert): void;
    resetAlert(): void;
    get alertInput(): JobTaskForEachTaskTaskSqlTaskAlert | undefined;
    private _dashboard;
    get dashboard(): JobTaskForEachTaskTaskSqlTaskDashboardOutputReference;
    putDashboard(value: JobTaskForEachTaskTaskSqlTaskDashboard): void;
    resetDashboard(): void;
    get dashboardInput(): JobTaskForEachTaskTaskSqlTaskDashboard | undefined;
    private _file;
    get file(): JobTaskForEachTaskTaskSqlTaskFileOutputReference;
    putFile(value: JobTaskForEachTaskTaskSqlTaskFile): void;
    resetFile(): void;
    get fileInput(): JobTaskForEachTaskTaskSqlTaskFile | undefined;
    private _query;
    get query(): JobTaskForEachTaskTaskSqlTaskQueryOutputReference;
    putQuery(value: JobTaskForEachTaskTaskSqlTaskQuery): void;
    resetQuery(): void;
    get queryInput(): JobTaskForEachTaskTaskSqlTaskQuery | undefined;
}
export interface JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededToTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededToHclTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededOutputReference;
}
export interface JobTaskForEachTaskTaskWebhookNotificationsOnFailure {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnFailureToTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnFailureToHclTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnFailureOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskWebhookNotificationsOnFailure | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnFailureList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskWebhookNotificationsOnFailureOutputReference;
}
export interface JobTaskForEachTaskTaskWebhookNotificationsOnStart {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnStartToTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnStartToHclTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnStartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskWebhookNotificationsOnStart | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnStartList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskWebhookNotificationsOnStartOutputReference;
}
export interface JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededToTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededToHclTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededOutputReference;
}
export interface JobTaskForEachTaskTaskWebhookNotificationsOnSuccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#id Job#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnSuccessToTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare function jobTaskForEachTaskTaskWebhookNotificationsOnSuccessToHclTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable): any;
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnSuccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskForEachTaskTaskWebhookNotificationsOnSuccess | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
}
export declare class JobTaskForEachTaskTaskWebhookNotificationsOnSuccessList extends cdktn.ComplexList {
    internalValue?: JobTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskForEachTaskTaskWebhookNotificationsOnSuccessOutputReference;
}
export interface JobTaskForEachTaskTaskWebhookNotifications {
    /**
    * on_duration_warning_threshold_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_duration_warning_threshold_exceeded Job#on_duration_warning_threshold_exceeded}
    */
    readonly onDurationWarningThresholdExceeded?: JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable;
    /**
    * on_failure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_failure Job#on_failure}
    */
    readonly onFailure?: JobTaskForEachTaskTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable;
    /**
    * on_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_start Job#on_start}
    */
    readonly onStart?: JobTaskForEachTaskTaskWebhookNotificationsOnStart[] | cdktn.IResolvable;
    /**
    * on_streaming_backlog_exceeded block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_streaming_backlog_exceeded Job#on_streaming_backlog_exceeded}
    */
    readonly onStreamingBacklogExceeded?: JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable;
    /**
    * on_success block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#on_success Job#on_success}
    */
    readonly onSuccess?: JobTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable;
}
export declare function jobTaskForEachTaskTaskWebhookNotificationsToTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOutputReference | JobTaskForEachTaskTaskWebhookNotifications): any;
export declare function jobTaskForEachTaskTaskWebhookNotificationsToHclTerraform(struct?: JobTaskForEachTaskTaskWebhookNotificationsOutputReference | JobTaskForEachTaskTaskWebhookNotifications): any;
export declare class JobTaskForEachTaskTaskWebhookNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTaskWebhookNotifications | undefined;
    set internalValue(value: JobTaskForEachTaskTaskWebhookNotifications | undefined);
    private _onDurationWarningThresholdExceeded;
    get onDurationWarningThresholdExceeded(): JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceededList;
    putOnDurationWarningThresholdExceeded(value: JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | cdktn.IResolvable): void;
    resetOnDurationWarningThresholdExceeded(): void;
    get onDurationWarningThresholdExceededInput(): cdktn.IResolvable | JobTaskForEachTaskTaskWebhookNotificationsOnDurationWarningThresholdExceeded[] | undefined;
    private _onFailure;
    get onFailure(): JobTaskForEachTaskTaskWebhookNotificationsOnFailureList;
    putOnFailure(value: JobTaskForEachTaskTaskWebhookNotificationsOnFailure[] | cdktn.IResolvable): void;
    resetOnFailure(): void;
    get onFailureInput(): cdktn.IResolvable | JobTaskForEachTaskTaskWebhookNotificationsOnFailure[] | undefined;
    private _onStart;
    get onStart(): JobTaskForEachTaskTaskWebhookNotificationsOnStartList;
    putOnStart(value: JobTaskForEachTaskTaskWebhookNotificationsOnStart[] | cdktn.IResolvable): void;
    resetOnStart(): void;
    get onStartInput(): cdktn.IResolvable | JobTaskForEachTaskTaskWebhookNotificationsOnStart[] | undefined;
    private _onStreamingBacklogExceeded;
    get onStreamingBacklogExceeded(): JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceededList;
    putOnStreamingBacklogExceeded(value: JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | cdktn.IResolvable): void;
    resetOnStreamingBacklogExceeded(): void;
    get onStreamingBacklogExceededInput(): cdktn.IResolvable | JobTaskForEachTaskTaskWebhookNotificationsOnStreamingBacklogExceeded[] | undefined;
    private _onSuccess;
    get onSuccess(): JobTaskForEachTaskTaskWebhookNotificationsOnSuccessList;
    putOnSuccess(value: JobTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | cdktn.IResolvable): void;
    resetOnSuccess(): void;
    get onSuccessInput(): cdktn.IResolvable | JobTaskForEachTaskTaskWebhookNotificationsOnSuccess[] | undefined;
}
export interface JobTaskForEachTaskTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#description Job#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#disable_auto_optimization Job#disable_auto_optimization}
    */
    readonly disableAutoOptimization?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#disabled Job#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#environment_key Job#environment_key}
    */
    readonly environmentKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#existing_cluster_id Job#existing_cluster_id}
    */
    readonly existingClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#job_cluster_key Job#job_cluster_key}
    */
    readonly jobClusterKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#max_retries Job#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#min_retry_interval_millis Job#min_retry_interval_millis}
    */
    readonly minRetryIntervalMillis?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#retry_on_timeout Job#retry_on_timeout}
    */
    readonly retryOnTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#run_if Job#run_if}
    */
    readonly runIf?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#task_key Job#task_key}
    */
    readonly taskKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#timeout_seconds Job#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * ai_runtime_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ai_runtime_task Job#ai_runtime_task}
    */
    readonly aiRuntimeTask?: JobTaskForEachTaskTaskAiRuntimeTask;
    /**
    * alert_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alert_task Job#alert_task}
    */
    readonly alertTask?: JobTaskForEachTaskTaskAlertTask;
    /**
    * clean_rooms_notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#clean_rooms_notebook_task Job#clean_rooms_notebook_task}
    */
    readonly cleanRoomsNotebookTask?: JobTaskForEachTaskTaskCleanRoomsNotebookTask;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#compute Job#compute}
    */
    readonly compute?: JobTaskForEachTaskTaskCompute;
    /**
    * condition_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#condition_task Job#condition_task}
    */
    readonly conditionTask?: JobTaskForEachTaskTaskConditionTask;
    /**
    * dashboard_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dashboard_task Job#dashboard_task}
    */
    readonly dashboardTask?: JobTaskForEachTaskTaskDashboardTask;
    /**
    * dbt_cloud_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbt_cloud_task Job#dbt_cloud_task}
    */
    readonly dbtCloudTask?: JobTaskForEachTaskTaskDbtCloudTask;
    /**
    * dbt_platform_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbt_platform_task Job#dbt_platform_task}
    */
    readonly dbtPlatformTask?: JobTaskForEachTaskTaskDbtPlatformTask;
    /**
    * dbt_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbt_task Job#dbt_task}
    */
    readonly dbtTask?: JobTaskForEachTaskTaskDbtTask;
    /**
    * depends_on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#depends_on Job#depends_on}
    */
    readonly dependsOn?: JobTaskForEachTaskTaskDependsOn[] | cdktn.IResolvable;
    /**
    * email_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#email_notifications Job#email_notifications}
    */
    readonly emailNotifications?: JobTaskForEachTaskTaskEmailNotifications;
    /**
    * gen_ai_compute_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gen_ai_compute_task Job#gen_ai_compute_task}
    */
    readonly genAiComputeTask?: JobTaskForEachTaskTaskGenAiComputeTask;
    /**
    * health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#health Job#health}
    */
    readonly health?: JobTaskForEachTaskTaskHealth;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobTaskForEachTaskTaskLibrary[] | cdktn.IResolvable;
    /**
    * new_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#new_cluster Job#new_cluster}
    */
    readonly newCluster?: JobTaskForEachTaskTaskNewCluster;
    /**
    * notebook_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notebook_task Job#notebook_task}
    */
    readonly notebookTask?: JobTaskForEachTaskTaskNotebookTask;
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notification_settings Job#notification_settings}
    */
    readonly notificationSettings?: JobTaskForEachTaskTaskNotificationSettings;
    /**
    * pipeline_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pipeline_task Job#pipeline_task}
    */
    readonly pipelineTask?: JobTaskForEachTaskTaskPipelineTask;
    /**
    * power_bi_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#power_bi_task Job#power_bi_task}
    */
    readonly powerBiTask?: JobTaskForEachTaskTaskPowerBiTask;
    /**
    * python_operator_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_operator_task Job#python_operator_task}
    */
    readonly pythonOperatorTask?: JobTaskForEachTaskTaskPythonOperatorTask;
    /**
    * python_wheel_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_wheel_task Job#python_wheel_task}
    */
    readonly pythonWheelTask?: JobTaskForEachTaskTaskPythonWheelTask;
    /**
    * run_job_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#run_job_task Job#run_job_task}
    */
    readonly runJobTask?: JobTaskForEachTaskTaskRunJobTask;
    /**
    * spark_jar_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_jar_task Job#spark_jar_task}
    */
    readonly sparkJarTask?: JobTaskForEachTaskTaskSparkJarTask;
    /**
    * spark_python_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_python_task Job#spark_python_task}
    */
    readonly sparkPythonTask?: JobTaskForEachTaskTaskSparkPythonTask;
    /**
    * spark_submit_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_submit_task Job#spark_submit_task}
    */
    readonly sparkSubmitTask?: JobTaskForEachTaskTaskSparkSubmitTask;
    /**
    * sql_task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#sql_task Job#sql_task}
    */
    readonly sqlTask?: JobTaskForEachTaskTaskSqlTask;
    /**
    * webhook_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#webhook_notifications Job#webhook_notifications}
    */
    readonly webhookNotifications?: JobTaskForEachTaskTaskWebhookNotifications;
}
export declare function jobTaskForEachTaskTaskToTerraform(struct?: JobTaskForEachTaskTaskOutputReference | JobTaskForEachTaskTask): any;
export declare function jobTaskForEachTaskTaskToHclTerraform(struct?: JobTaskForEachTaskTaskOutputReference | JobTaskForEachTaskTask): any;
export declare class JobTaskForEachTaskTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTaskTask | undefined;
    set internalValue(value: JobTaskForEachTaskTask | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableAutoOptimization?;
    get disableAutoOptimization(): boolean | cdktn.IResolvable;
    set disableAutoOptimization(value: boolean | cdktn.IResolvable);
    resetDisableAutoOptimization(): void;
    get disableAutoOptimizationInput(): boolean | cdktn.IResolvable | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentKey?;
    get environmentKey(): string;
    set environmentKey(value: string);
    resetEnvironmentKey(): void;
    get environmentKeyInput(): string | undefined;
    private _existingClusterId?;
    get existingClusterId(): string;
    set existingClusterId(value: string);
    resetExistingClusterId(): void;
    get existingClusterIdInput(): string | undefined;
    private _jobClusterKey?;
    get jobClusterKey(): string;
    set jobClusterKey(value: string);
    resetJobClusterKey(): void;
    get jobClusterKeyInput(): string | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _minRetryIntervalMillis?;
    get minRetryIntervalMillis(): number;
    set minRetryIntervalMillis(value: number);
    resetMinRetryIntervalMillis(): void;
    get minRetryIntervalMillisInput(): number | undefined;
    private _retryOnTimeout?;
    get retryOnTimeout(): boolean | cdktn.IResolvable;
    set retryOnTimeout(value: boolean | cdktn.IResolvable);
    resetRetryOnTimeout(): void;
    get retryOnTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    private _runIf?;
    get runIf(): string;
    set runIf(value: string);
    resetRunIf(): void;
    get runIfInput(): string | undefined;
    private _taskKey?;
    get taskKey(): string;
    set taskKey(value: string);
    get taskKeyInput(): string | undefined;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _aiRuntimeTask;
    get aiRuntimeTask(): JobTaskForEachTaskTaskAiRuntimeTaskOutputReference;
    putAiRuntimeTask(value: JobTaskForEachTaskTaskAiRuntimeTask): void;
    resetAiRuntimeTask(): void;
    get aiRuntimeTaskInput(): JobTaskForEachTaskTaskAiRuntimeTask | undefined;
    private _alertTask;
    get alertTask(): JobTaskForEachTaskTaskAlertTaskOutputReference;
    putAlertTask(value: JobTaskForEachTaskTaskAlertTask): void;
    resetAlertTask(): void;
    get alertTaskInput(): JobTaskForEachTaskTaskAlertTask | undefined;
    private _cleanRoomsNotebookTask;
    get cleanRoomsNotebookTask(): JobTaskForEachTaskTaskCleanRoomsNotebookTaskOutputReference;
    putCleanRoomsNotebookTask(value: JobTaskForEachTaskTaskCleanRoomsNotebookTask): void;
    resetCleanRoomsNotebookTask(): void;
    get cleanRoomsNotebookTaskInput(): JobTaskForEachTaskTaskCleanRoomsNotebookTask | undefined;
    private _compute;
    get compute(): JobTaskForEachTaskTaskComputeOutputReference;
    putCompute(value: JobTaskForEachTaskTaskCompute): void;
    resetCompute(): void;
    get computeInput(): JobTaskForEachTaskTaskCompute | undefined;
    private _conditionTask;
    get conditionTask(): JobTaskForEachTaskTaskConditionTaskOutputReference;
    putConditionTask(value: JobTaskForEachTaskTaskConditionTask): void;
    resetConditionTask(): void;
    get conditionTaskInput(): JobTaskForEachTaskTaskConditionTask | undefined;
    private _dashboardTask;
    get dashboardTask(): JobTaskForEachTaskTaskDashboardTaskOutputReference;
    putDashboardTask(value: JobTaskForEachTaskTaskDashboardTask): void;
    resetDashboardTask(): void;
    get dashboardTaskInput(): JobTaskForEachTaskTaskDashboardTask | undefined;
    private _dbtCloudTask;
    get dbtCloudTask(): JobTaskForEachTaskTaskDbtCloudTaskOutputReference;
    putDbtCloudTask(value: JobTaskForEachTaskTaskDbtCloudTask): void;
    resetDbtCloudTask(): void;
    get dbtCloudTaskInput(): JobTaskForEachTaskTaskDbtCloudTask | undefined;
    private _dbtPlatformTask;
    get dbtPlatformTask(): JobTaskForEachTaskTaskDbtPlatformTaskOutputReference;
    putDbtPlatformTask(value: JobTaskForEachTaskTaskDbtPlatformTask): void;
    resetDbtPlatformTask(): void;
    get dbtPlatformTaskInput(): JobTaskForEachTaskTaskDbtPlatformTask | undefined;
    private _dbtTask;
    get dbtTask(): JobTaskForEachTaskTaskDbtTaskOutputReference;
    putDbtTask(value: JobTaskForEachTaskTaskDbtTask): void;
    resetDbtTask(): void;
    get dbtTaskInput(): JobTaskForEachTaskTaskDbtTask | undefined;
    private _dependsOn;
    get dependsOn(): JobTaskForEachTaskTaskDependsOnList;
    putDependsOn(value: JobTaskForEachTaskTaskDependsOn[] | cdktn.IResolvable): void;
    resetDependsOn(): void;
    get dependsOnInput(): cdktn.IResolvable | JobTaskForEachTaskTaskDependsOn[] | undefined;
    private _emailNotifications;
    get emailNotifications(): JobTaskForEachTaskTaskEmailNotificationsOutputReference;
    putEmailNotifications(value: JobTaskForEachTaskTaskEmailNotifications): void;
    resetEmailNotifications(): void;
    get emailNotificationsInput(): JobTaskForEachTaskTaskEmailNotifications | undefined;
    private _genAiComputeTask;
    get genAiComputeTask(): JobTaskForEachTaskTaskGenAiComputeTaskOutputReference;
    putGenAiComputeTask(value: JobTaskForEachTaskTaskGenAiComputeTask): void;
    resetGenAiComputeTask(): void;
    get genAiComputeTaskInput(): JobTaskForEachTaskTaskGenAiComputeTask | undefined;
    private _health;
    get health(): JobTaskForEachTaskTaskHealthOutputReference;
    putHealth(value: JobTaskForEachTaskTaskHealth): void;
    resetHealth(): void;
    get healthInput(): JobTaskForEachTaskTaskHealth | undefined;
    private _library;
    get library(): JobTaskForEachTaskTaskLibraryList;
    putLibrary(value: JobTaskForEachTaskTaskLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobTaskForEachTaskTaskLibrary[] | undefined;
    private _newCluster;
    get newCluster(): JobTaskForEachTaskTaskNewClusterOutputReference;
    putNewCluster(value: JobTaskForEachTaskTaskNewCluster): void;
    resetNewCluster(): void;
    get newClusterInput(): JobTaskForEachTaskTaskNewCluster | undefined;
    private _notebookTask;
    get notebookTask(): JobTaskForEachTaskTaskNotebookTaskOutputReference;
    putNotebookTask(value: JobTaskForEachTaskTaskNotebookTask): void;
    resetNotebookTask(): void;
    get notebookTaskInput(): JobTaskForEachTaskTaskNotebookTask | undefined;
    private _notificationSettings;
    get notificationSettings(): JobTaskForEachTaskTaskNotificationSettingsOutputReference;
    putNotificationSettings(value: JobTaskForEachTaskTaskNotificationSettings): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): JobTaskForEachTaskTaskNotificationSettings | undefined;
    private _pipelineTask;
    get pipelineTask(): JobTaskForEachTaskTaskPipelineTaskOutputReference;
    putPipelineTask(value: JobTaskForEachTaskTaskPipelineTask): void;
    resetPipelineTask(): void;
    get pipelineTaskInput(): JobTaskForEachTaskTaskPipelineTask | undefined;
    private _powerBiTask;
    get powerBiTask(): JobTaskForEachTaskTaskPowerBiTaskOutputReference;
    putPowerBiTask(value: JobTaskForEachTaskTaskPowerBiTask): void;
    resetPowerBiTask(): void;
    get powerBiTaskInput(): JobTaskForEachTaskTaskPowerBiTask | undefined;
    private _pythonOperatorTask;
    get pythonOperatorTask(): JobTaskForEachTaskTaskPythonOperatorTaskOutputReference;
    putPythonOperatorTask(value: JobTaskForEachTaskTaskPythonOperatorTask): void;
    resetPythonOperatorTask(): void;
    get pythonOperatorTaskInput(): JobTaskForEachTaskTaskPythonOperatorTask | undefined;
    private _pythonWheelTask;
    get pythonWheelTask(): JobTaskForEachTaskTaskPythonWheelTaskOutputReference;
    putPythonWheelTask(value: JobTaskForEachTaskTaskPythonWheelTask): void;
    resetPythonWheelTask(): void;
    get pythonWheelTaskInput(): JobTaskForEachTaskTaskPythonWheelTask | undefined;
    private _runJobTask;
    get runJobTask(): JobTaskForEachTaskTaskRunJobTaskOutputReference;
    putRunJobTask(value: JobTaskForEachTaskTaskRunJobTask): void;
    resetRunJobTask(): void;
    get runJobTaskInput(): JobTaskForEachTaskTaskRunJobTask | undefined;
    private _sparkJarTask;
    get sparkJarTask(): JobTaskForEachTaskTaskSparkJarTaskOutputReference;
    putSparkJarTask(value: JobTaskForEachTaskTaskSparkJarTask): void;
    resetSparkJarTask(): void;
    get sparkJarTaskInput(): JobTaskForEachTaskTaskSparkJarTask | undefined;
    private _sparkPythonTask;
    get sparkPythonTask(): JobTaskForEachTaskTaskSparkPythonTaskOutputReference;
    putSparkPythonTask(value: JobTaskForEachTaskTaskSparkPythonTask): void;
    resetSparkPythonTask(): void;
    get sparkPythonTaskInput(): JobTaskForEachTaskTaskSparkPythonTask | undefined;
    private _sparkSubmitTask;
    get sparkSubmitTask(): JobTaskForEachTaskTaskSparkSubmitTaskOutputReference;
    putSparkSubmitTask(value: JobTaskForEachTaskTaskSparkSubmitTask): void;
    resetSparkSubmitTask(): void;
    get sparkSubmitTaskInput(): JobTaskForEachTaskTaskSparkSubmitTask | undefined;
    private _sqlTask;
    get sqlTask(): JobTaskForEachTaskTaskSqlTaskOutputReference;
    putSqlTask(value: JobTaskForEachTaskTaskSqlTask): void;
    resetSqlTask(): void;
    get sqlTaskInput(): JobTaskForEachTaskTaskSqlTask | undefined;
    private _webhookNotifications;
    get webhookNotifications(): JobTaskForEachTaskTaskWebhookNotificationsOutputReference;
    putWebhookNotifications(value: JobTaskForEachTaskTaskWebhookNotifications): void;
    resetWebhookNotifications(): void;
    get webhookNotificationsInput(): JobTaskForEachTaskTaskWebhookNotifications | undefined;
}
export interface JobTaskForEachTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#concurrency Job#concurrency}
    */
    readonly concurrency?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#inputs Job#inputs}
    */
    readonly inputs: string;
    /**
    * task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#task Job#task}
    */
    readonly task: JobTaskForEachTaskTask;
}
export declare function jobTaskForEachTaskToTerraform(struct?: JobTaskForEachTaskOutputReference | JobTaskForEachTask): any;
export declare function jobTaskForEachTaskToHclTerraform(struct?: JobTaskForEachTaskOutputReference | JobTaskForEachTask): any;
export declare class JobTaskForEachTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskForEachTask | undefined;
    set internalValue(value: JobTaskForEachTask | undefined);
    private _concurrency?;
    get concurrency(): number;
    set concurrency(value: number);
    resetConcurrency(): void;
    get concurrencyInput(): number | undefined;
    private _inputs?;
    get inputs(): string;
    set inputs(value: string);
    get inputsInput(): string | undefined;
    private _task;
    get task(): JobTaskForEachTaskTaskOutputReference;
    putTask(value: JobTaskForEachTaskTask): void;
    get taskInput(): JobTaskForEachTaskTask | undefined;
}
export interface JobTaskGenAiComputeTaskCompute {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gpu_node_pool_id Job#gpu_node_pool_id}
    */
    readonly gpuNodePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gpu_type Job#gpu_type}
    */
    readonly gpuType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#num_gpus Job#num_gpus}
    */
    readonly numGpus: number;
}
export declare function jobTaskGenAiComputeTaskComputeToTerraform(struct?: JobTaskGenAiComputeTaskComputeOutputReference | JobTaskGenAiComputeTaskCompute): any;
export declare function jobTaskGenAiComputeTaskComputeToHclTerraform(struct?: JobTaskGenAiComputeTaskComputeOutputReference | JobTaskGenAiComputeTaskCompute): any;
export declare class JobTaskGenAiComputeTaskComputeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskGenAiComputeTaskCompute | undefined;
    set internalValue(value: JobTaskGenAiComputeTaskCompute | undefined);
    private _gpuNodePoolId?;
    get gpuNodePoolId(): string;
    set gpuNodePoolId(value: string);
    resetGpuNodePoolId(): void;
    get gpuNodePoolIdInput(): string | undefined;
    private _gpuType?;
    get gpuType(): string;
    set gpuType(value: string);
    resetGpuType(): void;
    get gpuTypeInput(): string | undefined;
    private _numGpus?;
    get numGpus(): number;
    set numGpus(value: number);
    get numGpusInput(): number | undefined;
}
export interface JobTaskGenAiComputeTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#command Job#command}
    */
    readonly command?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dl_runtime_image Job#dl_runtime_image}
    */
    readonly dlRuntimeImage: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#mlflow_experiment_name Job#mlflow_experiment_name}
    */
    readonly mlflowExperimentName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#training_script_path Job#training_script_path}
    */
    readonly trainingScriptPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#yaml_parameters Job#yaml_parameters}
    */
    readonly yamlParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#yaml_parameters_file_path Job#yaml_parameters_file_path}
    */
    readonly yamlParametersFilePath?: string;
    /**
    * compute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#compute Job#compute}
    */
    readonly compute?: JobTaskGenAiComputeTaskCompute;
}
export declare function jobTaskGenAiComputeTaskToTerraform(struct?: JobTaskGenAiComputeTaskOutputReference | JobTaskGenAiComputeTask): any;
export declare function jobTaskGenAiComputeTaskToHclTerraform(struct?: JobTaskGenAiComputeTaskOutputReference | JobTaskGenAiComputeTask): any;
export declare class JobTaskGenAiComputeTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskGenAiComputeTask | undefined;
    set internalValue(value: JobTaskGenAiComputeTask | undefined);
    private _command?;
    get command(): string;
    set command(value: string);
    resetCommand(): void;
    get commandInput(): string | undefined;
    private _dlRuntimeImage?;
    get dlRuntimeImage(): string;
    set dlRuntimeImage(value: string);
    get dlRuntimeImageInput(): string | undefined;
    private _mlflowExperimentName?;
    get mlflowExperimentName(): string;
    set mlflowExperimentName(value: string);
    resetMlflowExperimentName(): void;
    get mlflowExperimentNameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _trainingScriptPath?;
    get trainingScriptPath(): string;
    set trainingScriptPath(value: string);
    resetTrainingScriptPath(): void;
    get trainingScriptPathInput(): string | undefined;
    private _yamlParameters?;
    get yamlParameters(): string;
    set yamlParameters(value: string);
    resetYamlParameters(): void;
    get yamlParametersInput(): string | undefined;
    private _yamlParametersFilePath?;
    get yamlParametersFilePath(): string;
    set yamlParametersFilePath(value: string);
    resetYamlParametersFilePath(): void;
    get yamlParametersFilePathInput(): string | undefined;
    private _compute;
    get compute(): JobTaskGenAiComputeTaskComputeOutputReference;
    putCompute(value: JobTaskGenAiComputeTaskCompute): void;
    resetCompute(): void;
    get computeInput(): JobTaskGenAiComputeTaskCompute | undefined;
}
export interface JobTaskHealthRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#metric Job#metric}
    */
    readonly metric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#op Job#op}
    */
    readonly op: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#value Job#value}
    */
    readonly value: number;
}
export declare function jobTaskHealthRulesToTerraform(struct?: JobTaskHealthRules | cdktn.IResolvable): any;
export declare function jobTaskHealthRulesToHclTerraform(struct?: JobTaskHealthRules | cdktn.IResolvable): any;
export declare class JobTaskHealthRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskHealthRules | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskHealthRules | cdktn.IResolvable | undefined);
    private _metric?;
    get metric(): string;
    set metric(value: string);
    get metricInput(): string | undefined;
    private _op?;
    get op(): string;
    set op(value: string);
    get opInput(): string | undefined;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
}
export declare class JobTaskHealthRulesList extends cdktn.ComplexList {
    internalValue?: JobTaskHealthRules[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskHealthRulesOutputReference;
}
export interface JobTaskHealth {
    /**
    * rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#rules Job#rules}
    */
    readonly rules: JobTaskHealthRules[] | cdktn.IResolvable;
}
export declare function jobTaskHealthToTerraform(struct?: JobTaskHealthOutputReference | JobTaskHealth): any;
export declare function jobTaskHealthToHclTerraform(struct?: JobTaskHealthOutputReference | JobTaskHealth): any;
export declare class JobTaskHealthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskHealth | undefined;
    set internalValue(value: JobTaskHealth | undefined);
    private _rules;
    get rules(): JobTaskHealthRulesList;
    putRules(value: JobTaskHealthRules[] | cdktn.IResolvable): void;
    get rulesInput(): cdktn.IResolvable | JobTaskHealthRules[] | undefined;
}
export interface JobTaskLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskLibraryCranToTerraform(struct?: JobTaskLibraryCranOutputReference | JobTaskLibraryCran): any;
export declare function jobTaskLibraryCranToHclTerraform(struct?: JobTaskLibraryCranOutputReference | JobTaskLibraryCran): any;
export declare class JobTaskLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskLibraryCran | undefined;
    set internalValue(value: JobTaskLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskLibraryMavenToTerraform(struct?: JobTaskLibraryMavenOutputReference | JobTaskLibraryMaven): any;
export declare function jobTaskLibraryMavenToHclTerraform(struct?: JobTaskLibraryMavenOutputReference | JobTaskLibraryMaven): any;
export declare class JobTaskLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskLibraryMaven | undefined;
    set internalValue(value: JobTaskLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskLibraryProviderConfigToTerraform(struct?: JobTaskLibraryProviderConfigOutputReference | JobTaskLibraryProviderConfig): any;
export declare function jobTaskLibraryProviderConfigToHclTerraform(struct?: JobTaskLibraryProviderConfigOutputReference | JobTaskLibraryProviderConfig): any;
export declare class JobTaskLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskLibraryProviderConfig | undefined;
    set internalValue(value: JobTaskLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskLibraryPypiToTerraform(struct?: JobTaskLibraryPypiOutputReference | JobTaskLibraryPypi): any;
export declare function jobTaskLibraryPypiToHclTerraform(struct?: JobTaskLibraryPypiOutputReference | JobTaskLibraryPypi): any;
export declare class JobTaskLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskLibraryPypi | undefined;
    set internalValue(value: JobTaskLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobTaskLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobTaskLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobTaskLibraryPypi;
}
export declare function jobTaskLibraryToTerraform(struct?: JobTaskLibrary | cdktn.IResolvable): any;
export declare function jobTaskLibraryToHclTerraform(struct?: JobTaskLibrary | cdktn.IResolvable): any;
export declare class JobTaskLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobTaskLibraryCranOutputReference;
    putCran(value: JobTaskLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobTaskLibraryCran | undefined;
    private _maven;
    get maven(): JobTaskLibraryMavenOutputReference;
    putMaven(value: JobTaskLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobTaskLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobTaskLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobTaskLibraryPypiOutputReference;
    putPypi(value: JobTaskLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobTaskLibraryPypi | undefined;
}
export declare class JobTaskLibraryList extends cdktn.ComplexList {
    internalValue?: JobTaskLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskLibraryOutputReference;
}
export interface JobTaskNewClusterAutoscale {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#max_workers Job#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#min_workers Job#min_workers}
    */
    readonly minWorkers?: number;
}
export declare function jobTaskNewClusterAutoscaleToTerraform(struct?: JobTaskNewClusterAutoscaleOutputReference | JobTaskNewClusterAutoscale): any;
export declare function jobTaskNewClusterAutoscaleToHclTerraform(struct?: JobTaskNewClusterAutoscaleOutputReference | JobTaskNewClusterAutoscale): any;
export declare class JobTaskNewClusterAutoscaleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterAutoscale | undefined;
    set internalValue(value: JobTaskNewClusterAutoscale | undefined);
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
}
export interface JobTaskNewClusterAwsAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_count Job#ebs_volume_count}
    */
    readonly ebsVolumeCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_iops Job#ebs_volume_iops}
    */
    readonly ebsVolumeIops?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_size Job#ebs_volume_size}
    */
    readonly ebsVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_throughput Job#ebs_volume_throughput}
    */
    readonly ebsVolumeThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ebs_volume_type Job#ebs_volume_type}
    */
    readonly ebsVolumeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#instance_profile_arn Job#instance_profile_arn}
    */
    readonly instanceProfileArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spot_bid_price_percent Job#spot_bid_price_percent}
    */
    readonly spotBidPricePercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobTaskNewClusterAwsAttributesToTerraform(struct?: JobTaskNewClusterAwsAttributesOutputReference | JobTaskNewClusterAwsAttributes): any;
export declare function jobTaskNewClusterAwsAttributesToHclTerraform(struct?: JobTaskNewClusterAwsAttributesOutputReference | JobTaskNewClusterAwsAttributes): any;
export declare class JobTaskNewClusterAwsAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterAwsAttributes | undefined;
    set internalValue(value: JobTaskNewClusterAwsAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _ebsVolumeCount?;
    get ebsVolumeCount(): number;
    set ebsVolumeCount(value: number);
    resetEbsVolumeCount(): void;
    get ebsVolumeCountInput(): number | undefined;
    private _ebsVolumeIops?;
    get ebsVolumeIops(): number;
    set ebsVolumeIops(value: number);
    resetEbsVolumeIops(): void;
    get ebsVolumeIopsInput(): number | undefined;
    private _ebsVolumeSize?;
    get ebsVolumeSize(): number;
    set ebsVolumeSize(value: number);
    resetEbsVolumeSize(): void;
    get ebsVolumeSizeInput(): number | undefined;
    private _ebsVolumeThroughput?;
    get ebsVolumeThroughput(): number;
    set ebsVolumeThroughput(value: number);
    resetEbsVolumeThroughput(): void;
    get ebsVolumeThroughputInput(): number | undefined;
    private _ebsVolumeType?;
    get ebsVolumeType(): string;
    set ebsVolumeType(value: string);
    resetEbsVolumeType(): void;
    get ebsVolumeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _instanceProfileArn?;
    get instanceProfileArn(): string;
    set instanceProfileArn(value: string);
    resetInstanceProfileArn(): void;
    get instanceProfileArnInput(): string | undefined;
    private _spotBidPricePercent?;
    get spotBidPricePercent(): number;
    set spotBidPricePercent(value: number);
    resetSpotBidPricePercent(): void;
    get spotBidPricePercentInput(): number | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobTaskNewClusterAzureAttributesLogAnalyticsInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#log_analytics_primary_key Job#log_analytics_primary_key}
    */
    readonly logAnalyticsPrimaryKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#log_analytics_workspace_id Job#log_analytics_workspace_id}
    */
    readonly logAnalyticsWorkspaceId?: string;
}
export declare function jobTaskNewClusterAzureAttributesLogAnalyticsInfoToTerraform(struct?: JobTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobTaskNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare function jobTaskNewClusterAzureAttributesLogAnalyticsInfoToHclTerraform(struct?: JobTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference | JobTaskNewClusterAzureAttributesLogAnalyticsInfo): any;
export declare class JobTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterAzureAttributesLogAnalyticsInfo | undefined;
    set internalValue(value: JobTaskNewClusterAzureAttributesLogAnalyticsInfo | undefined);
    private _logAnalyticsPrimaryKey?;
    get logAnalyticsPrimaryKey(): string;
    set logAnalyticsPrimaryKey(value: string);
    resetLogAnalyticsPrimaryKey(): void;
    get logAnalyticsPrimaryKeyInput(): string | undefined;
    private _logAnalyticsWorkspaceId?;
    get logAnalyticsWorkspaceId(): string;
    set logAnalyticsWorkspaceId(value: string);
    resetLogAnalyticsWorkspaceId(): void;
    get logAnalyticsWorkspaceIdInput(): string | undefined;
}
export interface JobTaskNewClusterAzureAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#capacity_reservation_group Job#capacity_reservation_group}
    */
    readonly capacityReservationGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spot_bid_max_price Job#spot_bid_max_price}
    */
    readonly spotBidMaxPrice?: number;
    /**
    * log_analytics_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#log_analytics_info Job#log_analytics_info}
    */
    readonly logAnalyticsInfo?: JobTaskNewClusterAzureAttributesLogAnalyticsInfo;
}
export declare function jobTaskNewClusterAzureAttributesToTerraform(struct?: JobTaskNewClusterAzureAttributesOutputReference | JobTaskNewClusterAzureAttributes): any;
export declare function jobTaskNewClusterAzureAttributesToHclTerraform(struct?: JobTaskNewClusterAzureAttributesOutputReference | JobTaskNewClusterAzureAttributes): any;
export declare class JobTaskNewClusterAzureAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterAzureAttributes | undefined;
    set internalValue(value: JobTaskNewClusterAzureAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _capacityReservationGroup?;
    get capacityReservationGroup(): string;
    set capacityReservationGroup(value: string);
    resetCapacityReservationGroup(): void;
    get capacityReservationGroupInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _spotBidMaxPrice?;
    get spotBidMaxPrice(): number;
    set spotBidMaxPrice(value: number);
    resetSpotBidMaxPrice(): void;
    get spotBidMaxPriceInput(): number | undefined;
    private _logAnalyticsInfo;
    get logAnalyticsInfo(): JobTaskNewClusterAzureAttributesLogAnalyticsInfoOutputReference;
    putLogAnalyticsInfo(value: JobTaskNewClusterAzureAttributesLogAnalyticsInfo): void;
    resetLogAnalyticsInfo(): void;
    get logAnalyticsInfoInput(): JobTaskNewClusterAzureAttributesLogAnalyticsInfo | undefined;
}
export interface JobTaskNewClusterClusterLogConfDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterClusterLogConfDbfsToTerraform(struct?: JobTaskNewClusterClusterLogConfDbfsOutputReference | JobTaskNewClusterClusterLogConfDbfs): any;
export declare function jobTaskNewClusterClusterLogConfDbfsToHclTerraform(struct?: JobTaskNewClusterClusterLogConfDbfsOutputReference | JobTaskNewClusterClusterLogConfDbfs): any;
export declare class JobTaskNewClusterClusterLogConfDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterClusterLogConfDbfs | undefined;
    set internalValue(value: JobTaskNewClusterClusterLogConfDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterClusterLogConfS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobTaskNewClusterClusterLogConfS3ToTerraform(struct?: JobTaskNewClusterClusterLogConfS3OutputReference | JobTaskNewClusterClusterLogConfS3): any;
export declare function jobTaskNewClusterClusterLogConfS3ToHclTerraform(struct?: JobTaskNewClusterClusterLogConfS3OutputReference | JobTaskNewClusterClusterLogConfS3): any;
export declare class JobTaskNewClusterClusterLogConfS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterClusterLogConfS3 | undefined;
    set internalValue(value: JobTaskNewClusterClusterLogConfS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobTaskNewClusterClusterLogConfVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterClusterLogConfVolumesToTerraform(struct?: JobTaskNewClusterClusterLogConfVolumesOutputReference | JobTaskNewClusterClusterLogConfVolumes): any;
export declare function jobTaskNewClusterClusterLogConfVolumesToHclTerraform(struct?: JobTaskNewClusterClusterLogConfVolumesOutputReference | JobTaskNewClusterClusterLogConfVolumes): any;
export declare class JobTaskNewClusterClusterLogConfVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterClusterLogConfVolumes | undefined;
    set internalValue(value: JobTaskNewClusterClusterLogConfVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterClusterLogConf {
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobTaskNewClusterClusterLogConfDbfs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobTaskNewClusterClusterLogConfS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobTaskNewClusterClusterLogConfVolumes;
}
export declare function jobTaskNewClusterClusterLogConfToTerraform(struct?: JobTaskNewClusterClusterLogConfOutputReference | JobTaskNewClusterClusterLogConf): any;
export declare function jobTaskNewClusterClusterLogConfToHclTerraform(struct?: JobTaskNewClusterClusterLogConfOutputReference | JobTaskNewClusterClusterLogConf): any;
export declare class JobTaskNewClusterClusterLogConfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterClusterLogConf | undefined;
    set internalValue(value: JobTaskNewClusterClusterLogConf | undefined);
    private _dbfs;
    get dbfs(): JobTaskNewClusterClusterLogConfDbfsOutputReference;
    putDbfs(value: JobTaskNewClusterClusterLogConfDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobTaskNewClusterClusterLogConfDbfs | undefined;
    private _s3;
    get s3(): JobTaskNewClusterClusterLogConfS3OutputReference;
    putS3(value: JobTaskNewClusterClusterLogConfS3): void;
    resetS3(): void;
    get s3Input(): JobTaskNewClusterClusterLogConfS3 | undefined;
    private _volumes;
    get volumes(): JobTaskNewClusterClusterLogConfVolumesOutputReference;
    putVolumes(value: JobTaskNewClusterClusterLogConfVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobTaskNewClusterClusterLogConfVolumes | undefined;
}
export interface JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#mount_options Job#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#server_address Job#server_address}
    */
    readonly serverAddress: string;
}
export declare function jobTaskNewClusterClusterMountInfoNetworkFilesystemInfoToTerraform(struct?: JobTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare function jobTaskNewClusterClusterMountInfoNetworkFilesystemInfoToHclTerraform(struct?: JobTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference | JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo): any;
export declare class JobTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
    set internalValue(value: JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _serverAddress?;
    get serverAddress(): string;
    set serverAddress(value: string);
    get serverAddressInput(): string | undefined;
}
export interface JobTaskNewClusterClusterMountInfo {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#local_mount_dir_path Job#local_mount_dir_path}
    */
    readonly localMountDirPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#remote_mount_dir_path Job#remote_mount_dir_path}
    */
    readonly remoteMountDirPath?: string;
    /**
    * network_filesystem_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#network_filesystem_info Job#network_filesystem_info}
    */
    readonly networkFilesystemInfo: JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo;
}
export declare function jobTaskNewClusterClusterMountInfoToTerraform(struct?: JobTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare function jobTaskNewClusterClusterMountInfoToHclTerraform(struct?: JobTaskNewClusterClusterMountInfo | cdktn.IResolvable): any;
export declare class JobTaskNewClusterClusterMountInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskNewClusterClusterMountInfo | cdktn.IResolvable | undefined);
    private _localMountDirPath?;
    get localMountDirPath(): string;
    set localMountDirPath(value: string);
    get localMountDirPathInput(): string | undefined;
    private _remoteMountDirPath?;
    get remoteMountDirPath(): string;
    set remoteMountDirPath(value: string);
    resetRemoteMountDirPath(): void;
    get remoteMountDirPathInput(): string | undefined;
    private _networkFilesystemInfo;
    get networkFilesystemInfo(): JobTaskNewClusterClusterMountInfoNetworkFilesystemInfoOutputReference;
    putNetworkFilesystemInfo(value: JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo): void;
    get networkFilesystemInfoInput(): JobTaskNewClusterClusterMountInfoNetworkFilesystemInfo | undefined;
}
export declare class JobTaskNewClusterClusterMountInfoList extends cdktn.ComplexList {
    internalValue?: JobTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskNewClusterClusterMountInfoOutputReference;
}
export interface JobTaskNewClusterDockerImageBasicAuth {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#password Job#password}
    */
    readonly password: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#username Job#username}
    */
    readonly username: string;
}
export declare function jobTaskNewClusterDockerImageBasicAuthToTerraform(struct?: JobTaskNewClusterDockerImageBasicAuthOutputReference | JobTaskNewClusterDockerImageBasicAuth): any;
export declare function jobTaskNewClusterDockerImageBasicAuthToHclTerraform(struct?: JobTaskNewClusterDockerImageBasicAuthOutputReference | JobTaskNewClusterDockerImageBasicAuth): any;
export declare class JobTaskNewClusterDockerImageBasicAuthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterDockerImageBasicAuth | undefined;
    set internalValue(value: JobTaskNewClusterDockerImageBasicAuth | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface JobTaskNewClusterDockerImage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#url Job#url}
    */
    readonly url: string;
    /**
    * basic_auth block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#basic_auth Job#basic_auth}
    */
    readonly basicAuth?: JobTaskNewClusterDockerImageBasicAuth;
}
export declare function jobTaskNewClusterDockerImageToTerraform(struct?: JobTaskNewClusterDockerImageOutputReference | JobTaskNewClusterDockerImage): any;
export declare function jobTaskNewClusterDockerImageToHclTerraform(struct?: JobTaskNewClusterDockerImageOutputReference | JobTaskNewClusterDockerImage): any;
export declare class JobTaskNewClusterDockerImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterDockerImage | undefined;
    set internalValue(value: JobTaskNewClusterDockerImage | undefined);
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _basicAuth;
    get basicAuth(): JobTaskNewClusterDockerImageBasicAuthOutputReference;
    putBasicAuth(value: JobTaskNewClusterDockerImageBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): JobTaskNewClusterDockerImageBasicAuth | undefined;
}
export interface JobTaskNewClusterDriverNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobTaskNewClusterDriverNodeTypeFlexibilityToTerraform(struct?: JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference | JobTaskNewClusterDriverNodeTypeFlexibility): any;
export declare function jobTaskNewClusterDriverNodeTypeFlexibilityToHclTerraform(struct?: JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference | JobTaskNewClusterDriverNodeTypeFlexibility): any;
export declare class JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterDriverNodeTypeFlexibility | undefined;
    set internalValue(value: JobTaskNewClusterDriverNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobTaskNewClusterGcpAttributes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#availability Job#availability}
    */
    readonly availability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#boot_disk_size Job#boot_disk_size}
    */
    readonly bootDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#confidential_compute_type Job#confidential_compute_type}
    */
    readonly confidentialComputeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#first_on_demand Job#first_on_demand}
    */
    readonly firstOnDemand?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#google_service_account Job#google_service_account}
    */
    readonly googleServiceAccount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#local_ssd_count Job#local_ssd_count}
    */
    readonly localSsdCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#use_preemptible_executors Job#use_preemptible_executors}
    */
    readonly usePreemptibleExecutors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#zone_id Job#zone_id}
    */
    readonly zoneId?: string;
}
export declare function jobTaskNewClusterGcpAttributesToTerraform(struct?: JobTaskNewClusterGcpAttributesOutputReference | JobTaskNewClusterGcpAttributes): any;
export declare function jobTaskNewClusterGcpAttributesToHclTerraform(struct?: JobTaskNewClusterGcpAttributesOutputReference | JobTaskNewClusterGcpAttributes): any;
export declare class JobTaskNewClusterGcpAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterGcpAttributes | undefined;
    set internalValue(value: JobTaskNewClusterGcpAttributes | undefined);
    private _availability?;
    get availability(): string;
    set availability(value: string);
    resetAvailability(): void;
    get availabilityInput(): string | undefined;
    private _bootDiskSize?;
    get bootDiskSize(): number;
    set bootDiskSize(value: number);
    resetBootDiskSize(): void;
    get bootDiskSizeInput(): number | undefined;
    private _confidentialComputeType?;
    get confidentialComputeType(): string;
    set confidentialComputeType(value: string);
    resetConfidentialComputeType(): void;
    get confidentialComputeTypeInput(): string | undefined;
    private _firstOnDemand?;
    get firstOnDemand(): number;
    set firstOnDemand(value: number);
    resetFirstOnDemand(): void;
    get firstOnDemandInput(): number | undefined;
    private _googleServiceAccount?;
    get googleServiceAccount(): string;
    set googleServiceAccount(value: string);
    resetGoogleServiceAccount(): void;
    get googleServiceAccountInput(): string | undefined;
    private _localSsdCount?;
    get localSsdCount(): number;
    set localSsdCount(value: number);
    resetLocalSsdCount(): void;
    get localSsdCountInput(): number | undefined;
    private _usePreemptibleExecutors?;
    get usePreemptibleExecutors(): boolean | cdktn.IResolvable;
    set usePreemptibleExecutors(value: boolean | cdktn.IResolvable);
    resetUsePreemptibleExecutors(): void;
    get usePreemptibleExecutorsInput(): boolean | cdktn.IResolvable | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsAbfss {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsAbfssToTerraform(struct?: JobTaskNewClusterInitScriptsAbfssOutputReference | JobTaskNewClusterInitScriptsAbfss): any;
export declare function jobTaskNewClusterInitScriptsAbfssToHclTerraform(struct?: JobTaskNewClusterInitScriptsAbfssOutputReference | JobTaskNewClusterInitScriptsAbfss): any;
export declare class JobTaskNewClusterInitScriptsAbfssOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsAbfss | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsAbfss | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsDbfs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsDbfsToTerraform(struct?: JobTaskNewClusterInitScriptsDbfsOutputReference | JobTaskNewClusterInitScriptsDbfs): any;
export declare function jobTaskNewClusterInitScriptsDbfsToHclTerraform(struct?: JobTaskNewClusterInitScriptsDbfsOutputReference | JobTaskNewClusterInitScriptsDbfs): any;
export declare class JobTaskNewClusterInitScriptsDbfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsDbfs | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsDbfs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsFile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsFileToTerraform(struct?: JobTaskNewClusterInitScriptsFileOutputReference | JobTaskNewClusterInitScriptsFile): any;
export declare function jobTaskNewClusterInitScriptsFileToHclTerraform(struct?: JobTaskNewClusterInitScriptsFileOutputReference | JobTaskNewClusterInitScriptsFile): any;
export declare class JobTaskNewClusterInitScriptsFileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsFile | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsFile | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsGcs {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsGcsToTerraform(struct?: JobTaskNewClusterInitScriptsGcsOutputReference | JobTaskNewClusterInitScriptsGcs): any;
export declare function jobTaskNewClusterInitScriptsGcsToHclTerraform(struct?: JobTaskNewClusterInitScriptsGcsOutputReference | JobTaskNewClusterInitScriptsGcs): any;
export declare class JobTaskNewClusterInitScriptsGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsGcs | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsGcs | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsS3 {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#canned_acl Job#canned_acl}
    */
    readonly cannedAcl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_encryption Job#enable_encryption}
    */
    readonly enableEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#encryption_type Job#encryption_type}
    */
    readonly encryptionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#endpoint Job#endpoint}
    */
    readonly endpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#kms_key Job#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#region Job#region}
    */
    readonly region?: string;
}
export declare function jobTaskNewClusterInitScriptsS3ToTerraform(struct?: JobTaskNewClusterInitScriptsS3OutputReference | JobTaskNewClusterInitScriptsS3): any;
export declare function jobTaskNewClusterInitScriptsS3ToHclTerraform(struct?: JobTaskNewClusterInitScriptsS3OutputReference | JobTaskNewClusterInitScriptsS3): any;
export declare class JobTaskNewClusterInitScriptsS3OutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsS3 | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsS3 | undefined);
    private _cannedAcl?;
    get cannedAcl(): string;
    set cannedAcl(value: string);
    resetCannedAcl(): void;
    get cannedAclInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _enableEncryption?;
    get enableEncryption(): boolean | cdktn.IResolvable;
    set enableEncryption(value: boolean | cdktn.IResolvable);
    resetEnableEncryption(): void;
    get enableEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionType?;
    get encryptionType(): string;
    set encryptionType(value: string);
    resetEncryptionType(): void;
    get encryptionTypeInput(): string | undefined;
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    resetEndpoint(): void;
    get endpointInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsVolumes {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsVolumesToTerraform(struct?: JobTaskNewClusterInitScriptsVolumesOutputReference | JobTaskNewClusterInitScriptsVolumes): any;
export declare function jobTaskNewClusterInitScriptsVolumesToHclTerraform(struct?: JobTaskNewClusterInitScriptsVolumesOutputReference | JobTaskNewClusterInitScriptsVolumes): any;
export declare class JobTaskNewClusterInitScriptsVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsVolumes | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsVolumes | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScriptsWorkspace {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#destination Job#destination}
    */
    readonly destination: string;
}
export declare function jobTaskNewClusterInitScriptsWorkspaceToTerraform(struct?: JobTaskNewClusterInitScriptsWorkspaceOutputReference | JobTaskNewClusterInitScriptsWorkspace): any;
export declare function jobTaskNewClusterInitScriptsWorkspaceToHclTerraform(struct?: JobTaskNewClusterInitScriptsWorkspaceOutputReference | JobTaskNewClusterInitScriptsWorkspace): any;
export declare class JobTaskNewClusterInitScriptsWorkspaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterInitScriptsWorkspace | undefined;
    set internalValue(value: JobTaskNewClusterInitScriptsWorkspace | undefined);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
}
export interface JobTaskNewClusterInitScripts {
    /**
    * abfss block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#abfss Job#abfss}
    */
    readonly abfss?: JobTaskNewClusterInitScriptsAbfss;
    /**
    * dbfs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbfs Job#dbfs}
    */
    readonly dbfs?: JobTaskNewClusterInitScriptsDbfs;
    /**
    * file block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#file Job#file}
    */
    readonly file?: JobTaskNewClusterInitScriptsFile;
    /**
    * gcs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gcs Job#gcs}
    */
    readonly gcs?: JobTaskNewClusterInitScriptsGcs;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#s3 Job#s3}
    */
    readonly s3?: JobTaskNewClusterInitScriptsS3;
    /**
    * volumes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#volumes Job#volumes}
    */
    readonly volumes?: JobTaskNewClusterInitScriptsVolumes;
    /**
    * workspace block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace Job#workspace}
    */
    readonly workspace?: JobTaskNewClusterInitScriptsWorkspace;
}
export declare function jobTaskNewClusterInitScriptsToTerraform(struct?: JobTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare function jobTaskNewClusterInitScriptsToHclTerraform(struct?: JobTaskNewClusterInitScripts | cdktn.IResolvable): any;
export declare class JobTaskNewClusterInitScriptsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskNewClusterInitScripts | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskNewClusterInitScripts | cdktn.IResolvable | undefined);
    private _abfss;
    get abfss(): JobTaskNewClusterInitScriptsAbfssOutputReference;
    putAbfss(value: JobTaskNewClusterInitScriptsAbfss): void;
    resetAbfss(): void;
    get abfssInput(): JobTaskNewClusterInitScriptsAbfss | undefined;
    private _dbfs;
    get dbfs(): JobTaskNewClusterInitScriptsDbfsOutputReference;
    putDbfs(value: JobTaskNewClusterInitScriptsDbfs): void;
    resetDbfs(): void;
    get dbfsInput(): JobTaskNewClusterInitScriptsDbfs | undefined;
    private _file;
    get file(): JobTaskNewClusterInitScriptsFileOutputReference;
    putFile(value: JobTaskNewClusterInitScriptsFile): void;
    resetFile(): void;
    get fileInput(): JobTaskNewClusterInitScriptsFile | undefined;
    private _gcs;
    get gcs(): JobTaskNewClusterInitScriptsGcsOutputReference;
    putGcs(value: JobTaskNewClusterInitScriptsGcs): void;
    resetGcs(): void;
    get gcsInput(): JobTaskNewClusterInitScriptsGcs | undefined;
    private _s3;
    get s3(): JobTaskNewClusterInitScriptsS3OutputReference;
    putS3(value: JobTaskNewClusterInitScriptsS3): void;
    resetS3(): void;
    get s3Input(): JobTaskNewClusterInitScriptsS3 | undefined;
    private _volumes;
    get volumes(): JobTaskNewClusterInitScriptsVolumesOutputReference;
    putVolumes(value: JobTaskNewClusterInitScriptsVolumes): void;
    resetVolumes(): void;
    get volumesInput(): JobTaskNewClusterInitScriptsVolumes | undefined;
    private _workspace;
    get workspace(): JobTaskNewClusterInitScriptsWorkspaceOutputReference;
    putWorkspace(value: JobTaskNewClusterInitScriptsWorkspace): void;
    resetWorkspace(): void;
    get workspaceInput(): JobTaskNewClusterInitScriptsWorkspace | undefined;
}
export declare class JobTaskNewClusterInitScriptsList extends cdktn.ComplexList {
    internalValue?: JobTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskNewClusterInitScriptsOutputReference;
}
export interface JobTaskNewClusterLibraryCran {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskNewClusterLibraryCranToTerraform(struct?: JobTaskNewClusterLibraryCranOutputReference | JobTaskNewClusterLibraryCran): any;
export declare function jobTaskNewClusterLibraryCranToHclTerraform(struct?: JobTaskNewClusterLibraryCranOutputReference | JobTaskNewClusterLibraryCran): any;
export declare class JobTaskNewClusterLibraryCranOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryCran | undefined;
    set internalValue(value: JobTaskNewClusterLibraryCran | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskNewClusterLibraryMaven {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#coordinates Job#coordinates}
    */
    readonly coordinates: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#exclusions Job#exclusions}
    */
    readonly exclusions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskNewClusterLibraryMavenToTerraform(struct?: JobTaskNewClusterLibraryMavenOutputReference | JobTaskNewClusterLibraryMaven): any;
export declare function jobTaskNewClusterLibraryMavenToHclTerraform(struct?: JobTaskNewClusterLibraryMavenOutputReference | JobTaskNewClusterLibraryMaven): any;
export declare class JobTaskNewClusterLibraryMavenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryMaven | undefined;
    set internalValue(value: JobTaskNewClusterLibraryMaven | undefined);
    private _coordinates?;
    get coordinates(): string;
    set coordinates(value: string);
    get coordinatesInput(): string | undefined;
    private _exclusions?;
    get exclusions(): string[];
    set exclusions(value: string[]);
    resetExclusions(): void;
    get exclusionsInput(): string[] | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskNewClusterLibraryProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskNewClusterLibraryProviderConfigToTerraform(struct?: JobTaskNewClusterLibraryProviderConfigOutputReference | JobTaskNewClusterLibraryProviderConfig): any;
export declare function jobTaskNewClusterLibraryProviderConfigToHclTerraform(struct?: JobTaskNewClusterLibraryProviderConfigOutputReference | JobTaskNewClusterLibraryProviderConfig): any;
export declare class JobTaskNewClusterLibraryProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryProviderConfig | undefined;
    set internalValue(value: JobTaskNewClusterLibraryProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskNewClusterLibraryPypi {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package Job#package}
    */
    readonly package: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#repo Job#repo}
    */
    readonly repo?: string;
}
export declare function jobTaskNewClusterLibraryPypiToTerraform(struct?: JobTaskNewClusterLibraryPypiOutputReference | JobTaskNewClusterLibraryPypi): any;
export declare function jobTaskNewClusterLibraryPypiToHclTerraform(struct?: JobTaskNewClusterLibraryPypiOutputReference | JobTaskNewClusterLibraryPypi): any;
export declare class JobTaskNewClusterLibraryPypiOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterLibraryPypi | undefined;
    set internalValue(value: JobTaskNewClusterLibraryPypi | undefined);
    private _package?;
    get package(): string;
    set package(value: string);
    get packageInput(): string | undefined;
    private _repo?;
    get repo(): string;
    set repo(value: string);
    resetRepo(): void;
    get repoInput(): string | undefined;
}
export interface JobTaskNewClusterLibrary {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#egg Job#egg}
    */
    readonly egg?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar Job#jar}
    */
    readonly jar?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#requirements Job#requirements}
    */
    readonly requirements?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#whl Job#whl}
    */
    readonly whl?: string;
    /**
    * cran block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cran Job#cran}
    */
    readonly cran?: JobTaskNewClusterLibraryCran;
    /**
    * maven block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#maven Job#maven}
    */
    readonly maven?: JobTaskNewClusterLibraryMaven;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskNewClusterLibraryProviderConfig;
    /**
    * pypi block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pypi Job#pypi}
    */
    readonly pypi?: JobTaskNewClusterLibraryPypi;
}
export declare function jobTaskNewClusterLibraryToTerraform(struct?: JobTaskNewClusterLibrary | cdktn.IResolvable): any;
export declare function jobTaskNewClusterLibraryToHclTerraform(struct?: JobTaskNewClusterLibrary | cdktn.IResolvable): any;
export declare class JobTaskNewClusterLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskNewClusterLibrary | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskNewClusterLibrary | cdktn.IResolvable | undefined);
    private _egg?;
    get egg(): string;
    set egg(value: string);
    resetEgg(): void;
    get eggInput(): string | undefined;
    private _jar?;
    get jar(): string;
    set jar(value: string);
    resetJar(): void;
    get jarInput(): string | undefined;
    private _requirements?;
    get requirements(): string;
    set requirements(value: string);
    resetRequirements(): void;
    get requirementsInput(): string | undefined;
    private _whl?;
    get whl(): string;
    set whl(value: string);
    resetWhl(): void;
    get whlInput(): string | undefined;
    private _cran;
    get cran(): JobTaskNewClusterLibraryCranOutputReference;
    putCran(value: JobTaskNewClusterLibraryCran): void;
    resetCran(): void;
    get cranInput(): JobTaskNewClusterLibraryCran | undefined;
    private _maven;
    get maven(): JobTaskNewClusterLibraryMavenOutputReference;
    putMaven(value: JobTaskNewClusterLibraryMaven): void;
    resetMaven(): void;
    get mavenInput(): JobTaskNewClusterLibraryMaven | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskNewClusterLibraryProviderConfigOutputReference;
    putProviderConfig(value: JobTaskNewClusterLibraryProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskNewClusterLibraryProviderConfig | undefined;
    private _pypi;
    get pypi(): JobTaskNewClusterLibraryPypiOutputReference;
    putPypi(value: JobTaskNewClusterLibraryPypi): void;
    resetPypi(): void;
    get pypiInput(): JobTaskNewClusterLibraryPypi | undefined;
}
export declare class JobTaskNewClusterLibraryList extends cdktn.ComplexList {
    internalValue?: JobTaskNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskNewClusterLibraryOutputReference;
}
export interface JobTaskNewClusterProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_id Job#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function jobTaskNewClusterProviderConfigToTerraform(struct?: JobTaskNewClusterProviderConfigOutputReference | JobTaskNewClusterProviderConfig): any;
export declare function jobTaskNewClusterProviderConfigToHclTerraform(struct?: JobTaskNewClusterProviderConfigOutputReference | JobTaskNewClusterProviderConfig): any;
export declare class JobTaskNewClusterProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterProviderConfig | undefined;
    set internalValue(value: JobTaskNewClusterProviderConfig | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface JobTaskNewClusterWorkerNodeTypeFlexibility {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alternate_node_type_ids Job#alternate_node_type_ids}
    */
    readonly alternateNodeTypeIds?: string[];
}
export declare function jobTaskNewClusterWorkerNodeTypeFlexibilityToTerraform(struct?: JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference | JobTaskNewClusterWorkerNodeTypeFlexibility): any;
export declare function jobTaskNewClusterWorkerNodeTypeFlexibilityToHclTerraform(struct?: JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference | JobTaskNewClusterWorkerNodeTypeFlexibility): any;
export declare class JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterWorkerNodeTypeFlexibility | undefined;
    set internalValue(value: JobTaskNewClusterWorkerNodeTypeFlexibility | undefined);
    private _alternateNodeTypeIds?;
    get alternateNodeTypeIds(): string[];
    set alternateNodeTypeIds(value: string[]);
    resetAlternateNodeTypeIds(): void;
    get alternateNodeTypeIdsInput(): string[] | undefined;
}
export interface JobTaskNewClusterWorkloadTypeClients {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jobs Job#jobs}
    */
    readonly jobs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notebooks Job#notebooks}
    */
    readonly notebooks?: boolean | cdktn.IResolvable;
}
export declare function jobTaskNewClusterWorkloadTypeClientsToTerraform(struct?: JobTaskNewClusterWorkloadTypeClientsOutputReference | JobTaskNewClusterWorkloadTypeClients): any;
export declare function jobTaskNewClusterWorkloadTypeClientsToHclTerraform(struct?: JobTaskNewClusterWorkloadTypeClientsOutputReference | JobTaskNewClusterWorkloadTypeClients): any;
export declare class JobTaskNewClusterWorkloadTypeClientsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterWorkloadTypeClients | undefined;
    set internalValue(value: JobTaskNewClusterWorkloadTypeClients | undefined);
    private _jobs?;
    get jobs(): boolean | cdktn.IResolvable;
    set jobs(value: boolean | cdktn.IResolvable);
    resetJobs(): void;
    get jobsInput(): boolean | cdktn.IResolvable | undefined;
    private _notebooks?;
    get notebooks(): boolean | cdktn.IResolvable;
    set notebooks(value: boolean | cdktn.IResolvable);
    resetNotebooks(): void;
    get notebooksInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskNewClusterWorkloadType {
    /**
    * clients block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#clients Job#clients}
    */
    readonly clients: JobTaskNewClusterWorkloadTypeClients;
}
export declare function jobTaskNewClusterWorkloadTypeToTerraform(struct?: JobTaskNewClusterWorkloadTypeOutputReference | JobTaskNewClusterWorkloadType): any;
export declare function jobTaskNewClusterWorkloadTypeToHclTerraform(struct?: JobTaskNewClusterWorkloadTypeOutputReference | JobTaskNewClusterWorkloadType): any;
export declare class JobTaskNewClusterWorkloadTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewClusterWorkloadType | undefined;
    set internalValue(value: JobTaskNewClusterWorkloadType | undefined);
    private _clients;
    get clients(): JobTaskNewClusterWorkloadTypeClientsOutputReference;
    putClients(value: JobTaskNewClusterWorkloadTypeClients): void;
    get clientsInput(): JobTaskNewClusterWorkloadTypeClients | undefined;
}
export interface JobTaskNewCluster {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#__apply_policy_default_values_allow_list Job#__apply_policy_default_values_allow_list}
    */
    readonly applyPolicyDefaultValuesAllowList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#apply_policy_default_values Job#apply_policy_default_values}
    */
    readonly applyPolicyDefaultValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_id Job#cluster_id}
    */
    readonly clusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_name Job#cluster_name}
    */
    readonly clusterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#custom_tags Job#custom_tags}
    */
    readonly customTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#data_security_mode Job#data_security_mode}
    */
    readonly dataSecurityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dependency_mode Job#dependency_mode}
    */
    readonly dependencyMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#driver_instance_pool_id Job#driver_instance_pool_id}
    */
    readonly driverInstancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#driver_node_type_id Job#driver_node_type_id}
    */
    readonly driverNodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_elastic_disk Job#enable_elastic_disk}
    */
    readonly enableElasticDisk?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#enable_local_disk_encryption Job#enable_local_disk_encryption}
    */
    readonly enableLocalDiskEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#idempotency_token Job#idempotency_token}
    */
    readonly idempotencyToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#instance_pool_id Job#instance_pool_id}
    */
    readonly instancePoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#is_single_node Job#is_single_node}
    */
    readonly isSingleNode?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#kind Job#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#node_type_id Job#node_type_id}
    */
    readonly nodeTypeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#num_workers Job#num_workers}
    */
    readonly numWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#policy_id Job#policy_id}
    */
    readonly policyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#remote_disk_throughput Job#remote_disk_throughput}
    */
    readonly remoteDiskThroughput?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#runtime_engine Job#runtime_engine}
    */
    readonly runtimeEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#single_user_name Job#single_user_name}
    */
    readonly singleUserName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_conf Job#spark_conf}
    */
    readonly sparkConf?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_env_vars Job#spark_env_vars}
    */
    readonly sparkEnvVars?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_version Job#spark_version}
    */
    readonly sparkVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#ssh_public_keys Job#ssh_public_keys}
    */
    readonly sshPublicKeys?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#total_initial_remote_disk_size Job#total_initial_remote_disk_size}
    */
    readonly totalInitialRemoteDiskSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#use_ml_runtime Job#use_ml_runtime}
    */
    readonly useMlRuntime?: boolean | cdktn.IResolvable;
    /**
    * autoscale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#autoscale Job#autoscale}
    */
    readonly autoscale?: JobTaskNewClusterAutoscale;
    /**
    * aws_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#aws_attributes Job#aws_attributes}
    */
    readonly awsAttributes?: JobTaskNewClusterAwsAttributes;
    /**
    * azure_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#azure_attributes Job#azure_attributes}
    */
    readonly azureAttributes?: JobTaskNewClusterAzureAttributes;
    /**
    * cluster_log_conf block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_log_conf Job#cluster_log_conf}
    */
    readonly clusterLogConf?: JobTaskNewClusterClusterLogConf;
    /**
    * cluster_mount_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#cluster_mount_info Job#cluster_mount_info}
    */
    readonly clusterMountInfo?: JobTaskNewClusterClusterMountInfo[] | cdktn.IResolvable;
    /**
    * docker_image block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#docker_image Job#docker_image}
    */
    readonly dockerImage?: JobTaskNewClusterDockerImage;
    /**
    * driver_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#driver_node_type_flexibility Job#driver_node_type_flexibility}
    */
    readonly driverNodeTypeFlexibility?: JobTaskNewClusterDriverNodeTypeFlexibility;
    /**
    * gcp_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#gcp_attributes Job#gcp_attributes}
    */
    readonly gcpAttributes?: JobTaskNewClusterGcpAttributes;
    /**
    * init_scripts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#init_scripts Job#init_scripts}
    */
    readonly initScripts?: JobTaskNewClusterInitScripts[] | cdktn.IResolvable;
    /**
    * library block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#library Job#library}
    */
    readonly library?: JobTaskNewClusterLibrary[] | cdktn.IResolvable;
    /**
    * provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#provider_config Job#provider_config}
    */
    readonly providerConfig?: JobTaskNewClusterProviderConfig;
    /**
    * worker_node_type_flexibility block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#worker_node_type_flexibility Job#worker_node_type_flexibility}
    */
    readonly workerNodeTypeFlexibility?: JobTaskNewClusterWorkerNodeTypeFlexibility;
    /**
    * workload_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workload_type Job#workload_type}
    */
    readonly workloadType?: JobTaskNewClusterWorkloadType;
}
export declare function jobTaskNewClusterToTerraform(struct?: JobTaskNewClusterOutputReference | JobTaskNewCluster): any;
export declare function jobTaskNewClusterToHclTerraform(struct?: JobTaskNewClusterOutputReference | JobTaskNewCluster): any;
export declare class JobTaskNewClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNewCluster | undefined;
    set internalValue(value: JobTaskNewCluster | undefined);
    private _applyPolicyDefaultValuesAllowList?;
    get applyPolicyDefaultValuesAllowList(): string[];
    set applyPolicyDefaultValuesAllowList(value: string[]);
    resetApplyPolicyDefaultValuesAllowList(): void;
    get applyPolicyDefaultValuesAllowListInput(): string[] | undefined;
    private _applyPolicyDefaultValues?;
    get applyPolicyDefaultValues(): boolean | cdktn.IResolvable;
    set applyPolicyDefaultValues(value: boolean | cdktn.IResolvable);
    resetApplyPolicyDefaultValues(): void;
    get applyPolicyDefaultValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    resetClusterId(): void;
    get clusterIdInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    resetClusterName(): void;
    get clusterNameInput(): string | undefined;
    private _customTags?;
    get customTags(): {
        [key: string]: string;
    };
    set customTags(value: {
        [key: string]: string;
    });
    resetCustomTags(): void;
    get customTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _dataSecurityMode?;
    get dataSecurityMode(): string;
    set dataSecurityMode(value: string);
    resetDataSecurityMode(): void;
    get dataSecurityModeInput(): string | undefined;
    private _dependencyMode?;
    get dependencyMode(): string;
    set dependencyMode(value: string);
    resetDependencyMode(): void;
    get dependencyModeInput(): string | undefined;
    private _driverInstancePoolId?;
    get driverInstancePoolId(): string;
    set driverInstancePoolId(value: string);
    resetDriverInstancePoolId(): void;
    get driverInstancePoolIdInput(): string | undefined;
    private _driverNodeTypeId?;
    get driverNodeTypeId(): string;
    set driverNodeTypeId(value: string);
    resetDriverNodeTypeId(): void;
    get driverNodeTypeIdInput(): string | undefined;
    private _enableElasticDisk?;
    get enableElasticDisk(): boolean | cdktn.IResolvable;
    set enableElasticDisk(value: boolean | cdktn.IResolvable);
    resetEnableElasticDisk(): void;
    get enableElasticDiskInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLocalDiskEncryption?;
    get enableLocalDiskEncryption(): boolean | cdktn.IResolvable;
    set enableLocalDiskEncryption(value: boolean | cdktn.IResolvable);
    resetEnableLocalDiskEncryption(): void;
    get enableLocalDiskEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _idempotencyToken?;
    get idempotencyToken(): string;
    set idempotencyToken(value: string);
    resetIdempotencyToken(): void;
    get idempotencyTokenInput(): string | undefined;
    private _instancePoolId?;
    get instancePoolId(): string;
    set instancePoolId(value: string);
    resetInstancePoolId(): void;
    get instancePoolIdInput(): string | undefined;
    private _isSingleNode?;
    get isSingleNode(): boolean | cdktn.IResolvable;
    set isSingleNode(value: boolean | cdktn.IResolvable);
    resetIsSingleNode(): void;
    get isSingleNodeInput(): boolean | cdktn.IResolvable | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _nodeTypeId?;
    get nodeTypeId(): string;
    set nodeTypeId(value: string);
    resetNodeTypeId(): void;
    get nodeTypeIdInput(): string | undefined;
    private _numWorkers?;
    get numWorkers(): number;
    set numWorkers(value: number);
    resetNumWorkers(): void;
    get numWorkersInput(): number | undefined;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    resetPolicyId(): void;
    get policyIdInput(): string | undefined;
    private _remoteDiskThroughput?;
    get remoteDiskThroughput(): number;
    set remoteDiskThroughput(value: number);
    resetRemoteDiskThroughput(): void;
    get remoteDiskThroughputInput(): number | undefined;
    private _runtimeEngine?;
    get runtimeEngine(): string;
    set runtimeEngine(value: string);
    resetRuntimeEngine(): void;
    get runtimeEngineInput(): string | undefined;
    private _singleUserName?;
    get singleUserName(): string;
    set singleUserName(value: string);
    resetSingleUserName(): void;
    get singleUserNameInput(): string | undefined;
    private _sparkConf?;
    get sparkConf(): {
        [key: string]: string;
    };
    set sparkConf(value: {
        [key: string]: string;
    });
    resetSparkConf(): void;
    get sparkConfInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkEnvVars?;
    get sparkEnvVars(): {
        [key: string]: string;
    };
    set sparkEnvVars(value: {
        [key: string]: string;
    });
    resetSparkEnvVars(): void;
    get sparkEnvVarsInput(): {
        [key: string]: string;
    } | undefined;
    private _sparkVersion?;
    get sparkVersion(): string;
    set sparkVersion(value: string);
    resetSparkVersion(): void;
    get sparkVersionInput(): string | undefined;
    private _sshPublicKeys?;
    get sshPublicKeys(): string[];
    set sshPublicKeys(value: string[]);
    resetSshPublicKeys(): void;
    get sshPublicKeysInput(): string[] | undefined;
    private _totalInitialRemoteDiskSize?;
    get totalInitialRemoteDiskSize(): number;
    set totalInitialRemoteDiskSize(value: number);
    resetTotalInitialRemoteDiskSize(): void;
    get totalInitialRemoteDiskSizeInput(): number | undefined;
    private _useMlRuntime?;
    get useMlRuntime(): boolean | cdktn.IResolvable;
    set useMlRuntime(value: boolean | cdktn.IResolvable);
    resetUseMlRuntime(): void;
    get useMlRuntimeInput(): boolean | cdktn.IResolvable | undefined;
    private _autoscale;
    get autoscale(): JobTaskNewClusterAutoscaleOutputReference;
    putAutoscale(value: JobTaskNewClusterAutoscale): void;
    resetAutoscale(): void;
    get autoscaleInput(): JobTaskNewClusterAutoscale | undefined;
    private _awsAttributes;
    get awsAttributes(): JobTaskNewClusterAwsAttributesOutputReference;
    putAwsAttributes(value: JobTaskNewClusterAwsAttributes): void;
    resetAwsAttributes(): void;
    get awsAttributesInput(): JobTaskNewClusterAwsAttributes | undefined;
    private _azureAttributes;
    get azureAttributes(): JobTaskNewClusterAzureAttributesOutputReference;
    putAzureAttributes(value: JobTaskNewClusterAzureAttributes): void;
    resetAzureAttributes(): void;
    get azureAttributesInput(): JobTaskNewClusterAzureAttributes | undefined;
    private _clusterLogConf;
    get clusterLogConf(): JobTaskNewClusterClusterLogConfOutputReference;
    putClusterLogConf(value: JobTaskNewClusterClusterLogConf): void;
    resetClusterLogConf(): void;
    get clusterLogConfInput(): JobTaskNewClusterClusterLogConf | undefined;
    private _clusterMountInfo;
    get clusterMountInfo(): JobTaskNewClusterClusterMountInfoList;
    putClusterMountInfo(value: JobTaskNewClusterClusterMountInfo[] | cdktn.IResolvable): void;
    resetClusterMountInfo(): void;
    get clusterMountInfoInput(): cdktn.IResolvable | JobTaskNewClusterClusterMountInfo[] | undefined;
    private _dockerImage;
    get dockerImage(): JobTaskNewClusterDockerImageOutputReference;
    putDockerImage(value: JobTaskNewClusterDockerImage): void;
    resetDockerImage(): void;
    get dockerImageInput(): JobTaskNewClusterDockerImage | undefined;
    private _driverNodeTypeFlexibility;
    get driverNodeTypeFlexibility(): JobTaskNewClusterDriverNodeTypeFlexibilityOutputReference;
    putDriverNodeTypeFlexibility(value: JobTaskNewClusterDriverNodeTypeFlexibility): void;
    resetDriverNodeTypeFlexibility(): void;
    get driverNodeTypeFlexibilityInput(): JobTaskNewClusterDriverNodeTypeFlexibility | undefined;
    private _gcpAttributes;
    get gcpAttributes(): JobTaskNewClusterGcpAttributesOutputReference;
    putGcpAttributes(value: JobTaskNewClusterGcpAttributes): void;
    resetGcpAttributes(): void;
    get gcpAttributesInput(): JobTaskNewClusterGcpAttributes | undefined;
    private _initScripts;
    get initScripts(): JobTaskNewClusterInitScriptsList;
    putInitScripts(value: JobTaskNewClusterInitScripts[] | cdktn.IResolvable): void;
    resetInitScripts(): void;
    get initScriptsInput(): cdktn.IResolvable | JobTaskNewClusterInitScripts[] | undefined;
    private _library;
    get library(): JobTaskNewClusterLibraryList;
    putLibrary(value: JobTaskNewClusterLibrary[] | cdktn.IResolvable): void;
    resetLibrary(): void;
    get libraryInput(): cdktn.IResolvable | JobTaskNewClusterLibrary[] | undefined;
    private _providerConfig;
    get providerConfig(): JobTaskNewClusterProviderConfigOutputReference;
    putProviderConfig(value: JobTaskNewClusterProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): JobTaskNewClusterProviderConfig | undefined;
    private _workerNodeTypeFlexibility;
    get workerNodeTypeFlexibility(): JobTaskNewClusterWorkerNodeTypeFlexibilityOutputReference;
    putWorkerNodeTypeFlexibility(value: JobTaskNewClusterWorkerNodeTypeFlexibility): void;
    resetWorkerNodeTypeFlexibility(): void;
    get workerNodeTypeFlexibilityInput(): JobTaskNewClusterWorkerNodeTypeFlexibility | undefined;
    private _workloadType;
    get workloadType(): JobTaskNewClusterWorkloadTypeOutputReference;
    putWorkloadType(value: JobTaskNewClusterWorkloadType): void;
    resetWorkloadType(): void;
    get workloadTypeInput(): JobTaskNewClusterWorkloadType | undefined;
}
export interface JobTaskNotebookTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#base_parameters Job#base_parameters}
    */
    readonly baseParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notebook_path Job#notebook_path}
    */
    readonly notebookPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
}
export declare function jobTaskNotebookTaskToTerraform(struct?: JobTaskNotebookTaskOutputReference | JobTaskNotebookTask): any;
export declare function jobTaskNotebookTaskToHclTerraform(struct?: JobTaskNotebookTaskOutputReference | JobTaskNotebookTask): any;
export declare class JobTaskNotebookTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNotebookTask | undefined;
    set internalValue(value: JobTaskNotebookTask | undefined);
    private _baseParameters?;
    get baseParameters(): {
        [key: string]: string;
    };
    set baseParameters(value: {
        [key: string]: string;
    });
    resetBaseParameters(): void;
    get baseParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookPath?;
    get notebookPath(): string;
    set notebookPath(value: string);
    get notebookPathInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
}
export interface JobTaskNotificationSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#alert_on_last_attempt Job#alert_on_last_attempt}
    */
    readonly alertOnLastAttempt?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#no_alert_for_canceled_runs Job#no_alert_for_canceled_runs}
    */
    readonly noAlertForCanceledRuns?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#no_alert_for_skipped_runs Job#no_alert_for_skipped_runs}
    */
    readonly noAlertForSkippedRuns?: boolean | cdktn.IResolvable;
}
export declare function jobTaskNotificationSettingsToTerraform(struct?: JobTaskNotificationSettingsOutputReference | JobTaskNotificationSettings): any;
export declare function jobTaskNotificationSettingsToHclTerraform(struct?: JobTaskNotificationSettingsOutputReference | JobTaskNotificationSettings): any;
export declare class JobTaskNotificationSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskNotificationSettings | undefined;
    set internalValue(value: JobTaskNotificationSettings | undefined);
    private _alertOnLastAttempt?;
    get alertOnLastAttempt(): boolean | cdktn.IResolvable;
    set alertOnLastAttempt(value: boolean | cdktn.IResolvable);
    resetAlertOnLastAttempt(): void;
    get alertOnLastAttemptInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForCanceledRuns?;
    get noAlertForCanceledRuns(): boolean | cdktn.IResolvable;
    set noAlertForCanceledRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForCanceledRuns(): void;
    get noAlertForCanceledRunsInput(): boolean | cdktn.IResolvable | undefined;
    private _noAlertForSkippedRuns?;
    get noAlertForSkippedRuns(): boolean | cdktn.IResolvable;
    set noAlertForSkippedRuns(value: boolean | cdktn.IResolvable);
    resetNoAlertForSkippedRuns(): void;
    get noAlertForSkippedRunsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskPipelineTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh Job#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh_selection Job#full_refresh_selection}
    */
    readonly fullRefreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pipeline_id Job#pipeline_id}
    */
    readonly pipelineId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_flow_selection Job#refresh_flow_selection}
    */
    readonly refreshFlowSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_selection Job#refresh_selection}
    */
    readonly refreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#reset_checkpoint_selection Job#reset_checkpoint_selection}
    */
    readonly resetCheckpointSelection?: string[];
}
export declare function jobTaskPipelineTaskToTerraform(struct?: JobTaskPipelineTaskOutputReference | JobTaskPipelineTask): any;
export declare function jobTaskPipelineTaskToHclTerraform(struct?: JobTaskPipelineTaskOutputReference | JobTaskPipelineTask): any;
export declare class JobTaskPipelineTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPipelineTask | undefined;
    set internalValue(value: JobTaskPipelineTask | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _fullRefreshSelection?;
    get fullRefreshSelection(): string[];
    set fullRefreshSelection(value: string[]);
    resetFullRefreshSelection(): void;
    get fullRefreshSelectionInput(): string[] | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
    private _refreshFlowSelection?;
    get refreshFlowSelection(): string[];
    set refreshFlowSelection(value: string[]);
    resetRefreshFlowSelection(): void;
    get refreshFlowSelectionInput(): string[] | undefined;
    private _refreshSelection?;
    get refreshSelection(): string[];
    set refreshSelection(value: string[]);
    resetRefreshSelection(): void;
    get refreshSelectionInput(): string[] | undefined;
    private _resetCheckpointSelection?;
    get resetCheckpointSelection(): string[];
    set resetCheckpointSelection(value: string[]);
    resetResetCheckpointSelection(): void;
    get resetCheckpointSelectionInput(): string[] | undefined;
}
export interface JobTaskPowerBiTaskPowerBiModel {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#authentication_method Job#authentication_method}
    */
    readonly authenticationMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#model_name Job#model_name}
    */
    readonly modelName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#overwrite_existing Job#overwrite_existing}
    */
    readonly overwriteExisting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#storage_mode Job#storage_mode}
    */
    readonly storageMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#workspace_name Job#workspace_name}
    */
    readonly workspaceName?: string;
}
export declare function jobTaskPowerBiTaskPowerBiModelToTerraform(struct?: JobTaskPowerBiTaskPowerBiModelOutputReference | JobTaskPowerBiTaskPowerBiModel): any;
export declare function jobTaskPowerBiTaskPowerBiModelToHclTerraform(struct?: JobTaskPowerBiTaskPowerBiModelOutputReference | JobTaskPowerBiTaskPowerBiModel): any;
export declare class JobTaskPowerBiTaskPowerBiModelOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPowerBiTaskPowerBiModel | undefined;
    set internalValue(value: JobTaskPowerBiTaskPowerBiModel | undefined);
    private _authenticationMethod?;
    get authenticationMethod(): string;
    set authenticationMethod(value: string);
    resetAuthenticationMethod(): void;
    get authenticationMethodInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    resetModelName(): void;
    get modelNameInput(): string | undefined;
    private _overwriteExisting?;
    get overwriteExisting(): boolean | cdktn.IResolvable;
    set overwriteExisting(value: boolean | cdktn.IResolvable);
    resetOverwriteExisting(): void;
    get overwriteExistingInput(): boolean | cdktn.IResolvable | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
    private _workspaceName?;
    get workspaceName(): string;
    set workspaceName(value: string);
    resetWorkspaceName(): void;
    get workspaceNameInput(): string | undefined;
}
export interface JobTaskPowerBiTaskTables {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#catalog Job#catalog}
    */
    readonly catalog?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#name Job#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#schema Job#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#storage_mode Job#storage_mode}
    */
    readonly storageMode?: string;
}
export declare function jobTaskPowerBiTaskTablesToTerraform(struct?: JobTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare function jobTaskPowerBiTaskTablesToHclTerraform(struct?: JobTaskPowerBiTaskTables | cdktn.IResolvable): any;
export declare class JobTaskPowerBiTaskTablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskPowerBiTaskTables | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskPowerBiTaskTables | cdktn.IResolvable | undefined);
    private _catalog?;
    get catalog(): string;
    set catalog(value: string);
    resetCatalog(): void;
    get catalogInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
}
export declare class JobTaskPowerBiTaskTablesList extends cdktn.ComplexList {
    internalValue?: JobTaskPowerBiTaskTables[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskPowerBiTaskTablesOutputReference;
}
export interface JobTaskPowerBiTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#connection_resource_name Job#connection_resource_name}
    */
    readonly connectionResourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_after_update Job#refresh_after_update}
    */
    readonly refreshAfterUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#warehouse_id Job#warehouse_id}
    */
    readonly warehouseId?: string;
    /**
    * power_bi_model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#power_bi_model Job#power_bi_model}
    */
    readonly powerBiModel?: JobTaskPowerBiTaskPowerBiModel;
    /**
    * tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#tables Job#tables}
    */
    readonly tables?: JobTaskPowerBiTaskTables[] | cdktn.IResolvable;
}
export declare function jobTaskPowerBiTaskToTerraform(struct?: JobTaskPowerBiTaskOutputReference | JobTaskPowerBiTask): any;
export declare function jobTaskPowerBiTaskToHclTerraform(struct?: JobTaskPowerBiTaskOutputReference | JobTaskPowerBiTask): any;
export declare class JobTaskPowerBiTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPowerBiTask | undefined;
    set internalValue(value: JobTaskPowerBiTask | undefined);
    private _connectionResourceName?;
    get connectionResourceName(): string;
    set connectionResourceName(value: string);
    resetConnectionResourceName(): void;
    get connectionResourceNameInput(): string | undefined;
    private _refreshAfterUpdate?;
    get refreshAfterUpdate(): boolean | cdktn.IResolvable;
    set refreshAfterUpdate(value: boolean | cdktn.IResolvable);
    resetRefreshAfterUpdate(): void;
    get refreshAfterUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _warehouseId?;
    get warehouseId(): string;
    set warehouseId(value: string);
    resetWarehouseId(): void;
    get warehouseIdInput(): string | undefined;
    private _powerBiModel;
    get powerBiModel(): JobTaskPowerBiTaskPowerBiModelOutputReference;
    putPowerBiModel(value: JobTaskPowerBiTaskPowerBiModel): void;
    resetPowerBiModel(): void;
    get powerBiModelInput(): JobTaskPowerBiTaskPowerBiModel | undefined;
    private _tables;
    get tables(): JobTaskPowerBiTaskTablesList;
    putTables(value: JobTaskPowerBiTaskTables[] | cdktn.IResolvable): void;
    resetTables(): void;
    get tablesInput(): cdktn.IResolvable | JobTaskPowerBiTaskTables[] | undefined;
}
export interface JobTaskPythonOperatorTaskParameters {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#name Job#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#value Job#value}
    */
    readonly value?: string;
}
export declare function jobTaskPythonOperatorTaskParametersToTerraform(struct?: JobTaskPythonOperatorTaskParameters | cdktn.IResolvable): any;
export declare function jobTaskPythonOperatorTaskParametersToHclTerraform(struct?: JobTaskPythonOperatorTaskParameters | cdktn.IResolvable): any;
export declare class JobTaskPythonOperatorTaskParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): JobTaskPythonOperatorTaskParameters | cdktn.IResolvable | undefined;
    set internalValue(value: JobTaskPythonOperatorTaskParameters | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class JobTaskPythonOperatorTaskParametersList extends cdktn.ComplexList {
    internalValue?: JobTaskPythonOperatorTaskParameters[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): JobTaskPythonOperatorTaskParametersOutputReference;
}
export interface JobTaskPythonOperatorTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#main Job#main}
    */
    readonly main?: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: JobTaskPythonOperatorTaskParameters[] | cdktn.IResolvable;
}
export declare function jobTaskPythonOperatorTaskToTerraform(struct?: JobTaskPythonOperatorTaskOutputReference | JobTaskPythonOperatorTask): any;
export declare function jobTaskPythonOperatorTaskToHclTerraform(struct?: JobTaskPythonOperatorTaskOutputReference | JobTaskPythonOperatorTask): any;
export declare class JobTaskPythonOperatorTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPythonOperatorTask | undefined;
    set internalValue(value: JobTaskPythonOperatorTask | undefined);
    private _main?;
    get main(): string;
    set main(value: string);
    resetMain(): void;
    get mainInput(): string | undefined;
    private _parameters;
    get parameters(): JobTaskPythonOperatorTaskParametersList;
    putParameters(value: JobTaskPythonOperatorTaskParameters[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | JobTaskPythonOperatorTaskParameters[] | undefined;
}
export interface JobTaskPythonWheelTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#entry_point Job#entry_point}
    */
    readonly entryPoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#named_parameters Job#named_parameters}
    */
    readonly namedParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#package_name Job#package_name}
    */
    readonly packageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobTaskPythonWheelTaskToTerraform(struct?: JobTaskPythonWheelTaskOutputReference | JobTaskPythonWheelTask): any;
export declare function jobTaskPythonWheelTaskToHclTerraform(struct?: JobTaskPythonWheelTaskOutputReference | JobTaskPythonWheelTask): any;
export declare class JobTaskPythonWheelTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskPythonWheelTask | undefined;
    set internalValue(value: JobTaskPythonWheelTask | undefined);
    private _entryPoint?;
    get entryPoint(): string;
    set entryPoint(value: string);
    resetEntryPoint(): void;
    get entryPointInput(): string | undefined;
    private _namedParameters?;
    get namedParameters(): {
        [key: string]: string;
    };
    set namedParameters(value: {
        [key: string]: string;
    });
    resetNamedParameters(): void;
    get namedParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    resetPackageName(): void;
    get packageNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
export interface JobTaskRunJobTaskPipelineParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh Job#full_refresh}
    */
    readonly fullRefresh?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#full_refresh_selection Job#full_refresh_selection}
    */
    readonly fullRefreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_flow_selection Job#refresh_flow_selection}
    */
    readonly refreshFlowSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#refresh_selection Job#refresh_selection}
    */
    readonly refreshSelection?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#reset_checkpoint_selection Job#reset_checkpoint_selection}
    */
    readonly resetCheckpointSelection?: string[];
}
export declare function jobTaskRunJobTaskPipelineParamsToTerraform(struct?: JobTaskRunJobTaskPipelineParamsOutputReference | JobTaskRunJobTaskPipelineParams): any;
export declare function jobTaskRunJobTaskPipelineParamsToHclTerraform(struct?: JobTaskRunJobTaskPipelineParamsOutputReference | JobTaskRunJobTaskPipelineParams): any;
export declare class JobTaskRunJobTaskPipelineParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskRunJobTaskPipelineParams | undefined;
    set internalValue(value: JobTaskRunJobTaskPipelineParams | undefined);
    private _fullRefresh?;
    get fullRefresh(): boolean | cdktn.IResolvable;
    set fullRefresh(value: boolean | cdktn.IResolvable);
    resetFullRefresh(): void;
    get fullRefreshInput(): boolean | cdktn.IResolvable | undefined;
    private _fullRefreshSelection?;
    get fullRefreshSelection(): string[];
    set fullRefreshSelection(value: string[]);
    resetFullRefreshSelection(): void;
    get fullRefreshSelectionInput(): string[] | undefined;
    private _refreshFlowSelection?;
    get refreshFlowSelection(): string[];
    set refreshFlowSelection(value: string[]);
    resetRefreshFlowSelection(): void;
    get refreshFlowSelectionInput(): string[] | undefined;
    private _refreshSelection?;
    get refreshSelection(): string[];
    set refreshSelection(value: string[]);
    resetRefreshSelection(): void;
    get refreshSelectionInput(): string[] | undefined;
    private _resetCheckpointSelection?;
    get resetCheckpointSelection(): string[];
    set resetCheckpointSelection(value: string[]);
    resetResetCheckpointSelection(): void;
    get resetCheckpointSelectionInput(): string[] | undefined;
}
export interface JobTaskRunJobTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#dbt_commands Job#dbt_commands}
    */
    readonly dbtCommands?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar_params Job#jar_params}
    */
    readonly jarParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#job_id Job#job_id}
    */
    readonly jobId: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#job_parameters Job#job_parameters}
    */
    readonly jobParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#notebook_params Job#notebook_params}
    */
    readonly notebookParams?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_named_params Job#python_named_params}
    */
    readonly pythonNamedParams?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_params Job#python_params}
    */
    readonly pythonParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#spark_submit_params Job#spark_submit_params}
    */
    readonly sparkSubmitParams?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#sql_params Job#sql_params}
    */
    readonly sqlParams?: {
        [key: string]: string;
    };
    /**
    * pipeline_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#pipeline_params Job#pipeline_params}
    */
    readonly pipelineParams?: JobTaskRunJobTaskPipelineParams;
}
export declare function jobTaskRunJobTaskToTerraform(struct?: JobTaskRunJobTaskOutputReference | JobTaskRunJobTask): any;
export declare function jobTaskRunJobTaskToHclTerraform(struct?: JobTaskRunJobTaskOutputReference | JobTaskRunJobTask): any;
export declare class JobTaskRunJobTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskRunJobTask | undefined;
    set internalValue(value: JobTaskRunJobTask | undefined);
    private _dbtCommands?;
    get dbtCommands(): string[];
    set dbtCommands(value: string[]);
    resetDbtCommands(): void;
    get dbtCommandsInput(): string[] | undefined;
    private _jarParams?;
    get jarParams(): string[];
    set jarParams(value: string[]);
    resetJarParams(): void;
    get jarParamsInput(): string[] | undefined;
    private _jobId?;
    get jobId(): number;
    set jobId(value: number);
    get jobIdInput(): number | undefined;
    private _jobParameters?;
    get jobParameters(): {
        [key: string]: string;
    };
    set jobParameters(value: {
        [key: string]: string;
    });
    resetJobParameters(): void;
    get jobParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _notebookParams?;
    get notebookParams(): {
        [key: string]: string;
    };
    set notebookParams(value: {
        [key: string]: string;
    });
    resetNotebookParams(): void;
    get notebookParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pythonNamedParams?;
    get pythonNamedParams(): {
        [key: string]: string;
    };
    set pythonNamedParams(value: {
        [key: string]: string;
    });
    resetPythonNamedParams(): void;
    get pythonNamedParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pythonParams?;
    get pythonParams(): string[];
    set pythonParams(value: string[]);
    resetPythonParams(): void;
    get pythonParamsInput(): string[] | undefined;
    private _sparkSubmitParams?;
    get sparkSubmitParams(): string[];
    set sparkSubmitParams(value: string[]);
    resetSparkSubmitParams(): void;
    get sparkSubmitParamsInput(): string[] | undefined;
    private _sqlParams?;
    get sqlParams(): {
        [key: string]: string;
    };
    set sqlParams(value: {
        [key: string]: string;
    });
    resetSqlParams(): void;
    get sqlParamsInput(): {
        [key: string]: string;
    } | undefined;
    private _pipelineParams;
    get pipelineParams(): JobTaskRunJobTaskPipelineParamsOutputReference;
    putPipelineParams(value: JobTaskRunJobTaskPipelineParams): void;
    resetPipelineParams(): void;
    get pipelineParamsInput(): JobTaskRunJobTaskPipelineParams | undefined;
}
export interface JobTaskSparkJarTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#jar_uri Job#jar_uri}
    */
    readonly jarUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#main_class_name Job#main_class_name}
    */
    readonly mainClassName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#run_as_repl Job#run_as_repl}
    */
    readonly runAsRepl?: boolean | cdktn.IResolvable;
}
export declare function jobTaskSparkJarTaskToTerraform(struct?: JobTaskSparkJarTaskOutputReference | JobTaskSparkJarTask): any;
export declare function jobTaskSparkJarTaskToHclTerraform(struct?: JobTaskSparkJarTaskOutputReference | JobTaskSparkJarTask): any;
export declare class JobTaskSparkJarTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSparkJarTask | undefined;
    set internalValue(value: JobTaskSparkJarTask | undefined);
    private _jarUri?;
    get jarUri(): string;
    set jarUri(value: string);
    resetJarUri(): void;
    get jarUriInput(): string | undefined;
    private _mainClassName?;
    get mainClassName(): string;
    set mainClassName(value: string);
    resetMainClassName(): void;
    get mainClassNameInput(): string | undefined;
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _runAsRepl?;
    get runAsRepl(): boolean | cdktn.IResolvable;
    set runAsRepl(value: boolean | cdktn.IResolvable);
    resetRunAsRepl(): void;
    get runAsReplInput(): boolean | cdktn.IResolvable | undefined;
}
export interface JobTaskSparkPythonTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#python_file Job#python_file}
    */
    readonly pythonFile: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#source Job#source}
    */
    readonly source?: string;
}
export declare function jobTaskSparkPythonTaskToTerraform(struct?: JobTaskSparkPythonTaskOutputReference | JobTaskSparkPythonTask): any;
export declare function jobTaskSparkPythonTaskToHclTerraform(struct?: JobTaskSparkPythonTaskOutputReference | JobTaskSparkPythonTask): any;
export declare class JobTaskSparkPythonTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSparkPythonTask | undefined;
    set internalValue(value: JobTaskSparkPythonTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
    private _pythonFile?;
    get pythonFile(): string;
    set pythonFile(value: string);
    get pythonFileInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export interface JobTaskSparkSubmitTask {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/job#parameters Job#parameters}
    */
    readonly parameters?: string[];
}
export declare function jobTaskSparkSubmitTaskToTerraform(struct?: JobTaskSparkSubmitTaskOutputReference | JobTaskSparkSubmitTask): any;
export declare function jobTaskSparkSubmitTaskToHclTerraform(struct?: JobTaskSparkSubmitTaskOutputReference | JobTaskSparkSubmitTask): any;
export declare class JobTaskSparkSubmitTaskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): JobTaskSparkSubmitTask | undefined;
    set internalValue(value: JobTaskSparkSubmitTask | undefined);
    private _parameters?;
    get parameters(): string[];
    set parameters(value: string[]);
    resetParameters(): void;
    get parametersInput(): string[] | undefined;
}
