/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FeatureEngineeringKafkaConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#auth_config FeatureEngineeringKafkaConfig#auth_config}
    */
    readonly authConfig: FeatureEngineeringKafkaConfigAuthConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#backfill_source FeatureEngineeringKafkaConfig#backfill_source}
    */
    readonly backfillSource?: FeatureEngineeringKafkaConfigBackfillSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#bootstrap_servers FeatureEngineeringKafkaConfig#bootstrap_servers}
    */
    readonly bootstrapServers: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#extra_options FeatureEngineeringKafkaConfig#extra_options}
    */
    readonly extraOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#ingestion_config FeatureEngineeringKafkaConfig#ingestion_config}
    */
    readonly ingestionConfig?: FeatureEngineeringKafkaConfigIngestionConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#key_schema FeatureEngineeringKafkaConfig#key_schema}
    */
    readonly keySchema?: FeatureEngineeringKafkaConfigKeySchema;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#provider_config FeatureEngineeringKafkaConfig#provider_config}
    */
    readonly providerConfig?: FeatureEngineeringKafkaConfigProviderConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#subscription_mode FeatureEngineeringKafkaConfig#subscription_mode}
    */
    readonly subscriptionMode: FeatureEngineeringKafkaConfigSubscriptionMode;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#value_schema FeatureEngineeringKafkaConfig#value_schema}
    */
    readonly valueSchema?: FeatureEngineeringKafkaConfigValueSchema;
}
export interface FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#key FeatureEngineeringKafkaConfig#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#scope FeatureEngineeringKafkaConfig#scope}
    */
    readonly scope: string;
}
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefToTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefToHclTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#key FeatureEngineeringKafkaConfig#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#scope FeatureEngineeringKafkaConfig#scope}
    */
    readonly scope: string;
}
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefToTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefToHclTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#key FeatureEngineeringKafkaConfig#key}
    */
    readonly key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#scope FeatureEngineeringKafkaConfig#scope}
    */
    readonly scope: string;
}
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefToTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefToHclTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigAuthConfigMtlsConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#disable_hostname_verification FeatureEngineeringKafkaConfig#disable_hostname_verification}
    */
    readonly disableHostnameVerification?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#key_password_ref FeatureEngineeringKafkaConfig#key_password_ref}
    */
    readonly keyPasswordRef: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#keystore_location FeatureEngineeringKafkaConfig#keystore_location}
    */
    readonly keystoreLocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#keystore_password_ref FeatureEngineeringKafkaConfig#keystore_password_ref}
    */
    readonly keystorePasswordRef: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#truststore_location FeatureEngineeringKafkaConfig#truststore_location}
    */
    readonly truststoreLocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#truststore_password_ref FeatureEngineeringKafkaConfig#truststore_password_ref}
    */
    readonly truststorePasswordRef: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef;
}
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigToTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigAuthConfigMtlsConfigToHclTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigAuthConfigMtlsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfig | cdktn.IResolvable | undefined);
    private _disableHostnameVerification?;
    get disableHostnameVerification(): boolean | cdktn.IResolvable;
    set disableHostnameVerification(value: boolean | cdktn.IResolvable);
    resetDisableHostnameVerification(): void;
    get disableHostnameVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _keyPasswordRef;
    get keyPasswordRef(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRefOutputReference;
    putKeyPasswordRef(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef): void;
    get keyPasswordRefInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeyPasswordRef | undefined;
    private _keystoreLocation?;
    get keystoreLocation(): string;
    set keystoreLocation(value: string);
    get keystoreLocationInput(): string | undefined;
    private _keystorePasswordRef;
    get keystorePasswordRef(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRefOutputReference;
    putKeystorePasswordRef(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef): void;
    get keystorePasswordRefInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigAuthConfigMtlsConfigKeystorePasswordRef | undefined;
    private _truststoreLocation?;
    get truststoreLocation(): string;
    set truststoreLocation(value: string);
    get truststoreLocationInput(): string | undefined;
    private _truststorePasswordRef;
    get truststorePasswordRef(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRefOutputReference;
    putTruststorePasswordRef(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef): void;
    get truststorePasswordRefInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigAuthConfigMtlsConfigTruststorePasswordRef | undefined;
}
export interface FeatureEngineeringKafkaConfigAuthConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#mtls_config FeatureEngineeringKafkaConfig#mtls_config}
    */
    readonly mtlsConfig?: FeatureEngineeringKafkaConfigAuthConfigMtlsConfig;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#uc_service_credential_name FeatureEngineeringKafkaConfig#uc_service_credential_name}
    */
    readonly ucServiceCredentialName?: string;
}
export declare function featureEngineeringKafkaConfigAuthConfigToTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigAuthConfigToHclTerraform(struct?: FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigAuthConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigAuthConfig | cdktn.IResolvable | undefined);
    private _mtlsConfig;
    get mtlsConfig(): FeatureEngineeringKafkaConfigAuthConfigMtlsConfigOutputReference;
    putMtlsConfig(value: FeatureEngineeringKafkaConfigAuthConfigMtlsConfig): void;
    resetMtlsConfig(): void;
    get mtlsConfigInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigAuthConfigMtlsConfig | undefined;
    private _ucServiceCredentialName?;
    get ucServiceCredentialName(): string;
    set ucServiceCredentialName(value: string);
    resetUcServiceCredentialName(): void;
    get ucServiceCredentialNameInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#dataframe_schema FeatureEngineeringKafkaConfig#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#entity_columns FeatureEngineeringKafkaConfig#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#filter_condition FeatureEngineeringKafkaConfig#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#full_name FeatureEngineeringKafkaConfig#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#timeseries_column FeatureEngineeringKafkaConfig#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#transformation_sql FeatureEngineeringKafkaConfig#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function featureEngineeringKafkaConfigBackfillSourceDeltaTableSourceToTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigBackfillSourceDeltaTableSourceToHclTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigBackfillSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#delta_table_name FeatureEngineeringKafkaConfig#delta_table_name}
    */
    readonly deltaTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#delta_table_source FeatureEngineeringKafkaConfig#delta_table_source}
    */
    readonly deltaTableSource?: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource;
}
export declare function featureEngineeringKafkaConfigBackfillSourceToTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigBackfillSourceToHclTerraform(struct?: FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigBackfillSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigBackfillSource | cdktn.IResolvable | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
    private _deltaTableSource;
    get deltaTableSource(): FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigBackfillSourceDeltaTableSource | undefined;
}
export interface FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#dataframe_schema FeatureEngineeringKafkaConfig#dataframe_schema}
    */
    readonly dataframeSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#entity_columns FeatureEngineeringKafkaConfig#entity_columns}
    */
    readonly entityColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#filter_condition FeatureEngineeringKafkaConfig#filter_condition}
    */
    readonly filterCondition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#full_name FeatureEngineeringKafkaConfig#full_name}
    */
    readonly fullName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#timeseries_column FeatureEngineeringKafkaConfig#timeseries_column}
    */
    readonly timeseriesColumn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#transformation_sql FeatureEngineeringKafkaConfig#transformation_sql}
    */
    readonly transformationSql?: string;
}
export declare function featureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceToTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceToHclTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | cdktn.IResolvable | undefined);
    private _dataframeSchema?;
    get dataframeSchema(): string;
    set dataframeSchema(value: string);
    resetDataframeSchema(): void;
    get dataframeSchemaInput(): string | undefined;
    private _entityColumns?;
    get entityColumns(): string[];
    set entityColumns(value: string[]);
    resetEntityColumns(): void;
    get entityColumnsInput(): string[] | undefined;
    private _filterCondition?;
    get filterCondition(): string;
    set filterCondition(value: string);
    resetFilterCondition(): void;
    get filterConditionInput(): string | undefined;
    private _fullName?;
    get fullName(): string;
    set fullName(value: string);
    get fullNameInput(): string | undefined;
    private _timeseriesColumn?;
    get timeseriesColumn(): string;
    set timeseriesColumn(value: string);
    resetTimeseriesColumn(): void;
    get timeseriesColumnInput(): string | undefined;
    private _transformationSql?;
    get transformationSql(): string;
    set transformationSql(value: string);
    resetTransformationSql(): void;
    get transformationSqlInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigIngestionConfigBackfillSource {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#delta_table_name FeatureEngineeringKafkaConfig#delta_table_name}
    */
    readonly deltaTableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#delta_table_source FeatureEngineeringKafkaConfig#delta_table_source}
    */
    readonly deltaTableSource?: FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource;
}
export declare function featureEngineeringKafkaConfigIngestionConfigBackfillSourceToTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigIngestionConfigBackfillSourceToHclTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigIngestionConfigBackfillSource | cdktn.IResolvable | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
    private _deltaTableSource;
    get deltaTableSource(): FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSourceOutputReference;
    putDeltaTableSource(value: FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource): void;
    resetDeltaTableSource(): void;
    get deltaTableSourceInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceDeltaTableSource | undefined;
}
export interface FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#delta_table_name FeatureEngineeringKafkaConfig#delta_table_name}
    */
    readonly deltaTableName?: string;
}
export declare function featureEngineeringKafkaConfigIngestionConfigIngestionDestinationToTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigIngestionConfigIngestionDestinationToHclTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigIngestionConfigIngestionDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | cdktn.IResolvable | undefined);
    private _deltaTableName?;
    get deltaTableName(): string;
    set deltaTableName(value: string);
    resetDeltaTableName(): void;
    get deltaTableNameInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigIngestionConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#backfill_source FeatureEngineeringKafkaConfig#backfill_source}
    */
    readonly backfillSource?: FeatureEngineeringKafkaConfigIngestionConfigBackfillSource;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#deduplication_columns FeatureEngineeringKafkaConfig#deduplication_columns}
    */
    readonly deduplicationColumns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#ingestion_destination FeatureEngineeringKafkaConfig#ingestion_destination}
    */
    readonly ingestionDestination: FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination;
}
export declare function featureEngineeringKafkaConfigIngestionConfigToTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfig | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigIngestionConfigToHclTerraform(struct?: FeatureEngineeringKafkaConfigIngestionConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigIngestionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigIngestionConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigIngestionConfig | cdktn.IResolvable | undefined);
    get backfillJobId(): number;
    private _backfillSource;
    get backfillSource(): FeatureEngineeringKafkaConfigIngestionConfigBackfillSourceOutputReference;
    putBackfillSource(value: FeatureEngineeringKafkaConfigIngestionConfigBackfillSource): void;
    resetBackfillSource(): void;
    get backfillSourceInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigIngestionConfigBackfillSource | undefined;
    private _deduplicationColumns?;
    get deduplicationColumns(): string[];
    set deduplicationColumns(value: string[]);
    resetDeduplicationColumns(): void;
    get deduplicationColumnsInput(): string[] | undefined;
    private _ingestionDestination;
    get ingestionDestination(): FeatureEngineeringKafkaConfigIngestionConfigIngestionDestinationOutputReference;
    putIngestionDestination(value: FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination): void;
    get ingestionDestinationInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigIngestionConfigIngestionDestination | undefined;
    get ingestionJobId(): number;
    get ingestionPipelineId(): string;
}
export interface FeatureEngineeringKafkaConfigKeySchemaProtoSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#message_name FeatureEngineeringKafkaConfig#message_name}
    */
    readonly messageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#schema_text FeatureEngineeringKafkaConfig#schema_text}
    */
    readonly schemaText: string;
}
export declare function featureEngineeringKafkaConfigKeySchemaProtoSchemaToTerraform(struct?: FeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigKeySchemaProtoSchemaToHclTerraform(struct?: FeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigKeySchemaProtoSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigKeySchemaProtoSchema | cdktn.IResolvable | undefined);
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    get messageNameInput(): string | undefined;
    private _schemaText?;
    get schemaText(): string;
    set schemaText(value: string);
    get schemaTextInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigKeySchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#avro_schema FeatureEngineeringKafkaConfig#avro_schema}
    */
    readonly avroSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}
    */
    readonly jsonSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#proto_schema FeatureEngineeringKafkaConfig#proto_schema}
    */
    readonly protoSchema?: FeatureEngineeringKafkaConfigKeySchemaProtoSchema;
}
export declare function featureEngineeringKafkaConfigKeySchemaToTerraform(struct?: FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigKeySchemaToHclTerraform(struct?: FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigKeySchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigKeySchema | cdktn.IResolvable | undefined);
    private _avroSchema?;
    get avroSchema(): string;
    set avroSchema(value: string);
    resetAvroSchema(): void;
    get avroSchemaInput(): string | undefined;
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
    private _protoSchema;
    get protoSchema(): FeatureEngineeringKafkaConfigKeySchemaProtoSchemaOutputReference;
    putProtoSchema(value: FeatureEngineeringKafkaConfigKeySchemaProtoSchema): void;
    resetProtoSchema(): void;
    get protoSchemaInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigKeySchemaProtoSchema | undefined;
}
export interface FeatureEngineeringKafkaConfigProviderConfig {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#workspace_id FeatureEngineeringKafkaConfig#workspace_id}
    */
    readonly workspaceId?: string;
}
export declare function featureEngineeringKafkaConfigProviderConfigToTerraform(struct?: FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigProviderConfigToHclTerraform(struct?: FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigProviderConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigProviderConfig | cdktn.IResolvable | undefined);
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigSubscriptionMode {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#assign FeatureEngineeringKafkaConfig#assign}
    */
    readonly assign?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#subscribe FeatureEngineeringKafkaConfig#subscribe}
    */
    readonly subscribe?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#subscribe_pattern FeatureEngineeringKafkaConfig#subscribe_pattern}
    */
    readonly subscribePattern?: string;
}
export declare function featureEngineeringKafkaConfigSubscriptionModeToTerraform(struct?: FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigSubscriptionModeToHclTerraform(struct?: FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigSubscriptionModeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigSubscriptionMode | cdktn.IResolvable | undefined);
    private _assign?;
    get assign(): string;
    set assign(value: string);
    resetAssign(): void;
    get assignInput(): string | undefined;
    private _subscribe?;
    get subscribe(): string;
    set subscribe(value: string);
    resetSubscribe(): void;
    get subscribeInput(): string | undefined;
    private _subscribePattern?;
    get subscribePattern(): string;
    set subscribePattern(value: string);
    resetSubscribePattern(): void;
    get subscribePatternInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigValueSchemaProtoSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#message_name FeatureEngineeringKafkaConfig#message_name}
    */
    readonly messageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#schema_text FeatureEngineeringKafkaConfig#schema_text}
    */
    readonly schemaText: string;
}
export declare function featureEngineeringKafkaConfigValueSchemaProtoSchemaToTerraform(struct?: FeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigValueSchemaProtoSchemaToHclTerraform(struct?: FeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigValueSchemaProtoSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigValueSchemaProtoSchema | cdktn.IResolvable | undefined);
    private _messageName?;
    get messageName(): string;
    set messageName(value: string);
    get messageNameInput(): string | undefined;
    private _schemaText?;
    get schemaText(): string;
    set schemaText(value: string);
    get schemaTextInput(): string | undefined;
}
export interface FeatureEngineeringKafkaConfigValueSchema {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#avro_schema FeatureEngineeringKafkaConfig#avro_schema}
    */
    readonly avroSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#json_schema FeatureEngineeringKafkaConfig#json_schema}
    */
    readonly jsonSchema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#proto_schema FeatureEngineeringKafkaConfig#proto_schema}
    */
    readonly protoSchema?: FeatureEngineeringKafkaConfigValueSchemaProtoSchema;
}
export declare function featureEngineeringKafkaConfigValueSchemaToTerraform(struct?: FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable): any;
export declare function featureEngineeringKafkaConfigValueSchemaToHclTerraform(struct?: FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable): any;
export declare class FeatureEngineeringKafkaConfigValueSchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable | undefined;
    set internalValue(value: FeatureEngineeringKafkaConfigValueSchema | cdktn.IResolvable | undefined);
    private _avroSchema?;
    get avroSchema(): string;
    set avroSchema(value: string);
    resetAvroSchema(): void;
    get avroSchemaInput(): string | undefined;
    private _jsonSchema?;
    get jsonSchema(): string;
    set jsonSchema(value: string);
    resetJsonSchema(): void;
    get jsonSchemaInput(): string | undefined;
    private _protoSchema;
    get protoSchema(): FeatureEngineeringKafkaConfigValueSchemaProtoSchemaOutputReference;
    putProtoSchema(value: FeatureEngineeringKafkaConfigValueSchemaProtoSchema): void;
    resetProtoSchema(): void;
    get protoSchemaInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigValueSchemaProtoSchema | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config}
*/
export declare class FeatureEngineeringKafkaConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "databricks_feature_engineering_kafka_config";
    /**
    * Generates CDKTN code for importing a FeatureEngineeringKafkaConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FeatureEngineeringKafkaConfig to import
    * @param importFromId The id of the existing FeatureEngineeringKafkaConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FeatureEngineeringKafkaConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/databricks/databricks/1.124.0/docs/resources/feature_engineering_kafka_config databricks_feature_engineering_kafka_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FeatureEngineeringKafkaConfigConfig
    */
    constructor(scope: Construct, id: string, config: FeatureEngineeringKafkaConfigConfig);
    private _authConfig;
    get authConfig(): FeatureEngineeringKafkaConfigAuthConfigOutputReference;
    putAuthConfig(value: FeatureEngineeringKafkaConfigAuthConfig): void;
    get authConfigInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigAuthConfig | undefined;
    private _backfillSource;
    get backfillSource(): FeatureEngineeringKafkaConfigBackfillSourceOutputReference;
    putBackfillSource(value: FeatureEngineeringKafkaConfigBackfillSource): void;
    resetBackfillSource(): void;
    get backfillSourceInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigBackfillSource | undefined;
    private _bootstrapServers?;
    get bootstrapServers(): string;
    set bootstrapServers(value: string);
    get bootstrapServersInput(): string | undefined;
    private _extraOptions?;
    get extraOptions(): {
        [key: string]: string;
    };
    set extraOptions(value: {
        [key: string]: string;
    });
    resetExtraOptions(): void;
    get extraOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _ingestionConfig;
    get ingestionConfig(): FeatureEngineeringKafkaConfigIngestionConfigOutputReference;
    putIngestionConfig(value: FeatureEngineeringKafkaConfigIngestionConfig): void;
    resetIngestionConfig(): void;
    get ingestionConfigInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigIngestionConfig | undefined;
    private _keySchema;
    get keySchema(): FeatureEngineeringKafkaConfigKeySchemaOutputReference;
    putKeySchema(value: FeatureEngineeringKafkaConfigKeySchema): void;
    resetKeySchema(): void;
    get keySchemaInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigKeySchema | undefined;
    get name(): string;
    private _providerConfig;
    get providerConfig(): FeatureEngineeringKafkaConfigProviderConfigOutputReference;
    putProviderConfig(value: FeatureEngineeringKafkaConfigProviderConfig): void;
    resetProviderConfig(): void;
    get providerConfigInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigProviderConfig | undefined;
    private _subscriptionMode;
    get subscriptionMode(): FeatureEngineeringKafkaConfigSubscriptionModeOutputReference;
    putSubscriptionMode(value: FeatureEngineeringKafkaConfigSubscriptionMode): void;
    get subscriptionModeInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigSubscriptionMode | undefined;
    private _valueSchema;
    get valueSchema(): FeatureEngineeringKafkaConfigValueSchemaOutputReference;
    putValueSchema(value: FeatureEngineeringKafkaConfigValueSchema): void;
    resetValueSchema(): void;
    get valueSchemaInput(): cdktn.IResolvable | FeatureEngineeringKafkaConfigValueSchema | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
